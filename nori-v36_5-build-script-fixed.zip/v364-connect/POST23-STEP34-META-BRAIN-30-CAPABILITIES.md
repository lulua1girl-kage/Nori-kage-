# Post-23 Step 34 — Nori Meta-Brain / 30 Capability Expansion

## Purpose
Step 34 turns the previous feature catalog into one supervisory cognitive layer. It does not create a second assistant. `NoriMetaBrainEngine` coordinates the 30 capability families through a bounded cycle:

UNDERSTAND → CONTEXT → RECALL → REASON → STRATEGY → CONTROL → EXECUTE → VERIFY → RECOVER → LEARN

The engine does not expose or persist hidden chain-of-thought.

## The 30 capability families

1. **Real cognitive loop** — one lifecycle for requests instead of isolated feature calls.
2. **Personal world model** — stores structured subject/relation/value/source facts with confidence and time.
3. **Temporal intelligence** — distinguishes immediate continuation, same-session gaps, same-day gaps and multi-day changes.
4. **Causal reasoning** — keeps possible causes separate from established causality.
5. **Counterfactual reasoning** — creates bounded change/hold/reverse scenarios.
6. **Adaptive personality** — selects a response posture from seriousness, capacity and academic context.
7. **Conversation state** — recognizes discovery, planning, action and follow-up transitions.
8. **Relationship continuity** — compares current requests with prior outcomes without creating dependency.
9. **Dynamic goal graph** — represents goal → domain → prerequisites → checkpoint → action → verification.
10. **Skill graph** — separates knowledge, recognition, application, problem solving, self-check and transfer.
11. **Misconception detection** — looks for repeated conceptual error rather than treating every wrong answer as a misconception.
12. **Transfer intelligence** — compares familiar-context and novel-context performance.
13. **Retention model** — uses retrieval history to flag when refresh/recheck is useful, without claiming mastery from one signal.
14. **Strategy experiments** — records bounded strategy outcomes and produces local evidence signals.
15. **Intervention intelligence** — compares expected benefit with interruption cost and protected windows.
16. **Human-state reasoning** — handles explicit fatigue/overload and capacity signals without diagnosis.
17. **Disclosure context** — treats voluntary personal disclosure as context, not diagnosis or forced interrogation.
18. **Contradiction resolution** — flags conflicts and requests scope/time/evidence checks rather than choosing arbitrarily.
19. **Evidence graph** — models claim → evidence → interpretation → confidence → decision.
20. **Self-correction** — records correction events so changed behavior can be checked later.
21. **Capability execution lifecycle** — Discover → Understand → Resolve → Prepare → Preview → Authorize → Execute → Verify → Recover → Learn.
22. **Edge-AI execution policy** — prefers local processing for private data and uses remote fallback only when permitted.
23. **Model arbitration** — chooses a capability-matched local/provider path based on privacy, modality, latency and network.
24. **Research brain** — dynamically selects 3 / 8 / 15 / 25 source targets according to question depth.
25. **World awareness** — marks information LIVE_RECENT, RECENT, STALE_RECHECK_REQUIRED or offline-unknown.
26. **App operating model** — resolves common goals to Nori destinations such as Study Center, Results, Calendar, Alarms, Focus and Recover.
27. **Failure recovery** — retries once when safe, chooses an alternate route when available, otherwise fails closed and explains the limitation.
28. **Resource intelligence** — adapts work for low memory, battery, network and heavy-task conditions.
29. **Meta-brain capability matrix** — every capability has an explicit truth record: understood, guideable, executable, verifiable and route.
30. **Meta-brain supervision** — maintains one coherent supervisory strategy over the other 29 capabilities.

## Control rules

- Understanding never equals authorization.
- External side effects require explicit user control and existing Nori permission/ActionEngine gates.
- Current information requires fresh evidence when available; otherwise Nori states the freshness limitation.
- Personal context is relevance-bounded; uncertainty and conflicts remain visible to the decision layer.
- Human Override remains authoritative.
- Device/app evidence is not treated as proof of human intent or behavior.
- No covert microphone/camera/screen monitoring is introduced by Step 34.
- No unrestricted background autonomy is introduced.
- No silent self-modification is introduced.
- No hidden chain-of-thought is stored or exposed.

## Integration

`NoriBrain` owns one `NoriMetaBrainEngine` instance and exposes:

- `getMetaBrainEngine()`
- `thinkMeta(...)`

The existing Brain, Constitution, User Control, ActionEngine, Edge-AI layer, memory, state and verification systems remain authoritative. Step 34 is additive and is intended to become the coordination layer for later real execution adapters.

## Verification boundary

The Step 34 engine and its test are pure Java and can be compiled without Android SDK. The complete Android APK/device path still requires the Android SDK/Gradle environment and real-device testing. The 30 entries are implemented as bounded cognitive contracts and local decision functions; they are not a claim that every downstream Android capability is already fully device-wired.
