#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
JAVA="$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/capacity/NoriBrainCapacityEngine.java"
CAT="$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/capacity/NoriBrainCapacityCatalog.java"
AI="$ROOT/android/app/src/main/java/com/nori/jarvis/nori/ai/AiRouter.java"
[[ -f "$JAVA" && -f "$CAT" && -f "$AI" ]] || { echo "STEP15_FAIL missing source"; exit 1; }
grep -q 'local_first' "$JAVA"
grep -q 'researchTarget' "$JAVA"
grep -q 'Human Override' "$CAT" || true
grep -q 'providerCooldownUntil' "$AI"
grep -q 'generateStreaming' "$AI"
TMP="$ROOT/.step15-check"
rm -rf "$TMP"; mkdir -p "$TMP"
javac -d "$TMP" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/human/HumanContextEngine.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/human/NoriSupportPolicy.java" \
 "$JAVA" "$CAT"
echo "POST23_STEP15_BRAIN_CAPACITY_SOURCE_PASS"
