#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
node --check "$ROOT/www/nori-focus-policy-v2.js"
node --check "$ROOT/www/nori-sensitive-history-v1.js"
node --check "$ROOT/www/nori-conversation-v3.js"
node --check "$ROOT/www/nori-interactive-presence-v1.js"
grep -q 'NoriBiometricPlugin' "$ROOT/android/app/src/main/java/com/nori/jarvis/MainActivity.java"
grep -q 'NoriFocusReasoner' "$ROOT/android/app/src/main/java/com/nori/jarvis/NoriBlockerService.java"
grep -q 'social_publication_is_never_allowed' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/actions/EducationalPurposeFirewall.java"
grep -q 'analyzeScreenEvidence' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'PRIVATE CHAT — LOCKED' "$ROOT/www/nori-conversation-v3.js"
echo 'POST23_STEP9_FOCUS_REASONING_PRIVACY_PASS'
