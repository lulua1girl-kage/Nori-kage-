# Post-23 Step 20 — Constitutional Brain + Governed Memory

## Goal
Advance two Stage 23 gaps without replacing existing Nori behavior:

1. Nori Constitution becomes an executable narrowing authority.
2. Memory becomes a decision-time context service rather than a passive store.

## Constitution — now functional
`NoriConstitution` evaluates proposed Brain operations before AI/tool pathways and applies the existing principles:
- Human Override remains final human authority.
- Safety can only narrow behavior.
- Educational integrity blocks cheating/assessment bypass patterns.
- Privacy rejects credential/private-secret exposure paths for persistence and can force review.
- Anti-dependency adjusts behavior toward user decision authority.
- Proportionality keeps intervention bounded.
- Capability disclosure is included in the system contract.

The Constitution does not replace `HumanOverrideGuard`, `ConsequenceSafetyGuard`, or existing privacy controls. It composes them.

## Memory — now part of reasoning
`NoriMemoryContext` performs decision-time retrieval from the existing MemoryEngine and creates a small working set using:
- lexical/task fit
- confidence
- importance
- recency decay
- topic consolidation
- conflict detection
- stale-memory detection

The working set is injected into optional AI requests and academic reasoning as bounded context. Conflicting or stale memories are explicitly marked as uncertain rather than silently treated as facts.

`NoriMemoryLifecycle` provides a non-destructive audit for stale and consolidation candidates. It never silently deletes or rewrites user memory.

## Why no vector database yet
A vector database is not required to fix the current architectural gap. Current memory is already governed, local-first and editable. The immediate priority is correct write policy + retrieval + ranking + supersession + decision integration. A future semantic index can sit behind this interface without changing the Brain contract.

## Performance
The new layers are local deterministic Java and bounded. They add no network call to cognitive preflight. Baseline/Startup Profiles remain available from previous work. Android's official guidance recommends Baseline Profiles and benchmarking rather than assuming a speed multiplier.
