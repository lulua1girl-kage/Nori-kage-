#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
if [ -z "${ANDROID_HOME}" ] || [ ! -d "${ANDROID_HOME}" ]; then
  echo "Android SDK not found. Set ANDROID_HOME to your Android SDK." >&2
  exit 2
fi
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Node.js and npm are required." >&2
  exit 2
fi
npm install --no-audit --no-fund
if [ ! -d android ]; then npx cap add android; fi
npx cap sync android
# V36.5 BUILD SAFETY:
# Do not copy files from native-voice/ into the Android source tree.
# The Android source tree contains the authoritative implementation; copying
# legacy files here would overwrite newer voice logic during every build.
echo "[NORI V36.5] Preserving the existing Android voice implementation."
if [ -f android/gradlew ]; then
  chmod +x android/gradlew
  cd android
  ./gradlew assembleDebug
else
  echo "Capacitor Android project was not generated." >&2
  exit 3
fi
