#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
command -v javac >/dev/null 2>&1 || { echo "ERROR: javac is required" >&2; exit 1; }
./verify-stage22.sh
rm -rf build_stage23
mkdir -p build_stage23
mapfile -t SOURCES < <(grep -L '^import android\.' $(find android/app/src/main/java/com/nori/jarvis/nori -name '*.java' -print) | grep -v '/V32MigrationValidator.java$' | grep -v '/NoriNativeCore.java$')
javac -encoding UTF-8 -d build_stage23 "${SOURCES[@]}" tests/native/Stage23FutureEvolution.java tests/native/Post23Step1UnifiedState.java tests/native/Post23Step2Reasoning.java
java -cp build_stage23 Stage23FutureEvolution
java -cp build_stage23 Post23Step1UnifiedState
java -cp build_stage23 Post23Step2Reasoning

test -f release/FUTURE-EVOLUTION.md
test -f release/STAGE23-FINAL-STATUS.md
test -f release/NoriReleaseMetadata.java
test -f android/app/src/main/java/com/nori/jarvis/nori/future/FutureEvolutionPolicy.java
test -f android/app/src/main/java/com/nori/jarvis/nori/future/ExtensionRegistry.java
test -f www/brain-engine/brain.js
printf 'STAGE23_FINAL_ARCHITECTURE_PASS\n'
if [[ -x android/gradlew || -x android/gradlew.bat ]]; then
  printf 'STAGE23_ANDROID_BUILD_ENV=wrapper-present\n'
else
  printf 'STAGE23_ANDROID_BUILD_ENV=not-available-in-this-environment\n'
fi

# Post-Stage-23 Step 1: Unified State source checks
for f in \
  android/app/src/main/java/com/nori/jarvis/nori/state/NoriState.java \
  android/app/src/main/java/com/nori/jarvis/nori/state/NoriStateEngine.java \
  android/app/src/test/java/com/nori/jarvis/nori/state/NoriStateEngineTest.java \
  NORI-POST23-STEP1-UNIFIED-STATE.md; do
  test -f "$f"
done
printf 'POST23_STEP1_UNIFIED_STATE_SOURCE_PASS\n'
# Post-Stage-23 Step 2: Reasoning source checks
for f in \
  android/app/src/main/java/com/nori/jarvis/nori/reasoning/Evidence.java \
  android/app/src/main/java/com/nori/jarvis/nori/reasoning/Confidence.java \
  android/app/src/main/java/com/nori/jarvis/nori/reasoning/ReasoningResult.java \
  android/app/src/main/java/com/nori/jarvis/nori/reasoning/ReasoningEngine.java \
  tests/native/Post23Step2Reasoning.java \
  NORI-POST23-STEP2-REASONING.md; do
  test -f "$f"
done
printf 'POST23_STEP2_REASONING_SOURCE_PASS\n'

