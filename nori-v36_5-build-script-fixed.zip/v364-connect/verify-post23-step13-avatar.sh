#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
node --check "$ROOT/www/nori-avatar-v27.js"
grep -q 'nori-avatar-v27.css' "$ROOT/www/index.html"
grep -q 'nori-avatar-v27.js' "$ROOT/www/index.html"
grep -q 'CONNECTED TO NORI BRAIN' "$ROOT/www/nori-avatar-v27.js"
grep -q 'setSpeechLevel' "$ROOT/www/nori-avatar-v27.js"
grep -q 'prefers-reduced-motion' "$ROOT/www/nori-avatar-v27.css"
grep -q 'data-panel="study"' "$ROOT/www/nori-avatar-v27.js"
grep -q 'data-panel="exams"' "$ROOT/www/nori-avatar-v27.js"
grep -q 'data-panel="trend"' "$ROOT/www/nori-avatar-v27.js"
echo 'POST23_STEP13_AVATAR_EVOLUTION_SOURCE_PASS'
