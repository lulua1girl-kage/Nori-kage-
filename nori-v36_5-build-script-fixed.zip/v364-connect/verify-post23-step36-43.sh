#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/android/app/src/main/java"
OUT="$ROOT/.step36-43-classes"
rm -rf "$OUT"; mkdir -p "$OUT"
mapfile -t FILES < <(python3 - <<PY2
import os
root=r'''$SRC'''
for dp,_,fs in os.walk(root):
  for f in fs:
    if not f.endswith('.java'): continue
    p=os.path.join(dp,f); s=open(p,errors='ignore').read()
    if any(x in s for x in ['import android.','import androidx.','import com.getcapacitor.','android.']): continue
    if p.endswith(('NoriNativeCore.java','NoriWorldPlugin.java','NoriOperationsPlugin.java','MainActivity.java','V32MigrationValidator.java')): continue
    print(p)
PY2
)
javac -d "$OUT" "${FILES[@]}"
java -cp "$OUT" com.nori.jarvis.nori.benchmark.NoriStep36to43Smoke
grep -q 'NoriPersonalWorldModel' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'NoriCausalCounterfactualEngine' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'NoriAdvancedLearningEngine' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'NoriResearchBrain2' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'NoriHumanContext2' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'NoriFailureRecoveryEngine' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'NoriIntegrationBenchmark' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'integrationTrace' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/meta/NoriMetaBrainOrchestrator.java"
echo 'POST23_STEP36_43_SOURCE_PASS'
