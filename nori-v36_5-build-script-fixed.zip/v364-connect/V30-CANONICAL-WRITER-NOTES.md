# V30 — Canonical State Writer Boundary

## Purpose
V29 established server-authoritative canonical state and a durable audit table. V30 closes the most important remaining gap: a decision request must not be able to bypass the canonical mutation boundary or send client state back as writable authority.

## Changes
- Added `supabase/migrations/006_v30_canonical_writer.sql`.
- Added atomic `nori_apply_canonical_mutation(...)` RPC.
- The RPC locks the current state row, checks the expected state version + hash, writes the next state, and inserts the audit event in one transaction.
- Browser roles (`anon`, `authenticated`) cannot execute the RPC. Only `service_role` can.
- Added `www/api/stateWriter.js` as the application-level mutation contract.
- Decision actions are split into read-only and mutation actions.
- Unknown actions, oversized/deep payloads, prototype-pollution keys, and client-controlled user/account target keys are rejected.
- The authenticated user ID always comes from the verified bearer token.
- Removed the old non-atomic `upsertState`/generic audit write path from the canonical-state module.
- `api/decide.js` now uses compare-and-swap semantics and returns HTTP 409 on a concurrent state change instead of overwriting newer state.
- `nori-decide-engine.js` no longer sends `state` back to the server and no longer persists the decision state in localStorage. Its state is a volatile UI read model only.
- Read actions do not create mutation audit events.

## Authority rule
`client -> authenticated request -> action contract -> deterministic engine -> atomic canonical writer -> durable audit`

Client state is never a write authority.

## Verification
- V26 architecture smoke: PASS
- V27 mentor contract smoke: PASS
- V28 explainability/rule-review smoke: PASS
- V29 canonical-state smoke: PASS
- V30 writer-boundary smoke: PASS
- V32 integrity source guards: PASS
- Node syntax checks: PASS

## Explicit limitation
This release has source/smoke-test verification only. It does not claim a successful Android Gradle build, Supabase deployment, or physical-device test. The SQL migration must be applied to the target Supabase project before the atomic writer is available in production.
