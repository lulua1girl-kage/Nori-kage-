# Nori Post-Stage 23 Step 3 — Interactive Presence

## Purpose
Adds one shared interaction surface for Nori Voice Chat and Smart Alarm without replacing existing systems.

## UI
- Black Nori background.
- White core/circle.
- Teal `#306761` technical rings/accent.
- Orange accent for speech/alarm activity.
- JARVIS-inspired technical motion, kept within Nori's restrained visual language.
- Explicit states: IDLE, LISTENING, PROCESSING, THINKING, SPEAKING, ALARM, ERROR.
- Small bottom transcription box shows current recognized speech/reply without returning to the main chat.
- Optional in-overlay history shows recent turns from the same conversation store.

## Circle / Avatar
- User can switch between INTERACTIVE CIRCLE and AVATAR.
- Switch is available from the interactive surface and General Settings.
- Existing Nori avatar assets are reused; no destructive replacement of the existing avatar layer.

## Voice + Chat
- Interactive voice input routes through the existing Meet Nori send pipeline.
- Voice turns are marked `channel: voice` in Conversation V3; typed turns remain `channel: text`.
- Both therefore belong to the same conversation history.
- Existing Nori Brain endpoint remains the response pipeline for Meet Nori; this change does not introduce a second chat brain.
- No background recording is added. Listening starts only after explicit user action.

## Smart Alarm
- When an alarm session starts while the UI is available, the shared interactive presence opens in ALARM state.
- Existing alarm scheduling, notification, rescheduling, and override behavior remains unchanged.

## Scope boundary
This is a web/hybrid UI interaction layer. Native Android build/device verification is still required later. The visual state system does not itself guarantee continuous native speech recognition; it reflects the state of the existing speech bridge.
