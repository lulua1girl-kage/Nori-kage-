# NORI V34 — Decision + Planning Cooperation / System Organization

## Decision + Planning problems fixed

1. No dedicated decision layer between intent and V33 execution.
2. Planning used generic execution steps rather than goal/context-aware plans.
3. Natural-language goals were too dependent on direct command parsing.
4. No shared academic priority calculation for planning choices.
5. Weak context inspection before planning.
6. Complex requests could be treated as single actions.
7. Study-session moves did not reliably inspect the existing session first.
8. Time phrases such as “to 8 PM” were not normalized by the planning layer.
9. Multi-action planning needed a clear handoff to V33 workflows.
10. Navigation goals needed to enter the same decision layer rather than remain a separate matcher.
11. Conflicts needed to block or surface before execution.
12. Decision/planning needed explicit trace events.

## V34 implementation

- Added `www/nori-decision-planner-v34.js`.
- Reads authoritative canonical state before planning.
- Produces a structured decision object with goal, kind, complexity, plan and context version.
- Supports goal classes for assignments, study, study-session updates, alarms, focus, results, navigation and multi-step planning.
- Adds an academic priority calculation using urgency, importance, consequence and feasibility.
- Detects schedule conflicts before execution.
- Normalizes common natural-language time expressions including “at”, “by”, “around” and “to”.
- Hands single actions to V33 and multi-action plans to the V33 workflow executor.
- Navigation goals use the existing navigation brain only as the route executor after V34 understands the goal.
- Complex operations remain confirmation-gated by V33.
- Emits `decision.created` into the V32 protocol event stream.

## UI / information architecture problems fixed

The build already contained many coded subsystems that were difficult to discover from the visible UI. V34 adds an additive system directory and organized Settings page without replacing the existing visual system.

New categories:

- Core Command
- Academic
- Planning & Execution
- Intelligence & Knowledge
- Personal / System
- Administrator Section (approved administrators only)

The existing navigation drawer remains the primary sidebar/menu. V34 does not add a competing drawer.

## Newly surfaced coded systems

Cards now expose or categorize existing subsystems including:

- Decision & Planning
- App Understanding
- Knowledge Hub
- Research Mode
- Workflow Planner
- Learning System
- Memory Governance
- Self-Improvement Lab
- Visual Understanding
- Language Specialist
- SAT Intelligence
- Interactive Presence
- System Integrity
- Integration Audit
- System Timeline
- Privacy / Permissions
- Data / Backup
- Focus
- Voice Alarms
- Verification
- Adaptive Command
- Recovery
- Awards / Merit

These cards are an information-architecture layer; they do not falsely claim that every specialist subsystem has a complete dedicated screen.

## Administrator access

Server-side administrator allowlisting already existed in the build and contains the requested default administrator emails in migration `002_nori_production_foundation.sql`.

V34 adds:

- Administrator-only Settings section.
- Administrator-only App Review card.
- Administrator-only Admin Accounts / Allowlist card.
- Server-backed add/accept-admin-email control through `admin-manage`.
- Existing server-side role checks remain authoritative.
- Allowlisted administrator sign-in can start the existing PIN + identity-email administrator verification flow.
- Approved administrators can enter without the student backup-email requirement after administrator identity verification.
- Ordinary student accounts do not receive the administrator Settings section.

## Visual policy

V34 is additive. It keeps the existing black/white/gray dossier style, borders, typography and red accent. It does not replace the existing home/recovery visual system.

## Validation

Passed:
- V26 brain architecture smoke
- V27 mentor contract smoke
- V28 explainability/rule review smoke
- V29 canonical state smoke
- V30 state writer smoke
- V31 integration core smoke
- V32 integrity smoke
- V32 operating protocol smoke
- V33 operative smoke
- V34 decision/planning smoke
- Syntax checks for all touched JavaScript files

Android/device runtime testing was not claimed.
