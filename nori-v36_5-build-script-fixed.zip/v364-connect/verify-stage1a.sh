#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
fail(){ echo "[NORI V32] ERROR: $1" >&2; exit 1; }
PLUGIN="$ROOT/android/app/src/main/java/com/nori/jarvis/voice/NoriVoicePlugin.java"
SERVICE="$ROOT/android/app/src/main/java/com/nori/jarvis/voice/NoriVoiceService.java"
[ -f "$PLUGIN" ] || fail "NoriVoicePlugin.java is not in its declared package path."
[ -f "$SERVICE" ] || fail "NoriVoiceService.java is not in its declared package path."
grep -q '^package com\.nori\.jarvis\.voice;' "$PLUGIN" || fail "Voice plugin package declaration mismatch."
grep -q '^package com\.nori\.jarvis\.voice;' "$SERVICE" || fail "Voice service package declaration mismatch."
[ ! -f "$ROOT/android/app/src/main/java/com/nori/jarvis/NoriVoicePlugin.java" ] || fail "Duplicate misplaced voice plugin remains."
[ ! -f "$ROOT/android/app/src/main/java/com/nori/jarvis/NoriVoiceService.java" ] || fail "Duplicate misplaced voice service remains."
grep -q 'com\.nori\.jarvis\.voice\.NoriVoicePlugin' "$ROOT/android/app/src/main/java/com/nori/jarvis/MainActivity.java" || fail "MainActivity import changed unexpectedly."
grep -q 'native-voice/NoriVoicePlugin.java' "$ROOT/build-v32.sh" || fail "build-v32.sh does not package native voice sources."
echo "[NORI V32] Stage 1A voice packaging validation PASSED"
