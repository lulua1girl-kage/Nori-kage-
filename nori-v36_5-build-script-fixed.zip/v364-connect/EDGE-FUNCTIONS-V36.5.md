# Nori V36.5 Edge Functions

The hosted Supabase project contains the `admin-verify` Edge Function.

- JWT verification is enabled.
- The function uses the caller's Authorization header to establish Supabase Auth context.
- It reads only the caller's `profiles` row through RLS.
- It returns admin status only when the profile role is `ADMIN` or `OWNER` and admission status is `APPROVED`.
- It does not contain a service-role key or privileged secret.

The browser client may call `/functions/v1/admin-verify` with the signed-in user's access token.
