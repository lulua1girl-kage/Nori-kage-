#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/android/app/src/main/java/com/nori/jarvis/nori/edgeai"
OUT="$ROOT/.step33-classes"
rm -rf "$OUT"; mkdir -p "$OUT"
javac -d "$OUT" "$SRC"/*.java
for f in NoriOnDeviceBackend.java NoriOnDeviceTask.java NoriEdgeModel.java NoriEdgeAiRegistry.java NoriEdgeAiPolicy.java NoriEdgeAiEngine.java NoriEdgeAiReflection.java; do test -f "$SRC/$f"; done
grep -q "NoriEdgeAiEngine" "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q "edgeAiEngine=new NoriEdgeAiEngine" "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q "noriEdgeAi" "$ROOT/android/app/build.gradle"
grep -q "genai-prompt:1.0.0-beta4" "$ROOT/android/app/build.gradle"
grep -q "tasks-genai:0.10.24" "$ROOT/android/app/build.gradle"
grep -q "onnxruntime-android:1.24.3" "$ROOT/android/app/build.gradle"
echo "POST23_STEP33_EDGE_AI_PASS"
