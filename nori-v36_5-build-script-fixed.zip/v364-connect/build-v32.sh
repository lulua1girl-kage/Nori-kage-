#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
fail(){ echo "[NORI V32] ERROR: $1" >&2; exit 1; }
command -v node >/dev/null 2>&1 || fail "Node.js is required."
command -v npm >/dev/null 2>&1 || fail "npm is required."
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
[ -n "$SDK" ] && [ -d "$SDK" ] || fail "Android SDK not found. Set ANDROID_HOME or ANDROID_SDK_ROOT."
[ -d "$SDK/platforms/android-36" ] || fail "Android API 36 platform is missing. Install Android SDK Platform 36."
if [ -x "$SDK/build-tools/35.0.0/aapt2" ]; then :; elif [ -x "$SDK/build-tools/36.0.0/aapt2" ]; then :; else fail "Android Build Tools with aapt2 are missing. Install Build Tools 35.0.0 or newer compatible with AGP 8.13.0."; fi
if [ ! -d node_modules ]; then npm install --no-audit --no-fund; fi
npx cap sync android
# V36.5 BUILD SAFETY:
# Do not copy files from native-voice/ into the Android source tree.
# The Android source tree contains the authoritative implementation; copying
# legacy files here would overwrite newer voice logic during every build.
echo "[NORI V36.5] Preserving the existing Android voice implementation."
if command -v gradle >/dev/null 2>&1; then GRADLE_CMD=(gradle); elif [ -x android/gradlew ]; then GRADLE_CMD=(android/gradlew); else fail "Gradle is unavailable."; fi
cd android
"${GRADLE_CMD[@]}" :app:assembleDebug --stacktrace
cd ..
APK="android/app/build/outputs/apk/debug/app-debug.apk"
[ -f "$APK" ] || fail "Build completed but APK was not found at $APK"
SIZE=$(wc -c < "$APK" | tr -d ' ')
[ "$SIZE" -gt 100000 ] || fail "APK exists but is suspiciously small ($SIZE bytes)."
echo "[NORI V32] INSTALLABLE DEBUG APK CREATED"
echo "$ROOT/$APK"
