# Nori release build keeps minification disabled by default.
# Keep this file ready for future verified R8 rules.
