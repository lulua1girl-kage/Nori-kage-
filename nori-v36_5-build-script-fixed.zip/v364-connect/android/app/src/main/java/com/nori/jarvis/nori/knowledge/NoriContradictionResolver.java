package com.nori.jarvis.nori.knowledge;

import java.util.*;

/** Contradiction protocol: expose the conflict and ask which source hierarchy the student wants. */
public final class NoriContradictionResolver {
    public static final class Claim { public final String id,text,source,date; public final int evidence; public Claim(String i,String t,String s,String d,int e){id=i;text=t;source=s;date=d;evidence=e;} }
    public static final class Result {
        public final boolean conflict,needsUserPriority; public final List<Claim> claims; public final String question;
        public Result(boolean c,boolean n,List<Claim> x,String q){conflict=c;needsUserPriority=n;claims=Collections.unmodifiableList(new ArrayList<>(x));question=q;}
    }
    public Result compare(List<Claim> claims){
        if(claims==null||claims.size()<2)return new Result(false,false,Collections.emptyList(),"");
        Set<String> normalized=new HashSet<>(); for(Claim c:claims) normalized.add(normalize(c.text));
        boolean conflict=normalized.size()>1;
        if(!conflict)return new Result(false,false,claims,"");
        return new Result(true,true,claims,"These sources disagree. Which should Nori prioritize for this task: your teacher/course material, your uploaded library, a primary/official source, or a newer research source?");
    }
    private String normalize(String s){return (s==null?"":s.toLowerCase(Locale.ROOT)).replaceAll("[^a-z0-9 ]"," ").replaceAll("\\s+"," ").trim();}
}
