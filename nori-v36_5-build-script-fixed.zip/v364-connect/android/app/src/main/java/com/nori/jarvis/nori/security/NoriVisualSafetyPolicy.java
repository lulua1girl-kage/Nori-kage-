package com.nori.jarvis.nori.security;

/** Context-sensitive visual policy: educational anatomy is not treated as unsafe merely because it depicts a body. */
public final class NoriVisualSafetyPolicy {
    public enum Context { EDUCATIONAL_ANATOMY, BIOLOGY, MEDICAL_EDUCATION, ABUSE_DISCUSSION, NORMAL, GRAPHIC_HARM, SEXUALIZED, UNKNOWN }
    public enum Decision { ALLOW_EDUCATIONAL, ALLOW_SUPPORTIVE, REVIEW, BLOCK }
    public Decision decide(Context c){switch(c){case EDUCATIONAL_ANATOMY:case BIOLOGY:case MEDICAL_EDUCATION:return Decision.ALLOW_EDUCATIONAL;case ABUSE_DISCUSSION:return Decision.ALLOW_SUPPORTIVE;case GRAPHIC_HARM:case SEXUALIZED:return Decision.BLOCK;case UNKNOWN:return Decision.REVIEW;default:return Decision.ALLOW_EDUCATIONAL;}}
    public String rule(){return "Topic sensitivity alone is not enough to block an image. Nori considers purpose and context; legitimate anatomy/biology learning can remain available without sensational framing.";}
}
