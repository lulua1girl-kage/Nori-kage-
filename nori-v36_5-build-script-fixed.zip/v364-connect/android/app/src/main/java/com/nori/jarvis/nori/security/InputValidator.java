package com.nori.jarvis.nori.security;

import java.net.URI;
import java.util.Locale;
import java.util.regex.Pattern;

/** Rejects malformed/oversized values before they reach storage or tools. */
public final class InputValidator {
    private static final Pattern EMAIL = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");
    private InputValidator() {}

    public static boolean text(String value, int max) {
        return value != null && !value.trim().isEmpty() && value.length() <= max;
    }
    public static boolean key(String value) { return text(value, SecurityPolicy.MAX_KEY_LENGTH); }
    public static boolean storedValue(String value) { return value != null && value.length() <= SecurityPolicy.MAX_VALUE_LENGTH; }
    public static boolean email(String value) { return text(value, 320) && EMAIL.matcher(value.trim()).matches(); }

    public static boolean httpsUrl(String value) {
        if (!text(value, 4096)) return false;
        try {
            URI uri = URI.create(value.trim());
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null
                    && (uri.getUserInfo() == null || !uri.getUserInfo().contains("@"));
        } catch (RuntimeException e) { return false; }
    }

    public static String normalizeEmail(String value) { return value == null ? "" : value.trim().toLowerCase(Locale.ROOT); }
}
