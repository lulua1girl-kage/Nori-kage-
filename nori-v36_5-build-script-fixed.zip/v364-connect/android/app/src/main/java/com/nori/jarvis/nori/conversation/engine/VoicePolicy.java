package com.nori.jarvis.nori.conversation.engine;

import com.nori.jarvis.nori.conversation.model.VoiceMode;
import java.util.*;

/** Maps conversation modes to presentation behavior; core safety/authorization remains unchanged. */
public final class VoicePolicy {
    public static final class Policy {
        public final int maxResponseSentences;
        public final boolean allowOpenEndedChat;
        public final boolean preferConciseCommands;
        public final boolean emphasizeVerification;
        public final boolean allowActionProposal;
        Policy(int maxResponseSentences, boolean allowOpenEndedChat, boolean preferConciseCommands,
               boolean emphasizeVerification, boolean allowActionProposal) {
            this.maxResponseSentences=maxResponseSentences; this.allowOpenEndedChat=allowOpenEndedChat;
            this.preferConciseCommands=preferConciseCommands; this.emphasizeVerification=emphasizeVerification;
            this.allowActionProposal=allowActionProposal;
        }
    }
    public static Policy forMode(VoiceMode mode) {
        switch(mode) {
            case COMMAND: return new Policy(3,false,true,true,true);
            case EXAM: return new Policy(4,false,true,true,false);
            case PLANNING: return new Policy(6,false,false,true,true);
            case CASUAL: return new Policy(6,true,false,false,false);
            case TUTOR:
            default: return new Policy(8,false,false,true,false);
        }
    }
    private VoicePolicy() {}
}
