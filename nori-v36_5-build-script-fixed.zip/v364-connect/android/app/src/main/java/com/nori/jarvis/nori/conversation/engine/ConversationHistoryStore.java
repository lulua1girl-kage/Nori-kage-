package com.nori.jarvis.nori.conversation.engine;

import com.nori.jarvis.nori.data.DataRepository;
import java.time.Instant;
import java.util.*;

/** Small persistent conversation history. Sensitive/private content must be filtered before append. */
public final class ConversationHistoryStore {
    public static final class Entry { public final String userId,speaker,text,at; public Entry(String u,String s,String t,String a){userId=u;speaker=s;text=t;at=a;} }
    private final DataRepository repo; private static final String PREFIX="nori_chat_history_v1_";
    public ConversationHistoryStore(DataRepository r){repo=r;}
    public boolean append(String userId,String speaker,String text){
        if(repo==null||blank(userId)||blank(speaker)||blank(text)||text.length()>20000)return false;
        if(looksSensitive(text))return false;
        String id=PREFIX+UUID.randomUUID();
        String payload=clean(userId)+"|"+clean(speaker)+"|"+clean(text)+"|"+Instant.now();
        return repo.putJson(id,payload,"conversation",1);
    }
    /** Returns recent records when the repository implementation supports key enumeration. */
    public List<Entry> recent(String userId,int limit){
        if(repo==null)return Collections.emptyList(); List<Entry> out=new ArrayList<>();
        for(String k:repo.keys()){
            if(!k.startsWith(PREFIX))continue; String p=repo.getJson(k);if(p==null)continue;String[] f=p.split("\\|",4);if(f.length!=4||!f[0].equals(userId))continue;out.add(new Entry(f[0],f[1],f[2],f[3]));
        }
        out.sort(Comparator.comparing(e->e.at)); Collections.reverse(out); if(out.size()>Math.max(0,limit))return Collections.unmodifiableList(new ArrayList<>(out.subList(0,limit)));return Collections.unmodifiableList(out);
    }
    private static boolean blank(String x){return x==null||x.trim().isEmpty();}
    private static String clean(String x){return x.replaceAll("[\\r\\n|]"," ").trim();}
    private static boolean looksSensitive(String x){String s=x.toLowerCase(Locale.ROOT);return s.matches(".*\\b(password|api key|secret|token|credit card|pin)\\b.*");}
}
