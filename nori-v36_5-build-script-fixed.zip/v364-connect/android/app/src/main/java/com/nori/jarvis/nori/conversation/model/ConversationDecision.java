package com.nori.jarvis.nori.conversation.model;

import java.util.*;

public final class ConversationDecision {
    public final String normalizedText;
    public final VoiceMode mode;
    public final String intentHint;
    public final boolean requiresConfirmation;
    public final boolean requiresHumanInput;
    public final List<String> nextSteps;

    public ConversationDecision(String normalizedText, VoiceMode mode, String intentHint,
                                boolean requiresConfirmation, boolean requiresHumanInput, List<String> nextSteps) {
        this.normalizedText = normalizedText;
        this.mode = mode;
        this.intentHint = intentHint;
        this.requiresConfirmation = requiresConfirmation;
        this.requiresHumanInput = requiresHumanInput;
        this.nextSteps = Collections.unmodifiableList(new ArrayList<>(nextSteps == null ? Collections.emptyList() : nextSteps));
    }
}
