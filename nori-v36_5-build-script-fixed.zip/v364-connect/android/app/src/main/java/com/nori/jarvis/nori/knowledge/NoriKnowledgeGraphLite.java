package com.nori.jarvis.nori.knowledge;

import java.util.*;

/** Lightweight relationship index for subjects, documents, concepts and sources; avoids rescanning full files. */
public final class NoriKnowledgeGraphLite {
    public static final class Edge { public final String from,to,relation; public Edge(String f,String t,String r){from=f;to=t;relation=r;} }
    private final Map<String,Set<String>> topics=new HashMap<>();
    private final List<Edge> edges=new ArrayList<>();
    public synchronized void link(String document,String topic,String source){topics.computeIfAbsent(topic==null?"":topic.toLowerCase(Locale.ROOT),k->new LinkedHashSet<>()).add(document);edges.add(new Edge(document,topic,"covers"));if(source!=null&&!source.isEmpty())edges.add(new Edge(document,source,"from"));}
    public synchronized List<String> documentsFor(String topic,int limit){Set<String>s=topics.getOrDefault(topic==null?"":topic.toLowerCase(Locale.ROOT),Collections.emptySet());return new ArrayList<>(new ArrayList<>(s).subList(0,Math.min(Math.max(0,limit),s.size())));}
    public synchronized int edgeCount(){return edges.size();}
}
