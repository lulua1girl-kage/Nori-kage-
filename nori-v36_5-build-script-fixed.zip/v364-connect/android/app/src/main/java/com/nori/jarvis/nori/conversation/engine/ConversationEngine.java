package com.nori.jarvis.nori.conversation.engine;

import com.nori.jarvis.nori.conversation.model.*;
import java.util.*;

/**
 * Stage 17 conversation policy. It routes voice/text interaction without pretending
 * to understand more than the evidence supports. It never executes commands itself.
 */
public final class ConversationEngine {
    private final ConversationState state;

    public ConversationEngine() { state = new ConversationState(); }
    public ConversationState state() { return state; }

    public ConversationDecision acceptUserText(String text) {
        if (text == null || text.trim().isEmpty())
            throw new IllegalArgumentException("text required");
        String x = text.trim().replaceAll("\\s+", " ");
        state.add(new ConversationTurn(ConversationTurn.Speaker.USER, x, state.getMode()));
        String l = x.toLowerCase(Locale.ROOT);
        String intent = "unknown";
        boolean confirm = false;
        boolean human = false;
        List<String> next = new ArrayList<>();

        if (l.startsWith("explain ") || l.contains("teach me") || l.contains("how do i understand")) {
            intent = "explain"; next.add("answer_with_tutor_policy");
        } else if (l.startsWith("plan ") || l.contains("make a study plan") || l.contains("schedule my study")) {
            intent = "plan"; next.add("inspect_academic_context"); next.add("build_bounded_plan");
        } else if (l.startsWith("record ") || l.startsWith("create ") || l.startsWith("complete ")) {
            intent = "action_request"; confirm = true; next.add("create_action_proposal"); next.add("show_preview_before_execution");
        } else if (l.contains("delete") || l.contains("change rule") || l.contains("change the rules")) {
            intent = "protected_change_request"; human = true; next.add("require_explicit_human_override");
        } else if (l.contains("exam") || l.contains("test")) {
            intent = "assessment_support"; next.add("inspect_exam_context");
        } else if (l.startsWith("stop") || l.startsWith("cancel")) {
            intent = "cancel"; next.add("cancel_pending_conversation_action");
        } else {
            intent = "conversation"; next.add("use_current_mode_policy");
        }
        return new ConversationDecision(x, state.getMode(), intent, confirm, human, next);
    }

    public void addNoriResponse(String text) {
        if (text == null || text.trim().isEmpty()) return;
        state.add(new ConversationTurn(ConversationTurn.Speaker.NORI, text, state.getMode()));
    }
}
