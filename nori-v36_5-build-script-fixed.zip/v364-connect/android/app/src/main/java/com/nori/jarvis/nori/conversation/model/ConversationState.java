package com.nori.jarvis.nori.conversation.model;

import java.util.*;

/** Bounded in-memory session. No recording or automatic long-term memory. */
public final class ConversationState {
    private final Deque<ConversationTurn> turns = new ArrayDeque<>();
    private final int maxTurns;
    private VoiceMode mode;
    private boolean active;

    public ConversationState() { this(40, VoiceMode.TUTOR); }
    public ConversationState(int maxTurns, VoiceMode initialMode) {
        this.maxTurns = Math.max(4, Math.min(maxTurns, 200));
        this.mode = initialMode == null ? VoiceMode.TUTOR : initialMode;
    }
    public synchronized void setMode(VoiceMode mode) { this.mode = mode == null ? this.mode : mode; }
    public synchronized VoiceMode getMode() { return mode; }
    public synchronized void setActive(boolean active) { this.active = active; }
    public synchronized boolean isActive() { return active; }
    public synchronized void add(ConversationTurn turn) { turns.addLast(turn); while (turns.size() > maxTurns) turns.removeFirst(); }
    public synchronized List<ConversationTurn> recent(int limit) {
        int n = Math.max(0, Math.min(limit, turns.size()));
        List<ConversationTurn> out = new ArrayList<>(turns);
        return Collections.unmodifiableList(out.subList(out.size() - n, out.size()));
    }
    public synchronized void clear() { turns.clear(); }
}
