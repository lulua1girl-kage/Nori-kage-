package com.nori.jarvis.nori.knowledge;

import java.util.*;

/** Curated learning-source registry. Source trust is metadata, not proof of correctness. */
public final class NoriKnowledgeSourceRegistry {
    public static final class Source {
        public final String id,name,url,coverage,access;
        public final int trustWeight;
        public Source(String id,String name,String url,String coverage,String access,int trustWeight){this.id=id;this.name=name;this.url=url;this.coverage=coverage;this.access=access;this.trustWeight=trustWeight;}
    }
    private final LinkedHashMap<String,Source> sources=new LinkedHashMap<>();
    public NoriKnowledgeSourceRegistry(){
        add("khan","Khan Academy","https://www.khanacademy.org/","math,science,economics,computing","public",90);
        add("mit-ocw","MIT OpenCourseWare","https://ocw.mit.edu/","engineering,physics,math,computer science,business","public",96);
        add("openstax","OpenStax","https://openstax.org/","biology,chemistry,physics,math,economics,business","public",96);
        add("mdn","MDN Web Docs","https://developer.mozilla.org/","web development,javascript,css,html","public",98);
        add("android","Android Developers","https://developer.android.com/","android,software engineering","public",99);
        add("python","Python Documentation","https://docs.python.org/3/","python,programming","public",99);
        add("arxiv","arXiv","https://arxiv.org/","research,computer science,physics,math","public",84);
        add("pubmed","PubMed","https://pubmed.ncbi.nlm.nih.gov/","biomedical research,biology","public",95);
        add("nasa","NASA","https://www.nasa.gov/","space,earth science,physics","public",97);
        add("nptel","NPTEL","https://nptel.ac.in/","engineering,science,management","public",92);
        add("stanford","Stanford Online","https://online.stanford.edu/","computer science,engineering,business,ai","public",95);
        add("cmu","Carnegie Mellon Open Learning Initiative","https://oli.cmu.edu/","computer science,math,statistics","public",94);
        add("harvard","Harvard Online","https://pll.harvard.edu/","science,computer science,business,history","public",93);
        add("ocw-umich","University of Michigan Open","https://open.umich.edu/","engineering,science,medicine,business","public",92);
        add("usgs","USGS","https://www.usgs.gov/","earth science,geography,mining","public",98);
        add("noaa","NOAA","https://www.noaa.gov/","earth science,climate,geography","public",98);
        add("worldbank","World Bank","https://www.worldbank.org/","economics,development,business","public",96);
        add("imf","IMF","https://www.imf.org/","economics,finance,macroeconomics","public",96);
        add("oecd","OECD","https://www.oecd.org/","economics,education,business,policy","public",95);
        add("who","WHO","https://www.who.int/","health,biology,public health","public",97);
        add("un","United Nations","https://www.un.org/","history,geography,economics,development","public",94);
        add("wikipedia","Wikipedia","https://www.wikipedia.org/","general knowledge,history,geography,science","public",70);
    }
    private void add(String id,String name,String url,String coverage,String access,int weight){sources.put(id,new Source(id,name,url,coverage,access,weight));}
    public List<Source> all(){return Collections.unmodifiableList(new ArrayList<>(sources.values()));}
    public Source get(String id){return sources.get(id);}
    public List<Source> forTopic(String topic,int limit){
        String t=topic==null?"":topic.toLowerCase(Locale.ROOT); List<Source> x=new ArrayList<>(sources.values());
        x.sort((a,b)->Integer.compare(score(b,t),score(a,t)));
        return Collections.unmodifiableList(x.subList(0,Math.min(Math.max(1,limit),x.size())));
    }
    private int score(Source s,String t){int x=s.trustWeight; if(!t.isEmpty()&&s.coverage.toLowerCase(Locale.ROOT).contains(t))x+=30;return x;}
}
