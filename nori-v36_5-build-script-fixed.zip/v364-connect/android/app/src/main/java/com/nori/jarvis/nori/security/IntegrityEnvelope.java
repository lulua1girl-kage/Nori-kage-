package com.nori.jarvis.nori.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Base64;

/** Small tamper-evidence envelope for exported or journaled native state. */
public final class IntegrityEnvelope {
    public final int version;
    public final long createdAt;
    public final String payload;
    public final String sha256;

    private IntegrityEnvelope(int version, long createdAt, String payload, String sha256) {
        this.version = version; this.createdAt = createdAt; this.payload = payload; this.sha256 = sha256;
    }

    public static IntegrityEnvelope create(String payload) {
        if (!InputValidator.storedValue(payload)) throw new IllegalArgumentException("payload_invalid");
        long now = System.currentTimeMillis();
        return new IntegrityEnvelope(1, now, payload, hash(1, now, payload));
    }

    public boolean verify() { return sha256.equals(hash(version, createdAt, payload)); }

    public static String hash(int version, long createdAt, String payload) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] raw = digest.digest((version + "|" + createdAt + "|" + payload).getBytes(StandardCharsets.UTF_8));
            return Base64.getUrlEncoder().withoutPadding().encodeToString(raw);
        } catch (Exception e) { throw new IllegalStateException("sha256_unavailable", e); }
    }
}
