package com.nori.jarvis.nori.knowledge;

import java.util.*;

/** Internet/source selection: ranks evidence, not popularity. */
public final class NoriSourcePrioritizer {
    public enum Type { OFFICIAL, PRIMARY, TEXTBOOK, UNIVERSITY, PEER_REVIEWED, DOCUMENTATION, NEWS, EDUCATOR, COMMUNITY, VIDEO, SOCIAL, UNKNOWN }
    public static final class Candidate { public final String id,title,domain; public final Type type; public final boolean current,primary,transparent; public final int topicMatch,evidence,corroboration; public Candidate(String i,String t,String d,Type y,boolean c,boolean p,boolean tr,int tm,int e,int co){id=i;title=t;domain=d;type=y;current=c;primary=p;transparent=tr;topicMatch=tm;evidence=e;corroboration=co;} }
    public static final class Ranked { public final Candidate candidate; public final int score; public final List<String> reasons; Ranked(Candidate c,int s,List<String>r){candidate=c;score=s;reasons=Collections.unmodifiableList(r);} }
    public List<Ranked> rank(List<Candidate> input,String task){List<Ranked> out=new ArrayList<>();for(Candidate c:input){int s=c.topicMatch*4+c.evidence*3+c.corroboration*2+(c.primary?18:0)+(c.transparent?8:0)+(c.current?8:0)+typeWeight(c.type);List<String>r=new ArrayList<>();if(c.primary)r.add("primary source");if(c.current)r.add("current");if(c.topicMatch>7)r.add("strong topic match");if(c.corroboration>7)r.add("corroborated");if(c.type==Type.VIDEO||c.type==Type.SOCIAL)r.add("secondary media: verify before treating as fact");out.add(new Ranked(c,s,r));}out.sort((a,b)->Integer.compare(b.score,a.score));return Collections.unmodifiableList(out);}
    public String policy(){return "Prefer primary/official, authoritative and transparent evidence; then corroborated educational material; use videos/social/community content as leads unless independently supported. Re-check current claims and expose uncertainty.";}
    private int typeWeight(Type t){switch(t){case OFFICIAL:return 30;case PRIMARY:return 28;case PEER_REVIEWED:return 25;case UNIVERSITY:return 24;case DOCUMENTATION:return 23;case TEXTBOOK:return 22;case NEWS:return 14;case EDUCATOR:return 10;case VIDEO:return 6;case COMMUNITY:return 4;case SOCIAL:return 1;default:return 0;}}
}
