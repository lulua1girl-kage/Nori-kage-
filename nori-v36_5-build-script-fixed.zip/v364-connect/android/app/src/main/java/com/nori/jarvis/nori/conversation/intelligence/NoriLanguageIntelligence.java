package com.nori.jarvis.nori.conversation.intelligence;

import java.util.*;

/** Lightweight multilingual policy: detection, locale selection, and language continuity without a new voice stack. */
public final class NoriLanguageIntelligence {
    public static final class Profile {
        public final NoriConversationIntelligence.Language language; public final String locale; public final boolean supported;
        Profile(NoriConversationIntelligence.Language l,String loc,boolean s){language=l;locale=loc;supported=s;}
    }
    private NoriConversationIntelligence.Language last=NoriConversationIntelligence.Language.ENGLISH;
    public synchronized Profile resolve(String text){
        NoriConversationIntelligence.Language d=NoriConversationIntelligence.detectLanguage(text);
        if(d==NoriConversationIntelligence.Language.UNKNOWN)d=last; else last=d;
        switch(d){
            case AMHARIC:return new Profile(d,"am-ET",true);
            case OROMO:return new Profile(d,"om-ET",true);
            case ARABIC:return new Profile(d,"ar",true);
            case FRENCH:return new Profile(d,"fr",true);
            case SPANISH:return new Profile(d,"es",true);
            default:return new Profile(NoriConversationIntelligence.Language.ENGLISH,"en-US",true);
        }
    }
    public synchronized void setPreferred(NoriConversationIntelligence.Language language){if(language!=null)last=language;}
}
