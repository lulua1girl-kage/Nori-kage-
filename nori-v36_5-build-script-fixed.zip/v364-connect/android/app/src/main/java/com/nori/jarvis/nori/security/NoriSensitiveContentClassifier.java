package com.nori.jarvis.nori.security;

import java.util.Locale;

/** Fast conservative classifier. It stores no sensitive text and never sends it to a provider. */
public final class NoriSensitiveContentClassifier {
    public boolean isSensitive(String text, String intent) {
        String t=(text==null?"":text).toLowerCase(Locale.ROOT);
        String i=(intent==null?"":intent).toLowerCase(Locale.ROOT);
        if(i.contains("private")||i.contains("personal")||i.contains("psycholog")||i.contains("family")) return true;
        String[] markers={"private","personal","family","trauma","abuse","fear","unsafe","mental health","therapy","psychological","confidential","secret","password","medical","relationship"};
        for(String m:markers) if(t.contains(m)) return true;
        return false;
    }
}
