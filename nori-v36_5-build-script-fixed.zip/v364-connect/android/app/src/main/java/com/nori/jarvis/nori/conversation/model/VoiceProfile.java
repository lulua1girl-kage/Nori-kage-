package com.nori.jarvis.nori.conversation.model;

/** Presentation settings only. It does not contain credentials or audio recordings. */
public final class VoiceProfile {
    public final boolean enabled;
    public final boolean wakeWordEnabled;
    public final String wakeWord;
    public final float speechRate;
    public final float pitch;
    public final String locale;
    public final String preferredVoiceName;

    public VoiceProfile(boolean enabled, boolean wakeWordEnabled, String wakeWord,
                        float speechRate, float pitch, String locale, String preferredVoiceName) {
        this.enabled = enabled;
        this.wakeWordEnabled = wakeWordEnabled;
        this.wakeWord = normalize(wakeWord, "nori");
        this.speechRate = clamp(speechRate, 0.5f, 2.0f, 1.0f);
        this.pitch = clamp(pitch, 0.5f, 2.0f, 1.0f);
        this.locale = normalize(locale, "en-US");
        this.preferredVoiceName = preferredVoiceName == null ? "" : preferredVoiceName.trim();
    }
    public static VoiceProfile defaults() { return new VoiceProfile(false, false, "nori", 1f, 1f, "en-US", ""); }
    private static String normalize(String s, String fallback) { return s == null || s.trim().isEmpty() ? fallback : s.trim(); }
    private static float clamp(float x, float min, float max, float fallback) { return Float.isNaN(x) ? fallback : Math.max(min, Math.min(max, x)); }
}
