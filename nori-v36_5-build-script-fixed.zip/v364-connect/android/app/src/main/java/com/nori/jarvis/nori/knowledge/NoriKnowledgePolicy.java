package com.nori.jarvis.nori.knowledge;

/** Source-aware knowledge policy. It explicitly separates usefulness from truth. */
public final class NoriKnowledgePolicy {
    public enum Verdict { ACCEPT_AS_CONTEXT, USE_AS_LEAD, CORROBORATE, PREFER_PRIMARY, ASK_USER, BLOCK_SOURCE }
    public Verdict decide(NoriSourcePrioritizer.Type type, boolean conflict, boolean currentClaim, boolean primaryAvailable){
        if(conflict && primaryAvailable)return Verdict.PREFER_PRIMARY;
        if(type==NoriSourcePrioritizer.Type.SOCIAL)return Verdict.CORROBORATE;
        if(type==NoriSourcePrioritizer.Type.VIDEO||type==NoriSourcePrioritizer.Type.COMMUNITY)return Verdict.USE_AS_LEAD;
        if(currentClaim)return Verdict.CORROBORATE;
        return Verdict.ACCEPT_AS_CONTEXT;
    }
    public String rule(){return "No source becomes true merely by being popular, official-looking, uploaded, or repeated. Nori separates source authority, evidence quality, recency and corroboration.";}
}
