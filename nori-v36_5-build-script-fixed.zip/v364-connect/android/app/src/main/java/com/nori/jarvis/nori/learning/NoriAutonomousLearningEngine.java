package com.nori.jarvis.nori.learning;

import com.nori.jarvis.nori.knowledge.NoriKnowledgeSourceRegistry;
import java.util.*;

/** Governed continuous learning: can discover and refresh knowledge, but cannot silently rewrite Nori's core rules. */
public final class NoriAutonomousLearningEngine {
    public enum Mode { OFF, SUGGEST, USER_APPROVED, SCHEDULED }
    public static final class Plan { public final String topic; public final int sourceTarget; public final List<String> sourceIds; public final boolean verify; public Plan(String t,int n,List<String> s,boolean v){topic=t;sourceTarget=n;sourceIds=Collections.unmodifiableList(new ArrayList<>(s));verify=v;} }
    private Mode mode=Mode.SUGGEST;
    private final NoriKnowledgeSourceRegistry registry;
    public NoriAutonomousLearningEngine(NoriKnowledgeSourceRegistry r){registry=r;}
    public synchronized void setMode(Mode m){mode=m==null?Mode.SUGGEST:m;}
    public synchronized Mode mode(){return mode;}
    public Plan plan(String topic,int depth){int n=Math.min(25,Math.max(3,depth));List<String> ids=new ArrayList<>();for(NoriKnowledgeSourceRegistry.Source s:registry.forTopic(topic,Math.min(10,n)))ids.add(s.id);return new Plan(topic,n,ids,true);}
    public String rule(){return "Learn continuously from approved/public sources, preserve provenance, compare conflicting claims, and never silently self-modify constitutional rules or user data.";}
}
