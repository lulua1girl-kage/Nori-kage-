package com.nori.jarvis.nori.conversation.model;

import java.time.Instant;

public final class ConversationTurn {
    public enum Speaker { USER, NORI, SYSTEM }
    public final Speaker speaker;
    public final String text;
    public final Instant timestamp;
    public final VoiceMode mode;

    public ConversationTurn(Speaker speaker, String text, VoiceMode mode) {
        if (speaker == null) throw new IllegalArgumentException("speaker required");
        if (text == null || text.trim().isEmpty()) throw new IllegalArgumentException("text required");
        this.speaker = speaker;
        this.text = text.trim();
        this.timestamp = Instant.now();
        this.mode = mode == null ? VoiceMode.TUTOR : mode;
    }
}
