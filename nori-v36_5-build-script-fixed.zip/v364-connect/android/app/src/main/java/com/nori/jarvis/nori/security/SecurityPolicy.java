package com.nori.jarvis.nori.security;

/** Central, conservative limits for untrusted or persisted Nori data. */
public final class SecurityPolicy {
    public static final int MAX_KEY_LENGTH = 256;
    public static final int MAX_VALUE_LENGTH = 1_000_000;
    public static final int MAX_INPUT_LENGTH = 50_000;
    public static final int MAX_AUDIT_RECORDS = 500;
    public static final long MAX_CLOCK_SKEW_MS = 10 * 60 * 1000L;
    private SecurityPolicy() {}
}
