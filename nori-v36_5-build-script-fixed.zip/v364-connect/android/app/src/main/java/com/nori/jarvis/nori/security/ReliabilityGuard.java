package com.nori.jarvis.nori.security;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/** Runtime guard for fail-closed initialization and bounded repeated failures. */
public final class ReliabilityGuard {
    private final AtomicBoolean initialized = new AtomicBoolean(false);
    private final AtomicInteger failures = new AtomicInteger(0);
    private final int failureLimit;
    public ReliabilityGuard(){this(5);}
    public ReliabilityGuard(int failureLimit){if(failureLimit<1)throw new IllegalArgumentException("failure_limit");this.failureLimit=failureLimit;}
    public boolean initialize(boolean dependenciesValid){ if(!dependenciesValid)return false; return initialized.compareAndSet(false,true) || initialized.get(); }
    public boolean isInitialized(){return initialized.get();}
    public int recordFailure(){return failures.incrementAndGet();}
    public void clearFailures(){failures.set(0);}
    public boolean shouldFailClosed(){return failures.get()>=failureLimit;}
}
