package com.nori.jarvis.nori.security;

/** Process-scoped unlock. Closing the app process clears this automatically. */
public final class NoriSensitiveSession {
    private static volatile boolean unlocked=false;
    private NoriSensitiveSession(){}
    public static boolean isUnlocked(){return unlocked;}
    public static void unlock(){unlocked=true;}
    public static void lock(){unlocked=false;}
}
