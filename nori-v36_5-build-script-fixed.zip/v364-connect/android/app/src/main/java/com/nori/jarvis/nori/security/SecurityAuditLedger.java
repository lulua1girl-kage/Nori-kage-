package com.nori.jarvis.nori.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;

/** In-process tamper-evident audit chain. It is evidence, not a replacement for server logs. */
public final class SecurityAuditLedger {
    public static final class Entry {
        public final String id, event, detail, previousHash, hash;
        public final long timestamp;
        private Entry(String id, String event, String detail, String previousHash, String hash, long timestamp) {
            this.id=id; this.event=event; this.detail=detail; this.previousHash=previousHash; this.hash=hash; this.timestamp=timestamp;
        }
    }
    private final List<Entry> entries = new ArrayList<>();
    public synchronized Entry record(String event, String detail) {
        if (!InputValidator.text(event, 256) || detail == null || detail.length() > 4096) throw new IllegalArgumentException("audit_input_invalid");
        long now=System.currentTimeMillis(); String previous=entries.isEmpty()?"GENESIS":entries.get(entries.size()-1).hash;
        String id=SecureId.next("audit"); String hash=hash(id,event,detail,previous,now);
        Entry e=new Entry(id,event,detail,previous,hash,now); entries.add(e);
        while(entries.size()>SecurityPolicy.MAX_AUDIT_RECORDS) entries.remove(0);
        return e;
    }
    public synchronized boolean verify() {
        String previous=entries.isEmpty()?"GENESIS":entries.get(0).previousHash;
        for(Entry e:entries) {
            if(!Objects.equals(e.previousHash, previous) || !Objects.equals(e.hash,hash(e.id,e.event,e.detail,e.previousHash,e.timestamp))) return false;
            previous=e.hash;
        }
        return true;
    }
    public synchronized List<Entry> entries(){return Collections.unmodifiableList(new ArrayList<>(entries));}
    private static String hash(String id,String event,String detail,String previous,long at){
        try{MessageDigest d=MessageDigest.getInstance("SHA-256"); byte[] b=d.digest((id+"|"+event+"|"+detail+"|"+previous+"|"+at).getBytes(StandardCharsets.UTF_8)); return Base64.getUrlEncoder().withoutPadding().encodeToString(b);}
        catch(Exception e){throw new IllegalStateException(e);}
    }
}
