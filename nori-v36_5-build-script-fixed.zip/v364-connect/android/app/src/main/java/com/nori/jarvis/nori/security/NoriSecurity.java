package com.nori.jarvis.nori.security;

/** Stage 19 security/reliability coordinator. No security decision grants tool authority. */
public final class NoriSecurity {
    private final SecurityAuditLedger audit = new SecurityAuditLedger();
    private final ReliabilityGuard reliability = new ReliabilityGuard();
    public SecurityAuditLedger audit(){return audit;}
    public ReliabilityGuard reliability(){return reliability;}
    public boolean validateStoredRecord(String key,String value){return InputValidator.key(key)&&InputValidator.storedValue(value);}
    public void recordSecurityEvent(String event,String detail){audit.record(event,detail==null?"":detail);}
    public boolean integrityHealthy(){return audit.verify();}
}
