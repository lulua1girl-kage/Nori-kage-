package com.nori.jarvis.nori.conversation.model;

/** User-selectable conversation modes. Mode changes affect response policy, not core rules. */
public enum VoiceMode {
    TUTOR, COMMAND, CASUAL, EXAM, PLANNING
}
