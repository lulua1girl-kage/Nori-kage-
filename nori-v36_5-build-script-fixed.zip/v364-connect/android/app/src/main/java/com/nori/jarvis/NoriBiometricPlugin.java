package com.nori.jarvis;

import android.app.BiometricPrompt;
import android.content.Context;
import android.os.Build;
import android.os.CancellationSignal;
import androidx.annotation.RequiresApi;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.JSObject;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.nori.jarvis.nori.security.NoriSensitiveSession;
import java.util.concurrent.Executor;

@CapacitorPlugin(name="NoriBiometric")
public final class NoriBiometricPlugin extends Plugin {
    @PluginMethod public void status(PluginCall call){
        JSObject o=new JSObject(); o.put("available", Build.VERSION.SDK_INT>=28); o.put("unlocked",NoriSensitiveSession.isUnlocked());
        if(Build.VERSION.SDK_INT>=29){ android.hardware.biometrics.BiometricManager bm=(android.hardware.biometrics.BiometricManager)getContext().getSystemService(Context.BIOMETRIC_SERVICE); o.put("canAuthenticate",bm.canAuthenticate()); }
        call.resolve(o);
    }
    @PluginMethod public void lock(PluginCall call){NoriSensitiveSession.lock();call.resolve();}
    @PluginMethod public void authenticate(PluginCall call){
        if(Build.VERSION.SDK_INT<28){call.reject("Biometric authentication is unavailable on this Android version");return;}
        final Executor executor=getContext().getMainExecutor();
        BiometricPrompt prompt=new BiometricPrompt.Builder(getContext())
            .setTitle("Unlock private Nori chat")
            .setSubtitle("Use your enrolled fingerprint or device biometric")
            .setDescription("Private and psychologically important chat history stays locked until you verify.")
            .setNegativeButton("CANCEL",executor,(d,w)->call.reject("cancelled"))
            .build();
        prompt.authenticate(new CancellationSignal(),executor,new BiometricPrompt.AuthenticationCallback(){
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r){NoriSensitiveSession.unlock();call.resolve(new JSObject().put("verified",true));}
            @Override public void onAuthenticationFailed(){ /* OS may allow another attempt without leaving the chat */ }
            @Override public void onAuthenticationError(int code,CharSequence msg){call.reject("authentication_failed",String.valueOf(msg));}
        });
    }
}
