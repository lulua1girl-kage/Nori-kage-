package com.nori.jarvis.nori.conversation.intelligence;

import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.brain.cognition.NoriCognitiveEngine;
import com.nori.jarvis.nori.constitution.NoriConstitution;
import com.nori.jarvis.nori.memory.context.NoriMemoryContext;
import com.nori.jarvis.nori.state.NoriState;
import com.nori.jarvis.nori.conversation.model.ConversationDecision;
import com.nori.jarvis.nori.conversation.model.VoiceMode;
import java.util.*;

/** Step 24 conversation layer: connects conversation to State, Memory, Cognition and Constitution. */
public final class NoriConversationIntelligence {
    public enum Language { ENGLISH, AMHARIC, OROMO, ARABIC, FRENCH, SPANISH, UNKNOWN }
    public static final class Context {
        public final String text; public final VoiceMode mode; public final Language language;
        public final NoriCognitiveEngine.ThoughtState thought; public final NoriMemoryContext memory;
        public final NoriState state; public final NoriConstitution.Decision constitutional;
        public final boolean contextStitched;
        Context(String t, VoiceMode m, Language l, NoriCognitiveEngine.ThoughtState th, NoriMemoryContext mem,
                NoriState st, NoriConstitution.Decision c) { text=t; mode=m; language=l; thought=th; memory=mem; state=st; constitutional=c; contextStitched=true; }
    }
    private final NoriBrain brain;
    private final NoriReferenceResolver referenceResolver = new NoriReferenceResolver();
    public NoriConversationIntelligence(NoriBrain brain){this.brain=Objects.requireNonNull(brain);}

    public Context understand(String text, VoiceMode mode, boolean externalAvailable, boolean userInitiatedAction){
        String q=normalize(text); NoriState state=brain.getCurrentState(); NoriMemoryContext mem=brain.buildMemoryContext(q,6);
        NoriReferenceResolver.Resolution reference=referenceResolver.resolve(q, brain.getConversationEngine().state().recent(40), state);
        String stitched=buildContextSummary(state,mem,mode,reference);
        NoriCognitiveEngine.ThoughtState thought=brain.think(q,stitched,externalAvailable,userInitiatedAction);
        NoriConstitution.Decision c=brain.getConstitution().evaluate(thought.intent.name(),q,null,userInitiatedAction,false);
        return new Context(q,mode==null?VoiceMode.TUTOR:mode,detectLanguage(q),thought,mem,state,c);
    }
    public String buildContextSummary(NoriState s,NoriMemoryContext m,VoiceMode mode){ return buildContextSummary(s,m,mode,new NoriReferenceResolver.Resolution("","","none",1,false)); }
    public String buildContextSummary(NoriState s,NoriMemoryContext m,VoiceMode mode,NoriReferenceResolver.Resolution r){
        StringBuilder b=new StringBuilder("mode=").append(mode==null?"TUTOR":mode.name()).append("; availability=").append(s.situation.availability).append("; activity=").append(s.situation.activity)
          .append("; study=").append(s.study.status).append("; subject=").append(s.study.subject).append("; exam=").append(s.exam.status).append("; nearExam=").append(s.situation.nearExam)
          .append("; memory=").append(m.compactContext);
        if(!r.reference.isEmpty()) b.append("; reference=").append(r.reference).append("; resolved=").append(r.target).append("; resolutionConfidence=").append(r.confidence).append("; ambiguous=").append(r.ambiguous);
        if(!s.academic.mistakePatterns.isEmpty()) b.append("; mistakePatterns=").append(String.join(" || ",s.academic.mistakePatterns)).append("; interventions=").append(String.join(",",s.academic.recommendedInterventions));
        return b.toString();
    }
    public static Language detectLanguage(String x){
        if(x==null||x.isEmpty())return Language.UNKNOWN;
        if(x.matches(".*[\\u1200-\\u137F].*"))return Language.AMHARIC;
        if(x.matches(".*[\\u0600-\\u06FF].*"))return Language.ARABIC;
        String l=x.toLowerCase(Locale.ROOT);
        if(l.matches(".*\\b(ani|maal|akkam|baruu|galatoomi)\\b.*"))return Language.OROMO;
        if(l.matches(".*\\b(bonjour|merci|comment|pourquoi)\\b.*"))return Language.FRENCH;
        if(l.matches(".*\\b(hola|gracias|como|porque)\\b.*"))return Language.SPANISH;
        if(l.matches(".*[a-z].*"))return Language.ENGLISH;
        return Language.UNKNOWN;
    }
    private static String normalize(String s){return s==null?"":s.trim().replaceAll("\\s+"," ");}
}
