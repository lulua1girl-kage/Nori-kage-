package com.nori.jarvis.nori.conversation.intelligence;

import com.nori.jarvis.nori.conversation.model.ConversationTurn;
import com.nori.jarvis.nori.state.NoriState;
import java.util.*;

/** Resolves short references against recent conversation and active Nori state. It never mutates state. */
public final class NoriReferenceResolver {
    public static final class Resolution {
        public final String reference, target, source; public final double confidence; public final boolean ambiguous;
        Resolution(String r,String t,String s,double c,boolean a){reference=r;target=t;source=s;confidence=c;ambiguous=a;}
    }
    public Resolution resolve(String text,List<ConversationTurn> turns,NoriState state){
        String q=clean(text), l=q.toLowerCase(Locale.ROOT);
        String ref=referenceWord(l); if(ref.isEmpty()) return new Resolution("","","none",1,false);
        List<String> candidates=new ArrayList<>();
        if(state!=null){
            if(!state.study.subject.isEmpty()) candidates.add("study session: "+state.study.subject+" / "+state.study.activity);
            if(state.exam.subject!=null&&!state.exam.subject.isEmpty()) candidates.add("exam: "+state.exam.subject);
            if(state.academic.latestSubject!=null&&!state.academic.latestSubject.isEmpty()) candidates.add("latest assessment: "+state.academic.latestSubject);
        }
        if(turns!=null){
            for(int i=turns.size()-1;i>=0 && candidates.size()<6;i--){ConversationTurn t=turns.get(i); if(t.speaker==ConversationTurn.Speaker.USER||t.speaker==ConversationTurn.Speaker.NORI){
                String x=t.text; if(isConcreteCandidate(x)) candidates.add("conversation: "+x); }
            }
        }
        LinkedHashSet<String> uniq=new LinkedHashSet<>(candidates); candidates=new ArrayList<>(uniq);
        if(candidates.isEmpty()) return new Resolution(ref,"","no_candidate",0,false);
        if(candidates.size()==1) return new Resolution(ref,candidates.get(0),"context",0.82,false);
        String best=bestMatch(l,candidates); if(best!=null) return new Resolution(ref,best,"context_match",0.68,false);
        return new Resolution(ref,"","multiple_candidates",0.35,true);
    }
    private static String referenceWord(String l){
        if(l.matches(".*\\b(that|it|this|the session|the study session|the exam|the assignment)\\b.*")){
            if(l.contains("the session")||l.contains("the study session"))return "session";
            if(l.contains("the exam"))return "exam"; if(l.contains("the assignment"))return "assignment";
            return l.contains("that")?"that":l.contains("this")?"this":"it";
        } return "";
    }
    private static String bestMatch(String q,List<String> xs){
        String best=null; int score=0; for(String x:xs){int s=0;String z=x.toLowerCase(Locale.ROOT);for(String w:q.split("\\W+")){if(w.length()>2&&z.contains(w))s++;}if(s>score){score=s;best=x;}}
        return score>0?best:null;
    }
    private static boolean isConcreteCandidate(String x){String l=x.toLowerCase(Locale.ROOT);return l.contains("study")||l.contains("session")||l.contains("exam")||l.contains("assignment")||l.contains("schedule")||l.contains("plan")||l.contains("chemistry")||l.contains("biology")||l.contains("physics")||l.contains("math");}
    private static String clean(String x){return x==null?"":x.trim().replaceAll("\\s+"," ");}
}
