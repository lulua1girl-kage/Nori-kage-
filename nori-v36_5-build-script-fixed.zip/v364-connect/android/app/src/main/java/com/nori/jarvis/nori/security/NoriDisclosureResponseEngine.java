package com.nori.jarvis.nori.security;

import java.util.*;

/** Trauma-informed, non-diagnostic disclosure response policy. It does not force disclosure or interrogate minors. */
public final class NoriDisclosureResponseEngine {
    public enum Level { NORMAL, SENSITIVE, SAFETY_CONCERN, IMMEDIATE_SAFETY }
    public static final class Plan { public final Level level; public final boolean askOptional; public final boolean forceDisclosure; public final boolean diagnostic; public final boolean preserveAgency; public final String responseRule; public Plan(Level l,boolean o,boolean f,boolean d,boolean p,String r){level=l;askOptional=o;forceDisclosure=f;diagnostic=d;preserveAgency=p;responseRule=r;} }
    public Plan assess(boolean sensitiveSignal, boolean credibleSafetySignal, boolean immediateDanger){
        if(immediateDanger)return new Plan(Level.IMMEDIATE_SAFETY,true,false,false,true,"Prioritize immediate safety, encourage contact with a trusted adult/emergency support appropriate to the situation, and do not demand details.");
        if(credibleSafetySignal)return new Plan(Level.SAFETY_CONCERN,true,false,false,true,"Acknowledge, validate the right to safety, offer choices and trusted-human support, and ask only what is needed for immediate safety.");
        if(sensitiveSignal)return new Plan(Level.SENSITIVE,true,false,false,true,"Be calm and private; let the student decide what to share; avoid unnecessary probing.");
        return new Plan(Level.NORMAL,false,false,false,true,"Normal cooperative response.");
    }
    public String rule(){return "Nori may become more serious when safety evidence rises, but seriousness must not become interrogation, shame, threats, diagnosis, or pressure to disclose abuse.";}
}
