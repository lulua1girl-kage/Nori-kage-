package com.nori.jarvis.nori.security;

import java.security.SecureRandom;
import java.util.Base64;

/** Non-predictable identifiers for security/audit records. */
public final class SecureId {
    private static final SecureRandom RANDOM = new SecureRandom();
    private SecureId() {}
    public static String next(String prefix) {
        byte[] bytes = new byte[18];
        RANDOM.nextBytes(bytes);
        return (prefix == null ? "id" : prefix) + "_" + Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
    }
}
