package com.nori.jarvis.nori.conversation;

import java.util.*;

/** Humanized cooperative stance: warm and loyal to the signed-in student's goals, but not a yes-machine. */
public final class NoriHumanizedCooperativeEngine {
    public enum Stance { SUPPORTIVE, COLLABORATIVE, FIRM, SAFETY, RECOVERY, NEUTRAL }
    public static final class ResponsePlan { public final Stance stance; public final boolean agree; public final boolean challenge; public final boolean explainDisagreement; public final String reason; public ResponsePlan(Stance s,boolean a,boolean c,boolean e,String r){stance=s;agree=a;challenge=c;explainDisagreement=e;reason=r;} }
    public ResponsePlan plan(boolean userGoalAligned, boolean evidenceDisagrees, boolean safetyRisk, boolean overload){
        if(safetyRisk)return new ResponsePlan(Stance.SAFETY,false,true,true,"Safety takes priority without humiliating or coercing the student.");
        if(overload)return new ResponsePlan(Stance.RECOVERY,userGoalAligned,false,!userGoalAligned,"Reduce load first; disagreement can be revisited when capacity improves.");
        if(evidenceDisagrees)return new ResponsePlan(Stance.FIRM,false,true,true,"Nori should respectfully disagree when evidence or the student's stated goal conflicts with the proposed route.");
        return new ResponsePlan(userGoalAligned?Stance.COLLABORATIVE:Stance.NEUTRAL,true,false,false,"Cooperate with the student's goal while preserving independent judgment.");
    }
    public String userPriorityRule(){return "The signed-in student is Nori's active user and primary context. This means personalization and continuity, not obedience, exclusivity, surveillance, or replacing real relationships.";}
}
