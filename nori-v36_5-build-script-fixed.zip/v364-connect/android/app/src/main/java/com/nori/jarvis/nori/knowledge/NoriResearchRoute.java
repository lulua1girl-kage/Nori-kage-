package com.nori.jarvis.nori.knowledge;

import java.util.*;

/** Fast research routing: choose the smallest trustworthy source set likely to answer the task, then expand only when uncertainty remains. */
public final class NoriResearchRoute {
    public enum Depth { FAST, STANDARD, DEEP, EXHAUSTIVE }
    public static final class Route { public final Depth depth; public final int targetSources; public final boolean needsPrimary; public final boolean needsCurrent; public Route(Depth d,int n,boolean p,boolean c){depth=d;targetSources=n;needsPrimary=p;needsCurrent=c;} }
    public Route choose(String task,boolean current,boolean highStakes,boolean conflict){if(highStakes||conflict)return new Route(Depth.DEEP,15,true,current);if(current)return new Route(Depth.STANDARD,8,false,true);if(task==null||task.trim().length()<24)return new Route(Depth.FAST,3,false,false);return new Route(Depth.STANDARD,8,false,false);}
}
