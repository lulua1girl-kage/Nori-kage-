package com.nori.jarvis.nori.knowledge;

import java.util.*;

/** Broad lifelong-learning map. Domains are routing metadata; mastery is earned through evidence, not a label. */
public final class NoriSubjectMasteryRegistry {
    public static final class Domain { public final String id,name; public final List<String> topics; Domain(String i,String n,String...t){id=i;name=n;topics=Collections.unmodifiableList(Arrays.asList(t));} }
    private final List<Domain> domains=Arrays.asList(
        new Domain("math","Mathematics","algebra","geometry","calculus","statistics","linear algebra","discrete math"),
        new Domain("physics","Physics","mechanics","electricity","waves","thermodynamics","quantum","relativity"),
        new Domain("chemistry","Chemistry","organic","inorganic","physical chemistry","analytical","biochemistry"),
        new Domain("biology","Biology","cell biology","genetics","ecology","evolution","physiology","microbiology"),
        new Domain("languages","Languages","grammar","writing","translation","linguistics","conversation"),
        new Domain("geography","Geography","physical geography","human geography","GIS","cartography","climate"),
        new Domain("history","History","world history","regional history","historiography","primary sources"),
        new Domain("economics","Economics","microeconomics","macroeconomics","econometrics","development"),
        new Domain("business","Business Administration","strategy","operations","finance","accounting","entrepreneurship"),
        new Domain("marketing","Marketing","consumer behavior","branding","analytics","digital marketing"),
        new Domain("management","Management","leadership","organizations","project management","decision science"),
        new Domain("software","Software Engineering","architecture","testing","security","databases","distributed systems","devops"),
        new Domain("web","Web Development","html","css","javascript","accessibility","performance","web security"),
        new Domain("ai","AI Development","machine learning","deep learning","NLP","computer vision","agents","evaluation","MLOps"),
        new Domain("coding","Advanced Coding","algorithms","data structures","debugging","systems","performance","code review"),
        new Domain("mining","Mining Engineering","geology","mine planning","rock mechanics","ventilation","processing","safety"),
        new Domain("engineering","Engineering","materials","thermodynamics","control","signals","design"),
        new Domain("agriculture","Agriculture","soil","crops","livestock","agronomy","agricultural economics"),
        new Domain("research","Research Skills","literature review","methodology","statistics","citation","evidence evaluation")
    );
    public List<Domain> all(){return Collections.unmodifiableList(domains);}
    public Domain route(String text){String x=text==null?"":text.toLowerCase(Locale.ROOT);Domain best=null;int score=0;for(Domain d:domains){int s=0;for(String t:d.topics)if(x.contains(t))s+=2;if(x.contains(d.name.toLowerCase(Locale.ROOT)))s+=4;if(s>score){score=s;best=d;}}return best==null?domains.get(0):best;}
}
