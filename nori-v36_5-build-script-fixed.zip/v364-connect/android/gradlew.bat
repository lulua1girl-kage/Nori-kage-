@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle -p "%~dp0" %*
  exit /b %ERRORLEVEL%
)
echo [NORI V32] Gradle is not installed. Open the project in Android Studio or install Gradle 8.13.
exit /b 2
