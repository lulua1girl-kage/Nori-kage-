# V31 — Nori Integration Core

V31 is an integration release, not a new intelligence engine.

## Core protocol

Interface -> Intent -> Capability -> Policy/Permission -> Proposal/Confirmation ->
Execution -> Verification -> Event -> Context -> Response.

## Added

- `nori-integration-core-v31.js`
  - Nori Orchestrator
  - capability registry and health
  - unified intent normalization for text/voice/navigation
  - action lifecycle and correlation IDs
  - shared session context
  - permission broker
  - canonical-state snapshot reader
  - event bus
  - transitional adapters for V27 ActionCore
- AI action schema expanded from three action types to a controlled allowlist of
  app capabilities including alarms, assignments, study sessions, results,
  calendar, recovery and navigation.
- Meet Nori AI actions now enter the same integration lifecycle.
- Voice commands enter the same integration event/intent path.
- Operations bridge exposes the integration layer while retaining native
  adapters.
- Alarm emits integration events.
- V31 smoke test.

## Important boundary

Existing feature modules still contain legacy local adapters. V31 does NOT
pretend that all localStorage mutations have become server-authoritative.
The Integration Core makes ActionCore the common client execution adapter and
makes the canonical server state the read authority. Full server-side mutation
migration remains a separate hardening step.

## Safety

AI actions remain allowlisted, validated, and confirmation-gated except
navigation/read-only behavior. The model does not gain database, permission,
or arbitrary-code authority.

## Verification

Run:

`node www/tests/v31-integration-core-smoke.js`

This is a source/runtime smoke test only. It does not prove a Gradle Android
build, device test, or deployed Supabase migration.
