# Nori V48 — Unified Admin + Language + SAT + Communication

## Admin
One logical ADMIN identity may contain many verified sign-in emails. The canonical display name is stored once at the admin-group level and rendered for every linked account. Admins receive the same capabilities and normal Nori experience. Administration is quiet by default and is opened from Settings.

## Languages
English is the operating language. Arabic, Español and Japanese are first-class specialist languages for dictionary, translation, grammar, writing, reading, listening/speaking practice, register, vocabulary and contrastive teaching.

## SAT
The engine models the current digital SAT as Reading and Writing + Math, two modules per section, with multistage adaptive behavior. It tracks domains, skills, timing, error types, misconceptions and transfer. Official Bluebook and College Board question-bank content remains external/user-provided rather than copied into the app.

## Communication
Instagram and Telegram are supported as study-block communication intents. Nori asks whether the request is text/call/video when needed and asks what to say when the user did not specify content. `ignore` means ignore. No autonomous AI-like messages are sent. Nori drafts; the user remains the sender. Call/video actions are user-directed external handoffs rather than covert calling.
