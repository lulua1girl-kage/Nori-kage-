#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
node --check "$ROOT/www/nori-presence-evolution-v2.js"
node --check "$ROOT/www/nori-meet.js"
node --check "$ROOT/www/api/brain.js"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/visual/NoriVisualPlugin.java"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/visual/NoriCameraActivity.java"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/visual/NoriScreenCaptureService.java"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/voice/NoriVoiceService.java"
grep -q 'FOREGROUND_SERVICE_MEDIA_PROJECTION' "$ROOT/android/app/src/main/AndroidManifest.xml"
grep -q 'foregroundServiceType="mediaProjection"' "$ROOT/android/app/src/main/AndroidManifest.xml"
grep -q 'foregroundServiceType="microphone"' "$ROOT/android/app/src/main/AndroidManifest.xml"
grep -q 'NoriVisualPlugin.class' "$ROOT/android/app/src/main/java/com/nori/jarvis/MainActivity.java"
grep -q 'visualContext' "$ROOT/www/nori-meet.js"
grep -q 'captureScreen' "$ROOT/www/nori-presence-evolution-v2.js"
grep -q 'captureCamera' "$ROOT/www/nori-presence-evolution-v2.js"
grep -q 'backgroundOptIn' "$ROOT/android/app/src/main/java/com/nori/jarvis/voice/NoriVoicePlugin.java"
printf '%s\n' 'POST23_STEP6_NATIVE_VISUAL_BACKGROUND_VOICE_SOURCE_PASS'
