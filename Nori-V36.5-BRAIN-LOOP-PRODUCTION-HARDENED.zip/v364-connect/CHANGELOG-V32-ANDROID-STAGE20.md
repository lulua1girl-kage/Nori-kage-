# Nori V32 Android — Stage 20 Changelog

- Added repeatable native Java regression suite under `tests/native/Stage20Regression.java`.
- Added `verify-stage20.sh` for deterministic compilation and regression execution.
- Covered cross-stage academic, KAGE, integrity, memory, educational intelligence, advanced intelligence, action, conversation, AI, security, reliability, and Brain orchestration contracts.
- Added static architecture guards for cleartext HTTP policy, V32 brain preservation, and critical native Stage 16–19 components.
- No production Brain rules were removed or weakened.
- Android-dependent classes remain outside the local `javac` regression pass; full APK/device validation still requires Android SDK + Gradle environment.
