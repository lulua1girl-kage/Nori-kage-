# Post-23 Step 19 — Cognitive Core 10x

This step keeps Step 18 as the base and adds a higher-order cognitive layer.

## Design goal
Nori should feel like one coherent brain, not a feature directory. The cognitive layer therefore performs a compact preflight over:
- actual user goal
- ambiguity and missing context
- competing interpretations/hypotheses
- evidence and freshness requirements
- contradictions and assumptions
- tool/action need
- verification/postconditions
- Human Override
- answer shape and effort

It does not expose or store hidden chain-of-thought.

## New higher-order behaviors
40 registered behaviors cover goal reconstruction, constraint tracking, hypothesis competition, evidence thresholds, counterexample/contradiction checks, uncertainty calibration, causal-vs-correlational guard, temporal/dependency reasoning, tradeoffs, value of information, minimal sufficient reasoning, context/memory relevance, tool need, action risk, verification, repair, resumption, feedback learning, provider/resource adaptation, privacy and provenance.

## Speed
- 256-entry cognitive hot cache
- deterministic keying
- zero network/tool I/O in cognitive preflight
- MICRO path for simple requests
- adaptive effort tiers
- no unconditional parallel fan-out
- existing Step 17/18 caches and scheduler remain in place

The requested '5x/10x' speed is treated as an optimization target, not a measured claim. Android recommends Baseline Profiles and Macrobenchmark to measure real startup/runtime gains on physical devices.
