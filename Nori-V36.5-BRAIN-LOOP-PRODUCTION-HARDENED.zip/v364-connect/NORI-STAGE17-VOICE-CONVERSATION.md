# Nori Native Java Stage 17 — Voice & Conversation Polish

## Purpose
Add a bounded conversation layer around the existing opt-in Android voice service. The stage improves mode-aware interaction, session state, and command safety without turning voice into unrestricted device control.

## Added
- Voice modes: Tutor, Command, Casual, Exam, Planning.
- Bounded in-memory conversation state with a fixed turn limit.
- Conversation turn model with speaker, timestamp, and mode.
- Conversation decision routing for explanation, planning, assessment support, action proposals, cancellation, and protected-rule requests.
- Voice presentation profile with bounded speech rate/pitch and locale.
- Mode-specific response policy.
- Explicit confirmation flag for action requests.
- Explicit human-input requirement for protected rule changes.
- NoriBrain conversation-engine accessor.

## Privacy / safety boundaries
- No background recording is added.
- No automatic long-term memory from conversation turns.
- Existing opt-in microphone service is preserved.
- Voice mode changes do not bypass KAGE, Integrity, Action, Admin, or Human Override rules.
- Command requests produce proposals/confirmation paths rather than direct execution.
- Protected rule changes require explicit human input.
- Conversation history is bounded to the current in-memory session.

## Preserved
Stages 1–16 and all V32 JavaScript remain intact.
