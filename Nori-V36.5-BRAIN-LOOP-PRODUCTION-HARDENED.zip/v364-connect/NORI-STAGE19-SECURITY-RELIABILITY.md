# Nori Native Java Stage 19 — Security & Reliability

Stage 19 adds a centralized native security/reliability boundary without replacing V32 modules.

## Added
- `NoriSecurity`: security/reliability coordinator.
- `SecurityPolicy`: bounded input, storage, audit, and clock limits.
- `InputValidator`: bounded text/key/value/email/HTTPS URL validation.
- `SecureId`: `SecureRandom` identifiers for audit/security events.
- `IntegrityEnvelope`: SHA-256 tamper-evidence for bounded exported/journaled payloads.
- `SecurityAuditLedger`: bounded hash-chained audit evidence with verification.
- `ReliabilityGuard`: fail-closed initialization and bounded repeated-failure tracking.

## Persistence hardening
- Native SQLite schema version raised from 1 to 2 with an additive integrity metadata table.
- SQLite foreign-key enforcement and WAL enabled at configuration time.
- Native repository rejects oversized/invalid keys and stored values before database writes.
- Automatic Android backup is disabled so the native database is not silently copied by platform backup. Explicit user-controlled export remains the intended future backup path.

## Boundaries
- Stage 19 does not claim local APK security against a hostile person who fully controls/modifies the device or APK.
- Local audit hash chaining is tamper-evidence, not a trusted remote audit service.
- No credentials are added or persisted by this stage.
- No unrestricted device control is introduced.
- Existing V32 and earlier native stages remain intact.
