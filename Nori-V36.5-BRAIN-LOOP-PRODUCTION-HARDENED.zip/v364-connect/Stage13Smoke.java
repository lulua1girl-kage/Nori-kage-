import com.nori.jarvis.nori.integrity.*;
public class Stage13Smoke {
  public static void main(String[] args) {
    var safe=ConsequenceSafetyGuard.check("online_game_restriction","Game access restriction","temporary access friction","gaming",false);
    var unsafe=ConsequenceSafetyGuard.check("push_ups","Physical punishment","exercise consequence","gaming",false);
    if(!safe.allowed || unsafe.allowed) throw new AssertionError("safety gate");
    var e=new IntegrityEngine();
    if(e.classify(false,false,false,false,false,true,false,false,false,false).status!=IntegrityEngine.BreachStatus.NOT_BREACH) throw new AssertionError("fatigue");
    if(e.classify(true,false,false,false,false,false,false,false,false,false).status!=IntegrityEngine.BreachStatus.BREACH) throw new AssertionError("breach");
    if(e.checkProportionality(2,4,false,false).allowed) throw new AssertionError("proportionality");
    var o=e.evaluateOverride("exhaustion",8,4,7,8,8,8,0);
    if(o.level==HumanOverrideGuard.Level.MONITOR) throw new AssertionError("override");
    var r=new RecoveryIntegrity().evaluate(true,true,true,true);
    if(r.status!=RecoveryIntegrity.Status.VERIFIED) throw new AssertionError("recovery");
    System.out.println("STAGE13_SMOKE_PASS");
  }
}
