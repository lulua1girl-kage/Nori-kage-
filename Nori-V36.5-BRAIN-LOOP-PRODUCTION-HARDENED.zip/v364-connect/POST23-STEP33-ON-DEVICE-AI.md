# Post-23 Step 33 — On-device AI Runtime Evolution

Nori now has an on-device AI abstraction layer built on the Step 32 baseline.

## Runtime families

1. ML Kit GenAI Prompt API / Gemini Nano — preferred high-level on-device generative path when the device supports Android AICore.
2. MediaPipe GenAI LLM — compatible on-device LLM path for supported hardware/model packages.
3. LiteRT — native model inference path for custom TFLite/LiteRT models and hardware delegates.
4. ONNX Runtime Mobile — path for ONNX models exported from other training stacks.
5. llama.cpp — GGUF/open-weight local model path, requiring an Android NDK/native integration.
6. MLC-LLM — alternative compiled local LLM path for supported model/device combinations.
7. Built-in deterministic Nori — always available fallback.

The architecture does NOT bundle model weights. Model files can be large, device-specific, and should be installed intentionally.

## Routing

Nori Brain remains the authority. The edge layer only supplies optional local intelligence:

User → Nori Brain → Constitution → Edge-AI policy → selected local runtime → result → verification → response/action

A local model can never bypass ActionEngine, UserControl, privacy gates, or Human Override.

## Model selection

NoriEdgeAiEngine considers:
- task type
- multimodal requirement
- installed runtime
- model size
- context limit
- device/runtime availability
- configured inference budget
- privacy preference

It does not silently download a model. `allowModelDownload=false` is the safe default.

## ML Kit / Gemini Nano

The optional Gradle profile uses ML Kit Prompt API beta4. The API supports on-device text and multimodal generation, model availability checks, streaming, and model preference selection. The device must support Android AICore. Nori should prefer stable model configuration for normal operation and use preview only when explicitly enabled for development.

## MediaPipe

The optional profile includes `tasks-genai:0.10.24`. MediaPipe LLM inference is treated as a backend, not as Nori's identity.

## LiteRT

TensorFlow Lite has evolved under the LiteRT name. Nori keeps a dedicated backend slot for LiteRT so custom `.tflite` models can be added without changing the Brain contract. Hardware delegates/NPU support remain device-dependent.

## ONNX Runtime Mobile

ONNX Runtime Mobile is available as an optional backend for `.onnx`/ORT-format models. The app must only load models that match the declared task and device resource policy.

## llama.cpp / MLC-LLM

These require native model runtimes and model files. Nori's registry accepts them as backend families but does not fake support by shipping a placeholder implementation. A real native module can be plugged in later.

## Performance policy

- tiny/simple tasks → deterministic Nori or small local model
- rewriting/summarization/classification → ML Kit/MediaPipe when available
- multimodal local tasks → compatible GenAI/MediaPipe/llama multimodal backend
- large reasoning → local model only when device budget permits; otherwise external provider if user has enabled it
- no network → local deterministic + installed local model only

## Safety and privacy

No hidden recording, no automatic model downloads, no automatic publication, and no automatic cross-app actions. Sensitive content remains subject to Nori's existing privacy/session gates.

## Build safety

The optional SDK profile is disabled by default so the current app does not suddenly acquire large dependencies or change its minimum-device assumptions. Enable it deliberately after Android Studio/device testing.
