# POST23 STEP46 — Admission, Admin Plane & Production Hardening

Step 46 turns the Step45 knowledge/humanization architecture into a gated multi-user product foundation.

## 1. Admission gate
No student workspace is available before an approved authenticated session.
Required registration fields:
- name
- age
- primary email
- backup email
- password through the configured authentication provider

The primary email must be verified. The backup email must be separately verified. The account must also have an accepted Nori-program admission basis: INVITED, PREAPPROVED_EMAIL, or KNOWN_AND_ACCEPTED.

Authentication and admission are separate. A valid password alone never unlocks the app.

## 2. Age-aware Nori
Age is retained as an age band for response/safety context. It may change communication and safety behavior, but never changes personal worth or academic expectations.

## 3. Per-user isolation
User identity scopes:
- profile
- memory
- library
- conversation
- plans/results
- feedback

The knowledge plugin now rejects protected library/WPS/YouTube actions unless an approved session exists.

## 4. Admin plane
OWNER/ADMIN functions are separated from the student app:
- admissions
- student registry
- program allowlist/invites
- audit
- feedback review
- improvement proposals
- controlled source changes
- release management

Students cannot edit source code or deploy changes.

The mobile admin UI is only a control-plane shell. Production authorization must be enforced on the server because an APK can be modified.

## 5. Code change governance
Production source lifecycle:
DISCOVER → PATCH → STATIC CHECKS → TESTS → SECURITY CHECKS → OWNER APPROVAL → BUILD → SIGN → DEPLOY → VERIFY → ROLLBACK.

Feedback never directly edits production code.

## 6. Email safety
Nori can create an improvement email draft. Sending requires explicit authorization. Sensitive student information must not be silently forwarded to a backup email. Admin-approved automated reports should be minimized and auditable.

## 7. Cloud/auth security
Supabase is suitable for the account/auth foundation if configured correctly. Confirm Email should be enabled for production. The service/secret key must remain server-side. RLS must enforce per-user data isolation.

## 8. Backup email
Backup email is required for both student and admin accounts. It must differ from the primary email and have its own verification state.

## 9. No client-side trust
The APK can provide UX gates, but cannot be the authoritative source of role, admission, permissions, or data access. The backend repeats authorization for every protected operation.
