import com.nori.jarvis.nori.ai.*;
import com.nori.jarvis.nori.brain.human.*;
import java.util.*;
public class BrainStep14Smoke {
  public static void main(String[] a){
    AiRouter r=new AiRouter();
    AiResponse x=r.generate(new AiRequest("what is 15% of 240"));
    if(!x.text.equals("36")) throw new RuntimeException("local compute failed: "+x.text);
    HumanContextEngine h=new HumanContextEngine();
    HumanContextEngine.Assessment q=h.assess("I am overwhelmed and can't start",3,0,true);
    if(q.support!=HumanContextEngine.SupportLevel.STABILIZE) throw new RuntimeException("support policy failed");
    System.out.println("BRAIN_STEP14_SMOKE_PASS");
  }
}
