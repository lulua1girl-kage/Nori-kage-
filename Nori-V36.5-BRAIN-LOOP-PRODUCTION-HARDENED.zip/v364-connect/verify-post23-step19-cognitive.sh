#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/cognition/NoriCognitiveEngine.java"
CAT="$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/cognition/NoriCognitiveFeatureCatalog.java"
BRAIN="$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
test -s "$SRC"; test -s "$CAT"; grep -q 'NoriCognitiveEngine' "$BRAIN"
rm -rf /tmp/nori-step19-classes; mkdir -p /tmp/nori-step19-classes
javac -d /tmp/nori-step19-classes "$SRC" "$CAT"
cat >/tmp/NoriCognitiveSmoke.java <<'JAVA'
import com.nori.jarvis.nori.brain.cognition.*;
public class NoriCognitiveSmoke {
 public static void main(String[] a){
  NoriCognitiveEngine e=new NoriCognitiveEngine();
  var x=e.think("Should I research the latest evidence and compare sources?", "student wants an accurate study answer", true, false);
  if(x.hypothesisCount<1 || !x.needsEvidence || !x.needsVerification) throw new AssertionError("cognitive checks failed");
  var y=e.think("what is 2+2?", "", false, false);
  if(y.effort!=NoriCognitiveEngine.Effort.MICRO) throw new AssertionError("fast path failed");
  System.out.println("STEP19_COGNITIVE_PASS features="+NoriCognitiveFeatureCatalog.all().size()+" cache="+e.cacheSize());
 }
}
JAVA
javac -cp /tmp/nori-step19-classes -d /tmp/nori-step19-classes /tmp/NoriCognitiveSmoke.java
java -cp /tmp/nori-step19-classes NoriCognitiveSmoke
printf 'POST23_STEP19_COGNITIVE_SOURCE_PASS\n'
