# NORI V32 → Native Java — Stage 2 Data Foundation

## Status

Implemented in parallel with V32. Existing V32 behavior has not been removed or redirected.

## What Stage 2 adds

1. A native SQLite database (`nori_native.db`).
2. A generic JSON-backed native repository (`NativeDataRepository`).
3. A non-destructive V32 export importer (`V32DataImporter`).
4. A first-pass storage inventory (`V32StorageInventory`).
5. Category tagging for migration without forcing premature typed models.

## Why generic JSON first

V32 contains many generations of storage keys and dynamic `nori_phase_*` keys. Converting every record directly into rigid Java classes before the complete schema is known would risk data loss or behavior changes.

Stage 2 therefore preserves each value as JSON while giving the native app a stable persistence boundary. Typed academic/KAGE/memory models can be introduced above this layer in later stages.

## V32 migration contract

The existing V32 storage layer already provides an export shape containing:

- `schemaVersion`
- `exportedAt`
- `data` — key/value records

`V32DataImporter` accepts that shape. By default it **does not overwrite an existing native key**.

## Important non-changes

Stage 2 does NOT:

- delete V32 localStorage
- replace V32 UI
- change MainActivity
- change the existing Brain generations
- change KAGE/Override behavior
- change voice/blocker behavior
- enable cloud sync
- require an API
- activate the native repository in the running app

## Next data work

Before connecting the native repository to the app, Stage 2B should:

- enumerate every remaining direct localStorage writer
- classify each key as canonical / legacy / cache / temporary / sensitive / system
- identify duplicate representations of the same concept
- define typed models for high-value records
- test export → import → read-back equivalence
- only then introduce the first native read path
