package release;

/** Release identity mirrored from android/app/build.gradle for source-gate verification. */
public final class NoriReleaseMetadata {
    public static final int VERSION_CODE = 33;
    public static final String VERSION_NAME = "33.0.0-rc1";
    private NoriReleaseMetadata() {}
}
