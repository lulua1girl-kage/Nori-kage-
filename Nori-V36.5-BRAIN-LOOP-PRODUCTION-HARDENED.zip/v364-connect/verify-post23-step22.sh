#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
BASE="$ROOT/android/app/src/main/java"
find "$BASE/com/nori/jarvis/nori/brain/learning" -name '*.java' -print >/tmp/nori_step22_sources.txt
javac -d /tmp/nori_step22_classes \
 "$BASE/com/nori/jarvis/nori/education/model/AcademicEvidence.java" \
 "$BASE/com/nori/jarvis/nori/education/model/StrengthWeaknessReport.java" \
 "$BASE/com/nori/jarvis/nori/education/model/MistakeReport.java" \
 "$BASE/com/nori/jarvis/nori/education/EducationalIntelligence.java" \
 "$BASE/com/nori/jarvis/nori/education/engine/StrengthWeaknessEngine.java" \
 "$BASE/com/nori/jarvis/nori/education/engine/MistakeIntelligence.java" \
 "$BASE/com/nori/jarvis/nori/education/engine/LearningPatternAnalyzer.java" \
 "$BASE/com/nori/jarvis/nori/education/engine/StudyPlanner.java" \
 "$BASE/com/nori/jarvis/nori/education/engine/ExamPreparationEngine.java" \
 "$BASE/com/nori/jarvis/nori/education/engine/DynamicStudySessionEngine.java" \
 "$BASE/com/nori/jarvis/nori/education/engine/AdaptiveTutorPolicy.java" \
 $(cat /tmp/nori_step22_sources.txt)
printf '%s\n' 'POST23_STEP22_ACADEMIC_DEVELOPMENT_PASS'
