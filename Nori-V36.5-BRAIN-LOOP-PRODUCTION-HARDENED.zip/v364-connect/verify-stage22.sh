#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
command -v javac >/dev/null 2>&1 || { echo "ERROR: javac is required" >&2; exit 1; }

# 1) Run the established native regression gates.
./verify-stage21.sh
rm -rf build_stage22
mkdir -p build_stage22
mapfile -t SOURCES < <(grep -L '^import android\.' $(find android/app/src/main/java/com/nori/jarvis/nori -name '*.java' -print) | grep -v '/V32MigrationValidator.java$' | grep -v '/NoriNativeCore.java$')
javac -encoding UTF-8 -d build_stage22 "${SOURCES[@]}" tests/native/Stage20Regression.java
java -cp build_stage22 Stage20Regression

# 2) Version/release identity checks.
grep -q "versionCode = 33" android/app/build.gradle
grep -q "versionName = '33.0.0-rc1'" android/app/build.gradle
grep -q 'VERSION_CODE = 33' release/NoriReleaseMetadata.java
grep -q 'VERSION_NAME = "33.0.0-rc1"' release/NoriReleaseMetadata.java

# 3) Manifest/security sanity.
grep -q 'android:allowBackup="false"' android/app/src/main/AndroidManifest.xml
grep -q 'android:usesCleartextTraffic="false"' android/app/src/main/AndroidManifest.xml
grep -q 'android.permission.INTERNET' android/app/src/main/AndroidManifest.xml
test -f android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java
test -f www/brain-engine/brain.js

# 4) No common hard-coded credential patterns in source/config.
if grep -RInE --exclude-dir=build_stage20 --exclude-dir=build_stage21 --exclude-dir=build_stage22 --exclude='*.zip' --exclude='*.md' '(sk-[A-Za-z0-9]{20,}|AIza[0-9A-Za-z_-]{20,}|BEGIN (RSA|OPENSSH|EC|PRIVATE) KEY)' android www release >/tmp/nori_stage22_secret_hits 2>/dev/null; then
  echo 'ERROR: possible credential material detected:' >&2
  cat /tmp/nori_stage22_secret_hits >&2
  exit 1
fi

# 5) Record whether a local Android build environment exists; do not fabricate one.
if [[ -x android/gradlew || -x android/gradlew.bat ]]; then
  BUILD_ENV_STATUS='wrapper-present'
else
  BUILD_ENV_STATUS='android-build-not-run-no-wrapper'
fi
printf 'STAGE22_RELEASE_SOURCE_GATE_PASS build_env=%s\n' "$BUILD_ENV_STATUS"
