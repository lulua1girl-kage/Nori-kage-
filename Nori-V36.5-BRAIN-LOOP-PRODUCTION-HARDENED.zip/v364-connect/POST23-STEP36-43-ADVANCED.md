# Nori Post-23 Steps 36–43 — Integrated Cognitive Evolution

This release repairs the Step 35/36 integration boundary and advances Steps 37–43 as one coherent architecture.

## Step 35 — Integrated Meta-Brain request pipeline

The Meta-Brain now coordinates, in one bounded request cycle:

1. Unified State
2. governed Memory Context
3. Cognitive preflight
4. Meta-Brain capability selection
5. Constitution decision
6. Personal World Model update when the request is materially goal/context related
7. Human Context 2.0 trajectory assessment
8. causal/counterfactual safety layer
9. research-depth planning
10. execution lifecycle requirement
11. recovery availability
12. outcome-learning readiness
13. verification requirement

The pipeline records an auditable integration trace rather than hidden chain-of-thought.

## Step 36 — Personal World Model + persistent cognitive state

`NoriPersonalWorldModel` stores bounded, relationship-oriented facts for goals, skills, schedules, events, preferences and context through the existing `DataRepository` abstraction.

It supports:
- confidence
- timestamps
- source labels
- relevance retrieval
- sequence numbers
- snapshots
- active goal/skill/event views
- restart persistence when a repository is supplied

It does not become a raw surveillance database.

## Step 37 — Causal + Counterfactual Reasoning

`NoriCausalCounterfactualEngine` explicitly separates:
- hypothesis
- association
- supported relationship
- missing evidence
- alternative explanations

Counterfactuals contain:
- baseline
- changed variable
- expected effects
- second-order risks
- measurable verification checks

No causal claim is upgraded merely because two observations correlate.

## Step 38 — Real Capability Execution Core

`NoriExecutionLifecycle` provides a common lifecycle record:

DISCOVER → UNDERSTAND → RESOLVE → PREPARE → PREVIEW → AUTHORIZE → EXECUTE → VERIFY → RECOVER → LEARN

It is connected to the existing `NoriFunctionalExecutionCore` and `ActionEngine` rather than replacing them.

Important: understanding a capability never authorizes execution.

## Step 39 — Advanced Learning + Misconception Detection

`NoriAdvancedLearningEngine` tracks bounded attempts by:
- subject
- skill
- error pattern
- context
- outcome

It clusters recurring error patterns, estimates mastery and produces targeted intervention candidates only when enough repeated evidence exists.

## Step 40 — Research Brain 2.0

`NoriResearchBrain2` adds:
- NORMAL / CURRENT / DEEP / EXHAUSTIVE depth
- 3 / 8 / 15 / 25 source targets
- provenance fields
- authority weighting
- duplicate reduction
- freshness evaluation
- repeated-claim conflict detection
- explicit unknowns

Retrieval remains owned by web/provider layers; this component plans and synthesizes research rather than pretending to fetch sources itself.

## Step 41 — Human Context 2.0

`NoriHumanContext2` maintains a bounded trajectory of explicit/contextual capacity assessments.

It can identify a broad trend:
- improving
- stable
- declining
- unclear

and recommend load reduction or continuation without diagnosing a condition.

## Step 42 — Self-Correction + Failure Recovery

`NoriFailureRecoveryEngine` classifies failures into:
- network
- permission
- timeout
- validation
- tool
- provider
- unknown

It chooses bounded retry, alternate offline/local route, user correction/permission, or fail-safe preservation.

The existing learning/evolution engines remain responsible for governed adaptation; there is no silent self-modification.

## Step 43 — Full Nori Integration + Benchmarking

`NoriIntegrationBenchmark` provides deterministic architecture-level cases for:
- local information
- current information
- navigation/action
- research
- planning

The benchmark tests orchestration correctness, not intelligence quality or model capability.

## Current validation

`POST23_STEP31_END_TO_END_PASS`

`POST23_STEP31_STATIC_PASS`

`POST23_STEP36_43_INTEGRATION_PASS trace=13 benchmark=5/5 worldSeq=1`

The current verification compiles the non-Android native Java source set. A complete Android APK/device build still requires the Android SDK/Gradle environment and a physical-device run.

## Architecture references used for design direction

The integration design follows current public patterns rather than copying proprietary implementations:

- OpenAI Agents SDK: agents/tools/handoffs, sessions, human-in-the-loop, guardrails and tracing.
- Android architecture guidance: layered state/data flows and local-first architecture.
- ML Kit Prompt API: current Android on-device generative model integration, structured outputs/system instructions and multimodal prompt support.

Nori remains its own architecture: Constitution and Human Override remain authoritative, local-first operation remains available, and model/tool layers remain subordinate to the Nori Brain.
