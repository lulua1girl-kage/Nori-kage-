#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
node --check www/nori-knowledge-hub-v1.js
rm -rf /tmp/nori-step45 && mkdir -p /tmp/nori-step45
javac -d /tmp/nori-step45 \
 android/app/src/main/java/com/nori/jarvis/nori/data/DataRepository.java \
 android/app/src/main/java/com/nori/jarvis/nori/library/NoriLibraryIndex.java \
 android/app/src/main/java/com/nori/jarvis/nori/library/NoriFileIntelligence.java \
 android/app/src/main/java/com/nori/jarvis/nori/library/NoriFastLibraryPipeline.java \
 android/app/src/main/java/com/nori/jarvis/nori/library/NoriLibraryPerformancePolicy.java \
 android/app/src/main/java/com/nori/jarvis/nori/knowledge/NoriKnowledgeSourceRegistry.java \
 android/app/src/main/java/com/nori/jarvis/nori/knowledge/NoriContradictionResolver.java \
 android/app/src/main/java/com/nori/jarvis/nori/knowledge/NoriSubjectMasteryRegistry.java \
 android/app/src/main/java/com/nori/jarvis/nori/knowledge/NoriTeachingPersonality.java \
 android/app/src/main/java/com/nori/jarvis/nori/knowledge/NoriSourcePrioritizer.java \
 android/app/src/main/java/com/nori/jarvis/nori/knowledge/NoriKnowledgePolicy.java \
 android/app/src/main/java/com/nori/jarvis/nori/knowledge/NoriKnowledgeReflectionEngine.java \
 android/app/src/main/java/com/nori/jarvis/nori/knowledge/NoriKnowledgeGraphLite.java \
 android/app/src/main/java/com/nori/jarvis/nori/knowledge/NoriResearchRoute.java \
 android/app/src/main/java/com/nori/jarvis/nori/learning/NoriAutonomousLearningEngine.java \
 android/app/src/main/java/com/nori/jarvis/nori/learning/NoriLearningGovernance.java \
 android/app/src/main/java/com/nori/jarvis/nori/identity/NoriUserIdentity.java \
 android/app/src/main/java/com/nori/jarvis/nori/cloud/NoriCloudLibraryStore.java \
 android/app/src/main/java/com/nori/jarvis/nori/cloud/NoriCloudStorageRouter.java \
 android/app/src/main/java/com/nori/jarvis/nori/conversation/NoriHumanizedCooperativeEngine.java \
 android/app/src/main/java/com/nori/jarvis/nori/security/NoriDisclosureResponseEngine.java \
 android/app/src/main/java/com/nori/jarvis/nori/security/NoriVisualSafetyPolicy.java \
 android/app/src/main/java/com/nori/jarvis/nori/benchmark/NoriStep45KnowledgeSmoke.java \
 android/app/src/main/java/com/nori/jarvis/nori/benchmark/NoriStep45FiveXSmoke.java
java -cp /tmp/nori-step45 com.nori.jarvis.nori.benchmark.NoriStep45KnowledgeSmoke
java -cp /tmp/nori-step45 com.nori.jarvis.nori.benchmark.NoriStep45FiveXSmoke
printf 'POST23_STEP45_FIVE_X_SOURCE_PASS\n'
