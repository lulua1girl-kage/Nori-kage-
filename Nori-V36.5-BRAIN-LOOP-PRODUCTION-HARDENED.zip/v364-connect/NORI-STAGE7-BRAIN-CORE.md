# Nori V32 — Stage 7 Native Brain Core

## Scope
Stage 7 connects the native intent, context, academic, KAGE and verification layers
into a single deterministic orchestration path. It is the first native Brain layer
that coordinates the migrated engines rather than exposing them only as separate
services.

## Pipeline
1. Validate the incoming academic event.
2. Analyze the assessment with the native AcademicEngine.
3. Classify the primary context with the native ContextEngine.
4. Classify optional secondary context.
5. Determine failure type through the native KAGE engine.
6. Determine the applicable KAGE degree from supplied history.
7. Select only known consequence IDs already represented by the migrated Stage 5 policy.
8. Produce an academic correction recommendation independently of discipline.
9. Run a completeness verification pass.
10. Return a structured BrainDecision containing facts, inferences and next actions.

## Important safety/architecture rule
Stage 7 is recommendation/orchestration only. It does not silently write a consequence,
change student data, or execute device actions. Action execution remains a later tool/action
layer with permission and confirmation boundaries.

## Intent routing
IntentEngine now deterministically recognizes the core intent classes used by the native
architecture: ASK, READ, ANALYZE, PLAN, UPDATE, COMPLETE, CREATE, SEARCH, SUMMARIZE,
ADMIN, EXPLAIN, VERIFY and UNKNOWN. It is a router, not an action executor.

## V32 parity
- Context classification was migrated from `www/brain-engine/engines/contextEngine.js`.
- Academic analysis remains the Stage 6 native migration.
- KAGE failure/degree rules remain the Stage 5 native migration.
- The V32 JavaScript Brain and all existing engines remain intact as the reference implementation.
- Stage 7 does not retire the old Brain.

## Current limitation
ConsequencePolicy still contains only the consequence IDs migrated in Stage 5. Therefore
Stage 7 deliberately does not pretend to have the complete V32 consequence catalog yet.
Full catalog parity belongs to the later KAGE/consequence migration work.

## Verification
- Native Brain core, AcademicEngine, ContextEngine and KAGE classes compile together with `javac`.
- Stage 7 smoke test passed for a combined academic/behavioral event.
- JUnit tests were added for intent routing, orchestration, verification, academic-only behavior.
- Full Android APK build/device validation remains pending until Android Studio/Android SDK is available.
