# Nori Native Stage 14 — Admin & Multi-Student System

## Purpose
Create a deny-by-default administrative control plane for Nori's multi-student model while preserving student isolation, privacy, Human Override, and the education-first architecture.

## Added
- `AdminControlPlane` with explicit owner bootstrap.
- Email invitation/allowlist and revocation.
- Roles: OWNER, ADMIN, STUDENT, VIEWER.
- Authorization checks with student-isolation rules.
- Student registry records with active/inactive status.
- Administrative audit records with bounded history.
- NoriBrain exposure through `getAdminControlPlane()`.

## Security boundary
- No public self-promotion to OWNER/ADMIN.
- Uninvited accounts are denied with `not_invited_to_nori_project`.
- Students cannot access another student's student-scoped operations through the native authorization boundary.
- Admin operations are restricted to OWNER/ADMIN; owner-only operations remain owner-only.
- The control plane does not grant administrative authority based on GitHub/source access.

## Important deployment limitation
Local Android code cannot provide absolute authorization against a person who controls and modifies the APK/database. For a real multi-user deployment, authentication and authorization must also be enforced server-side. The native control plane is therefore the application-layer policy, not a claim of unbreakable local security.

## Data isolation
Stage 14 defines the control-plane registry and authorization boundary. Detailed per-student memory, academic records, conversations, plans, and history remain separate concerns and should be stored under student-scoped namespaces in the next data/security work rather than mixed into one global record.

## Preserved
All V32 JavaScript and previous native stages remain intact.
