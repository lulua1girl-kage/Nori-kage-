#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/state/NoriState.java"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/state/NoriStateEngine.java"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/reasoning/GeneralReasoning.java"
grep -q 'observeStudy' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/state/NoriStateEngine.java"
grep -q 'observeExam' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/state/NoriStateEngine.java"
grep -q 'observeDeviceApp' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/state/NoriStateEngine.java"
grep -q 'GeneralReasoning' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
echo POST23_STEP21_UNIFIED_STATE_REASONING_SOURCE_PASS
