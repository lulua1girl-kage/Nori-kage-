# Nori V32 — Stage 20: Testing & Regression

## Purpose
Stage 20 establishes a repeatable regression gate over the native Java migration. It validates cross-stage contracts without replacing the Android build/device test that requires a real Android SDK.

## Coverage
- Academic assessment bands, weighting, error classification and invalid-input rejection.
- KAGE degree behavior and integrity/consequence safety boundaries.
- Explicit memory storage and sensitive-memory rejection.
- Educational evidence, assessment, mistake analysis and bounded planning.
- Advanced trajectory/insight availability and explainability warnings.
- Action proposal → preview → confirmation → execution → undo, including invalid payload blocking.
- Conversation confirmation and protected-change handling; bounded session state.
- Optional AI local fallback and remote-off default.
- Security input validation, HTTPS-only policy, audit-chain verification and fail-closed reliability threshold.
- End-to-end Nori Brain academic processing and verification.
- Static preservation checks for V32 brain and critical native security/intelligence modules.

## Run

```bash
./verify-stage20.sh
```

Expected final markers:

```text
STAGE20_REGRESSION_PASS
STAGE20_STATIC_REGRESSION_PASS
```

## Android limitation
The regression suite compiles the platform-independent Java layer. Android-dependent classes are excluded from this local `javac` pass. A full APK build/install/test still requires an Android SDK and a complete Gradle environment, followed by device testing on the target Android phone.

## Regression principle
A later stage must not silently remove or bypass an earlier stage's safety, Human Override, educational-purpose, privacy, or verification boundaries.
