#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT/www"
echo "== V36.4 JavaScript syntax audit =="
find . -type f -name '*.js' -not -path './node_modules/*' -print0 | xargs -0 -n1 node --check >/dev/null
echo "PASS: all JS syntax checks"
echo "== V36.4 test suite =="
failed=0
for f in tests/*-smoke.js; do
  if node "$f" >/tmp/nori-test.out 2>&1; then echo "PASS $f"; else cat /tmp/nori-test.out; echo "FAIL $f"; failed=1; fi
done
if [ "$failed" -ne 0 ]; then exit 1; fi
cd "$ROOT"
echo "== Android toolchain readiness =="
if [ -f android/gradle/wrapper/gradle-wrapper.jar ]; then echo "PASS wrapper jar present"; else echo "WARN wrapper jar missing: Android Gradle build cannot be executed in this package/environment."; fi
if [ -n "${ANDROID_HOME:-}" ] && [ -d "${ANDROID_HOME}" ]; then echo "PASS ANDROID_HOME=$ANDROID_HOME"; else echo "WARN Android SDK not available in this environment."; fi
if command -v java >/dev/null 2>&1; then java -version 2>&1 | head -1; else echo "WARN JDK unavailable"; fi
echo "V36.4 source/runtime verification complete. Physical-device verification remains external."
