# Nori V28 — Explainability + Rule Review

Baseline: Nori V32 Brain V27 Mentor Contract.

## Why V28 comes before smarter autonomous behavior

V28 adds two oversight layers before trajectory foresight, richer diagnosis, or growth narratives:

1. Explainable deterministic audit chain.
2. Owner-only rule-tuning review.

### Explainability

`explainabilityEngine.js` renders the actual recorded chain:

event -> academic rule/band -> failure classification -> degree + reasons -> consequence/correction -> override status.

It is read-only. It does not recalculate, soften, escalate, or modify the decision.

The API exposes `mode: "explain_decision"` and returns a plain-language explanation plus structured steps.

### Rule-tuning review

`ruleReviewEngine.js` looks for repeated predefined interventions in supplied audit records.

A repeated intervention is treated as evidence for review, NOT proof that the intervention caused the failure.

Flags are:
`OWNER_REVIEW_REQUIRED`

The review engine cannot:
- rewrite a rule
- increase severity
- replace a consequence
- alter degree thresholds
- change a band

This creates the beginning of the governance loop:
OBSERVED PATTERN -> REVIEW FLAG -> OWNER DECISION -> future controlled patch.

No automatic rule learning is implemented.

### Important limitation

The current audit engine is still an in-memory reference store. V28 therefore makes the explanation/review functions deterministic and read-only, but it does not yet create durable server-side audit storage. Canonical State Authority and durable audit persistence remain separate next layers.

### Tests

`www/tests/v28-explainability-review-smoke.js`

The test proves:
- explanation is read-only;
- the deterministic chain is exposed;
- repeated interventions create an owner-review flag;
- the review engine explicitly prohibits automatic rule changes.
