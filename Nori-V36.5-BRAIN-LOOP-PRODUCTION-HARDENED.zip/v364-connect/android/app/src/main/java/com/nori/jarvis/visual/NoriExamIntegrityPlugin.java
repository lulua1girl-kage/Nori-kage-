package com.nori.jarvis.visual;
import com.nori.jarvis.nori.exam.NoriExamIntegrityService;

import android.app.*;import android.content.*;import com.getcapacitor.*;import com.getcapacitor.annotation.*;

@CapacitorPlugin(name="NoriExamIntegrity")
public final class NoriExamIntegrityPlugin extends Plugin {
    private static final int REQ=9701;
    @PluginMethod public void start(PluginCall call){
        android.media.projection.MediaProjectionManager m=(android.media.projection.MediaProjectionManager)getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(call,m.createScreenCaptureIntent(),"consent");
    }
    @ActivityCallback public void consent(PluginCall call,ActivityResult result){
        if(result==null||result.getResultCode()!=Activity.RESULT_OK||result.getData()==null){call.reject("Exam screen monitoring permission was canceled");return;}
        Intent i=new Intent(getContext(),NoriExamIntegrityService.class).setAction(NoriExamIntegrityService.ACTION_START);i.putExtra("resultCode",result.getResultCode());i.putExtra("projectionData",result.getData());
        if(android.os.Build.VERSION.SDK_INT>=26)getContext().startForegroundService(i);else getContext().startService(i);
        getContext().getSharedPreferences("nori_exam_policy",Context.MODE_PRIVATE).edit().putBoolean("active",true).apply();
        call.resolve(new JSObject().put("ok",true).put("mode","exam_integrity"));
    }
    @PluginMethod public void stop(PluginCall call){getContext().stopService(new Intent(getContext(),NoriExamIntegrityService.class));getContext().getSharedPreferences("nori_exam_policy",Context.MODE_PRIVATE).edit().putBoolean("active",false).apply();call.resolve();}
    @PluginMethod public void status(PluginCall call){call.resolve(new JSObject().put("active",getContext().getSharedPreferences("nori_exam_policy",Context.MODE_PRIVATE).getBoolean("active",false)));}
}
