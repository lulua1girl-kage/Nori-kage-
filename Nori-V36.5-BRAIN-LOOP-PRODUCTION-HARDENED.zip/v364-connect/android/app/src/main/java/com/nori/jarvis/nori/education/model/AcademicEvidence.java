package com.nori.jarvis.nori.education.model;

import java.time.LocalDateTime;
import java.util.*;

public final class AcademicEvidence {
    public final String subject, topic;
    public final double score;
    public final List<String> missedConcepts;
    public final int carelessErrors, applicationErrors;
    public final LocalDateTime at;
    public AcademicEvidence(String subject,String topic,double score,List<String> missedConcepts,
                             int carelessErrors,int applicationErrors,LocalDateTime at){
        this.subject=subject; this.topic=topic; this.score=score;
        this.missedConcepts=Collections.unmodifiableList(new ArrayList<>(missedConcepts==null?Collections.emptyList():missedConcepts));
        this.carelessErrors=Math.max(0,carelessErrors); this.applicationErrors=Math.max(0,applicationErrors);
        this.at=at==null?LocalDateTime.now():at;
    }
}
