package com.nori.jarvis.nori.brain.cognition;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Step 19: Nori Cognitive Core.
 * Models useful decision-making structure without exposing private chain-of-thought.
 * It produces a compact reasoning state that can guide the rest of the Brain.
 */
public final class NoriCognitiveEngine {
    public enum Intent { INFORM, SOLVE, PLAN, DECIDE, CREATE, ACT, LEARN, SUPPORT, RESEARCH, DEBUG, NAVIGATE, UNKNOWN }
    public enum Confidence { LOW, MODERATE, HIGH }
    public enum Effort { MICRO, FAST, DELIBERATE, DEEP }
    public enum AnswerShape { DIRECT, EXPLAIN, OPTIONS, PLAN, ACTION, RESEARCH, SUPPORT }

    public static final class ThoughtState {
        public final Intent intent;
        public final Confidence confidence;
        public final Effort effort;
        public final AnswerShape answerShape;
        public final boolean ambiguity;
        public final boolean contradictionRisk;
        public final boolean staleKnowledgeRisk;
        public final boolean needsEvidence;
        public final boolean needsTool;
        public final boolean needsVerification;
        public final boolean needsClarification;
        public final boolean userControlRequired;
        public final boolean canAnswerLocally;
        public final int hypothesisCount;
        public final int decisionDepth;
        public final int estimatedWorkUnits;
        public final List<String> activeQuestions;
        public final List<String> checks;
        public final String strategy;

        ThoughtState(Intent i, Confidence c, Effort e, AnswerShape a, boolean amb, boolean contra,
                     boolean stale, boolean evidence, boolean tool, boolean verify, boolean clarify,
                     boolean override, boolean local, int hypotheses, int depth, int units,
                     List<String> questions, List<String> checks, String strategy) {
            intent=i; confidence=c; effort=e; answerShape=a; ambiguity=amb; contradictionRisk=contra;
            staleKnowledgeRisk=stale; needsEvidence=evidence; needsTool=tool; needsVerification=verify;
            needsClarification=clarify; userControlRequired=override; canAnswerLocally=local;
            hypothesisCount=hypotheses; decisionDepth=depth; estimatedWorkUnits=units;
            activeQuestions=Collections.unmodifiableList(new ArrayList<>(questions));
            this.checks=Collections.unmodifiableList(new ArrayList<>(checks)); this.strategy=strategy;
        }
    }

    private static final int MAX_CACHE = 256;
    private final ConcurrentHashMap<String, ThoughtState> hot = new ConcurrentHashMap<>();
    private final ArrayDeque<String> order = new ArrayDeque<>();

    /** Fast, bounded cognitive preflight. Never performs network or tool I/O. */
    public ThoughtState think(String raw, String contextSummary, boolean externalAvailable, boolean userInitiatedAction) {
        String p=normalize(raw); String key=key(p,contextSummary,externalAvailable,userInitiatedAction);
        ThoughtState cached=hot.get(key); if(cached!=null) return cached;
        Intent intent=classify(p); boolean amb=ambiguous(p,intent); boolean stale=staleRisk(p);
        boolean evidence=needsEvidence(p,intent,stale); boolean tool=needsTool(p,intent,userInitiatedAction);
        boolean contradiction=hasAny(p,"but","however","instead","actually","except","although");
        boolean local=localEnough(p,intent,externalAvailable,stale,evidence);
        boolean verify=needsVerification(p,intent,evidence,tool);
        boolean clarify=amb && !hasEnoughContext(contextSummary);
        boolean override=userInitiatedAction || intent==Intent.ACT;
        Effort effort=effort(p,intent,evidence,tool,contradiction,stale);
        Confidence conf=confidence(p,contextSummary,amb,stale,evidence);
        AnswerShape shape=shape(intent,p);
        int hypotheses=hypotheses(intent,amb,contradiction);
        int depth=depth(intent,evidence,tool,contradiction,stale);
        int units=units(effort,depth,hypotheses,tool,evidence);
        List<String> questions=new ArrayList<>();
        if(clarify) questions.add("Is the user's intended outcome unambiguous?");
        if(evidence) questions.add("What evidence is required before making a strong claim?");
        if(contradiction) questions.add("Are the apparent constraints actually in conflict?");
        if(stale) questions.add("Could current information change the answer?");
        if(tool) questions.add("Can the task be completed safely with an available tool?");
        List<String> checks=new ArrayList<>();
        checks.add("separate facts from assumptions"); checks.add("check the user's actual goal");
        if(hypotheses>1) checks.add("compare plausible interpretations before committing");
        if(verify) checks.add("verify the result against the requested outcome");
        if(override) checks.add("preserve Human Override before external action");
        if(stale) checks.add("prefer fresh evidence when recency matters");
        String strategy=strategy(intent,effort,conf,local,clarify,verify,hypotheses);
        ThoughtState s=new ThoughtState(intent,conf,effort,shape,amb,contradiction,stale,evidence,tool,verify,clarify,override,local,hypotheses,depth,units,questions,checks,strategy);
        put(key,s); return s;
    }

    private synchronized void put(String k, ThoughtState s){ hot.put(k,s); order.remove(k); order.addLast(k); while(order.size()>MAX_CACHE){String x=order.removeFirst();hot.remove(x);} }
    public synchronized void clear(){hot.clear();order.clear();}
    public int cacheSize(){return hot.size();}

    private static Intent classify(String p){
        if(hasAny(p,"debug","bug","error","compile","stack trace","fix code")) return Intent.DEBUG;
        if(hasAny(p,"research","investigate","sources","compare studies","latest evidence")) return Intent.RESEARCH;
        if(hasAny(p,"how do i","navigate","open","go to","where is")) return Intent.NAVIGATE;
        if(hasAny(p,"remind","schedule","do this","send","open app","save")) return Intent.ACT;
        if(hasAny(p,"should i","which","choose","decision","tradeoff")) return Intent.DECIDE;
        if(hasAny(p,"plan","schedule","roadmap","strategy","steps")) return Intent.PLAN;
        if(hasAny(p,"solve","calculate","equation","derive","work out")) return Intent.SOLVE;
        if(hasAny(p,"teach","learn","study","quiz","explain to me")) return Intent.LEARN;
        if(hasAny(p,"feel","tired","overwhelmed","stressed","can't focus","cannot focus")) return Intent.SUPPORT;
        if(hasAny(p,"write","create","design","draft","generate")) return Intent.CREATE;
        if(hasAny(p,"do","perform","execute")) return Intent.ACT;
        if(p.endsWith("?") || hasAny(p,"what is","who is","when is","define","why")) return Intent.INFORM;
        return Intent.UNKNOWN;
    }
    private static Effort effort(String p,Intent i,boolean e,boolean t,boolean c,boolean s){
        int n=(p.length()>500?1:0)+(e?2:0)+(t?1:0)+(c?1:0)+(s?1:0);
        if(i==Intent.INFORM && n<2) return Effort.MICRO;
        if(n>=5 || i==Intent.RESEARCH || i==Intent.DEBUG) return Effort.DEEP;
        if(n>=3 || i==Intent.DECIDE || i==Intent.PLAN) return Effort.DELIBERATE;
        return Effort.FAST;
    }
    private static Confidence confidence(String p,String ctx,boolean a,boolean s,boolean e){int n=0;if(p.length()>20)n++;if(ctx!=null&&!ctx.isEmpty())n++;if(!a)n++;if(!s)n++;if(!e)n++;return n>=4?Confidence.HIGH:n>=2?Confidence.MODERATE:Confidence.LOW;}
    private static AnswerShape shape(Intent i,String p){switch(i){case PLAN:return AnswerShape.PLAN;case DECIDE:return AnswerShape.OPTIONS;case RESEARCH:return AnswerShape.RESEARCH;case ACT:return AnswerShape.ACTION;case SUPPORT:return AnswerShape.SUPPORT;case LEARN:case SOLVE:case DEBUG:return AnswerShape.EXPLAIN;default:return AnswerShape.DIRECT;}}
    private static int hypotheses(Intent i,boolean a,boolean c){int n=(a?2:1);if(c)n++;if(i==Intent.DECIDE||i==Intent.PLAN||i==Intent.DEBUG)n++;return Math.min(4,n);}
    private static int depth(Intent i,boolean e,boolean t,boolean c,boolean s){int d=1;if(e)d++;if(t)d++;if(c)d++;if(s)d++;if(i==Intent.RESEARCH||i==Intent.DEBUG||i==Intent.DECIDE)d++;return Math.min(6,d);}
    private static int units(Effort e,int d,int h,boolean t,boolean ev){int base=e==Effort.MICRO?1:e==Effort.FAST?2:e==Effort.DELIBERATE?4:7;return base+d+h+(t?2:0)+(ev?2:0);}
    private static boolean ambiguous(String p,Intent i){return i==Intent.UNKNOWN || p.length()<6 || hasAny(p,"it","that","this","they","something","same thing");}
    private static boolean hasEnoughContext(String c){return c!=null&&c.trim().length()>=12;}
    private static boolean staleRisk(String p){return hasAny(p,"latest","today","current","recent","now","this week","2026","updated");}
    private static boolean needsEvidence(String p,Intent i,boolean stale){return stale||i==Intent.RESEARCH||hasAny(p,"proof","evidence","source","citation","fact check","is it true");}
    private static boolean needsTool(String p,Intent i,boolean action){return action||i==Intent.ACT||i==Intent.NAVIGATE||i==Intent.DEBUG||hasAny(p,"file","pdf","screen","calendar","github","calculate");}
    private static boolean needsVerification(String p,Intent i,boolean e,boolean t){return e||t||i==Intent.DECIDE||i==Intent.RESEARCH||i==Intent.DEBUG||hasAny(p,"exact","accurate","make sure","verify");}
    private static boolean localEnough(String p,Intent i,boolean ext,boolean stale,boolean evidence){return !stale&&!evidence&&i!=Intent.RESEARCH&&i!=Intent.NAVIGATE&&i!=Intent.ACT;}
    private static String strategy(Intent i,Effort e,Confidence c,boolean local,boolean clarify,boolean verify,int h){
        if(clarify)return "resolve_ambiguity_before_committing";
        if(local && e==Effort.MICRO)return "direct_local_response";
        if(h>1)return verify?"compare_hypotheses_then_verify":"compare_hypotheses_then_answer";
        if(verify)return "understand_then_check_then_answer";
        return "understand_goal_then_answer";
    }
    private static String key(String p,String c,boolean x,boolean a){return p+"|"+(c==null?"":c.hashCode())+"|"+x+"|"+a;}
    private static String normalize(String s){return s==null?"":s.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+"," ");}
    private static boolean has(String p,String x){return p.contains(x);}
    private static boolean hasAny(String p,String... xs){for(String x:xs)if(has(p,x))return true;return false;}
}
