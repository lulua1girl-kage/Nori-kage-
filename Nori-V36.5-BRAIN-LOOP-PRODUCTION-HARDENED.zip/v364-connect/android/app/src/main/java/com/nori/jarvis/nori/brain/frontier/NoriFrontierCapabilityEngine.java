package com.nori.jarvis.nori.brain.frontier;

import java.util.*;
import java.util.concurrent.*;

/**
 * Step 17 frontier brain: a larger capability graph with fast local routing.
 * Capability contracts are provider-agnostic; they do not copy proprietary model code.
 * The engine deliberately keeps simple requests on a cached O(1)-ish fast path.
 */
public final class NoriFrontierCapabilityEngine {
    public enum Capability {
        MULTIMODAL_VISION,
        DEEP_RESEARCH,
        SOURCE_GROUNDED_NOTEBOOK,
        COMPUTER_USE,
        AGENT_ORCHESTRATION,
        PROJECT_WORKSPACES,
        ARTIFACTS,
        LONG_TERM_MEMORY,
        PERSONALIZATION,
        CODING_AGENT,
        SCHEDULED_TASKS,
        CONNECTORS_MCP,
        REAL_TIME_VOICE,
        SCREEN_CONTEXT,
        IMAGE_CREATION,
        LONG_CONTEXT,
        STRUCTURED_TOOL_USE,
        WEB_FRESHNESS,
        MODEL_ROUTING,
        SELF_EVALUATION,
        TASK_DECOMPOSITION,
        PLAN_REPAIR,
        PLAN_BRANCHING,
        DEPENDENCY_GRAPH,
        CRITICAL_PATH,
        DEADLINE_REASONING,
        TIME_ESTIMATION,
        RESOURCE_AWARENESS,
        PARALLEL_EXECUTION,
        SEQUENTIAL_EXECUTION,
        ROLLBACK_PLANS,
        DRY_RUN,
        CONFIRMATION_GATES,
        PERMISSION_AWARENESS,
        PRIVACY_ROUTING,
        SENSITIVE_DATA_REDACTION,
        AUDIT_TRAIL,
        PROVENANCE,
        CITATION_CHECK,
        CONTRADICTION_CHECK,
        FACT_INFERENCE_SEPARATION,
        UNCERTAINTY_ESTIMATION,
        EVIDENCE_SCORING,
        SOURCE_DEDUPLICATION,
        SOURCE_DIVERSITY,
        RECENCY_FILTER,
        AUTHORITY_FILTER,
        CLAIM_EXTRACTION,
        CLAIM_COMPARISON,
        QUESTION_GENERATION,
        ANSWER_COMPRESSION,
        CONTEXT_COMPRESSION,
        MEMORY_SUMMARIZATION,
        MEMORY_CONFLICT_RESOLUTION,
        MEMORY_RECENCY,
        MEMORY_CONFIDENCE,
        MEMORY_FORGETTING,
        SESSION_CONTINUITY,
        CROSS_SESSION_PROJECTS,
        USER_GOAL_MODEL,
        STUDY_PLAN_GENERATION,
        ADAPTIVE_QUIZZING,
        SPACED_REPETITION,
        RETRIEVAL_PRACTICE,
        ERROR_NOTEBOOK,
        MISCONCEPTION_DETECTION,
        CONCEPT_GRAPH,
        PREREQUISITE_REASONING,
        EXAM_MODE,
        ASSIGNMENT_BREAKDOWN,
        RUBRIC_ALIGNMENT,
        PROGRESS_MODELING,
        MASTERY_ESTIMATION,
        WEAKNESS_DETECTION,
        STRENGTH_DETECTION,
        LEARNING_PACE,
        FATIGUE_AWARE_STUDY,
        RECOVERY_AWARE_PLANNING,
        ACADEMIC_INTEGRITY,
        EXPLANATION_ADAPTATION,
        DOCUMENT_INGESTION,
        DOCUMENT_CHUNKING,
        DOCUMENT_RETRIEVAL,
        DOCUMENT_COMPARISON,
        TABLE_EXTRACTION,
        FORM_EXTRACTION,
        PDF_QA,
        SOURCE_NOTES,
        KNOWLEDGE_BASES,
        FILE_CHANGE_TRACKING,
        VERSIONED_CONTEXT,
        ARTIFACT_DIFF,
        ARTIFACT_VALIDATION,
        EXPORT_PLANNING,
        TEMPLATE_FILLING,
        REPORT_GENERATION,
        SLIDE_PLANNING,
        SPREADSHEET_REASONING,
        DATA_SUMMARIZATION,
        CODE_SEARCH,
        CODE_EXPLANATION,
        BUG_TRIAGE,
        TEST_GENERATION,
        TEST_ANALYSIS,
        REFACTOR_PLANNING,
        DEPENDENCY_AUDIT,
        API_CONTRACT_CHECK,
        BUILD_DIAGNOSTICS,
        PERFORMANCE_PROFILING,
        REGRESSION_DETECTION,
        PATCH_REVIEW,
        CHANGE_IMPACT,
        ROLLBACK_SELECTION,
        RELEASE_GATING,
        STATIC_ANALYSIS,
        SECURITY_REVIEW,
        CONFIG_VALIDATION,
        CODE_GENERATION,
        REPOSITORY_NAVIGATION,
        VOICE_INTENT,
        VOICE_CONTEXT,
        VOICE_BARGE_IN,
        SPEECH_STATE,
        VOICE_SUMMARIZATION,
        COMMAND_DISAMBIGUATION,
        NATURAL_LANGUAGE_NAVIGATION,
        SCREEN_SEMANTICS,
        FOREGROUND_CONTEXT,
        APP_INTENT_ROUTING,
        NOTIFICATION_REASONING,
        CALENDAR_REASONING,
        REMINDER_REASONING,
        FOCUS_REASONING,
        DISTRACTION_DETECTION,
        HUMAN_CONTEXT,
        SUPPORT_MODE_SELECTION,
        NON_INTRUSIVE_CONTEXT,
        HUMAN_OVERRIDE,
        AUTONOMY_SUPPORT,
        RESEARCH_QUERY_PLANNING,
        RESEARCH_PARALLELISM,
        RESEARCH_SYNTHESIS,
        RESEARCH_GAPS,
        RESEARCH_STOPPING,
        RESEARCH_UPDATE,
        WEB_RESULT_FILTERING,
        WEB_RESULT_CLUSTERING,
        SEARCH_QUERY_VARIANTS,
        SOURCE_CONFLICT_MAP,
        EVIDENCE_TABLES,
        RESEARCH_BRIEF,
        RESEARCH_TIMELINE,
        TREND_DETECTION,
        CHANGE_DETECTION,
        KNOWLEDGE_REFRESH,
        CURRENTNESS_GUARD,
        SEARCH_CACHE,
        RESEARCH_CACHE_INVALIDATION,
        RESEARCH_VERIFICATION,
        LOCAL_FIRST,
        OFFLINE_FALLBACK,
        FAST_PATH,
        HOT_REQUEST_CACHE,
        PLAN_CACHE,
        CAPABILITY_CACHE,
        PROVIDER_COOLDOWN,
        PROVIDER_HEALTH,
        PROVIDER_SELECTION,
        MODEL_ESCALATION,
        MODEL_DEESCALATION,
        TOKEN_BUDGETING,
        LATENCY_BUDGET,
        CONCURRENCY_BUDGET,
        MEMORY_BUDGET,
        CPU_BUDGET,
        NETWORK_BUDGET,
        LOW_RAM_MODE,
        THERMAL_AWARENESS,
        BATTERY_AWARENESS,
        SELF_CRITIQUE,
        SECOND_PASS_VERIFICATION,
        ACTION_RESULT_CHECK,
        POSTCONDITION_CHECK,
        ERROR_CLASSIFICATION,
        RECOVERY_STRATEGY,
        RETRY_POLICY,
        IDEMPOTENCY,
        SAFE_CANCELLATION,
        PARTIAL_RESULT_RECOVERY,
        DEGRADED_MODE,
        GRACEFUL_TIMEOUT,
        USER_VISIBLE_STATUS,
        PROGRESS_ESTIMATION,
        TASK_RESUME,
        BACKGROUND_QUEUE,
        WORK_PRIORITIZATION,
        VALUE_OF_INFORMATION,
        DECISION_MEMO,
        LEARNING_FROM_FEEDBACK,
        CAPABILITY_TELEMETRY
    }

    public enum WorkClass { CHAT, STUDY, RESEARCH, CODE, DOCUMENT, VISION, VOICE, ACTION, PLANNING, CREATIVE, DATA, RECOVERY }
    public enum Priority { INSTANT, FAST, NORMAL, DEEP, CRITICAL }

    public static final class Plan {
        public final EnumSet<Capability> capabilities; public final WorkClass workClass; public final Priority priority;
        public final boolean parallelize, needsFreshWeb, needsUserConfirmation, privacySensitive;
        public final int estimatedLocalSteps; public final String strategy;
        public Plan(EnumSet<Capability> c, WorkClass w, Priority p, boolean par, boolean fresh, boolean confirm, boolean privateData, int steps, String strategy){
            capabilities=c.clone(); workClass=w; priority=p; parallelize=par; needsFreshWeb=fresh; needsUserConfirmation=confirm; privacySensitive=privateData; estimatedLocalSteps=steps; this.strategy=strategy;
        }
    }

    private final EnumSet<Capability> enabled=EnumSet.allOf(Capability.class);
    private final ConcurrentHashMap<String, Plan> planCache=new ConcurrentHashMap<>();
    private final ArrayDeque<String> cacheOrder=new ArrayDeque<>();
    private static final int MAX_CACHE=128;

    public synchronized void setEnabled(Capability c, boolean value){ if(c==null)return; if(value)enabled.add(c);else enabled.remove(c); planCache.clear(); cacheOrder.clear(); }
    public synchronized boolean isEnabled(Capability c){return enabled.contains(c);}
    public synchronized EnumSet<Capability> enabledCapabilities(){return enabled.clone();}

    public Plan plan(String prompt, boolean externalAvailable, boolean userInitiatedAction){
        String p=normalize(prompt);
        String key=fastKey(p,externalAvailable,userInitiatedAction);
        Plan cached=planCache.get(key); if(cached!=null)return cached;
        WorkClass wc=classify(p); Priority pri=priority(p,wc); EnumSet<Capability> c=EnumSet.noneOf(Capability.class);
        boolean fresh=has(p,"today","latest","current","recent","news","2026","update");
        boolean privateData=has(p,"private","sensitive","personal","password","medical","family","secret");
        add(c,Capability.LOCAL_FIRST,true); add(c,Capability.FAST_PATH,true); add(c,Capability.PERSONALIZATION,true);
        add(c,Capability.LONG_CONTEXT,p.length()>4000); add(c,Capability.WEB_FRESHNESS,fresh); add(c,Capability.DEEP_RESEARCH,has(p,"research","compare sources","literature","evidence","investigate"));
        add(c,Capability.SOURCE_GROUNDED_NOTEBOOK,has(p,"pdf","notes","study guide","flashcards","quiz","documents","notebook"));
        add(c,Capability.MULTIMODAL_VISION,has(p,"image","photo","screenshot","picture","what is this")); add(c,Capability.SCREEN_CONTEXT,has(p,"screen","current app","looking at"));
        add(c,Capability.COMPUTER_USE,has(p,"click","navigate","open","fill","computer","tap")); add(c,Capability.CODING_AGENT,has(p,"code","bug","compile","refactor","repository","github"));
        add(c,Capability.PROJECT_WORKSPACES,has(p,"project","workspace","continue where","milestone")); add(c,Capability.ARTIFACTS,has(p,"file","dashboard","table","artifact","report","document"));
        add(c,Capability.SCHEDULED_TASKS,has(p,"remind","schedule","every day","tomorrow","recurring")); add(c,Capability.CONNECTORS_MCP,has(p,"connect","calendar","github","drive","integration"));
        add(c,Capability.REAL_TIME_VOICE,has(p,"voice","speak","listen","say")); add(c,Capability.IMAGE_CREATION,has(p,"draw","generate image","create picture","visualize"));
        add(c,Capability.STRUCTURED_TOOL_USE,userInitiatedAction); add(c,Capability.AGENT_ORCHESTRATION,has(p,"handle all","end to end","step by step","in parallel","delegate"));
        add(c,Capability.SELF_EVALUATION,wc!=WorkClass.CHAT || fresh); add(c,Capability.CONFIRMATION_GATES,userInitiatedAction); add(c,Capability.PRIVACY_ROUTING,privateData);
        // Deep routing: expand the capability graph only when the request actually warrants it.
        if(wc==WorkClass.RESEARCH){ addMany(c, Capability.RESEARCH_QUERY_PLANNING,Capability.RESEARCH_PARALLELISM,Capability.RESEARCH_SYNTHESIS,Capability.RESEARCH_GAPS,Capability.RESEARCH_STOPPING,Capability.SOURCE_DEDUPLICATION,Capability.SOURCE_DIVERSITY,Capability.CITATION_CHECK,Capability.PROVENANCE); }
        if(wc==WorkClass.STUDY){ addMany(c,Capability.STUDY_PLAN_GENERATION,Capability.ADAPTIVE_QUIZZING,Capability.SPACED_REPETITION,Capability.RETRIEVAL_PRACTICE,Capability.ERROR_NOTEBOOK,Capability.MISCONCEPTION_DETECTION,Capability.MASTERY_ESTIMATION,Capability.EXPLANATION_ADAPTATION,Capability.FATIGUE_AWARE_STUDY); }
        if(wc==WorkClass.CODE){ addMany(c,Capability.CODE_SEARCH,Capability.BUG_TRIAGE,Capability.TEST_GENERATION,Capability.TEST_ANALYSIS,Capability.REFACTOR_PLANNING,Capability.BUILD_DIAGNOSTICS,Capability.PERFORMANCE_PROFILING,Capability.REGRESSION_DETECTION,Capability.SECURITY_REVIEW); }
        if(wc==WorkClass.DOCUMENT){ addMany(c,Capability.DOCUMENT_INGESTION,Capability.DOCUMENT_RETRIEVAL,Capability.DOCUMENT_COMPARISON,Capability.PDF_QA,Capability.TABLE_EXTRACTION,Capability.REPORT_GENERATION,Capability.ARTIFACT_VALIDATION); }
        if(wc==WorkClass.VOICE){ addMany(c,Capability.VOICE_INTENT,Capability.VOICE_CONTEXT,Capability.VOICE_BARGE_IN,Capability.COMMAND_DISAMBIGUATION,Capability.NATURAL_LANGUAGE_NAVIGATION); }
        if(wc==WorkClass.ACTION){ addMany(c,Capability.DRY_RUN,Capability.ROLLBACK_PLANS,Capability.IDEMPOTENCY,Capability.POSTCONDITION_CHECK,Capability.ACTION_RESULT_CHECK,Capability.SAFE_CANCELLATION); }
        if(wc==WorkClass.PLANNING){ addMany(c,Capability.TASK_DECOMPOSITION,Capability.PLAN_REPAIR,Capability.PLAN_BRANCHING,Capability.DEPENDENCY_GRAPH,Capability.CRITICAL_PATH,Capability.DEADLINE_REASONING,Capability.TIME_ESTIMATION); }
        if(pri==Priority.CRITICAL){ addMany(c,Capability.SECOND_PASS_VERIFICATION,Capability.RECOVERY_STRATEGY,Capability.AUDIT_TRAIL,Capability.USER_VISIBLE_STATUS); }
        add(c,Capability.MODEL_ROUTING,externalAvailable); add(c,Capability.PROVIDER_HEALTH,externalAvailable); add(c,Capability.PROVIDER_SELECTION,externalAvailable);
        add(c,Capability.HOT_REQUEST_CACHE,true); add(c,Capability.PLAN_CACHE,true); add(c,Capability.TOKEN_BUDGETING,true); add(c,Capability.LATENCY_BUDGET,true); add(c,Capability.LOW_RAM_MODE,true);
        boolean parallel=externalAvailable && (c.size()>=7 || c.contains(Capability.DEEP_RESEARCH) || c.contains(Capability.AGENT_ORCHESTRATION));
        boolean confirm=userInitiatedAction && (c.contains(Capability.COMPUTER_USE)||c.contains(Capability.STRUCTURED_TOOL_USE));
        int steps=Math.max(1,Math.min(16,1+c.size()/6));
        String strategy=parallel?"fast_local_preflight_then_bounded_parallel_fanout_then_verify":"fast_local_cached_path_then_targeted_capability";
        Plan out=new Plan(c,wc,pri,parallel,fresh,confirm,privateData,steps,strategy); putCache(key,out); return out;
    }

    public int capabilityCount(){return Capability.values().length;}
    public int cachedPlanCount(){return planCache.size();}

    private synchronized void putCache(String key,Plan p){ if(planCache.containsKey(key))return; if(planCache.size()>=MAX_CACHE){String old=cacheOrder.pollFirst(); if(old!=null)planCache.remove(old);} planCache.put(key,p); cacheOrder.addLast(key); }
    private String fastKey(String p,boolean ext,boolean action){return Integer.toHexString(p.hashCode())+":"+(ext?1:0)+":"+(action?1:0);}
    private String normalize(String s){return s==null?"":s.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+"," ");}
    private void add(EnumSet<Capability>s,Capability c,boolean cond){if(cond&&enabled.contains(c))s.add(c);}
    private void addMany(EnumSet<Capability>s,Capability...cs){for(Capability c:cs)add(s,c,true);}
    private boolean has(String p,String...xs){for(String x:xs)if(p.contains(x))return true;return false;}
    private WorkClass classify(String p){if(has(p,"research","sources","evidence","investigate"))return WorkClass.RESEARCH;if(has(p,"code","bug","compile","github","refactor"))return WorkClass.CODE;if(has(p,"image","photo","screenshot","screen"))return WorkClass.VISION;if(has(p,"voice","speak","listen"))return WorkClass.VOICE;if(has(p,"study","exam","homework","subject","quiz"))return WorkClass.STUDY;if(has(p,"document","pdf","report","file"))return WorkClass.DOCUMENT;if(has(p,"data","csv","spreadsheet","dataset"))return WorkClass.DATA;if(has(p,"plan","schedule","goal"))return WorkClass.PLANNING;if(has(p,"draw","generate","creative"))return WorkClass.CREATIVE;if(has(p,"open","save","create","change","execute","click"))return WorkClass.ACTION;return WorkClass.CHAT;}
    private Priority priority(String p,WorkClass w){if(has(p,"urgent","critical","safety"))return Priority.CRITICAL;if(w==WorkClass.CHAT&&p.length()<80)return Priority.INSTANT;if(w==WorkClass.VISION||w==WorkClass.VOICE||w==WorkClass.ACTION)return Priority.FAST;if(w==WorkClass.RESEARCH||w==WorkClass.CODE)return Priority.DEEP;return Priority.NORMAL;}
}
