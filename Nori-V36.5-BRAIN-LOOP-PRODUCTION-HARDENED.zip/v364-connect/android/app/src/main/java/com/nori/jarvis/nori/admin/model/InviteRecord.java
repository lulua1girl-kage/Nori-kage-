package com.nori.jarvis.nori.admin.model;

public final class InviteRecord {
    public final String email;
    public final AdminRole role;
    public final long createdAt;
    public final boolean active;

    public InviteRecord(String email, AdminRole role, long createdAt, boolean active) {
        this.email = email;
        this.role = role;
        this.createdAt = createdAt;
        this.active = active;
    }
}
