package com.nori.jarvis.nori.evolution;

import java.util.*;

/** Step 42: bounded failure classification, alternate routing and learning hooks. */
public final class NoriFailureRecoveryEngine {
    public enum Type { NETWORK, PERMISSION, TIMEOUT, VALIDATION, TOOL, PROVIDER, UNKNOWN }
    public static final class Plan { public final Type type; public final boolean retry; public final boolean alternate; public final boolean userAction; public final List<String> steps; Plan(Type t,boolean r,boolean a,boolean u,List<String>s){type=t;retry=r;alternate=a;userAction=u;steps=Collections.unmodifiableList(new ArrayList<>(s));} }
    public Plan plan(String error,boolean idempotent,boolean offlineAvailable){String x=error==null?"":error.toLowerCase(Locale.ROOT);Type t=x.contains("network")||x.contains("offline")?Type.NETWORK:x.contains("permission")||x.contains("denied")?Type.PERMISSION:x.contains("timeout")?Type.TIMEOUT:x.contains("invalid")||x.contains("validation")?Type.VALIDATION:x.contains("provider")?Type.PROVIDER:x.contains("tool")?Type.TOOL:Type.UNKNOWN;boolean retry=idempotent&&(t==Type.NETWORK||t==Type.TIMEOUT||t==Type.PROVIDER);boolean alt=offlineAvailable&&t==Type.NETWORK;boolean user=t==Type.PERMISSION||t==Type.VALIDATION;List<String>s=new ArrayList<>();if(retry)s.add("retry_once_with_bounded_backoff");if(alt)s.add("use_offline_or_local_route");if(user)s.add("request_user_correction_or_permission");s.add("preserve_prior_state_and report the exact failure");return new Plan(t,retry,alt,user,s);}
}
