package com.nori.jarvis.nori.actions;

public interface PermissionChecker {
    boolean isGranted(String permission);
}
