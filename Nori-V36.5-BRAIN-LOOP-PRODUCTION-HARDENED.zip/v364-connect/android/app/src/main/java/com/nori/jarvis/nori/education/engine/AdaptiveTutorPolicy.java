package com.nori.jarvis.nori.education.engine;

import com.nori.jarvis.nori.education.model.*;

public final class AdaptiveTutorPolicy {
    public TutoringPolicy choose(String subject, boolean conceptual, boolean calculationHeavy, boolean struggling, boolean confident){
        if(struggling&&conceptual) return new TutoringPolicy(TutoringPolicy.Depth.DEEP,TutoringPolicy.Help.GUIDED,true,"conceptual gap needs explanation plus guided application");
        if(calculationHeavy) return new TutoringPolicy(TutoringPolicy.Depth.STANDARD,TutoringPolicy.Help.HINT_FIRST,true,"calculation work benefits from solving before revealing the answer");
        if(confident) return new TutoringPolicy(TutoringPolicy.Depth.FAST,TutoringPolicy.Help.HINT_FIRST,false,"avoid unnecessary explanation when evidence shows competence");
        return new TutoringPolicy(TutoringPolicy.Depth.STANDARD,TutoringPolicy.Help.GUIDED,true,"balanced support while evidence is limited");
    }
}
