package com.nori.jarvis.nori.android.notification;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;

/** Native notification boundary. Does not request permission or post silently on its own. */
public final class NoriNotificationService {
    public static final String CHANNEL_REMINDERS = "nori.reminders";
    public static final String CHANNEL_SYSTEM = "nori.system";
    private final Context context;
    private final NotificationManager manager;

    public NoriNotificationService(Context context) {
        this.context = context.getApplicationContext();
        this.manager = (NotificationManager) this.context.getSystemService(Context.NOTIFICATION_SERVICE);
        ensureChannels();
    }
    public void ensureChannels() {
        if (Build.VERSION.SDK_INT < 26) return;
        manager.createNotificationChannel(new NotificationChannel(CHANNEL_REMINDERS, "Nori Reminders", NotificationManager.IMPORTANCE_DEFAULT));
        manager.createNotificationChannel(new NotificationChannel(CHANNEL_SYSTEM, "Nori System", NotificationManager.IMPORTANCE_LOW));
    }
    public boolean canPost() {
        return Build.VERSION.SDK_INT < 33 || manager.areNotificationsEnabled();
    }
    public void post(int id, String channelId, String title, String text, Notification.Builder builder) {
        if (!canPost()) throw new IllegalStateException("notifications_not_allowed");
        Notification notification = builder.setContentTitle(title).setContentText(text).setAutoCancel(true).build();
        manager.notify(id, notification);
    }
    public void cancel(int id) { manager.cancel(id); }
}
