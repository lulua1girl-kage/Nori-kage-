package com.nori.jarvis.nori.youtube;

import com.nori.jarvis.nori.web.NoriLiveWebRetrieval;
import java.util.*;

/** Public YouTube learning connector. It does not access a user's account. */
public final class NoriYouTubeLearningConnector {
    public static final class Video { public final String id,title,channel,published,url; public final boolean captions; public Video(String i,String t,String c,String p,boolean cap){id=i;title=t;channel=c;published=p;captions=cap;url="https://www.youtube.com/watch?v="+i;} }
    public static final class LearningItem { public final Video video; public final String status; public LearningItem(Video v,String s){video=v;status=s;} }
    private final NoriLiveWebRetrieval web;
    public NoriYouTubeLearningConnector(NoriLiveWebRetrieval w){web=w;}
    public String searchEndpoint(String query){return "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&videoCaption=closedCaption&q="+encode(query);}
    public String videoEndpoint(String id){return "https://www.googleapis.com/youtube/v3/videos?part=snippet,contentDetails&id="+encode(id);}
    public String explainPolicy(){return "Public educational discovery only. Nori ranks sources by evidence, recency, clarity and corroboration; a YouTube video is not treated as truth merely because it exists.";}
    private String encode(String x){return java.net.URLEncoder.encode(x==null?"":x,java.nio.charset.StandardCharsets.UTF_8);}
}
