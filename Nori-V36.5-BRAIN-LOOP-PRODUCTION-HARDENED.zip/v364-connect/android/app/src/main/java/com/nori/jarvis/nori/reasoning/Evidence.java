package com.nori.jarvis.nori.reasoning;

import java.util.Objects;

/** Structured evidence item. Facts are kept separate from interpretations. */
public final class Evidence {
    public enum Kind { FACT, CONTEXT, INFERENCE, ASSUMPTION }
    public enum Strength { STRONG, MODERATE, WEAK, UNKNOWN }

    public final String source;
    public final String statement;
    public final Kind kind;
    public final Strength strength;

    public Evidence(String source, String statement, Kind kind, Strength strength) {
        this.source = source == null ? "unknown" : source;
        this.statement = Objects.requireNonNull(statement, "statement");
        this.kind = kind == null ? Kind.ASSUMPTION : kind;
        this.strength = strength == null ? Strength.UNKNOWN : strength;
    }
}
