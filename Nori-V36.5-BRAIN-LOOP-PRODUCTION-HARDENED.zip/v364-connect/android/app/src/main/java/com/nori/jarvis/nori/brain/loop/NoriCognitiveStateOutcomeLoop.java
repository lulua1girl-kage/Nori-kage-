package com.nori.jarvis.nori.brain.loop;

import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.brain.cognition.NoriCognitiveEngine;
import com.nori.jarvis.nori.brain.intervention.NoriInterventionEngine;
import com.nori.jarvis.nori.brain.learning.NoriStudentDevelopment;
import com.nori.jarvis.nori.brain.learning.NoriLearningLoop;
import com.nori.jarvis.nori.state.NoriState;
import java.time.Instant;
import java.util.*;

/**
 * Central orchestration loop. It does not replace existing engines; it gives
 * them one shared lifecycle: observe -> reason -> decide -> act -> outcome -> learn.
 * No hidden chain-of-thought is exposed and no automatic self-modification occurs.
 */
public final class NoriCognitiveStateOutcomeLoop {
    public enum Phase { OBSERVE, REASON, DECIDE, INTERVENE, OUTCOME, LEARN, DEVELOP }
    public enum Outcome { POSITIVE, NEUTRAL, NEGATIVE, UNKNOWN }

    public static final class Event {
        public final String id, type, source, detail, relatedAction, relatedGoal;
        public final Instant at; public final double confidence; public final boolean userProvided;
        public Event(String id,String type,String source,String detail,String action,String goal,double confidence,boolean userProvided){
            this.id=safe(id);this.type=safe(type);this.source=safe(source);this.detail=safe(detail);this.relatedAction=safe(action);this.relatedGoal=safe(goal);this.confidence=clamp(confidence);this.userProvided=userProvided;this.at=Instant.now();
        }
    }
    public static final class ActionRecord {
        public final String id, action, goal; public final Instant at; public final double expectedUsefulness; public final boolean userRequested;
        ActionRecord(String i,String a,String g,double u,boolean r){id=i;action=a;goal=g;at=Instant.now();expectedUsefulness=clamp(u);userRequested=r;}
    }
    public static final class OutcomeRecord {
        public final String actionId, action, goal; public final Outcome outcome; public final double value; public final String evidence; public final Instant at;
        OutcomeRecord(String id,String a,String g,Outcome o,double v,String e){actionId=safe(id);action=safe(a);goal=safe(g);outcome=o==null?Outcome.UNKNOWN:o;value=clamp(v);evidence=safe(e);at=Instant.now();}
    }
    public static final class Cycle {
        public final Phase phase; public final NoriState state; public final NoriCognitiveEngine.ThoughtState thought;
        public final String decision; public final String intervention; public final double confidence; public final List<String> reasoningStatus;
        Cycle(Phase p,NoriState s,NoriCognitiveEngine.ThoughtState t,String d,String i,double c,List<String> r){phase=p;state=s;thought=t;decision=safe(d);intervention=safe(i);confidence=clamp(c);reasoningStatus=Collections.unmodifiableList(new ArrayList<>(r));}
    }

    private final NoriBrain brain; private final Deque<Event> events=new ArrayDeque<>(); private final Map<String,ActionRecord> actions=new LinkedHashMap<>(); private final List<OutcomeRecord> outcomes=new ArrayList<>();
    public NoriCognitiveStateOutcomeLoop(NoriBrain b){brain=Objects.requireNonNull(b,"brain");}

    public synchronized void observe(String type,String source,String detail,String goal,double confidence,boolean userProvided){
        events.addLast(new Event("e-"+events.size()+"-"+Integer.toHexString(Objects.hash(type,detail,System.nanoTime())),type,source,detail,"",goal,confidence,userProvided)); trim();
    }

    public synchronized Cycle run(String request, String goal, boolean userRequested){
        NoriState state=brain.getStateEngine().snapshot();
        NoriCognitiveEngine.ThoughtState thought=brain.think(request,state);
        List<String> status=new ArrayList<>(); status.add("observed current unified state"); status.add("classified intent and uncertainty");
        if(thought.needsEvidence)status.add("evidence threshold required"); if(thought.needsTool)status.add("tool capability may be required");
        String decision=thought.needsClarification?"CLARIFY":thought.answerShape.name();
        NoriInterventionEngine.Signal signal=signalFrom(state,thought,userRequested);
        NoriInterventionEngine.Proposal p=brain.getInterventionEngine().decide(signal,"",Collections.emptyList(),false);
        String intervention=p.intervene?p.action.name():"NONE";
        if(!state.academic.mistakePatterns.isEmpty()) status.add("academic patterns wired: "+state.academic.mistakePatterns.size());
        if(!state.academic.recommendedInterventions.isEmpty()) status.add("interventions wired: "+String.join(",",state.academic.recommendedInterventions));
        try { com.nori.jarvis.nori.brain.learning.NoriLearningLoop.LongitudinalReport lr=brain.evaluateLearning(); status.add("learning evaluated: trend="+lr.overallTrend+" strategy="+lr.nextStrategy); } catch(Exception ignored) {}
        status.add("constitution remains authoritative"); status.add("selected minimal sufficient response path");
        return new Cycle(Phase.DECIDE,state,thought,decision,intervention,thought.confidence==NoriCognitiveEngine.Confidence.HIGH?.88:thought.confidence==NoriCognitiveEngine.Confidence.MODERATE?.68:.42,status);
    }

    public synchronized String beginAction(String action,String goal,double expectedUsefulness,boolean userRequested){
        String id="a-"+Long.toHexString(System.nanoTime()); actions.put(id,new ActionRecord(id,action,goal,expectedUsefulness,userRequested)); trim(); return id;
    }
    public synchronized void recordOutcome(String actionId,Outcome outcome,double value,String evidence){
        ActionRecord a=actions.get(actionId); if(a==null)return; OutcomeRecord o=new OutcomeRecord(actionId,a.action,a.goal,outcome,value,evidence); outcomes.add(o); if(outcomes.size()>500)outcomes.remove(0);
        // Feed a bounded, explicit learning signal into the existing evolution engine.
        try {
            com.nori.jarvis.nori.evolution.NoriLearningEvolutionEngine.Outcome eo = outcome==Outcome.POSITIVE?com.nori.jarvis.nori.evolution.NoriLearningEvolutionEngine.Outcome.POSITIVE:outcome==Outcome.NEGATIVE?com.nori.jarvis.nori.evolution.NoriLearningEvolutionEngine.Outcome.NEGATIVE:outcome==Outcome.NEUTRAL?com.nori.jarvis.nori.evolution.NoriLearningEvolutionEngine.Outcome.NEUTRAL:com.nori.jarvis.nori.evolution.NoriLearningEvolutionEngine.Outcome.UNKNOWN;
            String exp="action:"+a.action; brain.getLearningEvolutionEngine().registerExperiment(new com.nori.jarvis.nori.evolution.NoriLearningEvolutionEngine.Experiment(exp,"whether action helps goal",a.action,"outcome",3));
            brain.getLearningEvolutionEngine().recordOutcome(new com.nori.jarvis.nori.evolution.NoriLearningEvolutionEngine.Observation(exp,eo,value,evidence));
        } catch(Exception ignored) { }
    }
    public synchronized List<Event> recentEvents(int limit){List<Event> x=new ArrayList<>(events);Collections.reverse(x);return Collections.unmodifiableList(x.subList(0,Math.min(Math.max(0,limit),x.size())));}
    public synchronized List<OutcomeRecord> outcomes(){return Collections.unmodifiableList(new ArrayList<>(outcomes));}

    private NoriInterventionEngine.Signal signalFrom(NoriState s,NoriCognitiveEngine.ThoughtState t,boolean requested){
        double need=t.needsTool||t.needsEvidence?.72:.35; double capacity=s.study.status==NoriState.StudyStatus.STUDYING||s.study.status==NoriState.StudyStatus.REVIEWING?.7:s.situation.availability==NoriState.Availability.BUSY?.35:.75; double urgency=s.exam.status==NoriState.ExamStatus.ACTIVE?1:s.exam.status==NoriState.ExamStatus.UPCOMING?.72:.35; double distraction=s.deviceAppEvidence.appCategory.toLowerCase(Locale.ROOT).matches(".*(social|video|feed|entertainment).*")?.75:.1; double availability=s.situation.availability==NoriState.Availability.AVAILABLE?.9:s.situation.availability==NoriState.Availability.BUSY?.35:.55; return new NoriInterventionEngine.Signal(need,capacity,urgency,distraction,availability,requested);
    }
    private void trim(){while(events.size()>300)events.removeFirst();while(actions.size()>200){String k=actions.keySet().iterator().next();actions.remove(k);}}
    private static String safe(String s){return s==null?"":s.trim();} private static double clamp(double x){return Double.isFinite(x)?Math.max(0,Math.min(1,x)):0;}
}
