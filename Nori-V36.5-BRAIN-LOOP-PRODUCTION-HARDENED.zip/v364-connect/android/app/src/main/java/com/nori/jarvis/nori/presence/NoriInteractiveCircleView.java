package com.nori.jarvis.nori.presence;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

/** Lightweight JARVIS-inspired presence surface. No microphone/background work happens here. */
public final class NoriInteractiveCircleView extends View {
    public enum State { IDLE, LISTENING, THINKING, SPEAKING, ALARM, ERROR }
    private final Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); private State state=State.IDLE; private float level=.35f;
    public NoriInteractiveCircleView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);}
    public void setState(State s){state=s==null?State.IDLE:s;invalidate();}
    public void setLevel(float v){level=Math.max(0,Math.min(1,v));invalidate();}
    @Override protected void onDraw(Canvas c){
        super.onDraw(c); float cx=getWidth()/2f, cy=getHeight()/2f, r=Math.min(getWidth(),getHeight())*.22f;
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(0xff306761);c.drawCircle(cx,cy,r*1.75f,p);p.setStrokeWidth(1);c.drawCircle(cx,cy,r*2.15f,p);
        p.setColor(0x55306761);p.setStrokeWidth(2);RectF box=new RectF(cx-r*2.15f,cy-r*2.15f,cx+r*2.15f,cy+r*2.15f);c.drawArc(box,-35,120,false,p);c.drawArc(box,145,100,false,p);
        p.setStyle(Paint.Style.FILL);p.setColor(0xfff2f2f2);c.drawCircle(cx,cy,r*(1f+level*.08f),p);
        p.setColor(state==State.ERROR?0xffd85b5b:state==State.ALARM?0xffe59a45:0xff306761);c.drawCircle(cx,cy,r*.62f,p);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(0xfff2f2f2);c.drawCircle(cx,cy,r*.42f,p);
        p.setStyle(Paint.Style.FILL);p.setTextAlign(Paint.Align.CENTER);p.setTextSize(Math.max(10,getWidth()*.035f));p.setColor(0xfff2f2f2);c.drawText(state.name,cx,cy+r*2.65f,p);
    }
}
