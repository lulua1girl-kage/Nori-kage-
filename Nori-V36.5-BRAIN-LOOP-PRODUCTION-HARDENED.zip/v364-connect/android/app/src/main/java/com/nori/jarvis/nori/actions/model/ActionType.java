package com.nori.jarvis.nori.actions.model;

public enum ActionType { READ_ONLY, LOCAL_MUTATION, DEVICE, EXTERNAL }
