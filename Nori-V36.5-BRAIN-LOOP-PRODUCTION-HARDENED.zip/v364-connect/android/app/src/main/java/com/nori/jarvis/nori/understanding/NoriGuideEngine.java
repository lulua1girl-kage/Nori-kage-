package com.nori.jarvis.nori.understanding;

import java.util.*;

/** Manual guide engine. Guides describe actions; they do not perform them. */
public final class NoriGuideEngine {
    public enum Completion { USER_CONFIRMED, OBSERVABLE_RESULT, OPTIONAL, NOT_APPLICABLE }
    public static final class Step {
        public final int number; public final String instruction, expected, alternative, commonMistake;
        Step(int n,String i,String e,String a,String m){number=n;instruction=i;expected=e;alternative=a;commonMistake=m;}
    }
    public static final class Guide {
        public final String id,title,goal,start,rollback; public final List<Step> steps; public final Completion completion;
        Guide(String id,String title,String goal,String start,List<Step> steps,String rollback,Completion c){this.id=id;this.title=title;this.goal=goal;this.start=start;this.steps=Collections.unmodifiableList(new ArrayList<>(steps));this.rollback=rollback;this.completion=c;}
    }
    private final Map<String,Guide> guides=new LinkedHashMap<>();
    public NoriGuideEngine(){
        put("guide-first-run","Nori in 2 minutes","Understand the app without guessing","Start on HOME",
                new String[]{"Read the workspace map and identify HOME, MEET NORI and COMMAND.","Ask Nori what you want to accomplish; you do not need to know the feature name.","Choose EXPLAIN for information, GUIDE for manual steps, or ACTION when you want Nori to prepare an action.","When an action is consequential, review the preview before confirming."},"Return to HOME; no state is changed by reading this guide.",Completion.USER_CONFIRMED);
        put("guide-confusion","Find what you need","Recover from being lost in the app","Open MEET NORI",
                new String[]{"Tell Nori the goal in plain language, even if you do not know the feature name.","Nori searches its capability map and shows the closest features.","Choose one route or ask for a manual guide.","If Nori cannot perform the task, it should switch to a manual route instead of pretending."},"No action is performed by this guide.",Completion.USER_CONFIRMED);
        put("guide-actions","Understand an action before it happens","Know scope, permissions, confirmation and verification","Open COMMAND",
                new String[]{"State the result you want, not necessarily the exact technical action.","Nori builds a preview with steps, dependencies, permissions and risk.","Review what will change and what will not change.","Confirm only if the scope is correct.","Nori executes through the existing ActionEngine/permission boundary.","Nori verifies the intended result and reports uncertainty or failure."},"Cancel before confirmation when possible; otherwise use the supported rollback shown in the plan.",Completion.OBSERVABLE_RESULT);
        put("guide-voice","Use Nori by voice","Navigate or request an action without hunting through menus","Open MEET NORI and start a visible voice session",
                new String[]{"Start the explicit voice session.","Speak a goal such as 'open my study center' or 'help me set up tomorrow's study block'.","Nori interprets the request and shows the route or action preview.","Confirm consequential actions when prompted.","Stop the voice session when finished."},"Stop the foreground voice session; Nori does not silently keep listening.",Completion.OBSERVABLE_RESULT);
        put("guide-visual","Use visual context safely","Let Nori understand a camera/screen context without covert capture","Open MEET NORI and choose the visual-context entry point",
                new String[]{"Choose camera or screen context deliberately.","Grant the Android permission/consent if requested.","Capture only the context you want Nori to analyze.","Ask a specific question about the captured context.","End the visual session; the capture is not a background monitor."},"Cancel permission/capture and return to the conversation.",Completion.USER_CONFIRMED);
        put("guide-background","Why Nori does not just act","Understand the no-silent-action boundary","Open INTEGRITY",
                new String[]{"Nori may understand a useful next step without being authorized to perform it.","Direct actions require a fresh user request; consequential actions can require confirmation.","Scheduled actions are only eligible when the user deliberately configured them.","Camera, microphone and screen capture require explicit Android/user consent.","If Nori cannot act, it can explain or guide instead."},"No rollback is needed because this guide performs nothing.",Completion.USER_CONFIRMED);
        put("guide-navigation","Find a feature by voice","Reach any Nori workspace without memorizing menus","Open MEET NORI",
                new String[]{"Say 'where can I see my results?', 'open study center', or another natural request.","Nori maps the goal to a feature route.","Nori shows the destination before or while navigating depending on risk.","If there is ambiguity, Nori asks for the missing choice instead of guessing."},"Use the menu if voice navigation is unavailable.",Completion.OBSERVABLE_RESULT);
        put("guide-capabilities","Ask what Nori can do","See capability, limitation and permission boundaries","Open DIAGNOSTIC",
                new String[]{"Ask 'what can you do with my study library?' or 'can you do this for me?'.","Nori identifies relevant capabilities and required permissions.","Nori distinguishes available now, available with permission, provider-dependent and unavailable.","When unavailable, Nori offers the closest manual path."},"No state is changed by capability discovery.",Completion.USER_CONFIRMED);
        put("guide-fallback","When Nori cannot do it","Get a manual route instead of a fake success","Open MEET NORI",
                new String[]{"Ask Nori to perform the task.","If the capability is unavailable, Nori states the exact limitation.","Choose GUIDE to receive a semantic step-by-step route.","Ask Nori to take over one specific step only if a supported action exists.","Return to manual mode whenever you prefer."},"No action is performed unless separately requested.",Completion.USER_CONFIRMED);
        put("guide-interface","Switch Nori's interface","Change presentation without creating another Brain","Open PROFILE / SETTINGS",
                new String[]{"Open interface settings.","Choose Standard, Kage Avatar, Interactive Circle, Hybrid or Compact.","The same memory, state and Brain remain active.","Switching the interface does not authorize a new background process."},"Switch back to Standard.",Completion.OBSERVABLE_RESULT);
        put("guide-library","Connect a study library","Give Nori a specific folder rather than unrestricted file access","Open STUDY CENTER",
                new String[]{"Choose Study Library.","Select a folder using Android's user-controlled document picker.","Review what the library classifier will use.","Run a scan only when you request it.","Remove the folder grant from settings when you no longer want it connected."},"Remove the user-granted folder access.",Completion.USER_CONFIRMED);
        put("guide-research","Use Nori for research","Ask for current, source-grounded information","Open STUDY CENTER or MEET NORI",
                new String[]{"State the research question and desired depth.","Nori determines whether fresh external information is necessary.","When research is requested, Nori gathers and organizes sources, compares evidence and flags conflicts.","Nori separates verified/partially verified/unverified claims.","Use the evidence gaps to decide what still needs checking."},"Stop the research request; no recurring research runs are created unless deliberately scheduled.",Completion.OBSERVABLE_RESULT);
        put("guide-support","Reduce pressure without giving up control","Adjust the route when capacity is limited","Open RECOVER",
                new String[]{"Tell Nori the current capacity in plain language; disclosure of private causes is optional.","Nori identifies whether a lighter route, small start, recovery or normal plan fits.","Choose the proposed intervention or reject it.","Nori learns from the outcome without silently rewriting its constitution."},"Return to the normal plan when ready.",Completion.USER_CONFIRMED);
        put("guide-memory","Use memory deliberately","Recall, edit or avoid stored information without silent changes","Open MEET NORI or PROFILE",
                new String[]{"Ask what Nori remembers about the relevant topic.","Nori reports confidence and stale/conflict warnings where applicable.","Ask to edit or forget a specific item when the feature supports it.","Nori does not silently turn an inference into a permanent fact."},"No memory is changed merely by reading it.",Completion.USER_CONFIRMED);
        put("guide-focus","Use focus controls without punishment","Choose bounded focus rules that remain under user control","Open FOCUS",
                new String[]{"Select only the apps you want eligible for focus controls.","Set the protected window or focus session.","Nori classifies observed app context conservatively; evidence is not proof of intent.","Review the reason before changing a rule.","Use Human Override to stop or adjust the focus session."},"Stop the focus session or clear the selected apps.",Completion.USER_CONFIRMED);
        put("guide-scheduled-actions","Use deliberate scheduling","Allow only previously configured actions to run on schedule","Open CALENDAR",
                new String[]{"Create a specific scheduled action yourself.","Review the exact action, scope, time and expiration.","Save the schedule explicitly.","At execution time, Nori checks that authorization is still valid.","Expired or ambiguous authorization is not reused."},"Delete or disable the scheduled action.",Completion.OBSERVABLE_RESULT);
    }
    private void put(String id,String title,String goal,String start,String[] steps,String rollback,Completion completion){List<Step>s=new ArrayList<>();int n=1;for(String x:steps)s.add(new Step(n++,x,"Expected progress is visible in Nori.","Ask Nori for the manual route.","Do not assume a step succeeded just because a command was issued."));guides.put(id,new Guide(id,title,goal,start,s,rollback,completion));}
    public Guide get(String id){return guides.get(id);}
    public List<Guide> all(){return Collections.unmodifiableList(new ArrayList<>(guides.values()));}
}
