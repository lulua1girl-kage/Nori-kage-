package com.nori.jarvis;

import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.nori.jarvis.nori.identity.*;
import java.util.*;

/**
 * Registration/admission bridge. The client is never the final authority:
 * production approval, session tokens and authorization must be enforced by the backend.
 */
@CapacitorPlugin(name="NoriAuth")
public final class NoriAuthPlugin extends Plugin {
    private final NoriAccessGate gate=new NoriAccessGate();
    private final NoriSessionAuthority authority=NoriSessionAuthority.get();
    private NoriUserIdentity identity=new NoriUserIdentity("","","","","",0);

    @PluginMethod public void status(PluginCall c){
        JSObject o=new JSObject();o.put("status",gate.status().name());o.put("canEnter",gate.canEnter());o.put("userId",identity.userId());o.put("displayName",identity.displayName());o.put("ageBand",identity.ageBand());o.put("reason",gate.denialReason());c.resolve(o);
    }
    @PluginMethod public void submitSignup(PluginCall c){
        String name=c.getString("name","");int age=c.getInt("age",0);String email=c.getString("email","");String backup=c.getString("backupEmail","");
        NoriSignupRequest r=new NoriSignupRequest(name,age,email,backup);
        if(!r.valid()||!r.backupDistinct()){gate.set(NoriAdmissionStatus.REJECTED,"");c.reject("Name, valid age, primary email and a distinct backup email are required.");return;}
        // Submission never grants access. The backend must verify both emails and admission basis.
        gate.set(NoriAdmissionStatus.PENDING_REVIEW,"");
        authority.pending();
        JSObject o=new JSObject();o.put("ok",true);o.put("status",gate.status().name());o.put("message","Application submitted. Access remains locked until Nori admission is approved.");c.resolve(o);
    }
    /** Called only after a trusted backend returns an approved session. */
    @PluginMethod public void acceptApprovedSession(PluginCall c){
        String id=c.getString("userId","");String name=c.getString("name","");String email=c.getString("email","");String backup=c.getString("backupEmail","");int age=c.getInt("age",0);String session=c.getString("sessionId","");String roleName="STUDENT";
        if(id.trim().isEmpty()||session.trim().isEmpty()){c.reject("Approved authenticated session required");return;}
        identity=new NoriUserIdentity(id,name,session,email,backup,age);gate.set(NoriAdmissionStatus.APPROVED,id);com.nori.jarvis.nori.admin.model.AdminRole trustedRole;try{trustedRole=com.nori.jarvis.nori.admin.model.AdminRole.valueOf(roleName);}catch(Exception e){trustedRole=com.nori.jarvis.nori.admin.model.AdminRole.STUDENT;}authority.approve(identity,trustedRole);
        JSObject o=new JSObject();o.put("ok",true);o.put("status",gate.status().name());o.put("scope",identity.scope());o.put("displayName",identity.displayName());o.put("ageBand",identity.ageBand());c.resolve(o);
    }
    @PluginMethod public void signOut(PluginCall c){identity=new NoriUserIdentity("","","","","",0);gate.set(NoriAdmissionStatus.SIGN_UP_REQUIRED,"");authority.signOut();JSObject o=new JSObject();o.put("ok",true);c.resolve(o);}
}
