package com.nori.jarvis.nori.android.calendar;

import android.content.Context;
import android.content.Intent;
import android.provider.CalendarContract;

/** Calendar boundary. Opens the user's calendar UI instead of silently modifying calendars. */
public final class NoriCalendarService {
    private final Context context;
    public NoriCalendarService(Context context) { this.context = context.getApplicationContext(); }
    public Intent createEventIntent(String title, long startMillis, long endMillis, String description) {
        if (title == null || title.trim().isEmpty()) throw new IllegalArgumentException("title_required");
        if (endMillis <= startMillis) throw new IllegalArgumentException("end_after_start_required");
        return new Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.Events.TITLE, title)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
                .putExtra(CalendarContract.Events.DESCRIPTION, description == null ? "" : description)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    }
    public void openCreateEvent(String title, long startMillis, long endMillis, String description) {
        context.startActivity(createEventIntent(title, startMillis, endMillis, description));
    }
}
