package com.nori.jarvis.nori.admin.model;

public final class AccessDecision {
    public final boolean allowed;
    public final String reason;
    public final String principalId;
    public final String studentId;

    public AccessDecision(boolean allowed, String reason, String principalId, String studentId) {
        this.allowed = allowed;
        this.reason = reason;
        this.principalId = principalId;
        this.studentId = studentId;
    }
}
