package com.nori.jarvis.nori.brain.command;

import java.util.*;

/** Natural-language command-chain planner. Execution remains confirmation/permission gated elsewhere. */
public final class NoriCommandChainEngine {
    public static final class Step { public final String id,action; public final List<String> dependsOn; public final boolean requiresConfirmation;
        Step(String i,String a,List<String>d,boolean c){id=i;action=a;dependsOn=Collections.unmodifiableList(new ArrayList<>(d));requiresConfirmation=c;}}
    public static final class Chain { public final String request; public final List<Step> steps; public final boolean needsConfirmation;
        Chain(String r,List<Step>s,boolean c){request=r;steps=Collections.unmodifiableList(new ArrayList<>(s));needsConfirmation=c;}}
    public Chain plan(String request){String r=request==null?"":request.toLowerCase(Locale.ROOT);List<Step>s=new ArrayList<>();
        if(r.contains("study block")){s.add(step("calendar","prepare_calendar_block",true));s.add(step("resources","surface_relevant_material",true));s.add(new Step("review","queue_review_or_flashcards",Collections.singletonList("resources"),true));s.add(new Step("focus","start_focus_timer",Collections.singletonList("calendar"),true));}
        else if(r.contains("tomorrow")&&r.contains("test")){s.add(step("calendar","inspect_tomorrow_assessment",false));s.add(new Step("resources","prepare_relevant_resources",Collections.singletonList("calendar"),false));s.add(new Step("review","prepare_retrieval_set",Collections.singletonList("resources"),true));}
        else s.add(step("interpret","resolve_requested_action",false));
        return new Chain(request,s,s.stream().anyMatch(x->x.requiresConfirmation));}
    private Step step(String id,String action,boolean c){return new Step(id,action,Collections.emptyList(),c);}
}
