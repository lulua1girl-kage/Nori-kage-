package com.nori.jarvis.nori.data;

import android.content.Context;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Iterator;

/**
 * Imports a V32 localStorage export into the native store.
 *
 * Expected input shape:
 * {"schemaVersion":1,"exportedAt":"...","data":{"nori_key": ...}}
 *
 * Import is non-destructive: existing native keys are not overwritten unless
 * overwriteExisting is explicitly true. The original V32 export remains
 * untouched because this class only reads the supplied JSON string.
 */
public final class V32DataImporter {
    private final NativeDataRepository repository;
    private final boolean ownsRepository;

    public V32DataImporter(Context context) {
        repository = new NativeDataRepository(context);
        ownsRepository = true;
    }

    V32DataImporter(NativeDataRepository repository) {
        if (repository == null) throw new IllegalArgumentException("repository == null");
        this.repository = repository;
        ownsRepository = false;
    }

    public ImportReport importExport(String exportJson, boolean overwriteExisting) {
        ImportReport report = new ImportReport();
        if (exportJson == null || exportJson.trim().isEmpty()) {
            report.errors++;
            return report;
        }
        try {
            JSONObject root = new JSONObject(exportJson);
            JSONObject data = root.optJSONObject("data");
            if (data == null) {
                report.errors++;
                return report;
            }
            Iterator<String> keys = data.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                if (key == null || key.trim().isEmpty()) continue;
                report.seen++;
                if (!overwriteExisting && repository.contains(key)) {
                    report.skippedExisting++;
                    continue;
                }
                Object value = data.opt(key);
                String json = value == null || value == JSONObject.NULL ? "null" : value.toString();
                if (repository.putJson(key, json, categoryFor(key), root.optInt("schemaVersion", 1))) {
                    report.imported++;
                } else {
                    report.errors++;
                }
            }
        } catch (JSONException e) {
            report.errors++;
        }
        return report;
    }

    private String categoryFor(String key) {
        if (key.startsWith("nori_phase_")) return "phase";
        if (key.contains("history") || key.contains("audit") || key.contains("events")) return "history";
        if (key.contains("memory") || key.contains("profile") || key.contains("prefs")) return "memory";
        if (key.contains("assignment") || key.contains("exam") || key.contains("study")) return "academic";
        if (key.contains("kage") || key.contains("override") || key.contains("breach") || key.contains("consequence")) return "kage";
        if (key.contains("privacy") || key.contains("owner")) return "system";
        return "general";
    }

    public void close() {
        if (ownsRepository) repository.close();
    }

    public static final class ImportReport {
        public int seen;
        public int imported;
        public int skippedExisting;
        public int errors;

        public boolean isSuccessful() {
            return errors == 0;
        }

        @Override
        public String toString() {
            return "ImportReport{" +
                    "seen=" + seen +
                    ", imported=" + imported +
                    ", skippedExisting=" + skippedExisting +
                    ", errors=" + errors +
                    '}';
        }
    }
}
