package com.nori.jarvis.nori.brain.research;

import java.time.*; import java.util.*;

/** Prepares resource requests from explicit schedule/syllabus signals; it does not silently fetch personal data. */
public final class NoriPreemptiveResourceEngine {
    public static final class ResourcePlan { public final String target; public final List<String> resources; public final String trigger;
        ResourcePlan(String t,List<String>r,String g){target=t;resources=Collections.unmodifiableList(new ArrayList<>(r));trigger=g;}}
    public ResourcePlan prepare(String assessment,String subject,List<String> syllabusItems,boolean tomorrow){List<String>r=new ArrayList<>();if(syllabusItems!=null)for(String x:syllabusItems)if(x!=null&&!x.trim().isEmpty())r.add("review:"+x.trim());if(r.isEmpty()&&subject!=null&&!subject.isEmpty())r.add("review:"+subject);return new ResourcePlan(assessment==null?"":assessment,r,tomorrow?"tomorrow_assessment":"scheduled_preparation");}
}
