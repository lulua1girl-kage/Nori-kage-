package com.nori.jarvis.nori.identity;

/** Minimal registration data needed for personalization and admission. */
public final class NoriSignupRequest {
    public final String name, email, backupEmail;
    public final int age;
    public NoriSignupRequest(String name, int age, String email, String backupEmail) {
        this.name = clean(name); this.age = age; this.email = clean(email); this.backupEmail = clean(backupEmail);
    }
    public boolean valid() { return !name.isEmpty() && age >= 13 && age <= 120 && email.contains("@") && backupEmail.contains("@"); }
    public boolean backupDistinct() { return !email.equalsIgnoreCase(backupEmail); }
    private static String clean(String s){return s==null?"":s.trim();}
}
