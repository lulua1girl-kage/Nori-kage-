package com.nori.jarvis.nori.admin;

import java.util.*;

/** Safe email policy: draft by default; sensitive personal data is never silently forwarded. */
public final class NoriImprovementEmailPolicy {
    public enum Mode { DRAFT, USER_CONFIRMED_SEND, ADMIN_APPROVED_SEND }
    public boolean canSend(Mode mode, boolean containsSensitive, boolean recipientVerified){
        if(!recipientVerified)return false;
        if(containsSensitive)return mode==Mode.ADMIN_APPROVED_SEND;
        return mode==Mode.USER_CONFIRMED_SEND || mode==Mode.ADMIN_APPROVED_SEND;
    }
    public String rule(){return "Nori may prepare improvement emails, but sending is explicit; sensitive student content requires stronger authorization and redaction.";}
}
