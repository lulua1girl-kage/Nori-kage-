package com.nori.jarvis.nori.education.engine;

import com.nori.jarvis.nori.education.model.*; import java.util.*;

public final class LearningPatternAnalyzer {
    public static final class Pattern { public final String label; public final double value; public Pattern(String l,double v){label=l;value=v;} }
    public List<Pattern> analyze(List<AcademicEvidence> evidence){
        if(evidence==null||evidence.isEmpty()) return Collections.emptyList();
        double avg=evidence.stream().mapToDouble(e->e.score).average().orElse(0);
        int recentLow=0, careless=0, application=0;
        for(AcademicEvidence e:evidence){if(e.score<70)recentLow++; careless+=e.carelessErrors; application+=e.applicationErrors;}
        List<Pattern> out=new ArrayList<>(); out.add(new Pattern("average_score",avg));
        out.add(new Pattern("low_result_rate",(double)recentLow/evidence.size()));
        out.add(new Pattern("careless_error_rate",(double)careless/Math.max(1,evidence.size())));
        out.add(new Pattern("application_error_rate",(double)application/Math.max(1,evidence.size())));
        return out;
    }
}
