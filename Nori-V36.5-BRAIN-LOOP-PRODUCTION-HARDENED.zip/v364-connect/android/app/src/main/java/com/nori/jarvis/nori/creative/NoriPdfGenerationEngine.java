package com.nori.jarvis.nori.creative;

import java.util.*;

/** Provider-neutral PDF document planner. Native Android rendering is supplied by NoriPdfService. */
public final class NoriPdfGenerationEngine {
    public enum DocumentType { NOTES, STUDY_GUIDE, REPORT, ASSIGNMENT, REVISION_SHEET, PLAN, RESUME, CUSTOM }
    public static final class Section {
        public final String title,body; public final boolean pageBreak;
        public Section(String title,String body,boolean pageBreak){this.title=title==null?"":title;this.body=body==null?"":body;this.pageBreak=pageBreak;}
    }
    public static final class DocumentSpec {
        public final String title,author; public final DocumentType type; public final List<Section> sections;
        public DocumentSpec(String title,String author,DocumentType type,List<Section> sections){
            this.title=title==null?"Nori Document":title;this.author=author==null?"":author;this.type=type==null?DocumentType.CUSTOM:type;
            this.sections=Collections.unmodifiableList(new ArrayList<>(sections==null?Collections.<Section>emptyList():sections));
        }
    }
    public DocumentSpec fromPlainText(String title,String text){
        List<Section> s=new ArrayList<>(); String[] blocks=(text==null?"":text).split("\\n\\s*\\n");
        for(int i=0;i<blocks.length;i++){String b=blocks[i].trim();if(!b.isEmpty())s.add(new Section(i==0?"Overview":"Section "+(i+1),b,false));}
        return new DocumentSpec(title,"",DocumentType.CUSTOM,s);
    }
}
