package com.nori.jarvis;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.List;
import com.nori.jarvis.nori.focus.NoriFocusReasoner;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Polls the foreground app every second via UsageStatsManager (not
 * AccessibilityService — see the plugin README for why) and shows a
 * full-screen overlay when a blocked package comes to the foreground.
 * The overlay interrupts and offers a way back to Nori; it does not
 * prevent force-closing and reopening the blocked app — that would
 * require AccessibilityService-level control, which brings real Play
 * Store policy risk for non-accessibility use.
 */
public class NoriBlockerService extends Service {

    public static final String EXTRA_BLOCKED_PACKAGES = "blockedPackages";
    public static final String EXTRA_STATUS_ENDPOINT = "statusEndpoint";
    public static final String EXTRA_AUTH_TOKEN = "authToken";
    public static final String EXTRA_CONTEXT_JSON = "contextJson";
    private static final String CHANNEL_ID = "nori_blocker_channel";
    private static final int NOTIFICATION_ID = 8420;
    private static final long POLL_INTERVAL_MS = 500L; // faster foreground response; does not change voice timing
    private static final long STATUS_REFRESH_MS = 30000L;
    private String statusEndpoint = "";
    private String authToken = "";
    private String contextJson = "{}";
    private long lastStatusRefresh = 0L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private List<String> blockedPackages = new ArrayList<>();
    private List<String> configuredPackages = new ArrayList<>();
    private final NoriFocusReasoner focusReasoner = new NoriFocusReasoner();
    // Native-owned temporary access survives JS context refreshes. JS context is
    // descriptive; it must never erase an authorization granted by this service.
    private final java.util.Map<String, Long> nativeTemporaryAccess = new java.util.HashMap<>();
    private View overlayView = null;
    private WindowManager windowManager = null;

    private final Runnable pollRunnable = new Runnable() {
        @Override
        public void run() {
            checkForegroundApp();
            handler.postDelayed(this, POLL_INTERVAL_MS);
        }
    };

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && intent.getStringArrayListExtra(EXTRA_BLOCKED_PACKAGES) != null) {
            ArrayList<String> incoming = intent.getStringArrayListExtra(EXTRA_BLOCKED_PACKAGES);
            if (incoming != null && !incoming.isEmpty()) {
                configuredPackages = new ArrayList<>(incoming);
                blockedPackages = new ArrayList<>(configuredPackages);
            }
        }
        if (intent != null) {
            statusEndpoint = intent.getStringExtra(EXTRA_STATUS_ENDPOINT);
            authToken = intent.getStringExtra(EXTRA_AUTH_TOKEN);
            if (intent.hasExtra(EXTRA_CONTEXT_JSON)) contextJson = intent.getStringExtra(EXTRA_CONTEXT_JSON);
        }
        startForeground(NOTIFICATION_ID, buildNotification());
        handler.removeCallbacks(pollRunnable);
        handler.post(pollRunnable);
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(pollRunnable);
        removeOverlay();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void checkForegroundApp() {
        clearExpiredTemporaryAccess();
        if (!statusEndpoint.isEmpty() && System.currentTimeMillis() - lastStatusRefresh >= STATUS_REFRESH_MS) {
            lastStatusRefresh = System.currentTimeMillis();
            refreshRestrictionsAsync();
        }
        UsageStatsManager usm = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        long now = System.currentTimeMillis();
        UsageEvents events = usm.queryEvents(now - 5000, now);
        String currentApp = null;
        UsageEvents.Event event = new UsageEvents.Event();
        while (events.hasNextEvent()) {
            events.getNextEvent(event);
            if (event.getEventType() == UsageEvents.Event.MOVE_TO_FOREGROUND) currentApp = event.getPackageName();
        }
        if (currentApp == null) return;
        if (currentApp.equals(getPackageName())) { removeOverlay(); return; }
        try {
            JSONObject context = new JSONObject(contextJson == null ? "{}" : contextJson);
            JSONObject settings = context.optJSONObject("settings");
            int tempMinutes = settings == null ? 5 : settings.optInt("tempAccessMinutes", 5);
            if (context.optBoolean("sleepWindowActive", false)) { /* legacy shape fallback */ }
            boolean sleep = context.optJSONObject("sleepWindow") != null && context.optJSONObject("sleepWindow").optBoolean("active", false);
            String mode = context.optString("mode", "normal");
            boolean protectedWindow = sleep || mode.equals("study") || mode.equals("exam_enhanced") || mode.equals("exam_final");
            if (!protectedWindow || isTemporarilyAllowed(currentApp)) { removeOverlay(); return; }
            if (isAcademicApp(currentApp)) { removeOverlay(); return; }
            // Only user-selected packages are eligible for restriction. Known social apps
            // are not implicitly blocked. Purpose/activity can create a legitimate-use exception.
            NoriFocusReasoner.Result decision = focusReasoner.decide(currentApp, context.optString("purpose", ""), context.optString("activity", ""), protectedWindow, new java.util.HashSet<>(blockedPackages));
            if (decision.decision == NoriFocusReasoner.Decision.BLOCK) showOverlay(currentApp, context);
            else removeOverlay();
        } catch (Exception e) {
            // Fail open for ambiguous/unknown context; preserve the existing explicit blocker list.
            if (blockedPackages.contains(currentApp)) showOverlay(currentApp, new JSONObject()); else removeOverlay();
        }
    }

    private boolean isKnownDistractor(String pkg) {
        return pkg.equals("com.instagram.android") || pkg.equals("com.pinterest") || pkg.equals("com.snapchat.android") || pkg.equals("com.zhiliaoapp.musically") || pkg.equals("com.google.android.youtube");
    }

    private boolean isAcademicApp(String pkg) {
        return pkg.equals(WPS_OFFICE_PACKAGE) || pkg.contains("office") || pkg.contains("docs") || pkg.contains("drive") || pkg.contains("acrobat") || pkg.contains("notion");
    }

    private void clearExpiredTemporaryAccess() {
        long now = System.currentTimeMillis();
        java.util.Iterator<java.util.Map.Entry<String, Long>> it = nativeTemporaryAccess.entrySet().iterator();
        while (it.hasNext()) {
            java.util.Map.Entry<String, Long> e = it.next();
            if (e.getValue() == null || e.getValue() <= now) it.remove();
        }
    }

    private boolean isTemporarilyAllowed(String pkg) {
        final long now = System.currentTimeMillis();
        Long nativeExpiry = nativeTemporaryAccess.get(pkg);
        if (nativeExpiry != null) {
            if (nativeExpiry > now) return true;
            nativeTemporaryAccess.remove(pkg);
        }
        // Also honor a token supplied by the JS layer (for restores/sync), but
        // never use JS context as the sole native authorization store.
        try {
            JSONObject context = new JSONObject(contextJson == null ? "{}" : contextJson);
            JSONArray tokens = context.optJSONArray("temporaryAccess");
            if (tokens == null) return false;
            for (int i=0;i<tokens.length();i++) {
                JSONObject t=tokens.optJSONObject(i);
                if(t!=null && pkg.equals(t.optString("package")) && t.optLong("expiresAt",0)>now) return true;
            }
        } catch(Exception ignored){}
        return false;
    }

    private void refreshRestrictionsAsync() {
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(statusEndpoint).openConnection();
                connection.setRequestMethod("GET"); connection.setConnectTimeout(5000); connection.setReadTimeout(5000);
                if (!authToken.isEmpty()) connection.setRequestProperty("Authorization", "Bearer " + authToken);
                int code = connection.getResponseCode();
                if (code != 200) return;
                BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                StringBuilder body = new StringBuilder(); String line; while ((line=reader.readLine())!=null) body.append(line); reader.close();
                JSONObject root = new JSONObject(body.toString()); JSONArray restrictions = root.optJSONArray("restrictions");
                if (restrictions == null) return;
                List<String> next = new ArrayList<>(configuredPackages);
                for (int i=0;i<restrictions.length();i++) {
                    JSONObject r=restrictions.getJSONObject(i); String domain=r.optString("domain","");
                    if (domain.equals("digital_social")) { addIfMissing(next,"com.instagram.android"); addIfMissing(next,"com.snapchat.android"); addIfMissing(next,"com.pinterest"); addIfMissing(next,"com.zhiliaoapp.musically"); }
                    else if (domain.equals("entertainment")) addIfMissing(next,"com.google.android.youtube");
                    else if (domain.equals("gaming")) { /* configured game packages can be added here */ }
                }
                final List<String> finalNext = next; handler.post(() -> blockedPackages = finalNext);
            } catch (Exception ignored) { }
            finally { if (connection != null) connection.disconnect(); }
        }).start();
    }

    private static void addIfMissing(List<String> list, String value) {
        if (!list.contains(value)) list.add(value);
    }

    // WPS Office package name — this is the standard package ID for the
    // international WPS Office app on the Play Store. Verify this against
    // your actual installed app if the button doesn't do anything (Settings
    // > Apps > WPS Office > Advanced > shows the package name), since this
    // couldn't be confirmed against a real device from this build.
    private static final String WPS_OFFICE_PACKAGE = "cn.wps.moffice_eng";

    private void showOverlay(String packageName, JSONObject context) {
        if (overlayView != null) return;
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(0xFFFFFFFF);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(60, 60, 60, 60);

        TextView text = new TextView(this);
        String mode = context.optString("mode", "protected");
        String reason = context.optString("reason", "Nori protection is active.");
        JSONObject app = new JSONObject();
        try { app.put("package", packageName); } catch(Exception ignored){}
        text.setText("Nori protection\n\n" + reason + "\n\nDetected: " + packageName);
        text.setTextSize(20f);
        text.setTextColor(0xFF000000);
        text.setGravity(Gravity.CENTER);
        layout.addView(text);

        // The actual point of breaking out is usually to get to notes, not
        // to see Nori again — so this goes straight to WPS Office when
        // it's installed, and only falls back to Nori if it isn't.
        Button studyButton = new Button(this);
        studyButton.setText("Open WPS Office \u2014 keep studying");
        studyButton.setOnClickListener(v -> {
            removeOverlay();
            Intent wpsIntent = getPackageManager().getLaunchIntentForPackage(WPS_OFFICE_PACKAGE);
            if (wpsIntent != null) {
                wpsIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(wpsIntent);
            } else {
                openNori();
            }
        });
        layout.addView(studyButton);

        Button necessaryButton = new Button(this);
        necessaryButton.setText("Necessary / Emergency — allow 5 minutes");
        necessaryButton.setOnClickListener(v -> {
            grantTemporaryAccess(packageName, 5);
            removeOverlay();
        });
        layout.addView(necessaryButton);

        Button noriButton = new Button(this);
        noriButton.setText("Return to Nori");
        noriButton.setOnClickListener(v -> { removeOverlay(); openNori(); });
        layout.addView(noriButton);

        int type = (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;

        // Deliberately NOT FLAG_NOT_FOCUSABLE — the button needs to receive
        // the tap. FLAG_NOT_TOUCH_MODAL is not needed either since this
        // overlay is meant to consume all touches while shown.
        WindowManager.LayoutParams params = new WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            0,
            PixelFormat.TRANSLUCENT
        );

        windowManager.addView(layout, params);
        overlayView = layout;
    }

    private void grantTemporaryAccess(String pkg, int minutes) {
        final long now = System.currentTimeMillis();
        final long expiry = now + Math.max(1, minutes) * 60000L;
        // Authoritative native token. Future JS context syncs cannot erase it.
        nativeTemporaryAccess.put(pkg, expiry);
        // Mirror it into context for UI/audit visibility only.
        try {
            JSONObject root = new JSONObject(contextJson == null ? "{}" : contextJson);
            JSONArray tokens = root.optJSONArray("temporaryAccess");
            if (tokens == null) tokens = new JSONArray();
            JSONObject token = new JSONObject();
            token.put("package", pkg);
            token.put("reason", "necessary_or_emergency");
            token.put("createdAt", now);
            token.put("expiresAt", expiry);
            tokens.put(token);
            root.put("temporaryAccess", tokens);
            contextJson = root.toString();
        } catch(Exception ignored){}
    }

    private void openNori() {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage(getPackageName());
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launchIntent);
        }
    }

    private void removeOverlay() {
        if (overlayView != null && windowManager != null) {
            windowManager.removeView(overlayView);
            overlayView = null;
        }
    }

    private Notification buildNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Nori Focus Mode", NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }
        return new NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Nori Focus Mode is active")
            .setContentText("Distracting apps are paused during your study block.")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .build();
    }
}
