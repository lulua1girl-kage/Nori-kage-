package com.nori.jarvis.nori.android;

import android.content.Context;
import com.nori.jarvis.nori.android.alarm.NoriAlarmService;
import com.nori.jarvis.nori.android.calendar.NoriCalendarService;
import com.nori.jarvis.nori.android.files.NoriFileService;
import com.nori.jarvis.nori.android.focus.NoriFocusBoundary;
import com.nori.jarvis.nori.android.notification.NoriNotificationService;
import com.nori.jarvis.nori.android.permission.AndroidPermissionChecker;
import com.nori.jarvis.nori.android.usage.NoriAppUsageService;

/** Stage 10 service registry. These are capabilities, not autonomous permissions. */
public final class NoriAndroidServices {
    public final NoriNotificationService notifications;
    public final NoriAlarmService alarms;
    public final NoriCalendarService calendar;
    public final NoriFileService files;
    public final NoriAppUsageService appUsage;
    public final NoriFocusBoundary focus;
    public final AndroidPermissionChecker permissions;
    public NoriAndroidServices(Context context) {
        notifications=new NoriNotificationService(context); alarms=new NoriAlarmService(context); calendar=new NoriCalendarService(context);
        files=new NoriFileService(); appUsage=new NoriAppUsageService(context); focus=new NoriFocusBoundary(context); permissions=new AndroidPermissionChecker(context);
    }
}
