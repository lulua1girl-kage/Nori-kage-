package com.nori.jarvis.nori.edgeai;

import java.util.*;

/**
 * Capability registry for on-device AI. It deliberately stores metadata, not model weights.
 * A runtime can be added later without changing Nori's Brain contract.
 */
public final class NoriEdgeAiRegistry {
    private final Map<String,NoriEdgeModel> models=new LinkedHashMap<>();
    private final EnumMap<NoriOnDeviceBackend,Boolean> available=new EnumMap<>(NoriOnDeviceBackend.class);

    public NoriEdgeAiRegistry(){
        for(NoriOnDeviceBackend b:NoriOnDeviceBackend.values())available.put(b,b==NoriOnDeviceBackend.BUILTIN_DETERMINISTIC);
    }
    public synchronized void setBackendAvailable(NoriOnDeviceBackend backend, boolean value){
        if(backend!=null)available.put(backend,value);
    }
    public synchronized boolean isBackendAvailable(NoriOnDeviceBackend backend){return Boolean.TRUE.equals(available.get(backend));}
    public synchronized void register(NoriEdgeModel model){if(model!=null&&!model.id.isEmpty())models.put(model.id,model);}
    public synchronized void remove(String id){if(id!=null)models.remove(id);}
    public synchronized List<NoriEdgeModel> models(){return Collections.unmodifiableList(new ArrayList<>(models.values()));}
    public synchronized List<NoriEdgeModel> candidates(NoriOnDeviceTask task, boolean multimodal){
        List<NoriEdgeModel> out=new ArrayList<>();
        for(NoriEdgeModel m:models.values()) if(isBackendAvailable(m.backend)&&m.supports(task)&&(!multimodal||m.multimodal)) out.add(m);
        out.sort(Comparator.comparingLong(m->m.estimatedBytes));
        return out;
    }
    public synchronized String summary(){
        StringBuilder b=new StringBuilder(); for(NoriOnDeviceBackend x:NoriOnDeviceBackend.values()){
            if(b.length()>0)b.append('|'); b.append(x.name()).append('=').append(isBackendAvailable(x));
        } return b.toString();
    }
}
