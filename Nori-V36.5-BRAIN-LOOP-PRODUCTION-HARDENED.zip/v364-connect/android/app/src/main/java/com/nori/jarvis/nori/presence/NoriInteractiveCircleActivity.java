package com.nori.jarvis.nori.presence;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Optional native presentation surface. It is a face for Nori, not a second assistant. */
public final class NoriInteractiveCircleActivity extends Activity {
    @Override protected void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(Color.BLACK);getWindow().setNavigationBarColor(Color.BLACK);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setGravity(Gravity.CENTER);root.setBackgroundColor(Color.BLACK);
        TextView title=new TextView(this);title.setText("NORI  •  INTERACTIVE CIRCLE");title.setTextColor(0xfff2f2f2);title.setTextSize(12);title.setLetterSpacing(.16f);root.addView(title,new LinearLayout.LayoutParams(-1,60));
        NoriInteractiveCircleView circle=new NoriInteractiveCircleView(this);root.addView(circle,new LinearLayout.LayoutParams(-1,0,1));
        TextView note=new TextView(this);note.setText("Same Nori Brain • same memory • same conversation");note.setTextColor(0xff8a969e);note.setTextSize(11);note.setGravity(Gravity.CENTER);root.addView(note,new LinearLayout.LayoutParams(-1,60));setContentView(root);
    }
}
