package com.nori.jarvis.nori.execution;

import com.nori.jarvis.nori.actions.model.*;
import java.time.Instant;
import java.util.*;

/** Step 38: durable-ish capability execution record around the existing ActionEngine. */
public final class NoriExecutionLifecycle {
    public enum Stage { DISCOVER, UNDERSTAND, RESOLVE, PREPARE, PREVIEW, AUTHORIZE, EXECUTE, VERIFY, RECOVER, LEARN }
    public static final class Record { public final String id,capability; public final Stage stage; public final String status,detail; public final long startedAt,finishedAt; public final boolean verified;
        Record(String i,String c,Stage s,String st,String d,long a,long f,boolean v){id=i;capability=c;stage=s;status=st;detail=d;startedAt=a;finishedAt=f;verified=v;} }
    private final Map<String,Record> records=new LinkedHashMap<>();
    public synchronized String begin(String capability){String id="exec-"+UUID.randomUUID();long now=System.currentTimeMillis();records.put(id,new Record(id,capability,Stage.DISCOVER,"STARTED","lifecycle_created",now,0,false));return id;}
    public synchronized void update(String id,Stage stage,String status,String detail,boolean verified){Record r=records.get(id);if(r==null)return;records.put(id,new Record(r.id,r.capability,stage,status,detail,r.startedAt,verified?System.currentTimeMillis():r.finishedAt,verified));}
    public synchronized List<Record> recent(int limit){List<Record>x=new ArrayList<>(records.values());Collections.reverse(x);if(x.size()>limit)x=new ArrayList<>(x.subList(0,limit));return Collections.unmodifiableList(x);}
}
