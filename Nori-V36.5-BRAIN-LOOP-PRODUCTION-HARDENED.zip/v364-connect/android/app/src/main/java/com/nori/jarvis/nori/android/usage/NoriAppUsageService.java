package com.nori.jarvis.nori.android.usage;

import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import java.util.*;

/** Permissioned screen-time evidence boundary. It reports usage; it does not infer causes or block apps. */
public final class NoriAppUsageService {
    private final Context context;
    private final UsageStatsManager usage;
    public NoriAppUsageService(Context context) {
        this.context = context.getApplicationContext();
        this.usage = (UsageStatsManager)this.context.getSystemService(Context.USAGE_STATS_SERVICE);
    }
    public boolean hasUsageAccess() {
        AppOpsManager ops=(AppOpsManager)context.getSystemService(Context.APP_OPS_SERVICE);
        int mode=ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), context.getPackageName());
        return mode==AppOpsManager.MODE_ALLOWED;
    }
    public Intent accessSettingsIntent() { return new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS); }
    public List<UsageStats> query(long startMillis, long endMillis) {
        if (!hasUsageAccess()) throw new IllegalStateException("usage_access_not_granted");
        if (endMillis <= startMillis) throw new IllegalArgumentException("invalid_range");
        List<UsageStats> result=usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,startMillis,endMillis);
        return result==null?Collections.<UsageStats>emptyList():Collections.unmodifiableList(new ArrayList<>(result));
    }
}
