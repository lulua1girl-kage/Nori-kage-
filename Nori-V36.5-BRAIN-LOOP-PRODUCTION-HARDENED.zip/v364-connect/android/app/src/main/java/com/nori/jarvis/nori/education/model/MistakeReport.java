package com.nori.jarvis.nori.education.model;

import java.util.*;

public final class MistakeReport {
    public static final class Pattern { public final String key,type; public final int count; public final double recency;
        public Pattern(String key,String type,int count,double recency){this.key=key;this.type=type;this.count=count;this.recency=recency;} }
    public final List<Pattern> patterns; public final List<String> interventions;
    public MistakeReport(List<Pattern> patterns,List<String> interventions){this.patterns=Collections.unmodifiableList(new ArrayList<>(patterns));this.interventions=Collections.unmodifiableList(new ArrayList<>(interventions));}
}
