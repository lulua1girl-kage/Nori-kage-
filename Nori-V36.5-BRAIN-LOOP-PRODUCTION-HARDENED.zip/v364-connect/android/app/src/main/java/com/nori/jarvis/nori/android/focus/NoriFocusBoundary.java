package com.nori.jarvis.nori.android.focus;

import android.content.Context;
import android.content.Intent;
import android.provider.Settings;

/** Explicit focus-access boundary. No accessibility service is enabled or controlled silently by this class. */
public final class NoriFocusBoundary {
    private final Context context;
    public NoriFocusBoundary(Context context) { this.context=context.getApplicationContext(); }
    public Intent openOverlaySettings() { return new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).setData(android.net.Uri.parse("package:"+context.getPackageName())); }
    public Intent openAccessibilitySettings() { return new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS); }
    public boolean requiresExplicitUserEnablement() { return true; }
}
