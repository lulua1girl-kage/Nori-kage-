package com.nori.jarvis.nori.brain;

import java.util.*;

/** Checks whether a Brain result is internally complete before it is surfaced. */
public final class VerificationEngine {
    public enum Status { VERIFIED, INCOMPLETE, CONFLICTING }
    public static final class Result {
        public final Status status; public final List<String> issues;
        public Result(Status status,List<String> issues){this.status=status;this.issues=Collections.unmodifiableList(new ArrayList<>(issues));}
        public boolean isVerified(){return status==Status.VERIFIED;}
    }
    public Result verifyAcademicEvent(boolean academicPresent, boolean contextPresent, boolean failurePresent, boolean degreePresent) {
        List<String> issues=new ArrayList<>();
        if(!academicPresent) issues.add("academic_analysis_missing");
        if(!contextPresent) issues.add("context_analysis_missing");
        if(!failurePresent) issues.add("failure_classification_missing");
        if(!degreePresent) issues.add("degree_decision_missing");
        return new Result(issues.isEmpty()?Status.VERIFIED:Status.INCOMPLETE,issues);
    }
}
