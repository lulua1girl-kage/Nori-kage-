package com.nori.jarvis.nori.identity;

import com.nori.jarvis.nori.admin.model.AdminRole;

/** In-process session state. Production authorization must be repeated on the backend. */
public final class NoriSessionAuthority {
    private static final NoriSessionAuthority INSTANCE=new NoriSessionAuthority();
    private NoriUserIdentity identity=new NoriUserIdentity("","","","","",0);
    private NoriAdmissionStatus status=NoriAdmissionStatus.SIGN_UP_REQUIRED;
    private AdminRole role=AdminRole.VIEWER;
    private NoriSessionAuthority(){}
    public static NoriSessionAuthority get(){return INSTANCE;}
    public synchronized void approve(NoriUserIdentity i,AdminRole r){identity=i;status=NoriAdmissionStatus.APPROVED;role=r==null?AdminRole.STUDENT:r;}
    public synchronized void pending(){identity=new NoriUserIdentity("","","","","",0);status=NoriAdmissionStatus.PENDING_REVIEW;role=AdminRole.VIEWER;}
    public synchronized void signOut(){identity=new NoriUserIdentity("","","","","",0);status=NoriAdmissionStatus.SIGN_UP_REQUIRED;role=AdminRole.VIEWER;}
    public synchronized NoriUserIdentity identity(){return identity;}
    public synchronized boolean approved(){return status==NoriAdmissionStatus.APPROVED&&identity.valid();}
    public synchronized NoriAdmissionStatus status(){return status;}
    public synchronized AdminRole role(){return role;}
    public synchronized boolean admin(){return approved()&&(role==AdminRole.OWNER||role==AdminRole.ADMIN);}
}
