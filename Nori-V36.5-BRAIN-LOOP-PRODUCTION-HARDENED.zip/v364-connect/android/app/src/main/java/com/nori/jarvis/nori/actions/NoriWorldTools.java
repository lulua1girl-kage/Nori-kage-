package com.nori.jarvis.nori.actions;

import com.nori.jarvis.nori.actions.model.*;
import com.nori.jarvis.nori.world.NoriWorldWebConnector;
import java.util.*;

/** ActionEngine adapters for fresh world information. Read-only requests may execute after the user's direct request. */
public final class NoriWorldTools {
    private final NoriWorldWebConnector world;
    public NoriWorldTools(NoriWorldWebConnector w){world=w;}
    public void register(ActionEngine engine){
        Set<String> none=Collections.emptySet();
        engine.register(new ToolDefinition("world_news_live","Live news","Retrieve current news from public web sources for informational/educational use.",ActionType.EXTERNAL,false,true,none), handlerNews());
        engine.register(new ToolDefinition("world_weather_live","Live weather","Retrieve current weather from a public web source for planning and informational use.",ActionType.EXTERNAL,false,true,none), handlerWeather());
        engine.register(new ToolDefinition("world_trends_live","Live trends","Retrieve current public trend information for informational/educational use.",ActionType.EXTERNAL,false,true,none), handlerTrends());
        engine.register(new ToolDefinition("world_web_search","Web search","Retrieve current public web search results for research and informational use.",ActionType.EXTERNAL,false,true,none), handlerSearch());
    }
    private ToolHandler handlerNews(){return new ToolHandler(){
        public ActionPreview preview(ToolRequest r){return ActionPreview.allow(Collections.singletonList("Retrieve live news"));}
        public ActionExecutionResult execute(ToolRequest r,String op){return result(world.latestNews(r.input.get("query"),5),op);}
        public ActionExecutionResult undo(ToolRequest r,String op){return ActionExecutionResult.fail("read_only_not_undoable");}
    };}
    private ToolHandler handlerWeather(){return new ToolHandler(){
        public ActionPreview preview(ToolRequest r){return ActionPreview.allow(Collections.singletonList("Retrieve live weather for "+val(r,"location","requested location")));}
        public ActionExecutionResult execute(ToolRequest r,String op){return result(world.weather(r.input.get("location")),op);}
        public ActionExecutionResult undo(ToolRequest r,String op){return ActionExecutionResult.fail("read_only_not_undoable");}
    };}
    private ToolHandler handlerTrends(){return new ToolHandler(){
        public ActionPreview preview(ToolRequest r){return ActionPreview.allow(Collections.singletonList("Retrieve current trends"));}
        public ActionExecutionResult execute(ToolRequest r,String op){return result(world.trends(r.input.get("query"),5),op);}
        public ActionExecutionResult undo(ToolRequest r,String op){return ActionExecutionResult.fail("read_only_not_undoable");}
    };}
    private ToolHandler handlerSearch(){return new ToolHandler(){
        public ActionPreview preview(ToolRequest r){return ActionPreview.allow(Collections.singletonList("Search the public web"));}
        public ActionExecutionResult execute(ToolRequest r,String op){return result(world.webSearch(r.input.get("query"),5),op);}
        public ActionExecutionResult undo(ToolRequest r,String op){return ActionExecutionResult.fail("read_only_not_undoable");}
    };}
    private ActionExecutionResult result(NoriWorldWebConnector.Report r,String op){
        Map<String,String> out=new LinkedHashMap<>(); out.put("kind",r.kind.name());out.put("query",r.query);out.put("observedAt",r.observedAt.toString());out.put("live",String.valueOf(r.live));out.put("summary",r.rawSummary);out.put("itemCount",String.valueOf(r.items.size()));out.put("warnings",String.join(";",r.warnings));
        for(int i=0;i<r.items.size();i++){NoriWorldWebConnector.Item x=r.items.get(i);out.put("item"+i+"Title",x.title);out.put("item"+i+"Url",x.url);out.put("item"+i+"Summary",x.summary);}
        return new ActionExecutionResult(r.live,op,r.live?null:(r.warnings.isEmpty()?"world_lookup_failed":r.warnings.get(0)),out,r.live);
    }
    private static String val(ToolRequest r,String k,String d){String v=r.input.get(k);return v==null||v.trim().isEmpty()?d:v;}
}
