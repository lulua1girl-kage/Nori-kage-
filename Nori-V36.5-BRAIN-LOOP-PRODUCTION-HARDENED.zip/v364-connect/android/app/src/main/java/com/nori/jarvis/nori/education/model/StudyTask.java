package com.nori.jarvis.nori.education.model;

import java.time.LocalDateTime;

public final class StudyTask {
    public final String id, subject, topic, kind;
    public final int estimatedMinutes;
    public final LocalDateTime due;
    public final double importance;
    public StudyTask(String id, String subject, String topic, String kind, int estimatedMinutes,
                     LocalDateTime due, double importance) {
        this.id=id; this.subject=subject; this.topic=topic; this.kind=kind;
        this.estimatedMinutes=Math.max(5, estimatedMinutes); this.due=due; this.importance=clamp(importance);
    }
    private static double clamp(double x){return Math.max(0,Math.min(1,x));}
}
