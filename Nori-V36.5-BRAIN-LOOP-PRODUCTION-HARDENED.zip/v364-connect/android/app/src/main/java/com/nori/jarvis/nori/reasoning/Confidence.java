package com.nori.jarvis.nori.reasoning;

/** Coarse decision confidence; it describes evidence quality, not certainty about a person. */
public enum Confidence {
    HIGH, MEDIUM, LOW, UNKNOWN
}
