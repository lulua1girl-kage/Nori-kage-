package com.nori.jarvis.nori.ai;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Minimal provider-neutral HTTP adapter. The server contract is intentionally tiny:
 * POST JSON {"prompt":"...","system":"..."} and return either plain text or
 * JSON containing a string field named "text". Provider-specific adapters can replace it.
 * No token is persisted by this class.
 */
public final class RemoteAiProvider implements AiProvider {
    private final AiProviderConfig config;
    public RemoteAiProvider(AiProviderConfig config){this.config=config==null?AiProviderConfig.disabled():config;}
    @Override public String id(){return config.providerId.isEmpty()?"remote":config.providerId;}
    @Override public boolean isAvailable(){return config.usable();}
    @Override public boolean isRemote(){return true;}

    @Override public AiResponse generate(AiRequest request){
        if(request==null) return AiResponse.error(id(),"request_missing");
        if(!config.usable()) return AiResponse.unavailable(id(),"remote_provider_disabled_or_not_consented");
        if(request.prompt.length()>config.maxInputCharacters) return AiResponse.blocked(id(),"input_limit_exceeded");
        HttpURLConnection c=null;
        try{
            c=(HttpURLConnection)new URL(config.endpoint).openConnection();
            c.setRequestMethod("POST"); c.setConnectTimeout(8000); c.setReadTimeout(20000);
            c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=utf-8");
            if(!config.authorizationToken.isEmpty()) c.setRequestProperty("Authorization","Bearer "+config.authorizationToken);
            String image=request.metadata.get("imageDataUrl"); String body="{\"prompt\":"+json(request.prompt)+",\"system\":"+json(request.systemInstruction)+(image==null?"":",\"imageDataUrl\":"+json(image))+"}";
            byte[] bytes=body.getBytes(StandardCharsets.UTF_8);
            try(OutputStream out=c.getOutputStream()){out.write(bytes);}
            int code=c.getResponseCode();
            InputStream stream=code>=200&&code<300?c.getInputStream():c.getErrorStream();
            String response=read(stream);
            if(code<200||code>=300) return AiResponse.error(id(),"http_"+code);
            String text=extractText(response);
            if(text.isEmpty()) return AiResponse.error(id(),"empty_provider_response");
            if(text.length()>request.maxOutputCharacters) text=text.substring(0,request.maxOutputCharacters);
            return AiResponse.success(id(),text,true);
        }catch(Exception e){return AiResponse.error(id(),"remote_request_failed");}
        finally{if(c!=null)c.disconnect();}
    }
    private static String read(InputStream in)throws Exception{
        if(in==null)return ""; StringBuilder b=new StringBuilder();
        try(BufferedReader r=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String s; while((s=r.readLine())!=null)b.append(s);}
        return b.toString();
    }
    private static String json(String s){StringBuilder b=new StringBuilder("\""); for(char ch:s.toCharArray()){switch(ch){case '\\':b.append("\\\\");break;case '"':b.append("\\\"");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '\t':b.append("\\t");break;default:b.append(ch);}} return b.append('"').toString();}
    private static String extractText(String s){
        String t=s.trim();
        if(t.startsWith("\"")&&t.endsWith("\"")) return unescape(t.substring(1,t.length()-1));
        int i=t.indexOf("\"text\""); if(i>=0){int colon=t.indexOf(':',i+6); if(colon>=0){int q=t.indexOf('"',colon+1); if(q>=0){StringBuilder b=new StringBuilder(); boolean esc=false; for(int k=q+1;k<t.length();k++){char ch=t.charAt(k); if(esc){b.append(ch);esc=false;continue;} if(ch=='\\'){esc=true;continue;} if(ch=='"')break; b.append(ch);} return b.toString();}}}
        return t;
    }
    private static String unescape(String s){return s.replace("\\n","\n").replace("\\r","\r").replace("\\t","\t").replace("\\\"","\"").replace("\\\\","\\");}
}
