package com.nori.jarvis.nori.education.model;

import java.util.*;

public final class StrengthWeaknessReport {
    public static final class SubjectState {
        public final String subject; public final double mastery, confidence;
        public final List<String> strengths, weaknesses;
        public SubjectState(String subject,double mastery,double confidence,List<String> strengths,List<String> weaknesses){
            this.subject=subject; this.mastery=mastery; this.confidence=confidence;
            this.strengths=Collections.unmodifiableList(new ArrayList<>(strengths));
            this.weaknesses=Collections.unmodifiableList(new ArrayList<>(weaknesses));
        }
    }
    public final Map<String,SubjectState> subjects;
    public final List<String> priorityWeaknesses;
    public final List<String> priorityStrengths;
    public StrengthWeaknessReport(Map<String,SubjectState> subjects,List<String> ws,List<String> ss){
        this.subjects=Collections.unmodifiableMap(new LinkedHashMap<>(subjects));
        this.priorityWeaknesses=Collections.unmodifiableList(new ArrayList<>(ws));
        this.priorityStrengths=Collections.unmodifiableList(new ArrayList<>(ss));
    }
}
