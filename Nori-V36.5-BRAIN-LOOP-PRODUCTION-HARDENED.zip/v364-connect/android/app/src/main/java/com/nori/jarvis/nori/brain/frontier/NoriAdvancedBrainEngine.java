package com.nori.jarvis.nori.brain.frontier;

import com.nori.jarvis.nori.web.engine.WebIntelligence;
import com.nori.jarvis.nori.web.model.WebFetchResult;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;

/**
 * Nori's additive frontier orchestration layer. It improves planning, research,
 * verification and response strategy without replacing Nori's existing Brain.
 * It exposes compact decision summaries, never private chain-of-thought.
 */
public final class NoriAdvancedBrainEngine {
    public enum Effort { MICRO, FAST, STANDARD, DEEP, FRONTIER }
    public enum AnswerMode { DIRECT, EXPLAIN, PLAN, OPTIONS, RESEARCH, ACTION, STUDY, CREATIVE, SUPPORT }
    public enum EvidencePolicy { NONE, NORMAL, STRONG, MULTI_SOURCE }
    public enum Feature {
        INTENT_ROUTING, CONTEXT_COMPRESSION, AMBIGUITY_CHECK, CONTRADICTION_CHECK, UNCERTAINTY_CALIBRATION,
        MEMORY_RELEVANCE, MEMORY_FRESHNESS, GOAL_DECOMPOSITION, TASK_GRAPH, PLAN_REPAIR, ADAPTIVE_EFFORT,
        TOOL_SELECTION, PERMISSION_AWARENESS, ACTION_PREVIEW, ACTION_VERIFICATION, FAILURE_RECOVERY,
        RESEARCH_PLANNING, MULTI_SOURCE_RESEARCH, SOURCE_DEDUPLICATION, SOURCE_DIVERSITY, CLAIM_PROVENANCE,
        CONFLICT_DETECTION, EVIDENCE_THRESHOLD, FACT_INFERENCE_SEPARATION, SELF_CHECK, ANSWER_COMPRESSION,
        FOLLOW_UP_CONTINUITY, MULTIMODAL_ROUTING, DOCUMENT_ROUTING, CREATIVE_ROUTING, STUDY_METHOD_SELECTION,
        OUTCOME_LEARNING, HUMAN_CONTEXT, USER_CONTROL, OFFLINE_FALLBACK, LATENCY_BUDGET, PROVIDER_ROUTING,
        SAFE_CAPABILITY_DISCLOSURE, CHROME_HANDOFF, EXPORT_PORTABILITY
    }

    public static final class ThoughtPlan {
        public final String request;
        public final String intent;
        public final Effort effort;
        public final AnswerMode answerMode;
        public final EvidencePolicy evidencePolicy;
        public final int workUnits;
        public final boolean needsWeb;
        public final boolean needsFiles;
        public final boolean needsTools;
        public final boolean needsVerification;
        public final boolean needsClarification;
        public final boolean userControlRequired;
        public final List<String> steps;
        public final List<Feature> activeFeatures;
        public final String publicReasoning;
        public ThoughtPlan(String request,String intent,Effort effort,AnswerMode answerMode,EvidencePolicy evidencePolicy,int workUnits,
                           boolean needsWeb,boolean needsFiles,boolean needsTools,boolean needsVerification,boolean needsClarification,
                           boolean userControlRequired,List<String> steps,List<Feature> activeFeatures,String publicReasoning){
            this.request=request;this.intent=intent;this.effort=effort;this.answerMode=answerMode;this.evidencePolicy=evidencePolicy;
            this.workUnits=workUnits;this.needsWeb=needsWeb;this.needsFiles=needsFiles;this.needsTools=needsTools;this.needsVerification=needsVerification;
            this.needsClarification=needsClarification;this.userControlRequired=userControlRequired;
            this.steps=Collections.unmodifiableList(new ArrayList<>(steps));this.activeFeatures=Collections.unmodifiableList(new ArrayList<>(activeFeatures));this.publicReasoning=publicReasoning;
        }
    }

    public static final class ResearchBudget {
        public final int requested; public final int selected; public final int concurrency; public final long deadlineMillis;
        public ResearchBudget(int requested,int selected,int concurrency,long deadlineMillis){this.requested=requested;this.selected=selected;this.concurrency=concurrency;this.deadlineMillis=deadlineMillis;}
    }
    public static final class SourceResult {
        public final String url; public final boolean success; public final String title; public final String text; public final long elapsedMillis; public final String reason;
        SourceResult(String u,boolean s,String t,String x,long e,String r){url=u;success=s;title=t;text=x;elapsedMillis=e;reason=r;}
    }
    public static final class ResearchReport {
        public final String question; public final Instant startedAt,finishedAt; public final ResearchBudget budget; public final List<SourceResult> results; public final int successful;
        ResearchReport(String q,Instant a,Instant b,ResearchBudget bu,List<SourceResult> r){question=q;startedAt=a;finishedAt=b;budget=bu;results=Collections.unmodifiableList(new ArrayList<>(r));int n=0;for(SourceResult x:r)if(x.success)n++;successful=n;}
    }

    private final WebIntelligence web;
    private final ExecutorService researchPool;
    private final EnumSet<Feature> all=EnumSet.allOf(Feature.class);
    public NoriAdvancedBrainEngine(){this(new WebIntelligence());}
    public NoriAdvancedBrainEngine(WebIntelligence web){this.web=web==null?new WebIntelligence():web;this.researchPool=Executors.newFixedThreadPool(8);}

    public EnumSet<Feature> features(){return EnumSet.copyOf(all);}

    public ThoughtPlan think(String request,String context,boolean externalAvailable,boolean userInitiatedAction){
        String q=request==null?"":request.trim(); String l=q.toLowerCase(Locale.ROOT);
        String intent="INFORM"; AnswerMode mode=AnswerMode.DIRECT;
        if(matches(l,"research|compare|sources|evidence|latest|current|news|trend|what happened")){intent="RESEARCH";mode=AnswerMode.RESEARCH;}
        else if(matches(l,"plan|schedule|organize|roadmap|study plan")){intent="PLAN";mode=AnswerMode.PLAN;}
        else if(matches(l,"do|open|create|add|set|save|export|remind|start")){intent="ACT";mode=AnswerMode.ACTION;}
        else if(matches(l,"study|learn|explain|quiz|practice|homework|exam")){intent="LEARN";mode=AnswerMode.STUDY;}
        else if(matches(l,"make an image|generate image|poster|diagram|pdf|document")){intent="CREATE";mode=AnswerMode.CREATIVE;}
        else if(matches(l,"why|how does|explain|teach me")){intent="SOLVE";mode=AnswerMode.EXPLAIN;}
        boolean webNeed=matches(l,"latest|today|current|news|weather|trend|research|source|what is happening|2026") || matches(l,"search the web|look online");
        boolean files=matches(l,"my notes|my pdf|my file|document|textbook|study library|what did i write");
        boolean tools=matches(l,"add|create|open|set|schedule|save|export|remind|start|complete|delete|move");
        boolean verify=webNeed||tools||matches(l,"important|medical|legal|fact|accurate|is this true");
        boolean clarify=q.length()<4 || (matches(l,"this|that|it|them") && context==null);
        Effort effort=Effort.FAST; EvidencePolicy evidence=EvidencePolicy.NONE;
        if(webNeed){effort=Effort.DEEP;evidence=matches(l,"research|compare|evidence|sources|latest")?EvidencePolicy.MULTI_SOURCE:EvidencePolicy.NORMAL;}
        if(matches(l,"hard|complex|deep|thorough|comprehensive|in detail")){effort=Effort.FRONTIER;}
        if(q.length()>500 || matches(l,"multiple|several|all of|everything|step by step")) effort=effort==Effort.FAST?Effort.STANDARD:effort;
        if(tools)verify=true;
        boolean userControl=tools||matches(l,"change|send|publish|delete|block|permission|camera|microphone|screen");
        int units=1+(webNeed?3:0)+(files?2:0)+(tools?2:0)+(verify?1:0)+(effort.ordinal());
        List<String> steps=new ArrayList<>(); steps.add("understand request and relevant context"); if(webNeed)steps.add("retrieve only the amount of fresh evidence justified by the question"); if(files)steps.add("search user-provided sources"); if(tools)steps.add("prepare and authorize requested action"); if(verify)steps.add("verify important claims or action outcome"); steps.add("answer concisely and disclose uncertainty when material");
        EnumSet<Feature> active=EnumSet.noneOf(Feature.class); active.add(Feature.INTENT_ROUTING);active.add(Feature.CONTEXT_COMPRESSION);active.add(Feature.ADAPTIVE_EFFORT);active.add(Feature.ANSWER_COMPRESSION);active.add(Feature.FACT_INFERENCE_SEPARATION);active.add(Feature.UNCERTAINTY_CALIBRATION);active.add(Feature.SELF_CHECK);
        if(webNeed){active.add(Feature.RESEARCH_PLANNING);active.add(Feature.MULTI_SOURCE_RESEARCH);active.add(Feature.SOURCE_DEDUPLICATION);active.add(Feature.SOURCE_DIVERSITY);active.add(Feature.CLAIM_PROVENANCE);}
        if(tools){active.add(Feature.TOOL_SELECTION);active.add(Feature.PERMISSION_AWARENESS);active.add(Feature.ACTION_PREVIEW);active.add(Feature.ACTION_VERIFICATION);active.add(Feature.USER_CONTROL);}
        if(files)active.add(Feature.DOCUMENT_ROUTING); if(mode==AnswerMode.STUDY){active.add(Feature.STUDY_METHOD_SELECTION);active.add(Feature.OUTCOME_LEARNING);} if(mode==AnswerMode.CREATIVE){active.add(Feature.CREATIVE_ROUTING);active.add(Feature.MULTIMODAL_ROUTING);} if(!externalAvailable)active.add(Feature.OFFLINE_FALLBACK); else active.add(Feature.PROVIDER_ROUTING);
        String reason="Nori selected "+effort.name().toLowerCase(Locale.ROOT)+" effort for "+intent.toLowerCase(Locale.ROOT)+" work; it will use external information only when freshness or capability requires it.";
        return new ThoughtPlan(q,intent,effort,mode,evidence,units,webNeed,files,tools,verify,clarify,userControl,new ArrayList<>(steps),new ArrayList<>(active),reason);
    }

    /** Choose a small number of sources by default; never forces 25-source research. */
    public ResearchBudget budgetFor(String question){
        String q=question==null?"":question.toLowerCase(Locale.ROOT); int selected=3;
        if(matches(q,"latest|current|news|trend|compare"))selected=8;
        if(matches(q,"deep research|comprehensive|systematic|evidence|conflicting|scientific|policy"))selected=15;
        if(matches(q,"exhaustive|25 sources|maximum sources|thorough literature review"))selected=25;
        return new ResearchBudget(selected,selected,Math.min(8,selected),selected>=15?20000:12000);
    }

    /** Fetches up to 25 user/discovered HTTPS sources concurrently, then returns them in stable input order. */
    public ResearchReport research(String question,List<String> urls){
        ResearchBudget b=budgetFor(question); List<String> selected=new ArrayList<>(); if(urls!=null)for(String u:urls){if(selected.size()>=b.selected)break;if(valid(u)&&!selected.contains(u))selected.add(u);}
        if(selected.isEmpty())return new ResearchReport(question,Instant.now(),Instant.now(),new ResearchBudget(b.requested,0,b.concurrency,b.deadlineMillis),Collections.emptyList());
        Instant start=Instant.now(); List<Future<SourceResult>> futures=new ArrayList<>();
        for(String u:selected) futures.add(researchPool.submit(()->fetchOne(u)));
        List<SourceResult> out=new ArrayList<>(); long deadline=System.currentTimeMillis()+b.deadlineMillis;
        for(int i=0;i<futures.size();i++){Future<SourceResult> f=futures.get(i);long remain=Math.max(1,deadline-System.currentTimeMillis());try{out.add(f.get(remain,TimeUnit.MILLISECONDS));}catch(Exception e){f.cancel(true);out.add(new SourceResult(selected.get(i),false,"","",b.deadlineMillis,"timeout_or_fetch_failure"));}}
        return new ResearchReport(question,start,Instant.now(),new ResearchBudget(b.requested,selected.size(),b.concurrency,b.deadlineMillis),out);
    }
    private SourceResult fetchOne(String url){long t=System.currentTimeMillis();WebFetchResult r=web.fetch(url);long e=System.currentTimeMillis()-t;if(r.status!=WebFetchResult.Status.SUCCESS)return new SourceResult(url,false,"","",e,r.reason);String title=title(r.text);return new SourceResult(url,true,title,r.text,e,null);}
    private static String title(String s){Matcher m=Pattern.compile("<title[^>]*>([\\s\\S]*?)</title>",Pattern.CASE_INSENSITIVE).matcher(s==null?"":s);return m.find()?m.group(1).replaceAll("\\s+"," ").trim():"";}
    private static boolean matches(String s,String regex){return Pattern.compile("(?:"+regex+")",Pattern.CASE_INSENSITIVE).matcher(s).find();}
    private static boolean valid(String u){try{java.net.URI x=new java.net.URI(u);return "https".equalsIgnoreCase(x.getScheme())&&x.getHost()!=null&&x.getUserInfo()==null;}catch(Exception e){return false;}}
}
