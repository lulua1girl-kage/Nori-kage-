package com.nori.jarvis.nori.performance;

import java.util.Objects;

/** Central Stage 21 performance/offline boundary. */
public final class NoriPerformance {
    private final OfflinePolicy offlinePolicy = new OfflinePolicy();
    private final ResourceBudget budget;
    private final BoundedLruCache<String,Object> cache;
    private final PerformanceMonitor monitor = new PerformanceMonitor();

    public NoriPerformance() { this(new ResourceBudget()); }
    public NoriPerformance(ResourceBudget budget) {
        this.budget = Objects.requireNonNull(budget);
        this.cache = new BoundedLruCache<>(budget.maxCacheEntries);
    }
    public OfflinePolicy offlinePolicy() { return offlinePolicy; }
    public ResourceBudget budget() { return budget; }
    public PerformanceMonitor monitor() { return monitor; }
    public boolean canUseRemote() { return offlinePolicy.allowRemoteNetwork(); }
    public boolean coreAvailableOffline() { return offlinePolicy.allowLocalCore(); }
    public Object cached(String key) { return cache.get(key); }
    public void cache(String key, Object value) { cache.put(key, value); }
    public void clearCache() { cache.clear(); }
    public int cacheSize() { return cache.size(); }
    public <T> T timed(String operation, Work<T> work) {
        Objects.requireNonNull(work);
        long start = System.nanoTime();
        try { return work.run(); }
        finally { monitor.recordNanos(System.nanoTime() - start); }
    }
    public interface Work<T> { T run(); }
}
