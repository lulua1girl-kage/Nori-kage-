package com.nori.jarvis.nori.state;

import com.nori.jarvis.nori.conversation.model.ConversationState;
import com.nori.jarvis.nori.education.EducationalIntelligence;
import com.nori.jarvis.nori.education.model.AcademicEvidence;
import com.nori.jarvis.nori.education.model.MistakeReport;
import com.nori.jarvis.nori.education.model.StrengthWeaknessReport;
import com.nori.jarvis.nori.memory.MemoryEngine;
import com.nori.jarvis.nori.memory.MemoryItem;
import com.nori.jarvis.nori.performance.NoriPerformance;
import com.nori.jarvis.nori.security.NoriSecurity;
import com.nori.jarvis.nori.brain.ContextEngine;

import java.time.Instant;
import java.util.*;

/**
 * Stage 1 of post-Stage-23 evolution: one additive composition point for
 * current situation, academic state, memory, conversation, and system health.
 * It never owns or rewrites the underlying domain data.
 */
public final class NoriStateEngine {
    private NoriState current = NoriState.empty();
    private long sequence = 0;
    private NoriState.Availability availability = NoriState.Availability.UNKNOWN;
    private String activity = "";
    private boolean nearExam = false;
    private ContextEngine.Result lastContext;
    private NoriState.StudyStatus studyStatus=NoriState.StudyStatus.UNKNOWN;
    private String studySubject="", studyActivity=""; private double studyProgress=0; private int studyStarts=0;
    private NoriState.ExamStatus examStatus=NoriState.ExamStatus.UNKNOWN; private String examSubject="", examStartsAt=""; private long examMinutesUntil=0;
    private NoriState.DeviceAppEvidence deviceAppEvidence=new NoriState.DeviceAppEvidence("","","",false,"","");
    private String previousRefreshAt="";
    private final Deque<String> recentEvents = new ArrayDeque<>();
    private void event(String value){if(value!=null&&!value.trim().isEmpty()){recentEvents.addLast(value.trim());while(recentEvents.size()>30)recentEvents.removeFirst();}}

    public synchronized NoriState snapshot() { return current; }

    public synchronized void observeAvailability(NoriState.Availability availability, String activity) {
        this.availability = availability == null ? NoriState.Availability.UNKNOWN : availability;
        this.activity = activity == null ? "" : activity.trim();
        event("availability="+this.availability+" activity="+this.activity);
    }

    public synchronized void observeStudy(NoriState.StudyStatus status,String subject,String activity,double progress,int consecutiveStarts){
        this.studyStatus=status==null?NoriState.StudyStatus.UNKNOWN:status; this.studySubject=safe(subject); this.studyActivity=safe(activity);
        this.studyProgress=Math.max(0,Math.min(1,progress)); this.studyStarts=Math.max(0,consecutiveStarts);
        event("study="+this.studyStatus+" subject="+this.studySubject);
    }
    public synchronized void observeExam(NoriState.ExamStatus status,String subject,String startsAt,long minutesUntil){
        this.examStatus=status==null?NoriState.ExamStatus.UNKNOWN:status; this.examSubject=safe(subject); this.examStartsAt=safe(startsAt); this.examMinutesUntil=minutesUntil; this.nearExam=status==NoriState.ExamStatus.UPCOMING||status==NoriState.ExamStatus.ACTIVE;
        event("exam="+this.examStatus+" subject="+this.examSubject);
    }
    public synchronized void observeDeviceApp(String packageName,String category,String source,boolean userGranted,String confidence){
        this.deviceAppEvidence=new NoriState.DeviceAppEvidence(packageName,category,source,userGranted,Instant.now().toString(),confidence);
        event("device evidence="+category);
    }

    public synchronized void observeContext(ContextEngine.Result result, boolean nearExam) {
        this.lastContext = result;
        this.nearExam = nearExam;
        event("context="+(result==null?"":result.type.value()));
    }

    public synchronized NoriState refresh(EducationalIntelligence education, MemoryEngine memory,
                                           ConversationState conversation, NoriSecurity security,
                                           NoriPerformance performance) {
        Objects.requireNonNull(education, "education");
        Objects.requireNonNull(memory, "memory");
        Objects.requireNonNull(conversation, "conversation");
        sequence++;

        StrengthWeaknessReport report = education.assess();
        Map<String, Double> mastery = new LinkedHashMap<>();
        Map<String, Double> confidence = new LinkedHashMap<>();
        for (Map.Entry<String, StrengthWeaknessReport.SubjectState> e : report.subjects.entrySet()) {
            mastery.put(e.getKey(), e.getValue().mastery);
            confidence.put(e.getKey(), e.getValue().confidence);
        }

        List<AcademicEvidence> evidence = education.evidence();
        AcademicEvidence latest = evidence.isEmpty() ? null : evidence.get(evidence.size() - 1);
        MistakeReport mistakes = education.mistakes();

        int confirmed = 0, likely = 0, uncertain = 0, archived = 0;
        for (MemoryItem item : memory.list()) {
            switch (item.status) {
                case CONFIRMED: confirmed++; break;
                case LIKELY: likely++; break;
                case UNCERTAIN: uncertain++; break;
                case ARCHIVED: archived++; break;
                default: break;
            }
        }

        String contextType = lastContext == null ? "" : lastContext.type.value();
        String contextConfidence = lastContext == null ? "" : lastContext.confidence.name().toLowerCase(Locale.ROOT);
        List<String> facts = new ArrayList<>();
        facts.add("academic.evidence_count=" + evidence.size());
        facts.add("memory.total=" + memory.size());
        facts.add("conversation.active=" + conversation.isActive());
        if (!contextType.isEmpty()) facts.add("context.type=" + contextType);
        if (latest != null) facts.add("academic.latest_subject=" + safe(latest.subject));

        boolean securityHealthy = security == null || security.integrityHealthy();
        boolean reliabilityHealthy = security == null || (security.reliability().isInitialized() && !security.reliability().shouldFailClosed());
        boolean offlineFirst = performance == null || performance.offlinePolicy().mode() == com.nori.jarvis.nori.performance.OfflinePolicy.Mode.OFFLINE_FIRST;

        String now=Instant.now().toString();
        long elapsed=0; boolean rapidlyChanged=false;
        if(!previousRefreshAt.isEmpty()) try { elapsed=Math.max(0, java.time.Duration.between(Instant.parse(previousRefreshAt),Instant.parse(now)).getSeconds()); rapidlyChanged=elapsed<2; } catch(Exception ignored){}
        previousRefreshAt=now;
        facts.add("study.status="+studyStatus.name()); facts.add("exam.status="+examStatus.name());
        if(!deviceAppEvidence.foregroundPackage.isEmpty()) facts.add("device.foreground="+deviceAppEvidence.foregroundPackage);
        current = new NoriState(now,
                new NoriState.Situation(availability, activity, contextType, contextConfidence, nearExam, now),
                new NoriState.Academic(evidence.size(), mastery, confidence, report.priorityWeaknesses, latest == null ? "" : latest.subject, "", latest == null ? null : latest.score, latest == null ? "" : latest.at.toString(), mistakes.patterns.size(), patternDetails(mistakes), mistakes.interventions),
                new NoriState.Memory(memory.size(), confirmed, likely, uncertain, archived),
                new NoriState.Study(studyStatus,studySubject,studyActivity,studyProgress,studyStarts),
                new NoriState.Exam(examStatus,examSubject,examStartsAt,examMinutesUntil),
                deviceAppEvidence, new NoriState.Temporal(now, current.generatedAt, elapsed, sequence, rapidlyChanged),
                new NoriState.Conversation(conversation.isActive(), conversation.getMode().name(), conversation.recent(200).size()),
                new NoriState.SystemState(securityHealthy, reliabilityHealthy, offlineFirst, sequence), facts, new ArrayList<>(recentEvents));
        return current;
    }

    public synchronized NoriState observeAndRefresh(ContextEngine.Result context, boolean nearExam,
                                                     EducationalIntelligence education, MemoryEngine memory,
                                                     ConversationState conversation, NoriSecurity security,
                                                     NoriPerformance performance) {
        observeContext(context, nearExam);
        return refresh(education, memory, conversation, security, performance);
    }

    private static List<String> patternDetails(MistakeReport m){ List<String> out=new ArrayList<>(); if(m!=null) for(MistakeReport.Pattern p:m.patterns) out.add(p.key+"|type="+p.type+"|count="+p.count+"|recency="+p.recency); return out; }
    private static String safe(String s) { return s == null ? "" : s; }
}
