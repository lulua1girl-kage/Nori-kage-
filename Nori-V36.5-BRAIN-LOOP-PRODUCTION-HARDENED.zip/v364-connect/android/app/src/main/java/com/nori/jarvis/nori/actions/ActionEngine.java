package com.nori.jarvis.nori.actions;

import com.nori.jarvis.nori.actions.model.*;
import com.nori.jarvis.nori.data.DataRepository;

import java.time.Instant;
import java.util.*;

/**
 * Native proposal/confirmation/execution boundary.
 * Brain proposes; ActionEngine validates, previews, requires human confirmation,
 * executes through a registered adapter, verifies the adapter result, and retains undo metadata.
 */
public final class ActionEngine {
    private static final String AUDIT_KEY = "nori.actions.audit.v1";
    private static final int MAX_AUDIT = 300;
    private final Map<String, ToolDefinition> definitions = new LinkedHashMap<>();
    private final Map<String, ToolHandler> handlers = new HashMap<>();
    private final Map<String, ActionProposal> proposals = new LinkedHashMap<>();
    private final Map<String, ToolRequest> executedRequests = new HashMap<>();
    private final EducationalPurposeFirewall firewall = new EducationalPurposeFirewall();
    private final PermissionChecker permissions;
    private final DataRepository repository;

    public ActionEngine() { this(null, permission -> false); }
    public ActionEngine(DataRepository repository, PermissionChecker permissions) {
        this.repository = repository;
        this.permissions = permissions == null ? permission -> false : permissions;
    }

    public synchronized void register(ToolDefinition definition, ToolHandler handler) {
        if (definition == null || handler == null) throw new IllegalArgumentException("tool definition and handler required");
        if (!firewall.evaluate(definition).allowed) throw new IllegalArgumentException("tool rejected by educational purpose firewall");
        definitions.put(definition.id, definition); handlers.put(definition.id, handler);
    }

    public synchronized ToolDefinition definition(String toolId) { return definitions.get(toolId); }

    public synchronized ActionProposal propose(ToolRequest request, String reason, List<String> evidence) {
        ToolDefinition d = definitions.get(request == null ? null : request.toolId);
        Validation v = validate(d);
        if (!v.ok) throw new IllegalArgumentException(v.reason);
        ActionProposal p = new ActionProposal(d, request, reason, evidence);
        proposals.put(p.id, p);
        audit("proposal_created", p, null, p.reason);
        return p;
    }

    public synchronized ActionPreview preview(String proposalId) {
        ActionProposal p = proposals.get(proposalId);
        if (p == null) return ActionPreview.deny("proposal_not_found");
        Validation v = validate(p.tool);
        if (!v.ok) return ActionPreview.deny(v.reason);
        ActionPreview preview = handlers.get(p.tool.id).preview(p.request);
        p.preview = preview;
        audit("preview", p, null, preview.reason == null ? "allowed" : preview.reason);
        return preview;
    }

    public synchronized ActionExecutionResult confirmAndExecute(String proposalId, String actor) {
        ActionProposal p = proposals.get(proposalId);
        if (p == null) return ActionExecutionResult.fail("proposal_not_found");
        if (p.status != ActionStatus.PENDING_CONFIRMATION) return ActionExecutionResult.fail("proposal_not_pending");
        Validation v = validate(p.tool);
        if (!v.ok) { p.status=ActionStatus.FAILED; p.failureReason=v.reason; return ActionExecutionResult.fail(v.reason); }
        ActionPreview preview = preview(proposalId);
        if (!preview.allowed) { p.status=ActionStatus.FAILED; p.failureReason=preview.reason; return ActionExecutionResult.fail(preview.reason); }
        // Read-only tools declared without confirmation may execute after the user-triggered proposal/preview.
        // Consequential/device/cross-app tools keep the original explicit-confirmation boundary.
        if (!p.tool.confirmationRequired) {
            p.status = ActionStatus.EXECUTED;
        }
        String operationId = "op_" + UUID.randomUUID();
        ActionExecutionResult result = handlers.get(p.tool.id).execute(p.request, operationId);
        if (result == null || !result.ok || !result.verified) {
            p.status=ActionStatus.FAILED; p.failureReason=result == null ? "handler_failed" : (result.reason == null ? "execution_not_verified" : result.reason);
            audit("execution_failed", p, operationId, p.failureReason);
            return result == null ? ActionExecutionResult.fail("handler_failed") : result;
        }
        p.status=ActionStatus.EXECUTED; p.operationId=operationId; executedRequests.put(operationId, p.request);
        audit("executed", p, operationId, "confirmed_by=" + (actor == null ? "human" : actor));
        return result;
    }

    public synchronized ActionExecutionResult undo(String operationId, String actor) {
        ToolRequest request = executedRequests.get(operationId);
        if (request == null) return ActionExecutionResult.fail("operation_not_found_or_not_undoable");
        ToolDefinition d = definitions.get(request.toolId);
        if (d == null) return ActionExecutionResult.fail("tool_not_registered");
        ActionExecutionResult result = handlers.get(d.id).undo(request, operationId);
        if (result == null || !result.ok || !result.verified) return result == null ? ActionExecutionResult.fail("undo_failed") : result;
        for (ActionProposal p : proposals.values()) if (operationId.equals(p.operationId)) p.status=ActionStatus.UNDONE;
        audit("undone", null, operationId, "confirmed_by=" + (actor == null ? "human" : actor));
        return result;
    }

    public synchronized boolean cancel(String proposalId) {
        ActionProposal p=proposals.get(proposalId); if(p==null || p.status!=ActionStatus.PENDING_CONFIRMATION)return false;
        p.status=ActionStatus.CANCELLED; audit("cancelled",p,null,"human_cancel"); return true;
    }

    public synchronized List<ActionProposal> pending() { List<ActionProposal> out=new ArrayList<>(); for(ActionProposal p:proposals.values())if(p.status==ActionStatus.PENDING_CONFIRMATION)out.add(p); return Collections.unmodifiableList(out); }
    public synchronized List<ActionProposal> allProposals() { return Collections.unmodifiableList(new ArrayList<>(proposals.values())); }

    private Validation validate(ToolDefinition d) {
        if (d == null) return new Validation(false,"tool_not_registered");
        EducationalPurposeFirewall.Decision f=firewall.evaluate(d); if(!f.allowed)return new Validation(false,f.reason);
        for(String permission:d.requiredPermissions) if(!permissions.isGranted(permission)) return new Validation(false,"permission_not_granted:"+permission);
        if(!handlers.containsKey(d.id)) return new Validation(false,"handler_not_registered");
        return new Validation(true,null);
    }

    private void audit(String event, ActionProposal p, String op, String detail) {
        if(repository==null)return;
        String proposal=p==null?"":p.id, tool=p==null?"":p.tool.id;
        String payload=escape(event)+"|"+escape(proposal)+"|"+escape(op)+"|"+escape(tool)+"|"+Instant.now()+"|"+escape(detail);
        String old=repository.getJson(AUDIT_KEY); List<String> rows=new ArrayList<>(); if(old!=null&&!old.isEmpty())rows.addAll(Arrays.asList(old.split("\\n")));
        rows.add(payload); while(rows.size()>MAX_AUDIT)rows.remove(0); repository.putJson(AUDIT_KEY,String.join("\n",rows),"actions",1);
    }
    private static String escape(String s){return String.valueOf(s==null?"":s).replace("\\","\\\\").replace("|","\\|").replace("\n"," ");}
    private static final class Validation {final boolean ok;final String reason;Validation(boolean o,String r){ok=o;reason=r;}}
}
