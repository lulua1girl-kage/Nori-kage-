package com.nori.jarvis.nori.understanding;

import java.util.*;

/**
 * Converts a user's goal/confusion into app understanding: feature discovery,
 * manual guide selection, or an action preview. It does not execute anything.
 */
public final class NoriAppUnderstandingEngine {
    public enum Intent { CONFUSED, FIND_FEATURE, EXPLAIN, GUIDE, REQUEST_ACTION, ASK_CAPABILITY, UNKNOWN }
    public static final class Result {
        public final Intent intent; public final String message; public final List<NoriAppCapabilityCatalog.Capability> matches;
        public final NoriGuideEngine.Guide guide; public final boolean actionRequested; public final boolean needsClarification;
        Result(Intent i,String m,List<NoriAppCapabilityCatalog.Capability> x,NoriGuideEngine.Guide g,boolean a,boolean c){intent=i;message=m;matches=x;guide=g;actionRequested=a;needsClarification=c;}
    }
    private final NoriAppCapabilityCatalog catalog; private final NoriGuideEngine guides;
    public NoriAppUnderstandingEngine(){catalog=new NoriAppCapabilityCatalog();guides=new NoriGuideEngine();}
    public Result understand(String text){
        String q=norm(text); Intent intent=classify(q); List<NoriAppCapabilityCatalog.Capability> matches=catalog.search(q,5);
        if(intent==Intent.CONFUSED && matches.isEmpty())return new Result(intent,"Nori understands that you are lost, but not the destination yet. Tell me the goal in plain language.",matches,guides.get("guide-confusion"),false,true);
        if(intent==Intent.GUIDE || intent==Intent.CONFUSED){NoriAppCapabilityCatalog.Capability c=matches.isEmpty()?null:matches.get(0);NoriGuideEngine.Guide g=c==null?guides.get("guide-confusion"):guides.get(c.guideId);return new Result(intent,"I can guide you without taking the action for you.",matches,g,false,false);}
        if(intent==Intent.REQUEST_ACTION){return new Result(intent,"I understand the requested outcome. I can prepare an action preview, but understanding does not authorize execution.",matches,null,true,matches.isEmpty());}
        if(intent==Intent.ASK_CAPABILITY || intent==Intent.EXPLAIN || intent==Intent.FIND_FEATURE){return new Result(intent,matches.isEmpty()?"I do not have a confident feature match yet. I can give you a manual route if you describe the goal.":"I found the closest Nori capabilities. You can open one, ask for a guide, or request an action explicitly.",matches,null,false,matches.isEmpty());}
        return new Result(Intent.UNKNOWN,"I need the goal or feature you want before I can help.",matches,guides.get("guide-confusion"),false,true);
    }
    public NoriAppCapabilityCatalog getCatalog(){return catalog;}
    public NoriGuideEngine getGuideEngine(){return guides;}
    private Intent classify(String q){
        if(q.matches(".*(i('?m| am) (lost|confused)|don'?t know what to do|where should i go|how do i use nori|help me find|i can'?t find).*"))return Intent.CONFUSED;
        if(q.matches(".*(what can you do|can you do|are you able|what feature|is there a way|capabilit).*"))return Intent.ASK_CAPABILITY;
        if(q.matches(".*(show me how|guide me|walk me through|how do i|manual guide|teach me how).*"))return Intent.GUIDE;
        if(q.matches(".*(open|go to|take me to|switch to|navigate to|show .* page).*"))return Intent.FIND_FEATURE;
        if(q.matches(".*(do it|do this|make|create|set|start|send|change|schedule|run|scan|record|add|remove|enable|disable).*"))return Intent.REQUEST_ACTION;
        return q.isEmpty()?Intent.UNKNOWN:Intent.EXPLAIN;
    }
    private static String norm(String s){return String.valueOf(s==null?"":s).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]+"," ").replaceAll("\\s+"," ").trim();}
}
