package com.nori.jarvis.nori.cloud;

import com.nori.jarvis.nori.identity.NoriUserIdentity;
import java.util.*;

/** Provider-neutral cloud plan. Supabase resumable object storage is the preferred implementation when configured; Firebase is a fallback. */
public final class NoriCloudStorageRouter {
    public enum Backend { SUPABASE_TUS, FIREBASE_RESUMABLE, DOCUMENT_PROVIDER }
    public static final class UploadPlan { public final Backend backend; public final String objectKey; public final boolean resumable; public final boolean localCopyRequired; public final String reason; public UploadPlan(Backend b,String k,boolean r,boolean l,String x){backend=b;objectKey=k;resumable=r;localCopyRequired=l;reason=x;} }
    private final NoriUserIdentity identity;
    public NoriCloudStorageRouter(NoriUserIdentity i){identity=i;}
    public UploadPlan plan(Backend preferred,String fileId){Backend b=preferred==null?Backend.SUPABASE_TUS:preferred;return new UploadPlan(b,identity.libraryScope()+"/objects/"+(fileId==null?"unknown":fileId),b!=Backend.DOCUMENT_PROVIDER,false,"Original file bytes live in the selected provider; Nori keeps only bounded cache/index data locally.");}
    public String selectionRule(){return "Use cloud object storage for the 15 GB logical library; use Android document providers for user-owned files; use resumable uploads for large files; never make 15 GB a required on-device allocation.";}
}
