package com.nori.jarvis.nori.web.engine;

import java.util.Locale;

/** Lightweight parser for local text/HTML. Binary formats are intentionally left to Android/document providers. */
public final class DocumentParser {
    public String parse(String mimeType, String name, String raw) {
        if(raw==null) return "";
        String m=(mimeType==null?"":mimeType).toLowerCase(Locale.ROOT);
        String n=(name==null?"":name).toLowerCase(Locale.ROOT);
        boolean html=m.contains("html") || n.endsWith(".html") || n.endsWith(".htm");
        if(html) return normalize(raw.replaceAll("(?is)<script[^>]*>.*?</script>"," ").replaceAll("(?is)<style[^>]*>.*?</style>"," ").replaceAll("(?s)<[^>]+>"," "));
        return normalize(raw);
    }
    private String normalize(String s){ return s.replace('\u00a0',' ').replaceAll("[ \\t]+"," ").replaceAll("\\r\\n?","\\n").replaceAll("\\n{3,}","\\n\\n").trim(); }
}
