package com.nori.jarvis.nori.memory.context;

import com.nori.jarvis.nori.memory.MemoryEngine;
import com.nori.jarvis.nori.memory.MemoryItem;
import java.util.*;

/**
 * Decision-time memory retrieval. It turns durable memory into a small, governed working set.
 * It intentionally uses the existing memory store rather than introducing a vector database.
 */
public final class NoriMemoryContext {
    public final List<MemoryItem> memories;
    public final String compactContext;
    public final boolean conflictDetected;
    public final boolean staleRisk;

    private NoriMemoryContext(List<MemoryItem> m, String c, boolean conflict, boolean stale) {
        memories=Collections.unmodifiableList(new ArrayList<>(m)); compactContext=c; conflictDetected=conflict; staleRisk=stale;
    }

    public static NoriMemoryContext build(MemoryEngine engine, String query, int limit) {
        if (engine == null) return new NoriMemoryContext(Collections.emptyList(), "", false, false);
        List<MemoryItem> raw = engine.recall(query == null ? "" : query, Math.max(1, Math.min(limit, 12)));
        List<MemoryItem> selected = new ArrayList<>();
        Map<String, MemoryItem> topic = new HashMap<>();
        boolean conflict=false, stale=false;
        long now=System.currentTimeMillis();
        for (MemoryItem item : raw) {
            String key=topicKey(item.text);
            MemoryItem prior=topic.get(key);
            if (prior != null && !prior.text.equalsIgnoreCase(item.text)) {
                conflict=true;
                if (item.confidence > prior.confidence || newer(item, prior)) topic.put(key,item);
            } else topic.put(key,item);
            if (ageDays(item.updatedAt, now) > 180 && item.importance >= 3) stale=true;
        }
        selected.addAll(topic.values());
        selected.sort(Comparator.comparingDouble(NoriMemoryContext::utility).reversed());
        if (selected.size() > limit) selected=new ArrayList<>(selected.subList(0, limit));
        StringBuilder b=new StringBuilder();
        for (MemoryItem x:selected) {
            if (b.length()>0) b.append(" | ");
            b.append(x.category.name()).append(": ").append(x.text).append(" [confidence=").append(String.format(Locale.ROOT,"%.2f",x.confidence)).append("]");
        }
        return new NoriMemoryContext(selected,b.toString(),conflict,stale);
    }

    private static double utility(MemoryItem x){ return x.importance*1.5 + x.confidence + freshness(x.updatedAt)*1.25; }
    private static double freshness(String t){ return Math.exp(-ageDays(t,System.currentTimeMillis())/120.0); }
    private static long ageDays(String t,long now){ try{return Math.max(0,(now-java.time.Instant.parse(t).toEpochMilli())/86400000L);}catch(Exception e){return 0;} }
    private static boolean newer(MemoryItem a, MemoryItem b){ try{return java.time.Instant.parse(a.updatedAt).isAfter(java.time.Instant.parse(b.updatedAt));}catch(Exception e){return false;} }
    private static String topicKey(String text){
        String s=text==null?"":text.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]"," ").replaceAll("\\s+"," ").trim();
        String[] p=s.split(" ");
        return p.length==0?s:(p.length<=3?s:String.join(" ",Arrays.copyOf(p,Math.min(4,p.length))));
    }
}
