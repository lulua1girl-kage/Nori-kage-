package com.nori.jarvis.visual;
import com.nori.jarvis.nori.exam.NoriExamIntegrityService;

import android.app.*;
import android.content.*;
import android.util.Base64;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import java.io.*;
import java.nio.file.*;

@CapacitorPlugin(name="NoriVisual")
public class NoriVisualPlugin extends Plugin {
    private static final int REQ_CAMERA=9201, REQ_SCREEN=9202;
    private BroadcastReceiver receiver;
    @Override public void load(){
        receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){
            String path=i.getStringExtra("path"); String err=i.getStringExtra("error");
            if(NoriExamIntegrityService.EVENT_SUSPICIOUS.equals(i.getAction())){JSObject d=new JSObject();d.put("ok",false);d.put("suspicious",true);d.put("evidence",i.getStringExtra("text"));notifyListeners("examSuspicious",d);return;}
            if(NoriExamIntegrityService.EVENT_SCREEN.equals(i.getAction())){try{JSObject d=new JSObject();d.put("ok",true);d.put("review",true);d.put("packageName",i.getStringExtra("packageName"));d.put("trigger",i.getStringExtra("trigger"));d.put("confidence",i.getStringExtra("confidence"));d.put("mimeType","image/jpeg");String b64=readBase64(path); d.put("dataUrl","data:image/jpeg;base64,"+b64); try { com.nori.jarvis.nori.brain.NoriBrain brain=new com.nori.jarvis.nori.brain.NoriBrain(); org.json.JSONObject ex=new org.json.JSONObject(getContext().getSharedPreferences("nori_exam_policy",0).getString("active_exam_context","{}")); com.nori.jarvis.nori.brain.visual.NoriScreenSemanticAnalyzer.Result sr=brain.getScreenSemanticAnalyzer().analyze(i.getStringExtra("packageName"),i.getStringExtra("trigger"),i.getStringExtra("confidence"),b64,ex.optString("subject","")); d.put("semanticSummary",sr.summary); d.put("semanticConfidence",sr.confidence); d.put("semanticClass",sr.classification); } catch(Exception ignored) {} notifyListeners("examScreenReview",d);new java.io.File(path).delete();}catch(Exception e){JSObject d=new JSObject();d.put("ok",false);d.put("error",e.getMessage());notifyListeners("examScreenError",d);}return;}
            if(NoriScreenCaptureService.EVENT_ERROR.equals(i.getAction())){JSObject d=new JSObject();d.put("ok",false);d.put("error",err==null?"Screen capture failed":err);notifyListeners("screenError",d);return;}
            if(path==null){return;} try{String b64=readBase64(path);JSObject d=new JSObject();d.put("ok",true);d.put("mimeType","image/jpeg");d.put("dataUrl","data:image/jpeg;base64,"+b64);notifyListeners("screenContext",d);new File(path).delete();}catch(Exception e){JSObject d=new JSObject();d.put("ok",false);d.put("error",e.getMessage());notifyListeners("screenError",d);}
        }};
        IntentFilter f=new IntentFilter();f.addAction(NoriScreenCaptureService.EVENT_RESULT);f.addAction(NoriScreenCaptureService.EVENT_ERROR);f.addAction(NoriExamIntegrityService.EVENT_SCREEN);f.addAction(NoriExamIntegrityService.EVENT_SUSPICIOUS);getContext().registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);
    }
    @Override protected void handleOnDestroy(){if(receiver!=null)try{getContext().unregisterReceiver(receiver);}catch(Exception ignored){} }

    @PluginMethod public void captureCamera(PluginCall call){
        Intent i=new Intent(getContext(),NoriCameraActivity.class);startActivityForResult(call,i,"cameraResult");
    }
    @ActivityCallback public void cameraResult(PluginCall call,ActivityResult result){
        if(result==null||result.getResultCode()!=Activity.RESULT_OK){call.reject(result!=null&&result.getData()!=null?result.getData().getStringExtra("error"):"Camera capture canceled");return;}
        String path=result.getData().getStringExtra("path"); if(path==null){call.reject("Camera returned no image");return;}
        try{JSObject d=new JSObject();d.put("ok",true);d.put("mimeType","image/jpeg");d.put("dataUrl","data:image/jpeg;base64,"+readBase64(path));notifyListeners("cameraContext",d);d.put("dataUrl",d.getString("dataUrl"));call.resolve(d);new File(path).delete();}catch(Exception e){call.reject("Camera image could not be read: "+e.getMessage());}
    }

    @PluginMethod public void captureScreen(PluginCall call){
        android.media.projection.MediaProjectionManager m=(android.media.projection.MediaProjectionManager)getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(call,m.createScreenCaptureIntent(),"screenConsent");
    }
    @ActivityCallback public void screenConsent(PluginCall call,ActivityResult result){
        if(result==null||result.getResultCode()!=Activity.RESULT_OK||result.getData()==null){call.reject("Screen capture permission was canceled");return;}
        Intent s=new Intent(getContext(),NoriScreenCaptureService.class);s.setAction(NoriScreenCaptureService.ACTION_CAPTURE);s.putExtra("resultCode",result.getResultCode());s.putExtra("data",result.getData());
        if(android.os.Build.VERSION.SDK_INT>=26)getContext().startForegroundService(s);else getContext().startService(s);
        JSObject out=new JSObject(); out.put("ok",true); out.put("started",true); call.resolve(out);
    }
    private String readBase64(String path)throws Exception{return Base64.encodeToString(Files.readAllBytes(new File(path).toPath()),Base64.NO_WRAP);}
}
