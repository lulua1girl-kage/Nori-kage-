package com.nori.jarvis.nori.advanced.model;

import java.util.*;

public final class TrajectoryReport {
    public final String subject; public final int observations; public final double slopePerObservation;
    public final String direction; public final double stability; public final double confidence;
    public final List<String> evidence;
    public TrajectoryReport(String subject,int observations,double slope,String direction,double stability,double confidence,List<String> evidence){
        this.subject=subject;this.observations=observations;this.slopePerObservation=slope;this.direction=direction;this.stability=stability;this.confidence=confidence;this.evidence=Collections.unmodifiableList(new ArrayList<>(evidence));
    }
}
