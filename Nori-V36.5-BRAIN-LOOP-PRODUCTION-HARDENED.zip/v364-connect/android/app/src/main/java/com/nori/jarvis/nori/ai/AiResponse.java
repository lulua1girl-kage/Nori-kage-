package com.nori.jarvis.nori.ai;

/** Normalized provider result. */
public final class AiResponse {
    public enum Status { SUCCESS, UNAVAILABLE, ERROR, BLOCKED }
    public final Status status;
    public final String text;
    public final String providerId;
    public final String reason;
    public final boolean remote;

    private AiResponse(Status status, String text, String providerId, String reason, boolean remote) {
        this.status=status; this.text=text; this.providerId=providerId; this.reason=reason; this.remote=remote;
    }
    public static AiResponse success(String provider, String text, boolean remote){return new AiResponse(Status.SUCCESS,text,provider,null,remote);}
    public static AiResponse unavailable(String provider, String reason){return new AiResponse(Status.UNAVAILABLE,"",provider,reason,false);}
    public static AiResponse error(String provider, String reason){return new AiResponse(Status.ERROR,"",provider,reason,false);}
    public static AiResponse blocked(String provider, String reason){return new AiResponse(Status.BLOCKED,"",provider,reason,false);}
}
