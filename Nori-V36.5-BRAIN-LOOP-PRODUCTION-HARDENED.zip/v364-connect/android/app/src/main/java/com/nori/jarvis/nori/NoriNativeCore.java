package com.nori.jarvis.nori;

import com.nori.jarvis.nori.data.DataRepository;

/**
 * Native Nori foundation.
 *
 * This class is intentionally not connected to MainActivity yet.
 * Stage 1 establishes the native architecture without replacing
 * the working V32 hybrid UI or Brain.
 */
public final class NoriNativeCore {
    private final brain.NoriBrain brain;

    public NoriNativeCore() { this(null); }

    public NoriNativeCore(DataRepository repository) {
        this.brain = new brain.NoriBrain(repository);
    }

    public brain.NoriBrain getBrain() {
        return brain;
    }
}
