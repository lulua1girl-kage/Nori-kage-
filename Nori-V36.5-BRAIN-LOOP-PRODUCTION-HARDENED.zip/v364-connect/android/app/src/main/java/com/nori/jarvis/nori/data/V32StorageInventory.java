package com.nori.jarvis.nori.data;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * First-pass inventory of stable V32 storage keys identified during Stage 2.
 * Dynamic nori_phase_* keys are intentionally represented by their prefix.
 */
public final class V32StorageInventory {
    private V32StorageInventory() {}

    public static final List<String> CORE_KEYS = Collections.unmodifiableList(Arrays.asList(
            "nori_eval_history_all_subjects",
            "nori_override_history_all_subjects",
            "nori_breach_history_by_category",
            "nori_command_assignments",
            "nori_daily_routine",
            "nori_user_memory",
            "nori_study_sessions",
            "nori_exams",
            "nori_notifications",
            "nori_system_events",
            "nori_calendar_events_v1",
            "nori_calendar_exceptions_v1",
            "nori_voice_alarms",
            "nori_brain_state",
            "nori_privacy_controls_v20",
            "nori_v26_profile",
            "nori_v31_profile",
            "nori_v31_chats",
            "nori_v31_updates",
            "nori_action_core_v27",
            "nori_action_core_v27/operations",
            "nori_action_core_v27/proposals",
            "nori_adaptive_kage_v19",
            "nori_adaptive_override_log_v19",
            "nori_adaptive_events_v19",
            "nori_adaptive_replans_v19",
            "nori_smart_plan_v1",
            "nori_smart_diagnostic_v1",
            "nori_smart_timeline_v1",
            "nori_smart_settings_v1",
            "nori_brain_memory_v13",
            "nori_academic_profile_v13",
            "nori_brain_events_v13",
            "nori_brain_prefs_v13",
            "nori_v27_self_improve_lab",
            "nori_v29_sandbox_experiments",
            "nori_visual_theme_v1",
            "nori_voice_mode_v21",
            "nori_v26_pip",
            "nori_tier4_v1",
            "nori_decide_state (stored as nori_brain_state)"
    ));

    public static final String DYNAMIC_PHASE_PREFIX = "nori_phase_";

    public static boolean isNoriKey(String key) {
        return key != null && key.startsWith("nori_");
    }
}
