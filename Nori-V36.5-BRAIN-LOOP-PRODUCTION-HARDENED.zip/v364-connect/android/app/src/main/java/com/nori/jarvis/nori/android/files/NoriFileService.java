package com.nori.jarvis.nori.android.files;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;

/** File boundary based on Android's Storage Access Framework. No broad storage permission is required. */
public final class NoriFileService {
    public Intent openDocumentIntent(String[] mimeTypes) {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");
        if (mimeTypes != null && mimeTypes.length > 0) i.putExtra(Intent.EXTRA_MIME_TYPES, mimeTypes);
        return i;
    }
    public Intent createDocumentIntent(String mimeType, String suggestedName) {
        return new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                .setType(mimeType == null ? "application/octet-stream" : mimeType)
                .putExtra(Intent.EXTRA_TITLE, suggestedName == null ? "Nori file" : suggestedName);
    }
    public void openDocument(Activity activity, int requestCode, String[] mimeTypes) { activity.startActivityForResult(openDocumentIntent(mimeTypes), requestCode); }
    public void createDocument(Activity activity, int requestCode, String mimeType, String suggestedName) { activity.startActivityForResult(createDocumentIntent(mimeType, suggestedName), requestCode); }
    public static boolean isContentUri(Uri uri) { return uri != null && "content".equalsIgnoreCase(uri.getScheme()); }
}
