package com.nori.jarvis.nori.creative;

import com.nori.jarvis.nori.safety.NoriYouthMediaSafety;
import java.util.*;

/**
 * Provider-neutral image-generation planner. It makes image generation a real,
 * inspectable capability without pretending that the local app contains a
 * frontier image model. A configured ImageProvider performs the actual render.
 */
public final class NoriImageGenerationEngine {
    public enum Aspect { SQUARE, PORTRAIT, LANDSCAPE, WIDE, TALL }
    public enum Quality { FAST, STANDARD, HIGH, ULTRA }
    public enum Mode { CREATE, EDIT, VARIATION, INPAINT, OUTPAINT, STORYBOARD, DIAGRAM }
    public enum Safety { ALLOW, REVIEW, BLOCK }

    public static final class Request {
        public final String prompt, style, negativePrompt, referenceId;
        public final Aspect aspect; public final Quality quality; public final Mode mode;
        public final int variants; public final boolean transparent;
        public Request(String prompt,String style,String negativePrompt,String referenceId,
                       Aspect aspect,Quality quality,Mode mode,int variants,boolean transparent){
            this.prompt=prompt==null?"":prompt.trim(); this.style=style==null?"":style.trim();
            this.negativePrompt=negativePrompt==null?"":negativePrompt.trim(); this.referenceId=referenceId==null?"":referenceId.trim();
            this.aspect=aspect==null?Aspect.SQUARE:aspect; this.quality=quality==null?Quality.STANDARD:quality;
            this.mode=mode==null?Mode.CREATE:mode; this.variants=Math.max(1,Math.min(4,variants)); this.transparent=transparent;
        }
    }
    public static final class Plan {
        public final Safety safety; public final String normalizedPrompt,reason;
        public final Map<String,String> parameters;
        Plan(Safety s,String p,String r,Map<String,String> params){safety=s;normalizedPrompt=p;reason=r;parameters=Collections.unmodifiableMap(new LinkedHashMap<>(params));}
    }

    /** Minimal provider contract; implementations may use a local or remote model. */
    public interface ImageProvider {
        String id(); boolean isAvailable(); boolean isRemote();
        ImageResult generate(Request request, String normalizedPrompt);
    }
    public static final class ImageResult {
        public final boolean success; public final String providerId,imageDataUrl,imageUrl,message;
        private ImageResult(boolean ok,String id,String data,String url,String msg){success=ok;providerId=id;imageDataUrl=data;imageUrl=url;message=msg;}
        public static ImageResult success(String id,String data,String url){return new ImageResult(true,id,data,url,"ok");}
        public static ImageResult failure(String id,String msg){return new ImageResult(false,id,"","",msg);}
    }

    private final NoriYouthMediaSafety mediaSafety;
    private ImageProvider provider;
    public NoriImageGenerationEngine(NoriYouthMediaSafety safety){mediaSafety=safety;}
    public synchronized void setProvider(ImageProvider p){provider=p;}
    public synchronized ImageProvider getProvider(){return provider;}

    public Plan plan(Request r){
        if(r==null||r.prompt.isEmpty()) return new Plan(Safety.REVIEW,"","A clear image request is required.",Collections.emptyMap());
        String p=(r.prompt+ (r.style.isEmpty()?"":"; style: "+r.style)).trim();
        Safety safety=Safety.ALLOW; String reason="request is within the image-generation boundary";
        // Keep the final safety decision with the existing youth-safety layer when available.
        if(mediaSafety!=null){
            try {
                if(mediaSafety.unnecessaryImageRequest(p)) { safety=Safety.BLOCK; reason="media safety policy blocked this request"; }
            } catch(Exception ignored) { safety=Safety.REVIEW; reason="safety evaluation unavailable"; }
        }
        Map<String,String> m=new LinkedHashMap<>();
        m.put("aspect",r.aspect.name().toLowerCase(Locale.ROOT)); m.put("quality",r.quality.name().toLowerCase(Locale.ROOT));
        m.put("mode",r.mode.name().toLowerCase(Locale.ROOT)); m.put("variants",String.valueOf(r.variants)); m.put("transparent",String.valueOf(r.transparent));
        if(!r.negativePrompt.isEmpty())m.put("negativePrompt",r.negativePrompt);
        if(!r.referenceId.isEmpty())m.put("referenceId",r.referenceId);
        return new Plan(safety,p,reason,m);
    }
    public synchronized ImageResult generate(Request r){
        Plan p=plan(r); if(p.safety!=Safety.ALLOW)return ImageResult.failure("nori","image_generation_"+p.safety.name().toLowerCase(Locale.ROOT));
        if(provider==null||!provider.isAvailable())return ImageResult.failure("nori","no_image_provider_configured");
        return provider.generate(r,p.normalizedPrompt);
    }
}
