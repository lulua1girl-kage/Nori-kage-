package com.nori.jarvis.nori.brain.human;

/** Final non-clinical support snapshot intended for Brain coordination, not a user-facing diagnosis. */
public final class NoriHumanAssessment {
    public final HumanContextEngine.Assessment context;
    public final NoriSupportPolicy.Guidance guidance;
    public final String principle;
    public NoriHumanAssessment(HumanContextEngine.Assessment c,NoriSupportPolicy.Guidance g,String p){context=c;guidance=g;principle=p;}
}
