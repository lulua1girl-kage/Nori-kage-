package com.nori.jarvis.nori.integrity;

import java.util.*;

/**
 * Stage 13 integrity coordinator. It separates academic failure from integrity breach,
 * applies proportionality, protects Human Override, and detects repeated system failure.
 */
public final class IntegrityEngine {
    public enum BreachStatus { NOT_BREACH, BREACH, REVIEW }
    public enum SystemFailureCause { NONE, RULE_FAILURE, ENVIRONMENT_FAILURE, RESTORATION_FAILURE, CONTROL_FAILURE, SYSTEM_MISUSE }
    private final HumanOverrideGuard overrideGuard = new HumanOverrideGuard();

    public BreachAssessment classify(boolean knowinglyDisplacedPriority, boolean deliberateDelay,
                                     boolean bypassedRestriction, boolean concealed, boolean repeatedDiscretionaryChoice,
                                     boolean fatigue, boolean emergency, boolean honestMistake, boolean necessaryCommunication,
                                     boolean legitimateOverride) {
        boolean excluded = fatigue || emergency || honestMistake || necessaryCommunication || legitimateOverride;
        boolean positive = knowinglyDisplacedPriority || deliberateDelay || bypassedRestriction || concealed || repeatedDiscretionaryChoice;
        if (excluded && !bypassedRestriction && !concealed) return new BreachAssessment(BreachStatus.NOT_BREACH,"legitimate_or_non_integrity_circumstance");
        if (concealed || bypassedRestriction || positive) return new BreachAssessment(BreachStatus.BREACH, concealed?"false_status_or_concealment":"meaningful_integrity_violation");
        return new BreachAssessment(BreachStatus.NOT_BREACH,"execution_failure_without_integrity_evidence");
    }

    public ProportionalityCheck checkProportionality(int severity, int consequenceSeverity, boolean affectsEssentialNeed, boolean createsNewFailure){
        int s=Math.max(1,Math.min(5,severity)), c=Math.max(1,Math.min(5,consequenceSeverity));
        if(affectsEssentialNeed) return new ProportionalityCheck(false,"essential_need_protected");
        if(createsNewFailure) return new ProportionalityCheck(false,"consequence_creates_greater_damage");
        if(c>s+1) return new ProportionalityCheck(false,"consequence_exceeds_proportionality_ceiling");
        return new ProportionalityCheck(true,"proportional_for_review");
    }

    public SystemFailureAssessment assessSystemFailure(int sameConsequenceFailures, boolean ruleUnclear, boolean stillAccessible,
                                                        boolean damageUnrestored, boolean easilyCircumvented, boolean academicObjectiveNeglected){
        if(sameConsequenceFailures<=0) return new SystemFailureAssessment(SystemFailureCause.NONE,"no_repeated_consequence_failure");
        if(ruleUnclear) return new SystemFailureAssessment(SystemFailureCause.RULE_FAILURE,"clarify_or_redesign_rule");
        if(stillAccessible) return new SystemFailureAssessment(SystemFailureCause.ENVIRONMENT_FAILURE,"modify_environment_or_friction");
        if(damageUnrestored) return new SystemFailureAssessment(SystemFailureCause.RESTORATION_FAILURE,"repair_academic_damage_first");
        if(easilyCircumvented) return new SystemFailureAssessment(SystemFailureCause.CONTROL_FAILURE,"repair_control_boundary");
        if(academicObjectiveNeglected) return new SystemFailureAssessment(SystemFailureCause.SYSTEM_MISUSE,"restore_academic_objective_focus");
        return new SystemFailureAssessment(SystemFailureCause.CONTROL_FAILURE,"review_consequence_instead_of_making_it_harsher");
    }

    public HumanOverrideGuard.Assessment evaluateOverride(String category,int importance,int weakness,int difficulty,int immediacy,int evidence,int impact,int repeatCount){
        return overrideGuard.assess(category,importance,weakness,difficulty,immediacy,evidence,impact,repeatCount);
    }

    public static final class BreachAssessment { public final BreachStatus status; public final String reason; BreachAssessment(BreachStatus s,String r){status=s;reason=r;} }
    public static final class ProportionalityCheck { public final boolean allowed; public final String reason; ProportionalityCheck(boolean a,String r){allowed=a;reason=r;} }
    public static final class SystemFailureAssessment { public final SystemFailureCause cause; public final String action; SystemFailureAssessment(SystemFailureCause c,String a){cause=c;action=a;} }
}
