package com.nori.jarvis.nori.integrity;

import java.util.*;
import java.util.regex.Pattern;

/** Hard safety gate for disciplinary consequences. Unsafe consequences are never valid candidates. */
public final class ConsequenceSafetyGuard {
    private static final Pattern BANNED = Pattern.compile(
        "\\b(exercise|push[- ]?ups?|sit[- ]?ups?|planks?|cold|showers?|ice|starv\\w*|hunger|sleep[- ]?depriv\\w*|pain|hurt|humiliat\\w*|degrad\\w*|shame|insult|threat|intimidat\\w*|physical|food[- ]?restriction|meal[- ]?skip)\\b", Pattern.CASE_INSENSITIVE);
    private static final Set<String> SAFE_DOMAINS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        "digital_access","planning","research","hobby","gaming","academic_rabbit_hole","creative_hobby","recovery","academic"
    )));
    private ConsequenceSafetyGuard() {}

    public static Check check(String id, String label, String description, String domain, boolean physical) {
        if (physical) return new Check(false, "physical_consequence_forbidden");
        if (domain == null || !SAFE_DOMAINS.contains(domain)) return new Check(false, "unrecognized_consequence_domain");
        String text = normalize((id == null ? "" : id) + " " + (label == null ? "" : label) + " " + (description == null ? "" : description));
        if (BANNED.matcher(text).find()) return new Check(false, "unsafe_pattern_detected");
        return new Check(true, "safe_for_review");
    }
    private static String normalize(String s){ return s.replace('_',' ').replace('-',' '); }
    public static final class Check { public final boolean allowed; public final String reason; Check(boolean a,String r){allowed=a;reason=r;} }
}
