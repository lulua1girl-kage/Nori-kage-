package com.nori.jarvis.nori.admin.model;

public final class AdminAuditRecord {
    public final String eventId;
    public final String actorId;
    public final String action;
    public final String targetId;
    public final long timestamp;
    public final boolean allowed;

    public AdminAuditRecord(String eventId, String actorId, String action, String targetId, long timestamp, boolean allowed) {
        this.eventId = eventId;
        this.actorId = actorId;
        this.action = action;
        this.targetId = targetId;
        this.timestamp = timestamp;
        this.allowed = allowed;
    }
}
