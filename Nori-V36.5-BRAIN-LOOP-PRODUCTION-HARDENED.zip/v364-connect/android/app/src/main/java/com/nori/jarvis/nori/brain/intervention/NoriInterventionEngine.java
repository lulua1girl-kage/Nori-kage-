package com.nori.jarvis.nori.brain.intervention;

import java.time.Instant;
import java.util.*;

/**
 * Decides whether intervention is useful now, which bounded intervention to try,
 * and whether it actually helped. It favors minimal sufficient intervention and autonomy.
 */
public final class NoriInterventionEngine {
    public enum Urgency { NONE, LOW, MODERATE, HIGH }
    public enum Action { NONE, REMINDER, CLARIFY, REDUCE_LOAD, SMALL_START, PLAN, RECOVER, CHECK_IN, ESCALATE_TO_HUMAN }
    public static final class Signal { public final double need,capacity,urgency,distraction,availability; public final boolean userRequested;
        public Signal(double n,double c,double u,double d,double a,boolean r){need=clamp(n);capacity=clamp(c);urgency=clamp(u);distraction=clamp(d);availability=clamp(a);userRequested=r;}}
    public static final class PreferenceOutcome { public final String preference; public final Action action; public final double effectiveness; public final int trials; public PreferenceOutcome(String p,Action a,double e,int t){preference=p;action=a;effectiveness=clamp(e);trials=Math.max(0,t);} }
    public static final class Proposal { public final boolean intervene; public final Urgency urgency; public final Action action; public final double expectedUsefulness; public final double confidence; public final String reason; public final boolean preservesAutonomy; public final boolean dependencyRisk; public final String timing;
        Proposal(boolean i,Urgency u,Action a,double eu,double c,String r,boolean pa,boolean dr,String t){intervene=i;urgency=u;action=a;expectedUsefulness=clamp(eu);confidence=clamp(c);reason=r;preservesAutonomy=pa;dependencyRisk=dr;timing=t;}}
    private final Map<String,List<Double>> outcomes=new HashMap<>();
    public synchronized void recordOutcome(String preference,Action action,boolean helped){String k=key(preference,action);List<Double> a=outcomes.computeIfAbsent(k,x->new ArrayList<>());a.add(helped?1d:0d);if(a.size()>30)a.remove(0);}
    public synchronized PreferenceOutcome effectiveness(String preference,Action action){List<Double>a=outcomes.getOrDefault(key(preference,action),Collections.emptyList());double v=0;for(double x:a)v+=x;if(!a.isEmpty())v/=a.size();return new PreferenceOutcome(preference,action,v,a.size());}
    public synchronized Proposal decide(Signal s,String preference,List<PreferenceOutcome> known,boolean protectedWindow){
        if(s==null)return new Proposal(false,Urgency.NONE,Action.NONE,0,.2,"no reliable situation signal",true,false,"wait");
        if(protectedWindow)return new Proposal(false,Urgency.NONE,Action.NONE,0,.95,"protected window: do not add non-essential intervention",true,false,"later");
        double pressure=s.need*(.45+.55*s.urgency), capacity=1-s.capacity, friction=.45*s.distraction+.35*capacity+.20*(1-s.availability);
        double threshold=s.userRequested?.10:.52;
        if(pressure+friction<threshold)return new Proposal(false,Urgency.NONE,Action.NONE,pressure+friction,.72,"current evidence does not justify interruption",true,false,"continue");
        Action chosen=choose(preference,known,s,pressure,friction); double learned=knownScore(preference,chosen,known); double usefulness=Math.min(1,.55*pressure+.30*friction+.15*learned);
        boolean dependency=chosen==Action.CHECK_IN && learned<.45 && !s.userRequested;
        if(dependency)chosen=Action.SMALL_START;
        Urgency u=s.urgency>.8?Urgency.HIGH:s.urgency>.55?Urgency.MODERATE:Urgency.LOW;
        return new Proposal(true,u,chosen,usefulness,Math.min(.95,.55+.35*learned),"intervene only when expected usefulness exceeds interruption cost; use the smallest sufficient step",true,dependency,timing(s));
    }
    private Action choose(String pref,List<PreferenceOutcome> known,Signal s,double p,double f){if(s.capacity<.25)return Action.REDUCE_LOAD;if(s.distraction>.7)return Action.SMALL_START;if(pref!=null&&!pref.isEmpty()){for(PreferenceOutcome x:known==null?Collections.<PreferenceOutcome>emptyList():known)if(pref.equalsIgnoreCase(x.preference)&&x.effectiveness>.65)return x.action;}if(s.need>.75)return Action.PLAN;return Action.CLARIFY;}
    private double knownScore(String p,Action a,List<PreferenceOutcome> k){double v=0;int n=0;for(PreferenceOutcome x:k==null?Collections.<PreferenceOutcome>emptyList():k)if(a==x.action&& (p==null||p.equalsIgnoreCase(x.preference))){v+=x.effectiveness;n++;}if(n==0)return effectiveness(p,a).effectiveness;return v/n;}
    private String timing(Signal s){if(s.availability<.25)return "wait_for_availability";if(s.capacity<.25)return "after_capacity_recovery_or_within_low_load";if(s.urgency>.8)return "now";return "next_natural_transition";}
    private static String key(String p,Action a){return (p==null?"":p.toLowerCase(Locale.ROOT))+"|"+a.name();} private static double clamp(double x){return Double.isFinite(x)?Math.max(0,Math.min(1,x)):0;}
}
