package com.nori.jarvis.nori.memory;

import com.nori.jarvis.nori.data.DataRepository;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import com.nori.jarvis.nori.memory.context.NoriMemoryLifecycle;

/**
 * Native Memory 2.0 boundary. Explicit, editable, evidence-backed and local-first.
 * Sensitive/credential-like material is rejected before persistence.
 */
public final class MemoryEngine {
    private static final String INDEX_KEY = "nori.memory.index.v2";
    private static final String ITEM_PREFIX = "nori.memory.item.v2.";
    private static final int MAX_ITEMS = 500;
    private static final Pattern SECRET = Pattern.compile("\\b(sk-[A-Za-z0-9_-]{12,}|ghp_[A-Za-z0-9_]+|AIza[\\w-]+|Bearer\\s+\\S+|password\\s*=|token\\s*=|secret\\s*=)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern SENSITIVE = Pattern.compile("(password|passcode|pin|api key|secret|token|bank|credit card|card number|address|location|medical|diagnos|medication|trauma|abuse|self[- ]?harm|suicide|sexual|private|family conflict|legal case)", Pattern.CASE_INSENSITIVE);

    private final List<MemoryItem> items = new ArrayList<>();
    private final PersonalModel personalModel = new PersonalModel();
    private DataRepository repository;

    public MemoryEngine() { }
    public MemoryEngine(DataRepository repository) { attachRepository(repository); }

    public synchronized void attachRepository(DataRepository repository) {
        this.repository = repository;
        loadPersisted();
    }

    public synchronized MemoryItem remember(String text) {
        return remember(text, null, 1.0, 3, "explicit_user_command", "user_confirmed");
    }

    public synchronized MemoryItem remember(String text, MemoryItem.Category category, double confidence,
                                            int importance, String source, String provenance) {
        String clean = normalize(text);
        PolicyResult policy = policy(clean);
        if (!policy.allowed) return null;
        for (MemoryItem existing : items) {
            if (existing.text.equalsIgnoreCase(clean)) {
                existing.updatedAt = now();
                existing.status = MemoryItem.Status.CONFIRMED;
                existing.confidence = 1.0;
                persist(); rebuildPersonalModel();
                return existing;
            }
        }
        String timestamp = now();
        MemoryItem item = new MemoryItem(
                "mem_" + UUID.randomUUID(), clean, MemoryItem.categoryFor(clean, category),
                MemoryItem.statusFor(confidence), confidence, importance, timestamp, timestamp,
                timestamp, source, provenance);
        items.add(item);
        trim(); persist(); rebuildPersonalModel();
        return item;
    }

    public synchronized MemoryItem update(String id, String text, MemoryItem.Category category,
                                           Double confidence, Integer importance, MemoryItem.Status status) {
        MemoryItem item = find(id);
        if (item == null) return null;
        if (text != null) {
            String clean = normalize(text); PolicyResult policy = policy(clean);
            if (!policy.allowed) return null;
            item.text = clean;
            item.category = MemoryItem.categoryFor(clean, category == null ? item.category : category);
        } else if (category != null) item.category = category;
        if (confidence != null) { item.confidence = clamp(confidence, 0, 1); item.status = MemoryItem.statusFor(item.confidence); }
        if (importance != null) item.importance = (int) clamp(importance, 1, 5);
        if (status != null) item.status = status;
        item.updatedAt = now();
        persist(); rebuildPersonalModel();
        return item;
    }

    public synchronized boolean archive(String id) {
        MemoryItem item = find(id); if (item == null) return false;
        item.status = MemoryItem.Status.ARCHIVED; item.updatedAt = now();
        persist(); rebuildPersonalModel(); return true;
    }

    public synchronized boolean delete(String id) {
        boolean removed = items.removeIf(x -> x.id.equals(id));
        if (removed) { persist(); rebuildPersonalModel(); }
        return removed;
    }

    public synchronized List<MemoryItem> list() {
        return Collections.unmodifiableList(new ArrayList<>(items));
    }

    /** Relevance = lexical overlap + exact match + importance + confidence + recency. */
    public synchronized List<MemoryItem> recall(String query, int limit) {
        String q = normalize(query).toLowerCase(Locale.ROOT);
        Set<String> tokens = tokens(q);
        List<Scored> scored = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (MemoryItem item : items) {
            if (item.status == MemoryItem.Status.ARCHIVED) continue;
            String text = item.text.toLowerCase(Locale.ROOT);
            int overlap = 0; for (String t : tokens) if (tokens(text).contains(t)) overlap++;
            boolean exact = !q.isEmpty() && text.contains(q);
            double ageDays = Math.max(0, (now - parseTime(item.updatedAt)) / 86400000.0);
            double recency = Math.exp(-ageDays / 120.0);
            double score = overlap * 2.8 + (exact ? 3 : 0) + (item.importance / 5.0) * .8 + item.confidence * .7 + recency * .8;
            if (tokens.isEmpty() || overlap > 0 || score >= 3) scored.add(new Scored(item, score));
        }
        scored.sort(Comparator.comparingDouble((Scored x) -> x.score).reversed());
        List<MemoryItem> out = new ArrayList<>(); int max = Math.max(0, limit);
        for (Scored x : scored) { if (out.size() >= max) break; out.add(x.item); }
        return Collections.unmodifiableList(out);
    }

    public synchronized PersonalModel personalModel() { rebuildPersonalModel(); return personalModel.snapshot(); }
    public synchronized int size() { return items.size(); }
    /** Decision-time lifecycle audit: identifies decay/consolidation candidates without mutating memory. */
    public synchronized NoriMemoryLifecycle.Audit lifecycleAudit() { return NoriMemoryLifecycle.audit(this); }
    public synchronized boolean isAllowed(String text) { return policy(normalize(text)).allowed; }
    public synchronized String rejectionReason(String text) { return policy(normalize(text)).reason; }

    private void rebuildPersonalModel() {
        personalModel.goals.clear(); personalModel.preferences.clear(); personalModel.projects.clear();
        personalModel.academicState.clear(); personalModel.confirmedFacts.clear(); personalModel.uncertainAssumptions.clear();
        for (MemoryItem item : items) personalModel.apply(item);
    }

    private void trim() {
        while (items.size() > MAX_ITEMS) items.remove(0);
    }

    private MemoryItem find(String id) { for (MemoryItem x : items) if (x.id.equals(id)) return x; return null; }

    private void persist() {
        if (repository == null) return;
        List<String> ids = new ArrayList<>();
        for (MemoryItem item : items) {
            ids.add(item.id);
            String payload = escape(item.text) + "|" + item.category.name() + "|" + item.status.name() + "|" +
                    item.confidence + "|" + item.importance + "|" + escape(item.createdAt) + "|" + escape(item.updatedAt) + "|" +
                    escape(item.learnedAt) + "|" + escape(item.source) + "|" + escape(item.provenance);
            repository.putJson(ITEM_PREFIX + item.id, payload, "memory", 2);
        }
        repository.putJson(INDEX_KEY, String.join("\n", ids), "memory", 2);
    }

    private void loadPersisted() {
        items.clear();
        if (repository == null) return;
        String index = repository.getJson(INDEX_KEY); if (index == null || index.isEmpty()) return;
        for (String id : index.split("\\n")) {
            if (id.trim().isEmpty()) continue;
            String p = repository.getJson(ITEM_PREFIX + id); if (p == null) continue;
            try {
                List<String> f = splitEscaped(p);
                if (f.size() != 10) continue;
                items.add(new MemoryItem(id, f.get(0), MemoryItem.Category.valueOf(f.get(1)), MemoryItem.Status.valueOf(f.get(2)),
                        Double.parseDouble(f.get(3)), Integer.parseInt(f.get(4)), f.get(5), f.get(6), f.get(7), f.get(8), f.get(9)));
            } catch (Exception ignored) { }
        }
        trim(); rebuildPersonalModel();
    }

    private static List<String> splitEscaped(String value) {
        List<String> out = new ArrayList<>(); StringBuilder b = new StringBuilder(); boolean esc = false;
        for (char c : value.toCharArray()) {
            if (esc) { b.append(c); esc = false; }
            else if (c == '\\') esc = true;
            else if (c == '|') { out.add(b.toString()); b.setLength(0); }
            else b.append(c);
        }
        if (esc) b.append('\\'); out.add(b.toString()); return out;
    }
    private static String escape(String s) { return String.valueOf(s).replace("\\", "\\\\").replace("|", "\\|").replace("\n", " "); }
    private static String normalize(String s) { return s == null ? "" : s.replaceAll("[\\u0000-\\u001F]", " ").replaceAll("\\s+", " ").trim(); }
    private static Set<String> tokens(String s) { Set<String> out = new HashSet<>(); for (String x : s.split("[^a-z0-9%]+")) if (x.length() > 1) out.add(x); return out; }
    private static long parseTime(String s) { try { return Instant.parse(s).toEpochMilli(); } catch (Exception e) { return System.currentTimeMillis(); } }
    private static String now() { return Instant.now().toString(); }
    private static double clamp(double v, double a, double b) { return Math.max(a, Math.min(b, v)); }
    private static long clamp(long v, long a, long b) { return Math.max(a, Math.min(b, v)); }
    private static PolicyResult policy(String text) {
        if (text.isEmpty()) return new PolicyResult(false, "empty");
        if (SECRET.matcher(text).find()) return new PolicyResult(false, "secret");
        if (SENSITIVE.matcher(text).find()) return new PolicyResult(false, "sensitive");
        return new PolicyResult(true, null);
    }
    private static final class PolicyResult { final boolean allowed; final String reason; PolicyResult(boolean a, String r){allowed=a;reason=r;} }
    private static final class Scored { final MemoryItem item; final double score; Scored(MemoryItem i,double s){item=i;score=s;} }
}
