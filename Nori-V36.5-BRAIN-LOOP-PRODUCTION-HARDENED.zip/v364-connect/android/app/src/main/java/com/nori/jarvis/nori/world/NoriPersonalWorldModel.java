package com.nori.jarvis.nori.world;

import com.nori.jarvis.nori.data.DataRepository;
import java.time.Instant;
import java.util.*;

/** Step 36: persistent, bounded personal world model. It stores relationships, not raw surveillance. */
public final class NoriPersonalWorldModel {
    public enum Kind { GOAL, SKILL, SCHEDULE, EVENT, PREFERENCE, CONTEXT, RELATION }
    public static final class Fact {
        public final String id, subject, relation, value, source;
        public final Kind kind; public final double confidence; public final long observedAt;
        public Fact(String id,String subject,String relation,String value,String source,Kind kind,double confidence,long observedAt){
            this.id=safe(id);this.subject=safe(subject);this.relation=safe(relation);this.value=safe(value);this.source=safe(source);
            this.kind=kind==null?Kind.CONTEXT:kind;this.confidence=clamp(confidence);this.observedAt=observedAt;
        }
    }
    public static final class Snapshot {
        public final List<Fact> facts; public final List<String> activeGoals,skills,events;
        public final long sequence; public final String changed;
        Snapshot(List<Fact> f,List<String> g,List<String> s,List<String> e,long q,String c){facts=unmod(f);activeGoals=unmod(g);skills=unmod(s);events=unmod(e);sequence=q;changed=safe(c);}
        private static <T> List<T> unmod(List<T> x){return Collections.unmodifiableList(new ArrayList<>(x==null?Collections.emptyList():x));}
    }
    private static final String KEY="nori.world.model.v2";
    private final DataRepository repo; private final Map<String,Fact> facts=new LinkedHashMap<>(); private long sequence;
    public NoriPersonalWorldModel(DataRepository r){repo=r;load();}
    public synchronized void observe(String subject,String relation,String value,String source,Kind kind,double confidence){
        String s=safe(subject), rel=safe(relation); if(s.isEmpty()||rel.isEmpty())return;
        String id=(s+"|"+rel).toLowerCase(Locale.ROOT); Fact old=facts.get(id); long now=System.currentTimeMillis();
        if(old==null||confidence>=old.confidence||now>=old.observedAt) facts.put(id,new Fact(id,s,rel,value,source,kind,confidence,now));
        sequence++; persist();
    }
    public synchronized void event(String text,String source,double confidence){observe("timeline","event",text,source,Kind.EVENT,confidence);}
    public synchronized Snapshot snapshot(){
        List<Fact> fs=new ArrayList<>(facts.values()); fs.sort((a,b)->Long.compare(b.observedAt,a.observedAt));
        List<String> g=new ArrayList<>(),s=new ArrayList<>(),e=new ArrayList<>();
        for(Fact f:fs){if(f.kind==Kind.GOAL)g.add(f.value);if(f.kind==Kind.SKILL)s.add(f.value);if(f.kind==Kind.EVENT)e.add(f.value);}
        String changed=fs.isEmpty()?"none":"latest="+fs.get(0).subject+"/"+fs.get(0).relation;
        return new Snapshot(fs,g,s,e,sequence,changed);
    }
    public synchronized List<Fact> relevant(String query,int limit){
        String q=safe(query).toLowerCase(Locale.ROOT); List<Fact> out=new ArrayList<>();
        for(Fact f:facts.values()){String z=(f.subject+" "+f.relation+" "+f.value).toLowerCase(Locale.ROOT);if(q.isEmpty()||containsToken(z,q))out.add(f);}
        out.sort((a,b)->Double.compare(score(b,q),score(a,q)));if(out.size()>limit)out=new ArrayList<>(out.subList(0,limit));return Collections.unmodifiableList(out);
    }
    public synchronized long sequence(){return sequence;}
    private double score(Fact f,String q){double x=f.confidence; if(q.contains(f.subject.toLowerCase(Locale.ROOT)))x+=1; if(q.contains(f.relation.toLowerCase(Locale.ROOT)))x+=.5; x+=Math.exp(-(System.currentTimeMillis()-f.observedAt)/86_400_000d); return x;}
    private static boolean containsToken(String z,String q){if(z.contains(q))return true;for(String t:q.split("\\s+"))if(t.length()>3&&z.contains(t))return true;return false;}
    private void load(){if(repo==null)return;String raw=repo.getJson(KEY);if(raw==null||raw.isEmpty())return;for(String line:raw.split("\\n")){String[] p=line.split("\\t",8);if(p.length<8)continue;try{facts.put(p[0],new Fact(p[0],p[1],p[2],p[3],p[4],Kind.valueOf(p[5]),Double.parseDouble(p[6]),Long.parseLong(p[7])));}catch(Exception ignored){}}}
    private void persist(){if(repo==null)return;StringBuilder b=new StringBuilder();for(Fact f:facts.values()){if(b.length()>0)b.append('\n');b.append(clean(f.id)).append('\t').append(clean(f.subject)).append('\t').append(clean(f.relation)).append('\t').append(clean(f.value)).append('\t').append(clean(f.source)).append('\t').append(f.kind).append('\t').append(f.confidence).append('\t').append(f.observedAt);}repo.putJson(KEY,b.toString(),"world_model",2);}
    private static String clean(String s){return safe(s).replace("\t"," ").replace("\n"," ");}
    private static String safe(String s){return s==null?"":s.trim();} private static double clamp(double x){return Double.isFinite(x)?Math.max(0,Math.min(1,x)):0;}
}
