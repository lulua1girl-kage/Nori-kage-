package com.nori.jarvis.nori.benchmark;
import java.util.*;
/** Step 43: deterministic architecture benchmark. Measures orchestration correctness, not model intelligence. */
public final class NoriIntegrationBenchmark {
 public static final class Case { public final String id,input; public final boolean expectTool,expectFresh; public Case(String i,String x,boolean t,boolean f){id=i;input=x;expectTool=t;expectFresh=f;} }
 public static final class Result { public final int total,passed; public final List<String> failures; public final long elapsedMs; Result(int t,int p,List<String>f,long e){total=t;passed=p;failures=Collections.unmodifiableList(new ArrayList<>(f));elapsedMs=e;} public boolean pass(){return passed==total;} }
 public Result evaluate(List<Case>cases,java.util.function.Function<Case,Decision>runner){long st=System.currentTimeMillis();int p=0;List<String>f=new ArrayList<>();for(Case c:cases){try{Decision d=runner.apply(c);if(d!=null&&d.tool==c.expectTool&&d.fresh==c.expectFresh)p++;else f.add(c.id);}catch(Exception e){f.add(c.id+":"+e.getClass().getSimpleName());}}return new Result(cases.size(),p,f,System.currentTimeMillis()-st);}
 public static final class Decision{public final boolean tool,fresh;public Decision(boolean t,boolean f){tool=t;fresh=f;}}
 public static List<Case>defaultCases(){return Arrays.asList(new Case("local_info","explain photosynthesis",false,false),new Case("current","latest study methods",false,true),new Case("action","open study center",true,false),new Case("research","research and compare study methods",false,true),new Case("plan","plan my chemistry revision",false,false));}
}
