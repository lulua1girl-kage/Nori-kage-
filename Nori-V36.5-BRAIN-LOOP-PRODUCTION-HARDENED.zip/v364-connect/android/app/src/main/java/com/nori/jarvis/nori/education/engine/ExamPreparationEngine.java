package com.nori.jarvis.nori.education.engine;

import com.nori.jarvis.nori.education.model.*; import java.time.*; import java.util.*;

public final class ExamPreparationEngine {
    public ExamPreparation prepare(String subject,String title,LocalDateTime examAt,StrengthWeaknessReport report,int availablePerDay){
        int days=(int)Math.max(0,Duration.between(LocalDateTime.now(),examAt).toDays());
        List<String> focus=new ArrayList<>(); if(report!=null&&report.subjects.containsKey(subject)) focus.addAll(report.subjects.get(subject).weaknesses); if(focus.isEmpty()) focus.add("coverage verification");
        List<String> phases=new ArrayList<>(); phases.add("diagnose gaps"); if(days>1) phases.add("targeted learning + retrieval"); if(days>3) phases.add("mixed practice"); phases.add("timed exam drill"); phases.add("final light review");
        int mins=Math.max(20,Math.min(120,availablePerDay)); return new ExamPreparation(subject,title,examAt,days,focus,phases,mins);
    }
}
