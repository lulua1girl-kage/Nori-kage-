package com.nori.jarvis.nori.world;

import java.time.Instant;
import java.util.*;

/** Source-aware world-information boundary. It does not pretend local data is live. */
public final class NoriWorldIntelligence {
    public enum Freshness { LIVE, RECENT, STORED, UNKNOWN }
    public enum Need { NEWS, WEATHER, TRENDS, GENERAL_KNOWLEDGE, RESEARCH, NONE }
    public static final class Request { public final Need need; public final String query; public final boolean requiresFresh;
        public Request(Need n,String q,boolean f){need=n;query=q==null?"":q;requiresFresh=f;}}
    public static final class Source { public final String title,provider; public final Freshness freshness; public final Instant observedAt;
        public Source(String t,String p,Freshness f,Instant at){title=t;provider=p;freshness=f;observedAt=at;}}
    public static final class Decision { public final boolean externalRequired; public final String reason; public final List<String> checks;
        Decision(boolean e,String r,List<String> c){externalRequired=e;reason=r;checks=Collections.unmodifiableList(new ArrayList<>(c));}}
    public Decision plan(Request r){
        if(r==null||r.need==Need.NONE)return new Decision(false,"no_world_lookup_needed",Collections.singletonList("answer locally when reliable"));
        if(r.requiresFresh||r.need==Need.NEWS||r.need==Need.WEATHER||r.need==Need.TRENDS)
            return new Decision(true,"fresh_or_time_sensitive_information_requires_external_source",Arrays.asList("timestamp","source identity","freshness","conflicts","uncertainty"));
        return new Decision(false,"stored_or_general_knowledge_may_be_sufficient",Arrays.asList("check freshness","separate fact from inference"));
    }
    public List<Source> organize(List<Source> sources){
        List<Source> out=new ArrayList<>(sources==null?Collections.emptyList():sources);
        out.sort((a,b)->Integer.compare(rank(b.freshness),rank(a.freshness)));
        return Collections.unmodifiableList(out);
    }
    private int rank(Freshness f){return f==Freshness.LIVE?4:f==Freshness.RECENT?3:f==Freshness.STORED?2:1;}
}
