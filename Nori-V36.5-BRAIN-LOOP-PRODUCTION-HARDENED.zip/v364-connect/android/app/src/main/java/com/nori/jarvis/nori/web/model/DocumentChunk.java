package com.nori.jarvis.nori.web.model;

public final class DocumentChunk {
    public final String documentId, chunkId, text;
    public final int index, start, end;
    public DocumentChunk(String documentId,String chunkId,int index,int start,int end,String text){
        this.documentId=documentId; this.chunkId=chunkId; this.index=index; this.start=start; this.end=end; this.text=text;
    }
}
