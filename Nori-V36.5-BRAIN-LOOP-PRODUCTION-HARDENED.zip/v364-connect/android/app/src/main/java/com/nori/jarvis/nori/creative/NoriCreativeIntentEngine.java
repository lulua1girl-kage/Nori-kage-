package com.nori.jarvis.nori.creative;

import java.util.*;

/** Routes creative requests without hijacking ordinary conversation. */
public final class NoriCreativeIntentEngine {
    public enum Intent { NONE, IMAGE, PDF, IMAGE_AND_PDF }
    public Intent classify(String text){
        String q=String.valueOf(text).toLowerCase(Locale.ROOT);
        boolean image=q.matches(".*\\b(generate|create|draw|render|design|illustrate|make)\\b.*\\b(image|picture|illustration|poster|diagram|artwork)\\b.*")
                ||q.matches(".*\\b(image|picture|illustration|poster|diagram)\\b.*\\b(generate|create|draw|render)\\b.*");
        boolean pdf=q.matches(".*\\b(make|create|generate|export|turn|convert)\\b.*\\b(pdf|document|study guide|report|revision sheet)\\b.*")
                ||q.matches(".*\\bpdf\\b.*");
        if(image&&pdf)return Intent.IMAGE_AND_PDF; if(image)return Intent.IMAGE; if(pdf)return Intent.PDF; return Intent.NONE;
    }
    public boolean shouldOfferCreativeHelp(String text){return classify(text)!=Intent.NONE;}
}
