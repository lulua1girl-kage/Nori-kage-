package com.nori.jarvis.nori.performance;

/** Stage 21: explicit connectivity policy. Core operation never requires a network. */
public final class OfflinePolicy {
    public enum Mode { OFFLINE_FIRST, ONLINE_ALLOWED }
    private Mode mode = Mode.OFFLINE_FIRST;
    private boolean networkAvailable;

    public synchronized Mode mode() { return mode; }
    public synchronized void setMode(Mode value) { mode = value == null ? Mode.OFFLINE_FIRST : value; }
    public synchronized void setNetworkAvailable(boolean available) { networkAvailable = available; }
    public synchronized boolean isOffline() { return !networkAvailable; }
    public synchronized boolean allowRemoteNetwork() { return mode == Mode.ONLINE_ALLOWED && networkAvailable; }
    public synchronized boolean allowLocalCore() { return true; }
}
