package com.nori.jarvis.nori.brain;

import java.util.Locale;

/** Lightweight deterministic intent router. It routes; it does not execute actions. */
public final class IntentEngine {
    public enum Intent {
        ASK, READ, ANALYZE, PLAN, UPDATE, COMPLETE, CREATE, SEARCH, SUMMARIZE, ADMIN, EXPLAIN, VERIFY, UNKNOWN
    }
    public Intent classify(String input) {
        if(input==null || input.trim().isEmpty()) return Intent.UNKNOWN;
        String s=input.trim().toLowerCase(Locale.ROOT);
        if(s.matches(".*\\b(admin|administrator|registry|system status)\\b.*")) return Intent.ADMIN;
        if(s.matches(".*\\b(verify|check|confirm|is this correct)\\b.*")) return Intent.VERIFY;
        if(s.matches(".*\\b(plan|schedule|study plan|what should i do)\\b.*")) return Intent.PLAN;
        if(s.matches(".*\\b(create|add|make|new)\\b.*")) return Intent.CREATE;
        if(s.matches(".*\\b(update|change|edit|move)\\b.*")) return Intent.UPDATE;
        if(s.matches(".*\\b(complete|finish|done|mark.*complete)\\b.*")) return Intent.COMPLETE;
        if(s.matches(".*\\b(search|find|look up|research)\\b.*")) return Intent.SEARCH;
        if(s.matches(".*\\b(summarize|summary|brief)\\b.*")) return Intent.SUMMARIZE;
        if(s.matches(".*\\b(analyze|analyse|why|pattern|compare)\\b.*")) return Intent.ANALYZE;
        if(s.matches(".*\\b(explain|teach|how does|what does)\\b.*")) return Intent.EXPLAIN;
        if(s.matches(".*\\b(show|get|list|read|what is|what are)\\b.*")) return Intent.READ;
        return Intent.ASK;
    }
}
