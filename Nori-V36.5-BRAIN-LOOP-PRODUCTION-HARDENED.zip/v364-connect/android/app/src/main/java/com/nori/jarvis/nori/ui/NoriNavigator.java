package com.nori.jarvis.nori.ui;

import android.app.Activity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import java.util.LinkedHashMap;
import java.util.Map;

/** Lightweight native navigation with persistent screen selection state. */
public final class NoriNavigator {
    public enum Screen { HOME, ACADEMICS, PLAN, RESULTS, KAGE, RECOVER, SETTINGS }

    public interface ScreenFactory { View create(Activity activity); }

    private final Activity activity;
    private final FrameLayout container;
    private final Map<Screen, ScreenFactory> factories = new LinkedHashMap<>();
    private Screen current = Screen.HOME;

    public NoriNavigator(Activity activity, FrameLayout container) {
        this.activity = activity;
        this.container = container;
    }

    public void register(Screen screen, ScreenFactory factory) { factories.put(screen, factory); }

    public void show(Screen screen) {
        ScreenFactory factory = factories.get(screen);
        if (factory == null) return;
        View next = factory.create(activity);
        container.removeAllViews();
        container.addView(next, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        current = screen;
    }

    public Screen getCurrent() { return current; }
}
