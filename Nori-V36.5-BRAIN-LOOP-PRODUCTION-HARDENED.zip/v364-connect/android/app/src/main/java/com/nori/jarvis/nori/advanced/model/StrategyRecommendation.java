package com.nori.jarvis.nori.advanced.model;

import java.util.*;

public final class StrategyRecommendation {
    public final String subject; public final String strategy; public final int minutes;
    public final double priority; public final String reason; public final List<String> safeguards;
    public StrategyRecommendation(String subject,String strategy,int minutes,double priority,String reason,List<String> safeguards){
        this.subject=subject;this.strategy=strategy;this.minutes=Math.max(0,minutes);this.priority=priority;this.reason=reason;this.safeguards=Collections.unmodifiableList(new ArrayList<>(safeguards));
    }
}
