package com.nori.jarvis.nori.education.model;

public final class TutoringPolicy {
    public enum Depth { FAST, STANDARD, DEEP }
    public enum Help { HINT_FIRST, GUIDED, DIRECT_EXPLANATION }
    public final Depth depth; public final Help help; public final boolean useExamples; public final String reason;
    public TutoringPolicy(Depth depth,Help help,boolean useExamples,String reason){this.depth=depth;this.help=help;this.useExamples=useExamples;this.reason=reason;}
}
