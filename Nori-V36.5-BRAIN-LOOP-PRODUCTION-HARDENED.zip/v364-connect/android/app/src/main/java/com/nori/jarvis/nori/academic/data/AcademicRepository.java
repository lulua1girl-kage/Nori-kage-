package com.nori.jarvis.nori.academic.data;

import com.nori.jarvis.nori.academic.model.Assessment;

import java.util.List;

/**
 * Persistence boundary for typed academic records.
 * Stage 6 does not force this interface to replace the generic V32/native
 * repository; that source-of-truth decision belongs to later equivalence
 * testing.
 */
public interface AcademicRepository {
    boolean saveAssessment(String id, Assessment assessment);
    Assessment getAssessment(String id);
    List<String> assessmentIds();
}
