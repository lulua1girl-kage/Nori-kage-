package com.nori.jarvis.nori.brain.schedule;

import java.time.Instant; import java.util.*;

/** Bounded asynchronous-preparation abstraction. Platform scheduling may execute it; this layer never runs covert work. */
public final class NoriBackgroundPreparationQueue {
    public enum Status { QUEUED, RUNNING, COMPLETE, FAILED, CANCELLED }
    public static final class Job { public final String id,title; public final Status status; public final Instant createdAt; Job(String i,String t,Status s){id=i;title=t;status=s;createdAt=Instant.now();} }
    private final Map<String,Job> jobs=new LinkedHashMap<>();
    public synchronized Job queue(String title){String id="job-"+Long.toHexString(System.nanoTime());Job j=new Job(id,title,Status.QUEUED);jobs.put(id,j);while(jobs.size()>100)jobs.remove(jobs.keySet().iterator().next());return j;}
    public synchronized List<Job> jobs(){return Collections.unmodifiableList(new ArrayList<>(jobs.values()));}
}
