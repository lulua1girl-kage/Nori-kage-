package com.nori.jarvis.nori.advanced.engine;

import com.nori.jarvis.nori.education.model.AcademicEvidence;
import com.nori.jarvis.nori.advanced.model.TrajectoryReport;
import java.util.*;

public final class TrajectoryAnalyzer {
    public TrajectoryReport analyze(String subject,List<AcademicEvidence> input){
        List<AcademicEvidence> rows=filter(subject,input); rows.sort(Comparator.comparing(e->e.at));
        if(rows.size()<2)return new TrajectoryReport(subject,rows.size(),0,"insufficient_data",0,0.2,Collections.singletonList("At least two observations are needed for a trajectory."));
        int n=rows.size(); double sx=0,sy=0,sxx=0,sxy=0;
        for(int i=0;i<n;i++){double x=i,y=rows.get(i).score;sx+=x;sy+=y;sxx+=x*x;sxy+=x*y;}
        double den=n*sxx-sx*sx; double slope=den==0?0:(n*sxy-sx*sy)/den;
        double mean=sy/n,ss=0,res=0;for(int i=0;i<n;i++){double y=rows.get(i).score;ss+=(y-mean)*(y-mean);double pred=mean+slope*(i-(n-1)/2.0);res+=(y-pred)*(y-pred);}
        double stability=1.0/(1.0+Math.sqrt(ss/Math.max(1,n))); String direction=slope>1.0?"improving":slope<-1.0?"declining":"stable";
        double confidence=Math.min(1,0.35+n*0.08)*Math.max(0.4,stability);
        return new TrajectoryReport(subject,n,slope,direction,stability,confidence,Arrays.asList("Observations="+n,"Linear slope per observation="+round(slope),"Residual variation="+round(res/Math.max(1,n))));
    }
    private List<AcademicEvidence> filter(String s,List<AcademicEvidence> in){List<AcademicEvidence> r=new ArrayList<>();if(in!=null)for(AcademicEvidence e:in)if(e!=null&&(s==null||s.equalsIgnoreCase(e.subject)))r.add(e);return r;}
    private static double round(double x){return Math.round(x*100.0)/100.0;}
}
