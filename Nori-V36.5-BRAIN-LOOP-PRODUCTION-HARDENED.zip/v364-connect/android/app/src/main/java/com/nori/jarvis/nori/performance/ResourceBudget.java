package com.nori.jarvis.nori.performance;

/** Stage 21 bounded-resource policy for native intelligence operations. */
public final class ResourceBudget {
    public final int maxCacheEntries;
    public final int maxTextChars;
    public final int maxCollectionItems;
    public final long maxOperationMillis;

    public ResourceBudget() { this(32, 120_000, 1_000, 5_000L); }
    public ResourceBudget(int maxCacheEntries, int maxTextChars, int maxCollectionItems, long maxOperationMillis) {
        if (maxCacheEntries < 1 || maxTextChars < 1 || maxCollectionItems < 1 || maxOperationMillis < 1)
            throw new IllegalArgumentException("resource limits must be positive");
        this.maxCacheEntries = maxCacheEntries;
        this.maxTextChars = maxTextChars;
        this.maxCollectionItems = maxCollectionItems;
        this.maxOperationMillis = maxOperationMillis;
    }
    public int boundedTextLength(String text) { return text == null ? 0 : Math.min(text.length(), maxTextChars); }
    public int boundedItems(int count) { return Math.max(0, Math.min(count, maxCollectionItems)); }
}
