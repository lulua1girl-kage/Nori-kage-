package com.nori.jarvis.nori.advanced.engine;

import com.nori.jarvis.nori.education.model.*;import com.nori.jarvis.nori.advanced.model.*;import java.util.*;

/** Chooses bounded interventions from evidence; it never executes device actions. */
public final class StrategyEngine {
    public StrategyRecommendation choose(String subject,StrengthWeaknessSnapshot s,MistakeSnapshot m,TrajectoryReport t,int availableMinutes,boolean nearExam){
        int minutes=Math.max(10,Math.min(availableMinutes,nearExam?90:75)); String strategy; String reason;
        if(s.weak && m.repeatedConcepts>0){strategy="targeted_reteach_then_retrieval";reason="Weakness and repeated concept errors overlap.";}
        else if(m.careless>m.application){strategy="error_autopsy_then_timed_set";reason="Careless errors are the dominant recorded error type.";}
        else if(m.application>0){strategy="worked_example_then_transfer";reason="Application errors indicate a need to practice using concepts in new problems.";}
        else if("declining".equals(t.direction)){strategy="short_retrieval_cycle";reason="Recent trajectory is declining; use a small repeatable repair cycle.";}
        else {strategy=nearExam?"retrieval_then_exam_drill":"retrieval_then_spaced_review";reason="No stronger specific error signal was found.";}
        List<String> safeguards=Arrays.asList("Stop if essential needs or scheduled commitments are affected.","Reassess using new evidence rather than escalating automatically.","Human Override remains authoritative.");
        double p=(s.weak?0.4:0)+(m.repeatedConcepts>0?0.3:0)+("declining".equals(t.direction)?0.2:0)+(nearExam?0.1:0);
        return new StrategyRecommendation(subject,strategy,minutes,Math.min(1,p),reason,safeguards);
    }
    public static final class StrengthWeaknessSnapshot{public final boolean weak;public StrengthWeaknessSnapshot(boolean w){weak=w;}}
    public static final class MistakeSnapshot{public final int repeatedConcepts,careless,application;public MistakeSnapshot(int r,int c,int a){repeatedConcepts=r;careless=c;application=a;}}
}
