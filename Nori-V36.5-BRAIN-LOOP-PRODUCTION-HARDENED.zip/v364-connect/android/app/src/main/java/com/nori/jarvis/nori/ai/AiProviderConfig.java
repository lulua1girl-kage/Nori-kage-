package com.nori.jarvis.nori.ai;

/** Explicit configuration for a remote provider. Disabled by default. */
public final class AiProviderConfig {
    public final boolean enabled;
    public final boolean userConsent;
    public final String providerId;
    public final String endpoint;
    public final String authorizationToken;
    public final int maxInputCharacters;

    public AiProviderConfig(boolean enabled, boolean userConsent, String providerId, String endpoint,
                            String authorizationToken, int maxInputCharacters) {
        this.enabled=enabled; this.userConsent=userConsent;
        this.providerId=providerId==null?"":providerId.trim(); this.endpoint=endpoint==null?"":endpoint.trim();
        this.authorizationToken=authorizationToken==null?"":authorizationToken;
        this.maxInputCharacters=maxInputCharacters<=0?16000:Math.min(maxInputCharacters,50000);
    }
    public static AiProviderConfig disabled(){return new AiProviderConfig(false,false,"","","",16000);}
    public boolean usable(){return enabled && userConsent && !providerId.isEmpty() && !endpoint.isEmpty();}
}
