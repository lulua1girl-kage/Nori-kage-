package com.nori.jarvis.nori.brain.model;

import com.nori.jarvis.nori.academic.model.Assessment;
import com.nori.jarvis.nori.brain.ContextEngine;
import java.util.*;

/** Complete native input contract for the Stage 7 orchestration path. */
public final class AcademicEventInput {
    public final String subject;
    public final Assessment assessment;
    public final ContextEngine.Event contextEvent;
    public final ContextEngine.Event secondaryContextEvent;
    public final int unresolvedDegree1, degree1Total, sameDomainRepeat;
    public final List<String> priorIneffectiveIds;
    public AcademicEventInput(String subject, Assessment assessment, ContextEngine.Event contextEvent,
                              ContextEngine.Event secondaryContextEvent, int unresolvedDegree1, int degree1Total,
                              int sameDomainRepeat, List<String> priorIneffectiveIds) {
        this.subject=subject; this.assessment=assessment; this.contextEvent=contextEvent; this.secondaryContextEvent=secondaryContextEvent;
        this.unresolvedDegree1=Math.max(0,unresolvedDegree1); this.degree1Total=Math.max(0,degree1Total); this.sameDomainRepeat=Math.max(0,sameDomainRepeat);
        this.priorIneffectiveIds=Collections.unmodifiableList(new ArrayList<>(priorIneffectiveIds==null?Collections.emptyList():priorIneffectiveIds));
    }
}
