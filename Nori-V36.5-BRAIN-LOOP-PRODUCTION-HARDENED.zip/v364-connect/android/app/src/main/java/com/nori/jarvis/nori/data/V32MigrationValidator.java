package com.nori.jarvis.nori.data;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Validates a V32 localStorage export before it is committed to native storage.
 * Validation is intentionally conservative: unknown keys are allowed and values
 * remain opaque JSON so migration cannot destroy information by over-modeling it.
 */
public final class V32MigrationValidator {
    private V32MigrationValidator() {}

    public static ValidationResult validate(String exportJson) {
        List<String> errors = new ArrayList<>();
        if (exportJson == null || exportJson.trim().isEmpty()) {
            errors.add("Export is empty.");
            return new ValidationResult(false, errors, 0);
        }

        try {
            JSONObject root = new JSONObject(exportJson);
            JSONObject data = root.optJSONObject("data");
            if (data == null) {
                errors.add("Missing data object.");
                return new ValidationResult(false, errors, 0);
            }

            int count = 0;
            java.util.Iterator<String> it = data.keys();
            while (it.hasNext()) {
                String key = it.next();
                count++;
                if (key == null || key.trim().isEmpty()) errors.add("Encountered empty storage key.");
            }

            int schema = root.optInt("schemaVersion", 1);
            if (schema < 1) errors.add("Unsupported schema version: " + schema);

            return new ValidationResult(errors.isEmpty(), errors, count);
        } catch (JSONException e) {
            errors.add("Invalid JSON export: " + e.getMessage());
            return new ValidationResult(false, errors, 0);
        }
    }

    public static final class ValidationResult {
        public final boolean valid;
        public final List<String> errors;
        public final int keyCount;

        ValidationResult(boolean valid, List<String> errors, int keyCount) {
            this.valid = valid;
            this.errors = java.util.Collections.unmodifiableList(new ArrayList<>(errors));
            this.keyCount = keyCount;
        }
    }
}
