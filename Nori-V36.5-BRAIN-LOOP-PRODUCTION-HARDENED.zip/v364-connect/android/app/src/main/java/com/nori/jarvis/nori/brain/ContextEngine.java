package com.nori.jarvis.nori.brain;

import java.util.*;

/** Native counterpart of V32 contextEngine.classifyContext(). */
public final class ContextEngine {
    public enum ContextType {
        LEGITIMATE_ACTIVITY("legitimate_activity"),
        NECESSARY_INTERRUPTION("necessary_interruption"),
        ACCIDENTAL_INTERACTION("accidental_interaction"),
        EMOTIONAL_LAPSE("emotional_lapse"),
        DIFFICULT_DAY("difficult_day"),
        DELIBERATE_DISTRACTION("deliberate_distraction"),
        SUSTAINED_DELIBERATE_DISTRACTION("sustained_deliberate_distraction"),
        UNKNOWN("unknown");
        private final String value;
        ContextType(String value){this.value=value;}
        public String value(){return value;}
    }
    public enum Confidence { CONFIRMED, PROBABLE, UNCLEAR }

    public static final class Event {
        public final String domain, statedPurpose;
        public final int durationMinutes;
        public final boolean emergency, accidental, continuedAfterAwareness, difficultDay;
        public final List<String> evidenceSources;
        public Event(String domain, int durationMinutes, String statedPurpose, boolean emergency,
                     boolean accidental, boolean continuedAfterAwareness, boolean difficultDay,
                     List<String> evidenceSources) {
            this.domain=domain; this.durationMinutes=Math.max(0,durationMinutes);
            this.statedPurpose=statedPurpose; this.emergency=emergency; this.accidental=accidental;
            this.continuedAfterAwareness=continuedAfterAwareness; this.difficultDay=difficultDay;
            this.evidenceSources=Collections.unmodifiableList(new ArrayList<>(evidenceSources==null?Collections.emptyList():evidenceSources));
        }
    }
    public static final class Result {
        public final ContextType type; public final Confidence confidence; public final boolean breachEligible; public final String reasoning;
        public Result(ContextType type, Confidence confidence, boolean breachEligible, String reasoning){this.type=type;this.confidence=confidence;this.breachEligible=breachEligible;this.reasoning=reasoning;}
    }

    public Result classifyContext(Event event) {
        if(event==null) throw new IllegalArgumentException("Context event is required");
        int evidence=event.evidenceSources.size();
        Confidence confidence=evidence>=2?Confidence.CONFIRMED:evidence==1?Confidence.PROBABLE:Confidence.UNCLEAR;
        if(event.emergency) return new Result(ContextType.NECESSARY_INTERRUPTION,confidence,false,"Emergency/necessary communication — never a disciplinary breach.");
        if(event.accidental && event.durationMinutes<=1 && !event.continuedAfterAwareness) return new Result(ContextType.ACCIDENTAL_INTERACTION,confidence,false,"Brief accidental interaction, immediately exited — not a breach.");
        if(event.statedPurpose!=null && event.statedPurpose.toLowerCase(Locale.ROOT).contains("academic")) return new Result(ContextType.LEGITIMATE_ACTIVITY,confidence,false,"Stated academic purpose — legitimate use unless contradicted by evidence.");
        if(event.difficultDay && !event.continuedAfterAwareness) return new Result(ContextType.DIFFICULT_DAY,confidence,false,"Reported difficult day — context for interpreting result, not itself a breach.");
        if(!event.accidental && event.durationMinutes>1 && !event.continuedAfterAwareness) return new Result(ContextType.EMOTIONAL_LAPSE,confidence,event.durationMinutes>10,"Brief non-accidental deviation without sustained continuation.");
        if(event.continuedAfterAwareness && event.durationMinutes<=20) return new Result(ContextType.DELIBERATE_DISTRACTION,confidence,true,"Continued deliberately after recognizing the breach; not yet sustained.");
        if(event.continuedAfterAwareness && event.durationMinutes>20) return new Result(ContextType.SUSTAINED_DELIBERATE_DISTRACTION,confidence,true,"Continued deliberately for an extended period after recognizing the breach.");
        return new Result(ContextType.UNKNOWN,Confidence.UNCLEAR,false,"Insufficient evidence to classify — defaults to investigation, not consequence.");
    }
}
