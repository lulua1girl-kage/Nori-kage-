package com.nori.jarvis.nori.understanding;

import java.time.Instant;
import java.util.*;

/**
 * Authorization firewall between Nori understanding and Nori action.
 * Understanding is never authorization.
 */
public final class NoriUserControlEngine {
    public enum Origin { NONE, USER_DIRECT, USER_CONFIRMED, USER_SCHEDULED, SYSTEM_AUTOMATIC }
    public enum Status { INFORMATION_ONLY, NEEDS_USER_REQUEST, NEEDS_CONFIRMATION, EXECUTION_READY, BLOCKED, EXPIRED }
    public static final class Request {
        public final String actionId, description; public final Origin origin; public final boolean consequential, crossApp, sensitive;
        public final String scope, permission;
        public Request(String id,String d,Origin o,boolean c,boolean x,boolean s,String scope,String permission){actionId=id;description=d;origin=o;consequential=c;crossApp=x;sensitive=s;this.scope=scope;this.permission=permission;}
    }
    public static final class Decision {
        public final Status status; public final String reason; public final boolean mayExecute; public final boolean requiresVisibleConfirmation;
        public final String preview;
        Decision(Status s,String r,boolean e,boolean c,String p){status=s;reason=r;mayExecute=e;requiresVisibleConfirmation=c;preview=p;}
    }
    public Decision evaluate(Request r){
        if(r==null||r.actionId==null||r.actionId.trim().isEmpty())return new Decision(Status.BLOCKED,"incomplete_action",false,false,"Nori cannot identify the requested action.");
        if(r.origin==Origin.SYSTEM_AUTOMATIC)return new Decision(Status.NEEDS_USER_REQUEST,"silent_background_actions_are_not_authorized",false,true,preview(r));
        if(r.origin==Origin.NONE)return new Decision(Status.NEEDS_USER_REQUEST,"fresh_user_trigger_required",false,true,preview(r));
        if(r.origin==Origin.USER_SCHEDULED){
            if(r.sensitive||r.crossApp)return new Decision(Status.NEEDS_CONFIRMATION,"scheduled_scope_requires_runtime_confirmation",false,true,preview(r));
            return new Decision(Status.EXECUTION_READY,"explicit_user_schedule_with_bounded_scope",true,false,preview(r));
        }
        if(r.origin==Origin.USER_DIRECT && (r.consequential||r.crossApp||r.sensitive))return new Decision(Status.NEEDS_CONFIRMATION,"important_action_requires_visible_confirmation",false,true,preview(r));
        if(r.origin==Origin.USER_CONFIRMED)return new Decision(Status.EXECUTION_READY,"explicit_user_confirmation_received",true,false,preview(r));
        return new Decision(Status.EXECUTION_READY,"user_triggered_low_risk_action",true,false,preview(r));
    }
    public boolean isBackgroundAllowed(NoriAppCapabilityCatalog.Capability capability){return capability!=null && capability.backgroundAllowed;}
    public String preview(Request r){return "ACTION="+r.actionId+" | SCOPE="+safe(r.scope)+" | PERMISSION="+safe(r.permission)+" | ORIGIN="+r.origin+" | CONSEQUENCES="+(r.consequential?"YES":"BOUNDED")+" | CROSS_APP="+(r.crossApp?"YES":"NO")+" | SENSITIVE="+(r.sensitive?"YES":"NO");}
    public boolean authorizationStillFresh(Instant issuedAt,long maxAgeSeconds){return issuedAt!=null&&maxAgeSeconds>0&&Instant.now().isBefore(issuedAt.plusSeconds(maxAgeSeconds));}
    private static String safe(String s){return s==null||s.trim().isEmpty()?"NONE":s.trim();}
}
