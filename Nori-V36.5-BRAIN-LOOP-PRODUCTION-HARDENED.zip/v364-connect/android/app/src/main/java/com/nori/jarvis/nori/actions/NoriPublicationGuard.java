package com.nori.jarvis.nori.actions;

import com.nori.jarvis.nori.actions.model.ToolDefinition;
import java.util.Locale;

/** Absolute Nori boundary: no social publishing/posting action is executable by the Brain. */
public final class NoriPublicationGuard {
    public boolean allowed(ToolDefinition tool){
        if(tool==null) return false;
        String s=(String.valueOf(tool.id)+" "+String.valueOf(tool.label)+" "+String.valueOf(tool.educationalPurpose)).toLowerCase(Locale.ROOT);
        return !(s.matches(".*\\b(publish|post|upload|story|reel|tweet|status)\\b.*") &&
                 s.matches(".*\\b(social|instagram|facebook|pinterest|tiktok|snapchat)\\b.*"));
    }
}
