package com.nori.jarvis.nori.world;

import com.nori.jarvis.nori.web.engine.WebIntelligence;
import com.nori.jarvis.nori.web.model.WebFetchResult;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.*;
import java.util.regex.*;

/**
 * Real web retrieval for time-sensitive world information.
 * Uses public HTTPS web endpoints; no credentials and no hidden browser control.
 * Chrome opening remains a separate explicit user action.
 */
public final class NoriWorldWebConnector {
    public enum Kind { NEWS, WEATHER, TRENDS, WEB_SEARCH }
    public static final class Item {
        public final String title, url, summary;
        public final Instant observedAt;
        public Item(String t,String u,String s,Instant at){title=t;url=u;summary=s;observedAt=at;}
    }
    public static final class Report {
        public final Kind kind; public final String query; public final Instant observedAt;
        public final boolean live; public final List<Item> items; public final String rawSummary; public final List<String> warnings;
        Report(Kind k,String q,Instant at,boolean l,List<Item> i,String s,List<String>w){kind=k;query=q;observedAt=at;live=l;items=Collections.unmodifiableList(new ArrayList<>(i));rawSummary=s==null?"":s;warnings=Collections.unmodifiableList(new ArrayList<>(w));}
    }

    private final WebIntelligence web;
    public NoriWorldWebConnector(){web=new WebIntelligence();}
    public Report latestNews(String query,int limit){
        String q=empty(query)?"latest news":query;
        return rss(Kind.NEWS,"https://news.google.com/rss/search?q="+enc(q)+"&hl=en-US&gl=US&ceid=US:en",q,limit,"Google News RSS");
    }
    public Report trends(String query,int limit){
        String q=empty(query)?"trending":query;
        // Google Trends exposes a public RSS feed; when a query is supplied we also search the current web.
        String url=empty(query)?"https://trends.google.com/trending/rss?geo=US":"https://www.google.com/search?tbm=nws&q="+enc(q);
        return rssOrHtml(Kind.TRENDS,url,q,limit,"Google Trends / Google web results");
    }
    public Report weather(String location){
        String q=empty(location)?"weather":location.trim();
        String url="https://wttr.in/"+encPath(q)+"?format=j1";
        WebFetchResult r=web.fetch(url); Instant now=Instant.now();
        if(r.status!=WebFetchResult.Status.SUCCESS) return new Report(Kind.WEATHER,q,now,false,Collections.emptyList(),"",Collections.singletonList("live_weather_fetch_failed:"+r.reason));
        String text=r.text;
        String temp=first(text,"\\\"temp_C\\\"\\s*:\\s*\\\"?([^\\\",}]+)");
        String feels=first(text,"\\\"FeelsLikeC\\\"\\s*:\\s*\\\"?([^\\\",}]+)");
        String desc=first(text,"\\\"weatherDesc\\\"\\s*:\\s*\\[\\s*\\{\\s*\\\"value\\\"\\s*:\\s*\\\"([^\\\"]+)");
        String humidity=first(text,"\\\"humidity\\\"\\s*:\\s*\\\"?([^\\\",}]+)");
        String summary=(temp.isEmpty()?"":temp+"°C")+(feels.isEmpty()?"":"; feels like "+feels+"°C")+(desc.isEmpty()?"":"; "+desc)+(humidity.isEmpty()?"":"; humidity "+humidity+"%");
        return new Report(Kind.WEATHER,q,now,true,Collections.singletonList(new Item("Current weather for "+q,url,summary,now)),summary,Collections.emptyList());
    }
    public Report webSearch(String query,int limit){
        String q=empty(query)?"latest information":query;
        return rss(Kind.WEB_SEARCH,"https://www.bing.com/search?format=rss&q="+enc(q),q,limit,"Bing web search RSS");
    }

    private Report rss(Kind kind,String url,String query,int limit,String provider){
        WebFetchResult r=web.fetch(url); Instant now=Instant.now();
        if(r.status!=WebFetchResult.Status.SUCCESS) return new Report(kind,query,now,false,Collections.emptyList(),"",Collections.singletonList(provider+"_fetch_failed:"+r.reason));
        List<Item> items=parseRss(r.text,Math.max(1,Math.min(10,limit)),now);
        List<String>w=items.isEmpty()?Collections.singletonList("source_returned_no_parseable_items"):Collections.emptyList();
        return new Report(kind,query,now,true,items,"live web results from "+provider,w);
    }
    private Report rssOrHtml(Kind kind,String url,String query,int limit,String provider){
        WebFetchResult r=web.fetch(url); Instant now=Instant.now();
        if(r.status!=WebFetchResult.Status.SUCCESS) return new Report(kind,query,now,false,Collections.emptyList(),"",Collections.singletonList(provider+"_fetch_failed:"+r.reason));
        List<Item> items=parseRss(r.text,Math.max(1,Math.min(10,limit)),now);
        if(items.isEmpty()) items=parseHtmlAnchors(r.text,Math.max(1,Math.min(10,limit)),now);
        return new Report(kind,query,now,true,items,items.isEmpty()?"live source returned no parseable items":"live web results from "+provider,items.isEmpty()?Collections.singletonList("source_returned_no_parseable_items"):Collections.emptyList());
    }
    private static List<Item> parseRss(String xml,int limit,Instant now){
        List<Item> out=new ArrayList<>();
        Matcher m=Pattern.compile("<item\\b[^>]*>([\\s\\S]*?)</item>",Pattern.CASE_INSENSITIVE).matcher(xml);
        while(m.find()&&out.size()<limit){String b=m.group(1);String title=tag(b,"title"),link=tag(b,"link"),desc=tag(b,"description");if(!title.isEmpty()&&!link.isEmpty())out.add(new Item(strip(title),strip(link),strip(desc),now));}
        if(out.isEmpty()){
            Matcher e=Pattern.compile("<entry\\b[^>]*>([\\s\\S]*?)</entry>",Pattern.CASE_INSENSITIVE).matcher(xml);
            while(e.find()&&out.size()<limit){String b=e.group(1),title=tag(b,"title"),link=first(b,"<link[^>]+href=\\\"([^\\\"]+)\\\"");if(!title.isEmpty()&&!link.isEmpty())out.add(new Item(strip(title),link,strip(tag(b,"summary")),now));}
        }
        return out;
    }
    private static List<Item> parseHtmlAnchors(String html,int limit,Instant now){
        List<Item> out=new ArrayList<>(); Matcher m=Pattern.compile("<a[^>]+href=\\\"(https?://[^\\\"]+)\\\"[^>]*>([\\s\\S]*?)</a>",Pattern.CASE_INSENSITIVE).matcher(html);
        while(m.find()&&out.size()<limit){String t=strip(m.group(2));if(t.length()>3&&!t.equalsIgnoreCase("Google"))out.add(new Item(t,m.group(1),"",now));}
        return out;
    }
    private static String tag(String s,String name){Matcher m=Pattern.compile("<"+name+"[^>]*>([\\s\\S]*?)</"+name+">",Pattern.CASE_INSENSITIVE).matcher(s);return m.find()?m.group(1):"";}
    private static String first(String s,String regex){Matcher m=Pattern.compile(regex,Pattern.CASE_INSENSITIVE).matcher(s);return m.find()?m.group(1).trim():"";}
    private static String strip(String s){return s==null?"":s.replaceAll("<[^>]+>"," ").replaceAll("&amp;","&").replaceAll("&quot;","\\\"").replaceAll("&#39;","'").replaceAll("&lt;","<").replaceAll("&gt;",">").replaceAll("\\s+"," ").trim();}
    private static String enc(String s){try{return URLEncoder.encode(s,StandardCharsets.UTF_8.name());}catch(Exception e){return s.replace(" ","+");}}
    private static String encPath(String s){return enc(s).replace("+","%20");}
    private static boolean empty(String s){return s==null||s.trim().isEmpty();}
}
