package com.nori.jarvis.nori.ai;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Provider-neutral AI request. No credentials are stored here. */
public final class AiRequest {
    public final String prompt;
    public final String systemInstruction;
    public final Map<String,String> metadata;
    public final int maxOutputCharacters;
    /** True when local deterministic Nori should delegate to external intelligence for this request. */
    public final boolean difficult;

    public AiRequest(String prompt, String systemInstruction, Map<String,String> metadata, int maxOutputCharacters) {
        if (prompt == null || prompt.trim().isEmpty()) throw new IllegalArgumentException("prompt required");
        this.prompt = prompt;
        this.systemInstruction = systemInstruction == null ? "" : systemInstruction;
        this.metadata = metadata == null ? Collections.emptyMap() : Collections.unmodifiableMap(new LinkedHashMap<>(metadata));
        this.maxOutputCharacters = maxOutputCharacters <= 0 ? 12000 : Math.min(maxOutputCharacters, 20000);
        this.difficult = this.metadata.getOrDefault("difficulty", "normal").equalsIgnoreCase("difficult") || this.metadata.getOrDefault("requiresExternal", "false").equalsIgnoreCase("true");
    }
    public AiRequest(String prompt) { this(prompt, "", null, 12000); }
    public boolean requiresExternalIntelligence(){ return difficult; }
}
