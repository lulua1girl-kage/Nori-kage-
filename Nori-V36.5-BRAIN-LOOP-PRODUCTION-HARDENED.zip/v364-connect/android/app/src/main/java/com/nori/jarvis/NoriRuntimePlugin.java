package com.nori.jarvis;

import com.getcapacitor.*;import com.getcapacitor.annotation.CapacitorPlugin;
import com.nori.jarvis.nori.NoriNativeCore;import com.nori.jarvis.nori.brain.NoriBrain;import com.nori.jarvis.nori.performance.NoriAndroidRuntimeProbe;import com.nori.jarvis.nori.runtime.*;import com.nori.jarvis.nori.web.NoriLiveWebRetrieval;import com.nori.jarvis.nori.edgeai.NoriOnDeviceTask;
import java.util.*;

/** Device-side observability bridge. Measurements are on-demand; there is no background telemetry. */
@CapacitorPlugin(name="NoriRuntime")
public final class NoriRuntimePlugin extends Plugin{
 private NoriBrain brain; @Override public void load(){brain=new NoriNativeCore().getBrain();}
 @PluginMethod public void snapshot(PluginCall c){NoriAndroidRuntimeProbe.Sample s=NoriAndroidRuntimeProbe.capture(getContext());var l=brain.getLongSessionMonitor().snapshot();JSObject o=new JSObject();o.put("pssKb",s.pssKb);o.put("availableMemoryKb",s.availMemKb);o.put("batteryPct",s.batteryPct);o.put("charging",s.charging);o.put("sessionMs",l.sessionMs);o.put("requests",l.requests);o.put("failures",l.failures);o.put("consecutiveFailures",l.consecutiveFailures);o.put("p95LatencyMs",l.p95LatencyMs);o.put("health",l.health.name());c.resolve(o);}
 @PluginMethod public void modelSelect(PluginCall c){NoriOnDeviceTask t;try{t=NoriOnDeviceTask.valueOf(c.getString("task","TEXT_GENERATION"));}catch(Exception e){t=NoriOnDeviceTask.TEXT_GENERATION;}var q=new NoriModelSelectionEngine.Request(t,c.getBoolean("multimodal",false),c.getBoolean("privacyCritical",true),c.getLong("latencyBudgetMs",12000L),c.getLong("maxBytes",1024L*1024L*1024L),c.getInt("minContext",0));var x=brain.getModelSelectionEngine().choose(q);JSObject o=new JSObject();o.put("available",x.available);o.put("modelId",x.modelId);o.put("backend",x.backend);o.put("score",x.score);o.put("reason",x.reason);c.resolve(o);}
 @PluginMethod public void webGet(PluginCall c){String u=c.getString("url","");int timeout=c.getInt("timeoutMs",8000);int max=c.getInt("maxBytes",512000);new Thread(()->{try{NoriLiveWebRetrieval.Result r=brain.getLiveWebRetrieval().get(u,timeout,max);brain.getLongSessionMonitor().request("web",r.latencyMs,r.ok);JSObject o=new JSObject();o.put("ok",r.ok);o.put("status",r.status);o.put("url",r.url);o.put("body",r.body);o.put("error",r.error);o.put("retrievedAt",r.retrievedAt);o.put("latencyMs",r.latencyMs);c.resolve(o);}catch(Exception e){brain.getLongSessionMonitor().request("web",0,false);c.reject(e.getMessage()==null?e.getClass().getSimpleName():e.getMessage());}}).start();}
 @PluginMethod public void sessionHealth(PluginCall c){var s=brain.getLongSessionMonitor().snapshot();JSObject o=new JSObject();o.put("sessionMs",s.sessionMs);o.put("requests",s.requests);o.put("failures",s.failures);o.put("consecutiveFailures",s.consecutiveFailures);o.put("p95LatencyMs",s.p95LatencyMs);o.put("health",s.health.name());c.resolve(o);}
}
