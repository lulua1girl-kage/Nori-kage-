package com.nori.jarvis.nori.reasoning;

import java.util.*;

/** Explainable reasoning summary. It intentionally contains conclusions/evidence, not hidden chain-of-thought. */
public final class ReasoningResult {
    public final List<Evidence> evidence;
    public final List<String> assumptions;
    public final String conclusion;
    public final Confidence confidence;
    public final boolean verificationRequired;

    public ReasoningResult(List<Evidence> evidence, List<String> assumptions, String conclusion,
                           Confidence confidence, boolean verificationRequired) {
        this.evidence = Collections.unmodifiableList(new ArrayList<>(evidence == null ? Collections.emptyList() : evidence));
        this.assumptions = Collections.unmodifiableList(new ArrayList<>(assumptions == null ? Collections.emptyList() : assumptions));
        this.conclusion = conclusion;
        this.confidence = confidence == null ? Confidence.UNKNOWN : confidence;
        this.verificationRequired = verificationRequired;
    }
}
