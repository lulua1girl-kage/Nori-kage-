package com.nori.jarvis.nori.actions.model;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

public final class ToolRequest {
    public final String toolId;
    public final Map<String,String> input;

    public ToolRequest(String toolId, Map<String,String> input) {
        this.toolId = toolId;
        this.input = Collections.unmodifiableMap(new LinkedHashMap<>(input == null ? Collections.<String,String>emptyMap() : input));
    }
}
