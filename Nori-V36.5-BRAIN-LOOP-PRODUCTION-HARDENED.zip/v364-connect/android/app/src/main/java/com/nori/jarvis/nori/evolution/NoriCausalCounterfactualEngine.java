package com.nori.jarvis.nori.evolution;

import java.util.*;

/** Step 37: evidence-aware causal and counterfactual reasoning without claiming causality from correlation. */
public final class NoriCausalCounterfactualEngine {
    public enum Strength { NONE, HYPOTHESIS, ASSOCIATION, SUPPORTED }
    public static final class Evidence { public final String observation, source; public final double strength; public Evidence(String o,String s,double x){observation=o==null?"":o;source=s==null?"":s;strength=clamp(x);} }
    public static final class Assessment { public final String observation, proposedCause; public final Strength strength; public final double confidence; public final List<String> alternatives; public final List<String> missingEvidence;
        Assessment(String o,String c,Strength s,double x,List<String>a,List<String>m){observation=o;proposedCause=c;strength=s;confidence=x;alternatives=unmod(a);missingEvidence=unmod(m);} }
    public static final class Scenario { public final String variable,baseline,changed; public final List<String> expectedEffects,risks,checks; Scenario(String v,String b,String c,List<String>e,List<String>r,List<String>x){variable=v;baseline=b;changed=c;expectedEffects=unmod(e);risks=unmod(r);checks=unmod(x);} }
    public Assessment assess(String observation,String cause,List<Evidence> evidence){
        List<String>a=new ArrayList<>(),m=new ArrayList<>(); double total=0;int n=0;if(evidence!=null)for(Evidence e:evidence){if(e==null)continue;total+=e.strength;n++;}
        if(n==0){a.add("alternative causes remain plausible");m.add("independent evidence");return new Assessment(observation,cause,Strength.HYPOTHESIS,.25,a,m);}
        double c=Math.min(1,total/n);Strength s=c>=.8?Strength.SUPPORTED:c>=.5?Strength.ASSOCIATION:Strength.HYPOTHESIS;
        a.add("selection effects or confounding may explain the association");if(c<.8)m.add("stronger independent evidence or intervention data");
        return new Assessment(observation,cause,s,c,a,m);
    }
    public Scenario counterfactual(String goal,String variable,String baseline,String changed){
        List<String> effects=Arrays.asList("estimate effect on goal: "+goal,"compare changed state against baseline","watch for second-order effects");
        List<String> risks=Arrays.asList("assumption sensitivity","unintended trade-off","insufficient evidence");
        List<String> checks=Arrays.asList("keep non-changing constraints fixed where possible","define measurable outcome","verify after the change");
        return new Scenario(variable,baseline,changed,effects,risks,checks);
    }
    private static List<String> unmod(List<String>x){return Collections.unmodifiableList(new ArrayList<>(x));}private static double clamp(double x){return Double.isFinite(x)?Math.max(0,Math.min(1,x)):0;}
}
