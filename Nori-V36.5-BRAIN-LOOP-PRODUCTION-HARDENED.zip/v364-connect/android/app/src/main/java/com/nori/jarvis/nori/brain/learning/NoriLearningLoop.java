package com.nori.jarvis.nori.brain.learning;

import com.nori.jarvis.nori.education.EducationalIntelligence;
import com.nori.jarvis.nori.education.model.AcademicEvidence;
import com.nori.jarvis.nori.education.model.MistakeReport;
import java.time.*;
import java.util.*;

/**
 * Connects existing academic engines into one longitudinal learning loop.
 * It measures change and intervention effectiveness; it does not replace the academic engines.
 */
public final class NoriLearningLoop {
    public static final class Mastery {
        public final String subject; public final double mastery; public final double trend;
        public final int observations; public final String confidence;
        Mastery(String s,double m,double t,int o,String c){subject=s;mastery=clamp(m);trend=t;observations=Math.max(0,o);confidence=c;}
    }
    public static final class InterventionOutcome {
        public final String interventionId, subject, strategy; public final double before, after, delta;
        public final int observations; public final boolean effective; public final String interpretation;
        InterventionOutcome(String i,String s,String st,double b,double a,int o,boolean e,String x){interventionId=i;subject=s;strategy=st;before=b;after=a;delta=a-b;observations=o;effective=e;interpretation=x;}
    }
    public synchronized List<Mastery> mastery(EducationalIntelligence edu){
        List<AcademicEvidence> es=edu==null?Collections.emptyList():edu.evidence();
        Map<String,List<AcademicEvidence>> by=new LinkedHashMap<>(); for(AcademicEvidence e:es)by.computeIfAbsent(safe(e.subject),k->new ArrayList<>()).add(e);
        List<Mastery> out=new ArrayList<>(); for(Map.Entry<String,List<AcademicEvidence>> x:by.entrySet()){
            List<AcademicEvidence> a=x.getValue(); a.sort(Comparator.comparing(e->e.at));
            double recent=avg(a,Math.max(0,a.size()-3),a.size()); double older=avg(a,0,Math.max(1,a.size()-3));
            double m=recent/100.0; double t=(recent-older)/100.0;
            String c=a.size()>=5?"HIGH":a.size()>=2?"MODERATE":"LOW";
            out.add(new Mastery(x.getKey(),m,t,a.size(),c)); }
        out.sort((a,b)->Double.compare(a.mastery,b.mastery)); return Collections.unmodifiableList(out);
    }
    public synchronized LongitudinalReport evaluate(EducationalIntelligence edu){
        List<Mastery> ms=mastery(edu); double avg=0,tr=0; for(Mastery m:ms){avg+=m.mastery;tr+=m.trend;}
        if(!ms.isEmpty()){avg/=ms.size();tr/=ms.size();}
        MistakeReport mr=edu==null?null:edu.mistakes();
        return new LongitudinalReport(ms,avg,tr,mr==null?0:mr.patterns.size(),strategyFor(tr,mr));
    }
    public synchronized InterventionOutcome compareIntervention(EducationalIntelligence edu,String subject,String strategy,int window){
        List<AcademicEvidence> a=new ArrayList<>(); if(edu!=null)for(AcademicEvidence e:edu.evidence())if(safe(subject).equalsIgnoreCase(safe(e.subject)))a.add(e);
        a.sort(Comparator.comparing(e->e.at)); int n=Math.max(1,window); int split=Math.max(1,a.size()-n);
        double before=avg(a,0,split), after=avg(a,split,a.size()); int obs=a.size();
        boolean effective=obs>=4 && after>=before+5;
        String interpretation=obs<4?"insufficient evidence":effective?"positive change observed; causality not established":after>before?"small improvement; effect uncertain":after<before-5?"performance declined; review intervention":"no material change observed";
        return new InterventionOutcome("int_"+Integer.toHexString(Objects.hash(subject,strategy,obs)),safe(subject),safe(strategy),before/100,after/100,obs,effective,interpretation);
    }
    private String strategyFor(double trend,MistakeReport m){if(trend>0.05)return "retain_working_strategy_and_increase_difficulty_gradually"; if(m!=null&&!m.patterns.isEmpty())return "targeted_mistake_intervention_then_remeasure"; if(trend<-0.05)return "review_strategy_and_reduce_unnecessary_load"; return "continue_current_strategy_and_collect_more_evidence";}
    public static final class LongitudinalReport { public final List<Mastery> mastery; public final double overallMastery,overallTrend; public final int repeatedMistakePatterns; public final String nextStrategy; LongitudinalReport(List<Mastery> m,double o,double t,int r,String n){mastery=Collections.unmodifiableList(new ArrayList<>(m));overallMastery=o;overallTrend=t;repeatedMistakePatterns=r;nextStrategy=n;} }
    private static double avg(List<AcademicEvidence>a,int s,int e){if(a==null||s>=e)return 0;double v=0;for(int i=s;i<e;i++)v+=a.get(i).score;return v/(e-s);}
    private static String safe(String s){return s==null?"":s.trim();} private static double clamp(double x){return Double.isFinite(x)?Math.max(0,Math.min(1,x)):0;}
}
