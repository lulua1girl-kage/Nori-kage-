package com.nori.jarvis.visual;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.ImageFormat;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.os.Bundle;
import android.view.Surface;
import android.view.TextureView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.*;
import java.nio.ByteBuffer;

/** One-shot, user-visible camera context capture. Never opens the camera in the background. */
public class NoriCameraActivity extends Activity {
    private static final int REQ_CAMERA = 4101;
    private TextureView preview;
    private CameraDevice camera;
    private CameraCaptureSession session;
    private ImageReader reader;
    private boolean closing;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        TextView label = new TextView(this);
        label.setText("NORI CAMERA CONTEXT — capture only when you press Capture");
        label.setPadding(24, 24, 24, 12);
        preview = new TextureView(this);
        root.addView(label, new LinearLayout.LayoutParams(-1, 0, 1));
        root.addView(preview, new LinearLayout.LayoutParams(-1, 0, 4));
        LinearLayout row = new LinearLayout(this);
        Button capture = new Button(this); capture.setText("CAPTURE");
        Button cancel = new Button(this); cancel.setText("CANCEL");
        row.addView(capture, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(cancel, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);
        setContentView(root);
        capture.setOnClickListener(v -> capture());
        cancel.setOnClickListener(v -> finishCanceled());
        preview.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) { openCamera(); }
            public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) {}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { return true; }
            public void onSurfaceTextureUpdated(SurfaceTexture s) {}
        });
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQ_CAMERA);
    }

    @Override public void onRequestPermissionsResult(int request, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(request, permissions, results);
        if (request == REQ_CAMERA && (results.length == 0 || results[0] != PackageManager.PERMISSION_GRANTED)) finishCanceled();
        else if (request == REQ_CAMERA && preview.isAvailable()) openCamera();
    }

    private void openCamera() {
        if (closing || ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return;
        try {
            CameraManager cm = (CameraManager)getSystemService(CAMERA_SERVICE);
            String id = null;
            for (String x : cm.getCameraIdList()) { CameraCharacteristics c = cm.getCameraCharacteristics(x); Integer facing = c.get(CameraCharacteristics.LENS_FACING); if (facing != null && facing == CameraCharacteristics.LENS_FACING_BACK) { id=x; break; } if(id==null) id=x; }
            if (id == null) { finishError("No camera found"); return; }
            reader = ImageReader.newInstance(1280, 720, ImageFormat.JPEG, 2);
            reader.setOnImageAvailableListener(r -> saveLatest(r), null);
            cm.openCamera(id, new CameraDevice.StateCallback() {
                public void onOpened(CameraDevice c) { camera=c; startPreview(); }
                public void onDisconnected(CameraDevice c) { c.close(); if(!closing) finishError("Camera disconnected"); }
                public void onError(CameraDevice c, int e) { c.close(); if(!closing) finishError("Camera error: "+e); }
            }, null);
        } catch (Exception e) { finishError(e.getMessage()); }
    }

    private void startPreview() {
        try {
            SurfaceTexture st = preview.getSurfaceTexture(); if (st == null) return;
            st.setDefaultBufferSize(1280,720);
            Surface s = new Surface(st);
            CaptureRequest.Builder b = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            b.addTarget(s);
            camera.createCaptureSession(java.util.Arrays.asList(s, reader.getSurface()), new CameraCaptureSession.StateCallback() {
                public void onConfigured(CameraCaptureSession cs) { if(closing)return; session=cs; try{cs.setRepeatingRequest(b.build(),null,null);}catch(Exception ignored){} }
                public void onConfigureFailed(CameraCaptureSession cs) { finishError("Camera preview failed"); }
            }, null);
        } catch(Exception e){ finishError(e.getMessage()); }
    }

    private void capture() {
        if(camera==null||session==null) return;
        try {
            CaptureRequest.Builder b=camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
            b.addTarget(reader.getSurface());
            b.set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO);
            session.capture(b.build(), new CameraCaptureSession.CaptureCallback(){}, null);
        } catch(Exception e){ finishError(e.getMessage()); }
    }

    private void saveLatest(ImageReader r) {
        if(closing) return;
        Image image=null;
        try {
            image=r.acquireLatestImage(); if(image==null)return;
            ByteBuffer buf=image.getPlanes()[0].getBuffer(); byte[] bytes=new byte[buf.remaining()]; buf.get(bytes);
            File dir=new File(getCacheDir(),"nori_visual"); if(!dir.exists())dir.mkdirs();
            File out=new File(dir,"camera_"+System.currentTimeMillis()+".jpg");
            try(FileOutputStream fos=new FileOutputStream(out)){fos.write(bytes);}
            Intent result=new Intent(); result.putExtra("path",out.getAbsolutePath()); setResult(RESULT_OK,result); finish();
        } catch(Exception e){ finishError(e.getMessage()); } finally { if(image!=null) image.close(); }
    }

    private void finishCanceled(){ closing=true; cleanup(); setResult(RESULT_CANCELED); finish(); }
    private void finishError(String message){ closing=true; cleanup(); Intent i=new Intent(); i.putExtra("error",message); setResult(RESULT_CANCELED,i); finish(); }
    private void cleanup(){ try{if(session!=null)session.close();}catch(Exception ignored){} try{if(camera!=null)camera.close();}catch(Exception ignored){} try{if(reader!=null)reader.close();}catch(Exception ignored){} }
    @Override protected void onDestroy(){ closing=true; cleanup(); super.onDestroy(); }
}
