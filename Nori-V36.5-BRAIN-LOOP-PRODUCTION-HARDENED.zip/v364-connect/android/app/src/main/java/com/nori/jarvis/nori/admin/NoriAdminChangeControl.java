package com.nori.jarvis.nori.admin;

import com.nori.jarvis.nori.admin.model.AdminRole;
import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Protected production-change workflow. Students never receive code-edit permissions.
 * The app can create a signed change request; actual source mutation/deployment must occur
 * in a trusted admin/server environment, followed by tests and an explicit release step.
 */
public final class NoriAdminChangeControl {
    public enum Status { DRAFT, TEST_REQUIRED, READY_FOR_REVIEW, APPROVED, REJECTED, DEPLOYED, ROLLED_BACK }
    public static final class Change {
        public final String id, actor, summary, patchHash; public final Status status; public final long createdAt;
        public Change(String i,String a,String s,String h,Status st,long t){id=i;actor=a;summary=s;patchHash=h;status=st;createdAt=t;}
    }
    private final List<Change> changes=new ArrayList<>();
    public synchronized Change propose(String actor, AdminRole role, String summary, String patch){
        if(role!=AdminRole.OWNER && role!=AdminRole.ADMIN)return null;
        if(blank(actor)||blank(summary)||blank(patch))return null;
        Change c=new Change(UUID.randomUUID().toString(),actor,summary,sha(patch),Status.TEST_REQUIRED,System.currentTimeMillis());changes.add(c);return c;
    }
    public synchronized Change markTestsPassed(String actor,AdminRole role,String id){return transition(actor,role,id,Status.READY_FOR_REVIEW);}
    public synchronized Change approve(String actor,AdminRole role,String id){if(role!=AdminRole.OWNER)return null;return transition(actor,role,id,Status.APPROVED);}
    public synchronized Change deployed(String actor,AdminRole role,String id){if(role!=AdminRole.OWNER)return null;return transition(actor,role,id,Status.DEPLOYED);}
    public synchronized List<Change> history(){return Collections.unmodifiableList(new ArrayList<>(changes));}
    private Change transition(String actor,AdminRole role,String id,Status next){if(role!=AdminRole.OWNER&&role!=AdminRole.ADMIN)return null;for(int i=0;i<changes.size();i++){Change c=changes.get(i);if(c.id.equals(id)){Change n=new Change(c.id,c.actor,c.summary,c.patchHash,next,c.createdAt);changes.set(i,n);return n;}}return null;}
    private static boolean blank(String s){return s==null||s.trim().isEmpty();}
    private static String sha(String s){try{byte[] b=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));StringBuilder x=new StringBuilder();for(byte v:b)x.append(String.format(Locale.ROOT,"%02x",v));return x.toString();}catch(Exception e){return Integer.toHexString(s.hashCode());}}
}
