package com.nori.jarvis.nori.benchmark;

import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.data.DataRepository;
import com.nori.jarvis.nori.meta.NoriMetaBrainEngine;
import com.nori.jarvis.nori.evolution.NoriCausalCounterfactualEngine;
import com.nori.jarvis.nori.learning.NoriAdvancedLearningEngine;
import com.nori.jarvis.nori.research.NoriResearchBrain2;
import java.util.*;

/** Cross-stage smoke: validates the integrated request path plus Steps 36-43 specialist engines. */
public final class NoriStep36to43Smoke {
 static final class R implements DataRepository { final Map<String,String> m=new HashMap<>(); public boolean putJson(String k,String v,String c,int s){m.put(k,v);return true;} public String getJson(String k){return m.get(k);} public boolean contains(String k){return m.containsKey(k);} public boolean delete(String k){return m.remove(k)!=null;} }
 public static void main(String[] args){
  NoriBrain b=new NoriBrain(new R());
  var cycle=b.processMetaBrain("latest study methods and help me plan tomorrow","school context",true,true,true,NoriMetaBrainEngine.Capacity.NORMAL);
  if(cycle.capabilities.size()!=30)throw new RuntimeException("meta capabilities not integrated");
  if(cycle.world==null||cycle.researchPlan==null||cycle.humanPlan==null||cycle.causalAssessment==null)throw new RuntimeException("integrated state missing");
  if(cycle.integrationTrace.size()<8)throw new RuntimeException("pipeline trace incomplete");
  b.getPersonalWorldModel().observe("goal","academic","improve biology","smoke",com.nori.jarvis.nori.world.NoriPersonalWorldModel.Kind.GOAL,.9);
  if(b.getPersonalWorldModel().snapshot().activeGoals.isEmpty())throw new RuntimeException("world persistence model failed");
  var ca=b.getCausalCounterfactualEngine().counterfactual("study goal","study time","2h","1h");
  if(ca.checks.size()<2)throw new RuntimeException("counterfactual incomplete");
  b.getAdvancedLearningEngine().record(new NoriAdvancedLearningEngine.Attempt("Math","quadratics","sign_error","practice",NoriAdvancedLearningEngine.Outcome.INCORRECT));
  b.getAdvancedLearningEngine().record(new NoriAdvancedLearningEngine.Attempt("Math","quadratics","sign_error","exam",NoriAdvancedLearningEngine.Outcome.INCORRECT));
  b.getAdvancedLearningEngine().record(new NoriAdvancedLearningEngine.Attempt("Math","quadratics","sign_error","quiz",NoriAdvancedLearningEngine.Outcome.INCORRECT));
  if(b.getAdvancedLearningEngine().analyze().interventions.isEmpty())throw new RuntimeException("misconception engine failed");
  var rp=b.getResearchBrain2().synthesize("deep research latest study methods",Collections.emptyList());
  if(rp.targetSources!=25)throw new RuntimeException("research depth failed");
  var fp=b.getFailureRecoveryEngine().plan("network timeout",true,true); if(!fp.retry||!fp.alternate)throw new RuntimeException("recovery plan failed");
  var bench=b.getIntegrationBenchmark().evaluate(NoriIntegrationBenchmark.defaultCases(), c->{var x=b.processMetaBrain(c.input,"",true,c.expectTool,c.expectFresh,NoriMetaBrainEngine.Capacity.NORMAL);return new NoriIntegrationBenchmark.Decision(x.cognition.needsTool,x.requiresFreshEvidence);});
  if(!bench.pass())throw new RuntimeException("benchmark failures="+bench.failures);
  System.out.println("POST23_STEP36_43_INTEGRATION_PASS trace="+cycle.integrationTrace.size()+" benchmark="+bench.passed+"/"+bench.total+" worldSeq="+cycle.world.sequence);
 }
}
