package com.nori.jarvis.nori.edgeai;

/** Lightweight optional-runtime detection; keeps the base APK build independent of large AI SDKs. */
public final class NoriEdgeAiReflection {
    private NoriEdgeAiReflection(){}
    public static boolean classPresent(String name){try{Class.forName(name);return true;}catch(Throwable ignored){return false;}}
    public static boolean mediaPipeLlmPresent(){return classPresent("com.google.mediapipe.tasks.genai.llminference.LlmInference");}
    public static boolean mlKitPresent(){return classPresent("com.google.mlkit.genai.prompt.GenerativeModel");}
    public static boolean onnxPresent(){return classPresent("ai.onnxruntime.OrtEnvironment");}
    public static boolean liteRtPresent(){return classPresent("com.google.ai.edge.litert.InterpreterApi");}
}
