package com.nori.jarvis.nori.performance;

import android.app.ActivityManager;
import android.content.Context;
import android.os.BatteryManager;
import android.os.Debug;
import java.util.*;

/** Device-side probe for real memory/battery/action measurements. No background polling is performed. */
public final class NoriAndroidRuntimeProbe {
 public static final class Sample { public final long pssKb,availMemKb; public final int batteryPct; public final boolean charging; public Sample(long p,long a,int b,boolean c){pssKb=p;availMemKb=a;batteryPct=b;charging=c;} }
 public static Sample capture(Context ctx){if(ctx==null)throw new IllegalArgumentException("context");ActivityManager am=(ActivityManager)ctx.getSystemService(Context.ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);Debug.MemoryInfo dm=new Debug.MemoryInfo();Debug.getMemoryInfo(dm);BatteryManager bm=(BatteryManager)ctx.getSystemService(Context.BATTERY_SERVICE);int pct=-1;long p=bm==null?-1:bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);if(p>=0)pct=(int)p;boolean charging=bm!=null&&bm.isCharging();return new Sample(dm.getTotalPss(),mi.availMem/1024,pct,charging);}
}
