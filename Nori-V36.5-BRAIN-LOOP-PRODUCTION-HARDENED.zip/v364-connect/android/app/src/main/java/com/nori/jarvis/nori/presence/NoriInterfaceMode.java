package com.nori.jarvis.nori.presence;

/** Presentation only. All modes share the same Nori Brain, memory, conversation and state. */
public enum NoriInterfaceMode {
    STANDARD("Nori Standard"), KAGE("Kage Avatar"), CIRCLE("Interactive Circle"), HYBRID("Hybrid"), COMPACT("Compact / Fast");
    public final String label;
    NoriInterfaceMode(String label){this.label=label;}
}
