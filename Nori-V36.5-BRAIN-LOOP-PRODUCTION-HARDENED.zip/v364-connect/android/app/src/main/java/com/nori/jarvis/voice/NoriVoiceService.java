package com.nori.jarvis.voice;

import android.app.*;
import android.content.*;
import android.os.*;
import android.speech.*;
import android.speech.tts.TextToSpeech;
import androidx.core.app.ServiceCompat;
import java.util.*;
import com.nori.jarvis.nori.voice.NoriVoiceCommand;
import com.nori.jarvis.nori.voice.NoriVoiceCommandRouter;

/**
 * Explicitly user-started background voice session.
 * Android foreground-service rules still apply; this service never self-starts
 * microphone capture and expires the session after a bounded period.
 */
public class NoriVoiceService extends Service implements RecognitionListener {
    public static final String ACTION_CONFIG="com.nori.jarvis.voice.CONFIG";
    public static final String ACTION_STOP="com.nori.jarvis.voice.STOP";
    public static final String ACTION_SPEAK="com.nori.jarvis.voice.SPEAK";
    public static final String EVENT_WAKE="com.nori.jarvis.voice.WAKE";
    public static final String EVENT_SPEECH="com.nori.jarvis.voice.SPEECH";
    public static final String EVENT_STATE="com.nori.jarvis.voice.STATE";
    private static final long MAX_SESSION_MS=30L*60L*1000L;
    private static final int NOTIFICATION_ID=7411;
    SpeechRecognizer r; TextToSpeech t; boolean running,active,listening; String wake="nori"; String languageTag="en-US";
    final NoriVoiceCommandRouter commandRouter=new NoriVoiceCommandRouter();
    final Handler h=new Handler(Looper.getMainLooper());
    final Runnable expiry=()->{emit(EVENT_STATE,"expired");stopVoice();};

    @Override public void onCreate(){super.onCreate();channel();t=new TextToSpeech(this,x->{if(x==0)t.setLanguage(Locale.US);});}

    @Override public int onStartCommand(Intent in,int flags,int id){
        if(in!=null){
            String a=in.getAction();
            if(ACTION_STOP.equals(a)){stopVoice();return START_NOT_STICKY;}
            if(ACTION_SPEAK.equals(a)){speak(in.getStringExtra("text"));if(!running)h.postDelayed(this::stopSelf,3500);return START_NOT_STICKY;}
            if(ACTION_CONFIG.equals(a)){
                String w=in.getStringExtra("wakeWord"); if(w!=null&&!w.trim().isEmpty())wake=w.trim().toLowerCase(Locale.US);
                String lang=in.getStringExtra("languageTag"); if(lang!=null&&!lang.trim().isEmpty()) languageTag=lang.trim();
                if(in.getBooleanExtra("backgroundOptIn",false) || in.getBooleanExtra("ambientVoiceOptIn",false))startBackgroundSession();
            }
        }
        return START_NOT_STICKY;
    }

    private void startBackgroundSession(){
        if(running)return;
        if(Build.VERSION.SDK_INT>=29){ /* foregroundServiceType is declared in the manifest */ }
        running=true; active=false; listening=false;
        if(Build.VERSION.SDK_INT>=29) ServiceCompat.startForeground(this,NOTIFICATION_ID,note("Background voice ON — tap Nori to return or Stop to end"),android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE); else startForeground(NOTIFICATION_ID,note("Background voice ON — tap Nori to return or Stop to end"));
        h.removeCallbacks(expiry); h.postDelayed(expiry,MAX_SESSION_MS);
        listen(); emit(EVENT_STATE,"background-listening");
    }

    private void listen(){
        if(!running||listening)return;
        if(!SpeechRecognizer.isRecognitionAvailable(this)){emit(EVENT_STATE,"speech-unavailable");return;}
        try{
            if(r!=null)r.destroy();
            r=SpeechRecognizer.createSpeechRecognizer(this); r.setRecognitionListener(this);
            Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,languageTag); i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true); i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3);
            listening=true; r.startListening(i);
        }catch(Exception e){listening=false;h.postDelayed(this::listen,1000);}
    }
    private void restart(){if(running)h.postDelayed(this::listen,350);}
    private void text(String s){
        if(s==null||s.trim().isEmpty())return; String x=s.trim(),l=x.toLowerCase(Locale.US);
        if(!active){if(l.equals(wake)||l.startsWith(wake+" ")||l.contains(" "+wake+" ")){active=true;emit(EVENT_WAKE,x);speak("I'm listening.");update("Nori active — listening");}}
        else{emit(EVENT_SPEECH,x); NoriVoiceCommand command=commandRouter.parse(x); if(command.type!=NoriVoiceCommand.Type.NONE){emit("com.nori.jarvis.voice.COMMAND",command.type.name()+"|"+command.target); commandNotification(command);}
        if(l.contains("nori shut down")||l.contains("nori close yourself")||l.equals("nori close")||l.equals("nori shutdown")){active=false;speak("Closing voice mode.");update("Background voice stopped");emit(EVENT_STATE,"stopped");}}
    }
    private void commandNotification(NoriVoiceCommand command){
        Intent open=getPackageManager().getLaunchIntentForPackage(getPackageName());
        String text="Nori heard: "+command.type.name().replace('_',' ');
        if(command.type==NoriVoiceCommand.Type.NEW_RESULT||command.type==NoriVoiceCommand.Type.NEW_ASSESSMENT||command.type==NoriVoiceCommand.Type.NEW_ASSIGNMENT||command.type==NoriVoiceCommand.Type.ADD_SUBJECT||command.type==NoriVoiceCommand.Type.START_EXAM_MODE){
            open=new Intent(this,NoriVoiceWorkspaceActivity.class);
            NoriVoiceCommand.Type t=command.type==NoriVoiceCommand.Type.ADD_SUBJECT?NoriVoiceCommand.Type.NEW_RESULT:command.type;
            open.putExtra("mode",t.name());
        } else if(command.type==NoriVoiceCommand.Type.SCAN_STUDY_LIBRARY||command.type==NoriVoiceCommand.Type.OPEN_STUDY_RESOURCE){ open=new Intent(this,com.nori.jarvis.nori.library.NoriStudyLibraryActivity.class); text="RETURN TO Nori study library"; } else if(command.type==NoriVoiceCommand.Type.ANOTHER_ENTRY){ open=new Intent(this,NoriVoiceWorkspaceActivity.class); open.putExtra("mode","NEW_RESULT"); text="RETURN TO CONTINUE — another result"; } else if(command.type==NoriVoiceCommand.Type.OPEN_APP){
            String pkg=resolveApp(command.target); boolean blocked=getSharedPreferences("nori_focus_policy",MODE_PRIVATE).getBoolean("active",false) && getSharedPreferences("nori_focus_policy",MODE_PRIVATE).getStringSet("blocked_packages",Collections.emptySet()).contains(pkg);
            if(!pkg.isEmpty()&&!blocked){Intent candidate=getPackageManager().getLaunchIntentForPackage(pkg);if(candidate!=null){open=candidate;text="RETURN TO CONTINUE — "+command.target;}} else if(blocked){text="Focus restriction active — Nori kept the request inside the system boundary.";}
        }
        if(open==null)return; open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(this,7412,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification n=new Notification.Builder(this,"nori_voice").setContentTitle("NORI — RETURN TO CONTINUE").setContentText(text).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(pi).setOngoing(true).build();
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID,n);
    }
    private String resolveApp(String name){String x=name==null?"":name.toLowerCase(Locale.ROOT).trim();if(x.equals("instagram"))return "com.instagram.android";if(x.equals("pinterest"))return "com.pinterest";if(x.equals("youtube"))return "com.google.android.youtube";if(x.equals("wps")||x.equals("wps office"))return "cn.wps.moffice_eng";if(x.equals("chrome"))return "com.android.chrome";return "";}
    private void speak(String s){if(t!=null&&s!=null&&!s.isEmpty())t.speak(s,TextToSpeech.QUEUE_FLUSH,null,"nori");}
    private void emit(String a,String s){Intent i=new Intent(a);i.setPackage(getPackageName());i.putExtra("text",s);sendBroadcast(i);}
    public void stopVoice(){
        running=false;listening=false;active=false;h.removeCallbacks(expiry);
        if(r!=null){try{r.cancel();r.destroy();}catch(Exception ignored){}r=null;}
        stopForeground(true);stopSelf();emit(EVENT_STATE,"stopped");
    }
    @Override public void onDestroy(){stopVoice();if(t!=null){try{t.stop();t.shutdown();}catch(Exception ignored){}t=null;}super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    private Notification note(String s){Intent o=getPackageManager().getLaunchIntentForPackage(getPackageName());PendingIntent p=PendingIntent.getActivity(this,1,o,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Intent stop=new Intent(this,NoriVoiceStopReceiver.class);PendingIntent sp=PendingIntent.getBroadcast(this,2,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new Notification.Builder(this,"nori_voice").setContentTitle("NORI VOICE").setContentText(s).setSmallIcon(android.R.drawable.ic_btn_speak_now).setContentIntent(p).addAction(new Notification.Action.Builder(null,"STOP",sp).build()).setOngoing(true).build();}
    private void channel(){if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("nori_voice","Nori Voice",NotificationManager.IMPORTANCE_LOW));}
    private void update(String s){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID,note(s));}
    public void onReadyForSpeech(Bundle b){} public void onBeginningOfSpeech(){} public void onRmsChanged(float x){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){listening=false;restart();} public void onError(int e){listening=false;restart();}
    public void onResults(Bundle b){listening=false;ArrayList<String>a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(a!=null&&!a.isEmpty())text(a.get(0));restart();}
    public void onPartialResults(Bundle b){ArrayList<String>a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(a!=null&&!a.isEmpty()){String partial=a.get(0); if(active) emit(EVENT_SPEECH,partial); else {String l=partial.toLowerCase(Locale.US); if(l.equals(wake)||l.startsWith(wake+" ")||l.contains(" "+wake+" ")) {active=true;emit(EVENT_WAKE,partial);speak("I'm listening.");update("Nori active — listening");}}}}
    public void onEvent(int t,Bundle b){}
}
