package com.nori.jarvis.nori.education;

import com.nori.jarvis.nori.education.engine.*; import com.nori.jarvis.nori.education.model.*; import com.nori.jarvis.nori.data.DataRepository; import java.time.*; import java.util.*; import java.nio.charset.StandardCharsets; import java.util.Base64;

/** Stage 12 offline-first educational intelligence coordinator. */
public final class EducationalIntelligence {
    private final StrengthWeaknessEngine strengthWeakness=new StrengthWeaknessEngine();
    private final MistakeIntelligence mistakeIntelligence=new MistakeIntelligence();
    private final LearningPatternAnalyzer learningPatterns=new LearningPatternAnalyzer();
    private final StudyPlanner planner=new StudyPlanner();
    private final ExamPreparationEngine exams=new ExamPreparationEngine();
    private final DynamicStudySessionEngine sessions=new DynamicStudySessionEngine();
    private final AdaptiveTutorPolicy tutor=new AdaptiveTutorPolicy();
    private static final String KEY="nori.educational_intelligence.evidence.v1";
    private final List<AcademicEvidence> evidence=new ArrayList<>();
    private final DataRepository repository;
    public EducationalIntelligence(){this(null);}
    public EducationalIntelligence(DataRepository repository){this.repository=repository; load();}
    public synchronized void recordEvidence(AcademicEvidence e){if(e!=null){evidence.add(e);if(evidence.size()>1000)evidence.remove(0);save();}}
    private void load(){
        if(repository==null)return; String raw=repository.getJson(KEY); if(raw==null||raw.isEmpty())return;
        try{for(String row:raw.split("\n")){String[] f=row.split("\t",-1);if(f.length<8)continue;
            String subject=dec(f[0]),topic=dec(f[1]); double score=Double.parseDouble(f[2]);
            List<String> missed=new ArrayList<>(); if(!f[3].isEmpty())for(String x:f[3].split(",",-1))missed.add(dec(x));
            int careless=Integer.parseInt(f[4]),application=Integer.parseInt(f[5]); LocalDateTime at=LocalDateTime.parse(dec(f[6]));
            evidence.add(new AcademicEvidence(subject,topic,score,missed,careless,application,at)); if(evidence.size()>=1000)break;
        }}catch(Exception ignored){}
    }
    private void save(){
        if(repository==null)return; StringBuilder b=new StringBuilder();
        for(AcademicEvidence e:evidence){if(b.length()>0)b.append('\n');b.append(enc(e.subject)).append('\t').append(enc(e.topic)).append('\t').append(e.score).append('\t');
            for(int i=0;i<e.missedConcepts.size();i++){if(i>0)b.append(',');b.append(enc(e.missedConcepts.get(i)));}
            b.append('\t').append(e.carelessErrors).append('\t').append(e.applicationErrors).append('\t').append(enc(e.at.toString())).append('\t').append('1');}
        repository.putJson(KEY,b.toString(),"education",1);
    }
    private static String enc(String s){return Base64.getUrlEncoder().withoutPadding().encodeToString((s==null?"":s).getBytes(StandardCharsets.UTF_8));}
    private static String dec(String s){return new String(Base64.getUrlDecoder().decode(s),StandardCharsets.UTF_8);}
    public synchronized List<AcademicEvidence> evidence(){return Collections.unmodifiableList(new ArrayList<>(evidence));}
    public synchronized StrengthWeaknessReport assess(){return strengthWeakness.analyze(evidence);}
    public synchronized MistakeReport mistakes(){return mistakeIntelligence.analyze(evidence);}
    public synchronized List<LearningPatternAnalyzer.Pattern> learningPatterns(){return learningPatterns.analyze(evidence);}
    public synchronized StudyPlan plan(List<StudyTask> tasks,int minutes){return planner.plan(tasks,minutes,LocalDateTime.now(),assess());}
    public synchronized ExamPreparation prepareExam(String subject,String title,LocalDateTime at,int minutesPerDay){return exams.prepare(subject,title,at,assess(),minutesPerDay);}
    public synchronized DynamicStudySession session(String subject,String topic,int availableMinutes,boolean nearExam){
        StrengthWeaknessReport.SubjectState s=assess().subjects.get(subject); return sessions.adapt(subject,topic,s,mistakes(),availableMinutes,nearExam);
    }
    public TutoringPolicy tutoring(String subject,boolean conceptual,boolean calculationHeavy,boolean struggling,boolean confident){return tutor.choose(subject,conceptual,calculationHeavy,struggling,confident);}
}
