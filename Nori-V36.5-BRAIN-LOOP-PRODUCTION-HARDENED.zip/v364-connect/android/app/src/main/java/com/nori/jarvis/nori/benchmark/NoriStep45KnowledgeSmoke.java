package com.nori.jarvis.nori.benchmark;
import com.nori.jarvis.nori.library.*;import com.nori.jarvis.nori.knowledge.*;import com.nori.jarvis.nori.learning.*;import java.util.*;
public final class NoriStep45KnowledgeSmoke{
 public static void main(String[] a){
  NoriLibraryIndex l=new NoriLibraryIndex(null);boolean ok=l.add(new NoriLibraryIndex.Entry("1","physics.pdf","content://1",100,"physics","WPS",System.currentTimeMillis(),NoriLibraryIndex.Kind.PDF,NoriLibraryIndex.Status.INDEXED,4));
  if(!ok||l.remainingBytes()!=NoriLibraryIndex.MAX_LIBRARY_BYTES-100)throw new AssertionError();
  NoriKnowledgeSourceRegistry r=new NoriKnowledgeSourceRegistry();if(r.all().size()<10)throw new AssertionError();
  NoriAutonomousLearningEngine e=new NoriAutonomousLearningEngine(r);if(e.plan("physics",15).sourceIds.size()<3)throw new AssertionError();
  NoriContradictionResolver c=new NoriContradictionResolver();List<NoriContradictionResolver.Claim>x=Arrays.asList(new NoriContradictionResolver.Claim("a","x","teacher","today",90),new NoriContradictionResolver.Claim("b","y","web","today",70));if(!c.compare(x).needsUserPriority)throw new AssertionError();
  NoriSubjectMasteryRegistry s=new NoriSubjectMasteryRegistry();if(!"Physics".equals(s.route("physics mechanics").name))throw new AssertionError();
  System.out.println("STEP45_KNOWLEDGE_PASS library15GB=true sources="+r.all().size()+" contradiction=ask priority");
 }
}
