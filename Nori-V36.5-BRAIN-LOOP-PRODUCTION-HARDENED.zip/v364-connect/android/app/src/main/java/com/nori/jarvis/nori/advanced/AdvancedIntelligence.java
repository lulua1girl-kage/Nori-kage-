package com.nori.jarvis.nori.advanced;

import com.nori.jarvis.nori.education.model.*;import com.nori.jarvis.nori.education.*;import com.nori.jarvis.nori.advanced.engine.*;import com.nori.jarvis.nori.advanced.model.*;import java.util.*;

/** Stage 16: higher-order, explainable intelligence built over Stage 12 evidence. */
public final class AdvancedIntelligence {
    private final EducationalIntelligence education; private final TrajectoryAnalyzer trajectory=new TrajectoryAnalyzer(); private final AnomalyDetector anomaly=new AnomalyDetector(); private final StrategyEngine strategy=new StrategyEngine();
    public AdvancedIntelligence(EducationalIntelligence education){this.education=Objects.requireNonNull(education);}
    public TrajectoryReport trajectory(String subject){return trajectory.analyze(subject,education.evidence());}
    public AnomalyReport anomaly(String subject){return anomaly.detect(subject,education.evidence());}
    public StrategyRecommendation recommend(String subject,int minutes,boolean nearExam){
        StrengthWeaknessReport report=education.assess();StrengthWeaknessReport.SubjectState state=report.subjects.get(subject);boolean weak=state!=null && state.mastery<0.80;
        MistakeReport mr=education.mistakes();int repeated=0,careless=0,application=0;
        for(MistakeReport.Pattern x:mr.patterns){if(x.key!=null && x.key.toLowerCase(Locale.ROOT).contains(subject.toLowerCase(Locale.ROOT))){if("repeated_concept".equals(x.type))repeated+=x.count;else if("careless_error".equals(x.type))careless+=x.count;else if("application_error".equals(x.type))application+=x.count;}}
        return strategy.choose(subject,new StrategyEngine.StrengthWeaknessSnapshot(weak),new StrategyEngine.MistakeSnapshot(repeated,careless,application),trajectory(subject),minutes,nearExam);
    }
    public AdvancedInsight inspect(String subject,int minutes,boolean nearExam){
        TrajectoryReport t=trajectory(subject);AnomalyReport a=anomaly(subject);StrategyRecommendation r=recommend(subject,minutes,nearExam);List<String> facts=new ArrayList<>();facts.addAll(t.evidence);facts.addAll(a.evidence);
        List<String> inf=new ArrayList<>();inf.add("trajectory="+t.direction);if(a.anomalous)inf.add("latest_observation_anomaly="+a.type);inf.add("selected_strategy="+r.strategy);
        List<String> actions=Collections.singletonList(r.strategy+" for approximately "+r.minutes+" minutes");List<String> warnings=new ArrayList<>();warnings.add("Patterns are evidence-based signals, not diagnoses or proof of causation.");if(a.anomalous)warnings.add("Verify the latest result before changing the long-term study model.");
        return new AdvancedInsight(subject,"ready",Math.min(t.confidence,a.confidence),facts,inf,actions,warnings);
    }
}
