package com.nori.jarvis.nori.actions.model;

public enum ActionStatus { PENDING_CONFIRMATION, EXECUTED, CANCELLED, FAILED, UNDONE }
