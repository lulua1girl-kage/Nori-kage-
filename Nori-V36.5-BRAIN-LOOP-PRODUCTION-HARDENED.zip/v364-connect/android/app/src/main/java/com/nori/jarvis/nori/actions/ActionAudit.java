package com.nori.jarvis.nori.actions;

import java.time.Instant;

public final class ActionAudit {
    public final String event;
    public final String proposalId;
    public final String operationId;
    public final String toolId;
    public final Instant at;
    public final String detail;

    public ActionAudit(String event, String proposalId, String operationId, String toolId, String detail) {
        this.event=event; this.proposalId=proposalId; this.operationId=operationId; this.toolId=toolId; this.detail=detail; this.at=Instant.now();
    }
}
