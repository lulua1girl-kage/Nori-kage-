package com.nori.jarvis.nori.brain.reasoning;

import com.nori.jarvis.nori.brain.cognition.NoriCognitiveEngine;
import java.util.*;

/** Visible reasoning status, not hidden chain-of-thought. */
public final class NoriReasoningNarrator {
    public List<String> status(NoriCognitiveEngine.ThoughtState t){if(t==null)return Collections.singletonList("No reasoning state available.");List<String>x=new ArrayList<>();x.add("Intent: "+t.intent.name());x.add("Confidence: "+t.confidence.name());if(t.needsEvidence)x.add("Evidence check required");if(t.needsTool)x.add("Tool capability required");if(t.needsVerification)x.add("Result verification required");if(t.needsClarification)x.add("Clarification needed");return Collections.unmodifiableList(x);}
}
