package com.nori.jarvis.nori.memory;

import java.util.Locale;

/** One governed item of Nori's long-term memory. */
public final class MemoryItem {
    public enum Status { CONFIRMED, LIKELY, UNCERTAIN, ARCHIVED }
    public enum Category { GOALS, PREFERENCES, PROJECTS, ACADEMIC, SYSTEM_CONFIGURATION, GENERAL }

    public final String id;
    public String text;
    public Category category;
    public Status status;
    public double confidence;
    public int importance;
    public final String createdAt;
    public String updatedAt;
    public String learnedAt;
    public String source;
    public String provenance;

    public MemoryItem(String id, String text, Category category, Status status,
                      double confidence, int importance, String createdAt,
                      String updatedAt, String learnedAt, String source, String provenance) {
        this.id = id;
        this.text = text;
        this.category = category == null ? Category.GENERAL : category;
        this.status = status == null ? Status.UNCERTAIN : status;
        this.confidence = clamp(confidence, 0, 1);
        this.importance = (int) clamp(importance, 1, 5);
        this.createdAt = createdAt;
        this.updatedAt = updatedAt == null ? createdAt : updatedAt;
        this.learnedAt = learnedAt == null ? this.createdAt : learnedAt;
        this.source = source == null ? "unknown" : source;
        this.provenance = provenance == null ? "unknown" : provenance;
    }

    public static Status statusFor(double confidence) {
        if (confidence >= 0.85) return Status.CONFIRMED;
        if (confidence >= 0.55) return Status.LIKELY;
        return Status.UNCERTAIN;
    }

    public static Category categoryFor(String text, Category explicit) {
        if (explicit != null) return explicit;
        String s = text == null ? "" : text.toLowerCase(Locale.ROOT);
        if (containsAny(s, "goal", "target", "aim", "objective")) return Category.GOALS;
        if (containsAny(s, "prefer", "preference", "like", "dislike", "style")) return Category.PREFERENCES;
        if (containsAny(s, "project", "app", "build", "system", "nori", "kage")) return Category.PROJECTS;
        if (containsAny(s, "study", "subject", "exam", "assignment", "grade", "school", "physics", "chemistry", "biology", "math", "english")) return Category.ACADEMIC;
        if (containsAny(s, "setting", "configuration", "mode", "rule", "provider", "model", "feature")) return Category.SYSTEM_CONFIGURATION;
        return Category.GENERAL;
    }

    private static boolean containsAny(String s, String... words) {
        for (String w : words) if (s.contains(w)) return true;
        return false;
    }

    private static double clamp(double v, double min, double max) { return Math.max(min, Math.min(max, v)); }
    private static long clamp(long v, long min, long max) { return Math.max(min, Math.min(max, v)); }
}
