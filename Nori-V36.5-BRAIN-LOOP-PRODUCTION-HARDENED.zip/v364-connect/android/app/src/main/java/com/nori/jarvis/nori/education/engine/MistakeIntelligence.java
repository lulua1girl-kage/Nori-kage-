package com.nori.jarvis.nori.education.engine;

import com.nori.jarvis.nori.education.model.*; import java.util.*;

public final class MistakeIntelligence {
    public MistakeReport analyze(List<AcademicEvidence> evidence){
        Map<String,Integer> counts=new LinkedHashMap<>(); Map<String,Double> recency=new HashMap<>();
        if(evidence!=null) for(AcademicEvidence e:evidence){
            String type=e.carelessErrors>e.missedConcepts.size()?"careless":e.applicationErrors>e.missedConcepts.size()?"application":"concept";
            if(e.missedConcepts.isEmpty()) counts.merge(e.subject+"|"+type,1,Integer::sum);
            for(String c:e.missedConcepts){String key=e.subject+"|"+c;counts.merge(key,1,Integer::sum);recency.put(key,Math.max(recency.getOrDefault(key,0.0),e.at.toLocalDate().toEpochDay()));}
        }
        List<MistakeReport.Pattern> p=new ArrayList<>();
        for(Map.Entry<String,Integer> x:counts.entrySet()) if(x.getValue()>=2) p.add(new MistakeReport.Pattern(x.getKey(),x.getKey().contains("|")?"repeated_pattern":"pattern",x.getValue(),recency.getOrDefault(x.getKey(),0.0)));
        p.sort((a,b)->Integer.compare(b.count,a.count));
        List<String> interventions=new ArrayList<>(); for(MistakeReport.Pattern x:p){
            if(x.key.endsWith("|careless")) interventions.add("slow_check_protocol");
            else if(x.key.endsWith("|application")) interventions.add("worked_application_drill");
            else interventions.add("targeted_reteaching_and_retrieval");
        }
        return new MistakeReport(p,new ArrayList<>(new LinkedHashSet<>(interventions)));
    }
}
