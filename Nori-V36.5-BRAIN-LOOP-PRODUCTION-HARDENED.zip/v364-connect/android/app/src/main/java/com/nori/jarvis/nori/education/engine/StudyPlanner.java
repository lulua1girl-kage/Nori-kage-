package com.nori.jarvis.nori.education.engine;

import com.nori.jarvis.nori.education.model.*; import java.time.*; import java.util.*;

public final class StudyPlanner {
    public StudyPlan plan(List<StudyTask> tasks,int availableMinutes,LocalDateTime now,StrengthWeaknessReport report){
        int budget=Math.max(0,availableMinutes); if(budget<10) return new StudyPlan(Collections.emptyList(),0,"Insufficient time for a useful study block; protect the remaining time.");
        List<StudyTask> sorted=new ArrayList<>(tasks==null?Collections.emptyList():tasks); sorted.sort((a,b)->Double.compare(score(b,now,report),score(a,now,report)));
        List<StudyPlan.Block> out=new ArrayList<>(); int used=0;
        for(StudyTask t:sorted){if(used>=budget)break;int m=Math.min(t.estimatedMinutes,budget-used); if(m<10)continue;out.add(new StudyPlan.Block(t,m,reason(t,now,report)));used+=m;}
        return new StudyPlan(out,used,out.isEmpty()?"No concrete task is available.":"Plan is bounded by current available time and academic value.");
    }
    private double score(StudyTask t,LocalDateTime now,StrengthWeaknessReport r){double urgency=0;if(t.due!=null){long h=Duration.between(now,t.due).toHours();urgency=h<=0?1:h<=24?.95:h<=72?.8:h<=168?.6:.3;}double weak=r!=null&&r.priorityWeaknesses.contains(t.subject)?.25:0;return urgency*.45+t.importance*.35+weak*.20;}
    private String reason(StudyTask t,LocalDateTime now,StrengthWeaknessReport r){return t.kind.equals("exam")?"exam proximity":r!=null&&r.priorityWeaknesses.contains(t.subject)?"weakness priority":"task urgency/importance";}
}
