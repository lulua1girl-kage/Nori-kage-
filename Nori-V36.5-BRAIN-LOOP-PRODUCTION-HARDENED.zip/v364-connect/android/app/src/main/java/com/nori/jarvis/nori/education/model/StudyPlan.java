package com.nori.jarvis.nori.education.model;

import java.util.*;

public final class StudyPlan {
    public static final class Block { public final StudyTask task; public final int minutes; public final String reason;
        public Block(StudyTask task,int minutes,String reason){this.task=task;this.minutes=minutes;this.reason=reason;} }
    public final List<Block> blocks; public final int totalMinutes; public final String note;
    public StudyPlan(List<Block> blocks,int totalMinutes,String note){this.blocks=Collections.unmodifiableList(new ArrayList<>(blocks));this.totalMinutes=totalMinutes;this.note=note;}
}
