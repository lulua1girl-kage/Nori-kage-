package com.nori.jarvis.nori.actions;

import com.nori.jarvis.nori.actions.model.ActionExecutionResult;
import com.nori.jarvis.nori.actions.model.ActionPreview;
import com.nori.jarvis.nori.actions.model.ToolRequest;

/** Adapter boundary. Android/device integrations implement this without changing the Brain. */
public interface ToolHandler {
    ActionPreview preview(ToolRequest request);
    ActionExecutionResult execute(ToolRequest request, String operationId);
    ActionExecutionResult undo(ToolRequest request, String operationId);
}
