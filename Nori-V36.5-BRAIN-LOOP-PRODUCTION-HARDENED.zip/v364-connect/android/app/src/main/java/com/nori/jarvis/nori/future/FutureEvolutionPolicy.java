package com.nori.jarvis.nori.future;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * Final architecture boundary for post-release evolution.
 * Future features extend Nori through explicit interfaces and never silently
 * replace the protected core, safety rules, memory model, or human override.
 */
public final class FutureEvolutionPolicy {
    public enum ChangeClass { CONFIGURATION, FEATURE, MODEL, CORE_RULE, SECURITY_BOUNDARY, DATA_SCHEMA }
    public enum Approval { ALLOWED, REQUIRES_REVIEW, FORBIDDEN }

    private static final Set<String> PROTECTED = Collections.unmodifiableSet(
            new LinkedHashSet<String>() {{
                add("human_override");
                add("safety_integrity");
                add("recovery_boundary");
                add("academic_priority");
                add("memory_privacy");
                add("credential_boundary");
                add("educational_purpose_firewall");
            }});

    private FutureEvolutionPolicy() {}

    public static Approval approvalFor(ChangeClass changeClass, boolean userConfirmed,
                                       boolean verifiedRollback) {
        if (changeClass == null) return Approval.FORBIDDEN;
        if (changeClass == ChangeClass.SECURITY_BOUNDARY || changeClass == ChangeClass.CORE_RULE) {
            return userConfirmed && verifiedRollback ? Approval.REQUIRES_REVIEW : Approval.FORBIDDEN;
        }
        if (changeClass == ChangeClass.DATA_SCHEMA || changeClass == ChangeClass.MODEL) {
            return verifiedRollback ? Approval.REQUIRES_REVIEW : Approval.FORBIDDEN;
        }
        return Approval.ALLOWED;
    }

    public static boolean isProtectedBoundary(String name) {
        return name != null && PROTECTED.contains(name);
    }

    public static Set<String> protectedBoundaries() { return PROTECTED; }
}
