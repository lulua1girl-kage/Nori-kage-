package com.nori.jarvis.nori.memory;

import java.util.Collections;
import java.util.List;

/** Structured memory result used by the Brain; no silent side effects. */
public final class MemoryDecision {
    public enum Type { REMEMBER, RECALL, UPDATE, ARCHIVE, DELETE, REJECTED, NONE }
    public final Type type;
    public final boolean persisted;
    public final String reason;
    public final List<MemoryItem> matches;

    public MemoryDecision(Type type, boolean persisted, String reason, List<MemoryItem> matches) {
        this.type = type; this.persisted = persisted; this.reason = reason;
        this.matches = matches == null ? Collections.emptyList() : Collections.unmodifiableList(matches);
    }
}
