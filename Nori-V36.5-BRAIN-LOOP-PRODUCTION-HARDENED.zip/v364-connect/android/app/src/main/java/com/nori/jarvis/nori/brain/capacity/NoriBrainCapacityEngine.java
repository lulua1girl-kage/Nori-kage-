package com.nori.jarvis.nori.brain.capacity;

import com.nori.jarvis.nori.brain.human.HumanContextEngine;
import com.nori.jarvis.nori.brain.human.NoriSupportPolicy;
import java.text.Normalizer;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Post-14 brain capacity layer. Additive: it does not replace existing Nori engines.
 * It turns existing state, reasoning, human-context and provider capabilities into a
 * single fast preflight/planning layer.
 */
public final class NoriBrainCapacityEngine {
    public enum Intent { CALCULATION, NAVIGATION, ACADEMIC, PLANNING, LIFE_SUPPORT, RESEARCH, ACTION, CONVERSATION, UNKNOWN }
    public enum Effort { INSTANT, FAST, DEEP }
    public enum Disclosure { NONE_NEEDED, OPTIONAL, USER_REQUESTED }
    public enum ResponseMode { DIRECT, SUPPORTIVE, STRICT, RECOVERY, SAFETY, RESEARCH }

    public static final class Plan {
        public final Intent intent; public final Effort effort; public final Disclosure disclosure;
        public final ResponseMode responseMode; public final boolean localFirst; public final boolean externalNeeded;
        public final boolean researchNeeded; public final boolean verifyAfterAction; public final boolean cacheEligible;
        public final String normalizedRequest; public final List<String> reasons;
        public Plan(Intent i, Effort e, Disclosure d, ResponseMode m, boolean local, boolean external,
                    boolean research, boolean verify, boolean cache, String normalized, List<String> reasons) {
            intent=i; effort=e; disclosure=d; responseMode=m; localFirst=local; externalNeeded=external;
            researchNeeded=research; verifyAfterAction=verify; cacheEligible=cache; normalizedRequest=normalized;
            this.reasons=Collections.unmodifiableList(new ArrayList<>(reasons));
        }
    }

    public static final class Snapshot {
        public final String key; public final Plan plan; public final long createdAt;
        Snapshot(String k, Plan p){key=k;plan=p;createdAt=System.currentTimeMillis();}
    }

    private final Map<String, Snapshot> recentPlans = new ConcurrentHashMap<>();
    private final Map<String, Long> decisionHistory = new ConcurrentHashMap<>();

    /** 1 normalization: keeps routing stable across trivial wording changes. */
    public String normalize(String message) {
        if(message==null) return "";
        String s=Normalizer.normalize(message, Normalizer.Form.NFKC).trim().replaceAll("\\s+"," ");
        return s;
    }

    /** 2 local-intent classification; intentionally conservative. */
    public Intent classify(String message) {
        String s=normalize(message).toLowerCase(Locale.ROOT);
        if(s.matches(".*\\b(what is|calculate|compute|percent|%|\\+|\\-|\\*|divide|multiply)\\b.*")) return Intent.CALCULATION;
        if(s.matches(".*\\b(open|go to|show|switch to|navigate|settings|calendar|tasks|results|study)\\b.*")) return Intent.NAVIGATION;
        if(s.matches(".*\\b(research|latest|recent|sources|studies|evidence|according to)\\b.*")) return Intent.RESEARCH;
        if(s.matches(".*\\b(plan|schedule|today|tomorrow|prioritize|routine|deadline)\\b.*")) return Intent.PLANNING;
        if(s.matches(".*\\b(add|create|mark|set|start|stop|save|delete|change)\\b.*")) return Intent.ACTION;
        if(s.matches(".*\\b(study|exam|assignment|homework|chemistry|biology|physics|math|english)\\b.*")) return Intent.ACADEMIC;
        if(s.matches(".*\\b(overwhelmed|tired|exhausted|stuck|hard day|can't cope|cannot cope|need a break|struggling)\\b.*")) return Intent.LIFE_SUPPORT;
        return Intent.CONVERSATION;
    }

    /** 3 effort selection: avoid expensive reasoning for deterministic work. */
    public Effort chooseEffort(Intent i, String message) {
        int n=normalize(message).length();
        if(i==Intent.CALCULATION || i==Intent.NAVIGATION) return Effort.INSTANT;
        if(i==Intent.RESEARCH || n>700) return Effort.DEEP;
        return Effort.FAST;
    }

    /** 4 determines whether disclosure is actually useful; private causes are never required. */
    public Disclosure disclosurePolicy(Intent i, boolean userAskedForAnalysis) {
        if(userAskedForAnalysis) return Disclosure.USER_REQUESTED;
        if(i==Intent.LIFE_SUPPORT) return Disclosure.OPTIONAL;
        return Disclosure.NONE_NEEDED;
    }

    /** 5 chooses a humane response mode without exposing clinical labels. */
    public ResponseMode responseMode(HumanContextEngine.Assessment a, Intent i) {
        if(a!=null) {
            if(a.support==HumanContextEngine.SupportLevel.SAFETY_FIRST) return ResponseMode.SAFETY;
            if(a.support==HumanContextEngine.SupportLevel.STABILIZE) return ResponseMode.RECOVERY;
            if(a.difficulty==HumanContextEngine.Difficulty.AVOIDANCE_PATTERN) return ResponseMode.STRICT;
        }
        if(i==Intent.RESEARCH) return ResponseMode.RESEARCH;
        if(i==Intent.LIFE_SUPPORT) return ResponseMode.SUPPORTIVE;
        return ResponseMode.DIRECT;
    }

    /** 6 goal/task distinction encoded as a lightweight classifier. */
    public String scope(String message) {
        String s=normalize(message).toLowerCase(Locale.ROOT);
        if(s.matches(".*\\b(this year|long term|eventually|goal|become|improve at)\\b.*")) return "goal";
        if(s.matches(".*\\b(today|tonight|next|do now|finish|submit|complete)\\b.*")) return "task";
        return "conversation";
    }

    /** 7 context compression: retain high-value anchors without copying whole history. */
    public String compressContext(List<String> facts, List<String> goals, List<String> recentTurns) {
        LinkedHashSet<String> out=new LinkedHashSet<>();
        add(out,facts,8); add(out,goals,8); add(out,recentTurns,6);
        return String.join(" | ",out);
    }
    private void add(LinkedHashSet<String> out,List<String> values,int max){ if(values==null)return; for(String v:values){if(out.size()>=max)break;if(v!=null&&!v.trim().isEmpty())out.add(normalize(v));} }

    /** 8 repeated-pattern detection, not a diagnosis and not a laziness verdict. */
    public boolean repeatedPattern(int misses, int starts) { return misses>=3 && starts<misses; }

    /** 9 protects against turning a single avoidance event into a character judgment. */
    public boolean enoughEvidenceForStrictness(int misses, boolean fatigue, boolean overload) {
        return misses>=3 && !fatigue && !overload;
    }

    /** 10 safety-aware response boundary. */
    public boolean requiresSafetyFirst(HumanContextEngine.Assessment a) {
        return a!=null && a.support==HumanContextEngine.SupportLevel.SAFETY_FIRST;
    }

    /** 11 research gate: research only when freshness/evidence is requested. */
    public boolean needsResearch(Intent i,String message) { return i==Intent.RESEARCH || normalize(message).toLowerCase(Locale.ROOT).matches(".*\\b(latest|current|today|new study|research)\\b.*"); }

    /** 12 cache eligibility: never cache obviously personal/sensitive requests. */
    public boolean cacheEligible(String message) {
        String s=normalize(message).toLowerCase(Locale.ROOT);
        return s.length()>=3 && s.length()<=500 && !s.matches(".*\\b(my parents|password|private|secret|self harm|suicid|hurt myself)\\b.*");
    }

    /** 13 deterministic key for request deduplication. */
    public String requestKey(String message,String mode) { return Integer.toHexString((normalize(message).toLowerCase(Locale.ROOT)+"|"+(mode==null?"":mode)).hashCode()); }

    /** 14 short-lived plan memoization prevents repeated routing work during bursts. */
    public void rememberPlan(String key,Plan plan){ if(key!=null&&plan!=null) recentPlans.put(key,new Snapshot(key,plan)); }
    public Plan recentPlan(String key){ Snapshot s=recentPlans.get(key); if(s==null)return null; if(System.currentTimeMillis()-s.createdAt>30000){recentPlans.remove(key);return null;} return s.plan; }

    /** 15 action verification contract. */
    public boolean shouldVerifyAction(boolean mutatingAction, boolean highImpact){ return mutatingAction || highImpact; }

    /** 16 decision history: remembers that a route was chosen, not private conversation content. */
    public void recordDecision(String key){ if(key!=null) decisionHistory.put(key,System.currentTimeMillis()); }
    public boolean seenRecently(String key){ Long t=decisionHistory.get(key); return t!=null && System.currentTimeMillis()-t<60000; }

    /** 17 user-agency guard. */
    public boolean preserveHumanOverride(boolean userExplicitlyOverrode){ return true; }

    /** 18 research source threshold for the requested 10+ source mode. */
    public int researchTarget(boolean deep){ return deep?10:3; }

    /** 19 provider escalation rule: local Nori remains the first authority. */
    public boolean escalateToExternal(boolean difficult, boolean localCanAnswer){ return difficult && !localCanAnswer; }

    /** 20 complete preflight plan. */
    public Plan plan(String message, HumanContextEngine.Assessment assessment, boolean localCanAnswer, boolean userAskedAnalysis) {
        String normalized=normalize(message); Intent i=classify(normalized); Effort e=chooseEffort(i,normalized);
        Disclosure d=disclosurePolicy(i,userAskedAnalysis); ResponseMode m=responseMode(assessment,i);
        boolean research=needsResearch(i,normalized); boolean external=e==Effort.DEEP && !localCanAnswer;
        boolean verify=i==Intent.ACTION || i==Intent.NAVIGATION; boolean cache=cacheEligible(normalized);
        List<String> reasons=new ArrayList<>(); reasons.add("local_first");
        if(e==Effort.INSTANT)reasons.add("deterministic_or_navigation_path");
        if(research)reasons.add("fresh_or_evidence_request");
        if(d==Disclosure.NONE_NEEDED)reasons.add("no_personal_disclosure_required");
        if(assessment!=null&&assessment.difficulty==HumanContextEngine.Difficulty.AVOIDANCE_PATTERN) reasons.add("repeated_pattern_before_strictness");
        Plan p=new Plan(i,e,d,m,true,external,research,verify,cache,normalized,reasons);
        String key=requestKey(normalized,m.name()); rememberPlan(key,p); recordDecision(key); return p;
    }
}
