package com.nori.jarvis.nori.ui;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.app.AlertDialog;
import android.content.Intent;
import com.nori.jarvis.nori.presence.NoriInterfaceController;
import com.nori.jarvis.nori.presence.NoriInterfaceMode;

import com.nori.jarvis.nori.NoriNativeCore;
import com.nori.jarvis.nori.data.NativeDataRepository;

/** Stage 18 native UI: usable dossier-style shell, still running beside protected V32. */
public final class NativeMainActivity extends Activity {
    private NoriNavigator navigator;
    private NativeDataRepository repository;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(NoriTheme.BG);
        getWindow().setNavigationBarColor(NoriTheme.BG);
        repository = new NativeDataRepository(getApplicationContext());
        new NoriNativeCore(repository); // initialize native core without coupling UI to Brain internals

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(NoriTheme.BG);
        LinearLayout shell = new LinearLayout(this);
        shell.setOrientation(LinearLayout.VERTICAL);

        FrameLayout content = new FrameLayout(this);
        navigator = new NoriNavigator(this, content);
        registerScreens();

        shell.addView(header(), new LinearLayout.LayoutParams(-1, NoriTheme.dp(this, 56)));
        shell.addView(content, new LinearLayout.LayoutParams(-1, 0, 1f));
        shell.addView(bottomNav(), new LinearLayout.LayoutParams(-1, NoriTheme.dp(this, 62)));
        root.addView(shell, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);
        navigator.show(NoriNavigator.Screen.HOME);
    }

    private View header() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(NoriTheme.dp(this, 16), 0, NoriTheme.dp(this, 12), 0);
        TextView brand = new TextView(this);
        brand.setText("NORI"); brand.setTextColor(NoriTheme.TEXT); brand.setTextSize(18);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD); brand.setLetterSpacing(.18f);
        bar.addView(brand, new LinearLayout.LayoutParams(0, -1, 1f));
        TextView state = new TextView(this);
        state.setText("NATIVE / V32"); state.setTextColor(NoriTheme.MUTED); state.setTextSize(10);
        state.setGravity(Gravity.CENTER_VERTICAL); state.setLetterSpacing(.08f);
        bar.addView(state, new LinearLayout.LayoutParams(-2, -1));
        return bar;
    }

    private View bottomNav() {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout nav = new LinearLayout(this); nav.setPadding(6, 4, 6, 4);
        addNav(nav, "HOME", NoriNavigator.Screen.HOME);
        addNav(nav, "STUDY", NoriNavigator.Screen.ACADEMICS);
        addNav(nav, "PLAN", NoriNavigator.Screen.PLAN);
        addNav(nav, "RESULTS", NoriNavigator.Screen.RESULTS);
        addNav(nav, "KAGE", NoriNavigator.Screen.KAGE);
        addNav(nav, "RECOVER", NoriNavigator.Screen.RECOVER);
        addNav(nav, "SET", NoriNavigator.Screen.SETTINGS);
        scroll.addView(nav); return scroll;
    }

    private void addNav(LinearLayout nav, String label, NoriNavigator.Screen screen) {
        Button b = new Button(this); b.setText(label); b.setTextSize(10); b.setTextColor(NoriTheme.TEXT);
        b.setAllCaps(false); b.setPadding(10, 0, 10, 0); b.setOnClickListener(v -> navigator.show(screen));
        nav.addView(b, new LinearLayout.LayoutParams(NoriTheme.dp(this, 78), -1));
    }

    private void registerScreens() {
        navigator.register(NoriNavigator.Screen.HOME, a -> home());
        navigator.register(NoriNavigator.Screen.ACADEMICS, a -> academics());
        navigator.register(NoriNavigator.Screen.PLAN, a -> plan());
        navigator.register(NoriNavigator.Screen.RESULTS, a -> results());
        navigator.register(NoriNavigator.Screen.KAGE, a -> kage());
        navigator.register(NoriNavigator.Screen.RECOVER, a -> recover());
        navigator.register(NoriNavigator.Screen.SETTINGS, a -> settings());
    }

    private ScrollView base() {
        ScrollView s = new ScrollView(this); s.setFillViewport(true);
        s.setBackgroundColor(NoriTheme.BG); return s;
    }

    private LinearLayout page() { return NoriTheme.page(this); }

    private View home() {
        LinearLayout p = page(); p.addView(NoriTheme.eyebrow(this, "Student command center"));
        p.addView(NoriTheme.title(this, "Nori"));
        p.addView(NoriTheme.body(this, "Education first. Evidence before conclusions. Human Override remains above convenience."));
        p.addView(NoriTheme.spacer(this, 10));
        LinearLayout metrics = new LinearLayout(this); metrics.setOrientation(LinearLayout.HORIZONTAL);
        metrics.addView(NoriTheme.metric(this, String.valueOf(repository.count()), "Stored records"), new LinearLayout.LayoutParams(0, -2, 1f));
        metrics.addView(NoriTheme.metric(this, "LOCAL", "AI default"), new LinearLayout.LayoutParams(0, -2, 1f));
        p.addView(metrics); p.addView(NoriTheme.spacer(this, 10));
        p.addView(card("CURRENT STATE", "Ready", "Native UI is active. Academic, KAGE, memory and action layers remain behind their safety boundaries.", "VIEW STATUS", () -> showInfo("Current State", "Native shell is active. Stored records: " + repository.count() + ". AI default: local. Human Override remains highest.")));
        p.addView(NoriTheme.spacer(this, 10));
        p.addView(card("QUICK ACCESS", "Study / Plan / Recover", "Use the navigation below to work with the native surfaces.", "OPEN STUDY", () -> navigator.show(NoriNavigator.Screen.ACADEMICS)));
        ScrollView s = base(); s.addView(p); return s;
    }

    private View academics() {
        LinearLayout p = page(); p.addView(NoriTheme.eyebrow(this, "Academic intelligence")); p.addView(NoriTheme.title(this, "Study"));
        p.addView(card("EVIDENCE", "Academic record", "Results, assessment types, mistakes and trends are intended to drive recommendations—not appearance or arbitrary targets.", "OPEN RESULTS", () -> navigator.show(NoriNavigator.Screen.RESULTS)));
        p.addView(card("ADAPTIVE", "Study strategy", "Native educational intelligence can select retrieval, reteaching, error review, transfer practice and exam preparation based on evidence.", "OPEN PLAN", () -> navigator.show(NoriNavigator.Screen.PLAN)));
        p.addView(card("TUTOR", "Mode-aware help", "Tutor behavior can remain fast, guided or deep without making remote AI a requirement.", "VIEW STATUS", () -> showInfo("Tutor", "The native educational policy layer is available. Full conversational tutoring remains in the Nori conversation surface.")));
        ScrollView s = base(); s.addView(p); return s;
    }

    private View plan() {
        LinearLayout p = page(); p.addView(NoriTheme.eyebrow(this, "Execution")); p.addView(NoriTheme.title(this, "Plan"));
        p.addView(card("TODAY", "Adaptive plan", "The planner is designed to respect available time and context rather than filling every empty minute.", "OPEN SESSION", () -> showInfo("Adaptive Plan", "The native planner foundation is active; session execution remains confirmation-controlled.")));
        p.addView(card("SESSION", "Dynamic study session", "Sessions can change focus when evidence shows a different intervention is needed.", "VIEW POLICY", () -> showInfo("Dynamic Session", "Nori can adapt the study strategy from academic evidence without silently changing stored goals.")));
        p.addView(card("ACTIONS", "Controlled execution", "Device actions remain proposal → confirmation → execution → verification.", "VIEW SAFETY", () -> showInfo("Controlled Actions", "Important side effects require a proposal and explicit confirmation before execution.")));
        ScrollView s = base(); s.addView(p); return s;
    }

    private View results() {
        LinearLayout p = page(); p.addView(NoriTheme.eyebrow(this, "Performance record")); p.addView(NoriTheme.title(this, "Results"));
        p.addView(card("TREND", "Personal trajectory", "Nori evaluates change against the student's own recorded evidence and keeps low-data conclusions uncertain.", "OPEN TRACKER", () -> showInfo("Trajectory", "The trajectory engine reads recorded evidence; this native screen is currently a summary surface.")));
        p.addView(card("ERRORS", "Mistake intelligence", "Repeated concept, execution and careless-error patterns can be separated instead of treating every wrong answer the same way.", "VIEW POLICY", () -> showInfo("Mistake Intelligence", "Concept misses, execution errors and careless errors have separate analysis paths.")));
        p.addView(card("VERIFY", "Anomalies", "Unusual results are signals for verification, not automatic permanent changes to the student model.", "VIEW SAFETY", () -> showInfo("Anomaly Handling", "Anomalies are signals for verification rather than automatic permanent conclusions.")));
        ScrollView s = base(); s.addView(p); return s;
    }

    private View kage() {
        LinearLayout p = page(); p.addView(NoriTheme.eyebrow(this, "Integrity / control")); p.addView(NoriTheme.title(this, "KAGE"));
        p.addView(card("OVERRIDE", "Human authority", "Recognized Override reasons can be reviewed without allowing arbitrary rule bypassing.", "VIEW OVERRIDE", () -> showInfo("Human Override", "Human Override has highest authority over convenience and ordinary enforcement, while safety and integrity boundaries remain protected.")));
        p.addView(card("CONSEQUENCES", "Safety boundary", "No physical punishment, deprivation, humiliation, threats or consequences that create additional harm.", "VIEW BOUNDARY", () -> showInfo("Consequence Safety", "Nori does not use physical punishment, sleep/food deprivation, humiliation or threats.")));
        p.addView(card("RECOVERY", "Restoration", "Recovery addresses the academic or behavioral state without pretending the historical event never happened.", "OPEN RECOVERY", () -> navigator.show(NoriNavigator.Screen.RECOVER)));
        ScrollView s = base(); s.addView(p); return s;
    }

    private View recover() {
        LinearLayout p = page(); p.addView(NoriTheme.eyebrow(this, "Return to function")); p.addView(NoriTheme.title(this, "Recover"));
        p.addView(card("FIRST", "Stabilize", "Identify what is actually blocking progress before adding more rules or workload.", "REVIEW", () -> showInfo("Stabilize", "Identify the actual obstacle before increasing workload or restrictions.")));
        p.addView(card("NEXT", "Restore academics", "Prioritize the smallest useful academic restoration step, then verify completion.", "OPEN PLAN", () -> navigator.show(NoriNavigator.Screen.PLAN)));
        p.addView(card("THEN", "Rebuild", "Return to the normal plan only after the immediate failure or disruption has been addressed.", "RETURN TO HOME", () -> navigator.show(NoriNavigator.Screen.HOME)));
        ScrollView s = base(); s.addView(p); return s;
    }

    private View settings() {
        LinearLayout p = page(); p.addView(NoriTheme.eyebrow(this, "Configuration")); p.addView(NoriTheme.title(this, "Settings"));
        p.addView(card("INTERFACE", "Nori presentation", "Choose Standard, Kage Avatar, Interactive Circle, Hybrid or Compact/Fast. This changes presentation only; Brain, memory and conversation remain shared.", "CHOOSE INTERFACE", () -> showInterfaceChooser(p)));
        p.addView(card("VOICE", "Profile and modes", "Voice configuration belongs here; microphone access remains explicit and opt-in.", "VIEW VOICE", () -> showInfo("Voice", "Voice is explicit and permission-bound. Use the conversation/voice surface for live interaction.")));
        p.addView(card("AI", "Provider boundary", "Remote AI is optional and disabled by default until explicitly configured and consented.", "VIEW PROVIDER", () -> showInfo("AI Provider", "Local AI remains the default boundary. Remote providers require explicit configuration/consent.")));
        p.addView(card("PRIVACY", "Local-first", "Long-term memory is not created from ordinary conversation automatically, and device access stays permission-bound.", "VIEW PRIVACY", () -> showInfo("Privacy", "Device access is permission-bound. Sensitive conversation access uses the biometric gate when integrated.")));
        p.addView(card("MIGRATION", "V32 reference", "The native implementation is still migrated incrementally; protected V32 modules remain available until equivalence is established.", "VIEW MIGRATION", () -> showInfo("V32 Migration", "Native implementation is additive and remains alongside the protected V32 surface until equivalence is verified.")));
        ScrollView s = base(); s.addView(p); return s;
    }

    private void showInterfaceChooser(View anchor) {
        final NoriInterfaceController controller = new NoriInterfaceController(this);
        final String[] labels = {"Nori Standard", "Kage Avatar", "Interactive Circle", "Hybrid", "Compact / Fast"};
        final NoriInterfaceMode[] modes = NoriInterfaceMode.values();
        int checked = controller.getMode().ordinal();
        new AlertDialog.Builder(this).setTitle("Nori Interface")
                .setSingleChoiceItems(labels, checked, (dialog, which) -> {
                    controller.setMode(modes[which]);
                    if (modes[which] == NoriInterfaceMode.CIRCLE) startActivity(new Intent(this, com.nori.jarvis.nori.presence.NoriInteractiveCircleActivity.class));
                    dialog.dismiss();
                }).setNegativeButton("CLOSE", null).show();
    }

    private View card(String eyebrow, String title, String body, String actionLabel, Runnable action) {
        LinearLayout c = NoriTheme.card(this);
        c.addView(NoriTheme.eyebrow(this, eyebrow));
        c.addView(NoriTheme.cardTitle(this, title));
        c.addView(NoriTheme.body(this, body));
        Button actionButton = new Button(this);
        actionButton.setText(actionLabel); actionButton.setTextColor(NoriTheme.TEXT); actionButton.setTextSize(11);
        actionButton.setAllCaps(false); actionButton.setBackground(NoriTheme.background(NoriTheme.PANEL_ALT, 0)); actionButton.setOnClickListener(v -> action.run());
        c.addView(actionButton, new LinearLayout.LayoutParams(-1, NoriTheme.dp(this, 46)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2); lp.topMargin = NoriTheme.dp(this, 10); c.setLayoutParams(lp);
        return c;
    }

    private void showInfo(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("CLOSE", null).show();
    }

    @Override protected void onDestroy() { if (repository != null) repository.close(); super.onDestroy(); }
}
