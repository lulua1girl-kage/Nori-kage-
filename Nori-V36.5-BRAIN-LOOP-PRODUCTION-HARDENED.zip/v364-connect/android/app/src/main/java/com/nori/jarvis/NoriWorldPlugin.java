package com.nori.jarvis;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.nori.jarvis.nori.NoriNativeCore;
import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.actions.model.ToolRequest;
import com.nori.jarvis.nori.actions.model.ActionExecutionResult;
import com.nori.jarvis.nori.understanding.NoriUserControlEngine;
import com.nori.jarvis.nori.browser.NoriChromeBridge;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * End-to-end world-information bridge:
 * UI/voice -> Nori Brain -> governed ActionEngine -> live web connector.
 * Chrome hand-off is explicit and separate; Nori never controls Chrome invisibly.
 */
@CapacitorPlugin(name="NoriWorld")
public final class NoriWorldPlugin extends Plugin {
    private final ExecutorService executor=Executors.newFixedThreadPool(2);
    private volatile NoriBrain brain;
    private NoriBrain brain(){NoriBrain b=brain;if(b==null){synchronized(this){b=brain;if(b==null){b=new NoriNativeCore().getBrain();brain=b;}}}return b;}

    @PluginMethod public void latestNews(PluginCall call){Map<String,String> in=new LinkedHashMap<>();in.put("query",call.getString("query", ""));runAction(call,"world_news_live",in);}
    @PluginMethod public void weather(PluginCall call){Map<String,String> in=new LinkedHashMap<>();in.put("location",call.getString("location", ""));runAction(call,"world_weather_live",in);}
    @PluginMethod public void trends(PluginCall call){Map<String,String> in=new LinkedHashMap<>();in.put("query",call.getString("query", ""));runAction(call,"world_trends_live",in);}
    @PluginMethod public void webSearch(PluginCall call){Map<String,String> in=new LinkedHashMap<>();in.put("query",call.getString("query", ""));runAction(call,"world_web_search",in);}

    private void runAction(PluginCall call,String toolId,Map<String,String> input){
        executor.execute(()->{
            try{
                NoriBrain b=brain();
                com.nori.jarvis.nori.execution.NoriFunctionalExecutionCore.PreparedAction prepared=b.getFunctionalExecutionCore().prepare(
                    new ToolRequest(toolId,input),"User explicitly requested fresh world information",Collections.singletonList("user_request"),
                    NoriUserControlEngine.Origin.USER_DIRECT,false,false,false,"world_information","");
                if(prepared.proposal==null){call.resolve(failure(prepared.authorization.reason));return;}
                if(!prepared.preview.allowed){call.resolve(failure(prepared.preview.reason));return;}
                ActionExecutionResult result=b.getFunctionalExecutionCore().confirmAndExecute(prepared.proposal.id,"human_user_request");
                call.resolve(actionJson(result));
            }catch(Exception e){call.resolve(failure(e.getClass().getSimpleName()));}
        });
    }
    private JSObject actionJson(ActionExecutionResult r){
        JSObject o=new JSObject();o.put("ok",r.ok);o.put("verified",r.verified);o.put("operationId",r.operationId);o.put("error",r.ok?"":String.valueOf(r.reason));
        if(r.result instanceof Map){for(Object k:((Map<?,?>)r.result).keySet())o.put(String.valueOf(k),String.valueOf(((Map<?,?>)r.result).get(k)));}
        return o;
    }
    private JSObject failure(String e){JSObject o=new JSObject();o.put("ok",false);o.put("verified",false);o.put("error",e);return o;}

    @PluginMethod public void openChrome(PluginCall call){String url=call.getString("url","");boolean ok=NoriChromeBridge.openUrl(getContext(),url);JSObject o=new JSObject();o.put("ok",ok);o.put("url",url);call.resolve(o);}
    @PluginMethod public void searchChrome(PluginCall call){String q=call.getString("query","");boolean ok=NoriChromeBridge.search(getContext(),q);JSObject o=new JSObject();o.put("ok",ok);o.put("query",q);call.resolve(o);}
    @PluginMethod public void newsInChrome(PluginCall call){String q=call.getString("query","");boolean ok=NoriChromeBridge.news(getContext(),q);JSObject o=new JSObject();o.put("ok",ok);o.put("query",q);call.resolve(o);}

    @Override protected void handleOnDestroy(){executor.shutdownNow();super.handleOnDestroy();}
}
