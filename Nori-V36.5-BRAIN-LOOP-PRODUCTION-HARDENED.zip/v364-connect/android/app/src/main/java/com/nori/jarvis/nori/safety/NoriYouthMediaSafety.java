package com.nori.jarvis.nori.safety;

import java.util.*;

/** Age-aware media safety decision layer. It avoids producing unnecessary graphic or sexual material. */
public final class NoriYouthMediaSafety {
    public enum Decision { ALLOW, REDIRECT, BLOCK, REVIEW }
    public enum Kind { ORDINARY, SEXUAL, GRAPHIC_ABUSE, GRAPHIC_VIOLENCE, DANGEROUS, UNKNOWN }
    public Decision evaluate(int age,Kind kind,boolean educationalNeed){
        if(age<18){
            if(kind==Kind.SEXUAL)return Decision.BLOCK;
            if((kind==Kind.GRAPHIC_ABUSE||kind==Kind.GRAPHIC_VIOLENCE)&&!educationalNeed)return Decision.BLOCK;
            if(kind==Kind.DANGEROUS)return Decision.BLOCK;
            if(kind==Kind.UNKNOWN)return Decision.REVIEW;
            if((kind==Kind.GRAPHIC_ABUSE||kind==Kind.GRAPHIC_VIOLENCE)&&educationalNeed)return Decision.REDIRECT;
        }
        return kind==Kind.UNKNOWN?Decision.REVIEW:Decision.ALLOW;
    }
    public boolean unnecessaryImageRequest(String request){
        String q=String.valueOf(request).toLowerCase(Locale.ROOT);
        return q.contains("sexual")||q.contains("nude")||q.contains("explicit")||q.contains("graphic abuse")||q.contains("gore");
    }
}
