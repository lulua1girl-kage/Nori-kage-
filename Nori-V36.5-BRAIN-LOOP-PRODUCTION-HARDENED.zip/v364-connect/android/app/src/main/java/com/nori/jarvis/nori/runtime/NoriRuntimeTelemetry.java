package com.nori.jarvis.nori.runtime;

import java.util.*;

/** Runtime measurements collected per bounded operation/session. No raw user content is stored. */
public final class NoriRuntimeTelemetry {
    public static final class Sample {
        public final String operation;
        public final long latencyMs;
        public final long heapUsedBytes;
        public final long heapMaxBytes;
        public final long elapsedSessionMs;
        public final long at;
        public Sample(String op,long latency,long used,long max,long session){operation=op==null?"":op;latencyMs=Math.max(0,latency);heapUsedBytes=Math.max(0,used);heapMaxBytes=Math.max(0,max);elapsedSessionMs=Math.max(0,session);at=System.currentTimeMillis();}
    }
    private final ArrayDeque<Sample> samples=new ArrayDeque<>();
    private final int maxSamples;
    public NoriRuntimeTelemetry(){this(256);}
    public NoriRuntimeTelemetry(int max){maxSamples=Math.max(16,max);}
    public synchronized void record(Sample s){if(s==null)return;samples.addLast(s);while(samples.size()>maxSamples)samples.removeFirst();}
    public synchronized List<Sample> recent(int limit){List<Sample> x=new ArrayList<>(samples);int from=Math.max(0,x.size()-Math.max(1,limit));return Collections.unmodifiableList(new ArrayList<>(x.subList(from,x.size())));}
    public synchronized long p50Latency(String op){return percentile(op,50);}
    public synchronized long p95Latency(String op){return percentile(op,95);}
    private long percentile(String op,int pct){List<Long> v=new ArrayList<>();for(Sample s:samples)if(op==null||op.equals(s.operation))v.add(s.latencyMs);if(v.isEmpty())return 0;Collections.sort(v);int i=(int)Math.ceil((pct/100.0)*v.size())-1;return v.get(Math.max(0,Math.min(i,v.size()-1)));}
    public static long heapUsed(){Runtime r=Runtime.getRuntime();return r.totalMemory()-r.freeMemory();}
    public static long heapMax(){return Runtime.getRuntime().maxMemory();}
}
