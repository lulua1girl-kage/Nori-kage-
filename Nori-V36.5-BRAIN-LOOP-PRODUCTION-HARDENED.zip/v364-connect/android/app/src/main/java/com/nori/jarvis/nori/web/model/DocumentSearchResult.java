package com.nori.jarvis.nori.web.model;

public final class DocumentSearchResult {
    public final String chunkId, documentId, text;
    public final double score;
    public DocumentSearchResult(String chunkId,String documentId,String text,double score){this.chunkId=chunkId;this.documentId=documentId;this.text=text;this.score=score;}
}
