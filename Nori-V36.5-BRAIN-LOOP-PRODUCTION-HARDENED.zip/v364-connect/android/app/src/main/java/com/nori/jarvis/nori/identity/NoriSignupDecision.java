package com.nori.jarvis.nori.identity;

public final class NoriSignupDecision {
    public final NoriAdmissionStatus status;
    public final boolean emailVerified;
    public final boolean backupVerified;
    public final boolean requiresAdminReview;
    public final String reason;
    public NoriSignupDecision(NoriAdmissionStatus s, boolean ev, boolean bv, boolean review, String r){status=s;emailVerified=ev;backupVerified=bv;requiresAdminReview=review;reason=r;}
    public boolean canEnterApp(){return status==NoriAdmissionStatus.APPROVED && emailVerified && backupVerified;}
}
