package com.nori.jarvis.nori.academic.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Typed native representation of a V32 academic assessment.
 * The shape intentionally mirrors the V32 academicEngine input contract.
 */
public final class Assessment {
    private final String type;
    private final double percentage;
    private final List<String> missedConcepts;
    private final int totalConceptsCovered;
    private final int carelessErrorCount;
    private final int applicationErrorCount;

    public Assessment(
            String type,
            double percentage,
            List<String> missedConcepts,
            int totalConceptsCovered,
            int carelessErrorCount,
            int applicationErrorCount) {
        this.type = type;
        this.percentage = percentage;
        this.missedConcepts = missedConcepts == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(new ArrayList<>(missedConcepts));
        this.totalConceptsCovered = totalConceptsCovered;
        this.carelessErrorCount = carelessErrorCount;
        this.applicationErrorCount = applicationErrorCount;
    }

    public String getType() { return type; }
    public double getPercentage() { return percentage; }
    public List<String> getMissedConcepts() { return missedConcepts; }
    public int getTotalConceptsCovered() { return totalConceptsCovered; }
    public int getCarelessErrorCount() { return carelessErrorCount; }
    public int getApplicationErrorCount() { return applicationErrorCount; }
}
