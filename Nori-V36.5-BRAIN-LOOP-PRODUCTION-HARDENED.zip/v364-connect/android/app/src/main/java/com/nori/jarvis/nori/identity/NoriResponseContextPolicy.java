package com.nori.jarvis.nori.identity;

/** Determines what identity context may safely influence Nori's communication style. */
public final class NoriResponseContextPolicy {
    public String context(NoriUserIdentity u){
        if(u==null||!u.valid())return "UNAUTHENTICATED: no personalized response context";
        String name=u.displayName().isEmpty()?"student":u.displayName();
        String age=u.ageBand();
        if("13-15".equals(age)||"16-17".equals(age)) return "REGISTERED_STUDENT name="+name+" ageBand="+age+"; use age-appropriate safety, clarity and communication; never expose identity context to another user.";
        if("18+".equals(age)) return "REGISTERED_USER name="+name+" ageBand=18+; personalize normally and preserve privacy boundaries.";
        return "REGISTERED_USER name="+name+" ageBand=unknown; avoid age-specific assumptions.";
    }
    public String rule(){return "Name and age can personalize tone and safety, but they do not determine worth, intelligence, diagnosis or permissions.";}
}
