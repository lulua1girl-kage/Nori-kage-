package com.nori.jarvis.nori.state;

import java.time.Instant;
import java.util.*;

/**
 * Unified, read-only snapshot of what Nori currently knows about the student
 * and the system. This is additive: existing engines remain authoritative for
 * their own domains; this object only composes their observable state.
 */
public final class NoriState {
    /** Study-state is deliberately non-diagnostic: it describes observable capacity and work. */
    public enum StudyStatus { UNKNOWN, NOT_STUDYING, PREPARING, STUDYING, REVIEWING, RECOVERING }
    public enum ExamStatus { NONE, UPCOMING, ACTIVE, RECENT, UNKNOWN }
    public enum Availability { UNKNOWN, AVAILABLE, BUSY, UNAVAILABLE, RECOVERING }

    public static final class Situation {
        public final Availability availability;
        public final String activity;
        public final String contextType;
        public final String contextConfidence;
        public final boolean nearExam;
        public final String observedAt;

        public Situation(Availability availability, String activity, String contextType,
                         String contextConfidence, boolean nearExam, String observedAt) {
            this.availability = availability == null ? Availability.UNKNOWN : availability;
            this.activity = safe(activity);
            this.contextType = safe(contextType);
            this.contextConfidence = safe(contextConfidence);
            this.nearExam = nearExam;
            this.observedAt = safe(observedAt);
        }
    }

    public static final class Study {
        public final StudyStatus status;
        public final String subject;
        public final String activity;
        public final double sessionProgress;
        public final int consecutiveStarts;
        public Study(StudyStatus status, String subject, String activity, double sessionProgress, int consecutiveStarts) {
            this.status = status == null ? StudyStatus.UNKNOWN : status;
            this.subject = safe(subject); this.activity = safe(activity);
            this.sessionProgress = clamp(sessionProgress); this.consecutiveStarts = Math.max(0, consecutiveStarts);
        }
    }

    public static final class Exam {
        public final ExamStatus status; public final String subject; public final String startsAt;
        public final long minutesUntil;
        public Exam(ExamStatus status, String subject, String startsAt, long minutesUntil) {
            this.status=status==null?ExamStatus.UNKNOWN:status; this.subject=safe(subject); this.startsAt=safe(startsAt); this.minutesUntil=minutesUntil;
        }
    }

    public static final class DeviceAppEvidence {
        public final String foregroundPackage; public final String appCategory; public final String source;
        public final boolean userGranted; public final String observedAt; public final String confidence;
        public DeviceAppEvidence(String foregroundPackage,String appCategory,String source,boolean userGranted,String observedAt,String confidence){
            this.foregroundPackage=safe(foregroundPackage); this.appCategory=safe(appCategory); this.source=safe(source);
            this.userGranted=userGranted; this.observedAt=safe(observedAt); this.confidence=safe(confidence);
        }
    }

    public static final class Temporal {
        public final String now; public final String previousObservedAt; public final long elapsedSeconds;
        public final long sequence; public final boolean rapidlyChanged;
        public Temporal(String now,String previousObservedAt,long elapsedSeconds,long sequence,boolean rapidlyChanged){
            this.now=safe(now); this.previousObservedAt=safe(previousObservedAt); this.elapsedSeconds=Math.max(0,elapsedSeconds);
            this.sequence=Math.max(0,sequence); this.rapidlyChanged=rapidlyChanged;
        }
    }

    public static final class Academic {
        public final int evidenceCount;
        public final Map<String, Double> masteryBySubject;
        public final Map<String, Double> confidenceBySubject;
        public final List<String> priorityWeaknesses;
        public final String latestSubject;
        public final String latestAssessmentType;
        public final Double latestScore;
        public final String latestObservedAt;
        public final int mistakePatternCount;
        public final List<String> mistakePatterns;
        public final List<String> recommendedInterventions;

        public Academic(int evidenceCount, Map<String, Double> masteryBySubject,
                        Map<String, Double> confidenceBySubject, List<String> priorityWeaknesses,
                        String latestSubject, String latestAssessmentType, Double latestScore,
                        String latestObservedAt, int mistakePatternCount) {
            this(evidenceCount, masteryBySubject, confidenceBySubject, priorityWeaknesses, latestSubject, latestAssessmentType, latestScore, latestObservedAt, mistakePatternCount, Collections.emptyList(), Collections.emptyList());
        }

        public Academic(int evidenceCount, Map<String, Double> masteryBySubject,
                        Map<String, Double> confidenceBySubject, List<String> priorityWeaknesses,
                        String latestSubject, String latestAssessmentType, Double latestScore,
                        String latestObservedAt, int mistakePatternCount, List<String> mistakePatterns, List<String> recommendedInterventions) {
            this.evidenceCount = Math.max(0, evidenceCount);
            this.masteryBySubject = Collections.unmodifiableMap(new LinkedHashMap<>(masteryBySubject == null ? Collections.emptyMap() : masteryBySubject));
            this.confidenceBySubject = Collections.unmodifiableMap(new LinkedHashMap<>(confidenceBySubject == null ? Collections.emptyMap() : confidenceBySubject));
            this.priorityWeaknesses = Collections.unmodifiableList(new ArrayList<>(priorityWeaknesses == null ? Collections.emptyList() : priorityWeaknesses));
            this.latestSubject = safe(latestSubject);
            this.latestAssessmentType = safe(latestAssessmentType);
            this.latestScore = latestScore;
            this.latestObservedAt = safe(latestObservedAt);
            this.mistakePatternCount = Math.max(0, mistakePatternCount);
            this.mistakePatterns = Collections.unmodifiableList(new ArrayList<>(mistakePatterns == null ? Collections.emptyList() : mistakePatterns));
            this.recommendedInterventions = Collections.unmodifiableList(new ArrayList<>(recommendedInterventions == null ? Collections.emptyList() : recommendedInterventions));
        }
    }

    public static final class Memory {
        public final int total;
        public final int confirmed;
        public final int likely;
        public final int uncertain;
        public final int archived;

        public Memory(int total, int confirmed, int likely, int uncertain, int archived) {
            this.total = Math.max(0, total); this.confirmed = Math.max(0, confirmed);
            this.likely = Math.max(0, likely); this.uncertain = Math.max(0, uncertain);
            this.archived = Math.max(0, archived);
        }
    }

    public static final class Conversation {
        public final boolean active;
        public final String mode;
        public final int recentTurns;
        public Conversation(boolean active, String mode, int recentTurns) {
            this.active = active; this.mode = safe(mode); this.recentTurns = Math.max(0, recentTurns);
        }
    }

    public static final class SystemState {
        public final boolean securityHealthy;
        public final boolean reliabilityHealthy;
        public final boolean offlineFirst;
        public final long sequence;
        public SystemState(boolean securityHealthy, boolean reliabilityHealthy, boolean offlineFirst, long sequence) {
            this.securityHealthy = securityHealthy; this.reliabilityHealthy = reliabilityHealthy;
            this.offlineFirst = offlineFirst; this.sequence = Math.max(0, sequence);
        }
    }

    public final String generatedAt;
    public final Situation situation;
    public final Academic academic;
    public final Memory memory;
    public final Study study;
    public final Exam exam;
    public final DeviceAppEvidence deviceAppEvidence;
    public final Temporal temporal;
    public final Conversation conversation;
    public final SystemState system;
    public final List<String> evidence;
    /** Recent meaningful events, not raw surveillance logs. */
    public final List<String> recentEvents;

    public NoriState(String generatedAt, Situation situation, Academic academic, Memory memory,
                     Conversation conversation, SystemState system, List<String> evidence) {
        this(generatedAt, situation, academic, memory, new Study(StudyStatus.UNKNOWN,"","",0,0),
                new Exam(ExamStatus.UNKNOWN,"","",0), new DeviceAppEvidence("","","",false,"",""),
                new Temporal(generatedAt,"",0,0,false), conversation, system, evidence, Collections.emptyList());
    }

    public NoriState(String generatedAt, Situation situation, Academic academic, Memory memory, Study study, Exam exam,
                     DeviceAppEvidence deviceAppEvidence, Temporal temporal, Conversation conversation, SystemState system, List<String> evidence) {
        this(generatedAt,situation,academic,memory,study,exam,deviceAppEvidence,temporal,conversation,system,evidence,Collections.emptyList());
    }

    public NoriState(String generatedAt, Situation situation, Academic academic, Memory memory, Study study, Exam exam,
                     DeviceAppEvidence deviceAppEvidence, Temporal temporal, Conversation conversation, SystemState system, List<String> evidence, List<String> recentEvents) {
        this.generatedAt = safe(generatedAt);
        this.situation = Objects.requireNonNull(situation, "situation");
        this.academic = Objects.requireNonNull(academic, "academic");
        this.memory = Objects.requireNonNull(memory, "memory");
        this.study = Objects.requireNonNull(study, "study");
        this.exam = Objects.requireNonNull(exam, "exam");
        this.deviceAppEvidence = Objects.requireNonNull(deviceAppEvidence, "deviceAppEvidence");
        this.temporal = Objects.requireNonNull(temporal, "temporal");
        this.conversation = Objects.requireNonNull(conversation, "conversation");
        this.system = Objects.requireNonNull(system, "system");
        this.evidence = Collections.unmodifiableList(new ArrayList<>(evidence == null ? Collections.emptyList() : evidence));
        this.recentEvents = Collections.unmodifiableList(new ArrayList<>(recentEvents == null ? Collections.emptyList() : recentEvents));
    }

    public static NoriState empty() {
        return new NoriState(Instant.now().toString(),
                new Situation(Availability.UNKNOWN, "", "", "", false, ""),
                new Academic(0, null, null, null, "", "", null, "", 0),
                new Memory(0, 0, 0, 0, 0),
                new Conversation(false, "", 0),
                new SystemState(true, true, true, 0), Collections.emptyList());
    }

    private static String safe(String s) { return s == null ? "" : s; }
    private static double clamp(double x){ return Double.isNaN(x)||Double.isInfinite(x)?0:Math.max(0,Math.min(1,x)); }
}
