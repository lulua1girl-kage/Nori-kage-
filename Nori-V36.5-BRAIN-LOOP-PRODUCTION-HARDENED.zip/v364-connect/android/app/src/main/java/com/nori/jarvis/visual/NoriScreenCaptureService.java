package com.nori.jarvis.visual;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.MediaProjection;
import android.os.*;
import androidx.core.app.ServiceCompat;
import androidx.core.app.NotificationCompat;
import java.io.*;
import java.nio.ByteBuffer;

/** Captures one user-approved screen frame, then immediately tears the projection down. */
public class NoriScreenCaptureService extends Service {
    public static final String ACTION_CAPTURE = "com.nori.jarvis.visual.SCREEN_CAPTURE";
    public static final String EVENT_RESULT = "com.nori.jarvis.visual.SCREEN_RESULT";
    public static final String EVENT_ERROR = "com.nori.jarvis.visual.SCREEN_ERROR";
    private MediaProjection projection;
    private VirtualDisplay display;
    private ImageReader reader;
    private Handler handler;
    private boolean done;

    @Override public void onCreate(){ super.onCreate(); handler=new Handler(Looper.getMainLooper()); createChannel(); }
    @Override public int onStartCommand(Intent in,int flags,int startId){
        if(in==null || !ACTION_CAPTURE.equals(in.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if(Build.VERSION.SDK_INT>=29) ServiceCompat.startForeground(this,7521,notification(),android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION); else startForeground(7521,notification());
        try {
            int code=in.getIntExtra("resultCode",Activity.RESULT_CANCELED);
            Intent data=in.getParcelableExtra("data");
            if(code!=Activity.RESULT_OK || data==null){ fail("Screen capture permission was not granted."); return START_NOT_STICKY; }
            MediaProjectionManagerCompat m=new MediaProjectionManagerCompat(this);
            projection=m.get(code,data);
            if(projection==null){ fail("MediaProjection unavailable."); return START_NOT_STICKY; }
            int w=Math.min(1280, getResources().getDisplayMetrics().widthPixels);
            int h=Math.min(720, getResources().getDisplayMetrics().heightPixels);
            int density=getResources().getDisplayMetrics().densityDpi;
            reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
            reader.setOnImageAvailableListener(r->captureLatest(r,w,h),handler);
            projection.registerCallback(new MediaProjection.Callback(){
                @Override public void onStop(){ if(!done) fail("Screen capture permission ended."); }
            },handler);
            display=projection.createVirtualDisplay("NoriScreenContext",w,h,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
            handler.postDelayed(()->{ if(!done) captureLatest(reader,w,h); },700);
        }catch(Exception e){ fail(e.getMessage()); }
        return START_NOT_STICKY;
    }

    private void captureLatest(ImageReader r,int w,int h){
        if(done||r==null)return; Image image=null;
        try{
            image=r.acquireLatestImage(); if(image==null)return;
            Image.Plane p=image.getPlanes()[0]; ByteBuffer b=p.getBuffer(); int ps=p.getPixelStride(), rs=p.getRowStride(); int rowPadding=rs-ps*w;
            Bitmap bmp=Bitmap.createBitmap(w+rowPadding/ps,h,Bitmap.Config.ARGB_8888); bmp.copyPixelsFromBuffer(b);
            Bitmap cropped=Bitmap.createBitmap(bmp,0,0,w,h); bmp.recycle();
            File dir=new File(getCacheDir(),"nori_visual"); if(!dir.exists())dir.mkdirs();
            File out=new File(dir,"screen_"+System.currentTimeMillis()+".jpg");
            try(FileOutputStream fos=new FileOutputStream(out)){cropped.compress(Bitmap.CompressFormat.JPEG,72,fos);} cropped.recycle();
            done=true; Intent i=new Intent(EVENT_RESULT); i.setPackage(getPackageName()); i.putExtra("path",out.getAbsolutePath()); sendBroadcast(i); stopProjection(); stopForeground(true); stopSelf();
        }catch(Exception e){fail(e.getMessage());}finally{if(image!=null)image.close();}
    }
    private void fail(String msg){if(done)return;done=true;Intent i=new Intent(EVENT_ERROR);i.setPackage(getPackageName());i.putExtra("error",msg==null?"Screen capture failed":msg);sendBroadcast(i);stopProjection();stopForeground(true);stopSelf();}
    private void stopProjection(){try{if(display!=null)display.release();}catch(Exception ignored){}try{if(reader!=null)reader.close();}catch(Exception ignored){}try{if(projection!=null)projection.stop();}catch(Exception ignored){}display=null;reader=null;projection=null;}
    @Override public void onDestroy(){stopProjection();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("nori_visual","Nori Visual Context",NotificationManager.IMPORTANCE_LOW));}
    private Notification notification(){return new Notification.Builder(this,"nori_visual").setContentTitle("NORI VISUAL CONTEXT").setContentText("Capturing one approved screen frame").setSmallIcon(android.R.drawable.ic_menu_view).setOngoing(true).build();}

    /** Small compatibility wrapper so the service has no dependency on a UI activity. */
    static final class MediaProjectionManagerCompat {
        private final android.media.projection.MediaProjectionManager manager;
        MediaProjectionManagerCompat(Context c){manager=(android.media.projection.MediaProjectionManager)c.getSystemService(Context.MEDIA_PROJECTION_SERVICE);}
        MediaProjection get(int code,Intent data){return manager.getMediaProjection(code,data);}
    }
}
