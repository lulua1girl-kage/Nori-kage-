package com.nori.jarvis.nori.actions.model;

import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/** Immutable declaration of what a tool is allowed to do. */
public final class ToolDefinition {
    public final String id;
    public final String label;
    public final String educationalPurpose;
    public final ActionType type;
    public final boolean confirmationRequired;
    public final boolean educationalAllowed;
    public final Set<String> requiredPermissions;

    public ToolDefinition(String id, String label, String educationalPurpose, ActionType type,
                          boolean confirmationRequired, boolean educationalAllowed, Set<String> requiredPermissions) {
        if (id == null || id.trim().isEmpty()) throw new IllegalArgumentException("tool id required");
        this.id = id;
        this.label = label == null ? id : label;
        this.educationalPurpose = educationalPurpose == null ? "" : educationalPurpose;
        this.type = type == null ? ActionType.LOCAL_MUTATION : type;
        this.confirmationRequired = confirmationRequired;
        this.educationalAllowed = educationalAllowed;
        this.requiredPermissions = Collections.unmodifiableSet(new LinkedHashSet<>(requiredPermissions == null ? Collections.<String>emptySet() : requiredPermissions));
    }
}
