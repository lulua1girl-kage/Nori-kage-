package com.nori.jarvis.nori.brain.capacity;

import java.util.*;

/** Human-readable capability registry for diagnostics and future UI exposure. */
public final class NoriBrainCapacityCatalog {
    private NoriBrainCapacityCatalog() {}
    public static List<String> all() {
        return Collections.unmodifiableList(Arrays.asList(
            "fast_request_normalization",
            "local_intent_classification",
            "adaptive_reasoning_effort",
            "disclosure_minimization",
            "humane_response_mode",
            "goal_vs_task_scope",
            "context_compression",
            "repeated_pattern_detection",
            "evidence_threshold_for_strictness",
            "safety_first_boundary",
            "fresh_research_gate",
            "privacy_aware_cache_gate",
            "request_deduplication_key",
            "burst_plan_memoization",
            "post_action_verification_contract",
            "decision_history_without_content_storage",
            "human_override_guard",
            "ten_plus_source_research_target",
            "local_first_external_escalation",
            "unified_brain_preflight"
        ));
    }
}
