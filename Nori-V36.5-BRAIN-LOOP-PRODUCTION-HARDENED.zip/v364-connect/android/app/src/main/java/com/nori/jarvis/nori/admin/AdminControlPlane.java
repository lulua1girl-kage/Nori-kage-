package com.nori.jarvis.nori.admin;

import com.nori.jarvis.nori.admin.model.*;
import com.nori.jarvis.nori.data.DataRepository;
import com.nori.jarvis.nori.identity.NoriSignupRequest;
import com.nori.jarvis.nori.identity.NoriSignupPolicy;
import com.nori.jarvis.nori.identity.NoriSignupDecision;
import java.util.*;

/**
 * Stage 14 admin/control plane. Authorization is deny-by-default.
 * The first owner identity is bootstrapped explicitly; there is no public
 * self-promotion path from STUDENT/VIEWER to OWNER/ADMIN.
 *
 * This is the native authorization boundary. A truly hostile modified APK
 * cannot be protected by local Java alone; production multi-user deployments
 * must enforce the same policy on an authenticated server.
 */
public final class AdminControlPlane {
    private static final String OWNER_KEY = "stage14.admin.owner";
    private static final String INVITES_KEY = "stage14.admin.invites";
    private static final String STUDENTS_KEY = "stage14.admin.students";
    private static final String ROLES_KEY = "stage14.admin.roles";
    private static final String AUDIT_KEY = "stage14.admin.audit";

    private final DataRepository repository;
    private final Map<String, AdminRole> roles = new LinkedHashMap<>();
    private final Map<String, InviteRecord> invites = new LinkedHashMap<>();
    private final Map<String, StudentRecord> students = new LinkedHashMap<>();
    private final List<AdminAuditRecord> audit = new ArrayList<>();
    private String ownerId;

    public AdminControlPlane() { this(null); }

    public AdminControlPlane(DataRepository repository) {
        this.repository = repository;
        load();
    }

    public synchronized boolean isBootstrapped() { return ownerId != null && !ownerId.isEmpty(); }
    public synchronized String ownerId() { return ownerId; }

    public synchronized boolean bootstrapOwner(String principalId) {
        return bootstrapOwner(principalId, "");
    }

    /** Production bootstrap must supply a distinct verified backup email outside the APK. */
    public synchronized boolean bootstrapOwner(String principalId, String backupEmail) {
        if (!valid(principalId) || !isDistinctEmail(principalId, backupEmail) || isBootstrapped()) return false;
        ownerId = normalize(principalId);
        roles.put(ownerId, AdminRole.OWNER);
        persist();
        record(ownerId, "bootstrap_owner", ownerId, true);
        persist();
        return true;
    }

    public synchronized boolean invite(String actorId, String email, AdminRole role) {
        if (!isOwner(actorId) || !valid(email) || role == null || role == AdminRole.OWNER) return false;
        String e = normalize(email);
        invites.put(e, new InviteRecord(e, role, System.currentTimeMillis(), true));
        record(actorId, "invite", e, true);
        persist();
        return true;
    }

    public synchronized boolean revokeInvite(String actorId, String email) {
        if (!isOwner(actorId) || !valid(email)) return false;
        String e = normalize(email);
        InviteRecord old = invites.get(e);
        if (old == null) return false;
        invites.put(e, new InviteRecord(e, old.role, old.createdAt, false));
        record(actorId, "revoke_invite", e, true);
        persist();
        return true;
    }

    public synchronized AccessDecision authenticate(String principalId, String email) {
        if (!valid(principalId) || !valid(email)) return deny(principalId, null, "missing_identity");
        String id = normalize(principalId), e = normalize(email);
        if (id.equals(ownerId)) return allow(id, null, "owner_authenticated");
        InviteRecord invite = invites.get(e);
        if (invite == null || !invite.active) return deny(id, null, "not_invited_to_nori_project");
        AdminRole role = roles.get(id);
        if (role == null) {
            roles.put(id, invite.role);
            persist();
        }
        return allow(id, null, "invited_access");
    }

    public synchronized AccessDecision authorize(String principalId, String studentId, String operation) {
        if (!valid(principalId) || !valid(operation)) return deny(principalId, studentId, "invalid_request");
        AdminRole role = roles.get(normalize(principalId));
        if (role == null) return deny(principalId, studentId, "unauthorized");
        String op = operation.toLowerCase(Locale.ROOT);
        boolean adminOperation = op.startsWith("admin_") || op.equals("registry_read") || op.equals("audit_read") || op.equals("student_read_all");
        boolean studentOperation = op.startsWith("student_") || op.startsWith("own_");
        if (adminOperation && role != AdminRole.OWNER && role != AdminRole.ADMIN) return deny(principalId, studentId, "admin_only");
        if (role == AdminRole.STUDENT && studentId != null && !studentId.equals(principalId) && studentOperation) return deny(principalId, studentId, "student_isolation");
        if (role == AdminRole.VIEWER && !op.equals("own_profile_read")) return deny(principalId, studentId, "viewer_read_scope");
        return allow(principalId, studentId, "authorized");
    }

    /** Submit a new student application. No application is admitted without an accepted program basis. */
    public synchronized NoriSignupDecision reviewSignup(String actorId, NoriSignupRequest request, boolean emailVerified, boolean backupVerified, NoriSignupPolicy.AdmissionBasis basis) {
        if (!isOwner(actorId) && roles.get(normalize(actorId)) != AdminRole.ADMIN)
            return new NoriSignupDecision(com.nori.jarvis.nori.identity.NoriAdmissionStatus.REJECTED,false,false,false,"admin_only");
        NoriSignupDecision d = new NoriSignupPolicy().evaluate(request,emailVerified,backupVerified,basis);
        if (d.canEnterApp()) {
            String studentId = "student:" + Integer.toHexString((request.email+":"+System.nanoTime()).hashCode());
            students.put(studentId,new StudentRecord(studentId,request.name,normalize(request.email),normalize(request.backupEmail),request.age,true,true,true,System.currentTimeMillis()));
            record(actorId,"approve_signup",studentId,true); persist();
        }
        return d;
    }

    public synchronized boolean registerStudent(String actorId, String studentId, String displayName, String email) {
        if (!isOwner(actorId) && roles.get(normalize(actorId)) != AdminRole.ADMIN) return false;
        if (!valid(studentId) || !valid(displayName) || !valid(email)) return false;
        students.put(normalize(studentId), new StudentRecord(normalize(studentId), displayName.trim(), normalize(email), true, System.currentTimeMillis()));
        record(actorId, "register_student", studentId, true);
        persist();
        return true;
    }

    public synchronized boolean deactivateStudent(String actorId, String studentId) {
        if (!isOwner(actorId) || !valid(studentId)) return false;
        StudentRecord s = students.get(normalize(studentId));
        if (s == null) return false;
        students.put(s.studentId, new StudentRecord(s.studentId, s.displayName, s.email, false, s.createdAt));
        record(actorId, "deactivate_student", studentId, true);
        persist();
        return true;
    }

    public synchronized List<StudentRecord> students() { return Collections.unmodifiableList(new ArrayList<>(students.values())); }
    public synchronized List<InviteRecord> invites() { return Collections.unmodifiableList(new ArrayList<>(invites.values())); }
    public synchronized List<AdminAuditRecord> audit() { return Collections.unmodifiableList(new ArrayList<>(audit)); }
    public synchronized AdminRole roleOf(String principalId) { return roles.get(normalize(principalId)); }

    private boolean isOwner(String id) { return valid(id) && normalize(id).equals(ownerId); }
    private AccessDecision allow(String p, String s, String reason) { record(p, "authorize", s, true); return new AccessDecision(true, reason, p, s); }
    private AccessDecision deny(String p, String s, String reason) { record(p, "authorize", s, false); persist(); return new AccessDecision(false, reason, p, s); }
    private void record(String actor, String action, String target, boolean ok) {
        audit.add(new AdminAuditRecord(UUID.randomUUID().toString(), actor, action, target, System.currentTimeMillis(), ok));
        while (audit.size() > 500) audit.remove(0);
    }
    private boolean valid(String s) { return s != null && !s.trim().isEmpty(); }
    private boolean isDistinctEmail(String primary, String backup) { return valid(backup) && primary.contains("@") && backup.contains("@") && !primary.trim().equalsIgnoreCase(backup.trim()); }
    private String normalize(String s) { return s.trim().toLowerCase(Locale.ROOT); }

    /* DataRepository stores opaque JSON strings during migration. The control
       plane deliberately persists only minimal metadata; detailed student data
       stays behind per-student namespaces in later stages. */
    private void load() { /* repository adapter is intentionally conservative until schema v2 */ }
    private void persist() { /* Stage 14 keeps in-memory state portable; schema persistence is Stage 14b/15 */ }
}
