package com.nori.jarvis.nori.data;

/**
 * Contract shared by the V32 export helper and native migration layer.
 *
 * V32 export:
 * {
 *   "schemaVersion": 1,
 *   "exportedAt": <epoch-ms>,
 *   "source": "nori-v32-localStorage",
 *   "data": { "<key>": "<exact localStorage value>" }
 * }
 */
public final class V32ExportContract {
    public static final int CURRENT_SCHEMA_VERSION = 1;
    public static final String SOURCE = "nori-v32-localStorage";

    private V32ExportContract() {}
}
