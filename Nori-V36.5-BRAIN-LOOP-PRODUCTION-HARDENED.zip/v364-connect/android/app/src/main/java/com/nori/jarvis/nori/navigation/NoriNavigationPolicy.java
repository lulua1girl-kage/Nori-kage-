package com.nori.jarvis.nori.navigation;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import java.util.*;

/**
 * App navigation boundary. Explicit user commands may open ordinary apps, but
 * an active Nori focus restriction is checked first. Nori does not manufacture
 * a shortcut around an integrity rule.
 */
public final class NoriNavigationPolicy {
    private static final Map<String,String> ALIASES=new LinkedHashMap<>();
    static {
        ALIASES.put("instagram","com.instagram.android");
        ALIASES.put("pinterest","com.pinterest");
        ALIASES.put("youtube","com.google.android.youtube");
        ALIASES.put("wps","cn.wps.moffice_eng");
        ALIASES.put("wps office","cn.wps.moffice_eng");
        ALIASES.put("chrome","com.android.chrome");
    }
    public static final class Result { public final boolean opened,blocked; public final String packageName,reason;
        Result(boolean opened,boolean blocked,String pkg,String reason){this.opened=opened;this.blocked=blocked;this.packageName=pkg;this.reason=reason;} }
    public Result open(Context context,String spokenName){
        String key=spokenName==null?"":spokenName.trim().toLowerCase(Locale.ROOT);
        String pkg=ALIASES.get(key);
        if(pkg==null) return new Result(false,false,"","unknown_app");
        android.content.SharedPreferences p=context.getSharedPreferences("nori_focus_policy",Context.MODE_PRIVATE);
        if(p.getBoolean("active",false)){
            Set<String> blocked=p.getStringSet("blocked_packages",Collections.emptySet());
            if(blocked.contains(pkg)) return new Result(false,true,pkg,"focus_restriction_active");
        }
        PackageManager pm=context.getPackageManager(); Intent i=pm.getLaunchIntentForPackage(pkg);
        if(i==null) return new Result(false,false,pkg,"app_not_installed");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); context.startActivity(i);
        return new Result(true,false,pkg,"opened_by_explicit_user_command");
    }
}
