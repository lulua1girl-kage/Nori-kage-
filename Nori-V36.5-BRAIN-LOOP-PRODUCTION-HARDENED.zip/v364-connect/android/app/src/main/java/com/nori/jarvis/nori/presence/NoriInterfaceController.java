package com.nori.jarvis.nori.presence;

import android.content.Context;
import android.content.SharedPreferences;

/** Tiny local presentation preference. It deliberately does not own Nori memory or conversation. */
public final class NoriInterfaceController {
    private static final String PREFS="nori_interface";
    private static final String KEY_MODE="mode";
    private final SharedPreferences prefs;
    public NoriInterfaceController(Context context){prefs=context.getApplicationContext().getSharedPreferences(PREFS,Context.MODE_PRIVATE);}
    public NoriInterfaceMode getMode(){
        try{return NoriInterfaceMode.valueOf(prefs.getString(KEY_MODE,NoriInterfaceMode.STANDARD.name()));}
        catch(Exception e){return NoriInterfaceMode.STANDARD;}
    }
    public void setMode(NoriInterfaceMode mode){prefs.edit().putString(KEY_MODE,mode.name()).apply();}
}
