package com.nori.jarvis.nori.edgeai;

/** Hardware/privacy policy for local inference. No model is downloaded or run silently. */
public final class NoriEdgeAiPolicy {
    public final boolean preferOnDevice;
    public final boolean allowModelDownload;
    public final boolean allowRemoteFallback;
    public final long maxModelBytes;
    public final int maxContextTokens;
    public final long maxInferenceMillis;

    public NoriEdgeAiPolicy(boolean preferOnDevice, boolean allowModelDownload, boolean allowRemoteFallback,
                            long maxModelBytes, int maxContextTokens, long maxInferenceMillis){
        this.preferOnDevice=preferOnDevice; this.allowModelDownload=allowModelDownload;
        this.allowRemoteFallback=allowRemoteFallback; this.maxModelBytes=Math.max(0,maxModelBytes);
        this.maxContextTokens=Math.max(256,maxContextTokens); this.maxInferenceMillis=Math.max(500,maxInferenceMillis);
    }
    public static NoriEdgeAiPolicy safeDefault(){return new NoriEdgeAiPolicy(true,false,true,1024L*1024L*1024L,8192,12000);}
    public boolean permits(NoriEdgeModel model){return model!=null&&model.estimatedBytes<=maxModelBytes&&model.contextTokens<=maxContextTokens;}
}
