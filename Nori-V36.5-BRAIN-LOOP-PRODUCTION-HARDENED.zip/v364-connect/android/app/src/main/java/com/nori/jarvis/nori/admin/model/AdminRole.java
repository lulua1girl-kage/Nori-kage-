package com.nori.jarvis.nori.admin.model;

public enum AdminRole {
    OWNER,
    ADMIN,
    STUDENT,
    VIEWER
}
