package com.nori.jarvis.nori.web.engine;

import com.nori.jarvis.nori.web.model.*;
import java.util.*;

/** Local-first document ingestion, chunking and lexical retrieval. No automatic memory saving. */
public final class DocumentIntelligence {
    private final DocumentParser parser=new DocumentParser();
    private final Map<String,DocumentSource> documents=new LinkedHashMap<>();
    private final Map<String,List<DocumentChunk>> chunks=new LinkedHashMap<>();

    public synchronized DocumentSource ingest(String name,String mimeType,String sourceUri,String rawText){
        String text=parser.parse(mimeType,name,rawText); String id="doc-"+UUID.randomUUID();
        DocumentSource d=new DocumentSource(id,name,mimeType,sourceUri,text); documents.put(id,d); chunks.put(id,chunk(d)); return d;
    }
    private List<DocumentChunk> chunk(DocumentSource d){
        final int size=2200, overlap=250; List<DocumentChunk> out=new ArrayList<>();
        if(d.text.isEmpty()) return out; int start=0,index=0;
        while(start<d.text.length()){
            int end=Math.min(d.text.length(),start+size); if(end<d.text.length()){int p=d.text.lastIndexOf('\n',end); if(p>start+100) end=p;}
            out.add(new DocumentChunk(d.id,d.id+"-"+index,index,start,end,d.text.substring(start,end).trim()));
            if(end>=d.text.length()) break; start=Math.max(end-overlap,start+1); index++;
        } return Collections.unmodifiableList(out);
    }
    public synchronized DocumentSource get(String id){return documents.get(id);}
    public synchronized List<DocumentChunk> chunks(String id){return chunks.containsKey(id)?chunks.get(id):Collections.emptyList();}
    public synchronized List<DocumentSearchResult> search(String query,int limit){
        if(query==null||query.trim().isEmpty()) return Collections.emptyList();
        String[] terms=query.toLowerCase(Locale.ROOT).split("\\W+"); List<DocumentSearchResult> r=new ArrayList<>();
        for(List<DocumentChunk> list:chunks.values()) for(DocumentChunk c:list){
            String t=c.text.toLowerCase(Locale.ROOT); int hits=0; for(String term:terms) if(term.length()>1 && t.contains(term)) hits++;
            if(hits>0) r.add(new DocumentSearchResult(c.chunkId,c.documentId,c.text,(double)hits/Math.max(1,terms.length)));
        }
        r.sort((a,b)->Double.compare(b.score,a.score)); return Collections.unmodifiableList(r.subList(0,Math.min(Math.max(1,limit),r.size())));
    }
    public synchronized void clear(){documents.clear();chunks.clear();}
}
