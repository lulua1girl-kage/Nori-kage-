package com.nori.jarvis.nori.memory;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Structured student model. Values are evidence-backed and carry provenance. */
public final class PersonalModel {
    public final Map<String, String> goals;
    public final Map<String, String> preferences;
    public final Map<String, String> projects;
    public final Map<String, String> academicState;
    public final Map<String, String> workPatterns;
    public final Map<String, String> constraints;
    public final Map<String, String> communicationPreferences;
    public final Map<String, String> currentPriorities;
    public final Map<String, String> confirmedFacts;
    public final Map<String, String> uncertainAssumptions;

    public PersonalModel() {
        goals = new LinkedHashMap<>(); preferences = new LinkedHashMap<>(); projects = new LinkedHashMap<>();
        academicState = new LinkedHashMap<>(); workPatterns = new LinkedHashMap<>(); constraints = new LinkedHashMap<>();
        communicationPreferences = new LinkedHashMap<>(); currentPriorities = new LinkedHashMap<>();
        confirmedFacts = new LinkedHashMap<>(); uncertainAssumptions = new LinkedHashMap<>();
    }

    public Map<String, String> readOnly(Map<String, String> source) { return Collections.unmodifiableMap(source); }

    public void apply(MemoryItem item) {
        if (item == null || item.status == MemoryItem.Status.ARCHIVED) return;
        Map<String, String> target;
        switch (item.category) {
            case GOALS: target = goals; break;
            case PREFERENCES: target = preferences; break;
            case PROJECTS: target = projects; break;
            case ACADEMIC: target = academicState; break;
            case SYSTEM_CONFIGURATION: target = communicationPreferences; break;
            default: target = confirmedFacts;
        }
        String key = item.id;
        target.put(key, item.text);
        if (item.status == MemoryItem.Status.CONFIRMED) uncertainAssumptions.remove(key);
        else uncertainAssumptions.put(key, item.text);
    }

    public PersonalModel snapshot() {
        PersonalModel copy = new PersonalModel();
        copy.goals.putAll(goals); copy.preferences.putAll(preferences); copy.projects.putAll(projects);
        copy.academicState.putAll(academicState); copy.workPatterns.putAll(workPatterns); copy.constraints.putAll(constraints);
        copy.communicationPreferences.putAll(communicationPreferences); copy.currentPriorities.putAll(currentPriorities);
        copy.confirmedFacts.putAll(confirmedFacts); copy.uncertainAssumptions.putAll(uncertainAssumptions);
        return copy;
    }
}
