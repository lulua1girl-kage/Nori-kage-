package com.nori.jarvis.nori.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Native persistent store for Nori.
 *
 * Stage 2 deliberately uses a generic JSON value column so existing V32
 * records can be migrated without prematurely forcing them into a new schema.
 * Old V32 data is never deleted by this class.
 */
public final class NoriDatabase extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "nori_native.db";
    public static final int DATABASE_VERSION = 2;

    public NoriDatabase(Context context) {
        super(context.getApplicationContext(), DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
        db.enableWriteAheadLogging();
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE nori_store (" +
                "key TEXT PRIMARY KEY NOT NULL," +
                "value_json TEXT NOT NULL," +
                "category TEXT NOT NULL DEFAULT 'general'," +
                "schema_version INTEGER NOT NULL DEFAULT 1," +
                "updated_at INTEGER NOT NULL");
        db.execSQL("CREATE INDEX idx_nori_store_category ON nori_store(category)");
        db.execSQL("CREATE TABLE nori_integrity_meta (id INTEGER PRIMARY KEY CHECK (id = 1), schema_version INTEGER NOT NULL, last_verified_at INTEGER NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS nori_integrity_meta (id INTEGER PRIMARY KEY CHECK (id = 1), schema_version INTEGER NOT NULL, last_verified_at INTEGER NOT NULL)");
        }
        // Additive only: never drop or silently rewrite the V32/native store.
    }
}
