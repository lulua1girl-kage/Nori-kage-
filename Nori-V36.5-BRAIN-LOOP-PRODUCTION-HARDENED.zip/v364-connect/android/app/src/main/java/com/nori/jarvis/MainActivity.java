package com.nori.jarvis;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;
import com.nori.jarvis.voice.NoriVoicePlugin;
import com.nori.jarvis.visual.NoriVisualPlugin;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NoriBlockerPlugin.class);
        registerPlugin(NoriVoicePlugin.class);
        registerPlugin(NoriVisualPlugin.class);
        registerPlugin(NoriWorldPlugin.class);
        registerPlugin(NoriOperationsPlugin.class);
        registerPlugin(NoriDevicePlugin.class);
        registerPlugin(NoriMetaBrainPlugin.class);
        registerPlugin(NoriRuntimePlugin.class);
        registerPlugin(NoriAuthPlugin.class);
        registerPlugin(NoriAdminPlugin.class);
        registerPlugin(NoriKnowledgePlugin.class);
        registerPlugin(NoriBiometricPlugin.class);
        registerPlugin(com.nori.jarvis.visual.NoriExamIntegrityPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
