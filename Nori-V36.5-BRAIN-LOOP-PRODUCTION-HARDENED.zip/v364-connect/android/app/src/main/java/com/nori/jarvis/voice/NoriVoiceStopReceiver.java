package com.nori.jarvis.voice;
import android.content.*;
public class NoriVoiceStopReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context c, Intent i){ c.stopService(new Intent(c,NoriVoiceService.class)); }
}
