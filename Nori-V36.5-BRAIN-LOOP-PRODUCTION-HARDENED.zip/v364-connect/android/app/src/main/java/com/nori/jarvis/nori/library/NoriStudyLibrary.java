package com.nori.jarvis.nori.library;
import android.content.*;import android.net.Uri;import android.provider.OpenableColumns;import java.util.*;
/** Consent-based study library. Nori can inspect only folders/files the user explicitly grants through SAF. */
public final class NoriStudyLibrary {
 public static final class Item { public final Uri uri; public final String name,subject,grade; Item(Uri u,String n,String s,String g){uri=u;name=n;subject=s;grade=g;} }
 public Item classify(Uri u,String name){String n=(name==null?"":name).toLowerCase(Locale.ROOT);String[] subs={"math","mathematics","physics","chemistry","biology","english","agriculture","it","web design"};String subject="Unknown";for(String x:subs)if(n.contains(x)){subject=x;break;}String grade="Unknown";java.util.regex.Matcher m=java.util.regex.Pattern.compile("(?:grade|g|class)[ _-]?(9|10|11|12)").matcher(n);if(m.find())grade="Grade "+m.group(1);return new Item(u,name,subject,grade);}
 public Intent openTreeIntent(){return new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION|Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);}
}
