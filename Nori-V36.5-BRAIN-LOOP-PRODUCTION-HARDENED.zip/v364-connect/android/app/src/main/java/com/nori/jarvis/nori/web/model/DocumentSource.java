package com.nori.jarvis.nori.web.model;

public final class DocumentSource {
    public final String id, name, mimeType, sourceUri, text;
    public final long characterCount, createdAt;
    public DocumentSource(String id,String name,String mimeType,String sourceUri,String text){
        this.id=id; this.name=name; this.mimeType=mimeType; this.sourceUri=sourceUri;
        this.text=text==null?"":text; this.characterCount=this.text.length(); this.createdAt=System.currentTimeMillis();
    }
}
