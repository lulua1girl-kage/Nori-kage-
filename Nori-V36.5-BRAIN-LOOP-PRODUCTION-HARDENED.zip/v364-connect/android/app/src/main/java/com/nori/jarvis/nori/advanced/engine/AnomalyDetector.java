package com.nori.jarvis.nori.advanced.engine;

import com.nori.jarvis.nori.education.model.AcademicEvidence;
import com.nori.jarvis.nori.advanced.model.AnomalyReport;
import java.util.*;

public final class AnomalyDetector {
    public AnomalyReport detect(String subject,List<AcademicEvidence> input){
        List<AcademicEvidence> rows=new ArrayList<>();if(input!=null)for(AcademicEvidence e:input)if(e!=null&&(subject==null||subject.equalsIgnoreCase(e.subject)))rows.add(e);
        if(rows.size()<3)return new AnomalyReport(subject,false,0,"insufficient_data",0.2,Collections.singletonList("Three observations are needed for anomaly detection."));
        double mean=rows.stream().mapToDouble(e->e.score).average().orElse(0);double var=0;for(AcademicEvidence e:rows)var+=(e.score-mean)*(e.score-mean);double sd=Math.sqrt(var/rows.size());AcademicEvidence last=rows.get(rows.size()-1);double z=sd<1e-9?0:(last.score-mean)/sd;
        boolean anomaly=Math.abs(z)>=2.0;String type=z<=-2?"unusually_low_result":z>=2?"unusually_high_result":"normal_range";double conf=Math.min(0.95,0.35+rows.size()*0.05);
        return new AnomalyReport(subject,anomaly,Math.abs(z),type,conf,Arrays.asList("Baseline mean="+round(mean),"Baseline standard deviation="+round(sd),"Latest score="+round(last.score),"Standardized deviation="+round(z)));
    }
    private static double round(double x){return Math.round(x*100.0)/100.0;}
}
