package com.nori.jarvis;

import android.app.*;
import android.content.Context;
import android.os.Build;
import android.content.Intent;
import android.provider.Settings;
import android.net.Uri;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.nori.jarvis.nori.android.alarm.NoriAlarmService;
import com.nori.jarvis.nori.android.notification.NoriNotificationService;

/** Small native device boundary for features already present in the web app. */
@CapacitorPlugin(name="NoriDevice")
public final class NoriDevicePlugin extends Plugin {
    private NoriAlarmService alarms;
    private NoriNotificationService notifications;
    @Override public void load(){ alarms=new NoriAlarmService(getContext()); notifications=new NoriNotificationService(getContext()); }

    @PluginMethod public void requestPermissions(PluginCall c){
        if(Build.VERSION.SDK_INT>=33 && !notifications.canPost()){
            Intent i=new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getContext().getPackageName());
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); getContext().startActivity(i);
        }
        c.resolve(new JSObject().put("display", notifications.canPost()?"granted":"denied"));
    }
    @PluginMethod public void status(PluginCall c){c.resolve(new JSObject().put("notifications",notifications.canPost()));}
    @PluginMethod public void schedule(PluginCall c){
        try{
            long at=c.getLong("at",0L); int id=c.getInt("id",(int)(System.currentTimeMillis()&0x7fffffff));
            alarms.scheduleReminder(id,at,c.getString("title","Nori Reminder"),c.getString("body","Scheduled reminder"));
            c.resolve(new JSObject().put("ok",true).put("id",id));
        }catch(Exception e){c.reject(e.getMessage()==null?"schedule_failed":e.getMessage());}
    }
    @PluginMethod public void cancel(PluginCall c){try{alarms.cancel(c.getInt("id",0));c.resolve(new JSObject().put("ok",true));}catch(Exception e){c.reject(e.getMessage());}}
}
