package com.nori.jarvis.nori.edgeai;

import java.util.*;

/** Describes a locally installed model without embedding model bytes in the app. */
public final class NoriEdgeModel {
    public final String id, displayName, format, path;
    public final NoriOnDeviceBackend backend;
    public final Set<NoriOnDeviceTask> tasks;
    public final long estimatedBytes;
    public final boolean multimodal;
    public final int contextTokens;

    public NoriEdgeModel(String id, String displayName, String format, String path,
                         NoriOnDeviceBackend backend, Set<NoriOnDeviceTask> tasks,
                         long estimatedBytes, boolean multimodal, int contextTokens) {
        this.id=id==null?"":id; this.displayName=displayName==null?this.id:displayName;
        this.format=format==null?"":format; this.path=path==null?"":path;
        this.backend=backend==null?NoriOnDeviceBackend.BUILTIN_DETERMINISTIC:backend;
        this.tasks=Collections.unmodifiableSet(tasks==null?Collections.emptySet():EnumSet.copyOf(tasks));
        this.estimatedBytes=Math.max(0,estimatedBytes); this.multimodal=multimodal;
        this.contextTokens=Math.max(0,contextTokens);
    }
    public boolean supports(NoriOnDeviceTask task){return task!=null&&tasks.contains(task);}
}
