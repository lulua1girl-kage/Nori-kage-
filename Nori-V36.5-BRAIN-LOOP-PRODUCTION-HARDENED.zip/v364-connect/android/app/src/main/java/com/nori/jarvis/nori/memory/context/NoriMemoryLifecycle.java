package com.nori.jarvis.nori.memory.context;

import com.nori.jarvis.nori.memory.MemoryEngine;
import com.nori.jarvis.nori.memory.MemoryItem;
import java.time.Instant;
import java.util.*;

/**
 * Non-destructive memory lifecycle manager. It identifies stale, duplicate and supersession
 * candidates; it never silently deletes or rewrites user memory.
 */
public final class NoriMemoryLifecycle {
    public static Audit audit(MemoryEngine engine) {
        if (engine == null) return new Audit(0,0,0,Collections.emptyList());
        List<MemoryItem> active=new ArrayList<>(); for(MemoryItem x:engine.list()) if(x.status!=MemoryItem.Status.ARCHIVED) active.add(x);
        int stale=0, duplicates=0, conflicts=0; List<String> candidates=new ArrayList<>();
        Map<String,List<MemoryItem>> groups=new LinkedHashMap<>();
        for(MemoryItem x:active){
            String k=key(x.text); groups.computeIfAbsent(k,z->new ArrayList<>()).add(x);
            if(ageDays(x.updatedAt)>180 && x.importance>=3){ stale++; candidates.add("stale:"+x.id); }
        }
        for(Map.Entry<String,List<MemoryItem>> e:groups.entrySet()) if(e.getValue().size()>1){
            duplicates += e.getValue().size()-1;
            boolean differing=false; for(int i=1;i<e.getValue().size();i++) if(!e.getValue().get(i).text.equalsIgnoreCase(e.getValue().get(0).text)) differing=true;
            if(differing) conflicts++;
            candidates.add((differing?"supersession_or_conflict:":"duplicate:")+e.getKey());
        }
        return new Audit(active.size(),stale,duplicates+conflicts,candidates);
    }
    private static String key(String s){return (s==null?"":s.toLowerCase(Locale.ROOT)).replaceAll("[^a-z0-9 ]"," ").replaceAll("\\s+"," ").trim();}
    private static long ageDays(String s){try{return Math.max(0,(System.currentTimeMillis()-Instant.parse(s).toEpochMilli())/86400000L);}catch(Exception e){return 0;}}
    public static final class Audit{
        public final int activeCount, staleCount, consolidationCandidateCount; public final List<String> candidates;
        public Audit(int a,int s,int c,List<String> x){activeCount=a;staleCount=s;consolidationCandidateCount=c;candidates=Collections.unmodifiableList(new ArrayList<>(x));}
    }
}
