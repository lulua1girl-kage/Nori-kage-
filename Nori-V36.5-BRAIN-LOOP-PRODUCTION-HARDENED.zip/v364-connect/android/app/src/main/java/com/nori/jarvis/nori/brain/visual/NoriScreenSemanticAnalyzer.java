package com.nori.jarvis.nori.brain.visual;

import com.nori.jarvis.nori.ai.*;
import java.util.*;

/** Fast screen-evidence layer. Local decision first; optional vision provider receives the actual frame. */
public final class NoriScreenSemanticAnalyzer {
  public static final class Result { public final String summary,confidence,classification; public Result(String s,String c,String k){summary=s;confidence=c;classification=k;} }
  private final AiRouter router;
  public NoriScreenSemanticAnalyzer(AiRouter r){router=r==null?new AiRouter():r;}
  public Result analyze(String pkg,String trigger,String confidence,String imageBase64,String subject){
    String p=pkg==null?"":pkg.toLowerCase(Locale.ROOT);
    String local="Foreground package="+p+"; trigger="+trigger+"; this is behavioral evidence, not proof of intent.";
    String cls=(p.contains("instagram")||p.contains("pinterest")||p.contains("tiktok")||p.contains("facebook")||p.contains("youtube"))?"DISTRACTION_APP":"UNKNOWN_SCREEN";
    if(imageBase64==null||imageBase64.isEmpty()||!router.remoteEnabled()) return new Result(local,confidence==null?"moderate":confidence,cls);
    Map<String,String> md=new LinkedHashMap<>(); md.put("imageDataUrl","data:image/jpeg;base64,"+imageBase64); md.put("task","exam_screen_semantic_review"); md.put("subject",subject==null?"":subject); md.put("trigger",trigger==null?"":trigger);
    AiRequest req=new AiRequest("Review this exam-mode screen image. Return a short JSON-like classification: visible_app, study_relevance, suspicious_signal, confidence, short_reason. Do not infer identity or intent beyond visible evidence.","You are Nori's evidence analyzer. Treat the image as evidence, not truth. Never claim certainty about student intent.",md,1800);
    AiResponse rr=router.generate(req);
    if(rr.status==AiResponse.Status.SUCCESS) return new Result(rr.text,"provider-reported","VISION_REVIEW");
    return new Result(local,confidence==null?"moderate":confidence,cls);
  }
}
