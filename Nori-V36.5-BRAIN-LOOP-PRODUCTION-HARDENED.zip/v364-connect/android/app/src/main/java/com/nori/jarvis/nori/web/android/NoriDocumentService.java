package com.nori.jarvis.nori.web.android;

import android.content.ContentResolver; import android.content.Context; import android.net.Uri;
import java.io.*; import java.nio.charset.StandardCharsets;

/** Reads user-selected documents through SAF; it does not grant itself storage access. */
public final class NoriDocumentService {
    private final ContentResolver resolver;
    public NoriDocumentService(Context context){resolver=context.getContentResolver();}
    public String readText(Uri uri,int maxChars) throws IOException {
        if(uri==null) throw new IOException("uri_required"); int cap=Math.max(1,Math.min(maxChars,2_000_000));
        try(InputStream in=resolver.openInputStream(uri); Reader r=new InputStreamReader(in,StandardCharsets.UTF_8)){char[] b=new char[8192];StringBuilder s=new StringBuilder();int n;while((n=r.read(b))!=-1){if(s.length()+n>cap){s.append(b,0,cap-s.length());break;}s.append(b,0,n);}return s.toString();}
    }
}
