package com.nori.jarvis.nori.runtime;

import com.nori.jarvis.nori.edgeai.*;
import java.util.*;

/** Chooses an installed edge model using explicit latency, memory, privacy and task constraints. */
public final class NoriModelSelectionEngine {
    public static final class Request { public final NoriOnDeviceTask task; public final boolean multimodal,privacyCritical; public final long latencyBudgetMs,maxBytes; public final int minContext; public Request(NoriOnDeviceTask t,boolean mm,boolean pc,long lb,long mb,int mc){task=t;multimodal=mm;privacyCritical=pc;latencyBudgetMs=lb;maxBytes=mb;minContext=mc;} }
    public static final class Choice { public final boolean available; public final String modelId,backend; public final double score; public final String reason; Choice(boolean a,String id,String b,double s,String r){available=a;modelId=id;backend=b;score=s;reason=r;} }
    private final NoriEdgeAiRegistry registry;
    public NoriModelSelectionEngine(NoriEdgeAiRegistry r){registry=Objects.requireNonNull(r);}
    public Choice choose(Request q){if(q==null||q.task==null)return new Choice(false,"","",0,"invalid_request");List<NoriEdgeModel> ms=registry.candidates(q.task,q.multimodal);NoriEdgeModel best=null;double bs=-Double.MAX_VALUE;for(NoriEdgeModel m:ms){if(q.maxBytes>0&&m.estimatedBytes>q.maxBytes)continue;if(q.minContext>0&&m.contextTokens<q.minContext)continue;double s=100.0;if(q.latencyBudgetMs>0)s-=Math.min(50,m.estimatedBytes/(1024d*1024d*10d));if(q.privacyCritical&&m.backend!=NoriOnDeviceBackend.BUILTIN_DETERMINISTIC)s+=5;if(m.multimodal==q.multimodal)s+=10;if(s>bs){bs=s;best=m;}}if(best==null)return new Choice(false,"","",0,"no_model_meets_constraints");return new Choice(true,best.id,best.backend.name(),bs,"best_installed_model_under_constraints");}
}
