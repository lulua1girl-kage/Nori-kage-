package com.nori.jarvis.nori.web.engine;

import com.nori.jarvis.nori.web.model.WebFetchResult;
import java.io.*; import java.net.*; import java.nio.charset.StandardCharsets; import java.util.*;

/** Controlled educational web boundary. HTTPS only, bounded response, no credential forwarding. */
public final class WebIntelligence {
    private static final int MAX_BYTES=1_500_000;
    public WebFetchResult fetch(String rawUrl){
        if(rawUrl==null||rawUrl.trim().isEmpty()) return new WebFetchResult(WebFetchResult.Status.INVALID_URL,rawUrl,"","empty_url");
        try{
            URI uri=new URI(rawUrl.trim()); String scheme=uri.getScheme();
            if(!"https".equalsIgnoreCase(scheme)) return new WebFetchResult(WebFetchResult.Status.BLOCKED,rawUrl,"","https_only");
            if(uri.getUserInfo()!=null) return new WebFetchResult(WebFetchResult.Status.BLOCKED,rawUrl,"","userinfo_not_allowed");
            HttpURLConnection c=(HttpURLConnection)uri.toURL().openConnection(); c.setConnectTimeout(8000); c.setReadTimeout(10000); c.setInstanceFollowRedirects(false); c.setRequestMethod("GET"); c.setRequestProperty("User-Agent","Nori-Educational-Reader/1.0");
            int code=c.getResponseCode(); if(code>=300&&code<400) return new WebFetchResult(WebFetchResult.Status.BLOCKED,rawUrl,"","redirect_not_followed");
            if(code<200||code>=300) return new WebFetchResult(WebFetchResult.Status.NETWORK_ERROR,rawUrl,"","http_"+code);
            int declared=c.getContentLength(); if(declared>MAX_BYTES) return new WebFetchResult(WebFetchResult.Status.TOO_LARGE,rawUrl,"","response_limit");
            try(InputStream in=c.getInputStream(); ByteArrayOutputStream out=new ByteArrayOutputStream()){byte[] buf=new byte[8192];int n,total=0;while((n=in.read(buf))!=-1){total+=n;if(total>MAX_BYTES)return new WebFetchResult(WebFetchResult.Status.TOO_LARGE,rawUrl,"","response_limit");out.write(buf,0,n);}return new WebFetchResult(WebFetchResult.Status.SUCCESS,rawUrl,new String(out.toByteArray(),StandardCharsets.UTF_8),null);}
        }catch(Exception e){return new WebFetchResult(WebFetchResult.Status.NETWORK_ERROR,rawUrl,"",e.getClass().getSimpleName());}
    }
}
