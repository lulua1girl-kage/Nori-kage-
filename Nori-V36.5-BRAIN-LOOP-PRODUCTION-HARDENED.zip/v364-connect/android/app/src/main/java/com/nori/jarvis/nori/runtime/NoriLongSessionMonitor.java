package com.nori.jarvis.nori.runtime;

import java.util.*;

/** Bounded long-session health model. It tracks drift, latency and failures without retaining chat content. */
public final class NoriLongSessionMonitor {
    public enum Health { HEALTHY, DEGRADED, RESET_RECOMMENDED }
    public static final class Snapshot { public final long sessionMs; public final int requests; public final int failures; public final int consecutiveFailures; public final long p95LatencyMs; public final Health health; Snapshot(long s,int r,int f,int cf,long p,Health h){sessionMs=s;requests=r;failures=f;consecutiveFailures=cf;p95LatencyMs=p;health=h;} }
    private final long started=System.currentTimeMillis(); private final NoriRuntimeTelemetry telemetry; private int requests,failures,consecutiveFailures;
    public NoriLongSessionMonitor(NoriRuntimeTelemetry t){telemetry=t==null?new NoriRuntimeTelemetry():t;}
    public synchronized void request(String op,long latency,boolean ok){requests++;if(!ok){failures++;consecutiveFailures++;}else consecutiveFailures=0;telemetry.record(new NoriRuntimeTelemetry.Sample(op,latency,NoriRuntimeTelemetry.heapUsed(),NoriRuntimeTelemetry.heapMax(),System.currentTimeMillis()-started));}
    public synchronized Snapshot snapshot(){long p=telemetry.p95Latency(null);Health h=(consecutiveFailures>=3||p>15000)?Health.RESET_RECOMMENDED:(failures>0&&p>5000?Health.DEGRADED:Health.HEALTHY);return new Snapshot(System.currentTimeMillis()-started,requests,failures,consecutiveFailures,p,h);}
    public synchronized boolean shouldReset(){return snapshot().health==Health.RESET_RECOMMENDED;}
}
