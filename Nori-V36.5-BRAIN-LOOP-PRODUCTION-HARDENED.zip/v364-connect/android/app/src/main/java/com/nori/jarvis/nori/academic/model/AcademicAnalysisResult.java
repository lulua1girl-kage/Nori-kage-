package com.nori.jarvis.nori.academic.model;

import java.util.Collections;
import java.util.List;

/** Immutable native equivalent of V32 academicEngine.analyzeAssessment(). */
public final class AcademicAnalysisResult {
    public enum ErrorDistribution {
        LOCALIZED_WEAKNESS("localized_weakness"),
        BROAD_ACADEMIC_WEAKNESS("broad_academic_weakness"),
        EXECUTION_ERROR("execution_error"),
        CARELESS_ERROR_PATTERN("careless_error_pattern"),
        UNKNOWN("unknown");

        private final String value;
        ErrorDistribution(String value) { this.value = value; }
        public String value() { return value; }
    }

    private final String type;
    private final double percentage;
    private final String band;
    private final String bandLabel;
    private final ErrorDistribution errorDistribution;
    private final double escalationWeight;
    private final List<String> missedConcepts;
    private final Integer totalConceptsCovered;
    private final Double conceptRatio;

    public AcademicAnalysisResult(
            String type,
            double percentage,
            String band,
            String bandLabel,
            ErrorDistribution errorDistribution,
            double escalationWeight,
            List<String> missedConcepts,
            Integer totalConceptsCovered,
            Double conceptRatio) {
        this.type = type;
        this.percentage = percentage;
        this.band = band;
        this.bandLabel = bandLabel;
        this.errorDistribution = errorDistribution;
        this.escalationWeight = escalationWeight;
        this.missedConcepts = missedConcepts == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(missedConcepts);
        this.totalConceptsCovered = totalConceptsCovered;
        this.conceptRatio = conceptRatio;
    }

    public String getType() { return type; }
    public double getPercentage() { return percentage; }
    public String getBand() { return band; }
    public String getBandLabel() { return bandLabel; }
    public ErrorDistribution getErrorDistribution() { return errorDistribution; }
    public double getEscalationWeight() { return escalationWeight; }
    public List<String> getMissedConcepts() { return missedConcepts; }
    public Integer getTotalConceptsCovered() { return totalConceptsCovered; }
    public Double getConceptRatio() { return conceptRatio; }
}
