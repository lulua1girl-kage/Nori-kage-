package com.nori.jarvis.nori.ai;

import com.nori.jarvis.nori.edgeai.NoriEdgeAiEngine;
import java.util.Locale;
import java.util.regex.*;

/**
 * Deterministic Nori capability layer. It answers bounded requests without an API.
 *
 * Composition is delegated to {@link NoriLocalThinkingEngine} when one is supplied
 * (NoriBrain wires its real memory store in) so a local-only answer is actually
 * shaped by the request and grounded in real recalled data, not a canned line.
 * The no-arg path keeps working with a memory-less thinking engine so every
 * existing caller (including AiRouter's own default constructor) still compiles
 * and still never throws for a missing dependency.
 */
public final class LocalAiProvider implements AiProvider {
    private final NoriEdgeAiEngine edgeAi = new NoriEdgeAiEngine();
    private final NoriLocalThinkingEngine thinking;
    public NoriEdgeAiEngine edgeAi(){ return edgeAi; }
    private static final Pattern PERCENT=Pattern.compile("^\\s*(?:what is )?([0-9]+(?:\\.[0-9]+)?)\\s*%\\s*of\\s*([0-9]+(?:\\.[0-9]+)?)\\s*\\??\\s*$",Pattern.CASE_INSENSITIVE);
    private static final Pattern ADD=Pattern.compile("^\\s*([0-9]+(?:\\.[0-9]+)?)\\s*([+\\-*/])\\s*([0-9]+(?:\\.[0-9]+)?)\\s*\\??\\s*$");

    public LocalAiProvider(){ this(new NoriLocalThinkingEngine(null)); }
    public LocalAiProvider(NoriLocalThinkingEngine thinkingEngine){ this.thinking=thinkingEngine==null?new NoriLocalThinkingEngine(null):thinkingEngine; }

    @Override public String id(){return "local";}
    @Override public boolean isAvailable(){return true;}
    @Override public boolean isRemote(){return false;}
    @Override public AiResponse generate(AiRequest request){
        if(request==null)return AiResponse.error(id(),"request_missing");
        String p=request.prompt.trim(); Matcher m=PERCENT.matcher(p); if(m.matches()){
            double a=Double.parseDouble(m.group(1)), b=Double.parseDouble(m.group(2)); return AiResponse.success(id(),format(a*b/100.0),false);
        }
        m=ADD.matcher(p); if(m.matches()){
            double a=Double.parseDouble(m.group(1)), b=Double.parseDouble(m.group(3)); String op=m.group(2); double v;
            if("+".equals(op))v=a+b; else if("-".equals(op))v=a-b; else if("*".equals(op))v=a*b; else {if(b==0)return AiResponse.error(id(),"division_by_zero");v=a/b;}
            return AiResponse.success(id(),format(v),false);
        }
        String l=p.toLowerCase(Locale.ROOT);
        if(l.contains("status")&&p.length()<120)return AiResponse.success(id(),"Nori local core is operational. On-device AI backends are optional and selected only when installed, permitted, and useful.",false);
        try {
            return AiResponse.success(id(), thinking.compose(request), false);
        } catch (Exception e) {
            // Composition must never crash the router; fall back to an honest, static line.
            return AiResponse.success(id(),"Nori local capability is active. For difficult requests, Nori can use an optional external provider while preserving its own context and rules.",false);
        }
    }
    private static String format(double v){if(v==Math.rint(v))return Long.toString((long)v);return Double.toString(v);}
}
