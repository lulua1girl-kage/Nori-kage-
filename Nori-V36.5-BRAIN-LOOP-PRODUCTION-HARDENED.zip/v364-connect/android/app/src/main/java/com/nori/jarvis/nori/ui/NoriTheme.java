package com.nori.jarvis.nori.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.Space;
import android.widget.TextView;

/** Centralized native visual system for Nori. Monochrome dossier UI with restrained red accents. */
public final class NoriTheme {
    public static final int BG = Color.rgb(12, 12, 12);
    public static final int PANEL = Color.rgb(22, 22, 22);
    public static final int PANEL_ALT = Color.rgb(28, 28, 28);
    public static final int BORDER = Color.rgb(62, 62, 62);
    public static final int TEXT = Color.rgb(242, 242, 242);
    public static final int MUTED = Color.rgb(158, 158, 158);
    public static final int ACCENT = Color.rgb(185, 45, 45);

    private NoriTheme() {}

    public static GradientDrawable background(int color, float radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(radius);
        d.setStroke(1, BORDER);
        return d;
    }

    public static LinearLayout page(Context c) {
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(c, 16), dp(c, 12), dp(c, 16), dp(c, 20));
        root.setBackgroundColor(BG);
        return root;
    }

    public static TextView title(Context c, String text) {
        TextView v = new TextView(c);
        v.setText(text);
        v.setTextColor(TEXT);
        v.setTextSize(28);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(dp(c, 2), dp(c, 8), dp(c, 2), dp(c, 2));
        return v;
    }

    public static TextView eyebrow(Context c, String text) {
        TextView v = new TextView(c);
        v.setText(text.toUpperCase());
        v.setTextColor(ACCENT);
        v.setTextSize(11);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setLetterSpacing(.12f);
        v.setPadding(dp(c, 2), dp(c, 6), dp(c, 2), 0);
        return v;
    }

    public static TextView body(Context c, String text) {
        TextView v = new TextView(c);
        v.setText(text);
        v.setTextColor(MUTED);
        v.setTextSize(15);
        v.setLineSpacing(0, 1.12f);
        v.setPadding(dp(c, 2), dp(c, 6), dp(c, 2), dp(c, 6));
        return v;
    }

    public static TextView metric(Context c, String value, String label) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        box.setBackground(background(PANEL, 0));
        TextView number = new TextView(c);
        number.setText(value);
        number.setTextColor(TEXT);
        number.setTextSize(21);
        number.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        TextView name = body(c, label.toUpperCase());
        name.setTextSize(10);
        box.addView(number);
        box.addView(name);
        return box;
    }

    public static LinearLayout card(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(c, 14), dp(c, 12), dp(c, 14), dp(c, 12));
        card.setBackground(background(PANEL, 0));
        card.setElevation(dp(c, 2));
        return card;
    }

    public static TextView cardTitle(Context c, String text) {
        TextView v = title(c, text);
        v.setTextSize(17);
        v.setPadding(0, 0, 0, dp(c, 4));
        return v;
    }

    public static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(BORDER);
        return v;
    }

    public static Space spacer(Context c, int height) {
        Space s = new Space(c);
        s.setLayoutParams(new LinearLayout.LayoutParams(1, dp(c, height)));
        return s;
    }

    public static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }
}
