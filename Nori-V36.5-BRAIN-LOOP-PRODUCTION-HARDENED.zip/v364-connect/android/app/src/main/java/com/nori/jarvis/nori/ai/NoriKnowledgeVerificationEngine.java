package com.nori.jarvis.nori.ai;

import java.net.URI;
import java.util.*;

/** Verification layer for generated knowledge. It never treats model agreement as proof. */
public final class NoriKnowledgeVerificationEngine {
    public enum Status { VERIFIED, PARTIALLY_VERIFIED, UNVERIFIED, CONFLICTING }
    public static final class SourceCheck {
        public final String sourceId, url; public final boolean usable, current; public final double authority;
        public SourceCheck(String id,String u,boolean usable,boolean current,double authority){sourceId=id;url=u;this.usable=usable;this.current=current;this.authority=clamp(authority);}
    }
    public static final class ClaimCheck {
        public final String claim; public final Status status; public final double confidence; public final List<String> reasons;
        public ClaimCheck(String c,Status s,double conf,List<String> r){claim=c;status=s;confidence=clamp(conf);reasons=Collections.unmodifiableList(new ArrayList<>(r));}
    }
    public static final class Conflict { public final String topic; public final List<String> statements; public final String resolution;
        public Conflict(String t,List<String>s,String r){topic=t;statements=Collections.unmodifiableList(new ArrayList<>(s));resolution=r;}}
    public static final class Report {
        public final Status status; public final double confidence; public final List<ClaimCheck> claims; public final List<Conflict> conflicts; public final List<String> warnings;
        Report(Status s,double c,List<ClaimCheck> cc,List<Conflict> x,List<String>w){status=s;confidence=clamp(c);claims=Collections.unmodifiableList(new ArrayList<>(cc));conflicts=Collections.unmodifiableList(new ArrayList<>(x));warnings=Collections.unmodifiableList(new ArrayList<>(w));}
    }
    public SourceCheck verifySource(String id,String url,double authority,boolean current){
        boolean usable=url!=null&&!url.trim().isEmpty(); if(usable){try{URI.create(url); }catch(Exception e){usable=false;}}
        return new SourceCheck(id,url,usable,current,authority);
    }
    public Report verifyClaims(List<String> claims,List<SourceCheck> sources){
        List<ClaimCheck> out=new ArrayList<>(); List<String>w=new ArrayList<>(); int verified=0, conflict=0;
        int usable=0; if(sources!=null)for(SourceCheck s:sources)if(s!=null&&s.usable)usable++;
        if(usable==0)w.add("no_verifiable_sources");
        if(claims!=null)for(String c:claims){if(c==null||c.trim().isEmpty())continue;String x=c.toLowerCase(Locale.ROOT);List<String> rs=new ArrayList<>();
            boolean absolute=x.matches(".*\\b(always|never|certainly|proven|guaranteed|definitely)\\b.*");
            boolean causal=x.contains("caused")||x.contains("causes")||x.contains("because");
            if(usable>=2&&!absolute&&!causal){out.add(new ClaimCheck(c,Status.PARTIALLY_VERIFIED,.62,Arrays.asList("multiple_sources_available","claim_requires_source_level_check")));}
            else if(usable>=1&&!absolute){out.add(new ClaimCheck(c,Status.UNVERIFIED,.45,Arrays.asList("source_presence_is_not_claim_verification")));}
            else {rs.add(absolute?"absolute_language_requires_stronger_evidence":"insufficient_source_evidence");out.add(new ClaimCheck(c,Status.UNVERIFIED,.25,rs));}
        }
        for(ClaimCheck c:out)if(c.status==Status.VERIFIED)verified++;
        double conf=out.isEmpty()?0:(usable>=2?.60:.35); Status st=out.isEmpty()?Status.UNVERIFIED:(conf>=.75?Status.VERIFIED:(conf>=.45?Status.PARTIALLY_VERIFIED:Status.UNVERIFIED));
        return new Report(st,conf,out,Collections.emptyList(),w);
    }
    public Report resolveConflicts(List<String> statements){
        Map<String,List<String>> groups=new LinkedHashMap<>(); if(statements!=null)for(String s:statements){if(s==null||s.trim().isEmpty())continue;String k=topic(s);groups.computeIfAbsent(k,z->new ArrayList<>()).add(s);}
        List<Conflict> cs=new ArrayList<>(); for(Map.Entry<String,List<String>> e:groups.entrySet())if(e.getValue().size()>1){cs.add(new Conflict(e.getKey(),e.getValue(),"preserve_competing_claims_until_authority_or_newer_evidence_resolves_them"));}
        return new Report(cs.isEmpty()?Status.PARTIALLY_VERIFIED:Status.CONFLICTING,cs.isEmpty()?.50:.20,Collections.emptyList(),cs,cs.isEmpty()?Collections.emptyList():Collections.singletonList("knowledge_conflict_detected"));
    }
    public boolean likelyHallucination(String text){
        if(text==null||text.trim().isEmpty())return true; String x=text.toLowerCase(Locale.ROOT);
        return x.matches(".*\\b(as an ai|i checked|i verified|according to a source)\\b.*") && !x.contains("cannot verify") || x.contains("http://")&&x.contains("example.com");
    }
    private static String topic(String s){String x=s.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]"," ").trim();String[] p=x.split("\\s+");return p.length==0?x:p[0];}
    private static double clamp(double x){return Math.max(0,Math.min(1,x));}
}
