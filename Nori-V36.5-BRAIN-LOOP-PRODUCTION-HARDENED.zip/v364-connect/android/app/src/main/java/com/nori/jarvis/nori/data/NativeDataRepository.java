package com.nori.jarvis.nori.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import com.nori.jarvis.nori.security.InputValidator;

/**
 * Generic native repository used during the V32 -> Java migration.
 * Values remain JSON strings so no V32 information is lost by premature
 * model conversion. Higher-level engines can introduce typed models later.
 */
public final class NativeDataRepository implements DataRepository, AutoCloseable {
    private final NoriDatabase database;

    public NativeDataRepository(Context context) {
        database = new NoriDatabase(context);
    }

    public boolean putJson(String key, String valueJson, String category, int schemaVersion) {
        if (!InputValidator.key(key) || !InputValidator.storedValue(valueJson)) return false;
        ContentValues values = new ContentValues();
        values.put("key", key);
        values.put("value_json", valueJson);
        String safeCategory = category == null ? "general" : category.trim();
        if (safeCategory.length() > 128) return false;
        values.put("category", safeCategory);
        if (schemaVersion < 1) return false;
        values.put("schema_version", schemaVersion);
        values.put("updated_at", System.currentTimeMillis());
        return database.getWritableDatabase().insertWithOnConflict(
                "nori_store", null, values, SQLiteDatabase.CONFLICT_REPLACE) != -1;
    }

    public String getJson(String key) {
        if (key == null) return null;
        try (Cursor cursor = database.getReadableDatabase().query(
                "nori_store", new String[]{"value_json"}, "key = ?",
                new String[]{key}, null, null, null)) {
            return cursor.moveToFirst() ? cursor.getString(0) : null;
        }
    }

    public boolean contains(String key) {
        return getJson(key) != null;
    }

    public boolean delete(String key) {
        if (key == null) return false;
        return database.getWritableDatabase().delete(
                "nori_store", "key = ?", new String[]{key}) > 0;
    }

    public List<String> keys() {
        ArrayList<String> result = new ArrayList<>();
        try (Cursor cursor = database.getReadableDatabase().query(
                "nori_store", new String[]{"key"}, null, null,
                null, null, "key ASC")) {
            while (cursor.moveToNext()) result.add(cursor.getString(0));
        }
        return Collections.unmodifiableList(result);
    }

    public int count() {
        try (Cursor cursor = database.rawQuery("SELECT COUNT(*) FROM nori_store", null)) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }

    @Override
    public void close() {
        database.close();
    }
}
