package com.nori.jarvis.nori.brain.learning;

import java.time.*; import java.util.*;

/** Capability-development model: tracks goals, behaviors and self-reliance without scoring human worth. */
public final class NoriStudentDevelopment {
    public enum Capability { KNOWLEDGE, PROBLEM_SOLVING, PLANNING, CONSISTENCY, SELF_CORRECTION, SELF_RELIANCE, ADAPTABILITY }
    public static final class Goal { public final String id,title,domain; public final double progress; public final String status; public Goal(String i,String t,String d,double p,String s){id=i;title=t;domain=d;progress=clamp(p);status=s==null?"ACTIVE":s;} }
    public static final class Observation { public final String capability; public final double value; public final String evidence; public final Instant at; public Observation(String c,double v,String e){capability=c;value=clamp(v);evidence=e==null?"":e;at=Instant.now();} }
    public static final class DevelopmentReport { public final Map<String,Double> capabilityLevels; public final double selfReliance; public final List<String> strategyChanges; public final List<String> experiments; DevelopmentReport(Map<String,Double> c,double s,List<String>x,List<String>e){capabilityLevels=Collections.unmodifiableMap(new LinkedHashMap<>(c));selfReliance=s;strategyChanges=Collections.unmodifiableList(new ArrayList<>(x));experiments=Collections.unmodifiableList(new ArrayList<>(e));} }
    private final Map<String,Goal> goals=new LinkedHashMap<>(); private final List<Observation> observations=new ArrayList<>();
    public synchronized void upsertGoal(Goal g){if(g!=null&&g.id!=null&&!g.id.isEmpty())goals.put(g.id,g);}
    public synchronized List<Goal> goals(){return Collections.unmodifiableList(new ArrayList<>(goals.values()));}
    public synchronized void observe(Capability c,double value,String evidence){if(c!=null)observations.add(new Observation(c.name(),value,evidence)); if(observations.size()>1000)observations.remove(0);}
    public synchronized DevelopmentReport assess(){
        Map<String,List<Observation>> by=new LinkedHashMap<>(); for(Observation o:observations)by.computeIfAbsent(o.capability,k->new ArrayList<>()).add(o);
        Map<String,Double> levels=new LinkedHashMap<>(); for(Capability c:Capability.values()){List<Observation>a=by.get(c.name());levels.put(c.name(),a==null||a.isEmpty()?0:avg(a));}
        double sr=levels.get(Capability.SELF_RELIANCE.name()); List<String> changes=new ArrayList<>(); List<String> ex=new ArrayList<>();
        if(levels.get(Capability.SELF_CORRECTION.name())<.5)changes.add("increase deliberate self-correction after mistakes");
        if(levels.get(Capability.PLANNING.name())<.5)changes.add("practice planning with bounded independent decisions");
        if(levels.get(Capability.ADAPTABILITY.name())<.5)changes.add("run small strategy experiments and compare outcomes");
        ex.add("change_one_study_variable_then_measure_outcome"); ex.add("attempt_before_requesting_help_when_safe");
        return new DevelopmentReport(levels,sr,changes,ex);
    }
    public synchronized String strategyForCurrentEvidence(){DevelopmentReport r=assess();if(r.selfReliance<.4)return "scaffold_then_gradually_remove_support";if(r.selfReliance>.75)return "increase_independent_planning_and_review";return "maintain_support_while_increasing_independent_decisions";}
    private static double avg(List<Observation>a){double x=0;for(Observation o:a)x+=o.value;return x/a.size();} private static double clamp(double x){return Double.isFinite(x)?Math.max(0,Math.min(1,x)):0;}
}
