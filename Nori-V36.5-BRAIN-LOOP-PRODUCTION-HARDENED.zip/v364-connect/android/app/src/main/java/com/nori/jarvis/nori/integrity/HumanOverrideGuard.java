package com.nori.jarvis.nori.integrity;

import java.util.*;

/** Bounded Human Override assessment. Override changes the plan; it is not a deletion of reality. */
public final class HumanOverrideGuard {
    public enum Level { MONITOR, LOW, MEDIUM, HIGH, CRITICAL, REVIEW }
    public enum Action { NO_CHANGE, SMALL_ADJUSTMENT, REDUCE_AND_EXTEND, PAUSE, REVIEW }
    public static final Set<String> CATEGORIES = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        "family_responsibility","social_conflict","exhaustion","bad_day","comparison","temporary_collapse",
        "missed_day","overwhelming_circumstances","motivation_loss","serious_unsafe_situation"
    )));
    public Assessment assess(String category,int importance,int weakness,int difficulty,int immediacy,int evidence,int impact,int repeatCount){
        if(category==null || !CATEGORIES.contains(category)) return new Assessment(Level.MONITOR,Action.NO_CHANGE,0,"unrecognized_circumstance");
        double score=(clamp(importance)*clamp(weakness)*clamp(difficulty)*clamp(immediacy))*(0.5+clamp(evidence)/5.0)*(0.75+clamp(impact)/10.0);
        Level level=score>=250?Level.CRITICAL:score>=120?Level.HIGH:score>=40?Level.MEDIUM:score>=1?Level.LOW:Level.MONITOR;
        Action action=level==Level.CRITICAL?Action.PAUSE:level==Level.HIGH?Action.REDUCE_AND_EXTEND:level==Level.MEDIUM?Action.REDUCE_AND_EXTEND:level==Level.LOW?Action.SMALL_ADJUSTMENT:Action.NO_CHANGE;
        if(repeatCount>=3 && level!=Level.CRITICAL) { level=Level.REVIEW; action=Action.REVIEW; }
        return new Assessment(level,action,score,repeatCount>=3?"repeated_override_pattern_requires_honest_review":"proportional_override");
    }
    private static int clamp(int x){return Math.max(0,Math.min(10,x));}
    public static final class Assessment { public final Level level; public final Action action; public final double score; public final String reason; Assessment(Level l,Action a,double s,String r){level=l;action=a;score=s;reason=r;} }
}
