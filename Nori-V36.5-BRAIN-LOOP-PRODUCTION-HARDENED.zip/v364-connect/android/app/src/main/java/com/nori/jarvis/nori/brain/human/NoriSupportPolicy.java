package com.nori.jarvis.nori.brain.human;

import java.util.*;

/** Converts context into respectful behavior. It avoids unnecessary probing and preserves autonomy. */
public final class NoriSupportPolicy {
    public enum Mode { PUSH, NORMAL, LIGHTEN, STABILIZE, SAFETY }
    public static final class Guidance {
        public final Mode mode; public final boolean askOptionalQuestion; public final boolean avoidInterrogation;
        public final String strategy; public final List<String> principles;
        public Guidance(Mode mode, boolean ask, boolean avoid, String strategy, List<String> principles){
            this.mode=mode; this.askOptionalQuestion=ask; this.avoidInterrogation=avoid; this.strategy=strategy;
            this.principles=Collections.unmodifiableList(new ArrayList<>(principles));
        }
    }
    public Guidance decide(HumanContextEngine.Assessment a, boolean userAskedForAnalysis) {
        if(a==null) return new Guidance(Mode.NORMAL,false,true,"help_with_the_next_clear_step",Collections.singletonList("do_not_invent_context"));
        switch(a.support){
            case SAFETY_FIRST:
                return new Guidance(Mode.SAFETY,false,true,"prioritize_immediate_safety_and_human_support_without_demanding_disclosure",Arrays.asList("no_diagnosis","no_interrogation","preserve_agency"));
            case STABILIZE:
                return new Guidance(Mode.STABILIZE,false,true,"reduce_load_and_make_the_next_step_manageable",Arrays.asList("do_not_moralize","do_not_assume_cause","protect_rest_and_basic_needs"));
            case LIGHTEN_LOAD:
                return new Guidance(Mode.LIGHTEN,false,true,"shrink_the_starting_step_and_offer_choices",Arrays.asList("small_action","choice_not_command","observe_pattern_over_time"));
            case NORMAL:
            default:
                return new Guidance(a.difficulty==HumanContextEngine.Difficulty.AVOIDANCE_PATTERN?Mode.PUSH:Mode.NORMAL,
                        userAskedForAnalysis,false,"match_challenge_to_evidence_and_capacity",Arrays.asList("strict_on_goals_flexible_on_route","avoid_shame","do_not_label_person"));
        }
    }
}
