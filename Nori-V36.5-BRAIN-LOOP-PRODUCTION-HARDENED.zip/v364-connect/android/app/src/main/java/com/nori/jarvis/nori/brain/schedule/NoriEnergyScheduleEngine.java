package com.nori.jarvis.nori.brain.schedule;

import java.time.*; import java.util.*;

/** Self-reported energy scheduling. It never infers energy from surveillance or device use. */
public final class NoriEnergyScheduleEngine {
    public enum Energy { LOW, MEDIUM, HIGH }
    public static final class CheckIn { public final DayOfWeek day; public final int hour; public final Energy energy; public final String note; public final Instant at;
        public CheckIn(DayOfWeek d,int h,Energy e,String n){day=d;hour=Math.max(0,Math.min(23,h));energy=e==null?Energy.MEDIUM:e;note=n==null?"":n;at=Instant.now();}}
    public static final class Window { public final DayOfWeek day; public final int startHour,endHour; public final Energy energy; public final String useFor;
        Window(DayOfWeek d,int s,int e,Energy x,String u){day=d;startHour=s;endHour=e;energy=x;useFor=u;}}
    private final List<CheckIn> checkIns=new ArrayList<>();
    public synchronized void recordCheckIn(DayOfWeek day,int hour,Energy energy,String note){checkIns.add(new CheckIn(day,hour,energy,note));if(checkIns.size()>1000)checkIns.remove(0);}
    public synchronized Energy energyAt(DayOfWeek day,int hour){int low=0,med=0,high=0;for(CheckIn c:checkIns)if(c.day==day&&Math.abs(c.hour-hour)<=1){if(c.energy==Energy.HIGH)high++;else if(c.energy==Energy.LOW)low++;else med++;}return high>=Math.max(med,low)&&high>0?Energy.HIGH:low>Math.max(high,med)?Energy.LOW:Energy.MEDIUM;}
    public synchronized List<Window> recommendWindows(){Map<String,List<CheckIn>> by=new LinkedHashMap<>();for(CheckIn c:checkIns)by.computeIfAbsent(c.day.name(),k->new ArrayList<>()).add(c);List<Window>w=new ArrayList<>();for(DayOfWeek d:DayOfWeek.values()){List<CheckIn>a=by.getOrDefault(d.name(),Collections.emptyList());if(a.isEmpty())continue;a.sort((x,y)->Integer.compare(y.energy.ordinal(),x.energy.ordinal()));CheckIn best=a.get(0);w.add(new Window(d,best.hour,Math.min(23,best.hour+2),best.energy,best.energy==Energy.HIGH?"hard/new material":best.energy==Energy.MEDIUM?"normal practice":"light review/admin"));}return Collections.unmodifiableList(w);}
    public synchronized List<CheckIn> checkIns(){return Collections.unmodifiableList(new ArrayList<>(checkIns));}
}
