package com.nori.jarvis.nori.advanced.model;

import java.util.*;

/** Explainable advanced-intelligence result. Facts and inferences stay separate. */
public final class AdvancedInsight {
    public final String subject;
    public final String status;
    public final double confidence;
    public final List<String> facts;
    public final List<String> inferences;
    public final List<String> actions;
    public final List<String> warnings;
    public AdvancedInsight(String subject,String status,double confidence,List<String> facts,List<String> inferences,List<String> actions,List<String> warnings){
        this.subject=subject; this.status=status; this.confidence=Math.max(0,Math.min(1,confidence));
        this.facts=unmod(facts); this.inferences=unmod(inferences); this.actions=unmod(actions); this.warnings=unmod(warnings);
    }
    private static List<String> unmod(List<String> x){return Collections.unmodifiableList(new ArrayList<>(x==null?Collections.emptyList():x));}
}
