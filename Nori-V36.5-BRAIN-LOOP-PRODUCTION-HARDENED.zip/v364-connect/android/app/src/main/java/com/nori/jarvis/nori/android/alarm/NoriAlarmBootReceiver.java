package com.nori.jarvis.nori.android.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Boot/time-change hook. Scheduling data is intentionally not fabricated here.
 * The web/native scheduler should call its authoritative reschedule routine when
 * the application next initializes. This receiver only marks that rescheduling
 * is required.
 */
public final class NoriAlarmBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        context.getSharedPreferences("nori_alarm_state", Context.MODE_PRIVATE)
            .edit().putBoolean("reschedule_required", true).apply();
    }
}
