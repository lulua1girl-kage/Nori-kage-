package com.nori.jarvis.nori.academic;

import com.nori.jarvis.nori.academic.model.AcademicAnalysisResult;
import com.nori.jarvis.nori.academic.model.Assessment;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Native migration of V32 brain-engine/engines/academicEngine.js.
 *
 * This engine answers one narrow question: what an assessment result means.
 * It does not decide discipline, consequences, recovery, or awards.
 * Those remain separate engines so a low score cannot directly become a
 * disciplinary action.
 */
public final class AcademicEngine {
    public static final List<String> ASSESSMENT_TYPES = Collections.unmodifiableList(Arrays.asList(
            "practice", "assignment", "quiz", "weekly_assessment",
            "unit_test", "mock_examination", "final_examination"
    ));

    public static final class ScoreBand {
        private final String id;
        private final double min;
        private final double max;
        private final String label;

        private ScoreBand(String id, double min, double max, String label) {
            this.id = id;
            this.min = min;
            this.max = max;
            this.label = label;
        }

        public String getId() { return id; }
        public double getMin() { return min; }
        public double getMax() { return max; }
        public String getLabel() { return label; }
    }

    public static final List<ScoreBand> SCORE_BANDS = Collections.unmodifiableList(Arrays.asList(
            new ScoreBand("D1-A", 76, 79, "Near target / minor underperformance"),
            new ScoreBand("D1-B", 71, 75, "Clear underperformance"),
            new ScoreBand("D1-C", 66, 70, "Significant underperformance"),
            new ScoreBand("D1-D", 51, 65, "Major underperformance"),
            new ScoreBand("D1-E", 0, 50, "Critical Degree 1 result")
    ));

    private static final Map<String, Double> WEIGHTS;
    static {
        Map<String, Double> weights = new LinkedHashMap<>();
        weights.put("practice", 0.2);
        weights.put("assignment", 0.4);
        weights.put("quiz", 0.5);
        weights.put("weekly_assessment", 0.6);
        weights.put("unit_test", 0.8);
        weights.put("mock_examination", 0.9);
        weights.put("final_examination", 1.0);
        WEIGHTS = Collections.unmodifiableMap(weights);
    }

    /** Returns null when the score is 80+ and therefore outside D1 territory. */
    public ScoreBand getScoreBand(double percentage) {
        if (percentage >= 80) return null;
        for (ScoreBand band : SCORE_BANDS) {
            if (percentage >= band.min && percentage <= band.max) return band;
        }
        return null;
    }

    public boolean isSupportedAssessmentType(String type) {
        return type != null && ASSESSMENT_TYPES.contains(type);
    }

    public double getEscalationWeight(String type) {
        Double weight = WEIGHTS.get(type);
        return weight == null ? 0.5 : weight;
    }

    /** Exact native counterpart of V32 analyzeAssessment(). */
    public AcademicAnalysisResult analyzeAssessment(Assessment assessment) {
        if (assessment == null) throw new IllegalArgumentException("Assessment is required");
        if (!isSupportedAssessmentType(assessment.getType())) {
            throw new IllegalArgumentException("Unknown assessment type: " + assessment.getType());
        }

        ScoreBand band = getScoreBand(assessment.getPercentage());
        List<String> missed = assessment.getMissedConcepts();
        int missedCount = missed.size();

        Double conceptRatio = assessment.getTotalConceptsCovered() != 0
                ? (double) missedCount / assessment.getTotalConceptsCovered()
                : null;

        AcademicAnalysisResult.ErrorDistribution distribution =
                AcademicAnalysisResult.ErrorDistribution.UNKNOWN;

        if (conceptRatio != null) {
            if (assessment.getCarelessErrorCount() > missedCount) {
                distribution = AcademicAnalysisResult.ErrorDistribution.CARELESS_ERROR_PATTERN;
            } else if (assessment.getApplicationErrorCount() > missedCount) {
                distribution = AcademicAnalysisResult.ErrorDistribution.EXECUTION_ERROR;
            } else if (conceptRatio <= 0.3) {
                distribution = AcademicAnalysisResult.ErrorDistribution.LOCALIZED_WEAKNESS;
            } else {
                distribution = AcademicAnalysisResult.ErrorDistribution.BROAD_ACADEMIC_WEAKNESS;
            }
        }

        return new AcademicAnalysisResult(
                assessment.getType(),
                assessment.getPercentage(),
                band == null ? null : band.id,
                band == null ? "Above Degree 1 threshold" : band.label,
                distribution,
                getEscalationWeight(assessment.getType()),
                missed,
                assessment.getTotalConceptsCovered() == 0 ? null : assessment.getTotalConceptsCovered(),
                conceptRatio
        );
    }
}
