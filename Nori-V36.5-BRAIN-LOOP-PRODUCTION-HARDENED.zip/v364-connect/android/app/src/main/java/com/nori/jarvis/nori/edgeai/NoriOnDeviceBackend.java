package com.nori.jarvis.nori.edgeai;

/** Supported on-device AI runtime families. Optional integrations never replace Nori's Brain. */
public enum NoriOnDeviceBackend {
    BUILTIN_DETERMINISTIC,
    ML_KIT_GENAI,
    MEDIAPIPE_LLM,
    LITERT,
    ONNX_RUNTIME_MOBILE,
    LLAMA_CPP,
    MLC_LLM
}
