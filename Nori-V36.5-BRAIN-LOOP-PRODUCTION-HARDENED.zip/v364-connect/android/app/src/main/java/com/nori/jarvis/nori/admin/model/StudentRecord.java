package com.nori.jarvis.nori.admin.model;

public final class StudentRecord {
    public final String studentId, displayName, email, backupEmail;
    public final int age;
    public final boolean active, emailVerified, backupVerified;
    public final long createdAt;
    public StudentRecord(String studentId,String displayName,String email,boolean active,long createdAt){this(studentId,displayName,email,"",0,active,false,false,createdAt);}
    public StudentRecord(String studentId,String displayName,String email,String backupEmail,int age,boolean active,boolean emailVerified,boolean backupVerified,long createdAt){
        this.studentId=studentId;this.displayName=displayName;this.email=email;this.backupEmail=backupEmail;this.age=age;this.active=active;this.emailVerified=emailVerified;this.backupVerified=backupVerified;this.createdAt=createdAt;
    }
}
