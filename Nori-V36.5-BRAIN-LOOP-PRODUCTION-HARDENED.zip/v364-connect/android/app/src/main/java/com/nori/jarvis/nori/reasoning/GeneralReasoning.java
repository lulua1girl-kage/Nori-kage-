package com.nori.jarvis.nori.reasoning;

import java.util.*;

/** General evidence -> interpretation -> confidence -> decision reasoning boundary. */
public final class GeneralReasoning {
    public enum Interpretation { SUPPORTED, PLAUSIBLE, CONFLICTED, UNDERDETERMINED }
    public enum CausalStatus { NONE, CORRELATION_ONLY, PLAUSIBLE_CAUSE, SUPPORTED_CAUSE, UNKNOWN }
    public enum TemporalStatus { STABLE, CHANGING, STALE, ORDER_UNKNOWN }
    public static final class Hypothesis {
        public final String id, statement; public final double support; public final boolean selected;
        public Hypothesis(String id,String statement,double support,boolean selected){this.id=id;this.statement=statement;this.support=Math.max(0,Math.min(1,support));this.selected=selected;}
    }
    public static final class Result {
        public final Interpretation interpretation; public final CausalStatus causalStatus; public final TemporalStatus temporalStatus;
        public final double confidence; public final boolean conflict; public final boolean needsEvidence; public final boolean needsClarification;
        public final List<String> assumptions, unresolvedQuestions, decisionChecks; public final List<Hypothesis> hypotheses;
        public final String decision;
        Result(Interpretation i,CausalStatus c,TemporalStatus t,double conf,boolean conflict,boolean evidence,boolean clarify,List<String>a,List<String>q,List<String>checks,List<Hypothesis>h,String d){
            interpretation=i;causalStatus=c;temporalStatus=t;confidence=conf;this.conflict=conflict;needsEvidence=evidence;needsClarification=clarify;
            assumptions=Collections.unmodifiableList(new ArrayList<>(a));unresolvedQuestions=Collections.unmodifiableList(new ArrayList<>(q));decisionChecks=Collections.unmodifiableList(new ArrayList<>(checks));hypotheses=Collections.unmodifiableList(new ArrayList<>(h));decision=d;
        }
    }
    public Result reason(List<Evidence> input, String requestedDecision, String temporalHint){
        List<Evidence> es=input==null?Collections.emptyList():input; int strong=0, usable=0, inferred=0, assumptionsN=0; boolean conflict=false, causal=false;
        Set<String> statements=new HashSet<>(); List<String> assumptions=new ArrayList<>();
        for(Evidence e:es){
            if(e==null)continue; if(e.kind==Evidence.Kind.FACT||e.kind==Evidence.Kind.CONTEXT){usable++;if(e.strength==Evidence.Strength.STRONG)strong++;}
            if(e.kind==Evidence.Kind.INFERENCE)inferred++; if(e.kind==Evidence.Kind.ASSUMPTION){assumptionsN++;assumptions.add(e.statement);}
            String normalized=e.statement.toLowerCase(Locale.ROOT); if(normalized.contains("caused")||normalized.contains("because"))causal=true;
            if(!statements.add(normalized) && e.kind==Evidence.Kind.FACT) conflict=true;
        }
        // Explicitly conflicting polarity is a conflict signal, not a verdict.
        for(Evidence e:es) if(e!=null && e.statement!=null){String x=e.statement.toLowerCase(Locale.ROOT);if((x.contains("true")&&x.contains("false"))||(x.contains("yes")&&x.contains("no")))conflict=true;}
        double conf=Math.min(1.0,(usable*0.16)+(strong*0.16)+(inferred*0.06)-(assumptionsN*0.08)-(conflict?0.20:0));
        if(es.isEmpty())conf=0; Interpretation interpretation=conflict?Interpretation.CONFLICTED:(conf>=.70?Interpretation.SUPPORTED:(conf>=.35?Interpretation.PLAUSIBLE:Interpretation.UNDERDETERMINED));
        CausalStatus cs=causal?(strong>=2?CausalStatus.SUPPORTED_CAUSE:CausalStatus.PLAUSIBLE_CAUSE):CausalStatus.UNKNOWN;
        String th=temporalHint==null?"":temporalHint.toLowerCase(Locale.ROOT); TemporalStatus ts=th.contains("stale")?TemporalStatus.STALE:(th.contains("changing")||th.contains("changed")?TemporalStatus.CHANGING:(th.contains("stable")?TemporalStatus.STABLE:TemporalStatus.ORDER_UNKNOWN));
        boolean needsEvidence=conf<.70||conflict; boolean clarify=usable==0;
        List<String> q=new ArrayList<>(); if(needsEvidence)q.add("What missing evidence would materially change the conclusion?"); if(conflict)q.add("Which source is newer or more authoritative?"); if(clarify)q.add("What outcome is the user actually asking for?"); if(ts==TemporalStatus.STALE)q.add("Is the information still current?");
        List<String> checks=new ArrayList<>(Arrays.asList("separate facts from interpretations","test important assumptions","check contradictory evidence","verify the decision against the requested outcome"));
        List<Hypothesis> hs=new ArrayList<>(); hs.add(new Hypothesis("H1","available evidence supports the requested interpretation",Math.max(0,conf),!conflict&&conf>=.70)); if(conflict||conf<.70)hs.add(new Hypothesis("H2","available evidence is insufficient or another interpretation remains plausible",1-Math.max(0,conf),conflict||conf<.70));
        return new Result(interpretation,cs,ts,conf,conflict,needsEvidence,clarify,assumptions,q,checks,hs,requestedDecision==null?"":requestedDecision);
    }
}
