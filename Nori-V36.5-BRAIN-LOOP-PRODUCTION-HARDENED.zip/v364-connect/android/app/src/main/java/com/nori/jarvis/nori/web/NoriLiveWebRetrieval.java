package com.nori.jarvis.nori.web;

import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;

/** Bounded live HTTPS retrieval primitive. It returns provenance and never claims freshness without a successful fetch. */
public final class NoriLiveWebRetrieval {
    public static final class Result { public final boolean ok; public final int status; public final String url,body,error; public final long retrievedAt,latencyMs; Result(boolean o,int s,String u,String b,String e,long t,long l){ok=o;status=s;url=u;body=b;error=e;retrievedAt=t;latencyMs=l;} }
    public Result get(String url,int timeoutMs,int maxBytes)throws IOException{long st=System.currentTimeMillis();if(url==null||!url.startsWith("https://"))return new Result(false,0,url,"","https_required",System.currentTimeMillis(),0);HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod("GET");c.setConnectTimeout(Math.max(1000,timeoutMs));c.setReadTimeout(Math.max(1000,timeoutMs));c.setRequestProperty("Accept","text/plain,application/json,text/xml,*/*");int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();String body="";if(in!=null){ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n,total=0;while((n=in.read(buf))!=-1&&total<maxBytes){int take=Math.min(n,maxBytes-total);out.write(buf,0,take);total+=take;if(total>=maxBytes)break;}body=out.toString(StandardCharsets.UTF_8.name());in.close();}long now=System.currentTimeMillis();return new Result(code>=200&&code<300,code,url,body,code>=400?"http_error":"",now,now-st);}
}
