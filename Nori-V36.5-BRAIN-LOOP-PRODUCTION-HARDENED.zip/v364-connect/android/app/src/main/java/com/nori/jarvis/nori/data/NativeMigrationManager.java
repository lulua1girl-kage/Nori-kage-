package com.nori.jarvis.nori.data;

import android.content.Context;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Stage 4 migration coordinator.
 *
 * Guarantees:
 *  - validate before import
 *  - never deletes V32 data
 *  - never overwrites native records by default
 *  - records a migration report
 *  - can create a JSON backup of the native store
 *
 * This class does not make the native store authoritative yet. That happens
 * only after equivalence testing in a later stage.
 */
public final class NativeMigrationManager implements AutoCloseable {
    private final NativeDataRepository repository;

    public NativeMigrationManager(Context context) {
        repository = new NativeDataRepository(context);
    }

    public MigrationResult migrateV32Export(String exportJson, boolean overwriteExisting) {
        V32MigrationValidator.ValidationResult validation =
                V32MigrationValidator.validate(exportJson);

        if (!validation.valid) {
            return MigrationResult.invalid(validation.errors);
        }

        V32DataImporter importer = new V32DataImporter(repository);
        V32DataImporter.ImportReport report = importer.importExport(
                exportJson, overwriteExisting);

        return new MigrationResult(
                true,
                report.seen,
                report.imported,
                report.skippedExisting,
                report.errors,
                validation.errors);
    }

    /**
     * Creates a complete JSON backup of native storage.
     * Values are retained as JSON rather than converted into typed models.
     */
    public String exportNativeStore() {
        try {
            JSONObject data = new JSONObject();
            for (String key : repository.keys()) {
                String value = repository.getJson(key);
                data.put(key, value == null ? JSONObject.NULL : value);
            }

            JSONObject root = new JSONObject();
            root.put("schemaVersion", 1);
            root.put("exportedAt", System.currentTimeMillis());
            root.put("source", "nori-native");
            root.put("data", data);
            return root.toString();
        } catch (Exception e) {
            return null;
        }
    }

    public int nativeRecordCount() {
        return repository.count();
    }

    @Override
    public void close() {
        repository.close();
    }


    public static final class MigrationResult {
        public final boolean valid;
        public final int seen;
        public final int imported;
        public final int skippedExisting;
        public final int errors;
        public final List<String> validationErrors;

        private MigrationResult(boolean valid, int seen, int imported,
                                int skippedExisting, int errors,
                                List<String> validationErrors) {
            this.valid = valid;
            this.seen = seen;
            this.imported = imported;
            this.skippedExisting = skippedExisting;
            this.errors = errors;
            this.validationErrors = java.util.Collections.unmodifiableList(
                    new ArrayList<>(validationErrors));
        }

        static MigrationResult invalid(List<String> errors) {
            return new MigrationResult(false, 0, 0, 0, 0, errors);
        }

        public boolean isSuccessful() {
            return valid && errors == 0;
        }

        @Override
        public String toString() {
            return "MigrationResult{" +
                    "valid=" + valid +
                    ", seen=" + seen +
                    ", imported=" + imported +
                    ", skippedExisting=" + skippedExisting +
                    ", errors=" + errors +
                    '}';
        }
    }

}
