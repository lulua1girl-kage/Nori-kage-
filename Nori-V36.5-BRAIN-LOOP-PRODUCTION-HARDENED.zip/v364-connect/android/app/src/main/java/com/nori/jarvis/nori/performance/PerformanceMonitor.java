package com.nori.jarvis.nori.performance;

import java.util.ArrayDeque;
import java.util.Deque;

/** Bounded timing monitor for local operations. */
public final class PerformanceMonitor {
    private final int maxSamples;
    private final Deque<Long> samples = new ArrayDeque<>();
    public PerformanceMonitor() { this(64); }
    public PerformanceMonitor(int maxSamples) {
        if (maxSamples < 1) throw new IllegalArgumentException("maxSamples must be positive");
        this.maxSamples = maxSamples;
    }
    public synchronized void recordNanos(long nanos) {
        if (nanos < 0) return;
        samples.addLast(nanos);
        while (samples.size() > maxSamples) samples.removeFirst();
    }
    public synchronized int sampleCount() { return samples.size(); }
    public synchronized long lastNanos() { return samples.isEmpty() ? 0L : samples.peekLast(); }
    public synchronized long averageNanos() {
        if (samples.isEmpty()) return 0L;
        long total = 0L; for (Long x : samples) total += x;
        return total / samples.size();
    }
}
