package com.nori.jarvis.nori.creative.android;

import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import com.nori.jarvis.nori.creative.NoriPdfGenerationEngine;
import java.io.*; import java.nio.charset.StandardCharsets;

/** Native, offline-capable PDF renderer using Android's PdfDocument API. */
public final class NoriPdfService {
    public byte[] render(NoriPdfGenerationEngine.DocumentSpec spec){
        if(spec==null) throw new IllegalArgumentException("document_required");
        PdfDocument pdf=new PdfDocument(); int pageNumber=1; PdfDocument.Page page=null; Canvas canvas=null;
        Paint title=new Paint(Paint.ANTI_ALIAS_FLAG); title.setTextSize(22); title.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
        Paint heading=new Paint(Paint.ANTI_ALIAS_FLAG); heading.setTextSize(15); heading.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
        Paint body=new Paint(Paint.ANTI_ALIAS_FLAG); body.setTextSize(11);
        int width=595,height=842, left=54, right=width-54, y=60;
        try{
            page=pdf.startPage(new PdfDocument.PageInfo.Builder(width,height,pageNumber).create()); canvas=page.getCanvas();
            canvas.drawText(spec.title,left,y,title); y+=24; if(!spec.author.isEmpty()){canvas.drawText("By "+spec.author,left,y,body);y+=24;} else y+=10;
            for(NoriPdfGenerationEngine.Section section:spec.sections){
                if(section.pageBreak || y>height-90){pdf.finishPage(page); pageNumber++; page=pdf.startPage(new PdfDocument.PageInfo.Builder(width,height,pageNumber).create());canvas=page.getCanvas();y=60;}
                if(!section.title.isEmpty()){canvas.drawText(section.title,left,y,heading);y+=20;}
                for(String para:section.body.split("\\n")){
                    String line=para.trim(); if(line.isEmpty()){y+=10;continue;}
                    String[] words=line.split("\\s+"); StringBuilder row=new StringBuilder();
                    for(String w:words){String test=row.length()==0?w:row+" "+w; if(body.measureText(test)>right-left){canvas.drawText(row.toString(),left,y,body);y+=16;row=new StringBuilder(w); if(y>height-60){pdf.finishPage(page);pageNumber++;page=pdf.startPage(new PdfDocument.PageInfo.Builder(width,height,pageNumber).create());canvas=page.getCanvas();y=60;}}else row=new StringBuilder(test);}
                    if(row.length()>0){canvas.drawText(row.toString(),left,y,body);y+=16;}
                }
                y+=12;
            }
            canvas.drawText("Nori",left,height-28,body); pdf.finishPage(page);
            ByteArrayOutputStream out=new ByteArrayOutputStream();pdf.writeTo(out);return out.toByteArray();
        }catch(IOException e){throw new IllegalStateException("pdf_render_failed",e);} finally {pdf.close();}
    }
    public void writeTo(OutputStream out,NoriPdfGenerationEngine.DocumentSpec spec)throws IOException{out.write(render(spec));}
    public static String utf8(byte[] data){return new String(data,StandardCharsets.ISO_8859_1);}
}
