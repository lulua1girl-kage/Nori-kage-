package com.nori.jarvis.nori.edgeai;

import java.util.*;

/**
 * Local intelligence coordinator. It selects an installed backend/model but never bypasses
 * Nori Constitution, User Control, ActionEngine, or privacy boundaries.
 */
public final class NoriEdgeAiEngine {
    public static final class Result {
        public final boolean handled; public final String text; public final String backend; public final String modelId; public final String reason;
        Result(boolean h,String t,String b,String m,String r){handled=h;text=t==null?"":t;backend=b==null?"":b;modelId=m==null?"":m;reason=r==null?"":r;}
        public static Result no(String r){return new Result(false,"","","",r);}
    }
    private final NoriEdgeAiRegistry registry; private NoriEdgeAiPolicy policy;
    public NoriEdgeAiEngine(){this(new NoriEdgeAiRegistry(),NoriEdgeAiPolicy.safeDefault());}
    public NoriEdgeAiEngine(NoriEdgeAiRegistry r,NoriEdgeAiPolicy p){registry=r==null?new NoriEdgeAiRegistry():r;policy=p==null?NoriEdgeAiPolicy.safeDefault():p;}
    public NoriEdgeAiRegistry registry(){return registry;}
    public synchronized void setPolicy(NoriEdgeAiPolicy p){if(p!=null)policy=p;}
    public synchronized NoriEdgeAiPolicy policy(){return policy;}
    public synchronized Result select(NoriOnDeviceTask task,boolean multimodal){
        for(NoriEdgeModel m:registry.candidates(task,multimodal)) if(policy.permits(m))
            return new Result(true,"",m.backend.name(),m.id,"model_selected");
        return Result.no("no_compatible_installed_model");
    }
    public synchronized String status(){return registry.summary()+"|models="+registry.models().size()+"|preferOnDevice="+policy.preferOnDevice;}
}
