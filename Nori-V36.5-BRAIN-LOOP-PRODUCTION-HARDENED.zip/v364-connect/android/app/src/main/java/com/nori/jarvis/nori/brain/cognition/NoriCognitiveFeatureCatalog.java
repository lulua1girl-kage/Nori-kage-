package com.nori.jarvis.nori.brain.cognition;

import java.util.*;
/** Registry of higher-order thinking behaviors used by the Cognitive Core. */
public final class NoriCognitiveFeatureCatalog {
    private NoriCognitiveFeatureCatalog() {}
    public static List<String> all(){ return Collections.unmodifiableList(Arrays.asList(
        "goal_reconstruction","constraint_tracking","ambiguity_detection","hypothesis_competition",
        "evidence_thresholding","counterexample_check","contradiction_detection","assumption_tracking",
        "uncertainty_calibration","causal_vs_correlational_guard","temporal_reasoning","dependency_reasoning",
        "tradeoff_reasoning","decision_boundary_detection","value_of_information","minimal_sufficient_reasoning",
        "answer_shape_selection","context_relevance_filter","memory_relevance_filter","freshness_detection",
        "tool_need_detection","action_risk_check","human_override_check","result_verification",
        "postcondition_check","error_recovery","plan_repair","partial_completion","task_resumption",
        "confidence_update","feedback_learning","provider_selection","resource_adaptation",
        "latency_budgeting","parallelism_selection","cache_reuse","cache_invalidation",
        "privacy_aware_reasoning","evidence_provenance","source_conflict_awareness","self_consistency_check"
    )); }
}
