package com.nori.jarvis.nori.ai;

/** Local-first routing. Remote providers are optional capabilities, not Nori itself. */
public final class AiRoutingPolicy {
    public enum Route { LOCAL_ONLY, LOCAL_THEN_REMOTE, REMOTE_THEN_LOCAL }
    private final Route route; private final boolean allowRemote;
    public AiRoutingPolicy(Route route, boolean allowRemote){this.route=route==null?Route.LOCAL_ONLY:route;this.allowRemote=allowRemote;}
    public Route route(){return route;} public boolean allowRemote(){return allowRemote;}
    public static AiRoutingPolicy localFirst(){return new AiRoutingPolicy(Route.LOCAL_THEN_REMOTE,true);}
    public static AiRoutingPolicy localOnly(){return new AiRoutingPolicy(Route.LOCAL_ONLY,false);}
}
