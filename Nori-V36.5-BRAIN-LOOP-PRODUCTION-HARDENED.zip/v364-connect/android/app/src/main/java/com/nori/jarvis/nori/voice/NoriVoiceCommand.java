package com.nori.jarvis.nori.voice;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Structured voice intent. Parsing is separate from execution so Brain can reason before acting. */
public final class NoriVoiceCommand {
    public enum Type { NONE, NEW_RESULT, NEW_ASSESSMENT, NEW_ASSIGNMENT, ADD_SUBJECT, RETURN_TO_CHAT, OPEN_APP, START_EXAM_MODE, SCAN_STUDY_LIBRARY, OPEN_STUDY_RESOURCE, ANOTHER_ENTRY }
    public final Type type;
    public final String target;
    public final Map<String,String> fields;
    public final String raw;
    public NoriVoiceCommand(Type type, String target, Map<String,String> fields, String raw) {
        this.type=type; this.target=target;
        this.fields=Collections.unmodifiableMap(new LinkedHashMap<>(fields==null?Collections.emptyMap():fields));
        this.raw=raw==null?"":raw;
    }
}
