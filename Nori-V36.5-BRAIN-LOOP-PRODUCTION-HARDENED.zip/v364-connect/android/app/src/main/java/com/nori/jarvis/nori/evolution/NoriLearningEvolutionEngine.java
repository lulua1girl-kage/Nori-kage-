package com.nori.jarvis.nori.evolution;

import java.time.Instant;
import java.util.*;

/** Governed action -> outcome -> learning -> adaptation loop. No silent self-modification. */
public final class NoriLearningEvolutionEngine {
    public enum Outcome { POSITIVE, NEUTRAL, NEGATIVE, UNKNOWN }
    public enum ProposalStatus { PROPOSED, APPROVED, REJECTED, APPLIED }
    public static final class Experiment { public final String id, hypothesis, intervention, metric; public final int targetTrials; public final Instant createdAt;
        public Experiment(String i,String h,String in,String m,int t){id=i;hypothesis=h;intervention=in;metric=m;targetTrials=Math.max(1,t);createdAt=Instant.now();}}
    public static final class Observation { public final String experimentId; public final Outcome outcome; public final double value; public final String evidence; public final Instant at;
        public Observation(String i,Outcome o,double v,String e){experimentId=i;outcome=o;value=clamp(v);evidence=e==null?"":e;at=Instant.now();}}
    public static final class Proposal { public final String id,change,reason; public final double confidence; public final ProposalStatus status;
        public Proposal(String i,String c,String r,double conf,ProposalStatus s){id=i;change=c;reason=r;confidence=clamp(conf);status=s;}}
    public static final class Report { public final int experiments,observations; public final List<Proposal> proposals; public final Map<String,Double> outcomeRates;
        Report(int e,int o,List<Proposal>p,Map<String,Double>r){experiments=e;observations=o;proposals=Collections.unmodifiableList(new ArrayList<>(p));outcomeRates=Collections.unmodifiableMap(new LinkedHashMap<>(r));}}
    private final Map<String,Experiment> experiments=new LinkedHashMap<>(); private final List<Observation> observations=new ArrayList<>();
    public synchronized boolean registerExperiment(Experiment e){if(e==null||e.id==null||e.id.isEmpty()||experiments.containsKey(e.id))return false;experiments.put(e.id,e);return true;}
    public synchronized void recordOutcome(Observation o){if(o!=null&&experiments.containsKey(o.experimentId)){observations.add(o);while(observations.size()>500)observations.remove(0);}}
    public synchronized Report evaluate(){
        Map<String,Double> rates=new LinkedHashMap<>();List<Proposal> ps=new ArrayList<>();
        for(Experiment e:experiments.values()){List<Observation> os=new ArrayList<>();for(Observation o:observations)if(e.id.equals(o.experimentId))os.add(o);if(os.isEmpty())continue;double sum=0;for(Observation o:os)sum+=o.outcome==Outcome.POSITIVE?1:o.outcome==Outcome.NEGATIVE?0:.5;double rate=sum/os.size();rates.put(e.id,rate);
            if(os.size()>=Math.min(3,e.targetTrials)){String change=rate>=.70?"prefer:"+e.intervention:rate<=.30?"avoid:"+e.intervention:"keep_testing:"+e.intervention;ps.add(new Proposal("p-"+e.id,change,"observed_outcome_rate="+String.format(Locale.ROOT,"%.2f",rate),Math.min(1,.45+os.size()*.08),ProposalStatus.PROPOSED));}}
        return new Report(experiments.size(),observations.size(),ps,rates);
    }
    public synchronized boolean approve(String proposalId, boolean userConfirmed){return userConfirmed&&proposalId!=null&&!proposalId.isEmpty();}
    public synchronized List<String> discoverCapabilities(Set<String> observedActions,Set<String> registeredCapabilities){List<String> out=new ArrayList<>();if(observedActions!=null)for(String a:observedActions)if(a!=null&&!a.isEmpty()&&(registeredCapabilities==null||!registeredCapabilities.contains(a)))out.add(a);return Collections.unmodifiableList(out);}
    private static double clamp(double x){return Math.max(0,Math.min(1,x));}
}
