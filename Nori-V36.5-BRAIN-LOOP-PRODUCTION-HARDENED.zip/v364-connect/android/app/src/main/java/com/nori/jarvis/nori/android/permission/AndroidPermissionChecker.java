package com.nori.jarvis.nori.android.permission;

import android.content.Context;
import android.content.pm.PackageManager;
import androidx.core.content.ContextCompat;

/** Runtime permission adapter. Special Android access (usage stats, overlays) is handled by its service. */
public final class AndroidPermissionChecker implements com.nori.jarvis.nori.actions.PermissionChecker {
    private final Context context;
    public AndroidPermissionChecker(Context context) { this.context = context.getApplicationContext(); }
    @Override public boolean isGranted(String permission) {
        if (permission == null || permission.trim().isEmpty()) return true;
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED;
    }
}
