package com.nori.jarvis.nori.brain.goal;

import java.util.*;

/** Turns broad goals into editable dependency trees. It proposes structure; the student owns the goal. */
public final class NoriGoalDecompositionEngine {
    public static final class Node { public final String id,title,type; public final List<Node> children; public final List<String> checkpoints;
        Node(String i,String t,String ty,List<Node> c,List<String> k){id=i;title=t;type=ty;children=Collections.unmodifiableList(new ArrayList<>(c));checkpoints=Collections.unmodifiableList(new ArrayList<>(k));}}
    public Node decompose(String goal){String g=goal==null?"":goal.trim();if(g.isEmpty())return new Node("goal","Define a goal","GOAL",Collections.emptyList(),Collections.emptyList());String l=g.toLowerCase(Locale.ROOT);List<Node> c=new ArrayList<>();
        if(l.contains("doctor")||l.contains("medicine")){c.add(node("science","Science foundation","SUBJECT",Arrays.asList("biology","chemistry","physics")));c.add(node("math","Mathematics","SUBJECT",Collections.singletonList("core mathematics")));c.add(node("exam","Exams and admissions","CHECKPOINT",Arrays.asList("school assessments","entrance preparation")));c.add(node("skills","Professional capabilities","SKILL",Arrays.asList("communication","problem solving","independent learning")));}
        else {c.add(node("knowledge","Knowledge foundation","DOMAIN",Arrays.asList("identify required subjects","identify prerequisites")));c.add(node("skills","Transferable skills","SKILL",Arrays.asList("problem solving","self-correction","communication")));c.add(node("checkpoints","Checkpoints","CHECKPOINT",Arrays.asList("near-term milestone","term milestone","long-term milestone")));}
        return new Node("goal",g,"GOAL",c,Arrays.asList("define success criteria","review progress periodically","re-derive near-term actions from current constraints"));}
    public List<String> deriveWeeklyTasks(Node root){List<String> out=new ArrayList<>();walk(root,out);return Collections.unmodifiableList(out.subList(0,Math.min(8,out.size())));}
    private void walk(Node n,List<String>o){if(!n.children.isEmpty())for(Node c:n.children){o.add("next: "+c.title);walk(c,o);}}
    private Node node(String id,String title,String type,List<String>k){return new Node(id,title,type,Collections.emptyList(),k);}
}
