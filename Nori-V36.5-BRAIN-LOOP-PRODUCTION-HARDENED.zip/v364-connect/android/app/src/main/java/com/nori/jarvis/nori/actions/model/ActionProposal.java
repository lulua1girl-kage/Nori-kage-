package com.nori.jarvis.nori.actions.model;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public final class ActionProposal {
    public final String id;
    public final ToolDefinition tool;
    public final ToolRequest request;
    public final String reason;
    public final List<String> evidence;
    public final Instant createdAt;
    public ActionStatus status;
    public ActionPreview preview;
    public String operationId;
    public String failureReason;

    public ActionProposal(ToolDefinition tool, ToolRequest request, String reason, List<String> evidence) {
        this.id = "proposal_" + UUID.randomUUID();
        this.tool = tool;
        this.request = request;
        this.reason = reason == null ? "User-requested action." : reason;
        this.evidence = Collections.unmodifiableList(new ArrayList<>(evidence == null ? Collections.<String>emptyList() : evidence));
        this.createdAt = Instant.now();
        this.status = tool.confirmationRequired ? ActionStatus.PENDING_CONFIRMATION : ActionStatus.PENDING_CONFIRMATION;
    }
}
