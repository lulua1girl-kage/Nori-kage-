package com.nori.jarvis.nori.actions.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ActionPreview {
    public final boolean allowed;
    public final String reason;
    public final List<String> changes;

    public ActionPreview(boolean allowed, String reason, List<String> changes) {
        this.allowed = allowed;
        this.reason = reason;
        this.changes = Collections.unmodifiableList(new ArrayList<>(changes == null ? Collections.<String>emptyList() : changes));
    }

    public static ActionPreview allow(List<String> changes) { return new ActionPreview(true, null, changes); }
    public static ActionPreview deny(String reason) { return new ActionPreview(false, reason, Collections.<String>emptyList()); }
}
