package com.nori.jarvis.nori.ai;

import com.nori.jarvis.nori.data.DataRepository;
import java.util.*;
import java.time.Instant;

/** Small persistent operational ledger for provider failures; never stores prompts or credentials. */
public final class ProviderFailureLedger implements AiRouter.FailureListener {
    private final DataRepository repository; private static final String KEY="nori_ai_provider_failures_v1"; private final List<String> rows=new ArrayList<>();
    public ProviderFailureLedger(DataRepository r){repository=r;load();}
    public synchronized void onFailure(String providerId,String reason){rows.add(Instant.now().toString()+"|"+clean(providerId)+"|"+clean(reason));while(rows.size()>200)rows.remove(0);persist();}
    public synchronized List<String> recent(){return Collections.unmodifiableList(new ArrayList<>(rows));}
    private void load(){if(repository==null)return;String x=repository.getJson(KEY);if(x!=null&&!x.isEmpty())rows.addAll(Arrays.asList(x.split("\\n")));}
    private void persist(){if(repository!=null)repository.putJson(KEY,String.join("\n",rows),"ai_reliability",1);}
    private static String clean(String x){return String.valueOf(x==null?"":x).replaceAll("[\\r\\n|]","_");}
}
