package com.nori.jarvis.nori.android.alarm;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

/** Reminder boundary. Uses inexact alarms by default; exact-alarm access is deliberately not requested here. */
public final class NoriAlarmService {
    private final Context context;
    private final AlarmManager alarmManager;
    public NoriAlarmService(Context context) {
        this.context = context.getApplicationContext();
        this.alarmManager = (AlarmManager)this.context.getSystemService(Context.ALARM_SERVICE);
    }
    public void scheduleReminder(int requestCode, long triggerAtMillis, String title, String text) {
        if (triggerAtMillis <= System.currentTimeMillis()) throw new IllegalArgumentException("trigger_must_be_future");
        Intent intent = new Intent(context, NoriAlarmReceiver.class)
            .putExtra("notification_id", requestCode).putExtra("title", title).putExtra("text", text);
        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (android.os.Build.VERSION.SDK_INT >= 31 && alarmManager.canScheduleExactAlarms()) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        } else if (android.os.Build.VERSION.SDK_INT >= 23) {
            alarmManager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        } else {
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pi);
        }
    }
    public void cancel(int requestCode) {
        Intent intent = new Intent(context, NoriAlarmReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        alarmManager.cancel(pi); pi.cancel();
    }
}
