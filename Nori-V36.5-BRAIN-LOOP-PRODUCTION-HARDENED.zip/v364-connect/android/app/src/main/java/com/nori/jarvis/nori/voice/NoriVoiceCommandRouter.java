package com.nori.jarvis.nori.voice;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Deterministic first-pass command router. It produces intents, never performs side effects. */
public final class NoriVoiceCommandRouter {
    private static final Pattern OPEN = Pattern.compile("(?:open|launch|start)\\s+(.+)", Pattern.CASE_INSENSITIVE);
    public NoriVoiceCommand parse(String raw) {
        String s=raw==null?"":raw.trim(); String l=s.toLowerCase(Locale.ROOT);
        if(s.isEmpty()) return new NoriVoiceCommand(NoriVoiceCommand.Type.NONE,"",Collections.emptyMap(),s);
        if(l.contains("new result") || l.contains("record result") || l.contains("new grade")) return cmd(NoriVoiceCommand.Type.NEW_RESULT,s);
        if(l.contains("new assessment") || l.contains("assessment update") || l.contains("assessment updates")) return cmd(NoriVoiceCommand.Type.NEW_ASSESSMENT,s);
        if(l.contains("new assignment") || l.contains("assignment update")) return cmd(NoriVoiceCommand.Type.NEW_ASSIGNMENT,s);
        if(l.contains("another subject") || l.contains("add subject") || l.contains("another result") || l.contains("new result form")) return cmd(NoriVoiceCommand.Type.ADD_SUBJECT,s);
        if(l.contains("scan my books") || l.contains("find my textbook") || l.contains("find the textbook") || l.contains("find my study files")) return cmd(NoriVoiceCommand.Type.SCAN_STUDY_LIBRARY,s);
        if(l.contains("open the textbook") || l.contains("open my textbook") || l.contains("open study material")) return cmd(NoriVoiceCommand.Type.OPEN_STUDY_RESOURCE,s);
        if(l.contains("another entry") || l.contains("another form")) return cmd(NoriVoiceCommand.Type.ANOTHER_ENTRY,s);
        if(l.contains("return me") || l.contains("return to chat") || l.contains("open nori chat") || l.equals("nori")) return cmd(NoriVoiceCommand.Type.RETURN_TO_CHAT,s);
        if((l.contains("i have") || l.contains("i've got") || l.contains("there is")) && l.contains("exam")) return cmd(NoriVoiceCommand.Type.START_EXAM_MODE,s);
        Matcher m=OPEN.matcher(s); if(m.matches()) return new NoriVoiceCommand(NoriVoiceCommand.Type.OPEN_APP,m.group(1).trim(),Collections.emptyMap(),s);
        return new NoriVoiceCommand(NoriVoiceCommand.Type.NONE,"",Collections.emptyMap(),s);
    }
    private NoriVoiceCommand cmd(NoriVoiceCommand.Type t,String raw){return new NoriVoiceCommand(t,"",Collections.emptyMap(),raw);}
}
