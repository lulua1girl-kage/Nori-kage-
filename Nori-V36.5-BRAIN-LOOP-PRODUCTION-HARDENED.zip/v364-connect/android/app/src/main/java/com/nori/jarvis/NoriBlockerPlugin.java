package com.nori.jarvis;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Process;
import android.provider.Settings;

import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.util.ArrayList;

/**
 * Bridges nori-blocker.js (running in the WebView) to the native Android
 * capabilities needed to pause distracting apps during a study block:
 * checking/requesting the two manually-granted permissions, and starting
 * or stopping the foreground service that actually does the watching.
 *
 * Registered as "NoriBlocker" — call it from JS as
 * Capacitor.Plugins.NoriBlocker.methodName({...}).
 */
@CapacitorPlugin(name = "NoriBlocker")
public class NoriBlockerPlugin extends Plugin {

    @PluginMethod
    public void checkPermissions(PluginCall call) {
        Context ctx = getContext();
        JSObject result = new JSObject();
        result.put("usageAccess", hasUsageAccessPermission(ctx));
        result.put("overlay", Settings.canDrawOverlays(ctx));
        call.resolve(result);
    }

    // Usage Access has no runtime permission dialog — Android only allows
    // opening this exact Settings screen, where the user finds Nori in the
    // list and flips the toggle themselves.
    @PluginMethod
    public void requestUsageAccess(PluginCall call) {
        Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(intent);
        call.resolve();
    }

    // Same story for the overlay permission — this one goes straight to
    // Nori's own entry in the "Draw over other apps" settings screen.
    @PluginMethod
    public void requestOverlayPermission(PluginCall call) {
        Intent intent = new Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:" + getContext().getPackageName())
        );
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        getContext().startActivity(intent);
        call.resolve();
    }

    @PluginMethod
    public void setSelectedPackages(PluginCall call) {
        JSArray a=call.getArray("packages");
        java.util.HashSet<String> set=new java.util.HashSet<>();
        try{if(a!=null)for(int i=0;i<a.length();i++)set.add(a.getString(i));}catch(Exception e){call.reject("Invalid packages array");return;}
        getContext().getSharedPreferences("nori_focus_policy",Context.MODE_PRIVATE).edit().putStringSet("blocked_packages",set).apply();
        call.resolve(new JSObject().put("count",set.size()));
    }
    @PluginMethod
    public void getSelectedPackages(PluginCall call) {
        java.util.Set<String> set=getContext().getSharedPreferences("nori_focus_policy",Context.MODE_PRIVATE).getStringSet("blocked_packages",java.util.Collections.emptySet());
        JSArray a=new JSArray(); for(String p:set)a.put(p); call.resolve(new JSObject().put("packages",a));
    }

    @PluginMethod
    public void startBlocking(PluginCall call) {
        JSArray packagesArg = call.getArray("packages");
        ArrayList<String> packages = new ArrayList<>();
        try {
            if (packagesArg != null) {
                for (int i = 0; i < packagesArg.length(); i++) packages.add(packagesArg.getString(i));
            }
        } catch (Exception e) {
            call.reject("Invalid packages array: " + e.getMessage());
            return;
        }

        getContext().getSharedPreferences("nori_focus_policy",Context.MODE_PRIVATE).edit().putBoolean("active",true).putStringSet("blocked_packages",new java.util.HashSet<>(packages)).apply();
        Intent intent = new Intent(getContext(), NoriBlockerService.class);
        intent.putStringArrayListExtra(NoriBlockerService.EXTRA_BLOCKED_PACKAGES, packages);
        intent.putExtra(NoriBlockerService.EXTRA_STATUS_ENDPOINT, call.getString("statusEndpoint", ""));
        intent.putExtra(NoriBlockerService.EXTRA_AUTH_TOKEN, call.getString("authToken", ""));
        intent.putExtra(NoriBlockerService.EXTRA_CONTEXT_JSON, call.getString("context", "{}"));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            getContext().startForegroundService(intent);
        } else {
            getContext().startService(intent);
        }
        call.resolve();
    }

    @PluginMethod
    public void refreshRestrictions(PluginCall call) {
        Intent intent = new Intent(getContext(), NoriBlockerService.class);
        intent.putExtra(NoriBlockerService.EXTRA_STATUS_ENDPOINT, call.getString("statusEndpoint", ""));
        intent.putExtra(NoriBlockerService.EXTRA_AUTH_TOKEN, call.getString("authToken", ""));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getContext().startForegroundService(intent);
        else getContext().startService(intent);
        call.resolve();
    }


    @PluginMethod
    public void setContext(PluginCall call) {
        String json = call.getString("context", "{}");
        Intent intent = new Intent(getContext(), NoriBlockerService.class);
        intent.putExtra(NoriBlockerService.EXTRA_CONTEXT_JSON, json);
        intent.putExtra(NoriBlockerService.EXTRA_BLOCKED_PACKAGES, new ArrayList<String>());
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getContext().startForegroundService(intent);
        else getContext().startService(intent);
        call.resolve();
    }

    @PluginMethod
    public void getContext(PluginCall call) {
        // The authoritative context remains in the JS intelligence layer.
        call.resolve(new JSObject().put("source", "js-context-intelligence"));
    }

    @PluginMethod
    public void listLaunchableApps(PluginCall call) {
        android.content.pm.PackageManager pm=getContext().getPackageManager();
        android.content.Intent main=new android.content.Intent(android.content.Intent.ACTION_MAIN);
        main.addCategory(android.content.Intent.CATEGORY_LAUNCHER);
        java.util.List<android.content.pm.ResolveInfo> infos=pm.queryIntentActivities(main,0);
        JSArray out=new JSArray();
        java.util.Collections.sort(infos,(a,b)->String.valueOf(a.loadLabel(pm)).compareToIgnoreCase(String.valueOf(b.loadLabel(pm))));
        for(android.content.pm.ResolveInfo ri:infos){
            String pkg=ri.activityInfo.packageName; if(pkg.equals(getContext().getPackageName())) continue;
            JSObject x=new JSObject(); x.put("package",pkg); x.put("label",String.valueOf(ri.loadLabel(pm))); out.put(x);
        }
        call.resolve(new JSObject().put("apps",out));
    }

    @PluginMethod
    public void stopBlocking(PluginCall call) {
        getContext().getSharedPreferences("nori_focus_policy",Context.MODE_PRIVATE).edit().putBoolean("active",false).apply();
        getContext().stopService(new Intent(getContext(), NoriBlockerService.class));
        getContext().getSharedPreferences("nori_focus_policy", Context.MODE_PRIVATE).edit().putBoolean("active", false).apply();
        call.resolve();
    }

    private boolean hasUsageAccessPermission(Context context) {
        AppOpsManager appOps = (AppOpsManager) context.getSystemService(Context.APP_OPS_SERVICE);
        int mode;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            mode = appOps.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.getPackageName());
        } else {
            mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), context.getPackageName());
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }
}
