package com.nori.jarvis.nori.ai;

import java.util.*;
import java.util.concurrent.*;

/** Optional multi-provider council for difficult verification; disagreement remains uncertainty, not a vote for truth. */
public final class NoriModelCouncil {
    public static final class Result { public final boolean used; public final boolean agreement; public final double agreementScore; public final List<AiResponse> responses; public final String conclusion;
        Result(boolean u,boolean a,double s,List<AiResponse>r,String c){used=u;agreement=a;agreementScore=s;responses=Collections.unmodifiableList(new ArrayList<>(r));conclusion=c;}}
    public Result consult(String prompt,List<AiProvider> providers,long timeoutMillis){
        if(prompt==null||prompt.trim().isEmpty()||providers==null||providers.size()<2)return new Result(false,false,0,Collections.emptyList(),"council_not_required");
        List<AiProvider> active=new ArrayList<>();for(AiProvider p:providers)if(p!=null&&p.isAvailable())active.add(p);if(active.size()<2)return new Result(false,false,0,Collections.emptyList(),"insufficient_available_providers");
        ExecutorService ex=Executors.newFixedThreadPool(Math.min(3,active.size()));List<Future<AiResponse>> fs=new ArrayList<>();
        for(AiProvider p:active.subList(0,Math.min(3,active.size())))fs.add(ex.submit(()->p.generate(new AiRequest(prompt,"Return a concise answer and clearly mark uncertainty. Do not claim source verification you did not perform.",Collections.singletonMap("council","true"),8000))));
        List<AiResponse> rs=new ArrayList<>();for(Future<AiResponse> f:fs)try{AiResponse r=f.get(Math.max(1000,timeoutMillis),TimeUnit.MILLISECONDS);if(r!=null&&r.status==AiResponse.Status.SUCCESS)rs.add(r);}catch(Exception ignored){} ex.shutdownNow();
        if(rs.size()<2)return new Result(true,false,0,rs,"insufficient_independent_responses");
        Set<String> normalized=new HashSet<>();for(AiResponse r:rs)normalized.add(normalize(r.text));double score=(double)Collections.frequency(new ArrayList<>(normalized),normalized.iterator().next())/rs.size();
        boolean agreement=score>=.67;return new Result(true,agreement,score,rs,agreement?"independent_responses_are_similar_but_still_require_evidence":"provider_disagreement_requires_evidence_or_human_review");
    }
    private static String normalize(String s){return s==null?"":s.toLowerCase(Locale.ROOT).replaceAll("\\s+"," ").replaceAll("[^a-z0-9 ]","").trim();}
}
