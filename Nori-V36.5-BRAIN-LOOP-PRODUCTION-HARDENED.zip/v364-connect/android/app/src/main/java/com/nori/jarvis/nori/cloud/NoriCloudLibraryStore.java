package com.nori.jarvis.nori.cloud;

import com.nori.jarvis.nori.identity.NoriUserIdentity;
import java.util.*;

/** Cloud-first logical library. Bytes live in an object store; Nori keeps only metadata/cache locally. */
public final class NoriCloudLibraryStore {
    public static final long LOGICAL_QUOTA_BYTES=15L*1024L*1024L*1024L;
    public enum Provider { SUPABASE_STORAGE,FIREBASE_STORAGE,USER_DOCUMENT_PROVIDER,NONE }
    public static final class ObjectRef { public final String userScope,path,sha256; public final long size; public ObjectRef(String u,String p,String s,long z){userScope=u;path=p;sha256=s;size=z;} }
    private final NoriUserIdentity identity; private Provider provider=Provider.NONE; private long logicalBytes;
    public NoriCloudLibraryStore(NoriUserIdentity i){identity=i;}
    public void setProvider(Provider p){provider=p==null?Provider.NONE:p;}
    public Provider provider(){return provider;}
    public boolean canAdd(long bytes){return bytes>=0 && logicalBytes+bytes<=LOGICAL_QUOTA_BYTES;}
    public synchronized ObjectRef reserve(String path,String sha,long bytes){if(!identity.valid()||!canAdd(bytes))return null;logicalBytes+=bytes;return new ObjectRef(identity.libraryScope(),normalize(path),sha,bytes);}
    public synchronized void release(long bytes){logicalBytes=Math.max(0,logicalBytes-Math.max(0,bytes));}
    public long logicalBytes(){return logicalBytes;}
    public long remaining(){return LOGICAL_QUOTA_BYTES-logicalBytes;}
    public String storageKey(String fileId){return identity.libraryScope()+"/objects/"+(fileId==null?"unknown":fileId);}
    public String rule(){return "15 GB is a logical per-user quota, not 15 GB of mandatory phone storage. Original bytes belong in the configured cloud/document provider; local storage is bounded cache only.";}
    private String normalize(String p){String x=p==null?"file":p.replace('\\','/');while(x.startsWith("/"))x=x.substring(1);return x.replace("..","_");}
}
