package com.nori.jarvis.nori.reasoning;

import com.nori.jarvis.nori.brain.ContextEngine;
import com.nori.jarvis.nori.brain.VerificationEngine;
import java.util.*;

/**
 * Stage 2 reasoning boundary. Converts existing Brain outputs into a structured,
 * auditable evidence/conclusion summary without replacing any existing engine.
 */
public final class ReasoningEngine {
    public ReasoningResult summarize(List<Evidence> evidence, List<String> assumptions,
                                     String conclusion, ContextEngine.Result context,
                                     VerificationEngine.Result verification) {
        List<Evidence> safe = evidence == null ? Collections.emptyList() : evidence;
        int strong = 0, usable = 0;
        for (Evidence item : safe) {
            if (item.kind == Evidence.Kind.FACT || item.kind == Evidence.Kind.CONTEXT) {
                usable++;
                if (item.strength == Evidence.Strength.STRONG) strong++;
            }
        }
        boolean verified = verification != null && verification.isVerified();
        boolean contextClear = context != null && context.confidence != ContextEngine.Confidence.UNCLEAR;
        Confidence confidence;
        if (verified && usable >= 2 && contextClear && strong >= 1) confidence = Confidence.HIGH;
        else if (usable >= 2 && contextClear) confidence = Confidence.MEDIUM;
        else if (usable >= 1) confidence = Confidence.LOW;
        else confidence = Confidence.UNKNOWN;

        boolean needsVerification = !verified || confidence == Confidence.LOW || confidence == Confidence.UNKNOWN;
        return new ReasoningResult(safe, assumptions, conclusion, confidence, needsVerification);
    }
}
