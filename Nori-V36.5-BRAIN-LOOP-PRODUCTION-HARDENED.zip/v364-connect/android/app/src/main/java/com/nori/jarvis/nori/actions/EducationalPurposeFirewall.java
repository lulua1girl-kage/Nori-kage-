package com.nori.jarvis.nori.actions;

import com.nori.jarvis.nori.actions.model.ActionType;
import com.nori.jarvis.nori.actions.model.ToolDefinition;

/** Hard boundary: technical capability never becomes permission to act. */
public final class EducationalPurposeFirewall {
    private final NoriPublicationGuard publicationGuard = new NoriPublicationGuard();
    public Decision evaluate(ToolDefinition tool) {
        if (tool == null) return new Decision(false, "tool_missing");
        if (!tool.educationalAllowed) return new Decision(false, "tool_not_educationally_allowed");
        if (tool.type == ActionType.EXTERNAL && tool.educationalPurpose.trim().isEmpty()) return new Decision(false, "external_tool_requires_educational_purpose");
        if (!publicationGuard.allowed(tool)) return new Decision(false, "social_publication_is_never_allowed");
        return new Decision(true, null);
    }

    public static final class Decision {
        public final boolean allowed; public final String reason;
        public Decision(boolean allowed, String reason) { this.allowed = allowed; this.reason = reason; }
    }
}
