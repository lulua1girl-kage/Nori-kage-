package com.nori.jarvis.nori.actions.coordination;

import com.nori.jarvis.nori.actions.ToolRouter;
import com.nori.jarvis.nori.actions.model.*;
import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.brain.cognition.NoriCognitiveEngine;
import com.nori.jarvis.nori.constitution.NoriConstitution;
import com.nori.jarvis.nori.memory.context.NoriMemoryContext;
import com.nori.jarvis.nori.state.NoriState;
import java.util.*;

/** Coordinates Brain decisions with existing tools without expanding execution authority. */
public final class NoriToolCoordinationEngine {
    public enum Decision { NOT_A_TOOL_REQUEST, PREPARE, NEEDS_CONFIRMATION, BLOCK, EXECUTE_READY }
    public static final class Result {
        public final Decision decision; public final ActionProposal proposal; public final String reason;
        public final NoriCognitiveEngine.ThoughtState thought; public final NoriState state; public final NoriMemoryContext memory;
        public final List<String> evidence;
        Result(Decision d, ActionProposal p, String r, NoriCognitiveEngine.ThoughtState t,NoriState s,NoriMemoryContext m,List<String> e){decision=d;proposal=p;reason=r;thought=t;state=s;memory=m;evidence=Collections.unmodifiableList(new ArrayList<>(e));}
    }
    private final NoriBrain brain; private final ToolRouter router;
    public NoriToolCoordinationEngine(NoriBrain b){brain=Objects.requireNonNull(b);router=b.getToolRouter();}
    public Result prepare(String userRequest, ToolRequest request, boolean externalAvailable){
        NoriState state=brain.getCurrentState(); NoriMemoryContext memory=brain.buildMemoryContext(userRequest,6);
        NoriCognitiveEngine.ThoughtState thought=brain.think(userRequest,memory.compactContext,externalAvailable,true);
        NoriConstitution.Decision c=brain.getConstitution().evaluate(thought.intent.name(),userRequest,null,true,true);
        List<String> evidence=Arrays.asList("brain_intent="+thought.intent,"mode="+thought.answerShape,"state_availability="+state.situation.availability,"memory_context_bound=true");
        if(c.verdict==NoriConstitution.Verdict.BLOCK)return new Result(Decision.BLOCK,null,"constitution_block",thought,state,memory,evidence);
        if(request==null||request.toolId==null||request.toolId.trim().isEmpty())return new Result(Decision.NOT_A_TOOL_REQUEST,null,"no_tool_request",thought,state,memory,evidence);
        ActionProposal p;
        try{p=router.propose(request,"Brain-coordinated action",evidence);}catch(Exception e){return new Result(Decision.BLOCK,null,"tool_validation_failed:"+e.getMessage(),thought,state,memory,evidence);}
        return new Result(Decision.NEEDS_CONFIRMATION,p,"existing_action_engine_confirmation_required",thought,state,memory,evidence);
    }
}
