package com.nori.jarvis.nori.web.model;

public final class WebFetchResult {
    public enum Status { SUCCESS, BLOCKED, INVALID_URL, TOO_LARGE, NETWORK_ERROR }
    public final Status status; public final String url, text, reason;
    public WebFetchResult(Status status,String url,String text,String reason){this.status=status;this.url=url;this.text=text==null?"":text;this.reason=reason;}
}
