package com.nori.jarvis.nori.constitution;

import com.nori.jarvis.nori.brain.human.NoriHumanAssessment;
import com.nori.jarvis.nori.integrity.ConsequenceSafetyGuard;
import java.util.*;
import java.util.regex.Pattern;

/**
 * System-level Nori Constitution. It is a deterministic authority layer used before
 * advice, memory-informed AI requests, and proposed actions. It does not replace the
 * existing safety/override engines; it composes them and can only narrow an outcome.
 */
public final class NoriConstitution {
    public enum Verdict { ALLOW, ADJUST, REVIEW, BLOCK }
    public enum Principle { HUMAN_OVERRIDE, SAFETY, EDUCATIONAL_INTEGRITY, PRIVACY, AUTONOMY, PROPORTIONALITY, CAPABILITY_DISCLOSURE }

    private static final Pattern COERCION = Pattern.compile("\\b(threat|humiliat|shame|degrad|force|coerce|punish|retaliat|withhold food|sleep deprivation|pain|physical)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern SECRET = Pattern.compile("\\b(password|passcode|api key|token|secret|credit card|private key)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern DEPENDENCY = Pattern.compile("\\b(always ask nori|only nori can|without nori i can.?t|make me dependent|never decide myself)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern EDUCATION_HARM = Pattern.compile("\\b(skip school|cheat|impersonat|submit as me|do my exam|hide from teacher)\\b", Pattern.CASE_INSENSITIVE);

    public Decision evaluate(String operation, String content, NoriHumanAssessment human, boolean userInitiated, boolean consequence) {
        String text = normalize((operation == null ? "" : operation) + " " + (content == null ? "" : content));
        List<Principle> applied = new ArrayList<>();
        List<String> reasons = new ArrayList<>();

        if (COERCION.matcher(text).find()) {
            applied.add(Principle.SAFETY); reasons.add("coercive_or_harmful_pattern");
            return new Decision(Verdict.BLOCK, applied, reasons, "reject_harmful_or_coercive_behavior");
        }
        if (consequence) {
            ConsequenceSafetyGuard.Check check = ConsequenceSafetyGuard.check("constitution", operation, content, "academic", false);
            if (!check.allowed) {
                applied.add(Principle.SAFETY); reasons.add(check.reason);
                return new Decision(Verdict.BLOCK, applied, reasons, "existing_consequence_safety_guard_rejected_proposal");
            }
        }
        if (SECRET.matcher(text).find()) {
            applied.add(Principle.PRIVACY); reasons.add("credential_or_private_secret_request");
            return new Decision(Verdict.REVIEW, applied, reasons, "do_not_persist_or_expose_secret_material");
        }
        if (EDUCATION_HARM.matcher(text).find()) {
            applied.add(Principle.EDUCATIONAL_INTEGRITY); reasons.add("educational_integrity_boundary");
            return new Decision(Verdict.BLOCK, applied, reasons, "protect_learning_and_assessment_integrity");
        }
        if (DEPENDENCY.matcher(text).find()) {
            applied.add(Principle.AUTONOMY); reasons.add("anti_dependency_boundary");
            return new Decision(Verdict.ADJUST, applied, reasons, "return_decision_authority_to_user");
        }
        if (human != null) {
            if (human.guidance != null && human.guidance.mode == com.nori.jarvis.nori.brain.human.NoriSupportPolicy.Mode.SAFETY) {
                applied.add(Principle.HUMAN_OVERRIDE); applied.add(Principle.SAFETY);
                reasons.add("human_context_safety_mode");
                return new Decision(Verdict.ADJUST, applied, reasons, "safety_first_without_unnecessary_interrogation");
            }
            if (human.context != null && human.context.difficulty == com.nori.jarvis.nori.brain.human.HumanContextEngine.Difficulty.AVOIDANCE_PATTERN) {
                applied.add(Principle.PROPORTIONALITY);
                reasons.add("strictness_requires_evidence_of_repeated_avoidance");
            }
        }
        if (!userInitiated && looksLikeExternalAction(text)) {
            applied.add(Principle.HUMAN_OVERRIDE); reasons.add("important_action_requires_user_control");
            return new Decision(Verdict.REVIEW, applied, reasons, "require_explicit_user_control_before_important_action");
        }
        applied.add(Principle.CAPABILITY_DISCLOSURE);
        return new Decision(reasons.isEmpty() ? Verdict.ALLOW : Verdict.ADJUST, applied, reasons,
                reasons.isEmpty() ? "constitution_clear" : "proceed_with_bounded_adjustment");
    }

    public String systemContract() {
        return "NORI CONSTITUTION: human authority remains final; safety and privacy are non-negotiable; " +
                "educational integrity is protected; intervention must be proportional; avoid unnecessary disclosure; " +
                "do not create dependency; distinguish facts from inference; disclose capability limits; verify important actions.";
    }

    public boolean mayExecute(Decision d) { return d != null && d.verdict == Verdict.ALLOW; }
    public boolean mayAnswer(Decision d) { return d != null && d.verdict != Verdict.BLOCK; }

    private static boolean looksLikeExternalAction(String s) {
        return s.contains("send ") || s.contains("post ") || s.contains("publish ") || s.contains("delete ") || s.contains("change setting") || s.contains("open app");
    }
    private static String normalize(String s) { return s.replaceAll("[\\u0000-\\u001F]", " ").replaceAll("\\s+", " ").trim().toLowerCase(Locale.ROOT); }

    public static final class Decision {
        public final Verdict verdict; public final List<Principle> principles; public final List<String> reasons; public final String instruction;
        public Decision(Verdict v, List<Principle> p, List<String> r, String i) {
            verdict=v; principles=Collections.unmodifiableList(new ArrayList<>(p)); reasons=Collections.unmodifiableList(new ArrayList<>(r)); instruction=i;
        }
    }
}
