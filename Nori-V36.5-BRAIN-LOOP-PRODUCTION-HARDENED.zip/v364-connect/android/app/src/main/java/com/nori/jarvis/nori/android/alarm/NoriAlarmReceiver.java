package com.nori.jarvis.nori.android.alarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.app.Notification;
import androidx.core.app.NotificationCompat;
import com.nori.jarvis.nori.android.notification.NoriNotificationService;

/** Receives only alarms explicitly scheduled through NoriAlarmService. */
public final class NoriAlarmReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        int id = intent.getIntExtra("notification_id", (int)(System.currentTimeMillis() & 0x7fffffff));
        String title = intent.getStringExtra("title");
        String text = intent.getStringExtra("text");
        NoriNotificationService notifications = new NoriNotificationService(context);
        if (!notifications.canPost()) return;
        Notification.Builder builder = new NotificationCompat.Builder(context, NoriNotificationService.CHANNEL_REMINDERS).setSmallIcon(android.R.drawable.ic_lock_idle_alarm);
        notifications.post(id, NoriNotificationService.CHANNEL_REMINDERS, title == null ? "Nori Reminder" : title, text == null ? "Scheduled reminder" : text, builder);
    }
}
