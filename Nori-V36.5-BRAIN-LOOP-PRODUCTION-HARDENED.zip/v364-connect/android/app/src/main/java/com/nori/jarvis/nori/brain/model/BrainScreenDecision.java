package com.nori.jarvis.nori.brain.model;

import com.nori.jarvis.nori.brain.visual.NoriScreenSemanticAnalyzer;
import com.nori.jarvis.nori.reasoning.Evidence;
import com.nori.jarvis.nori.reasoning.ReasoningEngine;
import java.util.*;

/** Structured screen-evidence decision: concise explanation, confidence and next action. */
public final class BrainScreenDecision {
 public final NoriScreenSemanticAnalyzer.Result visual; public final String conclusion; public final List<Evidence> evidence; public final boolean requiresHumanReview;
 public BrainScreenDecision(NoriScreenSemanticAnalyzer.Result v,String c,List<Evidence> e,boolean r){visual=v;conclusion=c;evidence=Collections.unmodifiableList(new ArrayList<>(e));requiresHumanReview=r;}
}
