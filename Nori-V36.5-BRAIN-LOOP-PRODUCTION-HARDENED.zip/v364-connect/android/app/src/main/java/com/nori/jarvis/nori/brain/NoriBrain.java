package com.nori.jarvis.nori.brain;

import com.nori.jarvis.nori.world.NoriPersonalWorldModel;
import com.nori.jarvis.nori.evolution.NoriCausalCounterfactualEngine;
import com.nori.jarvis.nori.learning.NoriAdvancedLearningEngine;
import com.nori.jarvis.nori.research.NoriResearchBrain2;
import com.nori.jarvis.nori.brain.human.NoriHumanContext2;
import com.nori.jarvis.nori.execution.NoriExecutionLifecycle;
import com.nori.jarvis.nori.evolution.NoriFailureRecoveryEngine;
import com.nori.jarvis.nori.runtime.NoriRuntimeTelemetry;
import com.nori.jarvis.nori.runtime.NoriLongSessionMonitor;
import com.nori.jarvis.nori.runtime.NoriModelSelectionEngine;
import com.nori.jarvis.nori.web.NoriLiveWebRetrieval;
import com.nori.jarvis.nori.benchmark.NoriIntegrationBenchmark;

import com.nori.jarvis.nori.meta.NoriMetaBrainEngine;

import com.nori.jarvis.nori.academic.AcademicEngine;
import com.nori.jarvis.nori.brain.model.AcademicEventInput;
import com.nori.jarvis.nori.brain.model.BrainDecision;
import com.nori.jarvis.nori.brain.model.BrainScreenDecision;
import com.nori.jarvis.nori.kage.ConsequencePolicy;
import com.nori.jarvis.nori.kage.KageEngine;
import com.nori.jarvis.nori.data.DataRepository;
import com.nori.jarvis.nori.memory.MemoryDecision;
import com.nori.jarvis.nori.memory.MemoryEngine;
import com.nori.jarvis.nori.memory.MemoryItem;
import com.nori.jarvis.nori.memory.PersonalModel;
import com.nori.jarvis.nori.actions.ActionEngine;
import com.nori.jarvis.nori.actions.LocalAcademicTools;
import com.nori.jarvis.nori.actions.ToolRouter;
import com.nori.jarvis.nori.ai.AiRequest;
import com.nori.jarvis.nori.ai.AiResponse;
import com.nori.jarvis.nori.ai.AiRouter;
import com.nori.jarvis.nori.education.EducationalIntelligence;
import com.nori.jarvis.nori.education.model.AcademicEvidence;
import com.nori.jarvis.nori.integrity.IntegrityEngine;
import com.nori.jarvis.nori.admin.AdminControlPlane;
import com.nori.jarvis.nori.integrity.ConsequenceSafetyGuard;
import com.nori.jarvis.nori.actions.model.ActionProposal;
import com.nori.jarvis.nori.actions.model.ToolRequest;
import com.nori.jarvis.nori.web.engine.DocumentIntelligence;
import com.nori.jarvis.nori.web.engine.WebIntelligence;
import com.nori.jarvis.nori.advanced.AdvancedIntelligence;
import com.nori.jarvis.nori.conversation.engine.ConversationEngine;
import com.nori.jarvis.nori.security.NoriSecurity;
import com.nori.jarvis.nori.performance.NoriPerformance;
import com.nori.jarvis.nori.state.NoriState;
import com.nori.jarvis.nori.state.NoriStateEngine;
import com.nori.jarvis.nori.reasoning.Evidence;
import com.nori.jarvis.nori.reasoning.ReasoningEngine;
import com.nori.jarvis.nori.brain.visual.NoriScreenSemanticAnalyzer;
import com.nori.jarvis.nori.brain.human.HumanContextEngine;
import com.nori.jarvis.nori.brain.human.NoriSupportPolicy;
import com.nori.jarvis.nori.research.ResearchIntelligence;
import com.nori.jarvis.nori.data.NoriProfileStore;
import com.nori.jarvis.nori.brain.capacity.NoriBrainCapacityEngine;
import com.nori.jarvis.nori.conversation.engine.ConversationHistoryStore;
import com.nori.jarvis.nori.brain.frontier.NoriFrontierCapabilityEngine;
import com.nori.jarvis.nori.brain.cognition.NoriCognitiveEngine;
import com.nori.jarvis.nori.constitution.NoriConstitution;
import com.nori.jarvis.nori.memory.context.NoriMemoryContext;
import com.nori.jarvis.nori.ai.ProviderFailureLedger;
import com.nori.jarvis.nori.brain.learning.NoriLearningLoop;
import com.nori.jarvis.nori.brain.learning.NoriStudentDevelopment;
import com.nori.jarvis.nori.brain.planning.NoriDecisionPlanningEngine;
import com.nori.jarvis.nori.brain.intervention.NoriInterventionEngine;
import com.nori.jarvis.nori.conversation.intelligence.NoriConversationIntelligence;
import com.nori.jarvis.nori.conversation.intelligence.NoriLanguageIntelligence;
import com.nori.jarvis.nori.actions.coordination.NoriToolCoordinationEngine;
import com.nori.jarvis.nori.ai.NoriKnowledgeVerificationEngine;
import com.nori.jarvis.nori.ai.NoriModelCouncil;
import com.nori.jarvis.nori.evolution.NoriLearningEvolutionEngine;
import com.nori.jarvis.nori.evolution.NoriDiagnosticsEngine;
import com.nori.jarvis.nori.brain.loop.NoriCognitiveStateOutcomeLoop;
import com.nori.jarvis.nori.brain.study.NoriStudyStrategyEngine;
import com.nori.jarvis.nori.brain.goal.NoriGoalDecompositionEngine;
import com.nori.jarvis.nori.brain.schedule.NoriEnergyScheduleEngine;
import com.nori.jarvis.nori.brain.schedule.NoriBackgroundPreparationQueue;
import com.nori.jarvis.nori.brain.command.NoriCommandChainEngine;
import com.nori.jarvis.nori.brain.focus.NoriInterruptAwareFocusEngine;
import com.nori.jarvis.nori.brain.reasoning.NoriReasoningNarrator;
import com.nori.jarvis.nori.brain.scenario.NoriScenarioEngine;
import com.nori.jarvis.nori.brain.research.NoriPreemptiveResourceEngine;
import com.nori.jarvis.nori.understanding.NoriAppUnderstandingEngine;
import com.nori.jarvis.nori.understanding.NoriUserControlEngine;
import com.nori.jarvis.nori.execution.NoriFunctionalExecutionCore;
import com.nori.jarvis.nori.world.NoriWorldIntelligence;
import com.nori.jarvis.nori.world.NoriWorldWebConnector;
import com.nori.jarvis.nori.actions.NoriWorldTools;
import com.nori.jarvis.nori.growth.NoriHumanGrowthEngine;
import com.nori.jarvis.nori.safety.NoriYouthMediaSafety;
import com.nori.jarvis.nori.creative.NoriImageGenerationEngine;
import com.nori.jarvis.nori.creative.NoriPdfGenerationEngine;
import com.nori.jarvis.nori.creative.NoriCreativeIntentEngine;
import com.nori.jarvis.nori.ops.NoriOperationalCore;
import com.nori.jarvis.nori.execution.NoriRealityEngine;
import com.nori.jarvis.nori.brain.frontier.NoriAdvancedBrainEngine;
import com.nori.jarvis.nori.edgeai.NoriEdgeAiEngine;
import com.nori.jarvis.nori.library.NoriLibraryIndex;
import com.nori.jarvis.nori.knowledge.NoriKnowledgeSourceRegistry;
import com.nori.jarvis.nori.learning.NoriAutonomousLearningEngine;
import com.nori.jarvis.nori.knowledge.NoriSubjectMasteryRegistry;
import com.nori.jarvis.nori.knowledge.NoriTeachingPersonality;
import java.util.*;

/**
 * Native Nori Brain coordinator.
 * Understands -> routes -> evaluates -> verifies -> returns a structured decision.
 * It does not silently write consequences or alter student data.
 */
public final class NoriBrain {
    private final IntentEngine intentEngine;
    private final ContextEngine contextEngine;
    private final KageEngine kageEngine;
    private final AcademicEngine academicEngine;
    private final ConsequencePolicy consequencePolicy;
    private final VerificationEngine verificationEngine;
    private final MemoryEngine memoryEngine;
    private final ActionEngine actionEngine;
    private final ToolRouter toolRouter;
    private final AiRouter aiRouter;
    private final EducationalIntelligence educationalIntelligence;
    private final IntegrityEngine integrityEngine;
    private final AdminControlPlane adminControlPlane;
    private final DocumentIntelligence documentIntelligence;
    private final WebIntelligence webIntelligence;
    private final AdvancedIntelligence advancedIntelligence;
    private final ConversationEngine conversationEngine;
    private final NoriSecurity security;
    private final NoriPerformance performance;
    private final NoriStateEngine stateEngine;
    private final ReasoningEngine reasoningEngine;
    private final com.nori.jarvis.nori.reasoning.GeneralReasoning generalReasoning;
    private final NoriScreenSemanticAnalyzer screenSemanticAnalyzer;
    private final HumanContextEngine humanContextEngine;
    private final NoriSupportPolicy supportPolicy;
    private final ResearchIntelligence researchIntelligence;
    private final ProviderFailureLedger providerFailureLedger;
    private final NoriProfileStore profileStore;
    private final ConversationHistoryStore conversationHistoryStore;
    private final NoriBrainCapacityEngine capacityEngine;
    private final NoriFrontierCapabilityEngine frontierCapabilityEngine;
    private final NoriCognitiveEngine cognitiveEngine;
    private final NoriConstitution constitution;
    private final NoriLearningLoop learningLoop;
    private final NoriStudentDevelopment studentDevelopment;
    private final NoriDecisionPlanningEngine decisionPlanningEngine;
    private final NoriInterventionEngine interventionEngine;
    private final NoriConversationIntelligence conversationIntelligence;
    private final NoriLanguageIntelligence languageIntelligence;
    private final NoriToolCoordinationEngine toolCoordinationEngine;
    private final NoriKnowledgeVerificationEngine knowledgeVerificationEngine;
    private final NoriModelCouncil modelCouncil;
    private final NoriLearningEvolutionEngine learningEvolutionEngine;
    private final NoriDiagnosticsEngine diagnosticsEngine;
    private final NoriCognitiveStateOutcomeLoop cognitiveStateOutcomeLoop;
    private final NoriStudyStrategyEngine studyStrategyEngine;
    private final NoriGoalDecompositionEngine goalDecompositionEngine;
    private final NoriEnergyScheduleEngine energyScheduleEngine;
    private final NoriBackgroundPreparationQueue backgroundPreparationQueue;
    private final NoriCommandChainEngine commandChainEngine;
    private final NoriInterruptAwareFocusEngine interruptAwareFocusEngine;
    private final NoriReasoningNarrator reasoningNarrator;
    private final NoriScenarioEngine scenarioEngine;
    private final NoriPreemptiveResourceEngine preemptiveResourceEngine;
    private final NoriAppUnderstandingEngine appUnderstandingEngine;
    private final NoriUserControlEngine userControlEngine;
    private final NoriFunctionalExecutionCore functionalExecutionCore;
    private final NoriWorldIntelligence worldIntelligence;
    private final NoriWorldWebConnector worldWebConnector;
    private final NoriHumanGrowthEngine humanGrowthEngine;
    private final NoriYouthMediaSafety youthMediaSafety;
    private final NoriImageGenerationEngine imageGenerationEngine;
    private final NoriPdfGenerationEngine pdfGenerationEngine;
    private final NoriCreativeIntentEngine creativeIntentEngine;
    private final NoriOperationalCore operationalCore;
    private final NoriRealityEngine realityEngine;
    private final NoriAdvancedBrainEngine advancedBrainEngine;
    private final NoriEdgeAiEngine edgeAiEngine;
    private final NoriMetaBrainEngine metaBrainEngine;
    private final com.nori.jarvis.nori.meta.NoriMetaBrainOrchestrator metaBrainOrchestrator;
    private final NoriPersonalWorldModel personalWorldModel;
    private final NoriCausalCounterfactualEngine causalCounterfactualEngine;
    private final NoriAdvancedLearningEngine advancedLearningEngine;
    private final NoriResearchBrain2 researchBrain2;
    private final NoriHumanContext2 humanContext2;
    private final NoriExecutionLifecycle executionLifecycle;
    private final NoriFailureRecoveryEngine failureRecoveryEngine;
    private final NoriRuntimeTelemetry runtimeTelemetry;
    private final NoriLongSessionMonitor longSessionMonitor;
    private final NoriModelSelectionEngine modelSelectionEngine;
    private final NoriLiveWebRetrieval liveWebRetrieval;
    private final NoriIntegrationBenchmark integrationBenchmark;
    private final NoriLibraryIndex libraryIndex;
    private final NoriKnowledgeSourceRegistry knowledgeSources;
    private final NoriAutonomousLearningEngine autonomousLearningEngine;
    private final NoriSubjectMasteryRegistry subjectMasteryRegistry;
    private final NoriTeachingPersonality teachingPersonality;

    public NoriBrain() { this(null); }

    public NoriBrain(DataRepository repository) {
        intentEngine=new IntentEngine(); contextEngine=new ContextEngine(); kageEngine=new KageEngine();
        academicEngine=new AcademicEngine(); consequencePolicy=new ConsequencePolicy(); verificationEngine=new VerificationEngine();
        memoryEngine=new MemoryEngine(repository);
        actionEngine=new ActionEngine(repository, permission -> false);
        new LocalAcademicTools().register(actionEngine);
        worldWebConnector=new NoriWorldWebConnector();
        new NoriWorldTools(worldWebConnector).register(actionEngine);
        toolRouter=new ToolRouter(actionEngine);
        // Local-first by construction: the real memory store is wired directly into
        // LocalAiProvider's thinking engine, so a local-only answer (default policy,
        // no network, no API key) is grounded in this student's actual saved memory
        // instead of a canned line. Remote providers remain fully optional — see
        // configureExternalAiProviders(), never called unless the caller explicitly
        // passes providers and userConsented=true.
        aiRouter=new AiRouter(
            new com.nori.jarvis.nori.ai.LocalAiProvider(new com.nori.jarvis.nori.ai.NoriLocalThinkingEngine(memoryEngine)),
            java.util.Collections.emptyList(),
            com.nori.jarvis.nori.ai.AiRoutingPolicy.localOnly());
        educationalIntelligence=new EducationalIntelligence(repository);
        integrityEngine=new IntegrityEngine();
        adminControlPlane=new AdminControlPlane(repository);
        documentIntelligence=new DocumentIntelligence();
        webIntelligence=new WebIntelligence();
        advancedIntelligence=new AdvancedIntelligence(educationalIntelligence);
        conversationEngine=new ConversationEngine();
        security=new NoriSecurity();
        performance=new NoriPerformance();
        stateEngine=new NoriStateEngine();
        reasoningEngine=new ReasoningEngine();
        generalReasoning=new com.nori.jarvis.nori.reasoning.GeneralReasoning();
        screenSemanticAnalyzer=new NoriScreenSemanticAnalyzer(aiRouter);
        humanContextEngine=new HumanContextEngine();
        supportPolicy=new NoriSupportPolicy();
        researchIntelligence=new ResearchIntelligence();
        providerFailureLedger=new ProviderFailureLedger(repository);
        profileStore=new NoriProfileStore(repository);
        conversationHistoryStore=new ConversationHistoryStore(repository);
        capacityEngine=new NoriBrainCapacityEngine();
        frontierCapabilityEngine=new NoriFrontierCapabilityEngine();
        cognitiveEngine=new NoriCognitiveEngine();
        constitution=new NoriConstitution();
        learningLoop=new NoriLearningLoop();
        studentDevelopment=new NoriStudentDevelopment();
        decisionPlanningEngine=new NoriDecisionPlanningEngine();
        interventionEngine=new NoriInterventionEngine();
        conversationIntelligence=new NoriConversationIntelligence(this);
        languageIntelligence=new NoriLanguageIntelligence();
        toolCoordinationEngine=new NoriToolCoordinationEngine(this);
        knowledgeVerificationEngine=new NoriKnowledgeVerificationEngine();
        modelCouncil=new NoriModelCouncil();
        learningEvolutionEngine=new NoriLearningEvolutionEngine();
        diagnosticsEngine=new NoriDiagnosticsEngine();
        cognitiveStateOutcomeLoop=new NoriCognitiveStateOutcomeLoop(this);
        studyStrategyEngine=new NoriStudyStrategyEngine();
        goalDecompositionEngine=new NoriGoalDecompositionEngine();
        energyScheduleEngine=new NoriEnergyScheduleEngine();
        backgroundPreparationQueue=new NoriBackgroundPreparationQueue();
        commandChainEngine=new NoriCommandChainEngine();
        interruptAwareFocusEngine=new NoriInterruptAwareFocusEngine();
        reasoningNarrator=new NoriReasoningNarrator();
        scenarioEngine=new NoriScenarioEngine();
        preemptiveResourceEngine=new NoriPreemptiveResourceEngine();
        appUnderstandingEngine=new NoriAppUnderstandingEngine();
        userControlEngine=new NoriUserControlEngine();
        executionLifecycle=new NoriExecutionLifecycle();
        functionalExecutionCore=new NoriFunctionalExecutionCore(toolRouter,userControlEngine,executionLifecycle);
        worldIntelligence=new NoriWorldIntelligence();
        humanGrowthEngine=new NoriHumanGrowthEngine();
        youthMediaSafety=new NoriYouthMediaSafety();
        imageGenerationEngine=new NoriImageGenerationEngine(youthMediaSafety);
        pdfGenerationEngine=new NoriPdfGenerationEngine();
        creativeIntentEngine=new NoriCreativeIntentEngine();
        operationalCore=new NoriOperationalCore(repository);
        new com.nori.jarvis.nori.actions.NoriOperationalTools(operationalCore).register(actionEngine);
        realityEngine=new NoriRealityEngine(actionEngine);
        advancedBrainEngine=new NoriAdvancedBrainEngine(webIntelligence);
        edgeAiEngine=new NoriEdgeAiEngine();
        metaBrainEngine=new NoriMetaBrainEngine();
        metaBrainOrchestrator=new com.nori.jarvis.nori.meta.NoriMetaBrainOrchestrator(this);
        personalWorldModel=new NoriPersonalWorldModel(repository);
        causalCounterfactualEngine=new NoriCausalCounterfactualEngine();
        advancedLearningEngine=new NoriAdvancedLearningEngine();
        researchBrain2=new NoriResearchBrain2();
        humanContext2=new NoriHumanContext2();
        failureRecoveryEngine=new NoriFailureRecoveryEngine();
        runtimeTelemetry=new NoriRuntimeTelemetry();
        longSessionMonitor=new NoriLongSessionMonitor(runtimeTelemetry);
        modelSelectionEngine=new NoriModelSelectionEngine(edgeAiEngine.registry());
        liveWebRetrieval=new NoriLiveWebRetrieval();
        integrationBenchmark=new NoriIntegrationBenchmark();
        libraryIndex=new NoriLibraryIndex(repository);
        knowledgeSources=new NoriKnowledgeSourceRegistry();
        autonomousLearningEngine=new NoriAutonomousLearningEngine(knowledgeSources);
        subjectMasteryRegistry=new NoriSubjectMasteryRegistry();
        teachingPersonality=new NoriTeachingPersonality();
        aiRouter.setFailureListener(providerFailureLedger);
        security.reliability().initialize(true);
        stateEngine.refresh(educationalIntelligence, memoryEngine, conversationEngine.state(), security, performance);
    }
    public IntentEngine getIntentEngine(){return intentEngine;}
    public ContextEngine getContextEngine(){return contextEngine;}
    public KageEngine getKageEngine(){return kageEngine;}
    public AcademicEngine getAcademicEngine(){return academicEngine;}
    public VerificationEngine getVerificationEngine(){return verificationEngine;}
    public MemoryEngine getMemoryEngine(){return memoryEngine;}
    public PersonalModel getPersonalModel(){return memoryEngine.personalModel();}
    public ActionEngine getActionEngine(){return actionEngine;}
    public ToolRouter getToolRouter(){return toolRouter;}
    public AiRouter getAiRouter(){return aiRouter;}
    public EducationalIntelligence getEducationalIntelligence(){return educationalIntelligence;}
    public IntegrityEngine getIntegrityEngine(){return integrityEngine;}
    public AdminControlPlane getAdminControlPlane(){return adminControlPlane;}
    public DocumentIntelligence getDocumentIntelligence(){return documentIntelligence;}
    public WebIntelligence getWebIntelligence(){return webIntelligence;}
    public AdvancedIntelligence getAdvancedIntelligence(){return advancedIntelligence;}
    /** Stage 17 bounded conversation session; it does not execute actions or persist recordings. */
    public ConversationEngine getConversationEngine(){return conversationEngine;}
    /** Stage 19 security/reliability boundary. */
    public NoriSecurity getSecurity(){return security;}
    /** Stage 21 performance/offline boundary; local core remains available without network. */
    public NoriPerformance getPerformance(){return performance;}
    /** Unified read-only state composed from existing engines; no domain data is replaced. */
    public NoriState getCurrentState(){ return stateEngine.refresh(educationalIntelligence, memoryEngine, conversationEngine.state(), security, performance); }
    public NoriStateEngine getStateEngine(){ return stateEngine; }
    /** Stage 2 structured evidence/reasoning layer. */
    public ReasoningEngine getReasoningEngine(){ return reasoningEngine; }
    /** General evidence→interpretation→confidence→decision reasoning; does not expose hidden chain-of-thought. */
    public com.nori.jarvis.nori.reasoning.GeneralReasoning.Result reason(List<com.nori.jarvis.nori.reasoning.Evidence> evidence,String requestedDecision,String temporalHint){ return generalReasoning.reason(evidence,requestedDecision,temporalHint); }
    public NoriScreenSemanticAnalyzer getScreenSemanticAnalyzer(){ return screenSemanticAnalyzer; }
    public HumanContextEngine getHumanContextEngine(){ return humanContextEngine; }
    public NoriSupportPolicy getSupportPolicy(){ return supportPolicy; }
    public ResearchIntelligence getResearchIntelligence(){ return researchIntelligence; }
    public ProviderFailureLedger getProviderFailureLedger(){ return providerFailureLedger; }
    public NoriProfileStore getProfileStore(){ return profileStore; }
    public ConversationHistoryStore getConversationHistoryStore(){ return conversationHistoryStore; }
    /** Post-14 capacity layer: fast local preflight, humane context, research gating and action verification. */
    public NoriBrainCapacityEngine getCapacityEngine(){ return capacityEngine; }
    /** Frontier capability planner: many modern AI capabilities behind one Nori Brain. */
    public NoriFrontierCapabilityEngine getFrontierCapabilityEngine(){ return frontierCapabilityEngine; }
    /** Step 19 cognitive core: compact, realistic decision structure without exposing private chain-of-thought. */
    public NoriCognitiveEngine getCognitiveEngine(){ return cognitiveEngine; }
    /** Constitution is the final narrowing authority shared by Brain pathways. */
    public NoriConstitution getConstitution(){ return constitution; }
    /** Stage 22: connects assessment, mastery, mistakes and study strategy into a longitudinal learning loop. */
    public NoriLearningLoop getLearningLoop(){ return learningLoop; }
    /** Stage 22: tracks capability development separately from academic scores. */
    public NoriStudentDevelopment getStudentDevelopment(){ return studentDevelopment; }
    /** Step 23: general goal/constraint/option/trade-off planning. */
    public NoriDecisionPlanningEngine getDecisionPlanningEngine(){ return decisionPlanningEngine; }
    /** Step 23: adaptive intervention timing/effectiveness/autonomy boundary. */
    public NoriInterventionEngine getInterventionEngine(){ return interventionEngine; }
    /** Step 24: conversation is interpreted against current state, governed memory, cognition and Constitution. */
    public NoriConversationIntelligence.Context understandConversation(String text, com.nori.jarvis.nori.conversation.model.VoiceMode mode, boolean externalAvailable, boolean userInitiatedAction){
        String q=text==null?"":text.trim();
        if(q.isEmpty()) throw new IllegalArgumentException("text required");
        conversationEngine.acceptUserText(q);
        cognitiveStateOutcomeLoop.observe("conversation_turn","conversation",q,"conversation_assistance",.98,true);
        cognitiveStateOutcomeLoop.run(q,"conversation_assistance",true);
        if(!q.isEmpty()) conversationHistoryStore.append("local-user","USER",q);
        return conversationIntelligence.understand(q,mode,externalAvailable,userInitiatedAction);
    }
    public NoriConversationIntelligence getConversationIntelligence(){ return conversationIntelligence; }
    public NoriLanguageIntelligence getLanguageIntelligence(){ return languageIntelligence; }
    /** Step 24: coordinates an existing tool proposal with Brain state/memory/Constitution; execution remains ActionEngine-owned. */
    public NoriToolCoordinationEngine.Result coordinateTool(com.nori.jarvis.nori.actions.model.ToolRequest request,String userRequest,boolean externalAvailable){ return toolCoordinationEngine.prepare(userRequest,request,externalAvailable); }
    public NoriToolCoordinationEngine getToolCoordinationEngine(){ return toolCoordinationEngine; }
    public NoriKnowledgeVerificationEngine getKnowledgeVerificationEngine(){ return knowledgeVerificationEngine; }
    public NoriModelCouncil getModelCouncil(){ return modelCouncil; }
    public NoriLearningEvolutionEngine getLearningEvolutionEngine(){ return learningEvolutionEngine; }
    public NoriDiagnosticsEngine getDiagnosticsEngine(){ return diagnosticsEngine; }
    public NoriCognitiveStateOutcomeLoop getCognitiveStateOutcomeLoop(){return cognitiveStateOutcomeLoop;}
    public NoriStudyStrategyEngine getStudyStrategyEngine(){return studyStrategyEngine;}
    public NoriGoalDecompositionEngine getGoalDecompositionEngine(){return goalDecompositionEngine;}
    public NoriEnergyScheduleEngine getEnergyScheduleEngine(){return energyScheduleEngine;}
    public NoriBackgroundPreparationQueue getBackgroundPreparationQueue(){return backgroundPreparationQueue;}
    public NoriCommandChainEngine getCommandChainEngine(){return commandChainEngine;}
    public NoriInterruptAwareFocusEngine getInterruptAwareFocusEngine(){return interruptAwareFocusEngine;}
    public NoriReasoningNarrator getReasoningNarrator(){return reasoningNarrator;}
    public NoriScenarioEngine getScenarioEngine(){return scenarioEngine;}
    public NoriPreemptiveResourceEngine getPreemptiveResourceEngine(){return preemptiveResourceEngine;}
    /** Step 27: Nori understands its own app as a searchable capability graph; understanding never authorizes action. */
    public NoriAppUnderstandingEngine getAppUnderstandingEngine(){return appUnderstandingEngine;}
    public NoriAppUnderstandingEngine.Result understandNoriApp(String text){return appUnderstandingEngine.understand(text);}
    /** Step 27: explicit action firewall. Background/system-initiated actions are not silently authorized. */
    public NoriUserControlEngine getUserControlEngine(){return userControlEngine;}
    public NoriUserControlEngine.Decision authorizeNoriAction(NoriUserControlEngine.Request request){return userControlEngine.evaluate(request);}
    /** End-to-end lifecycle over registered ActionEngine handlers; does not bypass existing safety gates. */
    public NoriFunctionalExecutionCore getFunctionalExecutionCore(){return functionalExecutionCore;}
    public NoriWorldIntelligence getWorldIntelligence(){return worldIntelligence;}
    /** Live public-web connector for news, weather, trends and general search. */
    public NoriWorldWebConnector getWorldWebConnector(){return worldWebConnector;}
    public NoriHumanGrowthEngine getHumanGrowthEngine(){return humanGrowthEngine;}
    public NoriYouthMediaSafety getYouthMediaSafety(){return youthMediaSafety;}
    public NoriImageGenerationEngine getImageGenerationEngine(){return imageGenerationEngine;}
    public NoriPdfGenerationEngine getPdfGenerationEngine(){return pdfGenerationEngine;}
    public NoriCreativeIntentEngine getCreativeIntentEngine(){return creativeIntentEngine;}
    public NoriKnowledgeVerificationEngine.Report verifyKnowledge(List<String> claims,List<NoriKnowledgeVerificationEngine.SourceCheck> sources){ return knowledgeVerificationEngine.verifyClaims(claims,sources); }
    public NoriKnowledgeVerificationEngine.Report resolveKnowledgeConflicts(List<String> statements){ return knowledgeVerificationEngine.resolveConflicts(statements); }
    public NoriModelCouncil.Result consultModelCouncil(String prompt,List<com.nori.jarvis.nori.ai.AiProvider> providers){ return modelCouncil.consult(prompt,providers,8000); }
    public NoriLearningEvolutionEngine.Report evaluateEvolution(){ return learningEvolutionEngine.evaluate(); }
    public NoriDecisionPlanningEngine.Plan planGoal(NoriDecisionPlanningEngine.Goal goal, List<NoriDecisionPlanningEngine.Constraint> constraints, List<NoriDecisionPlanningEngine.Option> options){
        return decisionPlanningEngine.plan(goal,constraints,options);
    }
    public NoriInterventionEngine.Proposal decideIntervention(NoriInterventionEngine.Signal signal,String preference,List<NoriInterventionEngine.PreferenceOutcome> known,boolean protectedWindow){
        return interventionEngine.decide(signal,preference,known,protectedWindow);
    }

    public NoriLearningLoop.LongitudinalReport evaluateLearning(){ return learningLoop.evaluate(educationalIntelligence); }
    public NoriLearningLoop.InterventionOutcome evaluateIntervention(String subject,String strategy,int window){ return learningLoop.compareIntervention(educationalIntelligence,subject,strategy,window); }
    public NoriStudentDevelopment.DevelopmentReport evaluateStudentDevelopment(){ return studentDevelopment.assess(); }
    /** Decision-time memory: retrieves only a small governed working set; no new persistence occurs. */
    public NoriMemoryContext buildMemoryContext(String query, int limit){ return NoriMemoryContext.build(memoryEngine, query, limit); }
    /** Unified cognitive preflight: cognition + memory + constitution before model/tool work. */
    public CognitivePreflight preflight(String prompt, boolean externalAvailable, boolean userInitiatedAction){
        String q=prompt==null?"":prompt;
        NoriMemoryContext memory=buildMemoryContext(q, 6);
        NoriCognitiveEngine.ThoughtState thought=cognitiveEngine.think(q, memory.compactContext, externalAvailable, userInitiatedAction);
        NoriConstitution.Decision constitutional=constitution.evaluate(thought.intent.name(), q, null, userInitiatedAction, false);
        return new CognitivePreflight(thought, memory, constitutional);
    }
    public NoriCognitiveEngine.ThoughtState think(String prompt, String contextSummary, boolean externalAvailable, boolean userInitiatedAction){
        return cognitiveEngine.think(prompt, contextSummary, externalAvailable, userInitiatedAction);
    }
    /** Unified-state-aware cognitive entry point. */
    public NoriCognitiveEngine.ThoughtState think(String prompt, NoriState state){
        String summary=state==null?"":("availability="+state.situation.availability+";activity="+state.situation.activity+";study="+state.study.status+";exam="+state.exam.status+";recentEvents="+state.recentEvents.size());
        return cognitiveEngine.think(prompt, summary, false, false);
    }
    /** Fast frontier preflight for feature-rich requests; does not execute actions. */
    public NoriFrontierCapabilityEngine.Plan planFrontierCapabilities(String prompt, boolean externalAvailable, boolean userInitiatedAction){
        return frontierCapabilityEngine.plan(prompt, externalAvailable, userInitiatedAction);
    }

    /** Configure ordered external capabilities. Nori remains local-first. */
    public void configureExternalAiProviders(List<com.nori.jarvis.nori.ai.AiProvider> providers, boolean userConsented){
        aiRouter.configureProviders(providers, userConsented ? com.nori.jarvis.nori.ai.AiRoutingPolicy.localFirst() : com.nori.jarvis.nori.ai.AiRoutingPolicy.localOnly());
    }

    /** Human-context assessment without requiring the student to disclose private causes. */
    public com.nori.jarvis.nori.brain.human.NoriHumanAssessment assessAndChooseSupport(String message,int recentMisses,int recentSuccessfulStarts,boolean reportedDifficulty,boolean askedForAnalysis){
        var a=humanContextEngine.assess(message,recentMisses,recentSuccessfulStarts,reportedDifficulty);
        var g=supportPolicy.decide(a,askedForAnalysis);
        return new com.nori.jarvis.nori.brain.human.NoriHumanAssessment(a,g,"strict_on_important_goals_flexible_on_route_and_never_require_unnecessary_disclosure");
    }

    /** Non-clinical situation assessment. It does not require personal disclosure. */
    public HumanContextEngine.Assessment assessHumanContext(String message,int recentMisses,int recentSuccessfulStarts,boolean userReportedDifficulty){
        return humanContextEngine.assess(message,recentMisses,recentSuccessfulStarts,userReportedDifficulty);
    }
    public NoriSupportPolicy.Guidance chooseSupport(HumanContextEngine.Assessment assessment,boolean userAskedForAnalysis){
        return supportPolicy.decide(assessment,userAskedForAnalysis);
    }

    /** Fast Brain-connected screen analysis. Local classification is returned immediately; provider vision is optional. */
    public BrainScreenDecision analyzeScreenEvidence(String packageName, String trigger, String confidence, String imageBase64, String subject) {
        NoriScreenSemanticAnalyzer.Result r=screenSemanticAnalyzer.analyze(packageName,trigger,confidence,imageBase64,subject);
        List<Evidence> ev=new ArrayList<>();
        ev.add(new Evidence("screen", "foreground_package="+(packageName==null?"":packageName), Evidence.Kind.FACT, Evidence.Strength.STRONG));
        ev.add(new Evidence("screen", "trigger="+(trigger==null?"":trigger), Evidence.Kind.CONTEXT, Evidence.Strength.MODERATE));
        String c=r.classification==null?"UNKNOWN_SCREEN":r.classification;
        boolean review="UNKNOWN_SCREEN".equals(c)||"VISION_REVIEW".equals(c);
        return new BrainScreenDecision(r,"Screen evidence classified as "+c+"; intent is not inferred from the frame alone.",ev,review);
    }

    /** Stage 13 hard safety gate for any proposed consequence. */
    public ConsequenceSafetyGuard.Check checkConsequenceSafety(String id, String label, String description, String domain, boolean physical){
        return ConsequenceSafetyGuard.check(id,label,description,domain,physical);
    }

    /** Optional AI path. Local mode is the default and requires no network/provider. */
    public AiResponse askOptionalAi(AiRequest request){
        if(request==null) throw new IllegalArgumentException("request required");
        NoriMemoryContext memory=buildMemoryContext(request.prompt, 6);
        NoriCognitiveEngine.ThoughtState thought=cognitiveEngine.think(request.prompt, memory.compactContext, request.requiresExternalIntelligence(), false);
        NoriConstitution.Decision constitutional=constitution.evaluate(thought.intent.name(), request.prompt, null, false, false);
        if(constitutional.verdict==NoriConstitution.Verdict.BLOCK) return AiResponse.blocked("constitution", "protected_system_boundary");
        String system=(request.systemInstruction==null?"":request.systemInstruction);
        String enriched=system + "\n\n" + constitution.systemContract() +
                "\nDecision mode="+thought.answerShape.name()+"; effort="+thought.effort.name()+"; confidence="+thought.confidence.name()+
                (memory.compactContext.isEmpty()?"":"\nRelevant user memory (use only when relevant; treat uncertain items as uncertain): "+memory.compactContext);
        if(memory.conflictDetected) enriched += "\nMemory warning: conflicting remembered items exist; prefer newer/higher-confidence evidence and do not state a conflict as settled fact.";
        if(memory.staleRisk) enriched += "\nMemory warning: some relevant memories may be stale; verify before relying on them for consequential decisions.";
        return aiRouter.generate(new AiRequest(request.prompt, enriched, request.metadata, request.maxOutputCharacters));
    }

    /** Stage 9: create a controlled action proposal. It never executes. */
    public ActionProposal proposeAction(ToolRequest request, String reason, List<String> evidence) {
        if(request==null) throw new IllegalArgumentException("tool request required");
        StringBuilder actionText=new StringBuilder(request.toolId==null?"":request.toolId);
        for(Map.Entry<String,String> e:request.input.entrySet()) actionText.append(' ').append(e.getKey()).append('=').append(e.getValue());
        NoriConstitution.Decision gate=constitution.evaluate("tool_action", actionText.toString(), null, true, false);
        ActionProposal proposal=toolRouter.propose(request, reason, evidence);
        if(gate.verdict==NoriConstitution.Verdict.BLOCK){ proposal.status=com.nori.jarvis.nori.actions.model.ActionStatus.CANCELLED; proposal.failureReason=String.join(",",gate.reasons); }
        return proposal;
    }

    public NoriConstitution.Decision checkActionConstitution(ToolRequest request, boolean userInitiated){
        if(request==null) return new NoriConstitution.Decision(NoriConstitution.Verdict.BLOCK, Collections.singletonList(NoriConstitution.Principle.SAFETY), Collections.singletonList("missing_tool_request"), "reject_incomplete_action");
        StringBuilder b=new StringBuilder(request.toolId==null?"":request.toolId);
        for(Map.Entry<String,String> e:request.input.entrySet()) b.append(' ').append(e.getKey()).append('=').append(e.getValue());
        return constitution.evaluate("tool_action", b.toString(), null, userInitiated, false);
    }

    /** Stage 8 explicit memory command path. No inferred memory is saved. */
    public MemoryDecision remember(String text) {
        if (!memoryEngine.isAllowed(text)) return new MemoryDecision(MemoryDecision.Type.REJECTED, false, memoryEngine.rejectionReason(text), null);
        MemoryItem item=memoryEngine.remember(text);
        return new MemoryDecision(MemoryDecision.Type.REMEMBER, item!=null, item==null?"not_persisted":null, item==null?null:java.util.Collections.singletonList(item));
    }

    public MemoryDecision recall(String query, int limit) {
        return new MemoryDecision(MemoryDecision.Type.RECALL, false, null, memoryEngine.recall(query, limit));
    }

    /** Stage 7 core path corresponding to V32 processAcademicEvent(). */
    public BrainDecision processAcademicEvent(AcademicEventInput input) {
        if(input==null || input.assessment==null || input.contextEvent==null) throw new IllegalArgumentException("Academic event input is incomplete");
        String eventId="nori-"+UUID.randomUUID();
        var academic=academicEngine.analyzeAssessment(input.assessment);
        educationalIntelligence.recordEvidence(new AcademicEvidence(input.subject, "", input.assessment.getPercentage(), input.assessment.getMissedConcepts(), input.assessment.getCarelessErrorCount(), input.assessment.getApplicationErrorCount(), java.time.LocalDateTime.now()));
        double normalizedScore=Math.max(0,Math.min(1,input.assessment.getPercentage()/100.0));
        studentDevelopment.observe(NoriStudentDevelopment.Capability.KNOWLEDGE, normalizedScore, "assessment_result");
        studentDevelopment.observe(NoriStudentDevelopment.Capability.SELF_CORRECTION, input.assessment.getMissedConcepts().isEmpty()?1.0:Math.max(0.0,1.0-input.assessment.getMissedConcepts().size()/10.0), "assessment_error_pattern");
        var context=contextEngine.classifyContext(input.contextEvent);
        stateEngine.observeContext(context, false);
        var secondary=input.secondaryContextEvent==null?null:contextEngine.classifyContext(input.secondaryContextEvent);
        boolean academicIssue=academic.getBand()!=null;
        boolean disciplinary=context.breachEligible;
        var failure=kageEngine.classifyFailure(academicIssue,disciplinary);
        var degree=kageEngine.determineDegree(input.unresolvedDegree1,input.sameDomainRepeat,input.degree1Total,failure,context.type.value());

        List<String> candidates=Collections.emptyList();
        if(context.breachEligible){
            candidates=consequencePolicy.selectCandidates(candidateIdsForDomain(input.contextEvent.domain),academic.getBand(),degree.degree,input.priorIneffectiveIds);
        }
        String correction=academic.getBand()==null?null:academicCorrectionFor(academic.getErrorDistribution());
        var verification=verificationEngine.verifyAcademicEvent(academic!=null,context!=null,failure!=null,degree!=null);

        List<String> facts=new ArrayList<>();
        facts.add("assessment="+academic.getType()); facts.add("score="+academic.getPercentage());
        facts.add("context="+context.type.value()); facts.add("context_confidence="+context.confidence.name().toLowerCase(Locale.ROOT));
        List<String> inferences=new ArrayList<>();
        inferences.add("failure_type="+failure.name().toLowerCase(Locale.ROOT));
        inferences.add("degree="+degree.degree);
        List<String> next=new ArrayList<>();
        if(correction!=null) next.add("academic_correction:"+correction);
        if(!candidates.isEmpty()) next.add("review_consequence_candidates_before_action");
        if(!verification.isVerified()) next.add("resolve_verification_issues");
        if(next.isEmpty()) next.add("no_action_required_from_kage_for_this_event");
        NoriMemoryContext memoryContext=buildMemoryContext(input.subject + " " + (correction==null?"":correction), 4);
        stateEngine.refresh(educationalIntelligence, memoryEngine, conversationEngine.state(), security, performance);
        List<Evidence> evidence = new ArrayList<>();
        evidence.add(new Evidence("assessment", "assessment=" + academic.getType(), Evidence.Kind.FACT, Evidence.Strength.STRONG));
        evidence.add(new Evidence("assessment", "score=" + academic.getPercentage(), Evidence.Kind.FACT, Evidence.Strength.STRONG));
        evidence.add(new Evidence("context", "context=" + context.type.value(), Evidence.Kind.CONTEXT,
                context.confidence == ContextEngine.Confidence.CONFIRMED ? Evidence.Strength.STRONG :
                context.confidence == ContextEngine.Confidence.PROBABLE ? Evidence.Strength.MODERATE : Evidence.Strength.WEAK));
        if(!memoryContext.memories.isEmpty()) evidence.add(new Evidence("memory", "relevant_memory_count="+memoryContext.memories.size(), Evidence.Kind.CONTEXT, memoryContext.conflictDetected?Evidence.Strength.WEAK:Evidence.Strength.MODERATE));
        List<String> assumptions = new ArrayList<>();
        if (memoryContext.conflictDetected) assumptions.add("relevant memory contains conflicting items; do not treat it as settled fact");
        if (memoryContext.staleRisk) assumptions.add("some relevant memory may be stale");
        if (context.confidence == ContextEngine.Confidence.UNCLEAR) assumptions.add("context classification is uncertain");
        if (!verification.isVerified()) assumptions.add("verification is incomplete");
        String conclusion = correction == null ? "No academic correction identified from this event." : "Academic correction: " + correction;
        var reasoning = reasoningEngine.summarize(evidence, assumptions, conclusion, context, verification);
        return new BrainDecision(eventId,academic,context,secondary,failure,degree,candidates,correction,verification,facts,inferences,next,reasoning);
    }

    private List<String> candidateIdsForDomain(String domain){
        if(domain==null) return Collections.emptyList();
        switch(domain){
            case "gaming": return Arrays.asList("protected_hour_gaming_lock","online_game_restriction","gaming_suspension_full");
            case "academic_rabbit_hole": return Arrays.asList("curiosity_reserve","research_queue","academic_purpose_only_research");
            case "creative_hobby": return Arrays.asList("hobby_scheduling_restriction","project_queue","optional_hobby_suspension");
            case "planning_system": return Arrays.asList("plan_freeze");
            default: return Collections.emptyList();
        }
    }
    private String academicCorrectionFor(com.nori.jarvis.nori.academic.model.AcademicAnalysisResult.ErrorDistribution distribution){
        switch(distribution){
            case LOCALIZED_WEAKNESS: return "targeted_reteaching";
            case BROAD_ACADEMIC_WEAKNESS: return "retrieval_practice_set";
            case EXECUTION_ERROR: return "error_autopsy";
            case CARELESS_ERROR_PATTERN: return "error_autopsy";
            default: return "targeted_reteaching";
        }
    }
    public NoriOperationalCore getOperationalCore(){ return operationalCore; }
    public NoriRealityEngine getRealityEngine(){ return realityEngine; }
    /** Step 32 frontier local orchestration: adaptive thinking, 30+ capability families and bounded parallel research. */
    public NoriAdvancedBrainEngine getAdvancedBrainEngine(){ return advancedBrainEngine; }
    public NoriAdvancedBrainEngine.ThoughtPlan thinkAdvanced(String prompt,String context,boolean externalAvailable,boolean userInitiatedAction){ return advancedBrainEngine.think(prompt,context,externalAvailable,userInitiatedAction); }
    public NoriAdvancedBrainEngine.ResearchReport researchSources(String question,List<String> urls){ return advancedBrainEngine.research(question,urls); }

    public static final class CognitivePreflight {
        public final NoriCognitiveEngine.ThoughtState thought;
        public final NoriMemoryContext memory;
        public final NoriConstitution.Decision constitution;
        public CognitivePreflight(NoriCognitiveEngine.ThoughtState t, NoriMemoryContext m, NoriConstitution.Decision c){thought=t;memory=m;constitution=c;}
    }

    /** Optional on-device AI runtime registry; never bypasses Nori Brain or ActionEngine. */
    public NoriEdgeAiEngine getEdgeAiEngine(){ return edgeAiEngine; }
    /** Step 34: one supervisory brain coordinating the 30 new capability families. */
    public NoriMetaBrainEngine getMetaBrainEngine(){ return metaBrainEngine; }
    public NoriMetaBrainEngine.ThoughtPlan thinkMeta(String request, String context, boolean externalAvailable, boolean userInitiated, boolean freshDataRequested, NoriMetaBrainEngine.Capacity capacity){
        return metaBrainEngine.think(request, context, externalAvailable, userInitiated, freshDataRequested, capacity);
    }
    /** Step 35: executes one integrated Meta-Brain cognitive cycle without performing side effects itself. */
    public com.nori.jarvis.nori.meta.NoriMetaBrainOrchestrator getMetaBrainOrchestrator(){ return metaBrainOrchestrator; }
    public com.nori.jarvis.nori.meta.NoriMetaBrainOrchestrator.Cycle processMetaBrain(String request,String context,boolean externalAvailable,boolean userInitiated,boolean freshRequested,NoriMetaBrainEngine.Capacity capacity){
        String q=request==null?"":request.trim();
        if(!q.isEmpty()){
            cognitiveStateOutcomeLoop.observe("request","meta_brain",q,"assistance",.98,userInitiated);
            cognitiveStateOutcomeLoop.run(q,"assistance",userInitiated);
            evaluateLearning();
        }
        return metaBrainOrchestrator.process(q,context,externalAvailable,userInitiated,freshRequested,capacity);
    }
    public NoriPersonalWorldModel getPersonalWorldModel(){return personalWorldModel;}
    public NoriCausalCounterfactualEngine getCausalCounterfactualEngine(){return causalCounterfactualEngine;}
    public NoriAdvancedLearningEngine getAdvancedLearningEngine(){return advancedLearningEngine;}
    public NoriResearchBrain2 getResearchBrain2(){return researchBrain2;}
    public NoriHumanContext2 getHumanContext2(){return humanContext2;}
    public NoriExecutionLifecycle getExecutionLifecycle(){return executionLifecycle;}
    public NoriFailureRecoveryEngine getFailureRecoveryEngine(){return failureRecoveryEngine;}
    public NoriRuntimeTelemetry getRuntimeTelemetry(){return runtimeTelemetry;}
    public NoriLongSessionMonitor getLongSessionMonitor(){return longSessionMonitor;}
    public NoriModelSelectionEngine getModelSelectionEngine(){return modelSelectionEngine;}
    public NoriLiveWebRetrieval getLiveWebRetrieval(){return liveWebRetrieval;}
    public NoriIntegrationBenchmark getIntegrationBenchmark(){return integrationBenchmark;}
    public NoriLibraryIndex getLibraryIndex(){return libraryIndex;}
    public NoriKnowledgeSourceRegistry getKnowledgeSources(){return knowledgeSources;}
    public NoriAutonomousLearningEngine getAutonomousLearningEngine(){return autonomousLearningEngine;}
    public NoriSubjectMasteryRegistry getSubjectMasteryRegistry(){return subjectMasteryRegistry;}
    public NoriTeachingPersonality getTeachingPersonality(){return teachingPersonality;}

}
