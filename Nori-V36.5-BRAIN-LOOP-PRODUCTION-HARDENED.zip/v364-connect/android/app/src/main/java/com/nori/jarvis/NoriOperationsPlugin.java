package com.nori.jarvis;

import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.nori.jarvis.nori.NoriNativeCore;
import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.actions.model.*;
import com.nori.jarvis.nori.understanding.NoriUserControlEngine;
import com.nori.jarvis.nori.data.NativeDataRepository;
import java.util.*;
import java.util.concurrent.*;

/** Capacitor bridge for Nori's local operating core. All mutations pass through Brain -> ActionEngine. */
@CapacitorPlugin(name="NoriOperations")
public final class NoriOperationsPlugin extends Plugin {
    private ExecutorService executor; private NativeDataRepository repository; private NoriBrain brain;
    @Override public void load(){repository=new NativeDataRepository(getContext().getApplicationContext());brain=new NoriNativeCore(repository).getBrain();executor=Executors.newFixedThreadPool(2);}
    private void action(PluginCall c,String tool,Map<String,String> in,boolean consequential){executor.execute(()->{try{
        long started=System.currentTimeMillis(); NoriUserControlEngine.Origin origin=NoriUserControlEngine.Origin.USER_DIRECT;
        var p=brain.getFunctionalExecutionCore().prepare(new ToolRequest(tool,in),"User explicitly requested Nori operation",Collections.singletonList("user_request"),origin,consequential,false,false,"nori_operations","");
        if(p.proposal==null){c.resolve(out(false,false,"",p.authorization.reason));return;}
        if(!p.preview.allowed){c.resolve(out(false,false,p.proposal.id,p.preview.reason));return;}
        if(p.authorization.status==NoriUserControlEngine.Status.NEEDS_CONFIRMATION){c.resolve(out(false,false,p.proposal.id,"confirmation_required"));return;}
        var r=brain.getFunctionalExecutionCore().confirmAndExecute(p.proposal.id,"human_user_request"); long elapsed=System.currentTimeMillis()-started; brain.getLongSessionMonitor().request("action:"+tool,elapsed,r.ok&&r.verified); JSObject rr=result(r); rr.put("latencyMs",elapsed); c.resolve(rr);
    }catch(Exception e){c.resolve(out(false,false,"",e.getClass().getSimpleName()));}});}
    @PluginMethod public void capabilities(PluginCall c){JSArray a=new JSArray();for(var x:brain.getOperationalCore().capabilityTruths()){JSObject o=new JSObject();o.put("id",x.id);o.put("label",x.label);o.put("status",x.status.name());o.put("reason",x.reason);a.put(o);}JSObject r=new JSObject();r.put("capabilities",a);c.resolve(r);}
    @PluginMethod public void commandCenter(PluginCall c){JSObject r=new JSObject();var o=brain.getOperationalCore();r.put("openCount",o.openRecords().size());r.put("storedCount",o.records().size());r.put("checkIns",o.checkins().size());r.put("timelineCount",o.timeline().size());c.resolve(r);}
    @PluginMethod public void addTask(PluginCall c){action(c,"ops_add_task",map(c),true);} 
    @PluginMethod public void addAssignment(PluginCall c){action(c,"ops_add_assignment",map(c),true);} 
    @PluginMethod public void addExam(PluginCall c){action(c,"ops_add_exam",map(c),true);} 
    @PluginMethod public void complete(PluginCall c){Map<String,String>m=new LinkedHashMap<>();m.put("id",c.getString("id",""));action(c,"ops_complete",m,true);} 
    @PluginMethod public void checkIn(PluginCall c){action(c,"ops_checkin",map(c),false);} 
    @PluginMethod public void recover(PluginCall c){action(c,"ops_recover",Collections.emptyMap(),false);} 
    @PluginMethod public void search(PluginCall c){Map<String,String>m=new LinkedHashMap<>();m.put("query",c.getString("query",""));action(c,"ops_search",m,false);} 
    @PluginMethod public void explain(PluginCall c){Map<String,String>m=new LinkedHashMap<>();m.put("recommendation",c.getString("recommendation","current recommendation"));action(c,"ops_explain",m,false);} 
    @PluginMethod public void exportData(PluginCall c){action(c,"ops_export",Collections.emptyMap(),false);} 
    @PluginMethod public void confirm(PluginCall c){executor.execute(()->{var r=brain.getFunctionalExecutionCore().confirmAndExecute(c.getString("proposalId",""),"human_user_confirmation");c.resolve(result(r));});}
    @PluginMethod public void plan(PluginCall c){String capacity=c.getString("capacity","UNKNOWN");var p=brain.getOperationalCore().buildAdaptivePlan(c.getString("goal","today"),c.getInt("maxSteps",6),capacity);JSObject r=new JSObject();r.put("ok",true);r.put("planId",p.id);r.put("state",p.state.name());JSArray steps=new JSArray();for(var x:p.steps){JSObject z=new JSObject();z.put("id",x.id);z.put("title",x.title);z.put("type",x.type);z.put("priority",x.priority);z.put("dueAt",x.dueAt);steps.put(z);}r.put("steps",steps);c.resolve(r);}
    private Map<String,String> map(PluginCall c){Map<String,String>m=new LinkedHashMap<>();for(String k:Arrays.asList("title","subject","dueAt","priority","details","capacity","activity","notes")){String v=c.getString(k,null);if(v!=null)m.put(k,v);}return m;}
    private JSObject result(ActionExecutionResult r){JSObject o=new JSObject();o.put("ok",r.ok);o.put("verified",r.verified);o.put("operationId",r.operationId);o.put("error",r.ok?"":String.valueOf(r.reason));if(r.result instanceof Map){for(Object k:((Map<?,?>)r.result).keySet())o.put(String.valueOf(k),String.valueOf(((Map<?,?>)r.result).get(k)));}return o;}
    private JSObject out(boolean ok,boolean v,String op,String err){JSObject o=new JSObject();o.put("ok",ok);o.put("verified",v);o.put("operationId",op);o.put("error",err==null?"":err);return o;}
    @Override protected void handleOnDestroy(){if(executor!=null)executor.shutdownNow();if(repository!=null)repository.close();super.handleOnDestroy();}
}
