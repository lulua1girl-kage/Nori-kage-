package com.nori.jarvis.nori.android.files;

import android.content.Context;
import android.net.Uri;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import java.io.InputStream;

/** Bounded local PDF text extraction for fast first-pass indexing. OCR is a separate, slower path. */
public final class NoriPdfFastExtractor {
    private final Context context; private volatile boolean initialized;
    public NoriPdfFastExtractor(Context c){context=c.getApplicationContext();}
    private synchronized void init(){if(!initialized){PDFBoxResourceLoader.init(context);initialized=true;}}
    public String extract(Uri uri,int maxPages)throws Exception{
        init(); try(InputStream in=context.getContentResolver().openInputStream(uri);PDDocument doc=PDDocument.load(in)){
            PDFTextStripper s=new PDFTextStripper();s.setStartPage(1);s.setEndPage(Math.min(maxPages,doc.getNumberOfPages()));return s.getText(doc);
        }
    }
}
