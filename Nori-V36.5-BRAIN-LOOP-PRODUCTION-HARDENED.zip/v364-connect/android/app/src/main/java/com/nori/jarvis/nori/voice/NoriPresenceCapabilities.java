package com.nori.jarvis.nori.voice;

import java.util.LinkedHashMap;
import java.util.Map;

/** Declarative native boundary for evolving Kage/Circle presence capabilities. */
public final class NoriPresenceCapabilities {
    private NoriPresenceCapabilities() {}
    public static Map<String, Boolean> defaults() {
        Map<String, Boolean> m = new LinkedHashMap<>();
        m.put("bargeInInterrupt", true);
        m.put("pauseResume", true);
        m.put("liveTranscript", true);
        m.put("sameChatVoiceText", true);
        m.put("speechRateControl", true);
        m.put("backgroundVoiceOptIn", true);
        m.put("visualContextEntry", true);
        m.put("cameraRequiresExplicitPermission", true);
        m.put("screenContextRequiresExplicitPermission", true);
        m.put("quickActions", true);
        m.put("sessionContinuity", true);
        m.put("adaptivePresenceStates", true);
        m.put("nativeCameraCapture", true);
        m.put("nativeScreenCapture", true);
        m.put("visionContextForwarding", true);
        m.put("boundedBackgroundVoice", true);
        return m;
    }
    public static boolean requiresExplicitUserAction(String capability) {
        return "camera".equals(capability) || "screen".equals(capability)
                || "backgroundVoice".equals(capability);
    }
}
