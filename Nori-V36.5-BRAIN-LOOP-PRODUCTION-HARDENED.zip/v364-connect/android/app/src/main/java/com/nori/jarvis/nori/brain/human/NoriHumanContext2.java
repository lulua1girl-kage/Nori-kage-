package com.nori.jarvis.nori.brain.human;

import java.util.*;

/** Step 41: trajectory-aware human context. Uses explicit reports and interaction outcomes; no diagnosis. */
public final class NoriHumanContext2 {
    public enum Trend { IMPROVING, STABLE, DECLINING, UNCLEAR }
    public static final class Signal { public final HumanContextEngine.Assessment assessment; public final long at; public Signal(HumanContextEngine.Assessment a){assessment=a;at=System.currentTimeMillis();} }
    public static final class Plan { public final Trend trend; public final HumanContextEngine.SupportLevel support; public final double confidence; public final List<String> actions; public final List<String> alternatives; Plan(Trend t,HumanContextEngine.SupportLevel s,double c,List<String>a,List<String>x){trend=t;support=s;confidence=c;actions=unmod(a);alternatives=unmod(x);} }
    private final ArrayDeque<Signal> history=new ArrayDeque<>();
    public synchronized void record(HumanContextEngine.Assessment a){if(a!=null){history.addLast(new Signal(a));while(history.size()>100)history.removeFirst();}}
    public synchronized Plan assess(){if(history.isEmpty())return new Plan(Trend.UNCLEAR,HumanContextEngine.SupportLevel.UNKNOWN,.2,Collections.singletonList("ask_one_non-invasive check-in if useful"),Collections.emptyList());int low=0,normal=0;for(Signal s:history){if(s.assessment.capacity==HumanContextEngine.Capacity.LOW)low++;if(s.assessment.capacity==HumanContextEngine.Capacity.AVAILABLE)normal++;}Trend t=low>normal?Trend.DECLINING:normal>low?Trend.IMPROVING:Trend.STABLE;HumanContextEngine.SupportLevel sup=history.peekLast().assessment.support;List<String>a=new ArrayList<>(),x=new ArrayList<>();if(sup==HumanContextEngine.SupportLevel.STABILIZE||sup==HumanContextEngine.SupportLevel.LIGHTEN_LOAD)a.add("reduce next-step load before increasing demands");else a.add("preserve current route and check progress");x.add("do not infer a clinical condition from behavior");x.add("use explicit user reports when capacity matters");return new Plan(t,sup,Math.min(.95,.5+history.size()*.01),a,x);}
    public synchronized int samples(){return history.size();}
    private static List<String>unmod(List<String>x){return Collections.unmodifiableList(new ArrayList<>(x));}
}
