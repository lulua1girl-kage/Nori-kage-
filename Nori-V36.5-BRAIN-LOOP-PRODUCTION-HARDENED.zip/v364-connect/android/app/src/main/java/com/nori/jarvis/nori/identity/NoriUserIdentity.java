package com.nori.jarvis.nori.identity;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Locale;

/** Per-registered-user scope. Identity is app/account scoped; Nori never infers identity from device surveillance. */
public final class NoriUserIdentity {
    private final String userId, displayName, sessionId, email, backupEmail;
    private final int age;
    public NoriUserIdentity(String userId,String displayName,String sessionId){this(userId,displayName,sessionId,"","",0);}
    public NoriUserIdentity(String userId,String displayName,String sessionId,String email,String backupEmail,int age){
        this.userId=clean(userId);this.displayName=clean(displayName);this.sessionId=clean(sessionId);this.email=clean(email);this.backupEmail=clean(backupEmail);this.age=age;
    }
    public String userId(){return userId;} public String displayName(){return displayName;} public String sessionId(){return sessionId;}
    public String email(){return email;} public String backupEmail(){return backupEmail;} public int age(){return age;}
    public boolean minor(){return age>=13&&age<18;} public String ageBand(){if(age>=13&&age<16)return "13-15";if(age>=16&&age<18)return "16-17";if(age>=18)return "18+";return "unknown";}
    public String scope(){return "user:"+digest(userId);} public String libraryScope(){return scope()+":library";} public String memoryScope(){return scope()+":memory";}
    public boolean valid(){return !userId.isEmpty();}
    private static String clean(String s){return s==null?"":s.trim();}
    private static String digest(String s){try{MessageDigest d=MessageDigest.getInstance("SHA-256");byte[] b=d.digest(s.getBytes(StandardCharsets.UTF_8));StringBuilder x=new StringBuilder();for(int i=0;i<12;i++)x.append(String.format(Locale.ROOT,"%02x",b[i]));return x.toString();}catch(Exception e){return Integer.toHexString(s.hashCode());}}
}
