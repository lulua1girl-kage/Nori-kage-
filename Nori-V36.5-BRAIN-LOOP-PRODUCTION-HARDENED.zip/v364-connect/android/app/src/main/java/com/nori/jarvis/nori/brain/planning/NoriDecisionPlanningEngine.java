package com.nori.jarvis.nori.brain.planning;

import java.util.*;

/**
 * General goal -> constraints -> options -> trade-offs -> plan reasoning.
 * Deterministic/local by design; external AI may enrich options but never owns the plan.
 */
public final class NoriDecisionPlanningEngine {
    public enum Priority { CRITICAL, HIGH, NORMAL, LOW }
    public enum Risk { LOW, MODERATE, HIGH }
    public static final class Goal { public final String id,title; public final Priority priority; public final double value; public Goal(String i,String t,Priority p,double v){id=s(i);title=s(t);priority=p==null?Priority.NORMAL:p;value=clamp(v);} }
    public static final class Constraint { public final String id,description; public final double penalty; public Constraint(String i,String d,double p){id=s(i);description=s(d);penalty=clamp(p);} }
    public static final class Option { public final String id,title; public final double benefit,cost,risk,feasibility; public final List<String> resources; public Option(String i,String t,double b,double c,double r,double f,List<String> rs){id=s(i);title=s(t);benefit=clamp(b);cost=clamp(c);risk=clamp(r);feasibility=clamp(f);resources=Collections.unmodifiableList(new ArrayList<>(rs==null?Collections.emptyList():rs));} }
    public static final class Step { public final String id,title; public final List<String> dependsOn; public Step(String i,String t,List<String>d){id=s(i);title=s(t);dependsOn=Collections.unmodifiableList(new ArrayList<>(d==null?Collections.emptyList():d));} }
    public static final class Plan { public final Goal goal; public final List<Option> rankedOptions; public final List<Step> steps; public final List<String> tradeOffs,constraints,scenarios,commandChain; public final String rationale; public final double confidence;
        Plan(Goal g,List<Option> o,List<Step> st,List<String> tr,List<String> co,List<String> sc,List<String> cc,String r,double c){goal=g;rankedOptions=unmod(o);steps=unmod(st);tradeOffs=unmod(tr);constraints=unmod(co);scenarios=unmod(sc);commandChain=unmod(cc);rationale=r;confidence=clamp(c);}
    }
    public Plan plan(Goal goal,List<Constraint> constraints,List<Option> options){
        if(goal==null) throw new IllegalArgumentException("goal required");
        List<Constraint> cs=constraints==null?Collections.emptyList():constraints;
        List<Option> os=new ArrayList<>(options==null?Collections.emptyList():options);
        final double hardPenalty=cs.stream().mapToDouble(c->c.penalty).sum();
        os.sort((a,b)->Double.compare(score(b,goal,hardPenalty),score(a,goal,hardPenalty)));
        List<String> trade=new ArrayList<>(); if(os.size()>1){Option a=os.get(0),b=os.get(1); trade.add("option_1_benefit_vs_cost="+fmt(a.benefit-b.benefit)+"/"+fmt(a.cost-b.cost)); trade.add("option_1_risk_vs_feasibility="+fmt(a.risk-b.risk)+"/"+fmt(a.feasibility-b.feasibility));}
        List<Step> steps=new ArrayList<>(); if(!os.isEmpty()){Option x=os.get(0); steps.add(new Step("assess","confirm_goal_and_constraints",Collections.emptyList())); for(String r:x.resources)steps.add(new Step("resource_"+Integer.toHexString(r.hashCode()),"allocate_"+r,Collections.singletonList("assess"))); steps.add(new Step("execute_"+x.id,"execute_"+x.title,Collections.singletonList("assess"))); steps.add(new Step("verify","verify_outcome_and_replan_if_needed",Collections.singletonList("execute_"+x.id)));}
        List<String> scenarios=Arrays.asList("base_case","constraint_tightens","available_time_drops","preferred_option_unavailable");
        List<String> chain=new ArrayList<>(); for(Step st:steps)chain.add(st.id); 
        double conf=os.isEmpty()?0.25:Math.min(0.95,0.45+0.12*Math.min(3,os.size())+0.08*(1-hardPenalty));
        return new Plan(goal,os,steps,trade,describe(cs),scenarios,chain,os.isEmpty()?"insufficient options: gather more information before committing":"selected the highest expected usefulness option subject to stated constraints",conf);
    }
    public Plan planFromSignals(String goalText,double urgency,double timeAvailable,double energy,List<String> limits){
        Goal g=new Goal("goal",goalText,urgency>.8?Priority.HIGH:Priority.NORMAL,urgency);
        List<Constraint> c=new ArrayList<>(); if(timeAvailable<.35)c.add(new Constraint("time","limited_available_time",.25)); if(energy<.35)c.add(new Constraint("energy","limited_current_capacity",.2)); if(limits!=null)for(String x:limits)c.add(new Constraint("limit_"+x.hashCode(),x,.12));
        List<Option> o=Arrays.asList(new Option("full","full_plan",.85,.75,.35,.45,Collections.singletonList("time")),new Option("minimum","minimum_viable_step",.62,.25,.12,.9,Collections.singletonList("time")),new Option("defer","defer_with_recovery",.35,.08,.08,.95,Collections.singletonList("recovery")));
        return plan(g,c,o);
    }
    private double score(Option o,Goal g,double p){return .48*o.benefit + .22*o.feasibility + .12*g.value - .10*o.cost - .08*o.risk - .15*p;}
    private static List<String> describe(List<Constraint> c){List<String>x=new ArrayList<>();for(Constraint z:c)x.add(z.id+":"+z.description);return x;}
    private static String s(String x){return x==null?"":x.trim();} private static double clamp(double x){return Double.isFinite(x)?Math.max(0,Math.min(1,x)):0;} private static String fmt(double x){return String.format(Locale.ROOT,"%.2f",x);} private static <T>List<T>unmod(List<T>x){return Collections.unmodifiableList(new ArrayList<>(x));}
}
