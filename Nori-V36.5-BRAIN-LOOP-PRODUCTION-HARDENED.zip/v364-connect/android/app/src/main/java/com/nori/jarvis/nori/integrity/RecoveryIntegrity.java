package com.nori.jarvis.nori.integrity;

/** Ensures recovery is tracked separately from consequence and never falsely marked complete. */
public final class RecoveryIntegrity {
    public enum Status { REQUIRED, IN_PROGRESS, VERIFIED, BLOCKED }
    public Result evaluate(boolean breach, boolean consequenceHandled, boolean restorationDone, boolean restorationVerified){
        if(!breach) return new Result(Status.VERIFIED,"no_integrity_breach_to_restore");
        if(!consequenceHandled) return new Result(Status.REQUIRED,"consequence_or_interruption_pending");
        if(!restorationDone) return new Result(Status.IN_PROGRESS,"academic_restoration_required");
        if(!restorationVerified) return new Result(Status.IN_PROGRESS,"restoration_not_verified");
        return new Result(Status.VERIFIED,"restoration_verified; breach remains historical evidence");
    }
    public static final class Result { public final Status status; public final String reason; Result(Status s,String r){status=s;reason=r;} }
}
