package com.nori.jarvis.nori.identity;

import java.util.*;

/** Admission policy. Local code is UX only; production enforcement belongs on the authenticated server. */
public final class NoriSignupPolicy {
    public enum AdmissionBasis { INVITED, PREAPPROVED_EMAIL, KNOWN_AND_ACCEPTED, NONE }
    public NoriSignupDecision evaluate(NoriSignupRequest r, boolean emailVerified, boolean backupVerified, AdmissionBasis basis){
        if(r==null || !r.valid() || !r.backupDistinct()) return new NoriSignupDecision(NoriAdmissionStatus.REJECTED,false,false,false,"valid_name_age_and_distinct_backup_email_required");
        if(!emailVerified) return new NoriSignupDecision(NoriAdmissionStatus.PENDING_REVIEW,false,backupVerified,true,"primary_email_must_be_verified");
        if(!backupVerified) return new NoriSignupDecision(NoriAdmissionStatus.PENDING_REVIEW,true,false,true,"backup_email_must_be_verified");
        if(basis==null || basis==AdmissionBasis.NONE) return new NoriSignupDecision(NoriAdmissionStatus.PENDING_REVIEW,true,true,true,"nori_program_admission_required");
        return new NoriSignupDecision(NoriAdmissionStatus.APPROVED,true,true,false,"admission_basis_accepted");
    }
    public String rule(){return "No anonymous app entry. Sign-up requires name, age, primary email, backup email, verification, and an accepted Nori-program admission basis.";}
}
