package com.nori.jarvis.nori.execution;

import com.nori.jarvis.nori.actions.ActionEngine;
import com.nori.jarvis.nori.actions.model.*;
import java.time.Instant;
import java.util.*;

/**
 * Cross-cutting reality/reliability gate. It reports what Nori actually knows
 * about an operation instead of treating intent, preparation or a catalog entry as success.
 */
public final class NoriRealityEngine {
    public enum State { UNDERSTOOD, PREPARED, AUTHORIZED, EXECUTED, VERIFIED, FAILED, RECOVERABLE, UNAVAILABLE }
    public static final class Check {
        public final String capability; public final State state; public final boolean trueSuccess;
        public final String evidence; public final Instant at;
        Check(String c,State s,boolean ok,String e){capability=c;state=s;trueSuccess=ok;evidence=e;at=Instant.now();}
    }
    private final ActionEngine actions;
    public NoriRealityEngine(ActionEngine a){actions=a;}
    public Check inspect(String capabilityId){
        ToolDefinition d=actions.definition(capabilityId);
        if(d==null)return new Check(capabilityId,State.UNAVAILABLE,false,"No ActionEngine definition.");
        return new Check(capabilityId,State.PREPARED,true,"ActionEngine definition exists; execution and verification are still required.");
    }
    public Check fromResult(String capabilityId,ActionExecutionResult r){
        if(r==null)return new Check(capabilityId,State.FAILED,false,"No execution result.");
        if(r.ok&&r.verified)return new Check(capabilityId,State.VERIFIED,true,"Handler returned success and verification=true.");
        return new Check(capabilityId,State.FAILED,false,r.reason==null?"Execution was not verified.":r.reason);
    }
}
