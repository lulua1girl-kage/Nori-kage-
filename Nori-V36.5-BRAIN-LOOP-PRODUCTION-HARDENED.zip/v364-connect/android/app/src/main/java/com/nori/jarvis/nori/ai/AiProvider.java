package com.nori.jarvis.nori.ai;

/** Adapter contract for optional intelligence providers. */
public interface AiProvider {
    String id();
    boolean isAvailable();
    boolean isRemote();
    AiResponse generate(AiRequest request);
    default AiResponse generateStreaming(AiRequest request, StreamListener listener) {
        AiResponse r=generate(request);
        if(r.status==AiResponse.Status.SUCCESS && listener!=null) listener.onChunk(r.text);
        if(listener!=null) listener.onComplete(r);
        return r;
    }
    interface StreamListener { void onChunk(String chunk); void onComplete(AiResponse response); }
}
