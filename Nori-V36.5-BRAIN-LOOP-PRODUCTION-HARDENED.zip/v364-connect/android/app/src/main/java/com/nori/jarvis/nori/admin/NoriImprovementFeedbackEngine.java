package com.nori.jarvis.nori.admin;

import com.nori.jarvis.nori.admin.model.AdminRole;
import java.util.*;

/** Converts user feedback into bounded, reviewable improvement suggestions. */
public final class NoriImprovementFeedbackEngine {
    public enum Kind { BUG, QUALITY, SAFETY, FEATURE, TEACHING, PERFORMANCE, PRIVACY }
    public static final class Feedback { public final String id,userId,text; public final Kind kind; public final long at; public Feedback(String i,String u,String t,Kind k){id=i;userId=u;text=t;kind=k;at=System.currentTimeMillis();} }
    private final List<Feedback> queue=new ArrayList<>();
    public synchronized Feedback submit(String userId,String text,Kind kind){if(blank(userId)||blank(text)||kind==null)return null;Feedback f=new Feedback(UUID.randomUUID().toString(),userId,text.trim(),kind);queue.add(f);while(queue.size()>1000)queue.remove(0);return f;}
    public synchronized List<Feedback> adminQueue(AdminRole role){if(role!=AdminRole.OWNER&&role!=AdminRole.ADMIN)return Collections.emptyList();return Collections.unmodifiableList(new ArrayList<>(queue));}
    public String rule(){return "User feedback is evidence for improvement, not automatic authority. Admin review, testing and safety checks precede production changes.";}
    private boolean blank(String s){return s==null||s.trim().isEmpty();}
}
