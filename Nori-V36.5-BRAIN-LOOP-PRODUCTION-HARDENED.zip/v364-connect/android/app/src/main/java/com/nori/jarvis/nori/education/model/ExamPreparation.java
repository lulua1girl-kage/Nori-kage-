package com.nori.jarvis.nori.education.model;

import java.time.LocalDateTime; import java.util.*;

public final class ExamPreparation {
    public final String subject,title; public final LocalDateTime examAt; public final int daysRemaining;
    public final List<String> focusTopics; public final List<String> phases; public final int recommendedMinutes;
    public ExamPreparation(String subject,String title,LocalDateTime examAt,int daysRemaining,List<String> focusTopics,List<String> phases,int recommendedMinutes){
        this.subject=subject;this.title=title;this.examAt=examAt;this.daysRemaining=daysRemaining;
        this.focusTopics=Collections.unmodifiableList(new ArrayList<>(focusTopics));this.phases=Collections.unmodifiableList(new ArrayList<>(phases));this.recommendedMinutes=recommendedMinutes;
    }
}
