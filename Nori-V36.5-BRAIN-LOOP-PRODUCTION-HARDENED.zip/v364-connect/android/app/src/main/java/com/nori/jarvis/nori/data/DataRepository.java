package com.nori.jarvis.nori.data;

/**
 * Native persistence abstraction. Higher-level engines depend on this
 * interface so they do not depend on Android storage implementation details.
 */
public interface DataRepository {
    boolean putJson(String key, String valueJson, String category, int schemaVersion);
    String getJson(String key);
    boolean contains(String key);
    boolean delete(String key);
    default java.util.List<String> keys(){ return java.util.Collections.emptyList(); }
}
