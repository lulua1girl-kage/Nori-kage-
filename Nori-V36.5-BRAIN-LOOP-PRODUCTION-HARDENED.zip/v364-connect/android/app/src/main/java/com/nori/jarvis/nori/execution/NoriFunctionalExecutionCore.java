package com.nori.jarvis.nori.execution;

import com.nori.jarvis.nori.actions.ActionEngine;
import com.nori.jarvis.nori.actions.ToolRouter;
import com.nori.jarvis.nori.actions.model.*;
import com.nori.jarvis.nori.understanding.NoriUserControlEngine;
import java.util.*;

/**
 * Truthful end-to-end action lifecycle over the existing ActionEngine.
 * It never bypasses permissions, educational firewalls, confirmations or handlers.
 */
public final class NoriFunctionalExecutionCore {
    public enum Stage { DISCOVER, UNDERSTAND, RESOLVE, PREPARE, PREVIEW, AUTHORIZE, EXECUTE, VERIFY, RECOVER, LEARN }
    public enum CapabilityTruth { UNDERSTAND_ONLY, GUIDE, PREPARE, EXECUTE, VERIFY, UNAVAILABLE }
    public static final class Status {
        public final String capabilityId; public final Stage stage; public final CapabilityTruth truth;
        public final String message; public final boolean userTriggerRequired; public final boolean confirmationRequired;
        Status(String id,Stage s,CapabilityTruth t,String m,boolean u,boolean c){capabilityId=id;stage=s;truth=t;message=m;userTriggerRequired=u;confirmationRequired=c;}
    }
    public static final class PreparedAction {
        public final ActionProposal proposal; public final ActionPreview preview; public final NoriUserControlEngine.Decision authorization;
        PreparedAction(ActionProposal p,ActionPreview v,NoriUserControlEngine.Decision a){proposal=p;preview=v;authorization=a;}
    }
    private final ToolRouter router; private final NoriUserControlEngine control; private final NoriExecutionLifecycle lifecycle;
    public NoriFunctionalExecutionCore(ToolRouter r,NoriUserControlEngine c){this(r,c,new NoriExecutionLifecycle());}
    public NoriFunctionalExecutionCore(ToolRouter r,NoriUserControlEngine c,NoriExecutionLifecycle l){if(r==null||c==null||l==null)throw new IllegalArgumentException("router, control and lifecycle required");router=r;control=c;lifecycle=l;}

    public Status truth(String capabilityId){
        if(capabilityId==null||capabilityId.trim().isEmpty())return new Status("unknown",Stage.DISCOVER,CapabilityTruth.UNAVAILABLE,"Capability id is missing.",true,false);
        ToolDefinition d=router.engine().definition(capabilityId);
        if(d==null)return new Status(capabilityId,Stage.DISCOVER,CapabilityTruth.UNAVAILABLE,"No executable handler is registered for this capability yet.",true,false);
        return new Status(capabilityId,Stage.PREPARE,CapabilityTruth.EXECUTE,"An ActionEngine handler exists; permission and confirmation still apply.",true,d.confirmationRequired);
    }

    public PreparedAction prepare(ToolRequest request,String reason,List<String> evidence,NoriUserControlEngine.Origin origin,boolean consequential,boolean crossApp,boolean sensitive,String scope,String permission){
        String lifecycleId = lifecycle.begin(request==null?"unknown":request.toolId);
        lifecycle.update(lifecycleId,NoriExecutionLifecycle.Stage.UNDERSTAND,"READY","request_received",false);
        if(request==null){ lifecycle.update(lifecycleId,NoriExecutionLifecycle.Stage.RECOVER,"FAILED","request_missing",false); return new PreparedAction(null,ActionPreview.deny("request_missing"),control.evaluate(new NoriUserControlEngine.Request("missing","Missing action",origin,consequential,crossApp,sensitive,scope,permission))); }
        lifecycle.update(lifecycleId,NoriExecutionLifecycle.Stage.AUTHORIZE,"CHECKING","user_control",false);
        NoriUserControlEngine.Decision auth=control.evaluate(new NoriUserControlEngine.Request(request.toolId,"User-requested action",origin,consequential,crossApp,sensitive,scope,permission));
        if(!auth.mayExecute && auth.status!=NoriUserControlEngine.Status.NEEDS_CONFIRMATION){ lifecycle.update(lifecycleId,NoriExecutionLifecycle.Stage.RECOVER,"BLOCKED",auth.reason,false); return new PreparedAction(null,ActionPreview.deny(auth.reason),auth); }
        lifecycle.update(lifecycleId,NoriExecutionLifecycle.Stage.PREPARE,"READY","proposal_preparation",false);
        ActionProposal p;
        try{p=router.propose(request,reason,evidence);}catch(Exception e){lifecycle.update(lifecycleId,NoriExecutionLifecycle.Stage.RECOVER,"FAILED",e.getMessage()==null?"proposal_failed":e.getMessage(),false);return new PreparedAction(null,ActionPreview.deny(e.getMessage()==null?"proposal_failed":e.getMessage()),auth);}
        ActionPreview preview=router.engine().preview(p.id);
        lifecycle.update(lifecycleId,NoriExecutionLifecycle.Stage.PREVIEW,"READY","preview_created",false);
        return new PreparedAction(p,preview,auth);
    }

    public ActionExecutionResult confirmAndExecute(String proposalId,String actor){
        if(proposalId==null||proposalId.trim().isEmpty())return ActionExecutionResult.fail("proposal_missing");
        ActionExecutionResult result=router.engine().confirmAndExecute(proposalId,actor);
        String id=lifecycle.begin("proposal:"+proposalId);
        lifecycle.update(id,NoriExecutionLifecycle.Stage.EXECUTE,result.ok?"SUCCESS":"FAILED",result.reason,result.verified);
        lifecycle.update(id,NoriExecutionLifecycle.Stage.VERIFY,result.verified?"VERIFIED":"UNVERIFIED",result.reason,result.verified);
        if(!result.ok) lifecycle.update(id,NoriExecutionLifecycle.Stage.RECOVER,"RECOVERY_AVAILABLE",result.reason,false);
        else lifecycle.update(id,NoriExecutionLifecycle.Stage.LEARN,"OUTCOME_RECORDED",result.reason,result.verified);
        return result;
    }
    public List<NoriExecutionLifecycle.Record> lifecycle(int limit){return lifecycle.recent(limit);}
    public ActionExecutionResult undo(String operationId,String actor){return router.engine().undo(operationId,actor);}
    public boolean cancel(String proposalId){return router.engine().cancel(proposalId);}
    public List<ActionProposal> pending(){return router.engine().pending();}
}
