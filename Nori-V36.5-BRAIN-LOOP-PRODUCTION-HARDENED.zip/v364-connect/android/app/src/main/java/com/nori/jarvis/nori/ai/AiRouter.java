package com.nori.jarvis.nori.ai;

import java.util.*;
import java.util.concurrent.*;

/**
 * Nori provider router: local deterministic capability first; difficult work may use
 * configured external providers in ordered fallback sequence. Failures are observable.
 */
public final class AiRouter {
    private final AiProvider local;
    private final List<AiProvider> remotes=new ArrayList<>();
    private AiRoutingPolicy policy;
    private long timeoutMillis=10000;
    private FailureListener failureListener;
    private final ExecutorService executor=Executors.newCachedThreadPool();
    private final Map<String,Long> providerCooldownUntil=new HashMap<>();
    private final Map<String,AiResponse> responseCache=new LinkedHashMap<String,AiResponse>(32,0.75f,true){ protected boolean removeEldestEntry(Map.Entry<String,AiResponse> e){ return size()>32; }};

    public interface FailureListener { void onFailure(String providerId,String reason); }
    public AiRouter(){this(new LocalAiProvider(),Collections.emptyList(),AiRoutingPolicy.localOnly());}
    public AiRouter(AiProvider local, AiProvider remote, AiRoutingPolicy policy){this(local,remote==null?Collections.emptyList():Collections.singletonList(remote),policy);}
    public AiRouter(AiProvider local,List<AiProvider> remotes,AiRoutingPolicy policy){
        this.local=local==null?new LocalAiProvider():local; if(remotes!=null)for(AiProvider p:remotes)if(p!=null)this.remotes.add(p);
        this.policy=policy==null?AiRoutingPolicy.localOnly():policy;
    }
    public synchronized void configureRemote(AiProvider provider,AiRoutingPolicy newPolicy){remotes.clear();if(provider!=null)remotes.add(provider);policy=newPolicy==null?AiRoutingPolicy.localOnly():newPolicy;}
    public synchronized void configureProviders(List<AiProvider> providers,AiRoutingPolicy newPolicy){remotes.clear();if(providers!=null)for(AiProvider p:providers)if(p!=null)remotes.add(p);policy=newPolicy==null?AiRoutingPolicy.localOnly():newPolicy;}
    public synchronized void setTimeoutMillis(long millis){timeoutMillis=Math.max(1000,Math.min(30000,millis));}
    public synchronized void setFailureListener(FailureListener l){failureListener=l;}

    public AiResponse generate(AiRequest request){
        if(request==null)return AiResponse.error("router","request_missing");
        // Local Nori decides whether the request is simple enough to answer itself.
        if(local.isAvailable()){
            AiResponse l=local.generate(request);
            if(l.status==AiResponse.Status.SUCCESS && !request.requiresExternalIntelligence()) return l;
        }
        if(!policy.allowRemote()) return local.generate(request);
        List<AiProvider> providers=orderedProviders(request,snapshotRemotes());
        for(AiProvider p:providers){
            if(isCoolingDown(p.id())) continue;
            if(!p.isAvailable()) {fail(p.id(),"unavailable");continue;}
            AiResponse cached=cached(request,p.id()); if(cached!=null)return cached;
            AiResponse r=callWithTimeout(p,request);
            if(r.status==AiResponse.Status.SUCCESS){cache(request,p.id(),r);return r;}
            fail(p.id(),r.reason==null?"provider_failed":r.reason);
        }
        return local.generate(request);
    }

    public AiResponse generateStreaming(AiRequest request,AiProvider.StreamListener listener){
        if(request==null)return AiResponse.error("router","request_missing");
        if(local.isAvailable()){
            AiResponse l=local.generateStreaming(request,listener);
            if(l.status==AiResponse.Status.SUCCESS && !request.requiresExternalIntelligence()) return l;
        }
        if(!policy.allowRemote())return local.generateStreaming(request,listener);
        for(AiProvider p:orderedProviders(request,snapshotRemotes())){
            if(isCoolingDown(p.id())) continue;
            if(!p.isAvailable()){fail(p.id(),"unavailable");continue;}
            AiResponse r=callStreamingWithTimeout(p,request,listener);
            if(r.status==AiResponse.Status.SUCCESS)return r;
            fail(p.id(),r.reason==null?"provider_failed":r.reason);
        }
        return local.generateStreaming(request,listener);
    }
    private AiResponse callWithTimeout(AiProvider p,AiRequest r){
        Future<AiResponse> f=executor.submit(()->p.generate(r));
        try{return f.get(timeoutMillis,TimeUnit.MILLISECONDS);}catch(TimeoutException e){f.cancel(true);return AiResponse.error(p.id(),"timeout_"+timeoutMillis+"ms");}
        catch(Exception e){return AiResponse.error(p.id(),"provider_exception");}finally{}
    }
    private AiResponse callStreamingWithTimeout(AiProvider p,AiRequest r,AiProvider.StreamListener listener){
        // Provider streaming is executed on a bounded worker; the listener receives chunks as provided.
        Future<AiResponse> f=executor.submit(()->p.generateStreaming(r,listener));
        try{return f.get(timeoutMillis,TimeUnit.MILLISECONDS);}catch(TimeoutException e){f.cancel(true);return AiResponse.error(p.id(),"timeout_"+timeoutMillis+"ms");}
        catch(Exception e){return AiResponse.error(p.id(),"provider_exception");}finally{}
    }
    private synchronized List<AiProvider> snapshotRemotes(){return new ArrayList<>(remotes);}
    /** Capability-aware ordering: provider metadata can express strengths without making provider count the goal. */
    private List<AiProvider> orderedProviders(AiRequest r,List<AiProvider> input){
        String capability=r.metadata.getOrDefault("capability","general").toLowerCase(Locale.ROOT);
        List<AiProvider> out=new ArrayList<>(input);
        out.sort((a,b)->Integer.compare(score(b,capability),score(a,capability)));
        return out;
    }
    private int score(AiProvider p,String capability){
        String id=p.id()==null?"":p.id().toLowerCase(Locale.ROOT); int s=0;
        if(id.contains(capability))s+=4;
        if(capability.contains("code")&&(id.contains("code")||id.contains("codex")))s+=3;
        if(capability.contains("vision")&&(id.contains("gemini")||id.contains("vision")))s+=3;
        if(capability.contains("research")&&(id.contains("research")||id.contains("search")))s+=3;
        if(capability.contains("reason")&&(id.contains("reason")||id.contains("thinking")||id.contains("opus")))s+=2;
        if(capability.contains("local")&&!p.isRemote())s+=5;
        return s;
    }
    private synchronized void fail(String id,String reason){ if(reason!=null && reason.startsWith("timeout_")) cooldown(id); if(failureListener!=null)failureListener.onFailure(id,reason);}
    private synchronized void cooldown(String id){ providerCooldownUntil.put(id,System.currentTimeMillis()+15000); }
    private synchronized boolean isCoolingDown(String id){ Long t=providerCooldownUntil.get(id); return t!=null&&t>System.currentTimeMillis(); }
    private synchronized AiResponse cached(AiRequest r,String id){ return responseCache.get(cacheKey(r,id)); }
    private synchronized void cache(AiRequest r,String id,AiResponse a){ if(a!=null&&a.status==AiResponse.Status.SUCCESS&&r.maxOutputCharacters<=12000) responseCache.put(cacheKey(r,id),a); }
    private String cacheKey(AiRequest r,String id){ return id+"|"+r.prompt.trim().toLowerCase(Locale.ROOT)+"|"+r.systemInstruction; }
    public synchronized boolean remoteEnabled(){return policy.allowRemote()&&remotes.stream().anyMatch(p->p!=null&&p.isAvailable());}
    public synchronized String activeMode(){return remoteEnabled()?"local_first_remote_fallback":"local";}
}
