package com.nori.jarvis.nori.actions;

import com.nori.jarvis.nori.actions.model.ActionProposal;
import com.nori.jarvis.nori.actions.model.ToolRequest;

import java.util.Collections;
import java.util.List;

/** Thin router: natural-language/Brain layers choose a tool; execution remains in ActionEngine. */
public final class ToolRouter {
    private final ActionEngine actions;
    public ToolRouter(ActionEngine actions) { if(actions==null)throw new IllegalArgumentException("action engine required"); this.actions=actions; }
    public ActionProposal propose(ToolRequest request,String reason,List<String> evidence){return actions.propose(request,reason,evidence==null? Collections.<String>emptyList():evidence);}
    public ActionEngine engine(){return actions;}
}
