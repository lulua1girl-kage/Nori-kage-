package com.nori.jarvis.nori.brain.human;

import java.util.*;
import java.util.regex.Pattern;

/**
 * Non-clinical human-context interpretation. It does not diagnose or label a person.
 * It estimates the kind of support a situation may require from observable context.
 */
public final class HumanContextEngine {
    public enum Capacity { AVAILABLE, LIMITED, LOW, UNKNOWN }
    public enum Difficulty { NORMAL, HIGH, OVERLOAD, AVOIDANCE_PATTERN, LOW_ACTIVATION, FATIGUE_LIMITED, UNCLEAR }
    public enum SupportLevel { NORMAL, LIGHTEN_LOAD, STABILIZE, SAFETY_FIRST, UNKNOWN }

    public static final class Assessment {
        public final Capacity capacity;
        public final Difficulty difficulty;
        public final SupportLevel support;
        public final double confidence;
        public final boolean repeatedPattern;
        public final List<String> signals;
        public final List<String> alternatives;
        public Assessment(Capacity c, Difficulty d, SupportLevel s, double confidence,
                          boolean repeated, List<String> signals, List<String> alternatives) {
            this.capacity=c; this.difficulty=d; this.support=s; this.confidence=confidence;
            this.repeatedPattern=repeated;
            this.signals=Collections.unmodifiableList(new ArrayList<>(signals));
            this.alternatives=Collections.unmodifiableList(new ArrayList<>(alternatives));
        }
    }

    private static final Pattern FATIGUE=Pattern.compile("\\b(tired|exhausted|sleepy|drained|can't think|cannot think|burned out|burnt out)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern OVERLOAD=Pattern.compile("\\b(overwhelmed|too much|can't handle|cannot handle|everything is|too many|pressure)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern LOW_ACTIVATION=Pattern.compile("\\b(can't start|cannot start|can't get started|stuck|procrastinat|keep putting off)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern AVOIDANCE=Pattern.compile("\\b(avoid|avoiding|scroll|reels|shorts|gaming|game all day|keep distracting)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern UNSAFE=Pattern.compile("\\b(unsafe|in danger|hurt myself|hurting myself|self harm|self-harm|suicid)\\b", Pattern.CASE_INSENSITIVE);
    private static final Pattern FUNCTIONAL_WIN=Pattern.compile("\\b(went to school|got out of bed|started|finished|one step|made it through|got through today)\\b", Pattern.CASE_INSENSITIVE);

    public Assessment assess(String message, int recentMisses, int recentSuccessfulStarts, boolean userReportedDifficulty) {
        String s=message==null?"":message.trim();
        List<String> signals=new ArrayList<>(), alternatives=new ArrayList<>();
        boolean fatigue=FATIGUE.matcher(s).find(), overload=OVERLOAD.matcher(s).find(), activation=LOW_ACTIVATION.matcher(s).find();
        boolean avoidance=AVOIDANCE.matcher(s).find(), unsafe=UNSAFE.matcher(s).find();
        boolean repeated=recentMisses>=3;
        if(fatigue) signals.add("fatigue_signal");
        if(overload) signals.add("overload_signal");
        if(activation) signals.add("low_activation_signal");
        if(avoidance) signals.add("avoidance_signal");
        if(repeated) signals.add("repeated_execution_pattern");
        if(FUNCTIONAL_WIN.matcher(s).find()) signals.add("functional_progress_signal");

        Capacity cap=Capacity.UNKNOWN;
        if(unsafe) cap=Capacity.LOW;
        else if(overload||fatigue) cap=Capacity.LOW;
        else if(userReportedDifficulty||activation||avoidance) cap=Capacity.LIMITED;
        else if(!s.isEmpty()) cap=Capacity.AVAILABLE;

        Difficulty difficulty=Difficulty.UNCLEAR;
        if(unsafe||overload) difficulty=Difficulty.OVERLOAD;
        else if(fatigue) difficulty=Difficulty.FATIGUE_LIMITED;
        else if(activation) difficulty=Difficulty.LOW_ACTIVATION;
        else if(avoidance && repeated) difficulty=Difficulty.AVOIDANCE_PATTERN;
        else if(userReportedDifficulty) difficulty=Difficulty.HIGH;
        else if(!s.isEmpty()) difficulty=Difficulty.NORMAL;

        // A behavior is not called laziness from a single observation.
        if(avoidance && !repeated) alternatives.add("could_be_habit_friction_or_temporary_avoidance");
        if(repeated && !fatigue && !overload) alternatives.add("repeated_pattern_needs_more_context_before_attributing_cause");
        alternatives.add("behavior_does_not_establish_clinical_condition");

        SupportLevel support=unsafe?SupportLevel.SAFETY_FIRST:(overload||fatigue?SupportLevel.STABILIZE:(activation?SupportLevel.LIGHTEN_LOAD:SupportLevel.NORMAL));
        double confidence=unsafe||overload?0.88:(fatigue||activation||repeated?0.72:(s.isEmpty()?0.25:0.55));
        return new Assessment(cap,difficulty,support,confidence,repeated,signals,alternatives);
    }
}
