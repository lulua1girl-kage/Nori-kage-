package com.nori.jarvis.nori.brain.scenario;

import java.util.*;

/** Bounded what-if reasoning. Outputs scenarios, not guaranteed predictions. */
public final class NoriScenarioEngine {
    public static final class Scenario { public final String title,assumptions,likelyEffects,uncertainty; Scenario(String t,String a,String e,String u){title=t;assumptions=a;likelyEffects=e;uncertainty=u;} }
    public List<Scenario> simulate(String choice,double urgency,double remainingTime,double mastery){double u=clamp(urgency),t=clamp(remainingTime),m=clamp(mastery);List<Scenario>x=new ArrayList<>();
        x.add(new Scenario("Do it now","current urgency and available time are used","more immediate preparation; remaining time for recovery decreases","moderate; depends on actual task difficulty"));
        x.add(new Scenario("Skip or defer","no additional work in this window","more immediate free time; preparation remains unchanged or may fall if no later recovery occurs","high; future schedule and starting behavior matter"));
        if(m<.5)x.add(new Scenario("Minimum viable session","limited time/capacity; target one important gap","small preparation gain with lower interruption/load cost","moderate"));
        return Collections.unmodifiableList(x);}
    private double clamp(double x){return Double.isFinite(x)?Math.max(0,Math.min(1,x)):0;}
}
