package com.nori.jarvis.nori.brain.study;

import java.util.*;

/** Adaptive study-method selector. It can choose, merge, slow down, or accelerate methods from evidence. */
public final class NoriStudyStrategyEngine {
    public enum Level { STRUGGLING, DEVELOPING, SOLID, ADVANCED, UNKNOWN }
    public enum Pace { TOO_SLOW, TOO_FAST, RIGHT, UNKNOWN }
    public static final class Method { public final String id,name,tier; public final Set<String> tags; public final String purpose;
        Method(String i,String n,String t,String p,String...tags){id=i;name=n;tier=t;purpose=p;this.tags=Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(tags)));}}
    public static final class Selection { public final List<Method> methods; public final String rationale; public final boolean aiSelected; public final String pacingAction;
        Selection(List<Method>m,String r,boolean a,String p){methods=Collections.unmodifiableList(new ArrayList<>(m));rationale=r;aiSelected=a;pacingAction=p;}}
    private final List<Method> catalog;
    public NoriStudyStrategyEngine(){catalog=buildCatalog();}
    public List<Method> catalog(){return Collections.unmodifiableList(catalog);}
    public Selection select(Level level,Pace pace,Set<String> preferred,String weakTag){
        List<Method> candidates=new ArrayList<>();for(Method m:catalog)if(preferred!=null&&!preferred.isEmpty()&&preferred.contains(m.id))candidates.add(m);
        if(candidates.isEmpty()){for(Method m:catalog)if(m.tier.equals("UNIVERSAL"))candidates.add(m);for(Method m:catalog)if(weakTag!=null&&m.tags.contains(weakTag)&&candidates.size()<3)candidates.add(m);}
        if(level==Level.STRUGGLING)for(Method m:catalog)if(m.tier.equals("STRUGGLING")&&candidates.size()<3)candidates.add(m);
        if(level==Level.SOLID)for(Method m:catalog)if(m.tier.equals("DEVELOPING")&&candidates.size()<3)candidates.add(m);
        if(level==Level.ADVANCED)for(Method m:catalog)if(m.tier.equals("ADVANCED")&&candidates.size()<3)candidates.add(m);
        LinkedHashMap<String,Method> unique=new LinkedHashMap<>();for(Method m:candidates)unique.put(m.id,m);
        String pacing=pace==Pace.TOO_SLOW?"reduce scaffolding / shorten explanation / increase challenge":pace==Pace.TOO_FAST?"add smaller steps / checks / slower transitions":"maintain current pace";
        return new Selection(new ArrayList<>(unique.values()).subList(0,Math.min(4,unique.size())),"selected methods from universal defaults plus current learning evidence; student preference overrides when explicit",preferred!=null&&!preferred.isEmpty(),pacing);
    }
    public Selection adapt(Selection current, Pace pace, boolean studentRequestedChange){
        if(current==null)return select(Level.UNKNOWN,pace,Collections.emptySet(),null);
        List<Method> m=new ArrayList<>(current.methods);
        if(pace==Pace.TOO_SLOW && m.size()>1)m.remove(m.size()-1);
        if(pace==Pace.TOO_FAST){for(Method x:catalog)if(x.tier.equals("STRUGGLING")&&!m.contains(x)){m.add(x);break;}}
        return new Selection(m,studentRequestedChange?"student feedback requested a pacing change":"adapted from observed learning response",current.aiSelected,pacingAction(pace));
    }
    public Method merge(String id,String name,String purpose,Method... parts){
        List<String> tags=new ArrayList<>();if(parts!=null)for(Method m:parts)if(m!=null)tags.addAll(m.tags);return new Method(id,name,"ADAPTIVE",purpose,tags.toArray(new String[0]));
    }
    private String pacingAction(Pace p){return p==Pace.TOO_SLOW?"accelerate":p==Pace.TOO_FAST?"slow_down":"maintain";}

    private List<Method> buildCatalog(){List<Method>x=new ArrayList<>();
        String[] universal={"active_recall","spaced_repetition","self_explanation","immediate_feedback","confidence_calibration","retrieval_practice","interleaved_review","concrete_example","compare_contrast","predict_then_verify","one_question","progress_tracking","explain_back","low_stakes_testing","why_before_move_on","feynman","socratic","worked_examples","error_analysis","teach_back"};
        for(String id:universal)x.add(new Method(id,id.replace('_',' '),"UNIVERSAL","baseline learning loop","retrieval","calibration"));
        String[] combined={"feynman_socratic_loop","spaced_retrieval_ladder","interleaved_worked_example_fade","dual_coded_mind_map_teach_back","cornell_to_blurt_pipeline","analogy_chain_elaboration","pq4r_socratic_reading_sprint","error_driven_interleaved_retest","confidence_calibrated_rubber_duck","full_stack_mastery_cycle"};for(String id:combined)x.add(new Method(id,id.replace('_',' '),"COMBINED","merge compatible methods","integration"));
        String[] struggling={"micro_chunking","preteach_vocabulary","concrete_to_abstract","errorless_learning","say_back_check","one_concept_at_a_time","positive_first_feedback","slow_motion_examples","frequent_small_wins","everyday_analogy"};for(String id:struggling)x.add(new Method(id,id.replace('_',' '),"STRUGGLING","reduce cognitive load","scaffold"));
        String[] stuck={"prerequisite_backtrace","modality_switch","wrong_on_purpose","minimal_example","reverse_explanation","physical_tactile_analogy","extreme_case_testing","shutdown_check","compare_known_topic","draw_no_words","younger_sibling_reframe","isolate_confusing_word","multiple_analogies","step_away_return","diagnostic_micro_quiz"};for(String id:stuck)x.add(new Method(id,id.replace('_',' '),"STUCK","find and repair the root block","diagnostic"));
        String[] advanced={"compression_challenge","immediate_application","edge_cases_first","cross_domain_transfer","reverse_engineering","socratic_devil_advocate","build_your_own_problem","synthesis_across_topics","fastest_path","predict_then_verify_deep","meta_questioning","constraint_removal","compressed_timeline","cross_examine_source","analogy_generation","first_principles_rebuild","multi_perspective_synthesis","time_pressure_depth","concept_mutation","independent_research_sprint"};for(String id:advanced)x.add(new Method(id,id.replace('_',' '),"ADVANCED","test flexible and deep understanding","transfer"));
        String[] developing={"graduated_difficulty","explain_then_extend","guided_discovery","mixed_confidence","semi_interleaved","worked_guided_independent","error_follow_up","concept_application","compare_similar","self_explanation_checkpoint","chunked_spaced_review","light_socratic","progress_visualization","stretch_question","peer_level_explanation","eighty_percent_rule","explain_mistake","two_step_preview","timed_checkpoint","half_scaffolded_sets","concept_map_fill_in","alternate_method_comparison","weekly_weak_spot","real_test_simulation","justify_rule","progressive_hint_ladder","cumulative_sets","self_correction_before_reveal","difficulty_self_selection","end_topic_synthesis"};for(String id:developing)x.add(new Method(id,id.replace('_',' '),"DEVELOPING","build independence and transfer","scaffold","independence"));
        return x;
    }
}
