package com.nori.jarvis.nori.brain.focus;

import java.time.Instant; import java.util.*;

/** Uses only explicit in-app interaction cadence. It does not inspect private background activity. */
public final class NoriInterruptAwareFocusEngine {
    public enum Decision { ALLOW, HOLD_UNTIL_BREAK, URGENT_ALLOW }
    private final Deque<Instant> interactions=new ArrayDeque<>(); private boolean focusActive;
    public synchronized void start(){focusActive=true;interactions.clear();}
    public synchronized void stop(){focusActive=false;interactions.clear();}
    public synchronized void recordInteraction(){if(!focusActive)return;interactions.addLast(Instant.now());while(interactions.size()>30)interactions.removeFirst();}
    public synchronized Decision decide(boolean urgent){if(!focusActive)return Decision.ALLOW;if(urgent)return Decision.URGENT_ALLOW;if(interactions.size()<3)return Decision.ALLOW;Instant last=interactions.peekLast();long idle=java.time.Duration.between(last,Instant.now()).getSeconds();return idle<45?Decision.HOLD_UNTIL_BREAK:Decision.ALLOW;}
    public synchronized int interactionCount(){return interactions.size();}
}
