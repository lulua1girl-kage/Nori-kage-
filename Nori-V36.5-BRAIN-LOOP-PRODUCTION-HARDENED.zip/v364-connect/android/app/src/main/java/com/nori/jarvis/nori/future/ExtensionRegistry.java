package com.nori.jarvis.nori.future;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Small explicit registry for future modules; no runtime self-installation. */
public final class ExtensionRegistry {
    private final Map<String, String> extensions = new LinkedHashMap<String, String>();
    private final int maxExtensions;

    public ExtensionRegistry() { this(64); }
    public ExtensionRegistry(int maxExtensions) {
        if (maxExtensions < 1 || maxExtensions > 256) throw new IllegalArgumentException("invalid maxExtensions");
        this.maxExtensions = maxExtensions;
    }

    public synchronized boolean register(String id, String version) {
        if (id == null || id.trim().isEmpty() || id.length() > 80) return false;
        if (version == null || version.trim().isEmpty() || version.length() > 40) return false;
        if (!extensions.containsKey(id) && extensions.size() >= maxExtensions) return false;
        extensions.put(id, version);
        return true;
    }

    public synchronized boolean remove(String id) { return extensions.remove(id) != null; }
    public synchronized Map<String, String> snapshot() {
        return Collections.unmodifiableMap(new LinkedHashMap<String, String>(extensions));
    }
}
