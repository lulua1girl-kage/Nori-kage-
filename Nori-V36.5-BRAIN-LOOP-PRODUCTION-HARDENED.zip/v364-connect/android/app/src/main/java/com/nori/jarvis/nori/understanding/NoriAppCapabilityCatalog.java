package com.nori.jarvis.nori.understanding;

import java.util.*;

/**
 * Nori's self-description layer: a structured map of what the app can do,
 * how to reach it, what it needs, and whether it can act without a fresh user trigger.
 * This is intentionally deterministic and local-first.
 */
public final class NoriAppCapabilityCatalog {
    public enum Risk { LOW, MODERATE, HIGH, CRITICAL }
    public enum Mode { EXPLAIN, GUIDE, ACTION }
    public enum Trigger { USER_REQUEST, USER_CONFIRMATION, USER_SCHEDULE, NONE }

    public static final class Capability {
        public final String id, title, category, purpose, route, guideId, permission;
        public final List<String> triggers, related, examples;
        public final Risk risk;
        public final Mode mode;
        public final boolean backgroundAllowed;
        Capability(String id,String title,String category,String purpose,String route,String guideId,String permission,
                    List<String> triggers,List<String> related,List<String> examples,Risk risk,Mode mode,boolean backgroundAllowed){
            this.id=id;this.title=title;this.category=category;this.purpose=purpose;this.route=route;this.guideId=guideId;this.permission=permission;
            this.triggers=unmod(triggers);this.related=unmod(related);this.examples=unmod(examples);this.risk=risk;this.mode=mode;this.backgroundAllowed=backgroundAllowed;
        }
        private static List<String> unmod(List<String> x){return Collections.unmodifiableList(new ArrayList<>(x==null?Collections.emptyList():x));}
    }

    private final List<Capability> all;
    private final Map<String,Capability> byId = new LinkedHashMap<>();

    public NoriAppCapabilityCatalog(){
        List<Capability> c=new ArrayList<>();
        add(c,"home","Home","Navigation","See Nori's current workspace and important next options","#/","guide-home","none",Mode.EXPLAIN,Risk.LOW,false,"home,main,start,where am i");
        add(c,"meet_nori","Meet Nori","Conversation","Talk to Nori by text or voice","#/meet-nori","guide-meet","microphone (only for voice)",Mode.ACTION,Risk.LOW,false,"chat,talk,ask nori,voice");
        add(c,"command","Command","Control","Turn a deliberate request into a previewable command chain","#/command","guide-command","none",Mode.ACTION,Risk.MODERATE,false,"command,do this,help me do");
        add(c,"tasks","Tasks","Academics","Create, review and organize assignments and tasks","#/tasks","guide-tasks","none",Mode.ACTION,Risk.MODERATE,false,"task,assignment,homework");
        add(c,"study","Study Center","Academics","Find study methods, resources and active study tools","#/study","guide-study","storage only when user grants a library",Mode.ACTION,Risk.LOW,false,"study,learn,resource,library");
        add(c,"results","Results","Academics","Record and inspect assessment results","#/results","guide-results","none",Mode.ACTION,Risk.MODERATE,false,"result,score,mark,grade");
        add(c,"progress","Progress","Intelligence","Review longitudinal academic and capability growth","#/progress","guide-progress","none",Mode.EXPLAIN,Risk.LOW,false,"progress,analytics,trend");
        add(c,"calendar","Calendar","Planning","Plan study blocks, deadlines and events","#/calendar","guide-calendar","calendar only when required",Mode.ACTION,Risk.MODERATE,false,"calendar,schedule,deadline");
        add(c,"alarms","Alarms","Planning","Create and manage deliberate reminders and alarms","#/alarms","guide-alarms","notifications/alarm",Mode.ACTION,Risk.MODERATE,false,"alarm,reminder,remind me");
        add(c,"exams","Exams","Integrity","Prepare and enter explicit exam-mode workflows","#/exams","guide-exams","screen capture only when explicitly started",Mode.ACTION,Risk.HIGH,false,"exam,test,assessment integrity");
        add(c,"focus","Focus","Protection","Use bounded focus controls selected by the user","#/focus","guide-focus","usage access only if enabled",Mode.ACTION,Risk.HIGH,false,"focus,block,distraction");
        add(c,"recover","Recover","Protection","Reduce load and recover from overload without erasing history","#/recover","guide-recover","none",Mode.ACTION,Risk.MODERATE,false,"recover,overwhelmed,reset plan");
        add(c,"notifications","Notifications","System","Inspect Nori notifications and pending user-created actions","#/notifications","guide-notifications","notifications",Mode.EXPLAIN,Risk.LOW,false,"notifications,pending");
        add(c,"inbox","Inbox","System","Review Nori-generated items awaiting attention","#/inbox","guide-inbox","none",Mode.ACTION,Risk.LOW,false,"inbox,queue");
        add(c,"diagnostic","Diagnostic","Intelligence","Inspect system health and capability limitations","#/diagnostic","guide-diagnostic","none",Mode.EXPLAIN,Risk.LOW,false,"diagnostic,health,broken");
        add(c,"timeline","Timeline","Intelligence","Review important recorded events and outcomes","#/timeline","guide-timeline","none",Mode.EXPLAIN,Risk.LOW,false,"timeline,history,what happened");
        add(c,"integrity","Integrity","System","Inspect academic-integrity and action boundaries","#/integrity","guide-integrity","none",Mode.EXPLAIN,Risk.LOW,false,"integrity,rules,permissions");
        add(c,"profile","Profile / Settings","System","Configure Nori interfaces, privacy and controls","#/profile","guide-profile","none",Mode.ACTION,Risk.MODERATE,false,"settings,profile,privacy,interface");
        add(c,"kage","Kage Avatar","Interface","Use the Kage visual companion while keeping the same Brain","#/profile","guide-interface","none",Mode.ACTION,Risk.LOW,false,"kage avatar,kage");
        add(c,"circle","Interactive Circle","Interface","Use the JARVIS-style technical interface with the same Brain","#/profile","guide-interface","none",Mode.ACTION,Risk.LOW,false,"interactive circle,circle");
        add(c,"hybrid","Hybrid Interface","Interface","Combine visual interfaces without changing memory or state","#/profile","guide-interface","none",Mode.ACTION,Risk.LOW,false,"hybrid");
        add(c,"compact","Compact / Fast","Interface","Use a reduced interface for quick actions and answers","#/profile","guide-interface","none",Mode.ACTION,Risk.LOW,false,"compact,fast mode");
        add(c,"camera_context","Visual Context","Context","Use a user-started camera capture to understand a visible situation","#/meet-nori","guide-visual","camera only when explicitly granted",Mode.ACTION,Risk.HIGH,false,"camera,what am i looking at");
        add(c,"screen_context","Screen Context","Context","Use a user-started screen capture to understand the current screen","#/meet-nori","guide-visual","MediaProjection consent",Mode.ACTION,Risk.HIGH,false,"screen,what is on my screen");
        add(c,"voice_session","Voice Session","Voice","Start an explicit foreground voice session and issue commands","#/meet-nori","guide-voice","microphone",Mode.ACTION,Risk.HIGH,false,"voice,listen,nori listen");
        add(c,"study_library","Study Library","Knowledge","Connect a user-selected folder for study-resource discovery","#/study","guide-library","Storage Access Framework folder",Mode.ACTION,Risk.MODERATE,false,"study library,scan my notes");
        add(c,"research","Research","Knowledge","Plan source-grounded research and compare evidence","#/study","guide-research","network only when explicitly requested/available",Mode.ACTION,Risk.MODERATE,false,"research,find sources,compare sources");
        add(c,"documents","Documents","Knowledge","Understand PDFs, notes, tables and study documents","#/study","guide-documents","user-granted file access",Mode.ACTION,Risk.MODERATE,false,"pdf,document,notes");
        add(c,"goal_decomposition","Goal Decomposition","Planning","Break a large goal into editable domains, skills and checkpoints","#/progress","guide-goals","none",Mode.ACTION,Risk.LOW,false,"big goal,break this down");
        add(c,"adaptive_study","Adaptive Study","Learning","Choose and combine study methods from observed response","#/study","guide-adaptive-study","none",Mode.ACTION,Risk.LOW,false,"study method,too fast,too slow");
        add(c,"energy_checkin","Energy Check-in","Planning","Use explicit student check-ins to protect high-focus windows","#/calendar","guide-energy","none",Mode.ACTION,Risk.LOW,false,"energy,sharp time,when should i study");
        add(c,"outcome_loop","Outcome Loop","Learning","Learn whether a Nori intervention helped without silently changing rules","#/progress","guide-outcomes","none",Mode.EXPLAIN,Risk.LOW,false,"did that help,adapt");
        add(c,"self_correction","Self-Correction","Development","Track capability growth in self-correction and independence","#/progress","guide-development","none",Mode.EXPLAIN,Risk.LOW,false,"self correction,independence");
        add(c,"action_preview","Action Preview","Control","Show what Nori intends to do before a consequential action","#/command","guide-actions","none",Mode.ACTION,Risk.MODERATE,false,"preview,what will you do");
        add(c,"manual_guides","Manual Guides","Help","Give exact step-by-step instructions without performing the action","#/meet-nori","guide-help","none",Mode.GUIDE,Risk.LOW,false,"how do i,show me,guide me");
        add(c,"capability_disclosure","Capability Map","Help","Explain what Nori can, cannot, or needs permission to do","#/diagnostic","guide-capabilities","none",Mode.EXPLAIN,Risk.LOW,false,"can you,what can nori do,are you able");
        add(c,"permission_explainer","Permission Explainer","Privacy","Explain why a permission is needed before requesting it","#/profile","guide-permissions","none",Mode.EXPLAIN,Risk.LOW,false,"why permission,why camera");
        add(c,"privacy_mode","Private Mode","Privacy","Keep user-started visual/context data from being sent to remote providers","#/profile","guide-privacy","none",Mode.ACTION,Risk.MODERATE,false,"private mode,don't send");
        add(c,"sensitive_chat","Sensitive Chat","Privacy","Protect sensitive conversation history behind a device-auth boundary","#/meet-nori","guide-sensitive-chat","device biometric",Mode.ACTION,Risk.HIGH,false,"private chat,lock chat");
        add(c,"focus_selection","Focus App Selection","Protection","Let the user choose which apps are eligible for focus controls","#/focus","guide-focus-apps","usage access only if enabled",Mode.ACTION,Risk.HIGH,false,"select apps,focus apps");
        add(c,"focus_review","Focus Review","Protection","Review why a selected app was allowed, warned, blocked or reviewed","#/focus","guide-focus-review","none",Mode.EXPLAIN,Risk.LOW,false,"why blocked,why allowed");
        add(c,"scheduled_actions","Scheduled Actions","Control","Execute only actions the user deliberately configured for a schedule","#/calendar","guide-scheduled-actions","relevant Android permission",Mode.ACTION,Risk.HIGH,true,"schedule action,scheduled");
        add(c,"background_boundary","Background Boundary","Control","Explain and enforce that Nori does not silently act in the background","#/integrity","guide-background","none",Mode.EXPLAIN,Risk.LOW,false,"background,why did nori not");
        add(c,"voice_navigation","Voice Navigation","Navigation","Navigate to Nori features using natural language","#/meet-nori","guide-navigation","microphone only for voice",Mode.ACTION,Risk.LOW,false,"open,go to,where is");
        add(c,"multi_step_commands","Multi-Step Commands","Control","Preview dependency-aware multi-step actions before execution","#/command","guide-multistep","varies",Mode.ACTION,Risk.HIGH,false,"do these steps,then");
        add(c,"verification","Action Verification","Control","Verify the visible result of an action and report uncertainty","#/diagnostic","guide-verification","none",Mode.EXPLAIN,Risk.LOW,false,"did it work,verify");
        add(c,"cancel_action","Cancel / Undo","Control","Cancel an unexecuted plan or use a supported rollback path","#/command","guide-cancel","none",Mode.ACTION,Risk.MODERATE,false,"cancel,stop,undo");
        add(c,"explain_failure","Failure Explanation","Help","Explain why Nori could not complete an action and give the next safe route","#/diagnostic","guide-failure","none",Mode.EXPLAIN,Risk.LOW,false,"why failed,not working");
        add(c,"offline_mode","Offline Core","Reliability","Continue core Nori functions without a network connection","#/diagnostic","guide-offline","none",Mode.EXPLAIN,Risk.LOW,false,"offline,no internet");
        add(c,"provider_routing","AI Provider Routing","Intelligence","Choose configured providers according to capability, privacy and reliability","#/profile","guide-providers","network/provider consent",Mode.EXPLAIN,Risk.MODERATE,false,"which AI,provider");
        add(c,"model_council","Model Council","Intelligence","Optionally compare multiple model outputs as consistency evidence, not truth","#/diagnostic","guide-model-council","provider consent",Mode.EXPLAIN,Risk.MODERATE,false,"compare models");
        add(c,"knowledge_verification","Knowledge Verification","Intelligence","Label knowledge as verified, partial, unverified or conflicting","#/diagnostic","guide-verification","sources/network when requested",Mode.EXPLAIN,Risk.LOW,false,"is that true,verify claim");
        add(c,"research_synthesis","Research Synthesis","Intelligence","Deduplicate, compare and organize many sources into evidence groups","#/study","guide-research","network only when requested",Mode.ACTION,Risk.MODERATE,false,"compare 10 sources");
        add(c,"scenario_planning","Scenario Planning","Planning","Explore bounded what-if paths without pretending uncertainty is certainty","#/command","guide-scenarios","none",Mode.ACTION,Risk.LOW,false,"what if,scenario");
        add(c,"resource_preparation","Resource Preparation","Planning","Prepare likely resources from explicit syllabus, assessment and schedule signals","#/study","guide-preparation","none",Mode.ACTION,Risk.MODERATE,false,"prepare resources");
        add(c,"interrupt_queue","Interrupt Queue","Focus","Hold non-urgent Nori interruptions during protected interaction windows","#/focus","guide-interruptions","none",Mode.ACTION,Risk.LOW,false,"hold notifications,not now");
        add(c,"support_mode","Support Mode","Human Context","Adjust support between normal, lighten-load, stabilize, safety-first and push","#/recover","guide-support","none",Mode.ACTION,Risk.MODERATE,false,"help me,too much,overwhelmed");
        add(c,"language_continuity","Language Continuity","Conversation","Maintain the selected conversation language and locale when possible","#/meet-nori","guide-language","none",Mode.EXPLAIN,Risk.LOW,false,"speak english,amharic,oromo");
        add(c,"memory_recall","Memory","Memory","Recall governed relevant memory with confidence and stale/conflict warnings","#/meet-nori","guide-memory","none",Mode.ACTION,Risk.MODERATE,false,"what do you remember");
        add(c,"memory_edit","Memory Editing","Memory","Review or edit a memory rather than silently changing it","#/profile","guide-memory","none",Mode.ACTION,Risk.HIGH,false,"edit memory,change memory");
        add(c,"memory_forget","Memory Forget","Memory","Process an explicit request to avoid/forget a memory under the app's memory controls","#/profile","guide-memory","none",Mode.ACTION,Risk.HIGH,false,"forget this,don't remember");
        add(c,"timeline_events","Meaningful Events","Memory","Record meaningful outcomes rather than indiscriminate activity logs","#/timeline","guide-timeline","none",Mode.EXPLAIN,Risk.LOW,false,"record this event");
        add(c,"development_report","Development Report","Development","Summarize growth in knowledge, planning, problem solving and independence","#/progress","guide-development","none",Mode.EXPLAIN,Risk.LOW,false,"development report");
        add(c,"diagnostics","System Diagnostics","Reliability","Inspect health of state, memory, provider and action layers","#/diagnostic","guide-diagnostic","none",Mode.EXPLAIN,Risk.LOW,false,"run diagnostics");
        add(c,"capability_audit","Capability Audit","Reliability","Show which Nori capabilities are implemented, limited or unavailable","#/diagnostic","guide-capabilities","none",Mode.EXPLAIN,Risk.LOW,false,"what is implemented");
        add(c,"interface_switch","Interface Switching","Interface","Switch Standard, Kage, Circle, Hybrid or Compact without resetting Brain state","#/profile","guide-interface","none",Mode.ACTION,Risk.LOW,false,"switch interface");
        add(c,"reduced_motion","Reduced Motion","Accessibility","Reduce animation intensity while preserving function","#/profile","guide-accessibility","none",Mode.ACTION,Risk.LOW,false,"reduce motion");
        add(c,"predictive_back","Predictive Back","Navigation","Use Android's modern back-navigation model for predictable navigation","#/profile","guide-navigation","none",Mode.EXPLAIN,Risk.LOW,false,"back gesture");
        add(c,"adaptive_layout","Adaptive Layout","Interface","Adapt the Nori workspace to different screen sizes and orientations","#/profile","guide-accessibility","none",Mode.EXPLAIN,Risk.LOW,false,"tablet,landscape");
        add(c,"local_first","Local First","Reliability","Prefer local deterministic processing before optional external intelligence","#/diagnostic","guide-offline","none",Mode.EXPLAIN,Risk.LOW,false,"local first");
        add(c,"action_log","Action History","Control","Show user-visible records of consequential Nori actions and outcomes","#/timeline","guide-actions","none",Mode.EXPLAIN,Risk.MODERATE,false,"action history");
        add(c,"confirmation_policy","Confirmation Policy","Control","Explain when Nori requires a confirmation and why","#/integrity","guide-actions","none",Mode.EXPLAIN,Risk.LOW,false,"why confirm");
        add(c,"human_override","Human Override","Control","Let the user cancel, change or reject Nori's proposed route","#/command","guide-override","none",Mode.ACTION,Risk.HIGH,false,"override,nori stop");
        add(c,"capability_fallback","Capability Fallback","Help","Offer manual instructions when Nori cannot perform a requested action","#/meet-nori","guide-fallback","none",Mode.GUIDE,Risk.LOW,false,"you can't do it,show me how");
        add(c,"confusion_recovery","Confusion Recovery","Help","Detect when a user is lost and switch from task execution to orientation","#/meet-nori","guide-confusion","none",Mode.GUIDE,Risk.LOW,false,"i'm lost,i'm confused,what do i do");
        add(c,"first_run","First Run","Onboarding","Explain the Nori mental model, interfaces, permissions and boundaries","#/profile","guide-first-run","none",Mode.GUIDE,Risk.LOW,false,"new to nori,how does this work");
        add(c,"feature_search","Feature Search","Help","Search Nori's capability map by natural language instead of menus","#/meet-nori","guide-capabilities","none",Mode.ACTION,Risk.LOW,false,"where is,find feature");
        add(c,"route_preview","Route Preview","Navigation","Show where a requested feature will take the user before navigation","#/meet-nori","guide-navigation","none",Mode.EXPLAIN,Risk.LOW,false,"where will this open");
        add(c,"action_scope","Action Scope","Control","State exactly which apps, data and settings an action will touch","#/command","guide-actions","varies",Mode.EXPLAIN,Risk.HIGH,false,"what will this change");
        add(c,"permission_boundary","Permission Boundary","Control","Refuse to infer or silently acquire permissions","#/integrity","guide-permissions","none",Mode.EXPLAIN,Risk.HIGH,false,"can you access my camera");
        add(c,"no_covert_activity","No Covert Activity","Privacy","Guarantee that mic, camera, screen and cross-app actions require visible user initiation or deliberate scheduling","#/integrity","guide-background","none",Mode.EXPLAIN,Risk.CRITICAL,false,"are you watching,background");
        add(c,"user_started_background_voice","Foreground Voice Boundary","Voice","Keep voice sessions explicitly started and visibly stoppable","#/meet-nori","guide-voice","microphone",Mode.ACTION,Risk.HIGH,false,"start voice,stop listening");
        add(c,"screen_capture_consent","Screen Capture Consent","Privacy","Use Android's user consent flow before screen capture","#/meet-nori","guide-visual","MediaProjection",Mode.ACTION,Risk.HIGH,false,"share screen");
        add(c,"camera_consent","Camera Consent","Privacy","Use Android camera permission and explicit capture entry points","#/meet-nori","guide-visual","camera",Mode.ACTION,Risk.HIGH,false,"use camera");
        add(c,"notification_action","Notification Action","Control","Turn a user-created Nori reminder into a visible notification action","#/notifications","guide-notifications","notifications",Mode.ACTION,Risk.MODERATE,true,"notification action");
        add(c,"schedule_action","Scheduled User Action","Control","Run a previously authorized scheduled action with scope and expiry checks","#/calendar","guide-scheduled-actions","relevant permission",Mode.ACTION,Risk.HIGH,true,"run my scheduled action");
        add(c,"action_expiry","Action Expiry","Control","Expire stale action authorization instead of reusing it indefinitely","#/integrity","guide-actions","none",Mode.EXPLAIN,Risk.MODERATE,false,"old permission");
        add(c,"double_confirm","High Risk Confirmation","Control","Require a second deliberate confirmation for high-impact actions","#/command","guide-actions","none",Mode.ACTION,Risk.HIGH,false,"confirm twice");
        add(c,"dry_run","Dry Run","Control","Simulate an action chain without executing it","#/command","guide-actions","none",Mode.ACTION,Risk.MODERATE,false,"preview only,dry run");
        add(c,"rollback_plan","Rollback Plan","Control","Prepare a rollback/undo path before supported consequential actions","#/command","guide-actions","none",Mode.ACTION,Risk.HIGH,false,"undo plan");
        add(c,"post_action_check","Post-Action Check","Control","Ask whether the intended result actually occurred and record outcome","#/diagnostic","guide-verification","none",Mode.ACTION,Risk.LOW,false,"check result");
        add(c,"explainable_action","Explainable Action","Control","Tell the user what Nori will do, why, scope and expected result","#/command","guide-actions","none",Mode.EXPLAIN,Risk.LOW,false,"why are you doing this");
        add(c,"manual_to_voice","Manual-to-Voice Handoff","Help","Turn a manual guide step into a user-requested voice action","#/meet-nori","guide-help","microphone only for voice",Mode.ACTION,Risk.MODERATE,false,"do the next step for me");
        add(c,"voice_to_manual","Voice-to-Manual Handoff","Help","Switch from failed automation to an exact manual guide","#/meet-nori","guide-fallback","none",Mode.GUIDE,Risk.LOW,false,"show me how instead");
        add(c,"context_resume","Context Resume","Conversation","Resume a user-started task without silently continuing actions","#/meet-nori","guide-actions","none",Mode.ACTION,Risk.MODERATE,false,"continue where we stopped");
        add(c,"task_state","Task State","Conversation","Explain the current task state: proposed, awaiting confirmation, executing, verified or failed","#/command","guide-actions","none",Mode.EXPLAIN,Risk.LOW,false,"what state is this");
        add(c,"capability_limits","Capability Limits","Help","State exactly when Nori needs Android, a provider, a permission or the user","#/diagnostic","guide-capabilities","none",Mode.EXPLAIN,Risk.LOW,false,"what can't you do");
        add(c,"provider_status","Provider Status","Reliability","Show whether local, remote or unavailable intelligence is being used","#/diagnostic","guide-providers","none",Mode.EXPLAIN,Risk.LOW,false,"which model are you using");
        add(c,"offline_fallback","Offline Fallback","Reliability","Fall back to local Nori behavior when network/provider work fails","#/diagnostic","guide-offline","none",Mode.EXPLAIN,Risk.LOW,false,"internet failed");
        add(c,"research_evidence_gap","Evidence Gap","Research","Identify what is still unknown before a research answer is treated as reliable","#/study","guide-research","network when requested",Mode.EXPLAIN,Risk.LOW,false,"what don't we know");
        add(c,"contradiction_review","Contradiction Review","Reasoning","Expose conflicting evidence instead of silently choosing one","#/diagnostic","guide-verification","none",Mode.EXPLAIN,Risk.LOW,false,"sources disagree");
        add(c,"uncertainty","Uncertainty","Reasoning","Separate known facts, inference, assumptions and unknowns","#/diagnostic","guide-reasoning","none",Mode.EXPLAIN,Risk.LOW,false,"how sure are you");
        add(c,"decision_options","Decision Options","Reasoning","Present relevant options and trade-offs without taking the decision away from the user","#/command","guide-reasoning","none",Mode.EXPLAIN,Risk.LOW,false,"what are my options");
        add(c,"goal_progression","Goal Progression","Development","Show movement toward a goal without reducing growth to a single score","#/progress","guide-development","none",Mode.EXPLAIN,Risk.LOW,false,"am i improving");
        add(c,"study_pace","Study Pace","Learning","Detect reported too-fast/too-slow study pace and adapt method selection","#/study","guide-adaptive-study","none",Mode.ACTION,Risk.LOW,false,"too fast,too slow");
        add(c,"mistake_analysis","Mistake Analysis","Learning","Classify mistakes and choose targeted correction methods","#/results","guide-results","none",Mode.ACTION,Risk.LOW,false,"why did i miss this");
        add(c,"retrieval_plan","Retrieval Practice","Learning","Build retrieval-oriented study sessions from current mastery evidence","#/study","guide-adaptive-study","none",Mode.ACTION,Risk.LOW,false,"quiz me,recall");
        add(c,"spaced_review","Spaced Review","Learning","Schedule review around observed mastery and explicit availability","#/calendar","guide-adaptive-study","calendar when scheduled",Mode.ACTION,Risk.MODERATE,false,"spaced review");
        add(c,"interleaving","Interleaving","Learning","Mix related problem types when evidence suggests it will help","#/study","guide-adaptive-study","none",Mode.ACTION,Risk.LOW,false,"mix problems");
        add(c,"worked_examples","Worked Examples","Learning","Use worked examples when a learner is still building a concept","#/study","guide-adaptive-study","none",Mode.ACTION,Risk.LOW,false,"show example");
        add(c,"exam_mode","Exam Mode","Learning","Switch to an explicit exam-focused interface with integrity controls","#/exams","guide-exams","screen capture only if started",Mode.ACTION,Risk.HIGH,false,"exam mode");
        add(c,"assignment_mode","Assignment Mode","Learning","Break assignments into steps while preserving student authorship","#/tasks","guide-tasks","none",Mode.ACTION,Risk.MODERATE,false,"help with assignment");
        add(c,"life_support","Life Support","Human Context","Offer manageable next steps when life circumstances reduce available capacity","#/recover","guide-support","none",Mode.ACTION,Risk.MODERATE,false,"i can't handle everything");
        add(c,"small_start","Small Start","Human Context","Offer a deliberately small first action when activation is low","#/recover","guide-support","none",Mode.ACTION,Risk.LOW,false,"i can't start");
        add(c,"load_reduction","Load Reduction","Human Context","Reduce plan complexity without declaring failure","#/recover","guide-support","none",Mode.ACTION,Risk.MODERATE,false,"too much to do");
        add(c,"human_escalation","Human Escalation","Human Context","Recommend involving a trusted human when the situation exceeds Nori's role","#/recover","guide-support","none",Mode.GUIDE,Risk.HIGH,false,"i need a person");
        add(c,"human_behavior_context","Human Context Understanding","Human Context","Interpret behavior as signals with uncertainty rather than diagnosing causes","#/meet-nori","guide-support","none",Mode.EXPLAIN,Risk.LOW,false,"why am i stuck,what is happening with me,behavior pattern");
        add(c,"daily_checkin","Daily Check-in","Human Context","Use a short optional check-in to make plans match the student's real day","#/meet-nori","guide-support","none",Mode.ACTION,Risk.LOW,false,"how was my day,check in,what am i dealing with");
        add(c,"world_news","News","World","Request current news through an external source when freshness matters","#/meet-nori","guide-research","network/provider when requested",Mode.ACTION,Risk.MODERATE,false,"latest news,today's news,what happened today");
        add(c,"world_weather","Weather","World","Request current weather through a weather-capable source","#/meet-nori","guide-research","network/provider when requested",Mode.ACTION,Risk.LOW,false,"weather today,forecast,is it raining");
        add(c,"world_trends","Trends","World","Check current trends with timestamps and source context","#/meet-nori","guide-research","network/provider when requested",Mode.ACTION,Risk.MODERATE,false,"latest trends,what is trending,right now");
        add(c,"growth_space","Growth Space","Development","Support growth across academics, self-correction, independence, adaptability and life skills","#/progress","guide-development","none",Mode.EXPLAIN,Risk.LOW,false,"grow,improve,life skills,personal growth");
        add(c,"execution_lifecycle","Functional Execution","Control","Track discover through verify/recover/learn without claiming success early","#/command","guide-actions","none",Mode.ACTION,Risk.MODERATE,false,"actually do it,execute,verify,what happened");
        add(c,"capability_truth","Capability Truth","Reliability","Tell whether a capability is understood, guideable, preparable, executable and verifiable","#/diagnostic","guide-capabilities","none",Mode.EXPLAIN,Risk.LOW,false,"can you really do this,is this actually working");
        add(c,"media_safety","Media Safety","Safety","Apply age-aware boundaries to unnecessary sexual or graphic media requests","#/profile","guide-capabilities","none",Mode.EXPLAIN,Risk.HIGH,false,"unsafe image,graphic image,sexual image");
        for(Capability x:c)byId.put(x.id,x.id==null?null:x);
        all=Collections.unmodifiableList(c);
    }

    private void add(List<Capability> out,String id,String title,String category,String purpose,String route,String guide,String permission,Mode mode,Risk risk,boolean bg,String... terms){
        List<String> triggers=Arrays.asList(terms);
        out.add(new Capability(id,title,category,purpose,route,guide,permission,triggers,Collections.emptyList(),triggers,risk,mode,bg));
    }
    public List<Capability> all(){return all;}
    public Capability get(String id){return byId.get(id);}
    public List<Capability> search(String query,int limit){
        String q=norm(query); if(q.isEmpty())return Collections.emptyList();
        List<Scored> s=new ArrayList<>();
        for(Capability c:all){int score=0;String hay=norm(c.id+" "+c.title+" "+c.category+" "+c.purpose+" "+String.join(" ",c.triggers));
            for(String token:q.split(" ")) if(token.length()>1 && hay.contains(token))score+=2;
            if(hay.contains(q))score+=6;
            if(score>0)s.add(new Scored(c,score));}
        s.sort((a,b)->Integer.compare(b.score,a.score));List<Capability> r=new ArrayList<>();for(Scored x:s){if(r.size()>=Math.max(1,limit))break;r.add(x.c);}return r;
    }
    private static final class Scored{final Capability c;final int score;Scored(Capability c,int s){this.c=c;score=s;}}
    private static String norm(String s){return String.valueOf(s==null?"":s).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9 ]+"," ").replaceAll("\\s+"," ").trim();}
}
