package com.nori.jarvis.nori.ai;

import com.nori.jarvis.nori.memory.MemoryEngine;
import com.nori.jarvis.nori.memory.context.NoriMemoryContext;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Real local composition layer for {@link LocalAiProvider}.
 *
 * Before this existed, NoriBrain.askOptionalAi() computed a real cognitive
 * preflight (NoriCognitiveEngine.ThoughtState: intent, answer shape, effort,
 * confidence) and a real governed memory context (NoriMemoryContext) on
 * every request — then threw both away the moment local answered, because
 * LocalAiProvider.generate() only ever read the raw prompt text and replied
 * with one of two canned lines. This class is the missing connection: it
 * reads the answer-shape signal NoriBrain already embeds in
 * AiRequest.systemInstruction and independently re-queries the same durable
 * memory store NoriBrain used, so a local-only answer (no network, no API
 * key, ever) is actually shaped by what kind of request this is and
 * grounded in real recalled facts — not a trained model's fluency, but not
 * a static string either.
 *
 * Hard rule, same as the server-side Brain: never invent a score, record,
 * or state change. If there isn't enough real information to answer
 * specifically, say so plainly instead of filling the gap with something
 * that merely sounds confident.
 */
public final class NoriLocalThinkingEngine {

    private final MemoryEngine memoryEngine;

    public NoriLocalThinkingEngine(MemoryEngine memoryEngine) {
        this.memoryEngine = memoryEngine;
    }

    private static final Pattern PERCENT_OF = Pattern.compile(
        "^\\s*(?:what is )?([0-9]+(?:\\.[0-9]+)?)\\s*%\\s*of\\s*([0-9]+(?:\\.[0-9]+)?)\\s*\\??\\s*$",
        Pattern.CASE_INSENSITIVE);
    private static final Pattern ARITHMETIC = Pattern.compile(
        "^\\s*(-?[0-9]+(?:\\.[0-9]+)?)\\s*([+\\-*/])\\s*(-?[0-9]+(?:\\.[0-9]+)?)\\s*\\??\\s*$");
    private static final Pattern MODE_LINE = Pattern.compile(
        "Decision mode=([A-Z_]+); effort=([A-Z_]+); confidence=([A-Z_]+)");

    public String compose(AiRequest request) {
        String prompt = request.prompt == null ? "" : request.prompt.trim();

        String arithmetic = tryArithmetic(prompt);
        if (arithmetic != null) return arithmetic;

        String shape = "DIRECT";
        Matcher m = MODE_LINE.matcher(request.systemInstruction == null ? "" : request.systemInstruction);
        if (m.find()) shape = m.group(1);

        NoriMemoryContext memory = NoriMemoryContext.build(memoryEngine, prompt, 6);
        String memoryLine = memory.compactContext.isEmpty() ? null : memory.compactContext;
        boolean conflicted = memory.conflictDetected;
        boolean stale = memory.staleRisk;

        switch (shape) {
            case "SUPPORT": return supportReply(memoryLine);
            case "OPTIONS": return optionsReply(prompt, memoryLine);
            case "PLAN": return planReply(prompt, memoryLine);
            case "EXPLAIN": return explainReply(prompt, memoryLine, conflicted, stale);
            case "ACTION":
            case "RESEARCH": return honestLimitReply(shape);
            default: return directReply(prompt, memoryLine, conflicted, stale);
        }
    }

    private String tryArithmetic(String p) {
        Matcher m = PERCENT_OF.matcher(p);
        if (m.matches()) {
            double a = Double.parseDouble(m.group(1)), b = Double.parseDouble(m.group(2));
            return format(a * b / 100.0);
        }
        m = ARITHMETIC.matcher(p);
        if (m.matches()) {
            double a = Double.parseDouble(m.group(1)), b = Double.parseDouble(m.group(3));
            String op = m.group(2);
            switch (op) {
                case "+": return format(a + b);
                case "-": return format(a - b);
                case "*": return format(a * b);
                default:
                    if (b == 0) return "Division by zero is undefined.";
                    return format(a / b);
            }
        }
        return null;
    }

    private String supportReply(String memoryLine) {
        StringBuilder b = new StringBuilder("I hear you. ");
        if (memoryLine != null) {
            b.append("From what you've told me before, this fits a pattern I should keep in mind rather than treat as brand new. ");
        }
        b.append("Let's find the smallest useful next step instead of the whole mountain right now — one responsibility, one page, one problem, then the next.");
        return b.toString();
    }

    private String optionsReply(String prompt, String memoryLine) {
        StringBuilder b = new StringBuilder("This reads like a real decision, not a simple lookup, so here's how I'd frame it rather than guess an answer: ");
        b.append("what's the actual constraint (time, energy, a deadline), what does each option cost you, and what does each option protect? ");
        if (memoryLine != null) b.append("One thing on record that's relevant: ").append(memoryLine).append(". ");
        b.append("Tell me the real options in front of you and I'll help you weigh them against what's actually saved, not a guess.");
        return b.toString();
    }

    private String planReply(String prompt, String memoryLine) {
        StringBuilder b = new StringBuilder("Before I hand you a plan, I want it grounded in what's actually due, not a generic template. ");
        if (memoryLine != null) b.append("Relevant to this: ").append(memoryLine).append(". ");
        b.append("Give me what's actually on your plate right now (subjects, deadlines, how much time you have) and I'll rank it by real pressure instead of stacking everything evenly.");
        return b.toString();
    }

    private String explainReply(String prompt, String memoryLine, boolean conflicted, boolean stale) {
        StringBuilder b = new StringBuilder();
        if (memoryLine != null) {
            b.append("Here's what's actually on record that's relevant: ").append(memoryLine).append(". ");
            if (conflicted) b.append("Some of that conflicts with itself, so I'm leaning on the newer/more confident item rather than treating both as equally true. ");
            if (stale) b.append("Some of it is old enough that it's worth double-checking it's still accurate. ");
        } else {
            b.append("I don't have anything specific on record for this, so I'd rather say that plainly than guess at an explanation. ");
        }
        b.append("Tell me more about what you actually need explained and I'll work from what's real instead of filling gaps.");
        return b.toString();
    }

    private String directReply(String prompt, String memoryLine, boolean conflicted, boolean stale) {
        if (memoryLine != null) {
            return "From what's actually saved: " + memoryLine + (conflicted
                ? " — though that conflicts with something else on record, so treat it as uncertain until you confirm."
                : (stale ? " — that's a bit old, worth confirming it's still current." : "."));
        }
        return "I don't have hosted reasoning available right now and nothing specific on record for that, "
            + "so I won't guess at an answer that just sounds right. Ask me about your assignments, exams, "
            + "deadlines, or the handbook directly and I can work from what's actually there.";
    }

    private String honestLimitReply(String shape) {
        if ("ACTION".equals(shape)) {
            return "That needs an actual tool to execute (calendar, blocker, file system), not a generated reply — "
                + "propose it through the real action flow and I'll confirm before anything actually happens.";
        }
        return "That needs live, current information I can't reach without hosted reasoning or a search tool right now. "
            + "I won't fabricate a current answer — try again once a provider is available, or ask me something "
            + "I can answer from what's actually saved on this device.";
    }

    private static String format(double v) {
        if (v == Math.rint(v) && !Double.isInfinite(v)) return Long.toString((long) v);
        return Double.toString(v);
    }
}
