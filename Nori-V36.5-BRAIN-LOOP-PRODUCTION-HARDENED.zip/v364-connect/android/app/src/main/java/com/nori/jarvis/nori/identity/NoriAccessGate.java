package com.nori.jarvis.nori.identity;

/** Central app-entry gate. Every protected feature should require an approved session. */
public final class NoriAccessGate {
    private NoriAdmissionStatus status=NoriAdmissionStatus.SIGN_UP_REQUIRED;
    private String userId="";
    public synchronized void set(NoriAdmissionStatus s,String id){status=s==null?NoriAdmissionStatus.SIGN_UP_REQUIRED:s;userId=id==null?"":id.trim();}
    public synchronized boolean canEnter(){return status==NoriAdmissionStatus.APPROVED && !userId.isEmpty();}
    public synchronized NoriAdmissionStatus status(){return status;}
    public synchronized String userId(){return userId;}
    public synchronized String denialReason(){
        switch(status){case SIGN_UP_REQUIRED:return "sign_up_required";case PENDING_REVIEW:return "nori_admission_pending";case REJECTED:return "nori_admission_rejected";case SUSPENDED:return "account_suspended";default:return "";}
    }
}
