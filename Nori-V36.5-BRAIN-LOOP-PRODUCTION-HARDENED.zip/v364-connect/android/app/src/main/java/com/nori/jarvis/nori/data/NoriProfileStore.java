package com.nori.jarvis.nori.data;

import java.util.*;

/** Minimal user profile store: identity, grade and goals only. */
public final class NoriProfileStore {
    private static final String KEY="nori_profile_v1"; private final DataRepository repo;
    public NoriProfileStore(DataRepository r){repo=r;}
    public boolean save(String name,String grade,String goals){
        String n=clean(name),g=clean(grade),o=clean(goals); if(n.length()>120||g.length()>80||o.length()>2000)return false;
        return repo!=null&&repo.putJson(KEY,escape(n)+"|"+escape(g)+"|"+escape(o),"profile",1);
    }
    public Map<String,String> read(){Map<String,String> m=new LinkedHashMap<>();String x=repo==null?null:repo.getJson(KEY);if(x==null)return m;String[] p=x.split("\\|",-1);if(p.length>=3){m.put("name",p[0]);m.put("grade",p[1]);m.put("goals",p[2]);}return Collections.unmodifiableMap(m);}
    private static String clean(String x){return String.valueOf(x==null?"":x).replaceAll("[\\u0000-\\u001F]"," ").trim();}
    private static String escape(String x){return x.replace("|","/");}
}
