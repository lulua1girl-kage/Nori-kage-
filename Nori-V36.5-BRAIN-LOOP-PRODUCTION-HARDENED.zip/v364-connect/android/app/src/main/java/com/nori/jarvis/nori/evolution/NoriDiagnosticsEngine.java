package com.nori.jarvis.nori.evolution;

import java.util.*;

/** Runtime diagnostics and capability discovery; proposes, never silently mutates protected code/rules. */
public final class NoriDiagnosticsEngine {
    public static final class Finding { public final String area,message; public final int severity; public Finding(String a,String m,int s){area=a;message=m;severity=Math.max(0,Math.min(3,s));} }
    public List<Finding> inspect(boolean stateHealthy,boolean memoryHealthy,boolean providerHealthy,boolean actionHealthy){
        List<Finding> f=new ArrayList<>();if(!stateHealthy)f.add(new Finding("state","unified_state_unhealthy",3));if(!memoryHealthy)f.add(new Finding("memory","memory_pipeline_unhealthy",3));if(!providerHealthy)f.add(new Finding("ai","provider_reliability_degraded",2));if(!actionHealthy)f.add(new Finding("actions","action_pipeline_unhealthy",3));return Collections.unmodifiableList(f);
    }
}
