package com.nori.jarvis.nori.identity;

public enum NoriAdmissionStatus { SIGN_UP_REQUIRED, PENDING_REVIEW, APPROVED, REJECTED, SUSPENDED }
