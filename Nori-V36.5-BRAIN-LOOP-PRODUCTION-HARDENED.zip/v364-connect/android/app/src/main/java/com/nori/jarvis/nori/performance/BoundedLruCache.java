package com.nori.jarvis.nori.performance;

import java.util.LinkedHashMap;
import java.util.Map;

/** Small process-local cache with a hard entry bound; no data is persisted here. */
public final class BoundedLruCache<K,V> {
    private final int maxEntries;
    private final LinkedHashMap<K,V> map;
    public BoundedLruCache(int maxEntries) {
        if (maxEntries < 1) throw new IllegalArgumentException("maxEntries must be positive");
        this.maxEntries = maxEntries;
        this.map = new LinkedHashMap<K,V>(16, 0.75f, true) {
            protected boolean removeEldestEntry(Map.Entry<K,V> eldest) { return size() > BoundedLruCache.this.maxEntries; }
        };
    }
    public synchronized V get(K key) { return map.get(key); }
    public synchronized void put(K key, V value) { if (key != null && value != null) map.put(key, value); }
    public synchronized void clear() { map.clear(); }
    public synchronized int size() { return map.size(); }
    public int maxEntries() { return maxEntries; }
}
