package com.nori.jarvis.nori.education.model;

public final class DynamicStudySession {
    public enum Mode { RETEACH, PRACTICE, RETRIEVAL, ERROR_REVIEW, EXAM_DRILL, REVIEW }
    public final String subject,topic; public final Mode mode; public final int minutes; public final String adaptationReason;
    public DynamicStudySession(String subject,String topic,Mode mode,int minutes,String adaptationReason){this.subject=subject;this.topic=topic;this.mode=mode;this.minutes=minutes;this.adaptationReason=adaptationReason;}
}
