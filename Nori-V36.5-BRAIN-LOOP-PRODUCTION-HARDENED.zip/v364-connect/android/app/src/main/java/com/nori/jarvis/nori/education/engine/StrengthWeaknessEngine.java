package com.nori.jarvis.nori.education.engine;

import com.nori.jarvis.nori.education.model.*; import java.util.*;

public final class StrengthWeaknessEngine {
    public StrengthWeaknessReport analyze(List<AcademicEvidence> evidence){
        Map<String,List<AcademicEvidence>> by=new LinkedHashMap<>(); if(evidence!=null) for(AcademicEvidence e: evidence) by.computeIfAbsent(e.subject,k->new ArrayList<>()).add(e);
        Map<String,StrengthWeaknessReport.SubjectState> states=new LinkedHashMap<>(); List<String> ws=new ArrayList<>(), ss=new ArrayList<>();
        for(var en:by.entrySet()){
            List<AcademicEvidence> rows=en.getValue(); double avg=rows.stream().mapToDouble(e->e.score).average().orElse(0);
            double mastery=Math.max(0,Math.min(1,avg/100.0)); double conf=Math.min(1,rows.size()/5.0);
            List<String> weak=new ArrayList<>(), strong=new ArrayList<>();
            for(AcademicEvidence e:rows) weak.addAll(e.missedConcepts); if(avg>=80) strong.add("consistent_above_threshold_results");
            if(weak.isEmpty()&&avg<80) weak.add("general_mastery");
            states.put(en.getKey(),new StrengthWeaknessReport.SubjectState(en.getKey(),mastery,conf,new ArrayList<>(new LinkedHashSet<>(strong)),new ArrayList<>(new LinkedHashSet<>(weak))));
            if(avg<80) ws.add(en.getKey()); else if(avg>=80) ss.add(en.getKey());
        }
        ws.sort((a,b)->Double.compare(states.get(a).mastery,states.get(b).mastery)); ss.sort((a,b)->Double.compare(states.get(b).mastery,states.get(a).mastery));
        return new StrengthWeaknessReport(states,ws,ss);
    }
}
