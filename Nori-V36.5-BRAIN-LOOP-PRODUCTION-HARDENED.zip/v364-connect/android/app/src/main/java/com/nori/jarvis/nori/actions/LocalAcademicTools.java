package com.nori.jarvis.nori.actions;

import com.nori.jarvis.nori.actions.model.*;

import java.util.*;

/** Small deterministic tool adapters proving the action boundary without touching Android UI/services. */
public final class LocalAcademicTools {
    private final Map<String, Map<String,String>> tasks = new LinkedHashMap<>();
    private final Map<String, Map<String,String>> sessions = new LinkedHashMap<>();
    private final Map<String, Map<String,String>> results = new LinkedHashMap<>();
    private final Map<String,String> undoRefs = new HashMap<>();
    private final Map<String,String> previousTaskStatus = new HashMap<>();

    public void register(ActionEngine engine) {
        Set<String> none=Collections.emptySet();
        engine.register(new ToolDefinition("create_task","Create academic task","Create a student assignment/task for academic planning.",ActionType.LOCAL_MUTATION,true,true,none), handlerCreateTask());
        engine.register(new ToolDefinition("complete_task","Complete academic task","Record that an academic task was completed.",ActionType.LOCAL_MUTATION,true,true,none), handlerCompleteTask());
        engine.register(new ToolDefinition("create_study_session","Create study session","Create a study session for academic progress.",ActionType.LOCAL_MUTATION,true,true,none), handlerCreateSession());
        engine.register(new ToolDefinition("record_result","Record result","Record an explicitly supplied academic assessment result.",ActionType.LOCAL_MUTATION,true,true,none), handlerRecordResult());
        // Focus/device tools are intentionally not registered here: Android permission adapters belong to Stage 10.
    }

    private ToolHandler handlerCreateTask(){return new ToolHandler(){
        public ActionPreview preview(ToolRequest r){return ActionPreview.allow(Collections.singletonList("Create task: "+req(r,"title","Untitled task")));}
        public ActionExecutionResult execute(ToolRequest r,String op){String id="task_"+UUID.randomUUID();Map<String,String> x=new LinkedHashMap<>(r.input);x.put("id",id);x.put("status","open");tasks.put(id,x);undoRefs.put(op,id);return new ActionExecutionResult(true,op,null,x,true);}
        public ActionExecutionResult undo(ToolRequest r,String op){String id=undoRefs.remove(op);if(id==null)id=findId(tasks,r);if(id==null)return ActionExecutionResult.fail("task_not_found_for_undo");Map<String,String> x=tasks.remove(id);return new ActionExecutionResult(true,op,null,x,true);}
    };}
    private ToolHandler handlerCompleteTask(){return new ToolHandler(){
        public ActionPreview preview(ToolRequest r){String id=findId(tasks,r);if(id==null)return ActionPreview.deny("task_not_found");return ActionPreview.allow(Collections.singletonList("Mark task "+id+" completed"));}
        public ActionExecutionResult execute(ToolRequest r,String op){String id=findId(tasks,r);if(id==null)return ActionExecutionResult.fail("task_not_found");Map<String,String>x=tasks.get(id);String before=x.get("status");previousTaskStatus.put(op,before==null?"open":before);x.put("status","done");return new ActionExecutionResult(true,op,null,x,true);}
        public ActionExecutionResult undo(ToolRequest r,String op){String id=findId(tasks,r);if(id==null)return ActionExecutionResult.fail("task_not_found");Map<String,String>x=tasks.get(id);x.put("status",previousTaskStatus.remove(op));return new ActionExecutionResult(true,op,null,x,true);}
    };}
    private ToolHandler handlerCreateSession(){return new ToolHandler(){
        public ActionPreview preview(ToolRequest r){return ActionPreview.allow(Collections.singletonList("Create study session for "+req(r,"subject","Mathematics")+" / "+req(r,"topic","Study session")));}
        public ActionExecutionResult execute(ToolRequest r,String op){String id="session_"+UUID.randomUUID();Map<String,String>x=new LinkedHashMap<>(r.input);x.put("id",id);x.put("status","planned");sessions.put(id,x);undoRefs.put(op,id);return new ActionExecutionResult(true,op,null,x,true);}
        public ActionExecutionResult undo(ToolRequest r,String op){String id=undoRefs.remove(op);if(id==null)id=findId(sessions,r);if(id==null)return ActionExecutionResult.fail("session_not_found_for_undo");Map<String,String>x=sessions.remove(id);return new ActionExecutionResult(true,op,null,x,true);}
    };}
    private ToolHandler handlerRecordResult(){return new ToolHandler(){
        public ActionPreview preview(ToolRequest r){String s=req(r,"score","");try{double n=Double.parseDouble(s);if(n<0||n>100)return ActionPreview.deny("score_must_be_0_to_100");}catch(Exception e){return ActionPreview.deny("score_invalid");}return ActionPreview.allow(Collections.singletonList("Record "+s+" for "+req(r,"subject","unknown subject")));}
        public ActionExecutionResult execute(ToolRequest r,String op){String id="result_"+UUID.randomUUID();Map<String,String>x=new LinkedHashMap<>(r.input);x.put("id",id);x.put("source","human_confirmed_action");results.put(id,x);undoRefs.put(op,id);return new ActionExecutionResult(true,op,null,x,true);}
        public ActionExecutionResult undo(ToolRequest r,String op){String id=undoRefs.remove(op);if(id==null)id=findId(results,r);if(id==null)return ActionExecutionResult.fail("result_not_found_for_undo");Map<String,String>x=results.remove(id);return new ActionExecutionResult(true,op,null,x,true);}
    };}
    private static String req(ToolRequest r,String k,String d){String v=r.input.get(k);return v==null||v.trim().isEmpty()?d:v;}
    private static String findId(Map<String,Map<String,String>> m,ToolRequest r){String id=r.input.get("id");if(id!=null&&m.containsKey(id))return id;String title=r.input.get("title");if(title!=null)for(Map.Entry<String,Map<String,String>>e:m.entrySet())if(title.equalsIgnoreCase(e.getValue().get("title")))return e.getKey();return null;}
    public int taskCount(){return tasks.size();} public int sessionCount(){return sessions.size();} public int resultCount(){return results.size();}
}
