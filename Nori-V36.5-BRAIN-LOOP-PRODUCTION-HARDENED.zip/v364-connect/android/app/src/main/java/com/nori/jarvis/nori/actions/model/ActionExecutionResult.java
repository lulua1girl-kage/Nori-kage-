package com.nori.jarvis.nori.actions.model;

public final class ActionExecutionResult {
    public final boolean ok;
    public final String operationId;
    public final String reason;
    public final Object result;
    public final boolean verified;

    public ActionExecutionResult(boolean ok, String operationId, String reason, Object result, boolean verified) {
        this.ok = ok; this.operationId = operationId; this.reason = reason; this.result = result; this.verified = verified;
    }
    public static ActionExecutionResult fail(String reason) { return new ActionExecutionResult(false, null, reason, null, false); }
}
