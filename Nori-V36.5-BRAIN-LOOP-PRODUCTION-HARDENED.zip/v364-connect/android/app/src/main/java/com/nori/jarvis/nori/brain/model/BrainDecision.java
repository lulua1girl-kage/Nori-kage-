package com.nori.jarvis.nori.brain.model;

import com.nori.jarvis.nori.academic.model.AcademicAnalysisResult;
import com.nori.jarvis.nori.brain.ContextEngine;
import com.nori.jarvis.nori.brain.VerificationEngine;
import com.nori.jarvis.nori.kage.KageEngine;
import java.util.*;
import com.nori.jarvis.nori.reasoning.ReasoningResult;

/** Immutable output of the native Stage 7 orchestration pipeline. */
public final class BrainDecision {
    public final String eventId;
    public final AcademicAnalysisResult academicResult;
    public final ContextEngine.Result contextResult;
    public final ContextEngine.Result secondaryContextResult;
    public final KageEngine.FailureType failureType;
    public final KageEngine.DegreeDecision degreeDecision;
    public final List<String> consequenceCandidates;
    public final String academicCorrection;
    public final VerificationEngine.Result verification;
    public final List<String> facts, inferences, nextActions;
    /** Stage 2 structured reasoning summary; existing fields remain unchanged. */
    public final ReasoningResult reasoning;

    public BrainDecision(String eventId, AcademicAnalysisResult academicResult, ContextEngine.Result contextResult,
                         ContextEngine.Result secondaryContextResult, KageEngine.FailureType failureType,
                         KageEngine.DegreeDecision degreeDecision, List<String> consequenceCandidates,
                         String academicCorrection, VerificationEngine.Result verification,
                         List<String> facts, List<String> inferences, List<String> nextActions) {
        this(eventId, academicResult, contextResult, secondaryContextResult, failureType, degreeDecision,
             consequenceCandidates, academicCorrection, verification, facts, inferences, nextActions, null);
    }

    public BrainDecision(String eventId, AcademicAnalysisResult academicResult, ContextEngine.Result contextResult,
                         ContextEngine.Result secondaryContextResult, KageEngine.FailureType failureType,
                         KageEngine.DegreeDecision degreeDecision, List<String> consequenceCandidates,
                         String academicCorrection, VerificationEngine.Result verification,
                         List<String> facts, List<String> inferences, List<String> nextActions, ReasoningResult reasoning) {
        this.eventId=eventId; this.academicResult=academicResult; this.contextResult=contextResult; this.secondaryContextResult=secondaryContextResult;
        this.failureType=failureType; this.degreeDecision=degreeDecision;
        this.consequenceCandidates=Collections.unmodifiableList(new ArrayList<>(consequenceCandidates));
        this.academicCorrection=academicCorrection; this.verification=verification;
        this.facts=Collections.unmodifiableList(new ArrayList<>(facts)); this.inferences=Collections.unmodifiableList(new ArrayList<>(inferences));
        this.nextActions=Collections.unmodifiableList(new ArrayList<>(nextActions));
        this.reasoning=reasoning;
    }
}
