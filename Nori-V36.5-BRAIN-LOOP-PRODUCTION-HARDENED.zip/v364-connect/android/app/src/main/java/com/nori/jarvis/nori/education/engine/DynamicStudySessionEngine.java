package com.nori.jarvis.nori.education.engine;

import com.nori.jarvis.nori.education.model.*;

public final class DynamicStudySessionEngine {
    public DynamicStudySession adapt(String subject,String topic,StrengthWeaknessReport.SubjectState state,MistakeReport mistakes,int availableMinutes,boolean nearExam){
        int mins=Math.max(10,Math.min(availableMinutes,nearExam?60:45)); DynamicStudySession.Mode mode=DynamicStudySession.Mode.RETRIEVAL; String why="retrieval strengthens retention";
        if(nearExam){mode=DynamicStudySession.Mode.EXAM_DRILL;why="exam proximity";}
        else if(state!=null&&!state.weaknesses.isEmpty()){mode=DynamicStudySession.Mode.RETEACH;why="documented weakness requires targeted reteaching";}
        else if(mistakes!=null&&!mistakes.patterns.isEmpty()){mode=DynamicStudySession.Mode.ERROR_REVIEW;why="repeated mistake pattern";}
        return new DynamicStudySession(subject,topic,mode,mins,why);
    }
}
