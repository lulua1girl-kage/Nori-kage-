package com.nori.jarvis.nori.advanced.model;

import java.util.*;

public final class AnomalyReport {
    public final String subject; public final boolean anomalous; public final double deviation;
    public final String type; public final double confidence; public final List<String> evidence;
    public AnomalyReport(String subject,boolean anomalous,double deviation,String type,double confidence,List<String> evidence){
        this.subject=subject;this.anomalous=anomalous;this.deviation=deviation;this.type=type;this.confidence=confidence;this.evidence=Collections.unmodifiableList(new ArrayList<>(evidence));
    }
}
