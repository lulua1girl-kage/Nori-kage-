# Nori Post-23 Step 28 — Repaired Functional Core

This package is an additive repair on the last **actual** uploaded baseline available to this work session: Step 27.

## What was fixed

1. **Capability truth** — Nori can distinguish a catalogued capability from a registered executable ActionEngine handler. It no longer needs to treat a capability count as proof of execution.
2. **Functional execution lifecycle** — discover → understand → resolve/prepare → preview → authorize → execute → verify, with cancel/undo/recovery paths delegated to the existing ActionEngine.
3. **Human context** — non-clinical context signals are converted into manageable next-step guidance; causes remain uncertain and disclosure remains optional.
4. **World information boundary** — news/weather/trends are explicitly marked as freshness-sensitive and require an external source/provider when current information is requested.
5. **Growth model** — growth is not reduced to grades; self-correction, consistency, self-reliance, adaptability, life skills and recovery remain separate areas.
6. **Age-aware media safety** — unnecessary sexual material and dangerous/graphic media requests are blocked or redirected for users under 18; educational handling can use safer non-graphic alternatives.
7. **App self-understanding catalog** — added entries for human context, daily check-ins, news, weather, trends, growth space, execution lifecycle, capability truth and media safety.

## What was deliberately NOT changed

- Existing Brain engines and storage architecture were not replaced.
- Existing ActionEngine permissions, educational firewall, confirmation boundary, undo and audit behavior remain authoritative.
- No silent background action was added.
- No covert microphone/camera/screen monitoring was added.
- No social publication capability was added.
- No provider was made mandatory.
- No hidden chain-of-thought or diagnostic labeling was added.
- Existing interfaces, Kage, Interactive Circle, navigation, voice and previous stage code remain in place.

## Verification

`POST23_STEP28_REPAIRED_PASS`
`POST23_STEP28_REPAIRED_STATIC_PASS`

The source-layer verification compiles the non-Android Java brain layer. An Android SDK/device build was not available in this environment, so this package is **not** claimed to be device-verified.
