#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
WWW="$ROOT/www"
TEST="$ROOT/android/app/src/test/java/com/nori/jarvis/nori/voice/NoriPresenceCapabilitiesTest.java"
for f in nori-presence-evolution-v2.js nori-presence-evolution-v2.css nori-interactive-presence-v1.js nori-avatar-v26.js; do test -f "$WWW/$f"; done
node --check "$WWW/nori-presence-evolution-v2.js"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/voice/NoriPresenceCapabilities.java"
test -f "$TEST"
grep -q 'nori-presence-evolution-v2.js' "$WWW/index.html"
grep -q 'nori-presence-evolution-v2.css' "$WWW/index.html"
grep -q 'bargeInInterrupt' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/voice/NoriPresenceCapabilities.java"
grep -q 'sameChatVoiceText' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/voice/NoriPresenceCapabilities.java"
printf 'POST23_STEP5_PRESENCE_EVOLUTION_SOURCE_PASS\n'
