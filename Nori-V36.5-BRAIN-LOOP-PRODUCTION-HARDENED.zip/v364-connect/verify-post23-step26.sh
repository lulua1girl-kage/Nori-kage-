#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/android/app/src/main/java"
OUT="$ROOT/build_step26_verify"
rm -rf "$OUT"; mkdir -p "$OUT"
mapfile -t FILES < <(python3 - <<PY
import os
root=r'''$SRC'''
for dp,_,fs in os.walk(root):
  for f in fs:
    if f.endswith('.java'):
      p=os.path.join(dp,f); s=open(p,errors='ignore').read()
      if 'import android.' not in s and 'import androidx.' not in s and 'android.' not in s and not p.endswith('NoriNativeCore.java') and not p.endswith('V32MigrationValidator.java'):
        print(p)
PY
)
javac -d "$OUT" "${FILES[@]}"
cat > "$OUT/Step26Check.java" <<'JAVA'
import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.brain.study.NoriStudyStrategyEngine;
import com.nori.jarvis.nori.brain.schedule.NoriEnergyScheduleEngine;
import com.nori.jarvis.nori.brain.loop.NoriCognitiveStateOutcomeLoop;
import java.time.*; import java.util.*;
public class Step26Check {
 public static void main(String[] a){
  NoriBrain b=new NoriBrain();
  b.getStateEngine().observeAvailability(com.nori.jarvis.nori.state.NoriState.Availability.AVAILABLE,"study");
  b.getStateEngine().observeStudy(com.nori.jarvis.nori.state.NoriState.StudyStatus.STUDYING,"chemistry","retrieval",.4,1);
  b.getStateEngine().refresh(b.getEducationalIntelligence(),b.getMemoryEngine(),b.getConversationEngine().state(),b.getSecurity(),b.getPerformance());
  if(b.getStateEngine().snapshot().recentEvents.isEmpty())throw new RuntimeException("state event stream missing");
  var cycle=b.getCognitiveStateOutcomeLoop().run("help me study chemistry","chemistry mastery",false);
  String id=b.getCognitiveStateOutcomeLoop().beginAction("SMALL_START","chemistry mastery",.7,false);
  b.getCognitiveStateOutcomeLoop().recordOutcome(id,NoriCognitiveStateOutcomeLoop.Outcome.POSITIVE,.8,"completed study block");
  b.getEnergyScheduleEngine().recordCheckIn(DayOfWeek.MONDAY,9,NoriEnergyScheduleEngine.Energy.HIGH,"sharp");
  var root=b.getGoalDecompositionEngine().decompose("I want to be a doctor");
  var methods=b.getStudyStrategyEngine().catalog();
  var selection=b.getStudyStrategyEngine().select(NoriStudyStrategyEngine.Level.STRUGGLING,NoriStudyStrategyEngine.Pace.TOO_FAST,Collections.emptySet(),"scaffold");
  var chain=b.getCommandChainEngine().plan("set up my study block for tomorrow");
  if(cycle==null||root.children.isEmpty()||methods.size()<100||selection.methods.isEmpty()||chain.steps.size()<2||b.getCognitiveStateOutcomeLoop().outcomes().isEmpty())throw new RuntimeException("step26 feature gate failed");
  System.out.println("POST23_STEP26_COGNITIVE_STATE_OUTCOME_PASS methods="+methods.size()+" stateEvents="+b.getStateEngine().snapshot().recentEvents.size()+" chainSteps="+chain.steps.size()+" outcomes="+b.getCognitiveStateOutcomeLoop().outcomes().size());
 }
}
JAVA
javac -cp "$OUT" -d "$OUT" "$OUT/Step26Check.java"
java -cp "$OUT" Step26Check
