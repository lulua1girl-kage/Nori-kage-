# Post-23 Step 23 — Decision, Planning & Adaptive Intervention

## Purpose
Advance existing planning/recovery/academic systems into two general Brain layers instead of duplicating them:

1. `NoriDecisionPlanningEngine`: Goal -> constraints -> options -> trade-offs -> resources -> dependency-aware plan -> scenarios -> verification/replan.
2. `NoriInterventionEngine`: situation signals -> interruption cost -> expected usefulness -> timing -> smallest sufficient intervention -> measured outcome -> preference/effectiveness learning.

## Existing systems preserved
Academic planning, exam planning, recovery, tasks, consequence policy, integrity protection, learning loop, student development, Human Context, Constitution and Human Override remain intact.

## Intervention policy
- Evidence is a signal, not proof of intent.
- Protected windows suppress non-essential intervention.
- User-requested help lowers the intervention threshold.
- Low capacity favors load reduction/recovery rather than pressure.
- Anti-dependency is implemented by preferring small starts and gradually removing scaffolding when evidence supports independence.
- Intervention effectiveness is measured by observed outcomes; no causal claim is made from a single observation.
- Preference is not assumed to mean effectiveness; measured outcomes can override preference.

## Implementation inspiration
Android's current WorkManager guidance formalizes constraints around execution, and modern Android samples emphasize a single source of truth and state-driven architecture. Nori applies the same architectural idea at the Brain decision layer while keeping the core deterministic/local. See Android WorkManager constraints and DataStore architecture documentation.
