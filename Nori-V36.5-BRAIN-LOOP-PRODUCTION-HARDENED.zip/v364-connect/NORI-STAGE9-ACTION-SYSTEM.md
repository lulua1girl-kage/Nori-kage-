# Nori V32 — Stage 9: Native Tool & Action System

## Scope
Stage 9 establishes the native controlled action boundary. Nori Brain may select and propose a tool, but execution is isolated behind an action engine with an educational-purpose firewall, permission checks, human confirmation, preview, verification, audit and undo.

## Native components
- `ActionEngine`: proposal -> preview -> human confirmation -> adapter execution -> verification -> undo.
- `ToolRouter`: thin routing boundary between Brain and action execution.
- `ToolDefinition`: declares purpose, action type, confirmation requirement and permissions.
- `ToolHandler`: adapter contract for native/local/Android integrations.
- `EducationalPurposeFirewall`: rejects tools that are not explicitly educationally allowed.
- `PermissionChecker`: permission boundary; device/external permissions default to denied until a later Android integration stage supplies them.
- Action models for proposals, previews, statuses, requests and results.
- Repository-backed action audit trail.
- Deterministic local academic adapters proving the boundary for task creation/completion, study-session creation and result recording.

## Safety/control invariants
1. A tool is not executable merely because code can technically call it.
2. Every mutation is proposed before execution.
3. Mutating tools require human confirmation.
4. A preview is produced before execution.
5. Execution must return a verified result or the action is failed.
6. Undo is exposed through the same registered adapter boundary.
7. Device and external tools are not enabled by default; Stage 10 supplies Android permissions/services.
8. No arbitrary shell command, arbitrary app automation, unrestricted URL opening, or hidden background action is introduced.
9. Educational purpose is checked at registration and execution.
10. The Brain remains separate from side effects.

## V32 migration boundary
Existing `nori-action-core-v27.js`, `nori-action-center-v27.js` and `nori-tool-router-v22.js` remain intact and serve as behavior/reference implementations. Stage 9 does not retire them.

## Verification
Native Stage 9 action classes and the Stage 7/8 Brain core are compiled together with smoke tests for registration, proposal, preview, confirmation, verification, undo, cancellation, permission denial and educational-purpose rejection.
Full Android APK/device validation remains pending until Android Studio/Android SDK is available.
