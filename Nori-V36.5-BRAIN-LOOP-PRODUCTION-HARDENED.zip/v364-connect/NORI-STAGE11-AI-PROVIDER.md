# Nori V32 — Stage 11 AI Provider Layer

Stage 11 introduces a provider-neutral AI abstraction. AI is an optional capability, not the Nori core.

## Architecture

Nori Brain -> AiRouter -> Local provider / optional remote provider

The local provider is always available and is the default. Remote AI requires explicit enablement and explicit user consent. No API key is hardcoded or persisted by the provider layer.

## Components

- AiRequest: provider-neutral request model.
- AiResponse: normalized success/unavailable/error/blocked result.
- AiProvider: adapter contract for future providers.
- LocalAiProvider: deterministic offline fallback; it never pretends to be a generative model.
- AiProviderConfig: explicit remote configuration; disabled by default.
- RemoteAiProvider: minimal generic HTTP adapter; provider-specific adapters can replace it.
- AiRoutingPolicy: local-only / remote-first / local-first routing.
- AiRouter: central routing and fallback boundary.

## Cost and reliability rules

1. No remote provider is enabled by default.
2. Remote use requires both enabled=true and userConsent=true.
3. Input/output size limits are enforced.
4. A remote failure falls back to local when routing permits.
5. The core app does not require an API, internet connection, or paid model.
6. No credentials are embedded in source code.
7. The router never silently turns on a remote provider.

## Android

INTERNET permission is declared because Stage 11 contains an optional remote adapter. Declaring the permission does not activate remote AI.

## Preservation

V32 AI files and existing JavaScript providers remain intact. Stage 11 adds the native abstraction without deleting the existing system.
