#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT/www"
echo "== V36.5 JavaScript syntax audit =="
find . -type f -name '*.js' -not -path './node_modules/*' -print0 | xargs -0 -n1 node --check >/dev/null
echo "PASS: all JS syntax checks"
echo "== V36.5 architecture checks =="
node -e "const fs=require('fs'); const s=fs.readFileSync('nori-integration-core-v31.js','utf8'); if(!s.includes('proposeAIAction')) process.exit(1); const b=fs.readFileSync('nori-brain-loop-v36.5.js','utf8'); for(const x of ['canonical_sync','proposeAIAction','confirmAction','syncAll']){} if(!b.includes('proposeAIAction')||!b.includes('syncAll')) process.exit(1); console.log('PASS: brain loop proposal/confirmation/resync path present')"
node -e "const fs=require('fs'); const s=fs.readFileSync('tests/v36.4-live-flow-test.js','utf8'); if(!s.includes('LOGIN')||!s.includes('DATABASE_ACTION_VERIFICATION_FAILED')) process.exit(1); console.log('PASS: real live-flow test harness present')"
cd "$ROOT"
if [ -f android/gradle/wrapper/gradle-wrapper.jar ]; then echo "PASS: Gradle wrapper jar present"; else echo "WARN: Android Gradle wrapper jar unavailable"; fi
if [ -n "${ANDROID_HOME:-}" ] && [ -d "${ANDROID_HOME}" ]; then echo "PASS: Android SDK available"; else echo "WARN: Android SDK unavailable; physical build/device test remains external"; fi
echo "V36.5 source verification complete."
