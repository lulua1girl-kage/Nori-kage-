# V33 — Operative Nori

V33 turns the V31 Integration Core + V32 Operating Protocol into an executable end-to-end operation layer.

## Core loop
User/Voice/Text → Intent → Context → Capability/Plan → Policy/Human Confirmation → Execute → Verify → Canonical Commit → Event → Response

## Implemented
- `www/nori-operative-v33.js` — single operative execution core.
- Text and model-generated actions can enter the same V33 executor.
- Persistent in-memory pending proposals with confirm/cancel/voice confirmation support.
- Capability registry with owner/risk contracts.
- Canonical server mutation gateway through `api/brain.js` (`mode: capability_action`).
- Authenticated server-side durable app state under `canonicalState.state.appData`.
- Idempotency keys stored in canonical state and bounded.
- Canonical verification after mutation.
- Local UI state mirrors canonical appData only after server commit.
- Multi-action workflow planning and sequential execution with partial-failure reporting.
- Simulation/dry-run path for workflows and individual operations.
- Unified V33 path for assignments, study sessions, calendar, reminders, alarms, results; specialist adapters remain for focus/recovery/awards.
- Added update operations for assignments, study sessions, and calendar events.
- Server confirmation gate for durable capability mutations.
- Server validation prevents client-controlled identity fields from being patched.
- `nori-meet.js` now routes AI action execution through V33 and supports workflow confirmation.

## Important architecture rule
The model does not become the database, permission manager, executor, or source of truth. It proposes structured actions. V33 and the authenticated server decide whether and how those actions execute.

## Verification
Passed:
- V26 brain architecture smoke
- V27 mentor contract smoke
- V28 explainability/rule-review smoke
- V29 canonical-state smoke
- V30 canonical-writer smoke
- V31 integration-core smoke
- V32 integrity smoke
- V32 operating-protocol smoke
- V33 operative smoke
- `node --check` on V33, patched `nori-meet.js`, and `api/brain.js`

No Android/device build or live Supabase deployment was claimed by this package.
