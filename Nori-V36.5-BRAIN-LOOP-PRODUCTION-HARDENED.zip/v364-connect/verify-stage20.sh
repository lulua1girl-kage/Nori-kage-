#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
command -v javac >/dev/null 2>&1 || { echo "ERROR: javac is required" >&2; exit 1; }
rm -rf build_stage20
mkdir -p build_stage20
# Android-dependent files are intentionally excluded here; the Android build is validated separately in Android Studio/with an installed SDK.
mapfile -t SOURCES < <(grep -L '^import android\.' $(find android/app/src/main/java/com/nori/jarvis/nori -name '*.java' -print) | grep -v '/V32MigrationValidator.java$' | grep -v '/NoriNativeCore.java$')
javac -encoding UTF-8 -d build_stage20 "${SOURCES[@]}" tests/native/Stage20Regression.java
java -cp build_stage20 Stage20Regression
# Static regression guards for critical architecture boundaries.
grep -q 'android:usesCleartextTraffic="false"' android/app/src/main/AndroidManifest.xml
grep -q 'android.permission.INTERNET' android/app/src/main/AndroidManifest.xml
test -f www/brain-engine/brain.js
test -f android/app/src/main/java/com/nori/jarvis/nori/security/NoriSecurity.java
test -f android/app/src/main/java/com/nori/jarvis/nori/advanced/AdvancedIntelligence.java
test -f android/app/src/main/java/com/nori/jarvis/nori/conversation/engine/ConversationEngine.java
echo 'STAGE20_STATIC_REGRESSION_PASS'
