# Nori V26 — Brain Architecture Upgrade

This pass applies the improved frontier-model pathway without making the frontier model the system authority.

## Core changes
- Added an explicit authority hierarchy: Human Override > Safety/System Integrity > deterministic KAGE rules > verified server state > client/user evidence > model inference > web/document content.
- Added a bounded Context Compiler. Client-supplied state, memory, brain context, conversation context, next-move data and transcript are treated as evidence with provenance labels, never as instructions.
- Added local-first handling for deterministic/simple requests that the local engine can answer correctly.
- Added configurable `NORI_PRIMARY_PROVIDER` so the underlying frontier provider can be changed without changing Nori's architecture.
- Added a global request deadline (default 18s fast, 28s reasoning/web; configurable with `NORI_GLOBAL_DEADLINE_MS`) across provider fallback attempts.
- Cross-model verification now respects the same global deadline and is skipped when insufficient time remains.
- Bumped brain API metadata to V26.

## Important boundary
The current `brain.js` endpoint still receives client-provided state/history/memory because this ZIP does not introduce a new server-side personal-state database layer. V26 therefore does **not** claim that those fields are independently verified. They are explicitly labeled as client evidence. A later state-authority pass should read canonical state from the authenticated user's server-side data source.

## Provider configuration
`NORI_PRIMARY_PROVIDER` may be `gemini`, `openai`, `anthropic`, or `backup` for the normal fast route. The provider abstraction remains intact.

## Not claimed fixed
- Android device build/signing
- complete ActionCore unification of every legacy action path
- canonical server-side personal state retrieval
- complete Human Override evidence/persistence redesign
- unified grading taxonomy
- full voice-state consolidation
