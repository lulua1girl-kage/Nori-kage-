#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/android/app/src/main/java"
OUT="$ROOT/build_step27_verify"
rm -rf "$OUT"; mkdir -p "$OUT"
mapfile -t FILES < <(python3 - <<PY
import os
root=r'''$SRC'''
for dp,_,fs in os.walk(root):
  for f in fs:
    if f.endswith('.java'):
      p=os.path.join(dp,f); s=open(p,errors='ignore').read()
      if 'import android.' not in s and 'import androidx.' not in s and 'android.' not in s and not p.endswith('NoriNativeCore.java') and not p.endswith('V32MigrationValidator.java'):
        print(p)
PY
)
javac -d "$OUT" "${FILES[@]}"
cat > "$OUT/Step27Check.java" <<'JAVA'
import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.understanding.*;
public class Step27Check {
 public static void main(String[] args){
  NoriBrain b=new NoriBrain();
  if(b.getAppUnderstandingEngine().getCatalog().all().size()<100) throw new RuntimeException("capability catalog too small");
  var lost=b.understandNoriApp("I am confused and don't know what to do");
  if(lost.intent!=NoriAppUnderstandingEngine.Intent.CONFUSED || lost.guide==null) throw new RuntimeException("confusion guide failed");
  var action=b.understandNoriApp("do this for me and set my study block");
  if(!action.actionRequested) throw new RuntimeException("action intent failed");
  var blocked=b.authorizeNoriAction(new NoriUserControlEngine.Request("open_app","Open another app",NoriUserControlEngine.Origin.SYSTEM_AUTOMATIC,false,true,false,"external app","none"));
  if(blocked.status!=NoriUserControlEngine.Status.NEEDS_USER_REQUEST) throw new RuntimeException("background boundary failed");
  var confirm=b.authorizeNoriAction(new NoriUserControlEngine.Request("schedule","Create tomorrow study block",NoriUserControlEngine.Origin.USER_DIRECT,true,false,false,"calendar block","calendar"));
  if(!confirm.requiresVisibleConfirmation) throw new RuntimeException("confirmation boundary failed");
  var ready=b.authorizeNoriAction(new NoriUserControlEngine.Request("navigate","Open Study Center",NoriUserControlEngine.Origin.USER_CONFIRMED,false,false,false,"Nori Study Center","none"));
  if(!ready.mayExecute) throw new RuntimeException("confirmed action failed");
  System.out.println("POST23_STEP27_APP_UNDERSTANDING_CONTROL_PASS capabilities="+b.getAppUnderstandingEngine().getCatalog().all().size()+" guides="+b.getAppUnderstandingEngine().getGuideEngine().all().size());
 }
}
JAVA
javac -cp "$OUT" -d "$OUT" "$OUT/Step27Check.java"
java -cp "$OUT" Step27Check
printf 'POST23_STEP27_STATIC_PASS\n'
