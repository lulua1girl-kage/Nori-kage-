# Post-23 Step 32 — Nori Advanced Brain

Step 32 is an additive frontier orchestration layer over the existing Nori Brain. It does not replace Nori's Constitution, Human Override, ActionEngine, memory, safety, or existing interfaces.

## 30+ capability families
1 intent routing 2 context compression 3 ambiguity checking 4 contradiction checking 5 uncertainty calibration 6 memory relevance 7 memory freshness 8 goal decomposition 9 task graph planning 10 plan repair 11 adaptive effort 12 tool selection 13 permission awareness 14 action preview 15 action verification 16 failure recovery 17 research planning 18 multi-source research 19 source deduplication 20 source diversity 21 claim provenance 22 conflict detection 23 evidence thresholds 24 fact/inference separation 25 self-check 26 answer compression 27 follow-up continuity 28 multimodal routing 29 document routing 30 creative routing 31 study method selection 32 outcome learning 33 human-context routing 34 user control 35 offline fallback 36 latency budget 37 provider routing 38 capability disclosure 39 Chrome handoff 40 export portability.

## Adaptive research
Nori does not search 25 websites by default. It chooses a bounded budget:
- normal: 3 sources
- current/latest/compare: 8
- deep/comprehensive/evidence-heavy: 15
- explicitly exhaustive / maximum 25: 25

Up to 25 HTTPS sources can be fetched concurrently, with bounded concurrency and a total deadline. The caller supplies discovered or approved source URLs; Nori does not claim to have searched sources it did not actually retrieve.

## Thinking
The engine produces a public decision plan rather than exposing hidden chain-of-thought. It selects intent, effort, answer mode, evidence policy, work units, tool/file/web needs, verification needs, and user-control requirements.

## Safety and identity
- Nori remains Nori; no personality replacement.
- Human Override remains authoritative.
- Tool execution remains behind ActionEngine/UserControl.
- No covert microphone/camera/background automation is introduced.
- No silent permissions or publication.
- Local-first remains available when external intelligence is unavailable.

## Current-AI inspiration
The architecture is informed by current 2026 patterns including agentic long-horizon task execution, deep research with multiple sources, multimodal/file grounding, computer use, adaptive memory, and tool orchestration. These are implemented as provider-neutral capabilities rather than copied proprietary model internals.
