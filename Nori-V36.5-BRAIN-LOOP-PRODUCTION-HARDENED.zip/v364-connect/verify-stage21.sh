#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
command -v javac >/dev/null 2>&1 || { echo "ERROR: javac is required" >&2; exit 1; }
rm -rf build_stage21
mkdir -p build_stage21
mapfile -t SOURCES < <(grep -L '^import android\.' $(find android/app/src/main/java/com/nori/jarvis/nori -name '*.java' -print) | grep -v '/V32MigrationValidator.java$' | grep -v '/NoriNativeCore.java$')
javac -encoding UTF-8 -d build_stage21 "${SOURCES[@]}" tests/native/Stage21PerformanceOffline.java
java -cp build_stage21 Stage21PerformanceOffline
test -f android/app/src/main/java/com/nori/jarvis/nori/performance/NoriPerformance.java
test -f android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java
grep -q 'getPerformance' android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java
grep -q 'usesCleartextTraffic="false"' android/app/src/main/AndroidManifest.xml
test -f www/brain-engine/brain.js
echo 'STAGE21_STATIC_REGRESSION_PASS'
