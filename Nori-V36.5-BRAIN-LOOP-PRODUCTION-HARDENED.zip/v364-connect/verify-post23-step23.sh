#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
BASE="$ROOT/android/app/src/main/java"
TMP="$ROOT/.step23-compile"
rm -rf "$TMP"; mkdir -p "$TMP"
javac -d "$TMP" \
 "$BASE/com/nori/jarvis/nori/brain/planning/NoriDecisionPlanningEngine.java" \
 "$BASE/com/nori/jarvis/nori/brain/intervention/NoriInterventionEngine.java"
cat > "$TMP/Smoke.java" <<'JAVA'
import com.nori.jarvis.nori.brain.planning.*;
import com.nori.jarvis.nori.brain.intervention.*;
import java.util.*;
public class Smoke { public static void main(String[]a){
 NoriDecisionPlanningEngine e=new NoriDecisionPlanningEngine();
 var p=e.planFromSignals("prepare for exam",.9,.6,.5,Arrays.asList("school_schedule"));
 if(p.steps.isEmpty()||p.rankedOptions.isEmpty()||p.scenarios.size()<4) throw new RuntimeException("planning fail");
 NoriInterventionEngine i=new NoriInterventionEngine();
 var x=i.decide(new NoriInterventionEngine.Signal(.8,.3,.8,.2,.8,false),"direct",Collections.emptyList(),false);
 if(!x.intervene||!x.preservesAutonomy) throw new RuntimeException("intervention fail");
 System.out.println("STEP23_SMOKE_PASS options="+p.rankedOptions.size()+" steps="+p.steps.size()+" action="+x.action);
}}
JAVA
javac -cp "$TMP" -d "$TMP" "$TMP/Smoke.java"
java -cp "$TMP" Smoke
echo POST23_STEP23_DECISION_INTERVENTION_SOURCE_PASS
