# Post-23 Step 21 — Unified State & General Reasoning

Advances the existing Step 20 baseline without replacing existing engines.

## Unified State
NoriState now includes situation, academic, memory, study status, exam status, explicit device/app evidence, and temporal state. State observations remain explicit and additive.

## General Reasoning
Adds a general evidence → interpretation → confidence → decision layer with assumption tracking, conflict detection, causal-status caution, temporal-status awareness, hypothesis competition, unresolved questions and verification checks.

This is an auditable reasoning boundary, not hidden chain-of-thought. It does not claim semantic intelligence that is not implemented.

## Safety / privacy
Device/app state is evidence only; it is not proof of intent. No covert recording or unrestricted surveillance is introduced. Existing Constitution and Human Override remain authoritative.
