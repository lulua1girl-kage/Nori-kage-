#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
WWW="$ROOT/www"
for f in nori-interactive-presence-v1.js nori-interactive-presence-v1.css nori-native-bridge.js nori-conversation-v3.js nori-meet.js nori-alarm.js; do test -f "$WWW/$f"; done
node --check "$WWW/nori-interactive-presence-v1.js"
node --check "$WWW/nori-native-bridge.js"
node --check "$WWW/nori-conversation-v3.js"
node --check "$WWW/nori-meet.js"
node --check "$WWW/nori-alarm.js"
node --check "$WWW/nori-control-center-v26.js"
grep -q 'nori-interactive-presence-v1.css' "$WWW/index.html"
grep -q 'nori-interactive-presence-v1.js' "$WWW/index.html"
grep -q 'Interactive Circle' "$WWW/nori-control-center-v26.js"
grep -q 'noriMeetSendText' "$WWW/nori-meet.js"
grep -q 'channel.*voice' "$WWW/nori-conversation-v3.js"
grep -q 'NoriInteractivePresence' "$WWW/nori-alarm.js"
printf 'POST23_STEP3_INTERACTIVE_PRESENCE_SOURCE_PASS\n'
