# Nori Step 47 — Production Foundation & Gap Closure

## What is real in this source package
- Supabase schema for admin allowlist, challenges, devices, Library catalog, usage/quota and admin events.
- Private `nori-library` Storage bucket with per-user RLS policies.
- Server-side Edge Functions for admin verification, admin operational reports and draft-first improvement email workflow.
- 13 supplied administrator emails are seeded server-side; the client never receives the allowlist.
- Primary email verification remains the first identity gate.
- Approved students can continue after primary verification without repeating admission checks.
- Backup email remains a recovery requirement rather than an unnecessary repeated login challenge.
- Admin identity verification is three-stage: authenticated/confirmed identity, six-digit PIN sent from the configured Nori admin mail service, then a second identity-confirmation email.
- Admin-only operational reporting and improvement workflows are separated from student data access.

## Required production secrets (Supabase Edge Function secrets)
- `SUPABASE_SERVICE_ROLE_KEY`
- `RESEND_API_KEY` or equivalent transactional email provider credential
- `NORI_MAIL_FROM` — configure only a sender address the provider has authorized. If `kage.beginning@gmail.com` cannot be used as a verified sender, use an authenticated domain/address instead and keep Justice as the contact identity.

Never put these secrets in the Android APK, WebView, GitHub repository, or public configuration.

## Supabase project setup
1. Create/select the production Supabase project.
2. Apply migrations `001_nori_admission_rls.sql` and `002_nori_production_foundation.sql`.
3. Configure Authentication email confirmation.
4. Configure custom SMTP for Auth emails.
5. Deploy the three Edge Functions.
6. Add the required Edge Function secrets.
7. Configure the app's public Supabase URL and anon/publishable key in `nori-production-config-v47.js`.
8. Never expose the service-role key.
9. Test RLS using a student account and an admin account separately.
10. Enable project MFA, SSL enforcement, network restrictions where appropriate, backups/PITR appropriate to the chosen plan, and Security Advisor checks before release.

## Email flow
### Student
Sign in/sign up → Supabase email confirmation → admission check → approved workspace.

### Administrator
Sign in → confirmed identity → server allowlist → six-digit PIN → confirmation email → admin session.

The Edge Function performs the allowlist decision server-side. The Android/web client cannot turn an account into an administrator by changing local storage, JavaScript or metadata.

## 15 GiB Library
The quota is 16,106,127,360 bytes (15 GiB). Actual bytes are stored in private cloud Storage; the app should keep metadata/indexes and an optional bounded cache locally. Large uploads should use TUS/resumable upload. The server-side quota ledger must be checked before accepting finalization.

## Honest verification boundary
This package can be source-verified without the production credentials. It cannot truthfully claim that a real Supabase project, SMTP provider, Resend account, production deployment or physical Android device has been exercised until those external resources are supplied and tested.
