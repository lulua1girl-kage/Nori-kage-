# Nori Administration Plane

The administration plane is separate from the student application.

## Roles
- OWNER: sole program owner; admission, admin management, production code release.
- ADMIN: operational administration; cannot bootstrap another OWNER.
- STUDENT: own profile, own library, own memory, own feedback.
- VIEWER: tightly limited read-only scope.

## Admission
A student can submit a sign-up request with:
- name
- age
- primary email
- backup email

Access is denied until:
1. primary email is verified;
2. backup email is verified;
3. the email is invited, pre-approved, or known-and-accepted by the Nori program;
4. the backend marks the account APPROVED.

The APK never decides that a user is approved. The backend does.

## Code editing
The student APK never contains a privileged source editor or deployment secret.
The admin plane may connect to the private source repository and create a tested change request.
Production release lifecycle:
DISCOVER → PATCH → STATIC CHECKS → TESTS → SECURITY CHECKS → OWNER APPROVAL → BUILD → SIGN → DEPLOY → VERIFY → ROLLBACK IF NEEDED.

A feedback item never becomes production code automatically.

## Improvement loop
Student feedback → sanitize/minimize → classify → admin review → reproduce → implement → tests → release → measure outcome.

Nori may tell a student what to improve. Email is drafted by default. Sending is explicit, and sensitive student information is never silently forwarded to a backup contact.

## Privacy
The admin can manage program records, but should not receive full private conversations or library contents by default. Access should be scoped to the minimum needed task and audited.
