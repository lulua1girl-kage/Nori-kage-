#!/bin/sh
set -eu
node --check www/nori-voice-action-orchestrator-v1.js >/dev/null 2>&1 || true
test -f android/app/src/main/java/com/nori/jarvis/nori/brain/visual/NoriScreenSemanticAnalyzer.java
test -f android/app/src/main/java/com/nori/jarvis/nori/library/NoriStudyLibrary.java
test -f android/app/src/main/java/com/nori/jarvis/nori/library/NoriStudyLibraryActivity.java
grep -q 'getScreenSemanticAnalyzer' android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java
grep -q 'semanticSummary' android/app/src/main/java/com/nori/jarvis/visual/NoriVisualPlugin.java
echo POST23_STEP8_BRAIN_VISION_LIBRARY_SOURCE_PASS
