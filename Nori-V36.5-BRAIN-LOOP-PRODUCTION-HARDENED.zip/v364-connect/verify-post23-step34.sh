#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/android/app/src/main/java/com/nori/jarvis/nori/meta"
OUT="$ROOT/.step34-classes"
rm -rf "$OUT"; mkdir -p "$OUT"
javac -d "$OUT" "$SRC"/NoriMetaBrainEngine.java "$SRC"/NoriMetaBrainEngineTest.java
java -cp "$OUT" com.nori.jarvis.nori.meta.NoriMetaBrainEngineTest
grep -q 'NoriMetaBrainEngine' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'metaBrainEngine=new NoriMetaBrainEngine' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'getMetaBrainEngine' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
test -f "$ROOT/POST23-STEP34-META-BRAIN-30-CAPABILITIES.md"
echo "POST23_STEP34_META_BRAIN_PASS"
