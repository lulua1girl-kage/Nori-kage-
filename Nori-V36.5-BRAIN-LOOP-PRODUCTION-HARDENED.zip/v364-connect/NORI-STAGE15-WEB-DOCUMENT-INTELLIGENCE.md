# Nori Native Java Stage 15 — Web & Document Intelligence

## Purpose
Add a local-first document intelligence layer and a controlled HTTPS web boundary without making internet access, cloud AI, or server infrastructure a requirement for Nori's core academic operation.

## Added
- `DocumentParser` for local text and HTML normalization.
- `DocumentIntelligence` for document ingestion, bounded chunking, lexical retrieval, and source tracking.
- `NoriDocumentService` using Android Storage Access Framework; no broad storage permission is introduced.
- `WebIntelligence` with HTTPS-only fetching, bounded response size, no credential forwarding, and redirects not followed automatically.
- Brain accessors for document and web intelligence.

## Integrity / privacy boundaries
- User-selected files only; no background filesystem crawling.
- Documents are not automatically saved to Nori Memory.
- Web retrieval is an explicit capability, not silent browsing.
- No cookies, API keys, Authorization headers, or user credentials are forwarded by the web reader.
- Web results are treated as source material, not automatically as facts.
- Binary document formats remain delegated to Android/document providers rather than pretending the lightweight parser supports them.

## Preserved
All V32 JavaScript and Stages 1–14 remain intact. Stage 11 optional AI remains optional. Stage 9 action confirmation and Stage 13 integrity protections remain in force.
