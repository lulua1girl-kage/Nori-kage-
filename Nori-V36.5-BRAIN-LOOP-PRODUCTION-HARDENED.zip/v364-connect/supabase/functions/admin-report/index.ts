// Admin-only operational report. No student client can call this successfully.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const admin=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
const json=(b:unknown,s=200)=>new Response(JSON.stringify(b),{status:s,headers:{'content-type':'application/json'}});
Deno.serve(async req=>{
  try{
    const token=(req.headers.get('authorization')||'').replace(/^Bearer\s+/i,'');
    const {data:{user}}=await admin.auth.getUser(token);
    if(!user?.email)return json({error:'unauthorized'},401);
    const {data:p}=await admin.from('nori_profiles').select('role,admission_status').eq('user_id',user.id).maybeSingle();
    if(!p || !['OWNER','ADMIN'].includes(p.role) || p.admission_status!=='APPROVED')return json({error:'admin_only'},403);
    const [students,events,files,usage]=await Promise.all([
      admin.from('nori_profiles').select('user_id,display_name,primary_email,admission_status,created_at,updated_at').order('created_at',{ascending:false}),
      admin.from('nori_admin_events').select('event_type,severity,created_at').order('created_at',{ascending:false}).limit(100),
      admin.from('nori_storage_files').select('processing_status,count', {count:'exact',head:true}),
      admin.from('nori_usage').select('storage_bytes,storage_quota_bytes,ai_units_used')
    ]);
    return json({ok:true,generatedAt:new Date().toISOString(),students:students.data||[],events:events.data||[],storageRecords:files.count||0,usage:usage.data||[]});
  }catch(e){return json({error:String(e?.message||e)},500)}
});
