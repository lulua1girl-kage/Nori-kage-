// Nori Step 47: server-side admin verification orchestrator.
// Required secrets: SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY, NORI_MAIL_FROM, RESEND_API_KEY.
// The service-role key is ONLY used inside this Edge Function.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const mailFrom = Deno.env.get('NORI_MAIL_FROM') || 'kage.beginning@gmail.com';
const resendKey = Deno.env.get('RESEND_API_KEY')!;
const admin = createClient(supabaseUrl, serviceKey);

const json = (body: unknown, status=200) => new Response(JSON.stringify(body), {status, headers:{'content-type':'application/json'}});
const hash = async (value:string) => {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');
};
const pin = () => String(Math.floor(100000 + Math.random()*900000));

async function send(to:string, subject:string, html:string){
  const r = await fetch('https://api.resend.com/emails', {method:'POST', headers:{authorization:`Bearer ${resendKey}`,'content-type':'application/json'}, body:JSON.stringify({from:mailFrom,to:[to],subject,html})});
  if(!r.ok) throw new Error(`email_provider_${r.status}`);
}

Deno.serve(async req=>{
  // The final identity-confirmation link is intentionally GET-capable so a normal email click works.
  if(req.method==='GET'){
    const u=new URL(req.url);
    if(u.searchParams.get('action')!=='confirm') return json({error:'method_not_allowed'},405);
    const uid=u.searchParams.get('user')||''; const tokenValue=u.searchParams.get('token')||'';
    try {
      const {data:c}=await admin.from('nori_admin_challenges').select('*').eq('user_id',uid).eq('step',3).is('consumed_at',null).gt('expires_at',new Date().toISOString()).order('created_at',{ascending:false}).limit(1).maybeSingle();
      if(!c || (await hash(tokenValue))!==c.token_hash) return new Response('<h2>Nori administrator confirmation failed</h2><p>The confirmation is invalid or expired.</p>',{status:401,headers:{'content-type':'text/html'}});
      await admin.from('nori_admin_challenges').update({consumed_at:new Date().toISOString()}).eq('id',c.id);
      await admin.from('nori_profiles').update({role:'ADMIN',admission_status:'APPROVED'}).eq('user_id',c.user_id);
      let g=(await admin.from('nori_admin_groups').select('*').limit(1).maybeSingle()).data;
      if(!g) g=(await admin.from('nori_admin_groups').insert({display_name:'Administrator'}).select().single()).data;
      await admin.from('nori_admin_group_members').upsert({group_id:g.id,user_id:c.user_id,email:c.email,active:true});
      await admin.from('nori_admin_events').insert({actor_user_id:c.user_id,event_type:'ADMIN_IDENTITY_VERIFIED',severity:'INFO'});
      return new Response('<h2>Nori administrator identity confirmed</h2><p>You may return to Nori. This account is now part of the shared Administrator identity.</p>',{status:200,headers:{'content-type':'text/html'}});
    } catch(e){return new Response(`<h2>Nori administrator confirmation error</h2><p>${String(e?.message||e)}</p>`,{status:500,headers:{'content-type':'text/html'}});}
  }
  if(req.method!=='POST') return json({error:'method_not_allowed'},405);
  try {
    const auth = req.headers.get('authorization') || '';
    const token = auth.replace(/^Bearer\s+/i,'');
    const {data:{user},error:userError}=await admin.auth.getUser(token);
    if(userError || !user?.email) return json({error:'unauthorized'},401);
    const email=user.email.toLowerCase();
    const {data:allowed}=await admin.from('nori_admin_allowlist').select('email').eq('email',email).eq('active',true).maybeSingle();
    if(!allowed) return json({error:'not_admin_allowlisted'},403);

    const body=await req.json();
    const action=body.action;
    if(action==='start'){
      const p=pin();
      const h=await hash(p);
      await admin.from('nori_admin_challenges').insert({user_id:user.id,email,step:2,pin_hash:h,expires_at:new Date(Date.now()+10*60*1000).toISOString()});
      await send(email,'Nori administrator verification',`<p>Nori administrator verification.</p><p>Your verification PIN is <strong>${p}</strong>.</p><p>It expires in 10 minutes. If you did not request this, ignore this message.</p>`);
      return json({ok:true,next:'PIN'});
    }
    if(action==='verify_pin'){
      const p=String(body.pin||'');
      if(!/^\d{6}$/.test(p)) return json({error:'invalid_pin'},400);
      const {data:c}=await admin.from('nori_admin_challenges').select('*').eq('user_id',user.id).eq('step',2).is('consumed_at',null).gt('expires_at',new Date().toISOString()).order('created_at',{ascending:false}).limit(1).maybeSingle();
      if(!c || (await hash(p))!==c.pin_hash) return json({error:'pin_rejected'},401);
      await admin.from('nori_admin_challenges').update({consumed_at:new Date().toISOString()}).eq('id',c.id);
      const tokenValue=crypto.randomUUID();
      await admin.from('nori_admin_challenges').insert({user_id:user.id,email,step:3,token_hash:await hash(tokenValue),expires_at:new Date(Date.now()+20*60*1000).toISOString()});
      const link=`${supabaseUrl}/functions/v1/admin-verify?action=confirm&token=${encodeURIComponent(tokenValue)}&user=${encodeURIComponent(user.id)}`;
      await send(email,'Confirm your Nori administrator identity',`<p>Confirm that you are the administrator signing into Nori.</p><p><a href="${link}">Confirm administrator identity</a></p><p>This confirmation expires in 20 minutes.</p>`);
      return json({ok:true,next:'IDENTITY_EMAIL'});
    }
    if(action==='confirm'){
      const tokenValue=String(body.token||'');
      const {data:c}=await admin.from('nori_admin_challenges').select('*').eq('user_id',String(body.user_id||'')).eq('step',3).is('consumed_at',null).gt('expires_at',new Date().toISOString()).order('created_at',{ascending:false}).limit(1).maybeSingle();
      if(!c || (await hash(tokenValue))!==c.token_hash) return json({error:'confirmation_rejected'},401);
      await admin.from('nori_admin_challenges').update({consumed_at:new Date().toISOString()}).eq('id',c.id);
      await admin.from('nori_profiles').update({role:'ADMIN',admission_status:'APPROVED'}).eq('user_id',c.user_id);
      let g=(await admin.from('nori_admin_groups').select('*').limit(1).maybeSingle()).data;
      if(!g) g=(await admin.from('nori_admin_groups').insert({display_name:'Administrator'}).select().single()).data;
      await admin.from('nori_admin_group_members').upsert({group_id:g.id,user_id:c.user_id,email:c.email,active:true});
      await admin.from('nori_admin_events').insert({actor_user_id:c.user_id,event_type:'ADMIN_IDENTITY_VERIFIED',severity:'INFO'});
      return json({ok:true,verified:true,role:'ADMIN',groupId:g.id});
    }
    return json({error:'unknown_action'},400);
  } catch(e) { return json({error:String(e?.message||e)},500); }
});
