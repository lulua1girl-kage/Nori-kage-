// Draft-first admin improvement email. Never sends automatically from a student request.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
const admin=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
const json=(b:unknown,s=200)=>new Response(JSON.stringify(b),{status:s,headers:{'content-type':'application/json'}});
Deno.serve(async req=>{
 try{
  const token=(req.headers.get('authorization')||'').replace(/^Bearer\s+/i,'');
  const {data:{user}}=await admin.auth.getUser(token);
  const {data:p}=user?await admin.from('nori_profiles').select('role,admission_status').eq('user_id',user.id).maybeSingle():{data:null};
  if(!p || !['OWNER','ADMIN'].includes(p.role) || p.admission_status!=='APPROVED') return json({error:'admin_only'},403);
  const body=await req.json();
  const draft={to:'justice',subject:String(body.subject||'Nori improvement report'),body:String(body.body||''),status:'DRAFT',createdAt:new Date().toISOString()};
  await admin.from('nori_admin_events').insert({actor_user_id:user.id,event_type:'IMPROVEMENT_EMAIL_DRAFTED',severity:'INFO',metadata:{subject:draft.subject}});
  return json({ok:true,draft,requiresExplicitSend:true});
 }catch(e){return json({error:String(e?.message||e)},500)}
});
