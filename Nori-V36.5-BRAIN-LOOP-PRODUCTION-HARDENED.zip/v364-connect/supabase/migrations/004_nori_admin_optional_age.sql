-- Admin accounts do not need age collection. Students still do.
alter table public.nori_profiles alter column age drop not null;
create or replace function public.nori_validate_profile_age()
returns trigger language plpgsql security definer set search_path=public
as $$
begin
  if new.age is null then
    if not exists(select 1 from public.nori_admin_allowlist a where lower(a.email)=lower(new.primary_email) and a.active=true) then
      raise exception 'age_required_for_student_accounts';
    end if;
  elsif new.age < 13 or new.age > 120 then
    raise exception 'invalid_age';
  end if;
  return new;
end; $$;
drop trigger if exists nori_profile_age_guard on public.nori_profiles;
create trigger nori_profile_age_guard before insert or update of age,primary_email on public.nori_profiles for each row execute function public.nori_validate_profile_age();
