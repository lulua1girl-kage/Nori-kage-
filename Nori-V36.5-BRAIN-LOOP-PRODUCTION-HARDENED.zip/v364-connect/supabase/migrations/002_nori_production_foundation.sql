-- NORI STEP 47: production foundation
-- Run in the trusted Supabase project. Never place service-role keys in the APK.
create extension if not exists pgcrypto;

create table if not exists public.nori_admin_allowlist (
  email text primary key,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

insert into public.nori_admin_allowlist(email) values
('danatbayu@gmail.com'),('danatbayu1@gmail.com'),('danatbayu2@gmail.com'),
('danatbayu3@gmail.com'),('danatbayu4@gmail.com'),('danatbayu5@gmail.com'),
('danatbayu6@gmail.com'),('danatbayu7@gmail.com'),('danatbayu8@gmail.com'),
('kage.beginning@gmail.com'),('xendia76@gmail.com'),('lulua1girl@gmail.com'),
('danatbayu9@gmail.com')
on conflict (email) do update set active=true;

create table if not exists public.nori_admin_challenges (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  email text not null,
  step smallint not null check(step between 1 and 3),
  pin_hash text,
  token_hash text,
  expires_at timestamptz not null,
  consumed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.nori_user_devices (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  device_id text not null,
  platform text,
  app_version text,
  last_seen_at timestamptz not null default now(),
  revoked_at timestamptz,
  unique(user_id, device_id)
);

create table if not exists public.nori_storage_files (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  object_path text not null,
  original_name text not null,
  mime_type text,
  byte_size bigint not null default 0,
  version integer not null default 1,
  processing_status text not null default 'QUEUED' check(processing_status in ('QUEUED','PROCESSING','READY','FAILED','DELETED')),
  sha256 text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(user_id, object_path)
);

create table if not exists public.nori_usage (
  user_id uuid primary key references auth.users(id) on delete cascade,
  storage_bytes bigint not null default 0,
  storage_quota_bytes bigint not null default 16106127360,
  ai_units_used bigint not null default 0,
  updated_at timestamptz not null default now()
);

create table if not exists public.nori_admin_events (
  id uuid primary key default gen_random_uuid(),
  actor_user_id uuid references auth.users(id) on delete set null,
  event_type text not null,
  severity text not null default 'INFO' check(severity in ('INFO','NOTICE','WARNING','CRITICAL')),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.nori_admin_allowlist enable row level security;
alter table public.nori_admin_challenges enable row level security;
alter table public.nori_user_devices enable row level security;
alter table public.nori_storage_files enable row level security;
alter table public.nori_usage enable row level security;
alter table public.nori_admin_events enable row level security;

create or replace function public.nori_is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.nori_profiles p where p.user_id=auth.uid() and p.role in ('OWNER','ADMIN') and p.admission_status='APPROVED'); $$;

create or replace function public.nori_is_allowlisted_admin(p_email text)
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.nori_admin_allowlist where lower(email)=lower(p_email) and active=true); $$;

-- Admin allowlist is never readable by student clients.
create policy nori_admin_allowlist_admin_only on public.nori_admin_allowlist for all using (public.nori_is_admin()) with check (public.nori_is_admin());
-- Challenge rows are never directly readable by student clients; Edge Functions use trusted server access.
create policy nori_admin_challenge_admin_only on public.nori_admin_challenges for all using (public.nori_is_admin()) with check (public.nori_is_admin());
create policy nori_devices_self on public.nori_user_devices for select using (user_id=auth.uid() or public.nori_is_admin());
create policy nori_devices_self_insert on public.nori_user_devices for insert with check (user_id=auth.uid());
create policy nori_devices_self_update on public.nori_user_devices for update using (user_id=auth.uid() or public.nori_is_admin()) with check (user_id=auth.uid() or public.nori_is_admin());
create policy nori_files_self on public.nori_storage_files for select using (user_id=auth.uid() or public.nori_is_admin());
create policy nori_files_self_insert on public.nori_storage_files for insert with check (user_id=auth.uid());
create policy nori_files_self_update on public.nori_storage_files for update using (user_id=auth.uid() or public.nori_is_admin()) with check (user_id=auth.uid() or public.nori_is_admin());
create policy nori_usage_self on public.nori_usage for select using (user_id=auth.uid() or public.nori_is_admin());
create policy nori_admin_events_admin_only on public.nori_admin_events for select using (public.nori_is_admin());

insert into public.nori_usage(user_id)
select id from auth.users
where not exists(select 1 from public.nori_usage u where u.user_id=auth.users.id)
on conflict do nothing;

-- Private Library bucket. Do not edit storage schema directly; use Storage APIs.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
values ('nori-library','nori-library',false,5368709120,null)
on conflict (id) do update set public=false, file_size_limit=5368709120;

create policy nori_library_select on storage.objects for select to authenticated
using (bucket_id='nori-library' and (owner_id=auth.uid()::text or public.nori_is_admin()));
create policy nori_library_insert on storage.objects for insert to authenticated
with check (bucket_id='nori-library' and owner_id=auth.uid()::text);
create policy nori_library_update on storage.objects for update to authenticated
using (bucket_id='nori-library' and owner_id=auth.uid()::text)
with check (bucket_id='nori-library' and owner_id=auth.uid()::text);
create policy nori_library_delete on storage.objects for delete to authenticated
using (bucket_id='nori-library' and (owner_id=auth.uid()::text or public.nori_is_admin()));

comment on table public.nori_admin_allowlist is 'Server-controlled administrator identity allowlist; never expose to ordinary clients.';
comment on table public.nori_storage_files is 'Logical file catalog. Actual bytes live in private Supabase Storage.';
comment on table public.nori_usage is '15 GiB logical per-user quota; server-side enforcement required before upload completion.';
