alter table public.goals add column if not exists local_id text;
alter table public.assignments add column if not exists local_id text;
alter table public.assessments add column if not exists local_id text;
alter table public.study_sessions add column if not exists local_id text;
alter table public.calendar_events add column if not exists local_id text;
alter table public.alarms add column if not exists local_id text;
alter table public.mistakes add column if not exists local_id text;
alter table public.conversations add column if not exists local_id text;
alter table public.conversation_messages add column if not exists local_id text;
alter table public.notifications add column if not exists local_id text;
alter table public.recovery_records add column if not exists local_id text;
alter table public.action_audit add column if not exists local_id text;

alter table public.goals add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.assignments add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.assessments add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.study_sessions add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.calendar_events add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.alarms add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.notifications add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.recovery_records add column if not exists metadata jsonb not null default '{}'::jsonb;

create unique index if not exists goals_user_local_id_uidx on public.goals(user_id, local_id) where local_id is not null;
create unique index if not exists assignments_user_local_id_uidx on public.assignments(user_id, local_id) where local_id is not null;
create unique index if not exists assessments_user_local_id_uidx on public.assessments(user_id, local_id) where local_id is not null;
create unique index if not exists study_sessions_user_local_id_uidx on public.study_sessions(user_id, local_id) where local_id is not null;
create unique index if not exists calendar_events_user_local_id_uidx on public.calendar_events(user_id, local_id) where local_id is not null;
create unique index if not exists alarms_user_local_id_uidx on public.alarms(user_id, local_id) where local_id is not null;
create unique index if not exists mistakes_user_local_id_uidx on public.mistakes(user_id, local_id) where local_id is not null;
create unique index if not exists conversations_user_local_id_uidx on public.conversations(user_id, local_id) where local_id is not null;
create unique index if not exists conversation_messages_user_local_id_uidx on public.conversation_messages(user_id, local_id) where local_id is not null;
create unique index if not exists notifications_user_local_id_uidx on public.notifications(user_id, local_id) where local_id is not null;
create unique index if not exists recovery_records_user_local_id_uidx on public.recovery_records(user_id, local_id) where local_id is not null;
create unique index if not exists action_audit_user_local_id_uidx on public.action_audit(user_id, local_id) where local_id is not null;

do $$
declare t text;
begin
  foreach t in array array['goals','assignments','assessments','study_sessions','calendar_events','alarms','mistakes','conversations','conversation_messages','notifications','recovery_records','action_audit'] loop
    begin
      execute format('alter publication supabase_realtime add table public.%I', t);
    exception when duplicate_object then null;
    end;
  end loop;
end $$;
