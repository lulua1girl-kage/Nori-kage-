-- V29 foundation: canonical state authority + durable, append-only audit trail.
-- Clients must NEVER write these tables. Server-side service-role code is the writer.
create extension if not exists pgcrypto;

create table if not exists public.nori_canonical_state (
  user_id uuid primary key references auth.users(id) on delete cascade,
  schema_version integer not null default 1,
  state_version bigint not null default 1,
  state jsonb not null default '{}'::jsonb,
  state_hash text not null default '',
  updated_at timestamptz not null default now(),
  updated_by text not null default 'server'
);

create table if not exists public.nori_audit_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  sequence bigint generated always as identity,
  event_type text not null,
  schema_version integer not null default 1,
  source text not null,
  authority text not null,
  verified boolean not null default false,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  unique(user_id, sequence)
);

create index if not exists nori_audit_events_user_created_idx
  on public.nori_audit_events(user_id, created_at desc);
create index if not exists nori_audit_events_user_type_idx
  on public.nori_audit_events(user_id, event_type, created_at desc);

alter table public.nori_canonical_state enable row level security;
alter table public.nori_audit_events enable row level security;

-- Read-only for the owning student; NO client INSERT/UPDATE/DELETE policies.
create policy nori_canonical_state_self_select
  on public.nori_canonical_state for select
  using (user_id=auth.uid() or public.nori_is_admin());

create policy nori_audit_events_self_select
  on public.nori_audit_events for select
  using (user_id=auth.uid() or public.nori_is_admin());

comment on table public.nori_canonical_state is
  'Server-authoritative per-user state. Clients may read their state but cannot write it.';
comment on table public.nori_audit_events is
  'Durable append-only decision/evidence audit trail. Client writes are intentionally denied.';
