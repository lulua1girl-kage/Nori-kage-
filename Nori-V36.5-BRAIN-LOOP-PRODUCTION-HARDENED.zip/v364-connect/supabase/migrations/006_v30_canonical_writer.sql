-- V30 — atomic canonical state writer boundary.
-- The service-role API calls this function; browser roles cannot execute it.
create or replace function public.nori_apply_canonical_mutation(
  p_user_id uuid,
  p_expected_version bigint,
  p_expected_hash text,
  p_next_state jsonb,
  p_event_type text,
  p_source text,
  p_authority text,
  p_verified boolean,
  p_payload jsonb
) returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_version bigint;
  v_hash text;
  v_new_hash text;
  v_updated timestamptz := now();
  v_event_id uuid;
begin
  if p_user_id is null then raise exception 'missing_user_id'; end if;
  if p_next_state is null or jsonb_typeof(p_next_state) <> 'object' then raise exception 'invalid_canonical_state'; end if;
  if p_event_type <> 'DECISION_EXECUTED' then raise exception 'invalid_mutation_event_type'; end if;
  if length(coalesce(p_source,'')) > 120 or length(coalesce(p_authority,'')) > 120 then raise exception 'mutation_metadata_too_long'; end if;
  if p_payload is null or jsonb_typeof(p_payload) <> 'object' then raise exception 'invalid_mutation_payload'; end if;

  -- PostgreSQL's jsonb text representation is deterministic for the same object.
  v_new_hash := encode(digest(convert_to(p_next_state::text,'UTF8'),'sha256'),'hex');

  select state_version,state_hash into v_version,v_hash
  from public.nori_canonical_state
  where user_id=p_user_id
  for update;

  if not found then
    if coalesce(p_expected_version,0) <> 0 or coalesce(p_expected_hash,'') <> '' then
      raise exception 'canonical_state_version_conflict';
    end if;
    insert into public.nori_canonical_state(user_id,schema_version,state_version,state,state_hash,updated_at,updated_by)
    values(p_user_id,1,1,p_next_state,v_new_hash,v_updated,left(p_source,120));
    v_version := 1;
  else
    if v_version <> coalesce(p_expected_version,0) or coalesce(v_hash,'') <> coalesce(p_expected_hash,'') then
      raise exception 'canonical_state_version_conflict';
    end if;
    update public.nori_canonical_state
    set state_version=v_version+1,state=p_next_state,state_hash=v_new_hash,updated_at=v_updated,updated_by=left(p_source,120)
    where user_id=p_user_id;
    v_version := v_version+1;
  end if;

  insert into public.nori_audit_events(user_id,event_type,schema_version,source,authority,verified,payload,created_at)
  values(p_user_id,p_event_type,1,left(p_source,120),left(p_authority,120),coalesce(p_verified,false),
         jsonb_build_object('stateVersion',v_version,'stateHash',v_new_hash,'mutation',coalesce(p_payload,'{}'::jsonb)),v_updated)
  returning id into v_event_id;

  return jsonb_build_object(
    'user_id',p_user_id,'schema_version',1,'state_version',v_version,
    'state',p_next_state,'state_hash',v_new_hash,'updated_at',v_updated,
    'updated_by',left(p_source,120),'audit_id',v_event_id
  );
end;
$$;

revoke all on function public.nori_apply_canonical_mutation(uuid,bigint,text,jsonb,text,text,text,boolean,jsonb) from public, anon, authenticated;
grant execute on function public.nori_apply_canonical_mutation(uuid,bigint,text,jsonb,text,text,text,boolean,jsonb) to service_role;

comment on function public.nori_apply_canonical_mutation is
  'V30 atomic canonical state mutation boundary. Browser roles cannot execute. It CAS-checks state version/hash, writes state and audit in one transaction.';
