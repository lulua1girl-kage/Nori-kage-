-- Nori V36.5 production hardening.
-- Mirrors the changes applied to the hosted project during the V36.5 hardening pass.

create index if not exists idx_action_audit_user_created
  on public.action_audit (user_id, created_at desc);
create index if not exists idx_conversation_messages_conversation_created
  on public.conversation_messages (conversation_id, created_at asc);
create index if not exists idx_notifications_user_read_created
  on public.notifications (user_id, read_at, created_at desc);
create index if not exists idx_goals_user_status_deadline
  on public.goals (user_id, status, deadline);

drop policy if exists "admin profiles update" on public.profiles;
drop policy if exists "profiles self update" on public.profiles;
create policy "profiles self or admin update"
on public.profiles for update to authenticated
using ((select auth.uid()) = id or (select private.is_admin()))
with check ((select auth.uid()) = id or (select private.is_admin()));
