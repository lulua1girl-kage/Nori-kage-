revoke execute on function public.handle_new_user() from anon, authenticated;
alter function public.set_updated_at() set search_path = public, pg_temp;
