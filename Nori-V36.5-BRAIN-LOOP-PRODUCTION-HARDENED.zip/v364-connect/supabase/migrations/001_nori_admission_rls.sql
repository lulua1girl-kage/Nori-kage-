-- Nori production admission + per-user isolation.
-- Run only in the trusted Supabase project. Do not ship service-role/secret keys in the APK.
create extension if not exists pgcrypto;

create table if not exists public.nori_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  age smallint not null check (age between 13 and 120),
  primary_email text not null,
  backup_email text not null,
  backup_email_verified boolean not null default false,
  admission_status text not null default 'PENDING_REVIEW' check (admission_status in ('PENDING_REVIEW','APPROVED','REJECTED','SUSPENDED')),
  admission_basis text check (admission_basis in ('INVITED','PREAPPROVED_EMAIL','KNOWN_AND_ACCEPTED')),
  role text not null default 'STUDENT' check (role in ('OWNER','ADMIN','STUDENT','VIEWER')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(primary_email),
  check(lower(primary_email) <> lower(backup_email))
);

create table if not exists public.nori_admission_registry (
  email text primary key,
  basis text not null check (basis in ('INVITED','PREAPPROVED_EMAIL','KNOWN_AND_ACCEPTED')),
  active boolean not null default true,
  note text,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id)
);

create table if not exists public.nori_backup_verifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  backup_email text not null,
  token_hash text not null,
  expires_at timestamptz not null,
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.nori_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null,
  text text not null,
  status text not null default 'NEW' check(status in ('NEW','REVIEWING','ACCEPTED','DECLINED','IMPLEMENTED')),
  created_at timestamptz not null default now()
);

create table if not exists public.nori_admin_changes (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid not null references auth.users(id),
  summary text not null,
  patch_hash text not null,
  status text not null default 'TEST_REQUIRED' check(status in ('TEST_REQUIRED','READY_FOR_REVIEW','APPROVED','REJECTED','DEPLOYED','ROLLED_BACK')),
  created_at timestamptz not null default now()
);

create or replace function public.nori_is_admin()
returns boolean language sql stable security definer set search_path=public
as $$ select exists(select 1 from public.nori_profiles p where p.user_id=auth.uid() and p.role in ('OWNER','ADMIN') and p.admission_status='APPROVED'); $$;

alter table public.nori_profiles enable row level security;
alter table public.nori_admission_registry enable row level security;
alter table public.nori_backup_verifications enable row level security;
alter table public.nori_feedback enable row level security;
alter table public.nori_admin_changes enable row level security;

-- Profiles: students see only their own profile. Admins can manage the registry.
create policy nori_profiles_self_select on public.nori_profiles for select using (user_id=auth.uid() or public.nori_is_admin());
create policy nori_profiles_self_insert on public.nori_profiles for insert with check (user_id=auth.uid() and role='STUDENT' and admission_status='PENDING_REVIEW');
create policy nori_profiles_admin_update on public.nori_profiles for update using (public.nori_is_admin()) with check (public.nori_is_admin());

-- Admission registry is never public.
create policy nori_registry_admin_only on public.nori_admission_registry for all using (public.nori_is_admin()) with check (public.nori_is_admin());

-- Backup verification records are owner/admin visible only.
create policy nori_backup_self on public.nori_backup_verifications for select using (user_id=auth.uid() or public.nori_is_admin());
create policy nori_backup_insert_self on public.nori_backup_verifications for insert with check (user_id=auth.uid());
create policy nori_backup_admin on public.nori_backup_verifications for update using (public.nori_is_admin()) with check (public.nori_is_admin());

-- Feedback belongs to the submitting student; admins can review it.
create policy nori_feedback_self_insert on public.nori_feedback for insert with check (user_id=auth.uid());
create policy nori_feedback_self_select on public.nori_feedback for select using (user_id=auth.uid() or public.nori_is_admin());
create policy nori_feedback_admin_update on public.nori_feedback for update using (public.nori_is_admin()) with check (public.nori_is_admin());

-- Code changes are strictly admin-side.
create policy nori_changes_admin_only on public.nori_admin_changes for all using (public.nori_is_admin()) with check (public.nori_is_admin());

-- IMPORTANT: the first OWNER must be bootstrapped through a trusted server/migration process.
-- Never expose the service-role key or an OWNER bootstrap endpoint to the APK.

-- Optional server-side admission helper. It never runs for unverified email or unverified backup contact.
create or replace function public.nori_try_admit()
returns public.nori_profiles
language plpgsql
security invoker
as $$
declare p public.nori_profiles;
       basis_value text;
begin
  select * into p from public.nori_profiles where user_id=auth.uid();
  if p.user_id is null then raise exception 'profile_missing'; end if;
  if p.backup_email_verified=false then return p; end if;
  if not exists(select 1 from auth.users u where u.id=auth.uid() and u.email_confirmed_at is not null) then return p; end if;
  select r.basis into basis_value from public.nori_admission_registry r where lower(r.email)=lower(p.primary_email) and r.active=true limit 1;
  if basis_value is not null then
    update public.nori_profiles set admission_status='APPROVED', admission_basis=basis_value, updated_at=now() where user_id=auth.uid() returning * into p;
  end if;
  return p;
end;
$$;
