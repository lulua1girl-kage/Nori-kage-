-- V48: unified administrator identity + quiet reporting + language/SAT/message preferences
create table if not exists public.nori_admin_groups (
  id uuid primary key default gen_random_uuid(),
  display_name text not null default 'Administrator',
  quiet_mode boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create table if not exists public.nori_admin_group_members (
  group_id uuid not null references public.nori_admin_groups(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  email text not null,
  active boolean not null default true,
  added_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  primary key(group_id,user_id),
  unique(group_id,email)
);
alter table public.nori_admin_groups enable row level security;
alter table public.nori_admin_group_members enable row level security;
create policy nori_admin_groups_admin on public.nori_admin_groups for all using(public.nori_is_admin()) with check(public.nori_is_admin());
create policy nori_admin_group_members_admin on public.nori_admin_group_members for all using(public.nori_is_admin()) with check(public.nori_is_admin());

create table if not exists public.nori_learning_profile (
  user_id uuid primary key references auth.users(id) on delete cascade,
  operating_language text not null default 'en',
  specialist_languages jsonb not null default '["ar","es","ja"]'::jsonb,
  sat_enabled boolean not null default true,
  sat_target integer,
  updated_at timestamptz not null default now()
);
alter table public.nori_learning_profile enable row level security;
create policy nori_learning_profile_self on public.nori_learning_profile for all using(user_id=auth.uid() or public.nori_is_admin()) with check(user_id=auth.uid() or public.nori_is_admin());

create table if not exists public.nori_message_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  instagram_enabled boolean not null default true,
  telegram_enabled boolean not null default true,
  auto_send boolean not null default false,
  default_mode text not null default 'ASK' check(default_mode in ('ASK','TEXT','CALL','VIDEO')),
  updated_at timestamptz not null default now()
);
alter table public.nori_message_preferences enable row level security;
create policy nori_message_preferences_self on public.nori_message_preferences for all using(user_id=auth.uid() or public.nori_is_admin()) with check(user_id=auth.uid() or public.nori_is_admin());
