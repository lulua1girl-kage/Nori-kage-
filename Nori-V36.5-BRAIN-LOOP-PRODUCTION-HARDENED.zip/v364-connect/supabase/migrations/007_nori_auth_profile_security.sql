-- Nori authentication/profile security
-- Normal accounts are always STUDENT unless the private admin allowlist
-- provisioning trigger has explicitly assigned ADMIN.

create or replace function private.enforce_profile_authority()
returns trigger
language plpgsql
security definer
set search_path = public, private, pg_temp
as $$
declare
  caller_is_admin boolean := private.is_admin();
begin
  if caller_is_admin then
    return new;
  end if;

  -- A normal authenticated user may edit profile details, but cannot
  -- promote themselves, change admission status, or change the account id.
  if new.id <> old.id then
    raise exception 'PROFILE_ID_IMMUTABLE';
  end if;
  if new.role is distinct from old.role then
    raise exception 'ROLE_CHANGE_NOT_ALLOWED';
  end if;
  if new.admission_status is distinct from old.admission_status then
    raise exception 'ADMISSION_STATUS_CHANGE_NOT_ALLOWED';
  end if;

  return new;
end;
$$;

revoke all on function private.enforce_profile_authority() from public, anon, authenticated;

drop trigger if exists enforce_profile_authority on public.profiles;
create trigger enforce_profile_authority
before update on public.profiles
for each row execute function private.enforce_profile_authority();

-- Ensure every newly-created non-allowlisted Auth account is explicitly a student.
create or replace function private.provision_admin_from_allowlist()
returns trigger
language plpgsql
security definer
set search_path = public, private, pg_temp
as $$
declare
  allow_row private.admin_allowlist%rowtype;
begin
  select * into allow_row
  from private.admin_allowlist
  where lower(email) = lower(new.email)
    and active = true
  limit 1;

  if found then
    insert into public.profiles (id, full_name, display_name, email, role, admission_status)
    values (new.id, coalesce(allow_row.admin_name, 'Justice S.'), coalesce(allow_row.admin_name, 'Justice S.'), lower(new.email), 'ADMIN', 'APPROVED')
    on conflict (id) do update set
      full_name = excluded.full_name,
      display_name = excluded.display_name,
      email = excluded.email,
      role = 'ADMIN',
      admission_status = 'APPROVED',
      updated_at = now();
  else
    insert into public.profiles (id, full_name, display_name, email, role, admission_status)
    values (new.id, nullif(trim(new.raw_user_meta_data->>'display_name'), ''), nullif(trim(new.raw_user_meta_data->>'display_name'), ''), lower(new.email), 'STUDENT', 'PENDING')
    on conflict (id) do nothing;
  end if;

  insert into public.preferences (user_id)
  values (new.id)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

revoke all on function private.provision_admin_from_allowlist() from public, anon, authenticated;

-- Existing trigger is replaced so every new Auth account gets a profile,
-- while allowlisted accounts become admins automatically.
drop trigger if exists provision_admin_on_auth_user on auth.users;
create trigger provision_admin_on_auth_user
after insert or update of email on auth.users
for each row execute function private.provision_admin_from_allowlist();
