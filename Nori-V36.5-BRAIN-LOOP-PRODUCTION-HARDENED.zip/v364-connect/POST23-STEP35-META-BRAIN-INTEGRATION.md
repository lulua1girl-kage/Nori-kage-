# Nori Post-23 Step 35 — Integrated Meta-Brain

Step 35 advances the Step 34 30-capability Meta-Brain from a capability catalog into a bounded orchestration cycle.

## Core cycle
USER REQUEST -> UNIFIED STATE -> GOVERNED MEMORY -> COGNITION -> META-BRAIN CAPABILITY SELECTION -> CONSTITUTION -> STRATEGY -> USER CONTROL -> EXISTING EXECUTION/AI/WEB/TOOLS -> VERIFICATION -> OUTCOME/LEARNING

The orchestrator itself does not perform side effects. ActionEngine, UserControl, existing execution handlers, provider layers and Android services remain authoritative for execution.

## All 30 capability families are evaluated in every integrated cycle
1. Cognitive loop
2. Personal world model
3. Temporal intelligence
4. Causal reasoning
5. Counterfactual reasoning
6. Adaptive personality
7. Conversation state
8. Relationship continuity
9. Dynamic goal graph
10. Skill graph
11. Misconception detection
12. Transfer intelligence
13. Retention model
14. Strategy experiments
15. Intervention intelligence
16. Human-state reasoning
17. Disclosure context
18. Contradiction resolution
19. Evidence graph
20. Self-correction
21. Capability execution lifecycle
22. Edge-AI execution
23. Model arbitration
24. Research brain
25. World awareness
26. App operating model
27. Failure recovery
28. Resource intelligence
29. Security/boundary intelligence
30. Meta-Brain supervision

## What changed from Step 34
- The Meta-Brain now consumes the actual NoriBrain unified state.
- It builds a governed memory context before planning.
- It calls the existing CognitiveEngine rather than inventing a second reasoning system.
- It evaluates the Constitution before choosing a response/action strategy.
- It evaluates all 30 capability families and reports capability-specific status/evidence.
- It exposes one native `process` bridge for the web UI.
- Freshness, user control, intent, cognitive effort and answer shape are propagated into the cycle.
- Edge AI is checked against the actual Edge-AI registry/policy; absence of a local model is reported instead of fabricated.
- World-awareness remains freshness-gated.
- Side effects remain outside the Meta-Brain and must pass existing action/permission controls.

## Important reality boundary
This is deeper integration, not a claim that every external service, Android permission, model weight or device-specific runtime is universally available. Device build/runtime validation is still required. No hidden chain-of-thought is stored or exposed.
