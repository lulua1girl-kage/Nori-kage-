# Nori V32 Integrity Patch

This build applies the source-level fixes that can be safely made without the user's Supabase secrets, deployed provider infrastructure, or a physical Android device.

## Patched
- Fractional exam-score band matching no longer falls back to Band 1 when a valid fractional score is between integer boundaries.
- API endpoints now require an authenticated Supabase bearer token, enforce request-size/rate limits, and use configurable CORS.
- `/api/decide` no longer accepts unauthenticated client-supplied state as authoritative.
- Provider-status access is behind the authenticated brain endpoint.
- Android exam-integrity service manifest package corrected.
- Missing native exam service imports corrected.
- WPS package visibility queries added.
- Boot/time-change alarm receiver added; alarms use exact scheduling when the OS permits it and otherwise fall back safely.
- Service-worker cache version advanced and old caches are deleted on activation.
- V47 production auth/config scripts are loaded before the admission gate.
- Admission/native role source uses the verified profile role instead of `app_metadata.role`; native bridge no longer accepts an arbitrary role string from JS.

## Requires deployment/device validation
- Configure `NORI_ALLOWED_ORIGINS`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, and frontend Supabase public configuration.
- Configure a real Supabase profile/role authorization policy and test native session verification on-device.
- Add persistent alarm storage/rescheduling logic if reminders must survive reboot exactly.
- Build and install on Android hardware; the ZIP cannot prove microphone, MediaProjection, alarm, overlay, WPS, or voice behavior.
- The voice/avatar system still needs consolidation into one production voice core.
- Human Override formula requires a policy decision and regression suite rather than an automatic guessed rewrite.
- Photo evidence policy requires multilingual/context-aware safety testing.
- Teaching/spaced repetition/mock-exam features remain future work and are intentionally not fabricated in this patch.
