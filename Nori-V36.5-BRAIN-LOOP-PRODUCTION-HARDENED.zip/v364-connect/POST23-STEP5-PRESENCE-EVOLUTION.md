# Post-Stage 23 Step 5 — Presence Evolution

This release advances both representations of the same Nori system:

- **Kage Avatar Chat:** monochrome Kage presentation; existing expressions/poses remain the visual library.
- **Interactive Circle:** JARVIS presentation using the existing white/orange/#306761 palette.
- Both remain presentation layers over the same Nori Brain, conversation, memory, tools and integrity boundaries.

## Added capability layer

1. Natural barge-in / interrupt control.
2. Explicit pause/resume turn control.
3. Live transcript event handling.
4. Same-chat voice/text continuity.
5. Speech-rate control (bounded 0.65–1.50).
6. Quick actions: simpler, repeat, summary, pause, continue.
7. Session continuity state.
8. Adaptive presence-state events.
9. Optional background-voice preference boundary; never enabled by this layer automatically.
10. Visual-context entry points for camera/screen; native permission remains explicit.
11. Reduced-motion support.
12. Declarative native capability contract for Android.

## Current industry-inspired patterns researched

As of September 2026, current voice assistants expose several useful interaction patterns:

- ChatGPT Voice supports natural interruption, waiting for the user to finish, voice/text in one chat, memory/web/image context, background conversations as an opt-in, and on eligible mobile Advanced Voice camera/screen sharing. (OpenAI Help Center.)
- Gemini Live supports free-flowing interruptions, longer contextual conversations, visual camera guidance, connected app actions, and more expressive speech; its August 2026 update adds voice-driven multi-step work, Personal Intelligence, Daily Brief and hands-free inbox management.
- Claude mobile Voice supports spoken conversation, key points on screen while speaking, and switching between text and voice in the same conversation.

These patterns were used as design references, not as claims that Nori already has every underlying native capability. Camera/screen capture and true background voice require Android-side integration and permissions beyond this additive presentation layer.

## Safety / integrity boundary

- No silent microphone or camera activation.
- No automatic background recording.
- Background voice is opt-in and remains bounded by the existing voice/service rules.
- Visual context is an explicit request and permission boundary.
- AI remains proposal/reasoning authority; Human Override remains higher authority for side effects.
- Existing Nori Brain and feature modules are not replaced.
