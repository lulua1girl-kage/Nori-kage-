# Nori Post23 Step 27 — App Understanding & User Control

## Core rule
**Understanding is not authorization.** Nori may understand a feature, goal, screen, or useful next step without being allowed to execute it.

## User paths
1. **EXPLAIN** — Nori explains the feature/capability.
2. **GUIDE** — Nori gives a manual, semantic walkthrough.
3. **ACTION** — Nori prepares an action preview; consequential work requires visible confirmation.
4. **FALLBACK** — If automation is unavailable, Nori switches to a manual route rather than claiming success.

## Advanced capability map
`NoriAppCapabilityCatalog` is a local searchable catalog of more than 100 Nori capabilities covering navigation, academics, study methods, adaptive learning, planning, voice, visual context, research, documents, memory, privacy, focus, diagnostics, provider routing, verification, human-context support, interfaces, scheduling and action control.

Each capability records its purpose, route, guide, permission boundary, risk, trigger examples and whether it is eligible for a deliberately configured schedule.

## Manual guides
`NoriGuideEngine` stores semantic guides with:
- goal
- starting location
- numbered steps
- expected progress
- alternative route
- common mistake
- rollback/cancel path
- completion condition

Guides do not execute actions.

## Action authorization
`NoriUserControlEngine` is a firewall between understanding and execution:
- no origin / system automatic -> user request required
- direct low-risk request -> may execute through existing ActionEngine
- direct consequential/cross-app/sensitive request -> visible confirmation
- user confirmation -> execution-ready
- deliberate user schedule -> bounded scheduled execution; sensitive/cross-app actions can require runtime confirmation
- stale authorization should not be reused indefinitely

Nori must not silently open apps, change settings, send/publish, capture camera/screen/mic, alter focus controls, or manipulate other apps merely because its Brain predicts that doing so would help.

## Voice
Voice is a first-class interface to the same Brain. A voice request follows:
`voice -> app understanding -> capability -> preview/guide -> authorization -> ActionEngine -> verification -> outcome`.

## Visual context
Camera/screen context remains explicitly user-started and permission-gated. It is context, not proof of intent.

## Nori UI
`nori-app-understanding-v1.js/css` adds a compact **HELP / FIND** control. It lets a new user describe a goal without knowing Nori's menu structure and hands off to navigation, manual guidance or Command preview.

## Android architecture references used as design guidance
The implementation follows current Android architectural patterns rather than copying external project code: Compose/single-activity navigation, reactive state, testable layers and repository separation are reflected in Android's architecture samples. Android's current predictive-back guidance is also relevant to Nori navigation. See the official Android references linked in the project research notes.

## Verification
Run:
`./verify-post23-step27.sh`

Android APK/device build remains a separate environment-dependent gate.
