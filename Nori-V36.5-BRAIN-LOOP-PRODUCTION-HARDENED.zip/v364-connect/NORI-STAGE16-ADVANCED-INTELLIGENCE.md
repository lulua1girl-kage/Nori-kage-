# Nori Native Java Stage 16 — Advanced Intelligence

## Purpose
Add a higher-order reasoning layer above Stage 12 Educational Intelligence without making cloud AI mandatory or turning statistical signals into diagnoses or certainties.

## Added
- `AdvancedIntelligence` coordinator.
- `TrajectoryAnalyzer` for explainable performance direction and stability.
- `AnomalyDetector` for unusual latest observations with bounded confidence.
- `StrategyEngine` for evidence-driven study intervention selection.
- Structured models for advanced insights, trajectories, anomalies, and recommendations.
- Brain accessor for Stage 16 intelligence.

## Design boundaries
- Deterministic/local-first; Stage 11 AI remains optional.
- Facts and inferences are separated.
- Temporal patterns are explicitly not treated as proof of causation.
- Low-data conditions reduce confidence rather than fabricating conclusions.
- Recommendations are bounded and do not execute device actions.
- Human Override remains authoritative.
- No peer ranking, student worth scoring, or psychological diagnosis.
- No automatic permanent self-modification of protected source/rules.

## Preserved
Stages 1–15 and all V32 JavaScript remain intact. Existing action confirmation, integrity protections, admin boundaries, document intelligence, and optional AI provider architecture remain in force.
