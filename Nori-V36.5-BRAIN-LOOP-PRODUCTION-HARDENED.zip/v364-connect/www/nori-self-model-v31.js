/* NORI V31 Self Model: operational introspection, not consciousness. */
(function(g){'use strict';
  function snapshot(){return g.NoriIntegratedV31&&g.NoriIntegratedV31.selfModel?g.NoriIntegratedV31.selfModel():{identity:{name:'Nori',version:'31'},limits:['Self-model unavailable']}}
  function explain(){const s=snapshot();return 'I am '+s.identity.name+' '+s.identity.version+'. My self-model describes my registered capabilities, environment, permissions, authority boundaries and integrity state. It does not mean I am conscious. I only claim access that a permitted tool actually reports.'}
  g.NoriSelfModelV31={snapshot,explain,capabilities:()=>snapshot().capabilities||[]};
})(window);
