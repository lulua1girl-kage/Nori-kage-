/* NORI TOOL ROUTER V22
   Deterministic routing: Local Brain -> App Data -> KAGE Knowledge -> Web -> AI -> Action.
   Side effects are always proposals until the user explicitly confirms them.
*/
(function(g){'use strict';
  var KEY='nori_tool_router_v22';
  var ACTION_WORDS=/\b(create|add|set|schedule|move|change|delete|remove|start|stop|enable|disable|remind|book|mark|complete|skip|focus|alarm|organize|execute|do this)\b/i;
  var DATA_WORDS=/\b(assignment|exam|grade|result|study session|calendar|deadline|reminder|focus mode|alarm|task|progress|analytics)\b/i;
  var DOC_WORDS=/\b(pdf|document|handbook|rule|policy|kage|knowledge base|source document)\b/i;
  var WEB_WORDS=/\b(search|research|browse|look up|latest|current|verify online|online)\b/i;
  function now(){return new Date().toISOString()}
  function load(k,fb){try{var x=JSON.parse(localStorage.getItem(k)||'null');return x==null?fb:x}catch(e){return fb}}
  function save(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function log(event){var a=load(KEY+'/audit',[]);a.push(Object.assign({at:now()},event));save(KEY+'/audit',a.slice(-300))}
  function has(name){return typeof g[name]==='function'}
  function appToolFor(t){
    if(/assignment/i.test(t)) return 'assignment';
    if(/exam|result|grade/i.test(t)) return 'exam';
    if(/study session|study block|study/i.test(t)) return 'study_session';
    if(/calendar|schedule/i.test(t)) return 'calendar';
    if(/remind/i.test(t)) return 'reminder';
    if(/focus mode|blocker/i.test(t)) return 'focus_mode';
    if(/alarm/i.test(t)) return 'alarm';
    return null;
  }
  function route(message,opts){
    opts=opts||{}; var t=String(message||'').trim(), lower=t.toLowerCase(); var stages=[]; var tools=[];
    if(!t) return {route:'local_brain',stages:['local_brain'],tools:[],reason:'Empty request.'};
    stages.push('local_brain');
    if(DATA_WORDS.test(lower)) { stages.push('app_data'); var at=appToolFor(lower); if(at) tools.push(at); }
    if(DOC_WORDS.test(lower)) { stages.push('kage_knowledge'); tools.push(/pdf|document/i.test(lower)?'document_analysis':'kage_retrieval'); }
    if(opts.webSearch===true || WEB_WORDS.test(lower)) { stages.push('web'); tools.push('web_search'); }
    if(!tools.length || /why|explain|analy[sz]e|compare|plan|reason/i.test(lower)) { stages.push('ai'); tools.push('reasoning_model'); }
    var action=null;
    if(ACTION_WORDS.test(lower) && (DATA_WORDS.test(lower)||/focus|alarm|remind/i.test(lower))) { stages.push('action'); action=at||(/focus/i.test(lower)?'focus_mode':/alarm/i.test(lower)?'alarm':'general'); }
    stages=stages.filter(function(x,i,a){return a.indexOf(x)===i});
    var requiresConfirmation=stages.indexOf('action')>=0;
    var out={route:requiresConfirmation?'action_proposal':stages[stages.length-1],stages:stages,tools:tools.filter(function(x,i,a){return a.indexOf(x)===i}),action:action,requiresConfirmation:requiresConfirmation,reason:requiresConfirmation?'An app side effect is requested; proposal requires explicit confirmation.':stages.indexOf('web')>=0?'External research was explicitly requested or clearly indicated.':stages.indexOf('kage_knowledge')>=0?'Local KAGE/document evidence is relevant.':'Local deterministic intelligence is sufficient before model reasoning.'};
    log({type:'route',message:t.slice(0,500),decision:out}); return out;
  }
  function appState(){
    var s={};
    try{s.assignments=has('noriAssignmentsLoad')?g.noriAssignmentsLoad():[];}catch(e){s.assignments=[]}
    try{s.exams=has('noriExamsLoad')?g.noriExamsLoad():[];}catch(e){s.exams=[]}
    try{s.calendar=has('noriCalendar')&&g.noriCalendar.events?g.noriCalendar.events():[];}catch(e){s.calendar=[]}
    try{s.nextMove=has('noriGetContextualNextMove')?g.noriGetContextualNextMove():null;}catch(e){s.nextMove=null}
    return s;
  }
  function propose(message,opts){var r=route(message,opts);var proposal={id:'proposal_'+Date.now().toString(36),createdAt:now(),message:String(message||''),route:r,appState:r.stages.indexOf('app_data')>=0?appState():null,status:r.requiresConfirmation?'pending_confirmation':'informational'};log({type:'proposal',proposal:proposal});return proposal}
  function confirm(id){var a=load(KEY+'/audit',[]);var p=a.map(function(x){return x.proposal}).filter(Boolean).find(function(x){return x&&x.id===id});if(!p)return {ok:false,reason:'proposal_not_found'};p.status='confirmed';p.confirmedAt=now();save(KEY+'/audit',a);log({type:'confirmation',proposalId:id});return {ok:true,proposal:p}}
  function cancel(id){log({type:'cancellation',proposalId:id});return {ok:true,id:id}}
  g.NoriToolRouterV22={route:route,propose:propose,confirm:confirm,cancel:cancel,appState:appState,audit:function(){return load(KEY+'/audit',[])}};
})(window);
