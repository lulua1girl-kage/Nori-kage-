/* NORI KAGE LAYER — contextual communication, notification intelligence,
   inspectable decisions, system integrity and visible Human Override. */
(function(){
  'use strict';
  const NKEY='nori_kage_notifications_v1', IKEY='nori_kage_inbox_v1', OKEY='nori_kage_overrides_v1';
  const load=(k,fb)=>{try{const v=JSON.parse(localStorage.getItem(k)||'null');return v==null?fb:v}catch(e){return fb}};
  const save=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}};
  const uid=p=>p+'_'+Date.now()+'_'+Math.random().toString(36).slice(2,8);
  const iso=()=>new Date().toISOString();
  const today=()=>iso().slice(0,10);
  const esc=v=>String(v==null?'':v);
  function results(){const all=typeof noriHistoryLoadAll==='function'?noriHistoryLoadAll():{};const out=[];Object.keys(all||{}).forEach(s=>(all[s]||[]).forEach(r=>{if(typeof r.score==='number')out.push({subject:s,score:r.score,date:r.date||''})}));return out}
  function assignments(){return typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():load('nori_command_assignments',[])}
  function exams(){return load('nori_exams',[])}
  function sessions(){return load('nori_study_sessions',[])}
  function activeConsequences(){return typeof noriActiveConsequences==='function'?noriActiveConsequences():[]}
  function calendar(){return window.noriCalendar&&typeof noriCalendar.allOccurrences==='function'?noriCalendar.allOccurrences:new Function('return []')}
  function latestBySubject(){const o={};results().sort((a,b)=>String(a.date).localeCompare(String(b.date))).forEach(r=>o[r.subject]=r);return o}
  function academicStatus(){const rs=results();if(!rs.length)return 'ATTENTION';const avg=rs.reduce((a,r)=>a+r.score,0)/rs.length;return avg<70?'RECOVERY':avg<80?'ATTENTION':'ON TRACK'}
  function scheduleStatus(){const a=assignments().filter(x=>x.status!=='done'&&x.due);const overdue=a.filter(x=>x.due<today()).length;return overdue>=2||a.length>=7?'OVERLOADED': 'STABLE'}
  function verificationStatus(){const a=assignments();return a.some(x=>x.status==='done'&&x.verification!=='verified')?'PENDING':'CLEAR'}
  function recoveryStatus(){return activeConsequences().length?'ACTIVE':'NONE'}
  function systemStatus(){return navigator.onLine===false?'DEGRADED':'ONLINE'}
  function statusModel(){return {academic:academicStatus(),schedule:scheduleStatus(),verification:verificationStatus(),recovery:recoveryStatus(),system:systemStatus()}}
  function contextual(){
    const rs=results(), by=latestBySubject(), a=assignments().filter(x=>x.status!=='done'), missed=a.filter(x=>x.due&&x.due<today()), active=activeConsequences();
    if(systemStatus()==='DEGRADED')return ['SYSTEM DEGRADED','Network is unavailable. Local records remain the working source until synchronization is restored.'];
    if(active.length)return ['RECOVERY ACTIVE','An active system restriction exists. Review the recovery requirement before restoring normal access.'];
    if(missed.length)return ['MISSED RESPONSIBILITY',missed.length+' unresolved responsibility(ies) are past due. Reassessment is available; no manufactured urgency will be added.'];
    if(a.length>=5)return ['LOAD DETECTED','Several responsibilities are accumulating. Reprioritization should protect the highest-value academic work.'];
    let weakest=null;Object.keys(by).forEach(s=>{if(!weakest||by[s].score<weakest.score)weakest=Object.assign({subject:s},by[s])});
    if(weakest&&weakest.score<70)return ['PRIORITY IDENTIFIED',weakest.subject+' has the strongest current recovery signal at '+weakest.score+'%.'];
    if(rs.length>=3){const sorted=rs.slice().sort((x,y)=>String(x.date).localeCompare(String(y.date)));const last=sorted[sorted.length-1],prev=sorted[sorted.length-2];if(last.score>prev.score)return ['TREND CONFIRMED','Recent evidence indicates improvement in '+last.subject+'.'];}
    if(a.length)return ['SYSTEM STATUS — STABLE',a.length+' academic responsibility(ies) require attention.'];
    return ['SYSTEM STATUS — STABLE','No unresolved priority has been detected from the current records.'];
  }
  function pushNotification(n){
    const list=load(NKEY,[]);const now=Date.now();const id=n.id||uid('notice');
    const idx=list.findIndex(x=>x.id===id);
    const row=Object.assign({id,type:'information',priority:'normal',timestamp:iso(),read:false,source:'system',action:null,expiresAt:null},n);
    if(idx>=0){list[idx]=Object.assign({},list[idx],row)}else list.push(row);
    const cutoff=now-1000*60*60*24*30;const clean=list.filter(x=>!x.expiresAt||new Date(x.expiresAt).getTime()>now).filter(x=>new Date(x.timestamp||0).getTime()>cutoff||!x.resolved);
    save(NKEY,clean);return row;
  }
  function logMessage(title,body,source='system',key){
    const list=load(IKEY,[]);if(key&&list.some(x=>x.key===key))return;
    list.push({id:uid('msg'),key:key||null,title,body,source,timestamp:iso()});
    save(IKEY,list.slice(-100));
  }
  function generate(){
    const out=[];const now=Date.now();
    assignments().filter(x=>x.status!=='done'&&x.due).forEach(x=>{const d=Math.ceil((new Date(x.due+'T23:59:59')-now)/86400000);if(d<=2)out.push({id:'assignment:'+x.id,title:d<0?'MISSED RESPONSIBILITY':d===0?'ACTION REQUIRED':'REMINDER',body:x.title+' · '+(x.subject||'Academic'),type:d<0?'warning':'reminder',priority:d<0?'high':'normal',source:'assignment',action:'#/'});});
    exams().forEach(x=>{const d=Math.ceil((new Date(x.date+'T23:59:59')-now)/86400000);if(d>=0&&d<=7)out.push({id:'exam:'+x.id,title:'EXAM APPROACHING',body:x.subject+' — '+x.title+' · '+x.date,type:'reminder',priority:d<=2?'high':'normal',source:'exam',action:'#/exams'});});
    sessions().filter(x=>x.status!=='completed'&&x.date<=today()).forEach(x=>out.push({id:'session:'+x.id,title:'SESSION READY',body:x.subject+' — '+x.topic+' · '+x.minutes+' min',type:'action',priority:'normal',source:'study session',action:'#/study'}));
    sessions().filter(x=>x.status==='completed'&&!x.verified).forEach(x=>out.push({id:'session-verify:'+x.id,title:'VERIFICATION PENDING',body:x.subject+' — '+x.topic+' was completed; verification is pending.',type:'action',priority:'normal',source:'verification',action:'#/verification'}));
    assignments().filter(x=>x.status==='done'&&x.verification!=='verified').forEach(x=>out.push({id:'verify:'+x.id,title:'VERIFICATION PENDING',body:x.title+' is completed but not yet verified.',type:'action',priority:'normal',source:'verification',action:'#/verification'}));
    activeConsequences().forEach(x=>out.push({id:'consequence:'+x.eventId+':'+x.consequenceId,title:'RECOVERY',body:x.label||'Active consequence requires review.',type:'warning',priority:'high',source:'consequence',action:'#/consequences'}));
    const missed=assignments().filter(x=>x.status!=='done'&&x.due&&x.due<today());if(missed.length)out.push({id:'recovery:missed:'+missed.map(x=>x.id).sort().join(','),title:'RECOVERY',body:missed.length+' missed responsibility(ies) detected. Review recovery rather than stacking demands.',type:'action',priority:'high',source:'recovery',action:'#/recover'});
    const rs=results().sort((a,b)=>String(a.date).localeCompare(String(b.date)));if(rs.length>=2){const a=rs[rs.length-2],b=rs[rs.length-1];if(a.subject===b.subject&&b.score>a.score)out.push({id:'trend:'+b.subject+':'+b.date,title:'TREND CONFIRMED',body:'Recent evidence indicates improvement in '+b.subject+'.',type:'information',priority:'normal',source:'academic trend',action:'#/progress'});}
    if(window.noriCalendar&&typeof noriCalendar.allOccurrences==='function'){
      const ds=new Date();const de=new Date(ds);de.setDate(de.getDate()+1);
      noriCalendar.allOccurrences(ds,de).filter(x=>x.start||x.occurrenceDate).slice(0,12).forEach(x=>{const d=x.occurrenceDate||x.start;if(d&&d<=today() || d===today() || d===de.toISOString().slice(0,10))out.push({id:'calendar:'+x.id+':'+d,title:'CALENDAR EVENT',body:x.title,type:'reminder',priority:'normal',source:'calendar',action:'#/calendar'})});
    }
    const integrity=integrityModel();if(integrity.some(x=>x.state==='DEGRADED'))out.push({id:'integrity:'+integrity.filter(x=>x.state==='DEGRADED').map(x=>x.name).join('|'),title:'SYSTEM ISSUE',body:'One or more system integrity checks require attention.',type:'system',priority:'high',source:'system integrity',action:'#/integrity'});
    const currentIds=new Set(out.map(x=>x.id));const existing=load(NKEY,[]);const reconciled=existing.map(x=>currentIds.has(x.id)?Object.assign({},x,{resolved:false}):Object.assign({},x,{resolved:true,resolvedAt:x.resolvedAt||iso()}));save(NKEY,reconciled.filter(x=>!x.resolved||new Date(x.timestamp||0).getTime()>now-1000*60*60*24*30));out.forEach(pushNotification);return out;
  }
  function activeNotifications(){return load(NKEY,[]).filter(x=>!x.resolved&&!x.expiresAt||(!x.resolved&&new Date(x.expiresAt).getTime()>Date.now()));}
  function renderNotifications(){
    generate();const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});wrap.appendChild(noriRenderCommandHeader(false));wrap.appendChild(noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:'Notifications'}]));
    const card=noriEl('section',{class:'nori-section-card'});const head=noriEl('div',{class:'nori-section-head'});head.appendChild(noriEl('h2',{text:'NOTIFICATION CENTER'}));const mark=noriEl('button',{class:'nori-btn nori-btn-ghost',text:'MARK ALL READ'});mark.onclick=()=>{const a=load(NKEY,[]);a.forEach(x=>x.read=true);save(NKEY,a);noriRoute()};head.appendChild(mark);card.appendChild(head);
    const list=noriEl('div',{class:'nori-notification-list'});const active=activeNotifications().slice().sort((a,b)=>{const p={high:0,normal:1,low:2};return (p[a.priority]??1)-(p[b.priority]??1)||String(b.timestamp).localeCompare(String(a.timestamp))});
    if(!active.length)list.appendChild(noriEl('div',{class:'nori-command-empty',text:'No active notifications. Resolved items remain historical rather than cluttering the command view.'}));
    active.forEach(x=>{const r=noriEl('div',{class:'nori-notification-row '+(x.read?'read':'unread')});const label=(x.priority==='high'?'ACTION REQUIRED':String(x.type||'information').toUpperCase());r.appendChild(noriEl('div',{class:'nori-notification-mark',text:x.read?'':'•'}));const b=noriEl('div',{});b.appendChild(noriEl('strong',{text:label}));b.appendChild(noriEl('span',{class:'nori-notification-body',text:x.body}));b.appendChild(noriEl('small',{text:x.source+' · '+new Date(x.timestamp).toLocaleString()}));r.appendChild(b);const acts=noriEl('div',{class:'nori-inline-actions'});if(x.action){const a=noriEl('a',{class:'nori-btn nori-btn-primary',href:x.action,text:'OPEN'});acts.appendChild(a)}const ack=noriEl('button',{class:'nori-btn nori-btn-ghost',text:x.read?'READ':'ACK'});ack.onclick=()=>{const a=load(NKEY,[]);const i=a.findIndex(y=>y.id===x.id);if(i>=0)a[i].read=true;save(NKEY,a);noriRoute()};acts.appendChild(ack);r.appendChild(acts);list.appendChild(r)});
    card.appendChild(list);wrap.appendChild(card);
    const hist=noriEl('section',{class:'nori-section-card'});hist.appendChild(noriEl('div',{class:'nori-section-head'},[noriEl('h2',{text:'RESOLVED / HISTORICAL'})]));const hlist=noriEl('div',{class:'nori-notification-list'});const history=load(NKEY,[]).filter(x=>x.resolved).slice().reverse().slice(0,30);if(!history.length)hlist.appendChild(noriEl('div',{class:'nori-command-empty',text:'No resolved notifications in history.'}));history.forEach(x=>{const r=noriEl('div',{class:'nori-notification-row read'});r.appendChild(noriEl('div',{class:'nori-notification-mark',text:'✓'}));const b=noriEl('div',{});b.appendChild(noriEl('strong',{text:x.title}));b.appendChild(noriEl('span',{class:'nori-notification-body',text:x.body}));b.appendChild(noriEl('small',{text:'RESOLVED · '+new Date(x.resolvedAt||x.timestamp).toLocaleString()}));r.appendChild(b);hlist.appendChild(r)});hist.appendChild(hlist);wrap.appendChild(hist);wrap.appendChild(noriBottomNav('profile'));return wrap;
  }
  function integrityModel(){
    const checks=[];
    const can=k=>{try{const s='__nori_'+k;localStorage.setItem(s,'1');localStorage.removeItem(s);return true}catch(e){return false}};
    checks.push({name:'Data storage',state:can('integrity')?'CLEAR':'DEGRADED',detail:'Local persistence available'});
    checks.push({name:'Calendar',state:window.noriCalendar&&typeof noriCalendar.allOccurrences==='function'?'CLEAR':'DEGRADED',detail:'Calendar engine '+(window.noriCalendar?'loaded':'missing')});
    checks.push({name:'Notifications',state:'CLEAR',detail:'Notification engine loaded'});
    checks.push({name:'Verification',state:typeof noriAssignmentsLoad==='function'?'CLEAR':'DEGRADED',detail:'Assignment verification path '+(typeof noriAssignmentsLoad==='function'?'available':'missing')});
    checks.push({name:'Academic records',state:typeof noriHistoryLoadAll==='function'?'CLEAR':'DEGRADED',detail:'Result history '+(typeof noriHistoryLoadAll==='function'?'available':'missing')});
    checks.push({name:'Recovery records',state:typeof noriActiveConsequences==='function'?'CLEAR':'DEGRADED',detail:'Recovery/consequence path '+(typeof noriActiveConsequences==='function'?'available':'missing')});
    const orphan=assignments().filter(x=>x.id==null).length;checks.push({name:'Orphaned assignments',state:orphan?'DEGRADED':'CLEAR',detail:orphan?orphan+' record(s) lack an id':'No orphaned assignment records detected'});
    return checks;
  }
  function whyDecision(){
    const rs=results(), by=latestBySubject(), ex=exams(), a=assignments().filter(x=>x.status!=='done');
    let best=null;Object.keys(by).forEach(s=>{const r=by[s];let score=(100-r.score);const upcoming=ex.some(e=>e.subject===s&&e.date>=today());const incomplete=a.filter(x=>x.subject===s).length;score+=upcoming?25:0;score+=Math.min(20,incomplete*5);if(!best||score>best.score)best={subject:s,score,record:r,upcoming,incomplete}});
    if(!best)return {title:'NO PRIORITY CHANGE',lines:['No sufficient academic evidence is recorded yet.','Record real results, deadlines or study evidence before asking Nori to reprioritize.']};
    const lines=[best.subject+' was prioritized because:'];lines.push('recent recorded performance: '+best.record.score+'%');if(best.upcoming)lines.push('an examination is approaching');if(best.incomplete)lines.push(best.incomplete+' incomplete responsibility(ies) remain');const others=Object.keys(by).filter(s=>s!==best.subject);if(others.length)lines.push(others.join(', ')+' currently have lower calculated urgency');lines.push('Decision: '+best.subject+' moved to Priority 1.');return {title:'DECISION BASIS',lines};
  }
  function overrideModal(){
    const ov=noriEl('div',{class:'nori-modal'}),m=noriEl('div',{class:'nori-modal-card nori-kage-modal'});const h=noriEl('div',{class:'nori-modal-head'});h.appendChild(noriEl('h2',{text:'HUMAN OVERRIDE'}));h.appendChild(noriEl('button',{class:'nori-btn nori-btn-ghost',text:'CLOSE'}));h.lastChild.onclick=()=>ov.remove();m.appendChild(h);
    m.appendChild(noriEl('p',{class:'nori-kage-copy',text:'Reality has changed. Reassess the plan instead of blindly enforcing the previous state.'}));const t=noriEl('textarea',{class:'nori-override-input',placeholder:'What changed? Include only information necessary for reassessment.'});m.appendChild(t);const b=noriEl('button',{class:'nori-btn nori-btn-primary',text:'REQUEST REASSESSMENT'});b.onclick=()=>{if(!t.value.trim()){t.focus();return}const arr=load(OKEY,[]);arr.push({id:uid('override'),timestamp:iso(),reason:t.value.trim(),status:'pending'});save(OKEY,arr);pushNotification({id:'override:'+arr[arr.length-1].id,title:'REASSESSMENT REQUESTED',body:'Human Override submitted. Nori should reassess schedule, workload, recovery and consequences.',type:'action',priority:'high',source:'human override',action:'#/integrity'});logMessage('Human Override submitted','A reassessment request was recorded. Previous plans remain historical until reassessment is completed.','human override');ov.remove();if(typeof noriRoute==='function')noriRoute()};m.appendChild(b);ov.appendChild(m);document.body.appendChild(ov);
  }
  function renderStatus(){const s=statusModel(),wrap=noriEl('section',{class:'nori-kage-status'});const head=noriEl('div',{class:'nori-kage-status-head'});head.appendChild(noriEl('strong',{text:'KAGE STATUS'}));head.appendChild(noriEl('span',{text:'SYSTEM INTEGRITY LAYER'}));wrap.appendChild(head);const grid=noriEl('div',{class:'nori-kage-status-grid'});[['Academic',s.academic],['Schedule',s.schedule],['Verification',s.verification],['Recovery',s.recovery],['System',s.system]].forEach(x=>{const r=noriEl('div',{class:'nori-kage-status-item '+(x[1]==='DEGRADED'||x[1]==='RECOVERY'||x[1]==='OVERLOADED'||x[1]==='PENDING'?'attention':'')});r.appendChild(noriEl('span',{text:x[0]}));r.appendChild(noriEl('strong',{text:x[1]}));grid.appendChild(r)});wrap.appendChild(grid);return wrap}
  function renderMessage(){const c=contextual(),el=noriEl('section',{class:'nori-kage-message'});el.appendChild(noriEl('div',{class:'nori-kage-message-label',text:c[0]}));el.appendChild(noriEl('div',{class:'nori-kage-message-text',text:c[1]}));return el}
  function addHeaderControls(){const headers=document.querySelectorAll('.nori-shell-header');headers.forEach(h=>{if(h.querySelector('.nori-kage-controls'))return;const c=noriEl('div',{class:'nori-kage-controls'});const count=load(NKEY,[]).filter(x=>!x.read&&!x.resolved).length;const n=noriEl('a',{href:'#/notifications',class:'nori-kage-nav-link',text:'NOTIFICATIONS'+(count?' ['+count+']':'')});const i=noriEl('a',{href:'#/inbox',class:'nori-kage-nav-link',text:'INBOX'});const o=noriEl('button',{class:'nori-kage-override-link',text:'OVERRIDE'});o.onclick=overrideModal;c.appendChild(n);c.appendChild(i);c.appendChild(o);h.appendChild(c)});}
  function renderInbox(){generate();const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});if(typeof noriRenderCommandHeader==='function')wrap.appendChild(noriRenderCommandHeader(false));wrap.appendChild(noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:'Nori Inbox'}]));const card=noriEl('section',{class:'nori-section-card'});const head=noriEl('div',{class:'nori-section-head'});head.appendChild(noriEl('h2',{text:'NORI INBOX'}));const clear=noriEl('button',{class:'nori-btn nori-btn-ghost',text:'CLEAR HISTORY'});clear.onclick=()=>{save(IKEY,[]);if(typeof noriRoute==='function')noriRoute()};head.appendChild(clear);card.appendChild(head);const list=noriEl('div',{class:'nori-inbox-list'});const rows=load(IKEY,[]).slice().reverse();if(!rows.length)list.appendChild(noriEl('div',{class:'nori-command-empty',text:'No system communications recorded yet.'}));rows.forEach(x=>{const r=noriEl('div',{class:'nori-inbox-row'});r.appendChild(noriEl('div',{class:'nori-inbox-time',text:'NORI / '+new Date(x.timestamp).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})}));r.appendChild(noriEl('strong',{text:x.title}));r.appendChild(noriEl('p',{text:x.body}));r.appendChild(noriEl('small',{text:x.source+' · '+new Date(x.timestamp).toLocaleDateString()}));list.appendChild(r)});card.appendChild(list);wrap.appendChild(card);wrap.appendChild(noriBottomNav('profile'));return wrap}
  function renderIntegrity(){generate();const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});wrap.appendChild(noriRenderCommandHeader(false));wrap.appendChild(noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:'System Integrity'}]));const card=noriEl('section',{class:'nori-section-card'});const head=noriEl('div',{class:'nori-section-head'});head.appendChild(noriEl('h2',{text:'SYSTEM INTEGRITY'}));head.appendChild(noriEl('span',{text:'GOVERNING LAYER'}));card.appendChild(head);integrityModel().forEach(x=>{const r=noriEl('div',{class:'nori-integrity-row '+(x.state==='DEGRADED'?'bad':'')});r.appendChild(noriEl('strong',{text:x.name}));r.appendChild(noriEl('span',{text:x.state}));r.appendChild(noriEl('small',{text:x.detail}));card.appendChild(r)});wrap.appendChild(card);const why=noriEl('section',{class:'nori-section-card'});why.appendChild(noriEl('div',{class:'nori-section-head'},[noriEl('h2',{text:'WHY Nori decided this'})]));const d=whyDecision();const body=noriEl('div',{class:'nori-why-body'});body.appendChild(noriEl('strong',{text:d.title}));d.lines.forEach(l=>body.appendChild(noriEl('div',{text:l})));why.appendChild(body);wrap.appendChild(why);const ov=noriEl('section',{class:'nori-section-card'});ov.appendChild(noriEl('div',{class:'nori-section-head'},[noriEl('h2',{text:'HUMAN OVERRIDE'})]));ov.appendChild(noriEl('p',{class:'nori-kage-copy',text:'Reality has changed. Reassess the plan.'}));const b=noriEl('button',{class:'nori-btn nori-btn-primary',text:'OPEN OVERRIDE'});b.onclick=overrideModal;ov.appendChild(b);wrap.appendChild(ov);wrap.appendChild(noriBottomNav('profile'));return wrap}
  function afterRoute(parts){
    generate();
    const root=document.getElementById('nori-app');if(!root)return;
    addHeaderControls();
    const first=root.firstElementChild;if(first&&first.classList.contains('nori-command-wrap')){
      if(!first.querySelector('.nori-kage-status')){const header=first.querySelector('.nori-shell-header');if(header&&header.nextSibling)header.parentNode.insertBefore(renderStatus(),header.nextSibling);else first.insertBefore(renderStatus(),first.firstChild)}
      if(!first.querySelector('.nori-kage-message')){const status=first.querySelector('.nori-kage-status');if(status)status.after(renderMessage())}
    }else if(first&&!first.querySelector('.nori-kage-global')){
      const box=noriEl('div',{class:'nori-kage-global'});box.appendChild(renderStatus());box.appendChild(renderMessage());first.insertBefore(box,first.firstChild)
    }
    const profileLinks=root.querySelectorAll('.nori-system-link');
    if(profileLinks.length){const parent=profileLinks[0].parentElement;if(parent&&!parent.querySelector('[data-kage-links]')){const marker=noriEl('div',{"data-kage-links":'1'});marker.appendChild(noriEl('a',{class:'nori-system-link',href:'#/inbox'},[noriEl('span',{text:'Nori Inbox'}),noriEl('span',{text:'→'})]));marker.appendChild(noriEl('a',{class:'nori-system-link',href:'#/integrity'},[noriEl('span',{text:'System Integrity / WHY / Override'}),noriEl('span',{text:'→'})]));parent.appendChild(marker)}}
    const quote=root.querySelector('.nori-quote-text');if(quote){const c=contextual();quote.textContent=c[1];const author=root.querySelector('.nori-quote-author');if(author)author.textContent='— '+c[0]}
    logMessage(contextual()[0],contextual()[1],'context engine','context:'+today()+':'+contextual()[0]);
  }
  window.noriKagePushNotification=pushNotification;
  window.noriKageAfterRoute=afterRoute;window.noriKageRenderInbox=renderInbox;window.noriKageRenderNotifications=renderNotifications;window.noriKageRenderIntegrity=renderIntegrity;window.noriKageOverride=overrideModal;window.noriKageGenerateNotifications=generate;
  window.noriKageBoot=function(){generate()};
})();
