/* ==========================================================================
   NORI PHASE — AI EVALUATION (CLIENT)
   ==========================================================================
   A second floating button, "Report Result", separate from the Check-In
   button. This one is for reporting an actual score ("I got 65% on my
   chemistry test, I've been really tired this week") and getting back a
   full Band/Degree classification, Human Override screening, award
   crediting, auto-filled forms, and a recovery schedule.

   Reuses noriListenOnce / noriSpeak from nori-ai-checkin.js (load that
   file first), noriStorageKey / noriLoadEntries / noriSaveEntries /
   noriHistoryLoadAll / noriHistoryAppend from nori-storage.js, and
   noriEl / noriFindPhase / noriFindSystem / noriFindForm / noriRoute
   from nori-phase-app.js.

   CONFIGURE THIS ONE LINE before deploying:
   ========================================================================== */
const NORI_EVAL_ENDPOINT = NORI_API_BASE_URL + "/api/evaluate"; // base URL set once in nori-native-bridge.js

/* ========================================================================== */

// Subject-result history reads/writes go through noriHistoryLoadAll /
// noriHistoryAppend in nori-storage.js — this used to be a separate,
// independently-maintained copy of the same logic (nori-meet.js had
// another one) writing the exact same key; now there's exactly one.

/* ---------------------------- .ics EXPORT ---------------------------- */

function noriEvalBuildICS(schedule) {
  function stamp(d) { return d.replace(/-/g, ""); }
  const lines = ["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//NORI PHASE//Recovery Schedule//EN"];
  schedule.forEach(function (block, i) {
    lines.push(
      "BEGIN:VEVENT",
      "UID:nori-recovery-" + Date.now() + "-" + i + "@noriphase",
      "DTSTART;VALUE=DATE:" + stamp(block.date),
      "SUMMARY:" + (block.task || "Recovery block") + (block.durationMinutes ? " (" + block.durationMinutes + " min)" : ""),
      "END:VEVENT"
    );
  });
  lines.push("END:VCALENDAR");
  return lines.join("\r\n");
}

function noriEvalDownloadICS(schedule) {
  const blob = new Blob([noriEvalBuildICS(schedule)], { type: "text/calendar" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "nori-recovery-schedule.ics";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/* ---------------------------- SAVING FORM ENTRIES ---------------------------- */

function noriEvalSaveEntries(entries) {
  entries.forEach(function (entry) {
    const key = noriStorageKey(entry.phaseId, entry.systemId, entry.formId);
    if (entry.kind === "table-log") {
      const existing = noriLoadEntries(key);
      existing.push(entry.row || {});
      noriSaveEntries(key, existing);
    } else if (entry.kind === "snapshot-log") {
      const phase = noriFindPhase(entry.phaseId);
      const system = phase && noriFindSystem(phase, entry.systemId);
      const form = system && noriFindForm(system, entry.formId);
      if (!form || !form.fixedTable) return;
      const snapEntry = { date: new Date().toISOString().slice(0, 10), values: {}, freeText: {}, fixedTable: {} };
      form.fixedTable.rows.forEach(function (rowLabel) {
        snapEntry.fixedTable[rowLabel] = {};
        form.fixedTable.columns.forEach(function (col) { snapEntry.fixedTable[rowLabel][col.key] = ""; });
      });
      if (snapEntry.fixedTable[entry.fixedTableRow]) {
        Object.keys(entry.values || {}).forEach(function (k) {
          snapEntry.fixedTable[entry.fixedTableRow][k] = entry.values[k];
        });
      }
      const existing = noriLoadEntries(key);
      existing.push(snapEntry);
      noriSaveEntries(key, existing);
    }
  });
  noriRoute();
}

/* ---------------------------- MODAL UI ---------------------------- */

function noriEvalBuildModal() {
  const overlay = noriEl("div", { class: "nori-checkin-overlay" });
  const modal = noriEl("div", { class: "nori-checkin-modal" });
  overlay.appendChild(modal);
  const closeBtn = noriEl("button", { class: "nori-btn nori-btn-ghost nori-checkin-close", text: "Close" });
  const title = noriEl("h2", { class: "nori-panel-title", text: "Report Result" });
  const status = noriEl("p", { class: "nori-checkin-status", text: "Tap the mic and report a result \u2014 subject, score, and how it went." });
  const transcriptBox = noriEl("p", { class: "nori-checkin-transcript" });
  const actions = noriEl("div", { class: "nori-checkin-actions" });
  const resultBox = noriEl("div", { class: "nori-checkin-result" });
  modal.appendChild(closeBtn);
  modal.appendChild(title);
  modal.appendChild(status);
  modal.appendChild(transcriptBox);
  modal.appendChild(actions);
  modal.appendChild(resultBox);
  closeBtn.addEventListener("click", function () {
    window.speechSynthesis && window.speechSynthesis.cancel();
    overlay.remove();
  });
  return { overlay: overlay, status: status, transcriptBox: transcriptBox, actions: actions, resultBox: resultBox };
}

function noriEvalRenderClassification(data) {
  const box = noriEl("div", { class: "nori-checkin-entry-preview" });
  if (data.subject) box.appendChild(noriEl("p", { class: "nori-history-line", text: "Subject: " + data.subject }));
  if (data.reportedScore !== null && data.reportedScore !== undefined) box.appendChild(noriEl("p", { class: "nori-history-line", text: "Score: " + data.reportedScore + "%" }));
  if (data.band) box.appendChild(noriEl("p", { class: "nori-history-line", text: "Band: " + data.band }));
  if (data.degree) box.appendChild(noriEl("p", { class: "nori-history-line", text: "Degree: " + data.degree }));
  if (data.recoveryActions && data.recoveryActions.length) {
    box.appendChild(noriEl("p", { class: "nori-checkin-entry-title", text: "Recovery actions" }));
    data.recoveryActions.forEach(function (a) { box.appendChild(noriEl("p", { class: "nori-history-line", text: "\u2022 " + a })); });
  }
  return box;
}

function noriEvalRenderOverride(ho) {
  if (!ho || !ho.circumstanceDetected) return null;
  const box = noriEl("div", { class: "nori-checkin-entry-preview" });
  box.appendChild(noriEl("p", { class: "nori-checkin-entry-title", text: "Human Override \u2014 " + (ho.category || "circumstance noted") }));
  box.appendChild(noriEl("p", { class: "nori-history-line", text: "Priority level: " + (ho.priorityLevel || "\u2014") + " \u2192 " + (ho.adjustment || "none") }));
  if (ho.note) box.appendChild(noriEl("p", { class: "nori-history-line", text: ho.note }));
  return box;
}

function noriEvalRenderAwards(awards) {
  if (!awards || !awards.length) return null;
  const box = noriEl("div", { class: "nori-checkin-entry-preview" });
  box.appendChild(noriEl("p", { class: "nori-checkin-entry-title", text: "Awards" }));
  awards.forEach(function (a) {
    box.appendChild(noriEl("p", { class: "nori-history-line", text: a.level + (a.points ? " (+" + a.points + " pts)" : "") + " \u2014 " + a.reason }));
  });
  return box;
}

function noriEvalRenderFormEntries(entries) {
  const box = noriEl("div", { class: "nori-checkin-entry-preview" });
  box.appendChild(noriEl("p", { class: "nori-checkin-entry-title", text: "Will save to" }));
  entries.forEach(function (e) {
    const phase = noriFindPhase(e.phaseId);
    const system = phase && noriFindSystem(phase, e.systemId);
    const form = system && noriFindForm(system, e.formId);
    box.appendChild(noriEl("p", { class: "nori-history-line", text: (form ? form.title : e.formId) + (e.fixedTableRow ? " \u2014 " + e.fixedTableRow : "") }));
  });
  return box;
}

function noriEvalRenderSchedule(schedule) {
  if (!schedule || !schedule.length) return null;
  const box = noriEl("div", { class: "nori-checkin-entry-preview" });
  box.appendChild(noriEl("p", { class: "nori-checkin-entry-title", text: "Proposed recovery schedule" }));
  schedule.forEach(function (b) {
    box.appendChild(noriEl("p", { class: "nori-history-line", text: b.date + " \u2014 " + b.task + (b.durationMinutes ? " (" + b.durationMinutes + " min)" : "") }));
  });
  return box;
}

async function noriEvalRunFlow(ui) {
  let transcript;
  try {
    ui.status.textContent = "Listening\u2026";
    transcript = await noriListenOnce();
  } catch (err) {
    if (err.message === "no-speech-api") {
      ui.status.textContent = "Voice input isn't supported in this browser \u2014 type instead.";
      const input = noriEl("input", { type: "text", class: "nori-checkin-typed", placeholder: "e.g. got 65% on chemistry, tired all week" });
      const submitBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "Submit" });
      ui.actions.appendChild(input);
      ui.actions.appendChild(submitBtn);
      transcript = await new Promise(function (resolve) { submitBtn.addEventListener("click", function () { resolve(input.value.trim()); }); });
      ui.actions.innerHTML = "";
    } else {
      ui.status.textContent = "Didn't catch that \u2014 tap the mic to try again.";
      const retryBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "\ud83c\udf99\ufe0f Try again" });
      ui.actions.appendChild(retryBtn);
      retryBtn.addEventListener("click", function () { ui.actions.innerHTML = ""; noriEvalRunFlow(ui); });
      return;
    }
  }

  if (!transcript) {
    ui.status.textContent = "Nothing recorded \u2014 tap the mic to try again.";
    const retryBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "\ud83c\udf99\ufe0f Try again" });
    ui.actions.appendChild(retryBtn);
    retryBtn.addEventListener("click", function () { ui.actions.innerHTML = ""; noriEvalRunFlow(ui); });
    return;
  }

  ui.transcriptBox.textContent = "\u201c" + transcript + "\u201d";
  ui.status.textContent = "Evaluating\u2026";

  let data;
  try {
    const resp = await fetch(NORI_EVAL_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ transcript: transcript, subjectHistory: noriHistoryLoadAll() })
    });
    if (!resp.ok) throw new Error("Backend returned " + resp.status);
    data = await resp.json();
  } catch (err) {
    ui.status.textContent = "Couldn't reach the AI backend. Check that it's deployed and NORI_EVAL_ENDPOINT is correct.";
    return;
  }

  ui.status.textContent = data.summary || "Here's what I understood.";
  noriSpeak((data.summary || "Here's the evaluation.") + " Say yes to save, or no to cancel.");

  if (data.band || data.degree) ui.resultBox.appendChild(noriEvalRenderClassification(data));
  const overrideBox = noriEvalRenderOverride(data.humanOverride);
  if (overrideBox) ui.resultBox.appendChild(overrideBox);
  const awardsBox = noriEvalRenderAwards(data.awards);
  if (awardsBox) ui.resultBox.appendChild(awardsBox);
  if (data.formEntries && data.formEntries.length) ui.resultBox.appendChild(noriEvalRenderFormEntries(data.formEntries));
  const scheduleBox = noriEvalRenderSchedule(data.recoverySchedule);
  if (scheduleBox) ui.resultBox.appendChild(scheduleBox);

  const confirmBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "\u2713 Save" });
  const cancelBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "\u2717 Cancel" });
  ui.actions.appendChild(confirmBtn);
  ui.actions.appendChild(cancelBtn);
  if (data.recoverySchedule && data.recoverySchedule.length) {
    const icsBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "\ud83d\udcc5 Download schedule (.ics)" });
    icsBtn.addEventListener("click", function () { noriEvalDownloadICS(data.recoverySchedule); });
    ui.actions.appendChild(icsBtn);
  }

  confirmBtn.addEventListener("click", function () {
    if (data.formEntries && data.formEntries.length) noriEvalSaveEntries(data.formEntries);
    if (data.subject) {
      noriHistoryAppend(data.subject, {
        date: new Date().toISOString().slice(0, 10),
        score: data.reportedScore,
        band: data.band,
        degree: data.degree,
        overrideCategory: data.humanOverride && data.humanOverride.circumstanceDetected ? data.humanOverride.category : null
      });
    }
    ui.status.textContent = "Saved.";
    noriSpeak("Saved.");
    ui.actions.innerHTML = "";
  });
  cancelBtn.addEventListener("click", function () {
    ui.status.textContent = "Not saved.";
    ui.resultBox.innerHTML = "";
    ui.actions.innerHTML = "";
  });

  if (NORI_SPEECH_SUPPORTED) {
    noriListenOnce().then(function (said) {
      const lower = said.toLowerCase();
      if (lower.indexOf("yes") !== -1) confirmBtn.click();
      else if (lower.indexOf("no") !== -1) cancelBtn.click();
    }).catch(function () { /* ignore — tap buttons still work */ });
  }
}

function noriEvalOpen() {
  const ui = noriEvalBuildModal();
  document.body.appendChild(ui.overlay);
  noriEvalRunFlow(ui);
}

function noriEvalMountButton() {
  const btn = noriEl("button", { class: "nori-checkin-fab nori-eval-fab", text: "\ud83d\udcca Report Result" });
  btn.addEventListener("click", noriEvalOpen);
  document.body.appendChild(btn);
}

window.addEventListener("DOMContentLoaded", noriEvalMountButton);
