/* NORI APP UNDERSTANDING V1 — searchable self-help + manual/action handoff. */
(function(g){'use strict';
  const CAPS=[
    ['CONFUSION','I am confused / lost','Tell Nori what you want to accomplish; you do not need the feature name.'],
    ['GUIDE','Show me how','Nori gives a manual route without performing the action.'],
    ['ACTION','Do it for me','Nori prepares a visible action preview; important actions still require confirmation.'],
    ['CAPABILITY','What can Nori do?','Nori explains what is available, permission-dependent, provider-dependent, or unavailable.'],
    ['VOICE','Use voice','Start the visible voice session, then ask Nori to navigate or prepare an action.'],
    ['VISUAL','Understand this screen','Use an explicit screen/camera context entry point; there is no covert capture.'],
    ['PRIVACY','Why is permission needed?','Nori explains scope and asks only when the capability actually needs it.'],
    ['BACKGROUND','Why did Nori not do it automatically?','Understanding a useful action is not authorization. User request or deliberate schedule is required.'],
    ['FALLBACK','Nori cannot do it','Nori switches to a manual guide instead of pretending the action succeeded.']
  ];
  function norm(s){return String(s||'').toLowerCase().replace(/[^a-z0-9 ]+/g,' ').replace(/\s+/g,' ').trim();}
  function ensure(){if(document.getElementById('nori-app-understanding'))return;
    const b=document.createElement('button');b.id='nori-app-understanding';b.className='nori-understand-launch';b.innerHTML='<b>?</b><span>HELP / FIND</span>';b.title='Ask Nori what you want to find or how to use the app';b.onclick=open;
    document.body.appendChild(b);
  }
  function open(prefill){
    let shell=document.getElementById('nori-understand-panel');
    if(shell){shell.classList.add('open');const input=shell.querySelector('input');if(prefill){input.value=prefill;render(prefill)}input.focus();return;}
    shell=document.createElement('aside');shell.id='nori-understand-panel';shell.className='nori-understand-panel';
    shell.innerHTML='<div class="nori-understand-head"><div><small>NORI / APP UNDERSTANDING</small><strong>What are you trying to do?</strong></div><button aria-label="Close">×</button></div><div class="nori-understand-rule">UNDERSTANDING ≠ AUTHORIZATION</div><div class="nori-understand-search"><input autocomplete="off" placeholder="e.g. I want to see my results"/><button>FIND</button></div><div class="nori-understand-result"></div><div class="nori-understand-grid"></div>';
    document.body.appendChild(shell);shell.querySelector('.nori-understand-head button').onclick=()=>shell.classList.remove('open');shell.querySelector('.nori-understand-search button').onclick=()=>render(shell.querySelector('input').value);shell.querySelector('input').addEventListener('keydown',e=>{if(e.key==='Enter')render(e.target.value)});
    const grid=shell.querySelector('.nori-understand-grid');CAPS.forEach(x=>{const c=document.createElement('button');c.innerHTML='<b>'+x[0]+'</b><span>'+x[1]+'</span><small>'+x[2]+'</small>';c.onclick=()=>{shell.querySelector('input').value=x[1];render(x[1])};grid.appendChild(c)});
    shell.classList.add('open');if(prefill){shell.querySelector('input').value=prefill;render(prefill)}shell.querySelector('input').focus();
  }
  function render(q){const out=document.querySelector('#nori-understand-panel .nori-understand-result');if(!out)return;const n=norm(q);let items=[];
    const route=(g.NoriNavigationBrain&&g.NoriNavigationBrain.routeFor)?g.NoriNavigationBrain.routeFor(q):null;
    if(route){items.push({label:'NAVIGATE',text:'I found a Nori workspace for that request.',action:function(){g.NoriNavigationBrain.go(route)}})}
    if(/lost|confused|what do i|how do i|find|where/.test(n))items.push({label:'GUIDE',text:'I can give you a manual guide without changing anything.',action:function(){if(g.NoriNavigationBrain&&g.NoriNavigationBrain.go)g.NoriNavigationBrain.go('#/meet-nori')}});
    if(/do it|do this|make|set|create|start|schedule|scan/.test(n))items.push({label:'ACTION PREVIEW',text:'I can prepare the action, but it needs your deliberate request and may require confirmation.',action:function(){if(g.NoriNavigationBrain&&g.NoriNavigationBrain.go)g.NoriNavigationBrain.go('#/command')}});
    if(!items.length)items.push({label:'MEET NORI',text:'Tell Nori the goal in plain language. You do not need to know the feature name.',action:function(){if(g.NoriNavigationBrain&&g.NoriNavigationBrain.go)g.NoriNavigationBrain.go('#/meet-nori')}});
    out.innerHTML='';items.forEach(x=>{const d=document.createElement('div');d.className='nori-understand-hit';d.innerHTML='<div><b>'+x.label+'</b><p>'+x.text+'</p></div><button>OPEN →</button>';d.querySelector('button').onclick=()=>{x.action();document.getElementById('nori-understand-panel').classList.remove('open')};out.appendChild(d)});
  }
  g.NoriAppUnderstandingUI={open,render};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',ensure);else ensure();
})(window);
