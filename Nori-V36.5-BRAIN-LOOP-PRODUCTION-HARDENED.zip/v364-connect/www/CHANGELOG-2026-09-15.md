# Nori integration pass — 2026-09-15

- Added a unified Today/Command panel on the Nori home screen.
- Added Merit Points progress using the persisted award ledger balance.
- Connected native Focus Mode startup to `/api/domain-status` and the current Supabase access token.
- Added a native `refreshRestrictions` bridge method for consequence-state refreshes.
- Native blocker now preserves manually selected apps while dynamically adding consequence-restricted domains, and returns to the manual selection when restrictions expire.
- Kept the deterministic decision engine as the authority for result/breach classification and automatic score-band Merit granting.
- Degree 5 case-file and Active Consequences screens remain audit-oriented and do not create escalations by themselves.

## Verification

JavaScript syntax checks pass for the edited browser/API files. Native Android blocker code still requires a real-device test because Usage Access and overlay behavior cannot be verified inside this build environment.
