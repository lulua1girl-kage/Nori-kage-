/* NORI INTERFACE MODE V1 — presentation selector. One Brain, one memory, multiple faces. */
(function(g){'use strict';
  var KEY='nori.interface.mode';
  var MODES={standard:'STANDARD',kage:'KAGE',circle:'CIRCLE',hybrid:'HYBRID',compact:'COMPACT'};
  function get(){try{var m=localStorage.getItem(KEY)||'standard';return MODES[m]?m:'standard'}catch(e){return 'standard'}}
  function set(mode){mode=String(mode||'').toLowerCase();if(!MODES[mode])return false;try{localStorage.setItem(KEY,mode)}catch(e){} document.documentElement.dataset.noriInterface=mode;document.body.dataset.noriInterface=mode;
    if(g.NoriInteractivePresence){ if(mode==='circle'||mode==='hybrid') g.NoriInteractivePresence.setMode('circle'); else if(mode==='kage') g.NoriInteractivePresence.setMode('avatar'); }
    g.dispatchEvent(new CustomEvent('nori:interface-change',{detail:{mode:mode,label:MODES[mode]}})); return true;
  }
  function apply(){var m=get();document.documentElement.dataset.noriInterface=m;document.body.dataset.noriInterface=m;return m}
  function open(){var m=get(); if(m==='kage'&&g.NoriAvatarV26&&g.NoriAvatarV26.open)return g.NoriAvatarV26.open(); if((m==='circle'||m==='hybrid')&&g.NoriInteractivePresence&&g.NoriInteractivePresence.open)return g.NoriInteractivePresence.open('chat'); if(m==='compact'&&g.NoriInteractivePresence&&g.NoriInteractivePresence.open)return g.NoriInteractivePresence.open('chat'); return false}
  g.NoriInterfaceMode={get:get,set:set,apply:apply,open:open,modes:MODES};
  apply();
  g.addEventListener('nori:interface-change',function(e){var m=e&&e.detail&&e.detail.mode;if(m)apply()});
})(window);
