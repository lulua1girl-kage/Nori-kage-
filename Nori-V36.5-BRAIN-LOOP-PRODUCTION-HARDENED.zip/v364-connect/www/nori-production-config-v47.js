/* Nori Step 47 runtime configuration. Public values only. Never put service-role,
   SMTP, Resend, OpenAI/Gemini or other secret keys here. */
window.NORI_PRODUCTION_CONFIG = Object.freeze({
  supabaseUrl: 'https://qrlvkxewyoceykaquapv.supabase.co',
  supabaseAnonKey: '',
  adminVerifyFunction: '/functions/v1/admin-verify',
  adminReportFunction: '/functions/v1/admin-report',
  libraryBucket: 'nori-library',
  logicalQuotaBytes: 16106127360,
  maxSingleFileBytes: 5368709120,
  approvedSessionDoesNotRequireRepeatedAdmission: true,
  backupEmailRequiredForRecovery: true
});
