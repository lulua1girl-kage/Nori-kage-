/* ==========================================================================
   NORI — RULES LOADER
   ==========================================================================
   Before this file existed, the handbook's rules lived in TWO places: the
   JSON files (nori-exam-result-rules.json, nori-award-rules.json,
   nori-human-override-rules.json, nori-system-integrity-rules.json — used
   server-side by api/evaluate.js and api/brain.js) AND a second,
   hand-typed copy of the same data baked in as JS constants inside
   nori-meet.js, for the client-side deterministic calculator (so it can
   classify Bands/Degrees/Awards without a network round-trip). Same
   fragmentation problem the storage layer and speech bridge fixed,
   applied here to the handbook rules themselves — the two copies had no
   way to stay in sync if either one changed.

   This file fetches the real JSON (the same files the backend reads) and
   derives the exact shapes nori-meet.js's calculator functions use. There
   is now exactly one copy of the handbook data; nori-meet.js just reads it.

   Load this AFTER nori-native-bridge.js and BEFORE nori-phase-data.js /
   nori-meet.js. Anything that reads the derived constants below should
   only do so after NORI_RULES_READY has resolved — in practice that means
   inside a user-interaction handler (button click, form open), never at
   page-parse time, since the fetch is async.
   ========================================================================== */

let NORI_RULES_EXAM = null;
let NORI_RULES_AWARD = null;
let NORI_RULES_OVERRIDE = null;
let NORI_RULES_INTEGRITY = null;

// Derived shapes nori-meet.js's calculator reads — empty until
// NORI_RULES_READY resolves, then populated straight from the JSON above.
let NORI_MEET_BANDS = [];
let NORI_MEET_MERIT_POINTS = [];
let NORI_MEET_DEGREE_ACTIONS = {};
let NORI_MEET_OVERRIDE_CATEGORIES = [];
let NORI_MEET_OVERRIDE_LEVELS = [];
let NORI_MEET_DESTRUCTION_CATEGORIES = [];
let NORI_MEET_BREACH_TEST = { isABreach: [], isNotAutomaticallyABreach: [] };
let NORI_MEET_DISCIPLINARY_LADDER = {};
let NORI_MEET_PROPORTIONALITY_NOTE = "";

function noriDeriveRulesFromJSON() {
  NORI_MEET_BANDS = NORI_RULES_EXAM.bands.map(function (b) {
    return { id: b.id, min: b.range[0], max: b.range[1], label: b.label };
  });

  NORI_MEET_DEGREE_ACTIONS = {};
  Object.keys(NORI_RULES_EXAM.degrees).forEach(function (degKey) {
    const src = NORI_RULES_EXAM.degrees[degKey];
    const bands = {};
    Object.keys(src.bands).forEach(function (bandKey) { bands[bandKey] = src.bands[bandKey].actions; });
    NORI_MEET_DEGREE_ACTIONS[degKey] = { trigger: src.trigger, bands: bands };
  });

  NORI_MEET_MERIT_POINTS = NORI_RULES_AWARD.meritPoints.map(function (m) {
    return { min: m.resultRange[0], max: m.resultRange[1], points: m.points, perfect: !!m.note };
  });

  NORI_MEET_OVERRIDE_CATEGORIES = NORI_RULES_OVERRIDE.recognizedCircumstanceCategories.map(function (c) { return c.category; });
  NORI_MEET_OVERRIDE_LEVELS = NORI_RULES_OVERRIDE.prioritySeverityFormula.levels;

  NORI_MEET_DESTRUCTION_CATEGORIES = NORI_RULES_INTEGRITY.destructionCategories;
  NORI_MEET_BREACH_TEST = NORI_RULES_INTEGRITY.breachTest;
  NORI_MEET_PROPORTIONALITY_NOTE = NORI_RULES_INTEGRITY.proportionalityLaw;

  NORI_MEET_DISCIPLINARY_LADDER = {};
  Object.keys(NORI_RULES_INTEGRITY.escalationLadder).forEach(function (degKey) {
    const src = NORI_RULES_INTEGRITY.escalationLadder[degKey];
    NORI_MEET_DISCIPLINARY_LADDER[degKey] = { name: src.name, trigger: src.trigger, steps: src.steps, command: src.command };
  });
}

const NORI_RULES_BASE_URL = (typeof NORI_API_BASE_URL !== "undefined" ? NORI_API_BASE_URL : "").replace(/\/$/, "");
function noriRuleURL(file) { return NORI_RULES_BASE_URL ? NORI_RULES_BASE_URL + "/" + file : file; }

const NORI_RULES_READY = Promise.all([
  fetch(noriRuleURL("nori-exam-result-rules.json")).then(function (r) { if (!r.ok) throw new Error("Rules request failed: " + r.status); return r.json(); }),
  fetch(noriRuleURL("nori-award-rules.json")).then(function (r) { if (!r.ok) throw new Error("Rules request failed: " + r.status); return r.json(); }),
  fetch(noriRuleURL("nori-human-override-rules.json")).then(function (r) { if (!r.ok) throw new Error("Rules request failed: " + r.status); return r.json(); }),
  fetch(noriRuleURL("nori-system-integrity-rules.json")).then(function (r) { if (!r.ok) throw new Error("Rules request failed: " + r.status); return r.json(); })
]).then(function (results) {
  NORI_RULES_EXAM = results[0];
  NORI_RULES_AWARD = results[1];
  NORI_RULES_OVERRIDE = results[2];
  NORI_RULES_INTEGRITY = results[3];
  noriDeriveRulesFromJSON();
}).catch(function (err) {
  // Deliberately NOT falling back to a hardcoded duplicate here — that
  // would recreate the exact fragmentation this file exists to remove.
  // An explicit "rules failed to load" state (shown by whatever tried to
  // use them) is more honest than a silently stale second copy.
  console.error("Nori rules failed to load:", err.message);
  throw err;
});
