/* NORI V34.1 — OPERATIONAL FEATURE CENTER
 * One truthful capability/status surface. It does not create a second brain.
 * It exposes controls only where a real executor already exists or can be
 * exercised safely in the current platform.
 */
(function(g){'use strict';
  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const native=()=>!!(g.Capacitor&&g.Capacitor.isNativePlatform&&g.Capacitor.isNativePlatform());
  function capabilityStatus(){
    const blocker=!!g.noriBlockerAvailable?.();
    const visual=!!g.Capacitor?.Plugins?.NoriVisual;
    const voice=!!g.Capacitor?.Plugins?.NoriVoice || !!g.NORI_SPEECH_SUPPORTED || !!g.SpeechRecognition || !!g.webkitSpeechRecognition;
    const notifications=!!g.Capacitor?.Plugins?.LocalNotifications || 'Notification' in g;
    const livekit=!!g.NoriLiveKitV26;
    const knowledge=!!g.NoriKnowledgeHub;
    const selfImprove=!!g.NoriSelfImproveV26;
    const memory=!!g.NoriMemoryV26;
    const sat=!!g.NoriSAT;
    const language=!!g.NoriLanguageSpecialist;
    const world=!!g.NoriWorldWeb;
    return [
      ['Focus Mode',blocker?'OPERATIONAL':'CONDITIONAL',native?'Android native blocker is connected; permissions may still be required.':'Browser cannot block other apps.'],
      ['Voice',voice?'OPERATIONAL':'CONDITIONAL',native?'Uses the Nori Android voice bridge when available.':'Uses browser speech when supported.'],
      ['Camera / Visual Context',visual?'OPERATIONAL':'CONDITIONAL',native?'NoriVisual camera/screen bridge is installed.':'Browser visual capture requires an explicit browser media/file path.'],
      ['Reminders',notifications?'OPERATIONAL':'CONDITIONAL',native?'Native notifications are available when the notification provider is installed.':'Browser notifications require permission and an open/browser-supported context.'],
      ['Knowledge Hub',knowledge?'OPERATIONAL':'CONDITIONAL','Library controls are available when the native knowledge bridge is present.'],
      ['Live Voice',livekit?(g.NORI_LIVEKIT_TOKEN_URL?'CONDITIONAL':'CONFIGURATION REQUIRED'):'CONDITIONAL','LiveKit remains optional and requires its external token service.'],
      ['Self-Improvement',selfImprove?'OPERATIONAL':'CONDITIONAL','Protected-base workflow requires server plan/apply endpoints and human confirmation.'],
      ['Memory Governance',memory?'OPERATIONAL':'CONDITIONAL','Local memory controls are available; sensitive data remains governed separately.'],
      ['SAT Intelligence',sat?'OPERATIONAL':'CONDITIONAL','Diagnostic/planning engine is available through NoriSAT.'],
      ['Language Specialist',language?'OPERATIONAL':'CONDITIONAL','Language specialist is available through the specialist module.'],
      ['World / Research',world?'OPERATIONAL':'CONDITIONAL',native?'Native governed world-information bridge is available.':'Use explicit web research through the supported web path.']
    ].map(x=>({name:x[0],status:x[1],detail:x[2]}));
  }
  function panelFor(name,host){
    host.innerHTML='';
    if(name==='Voice' && g.NoriVoiceV28){g.NoriVoiceV28.installVoicePanel(host);return;}
    if(name==='Knowledge Hub' && g.NoriKnowledgeHub){g.NoriKnowledgeHub.mount();const h=document.getElementById('nori-knowledge-hub');if(h){host.appendChild(h.cloneNode(true));return;}}
    if(name==='Self-Improvement' && g.NoriSelfImproveLabV27?.mount){g.NoriSelfImproveLabV27.mount(host);return;}
    if(name==='Memory Governance' && g.NoriMemoryV26){host.innerHTML='<div class="nori-v341-detail"><b>MEMORY GOVERNANCE</b><p>'+g.NoriMemoryV26.list().length+' local memory items currently stored.</p><button data-memory-clear>OPEN MEMORY CONTROLS</button></div>';host.querySelector('button').onclick=()=>g.NoriMemoryV26.confirmClear();return;}
    if(name==='SAT Intelligence' && g.NoriSAT){host.innerHTML='<div class="nori-v341-detail"><b>SAT INTELLIGENCE</b><pre>'+esc(JSON.stringify(g.NoriSAT.blueprint(),null,2))+'</pre></div>';return;}
    if(name==='Language Specialist' && g.NoriLanguageSpecialist){host.innerHTML='<div class="nori-v341-detail"><b>LANGUAGE SPECIALIST</b><p>'+esc(JSON.stringify(g.NoriLanguageSpecialist.capabilities(),null,2))+'</p></div>';return;}
    if(name==='Focus Mode'){location.hash='#/focus';return;}
    if(name==='Privacy & Permissions'){host.innerHTML='<div class="nori-v341-detail"><b>PRIVACY & PERMISSIONS</b><p>Camera, microphone, files and administrator access remain explicit. Hidden recording and silent surveillance are not enabled.</p><pre>'+esc(JSON.stringify(g.NoriPrivacyV31?.rules?.()||{},null,2))+'</pre></div>';return;}
    if(name==='Interface'){host.innerHTML='<div class="nori-v341-detail"><b>INTERFACE</b><p>Choose an existing Nori interface mode without changing the visual system.</p><button data-mode="standard">STANDARD</button> <button data-mode="kage">KAGE</button> <button data-mode="circle">CIRCLE</button> <button data-mode="hybrid">HYBRID</button> <button data-mode="compact">COMPACT</button></div>';host.querySelectorAll('[data-mode]').forEach(b=>b.onclick=()=>g.NoriInterfaceMode?.set?.(b.dataset.mode));return;}
    if(name==='Reminders'){location.hash='#/alarms';return;}
    if(name==='Notifications'){location.hash='#/notifications';return;}
    if(name==='Data & Backup'){host.innerHTML='<div class="nori-v341-detail"><b>DATA & BACKUP</b><p>Use Nori\'s existing export path. No automatic cloud backup is claimed unless the signed-in sync layer confirms it.</p><button data-export>EXPORT DATA</button><div data-v341-output></div></div>';host.querySelector('[data-export]').onclick=async()=>{try{const r=await g.Capacitor?.Plugins?.NoriOperations?.exportData?.();host.querySelector('[data-v341-output]').textContent=JSON.stringify(r||{ok:false},null,2);}catch(e){host.querySelector('[data-v341-output]').textContent=e.message;}};return;}
    if(name==='Camera / Visual Context'){host.innerHTML='<div class="nori-v341-detail"><b>VISUAL CONTEXT</b><p>Visual capture remains explicit and foreground-only. Use the Visual/Camera control from the active Nori feature.</p><button data-visual-test>TEST CAMERA BRIDGE</button><div data-v341-output></div></div>';const b=host.querySelector('[data-visual-test]');b.onclick=async()=>{const p=g.Capacitor?.Plugins?.NoriVisual;try{if(!p)throw new Error('NoriVisual native bridge unavailable.');const r=await p.captureCamera();host.querySelector('[data-v341-output]').textContent=r?.ok?'Camera bridge returned an image.':'Camera capture returned no image.';}catch(e){host.querySelector('[data-v341-output]').textContent=e.message;}};return;}
    if(name==='World / Research'){host.innerHTML='<div class="nori-v341-detail"><b>WORLD / RESEARCH</b><p>Fresh world information remains user-initiated. Ask Nori for current news, weather, trends or a web search.</p><button>OPEN MEET NORI</button></div>';host.querySelector('button').onclick=()=>location.hash='#/meet-nori';return;}
    host.innerHTML='<div class="nori-v341-detail"><b>'+esc(name)+'</b><p>This feature is available through its existing specialist surface. No duplicate brain screen is created.</p></div>';
  }
  function render(root){if(!root||root.querySelector('[data-v341-feature-center]'))return;const sec=document.createElement('section');sec.className='nori-v34-section nori-v341-center';sec.dataset.v341FeatureCenter='';sec.innerHTML='<h3 class="nori-v34-section-title">OPERATIONAL FEATURES</h3><p class="nori-lede">Only real capabilities are marked operational. Conditional features show the dependency that still matters on this device or deployment.</p><div class="nori-v341-grid"></div><div class="nori-v341-detail-host"></div>';const grid=sec.querySelector('.nori-v341-grid'),host=sec.querySelector('.nori-v341-detail-host');capabilityStatus().forEach(c=>{const b=document.createElement('button');b.className='nori-v341-feature';b.innerHTML='<span><b>'+esc(c.name)+'</b><small>'+esc(c.detail)+'</small></span><em class="nori-v341-status '+c.status.replace(/\s+/g,'-').toLowerCase()+'">'+esc(c.status)+'</em>';b.onclick=()=>panelFor(c.name,host);grid.appendChild(b)});root.appendChild(sec);return sec;}
  g.NoriOperationalFeatureCenterV341={status:capabilityStatus,render,panelFor};
})(window);
