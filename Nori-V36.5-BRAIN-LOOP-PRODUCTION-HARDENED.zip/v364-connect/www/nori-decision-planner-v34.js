/* NORI V34 — DECISION + PLANNING COOPERATION
 * Decision is a planning layer, not a second brain.
 * It reads authoritative context, identifies the user's goal, scores academic
 * constraints, builds a plan, simulates complex work, and hands execution to V33.
 */
(function(g){'use strict';
 const VERSION='34';
 const uid=p=>(p||'v34')+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);
 const clone=x=>{try{return JSON.parse(JSON.stringify(x));}catch(_){return x;}};
 const SUBJECT_RE=/\b(math(?:ematics)?|english|chemistry|physics|biology|agriculture|web\s*design|it)\b/i;
 const TIME_RE=/\b(?:at|by|around|to)\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b/i;
 const CAP={assignment:'create_assignment',study:'create_study_session',calendar:'create_calendar_event',alarm:'schedule_alarm',focus:'focus_start',result:'record_result',navigate:'navigate'};
 const readCanonical=async()=>{
   try{
     const base=String(g.NORI_API_BASE_URL||''); if(!base)return {};
     const h={'Content-Type':'application/json'};
     if(g.NoriProductionAuth?.session){const s=(await g.NoriProductionAuth.session())?.data?.session;if(s?.access_token)h.Authorization='Bearer '+s.access_token;}
     const r=await fetch(base+'/api/brain',{method:'POST',headers:h,body:JSON.stringify({mode:'canonical_state'})});
     const j=await r.json(); if(!r.ok||!j.ok)return {};
     return j.context?.canonicalState?.state||{};
   }catch(_){return {};}
 };
 function arrays(state){const d=state?.appData||{};const pick=(...keys)=>{for(const k of keys)if(Array.isArray(d[k]))return d[k];return []};return {
   assignments:pick('nori_command_assignments','assignments'),
   study:pick('nori_study_sessions','studySessions'),
   calendar:pick('nori_calendar_events_v1','calendarEvents'),
   alarms:pick('nori_voice_alarms','alarms'),
   results:pick('nori_eval_history_all_subjects','results')
 };}
 function goal(text){const t=String(text||'').toLowerCase();
   if(/\b(cancel|stop)\b/.test(t)&&/\b(timer|stopwatch|watch|timing)\b/.test(t))return {kind:'time_stop'};
   if(/\b(start|begin|run|set|use)\b/.test(t)&&/\b(timer|countdown)\b/.test(t))return {kind:'timer'};
   if(/\b(start|begin|run)\b/.test(t)&&/\b(stopwatch|stop watch|math speed|speed test)\b/.test(t))return {kind:'math_speed'};
   if(/\b(cancel|stop)\b/.test(t))return {kind:'cancel'};
   if(/\b(open|show|take me|go to|navigate)\b/.test(t))return {kind:'navigate'};
   // Specific executable intents must win over the generic planning classifier.
   // Otherwise phrases such as "schedule a chemistry alarm" were incorrectly
   // classified as a generic plan.
   if(/\b(remind|alarm|wake|notify)\b/.test(t) && !/\b(prepare|organize|plan my|prepare my|schedule my)\b/.test(t))return {kind:'alarm'};
   if(/\b(create|add|schedule|plan|prepare|organize)\b/.test(t)&&/\b(schedule|plan|tomorrow|today)\b/.test(t))return {kind:'plan'};
   if(/\b(focus|concentrate|study now|start focus)\b/.test(t))return {kind:'focus'};
   if(/\b(result|score|mark|grade)\b/.test(t)&&/\b\d{1,3}(?:\.\d+)?\s*%?\b/.test(t))return {kind:'result'};
   if(/\b(move|reschedule|change)\b/.test(t)&&/\b(session|study)\b/.test(t))return {kind:'study_update'};
   if(/\b(create|add|schedule|plan|prepare|organize|set up)\b/.test(t)&&/\b(schedule|plan|tomorrow|today)\b/.test(t))return {kind:'plan'};
   if(/\b(assignment|homework|task)\b/.test(t))return {kind:'assignment'};
   if(/\b(study|session|revision|revise)\b/.test(t))return {kind:'study'};
   return {kind:'conversation'};
 }
 function priority(item,now){
   const due=item?.due||item?.date||item?.deadline; let urgency=0;
   if(due){const ms=new Date(String(due).length<=10?due+'T23:59:59':due).getTime()-now;const days=ms/86400000;urgency=days<0?100:days<=1?90:days<=3?70:days<=7?45:20;}
   const importance={high:90,medium:60,low:30}[String(item?.priority||'medium').toLowerCase()]||50;
   const consequence=item?.status==='overdue'?90:item?.status==='open'?60:20;
   const feasibility=item?.blocked?20:80;
   return Math.round(urgency*.35+importance*.30+consequence*.20+feasibility*.15);
 }
 function chooseAssignment(a,text){const subject=(text.match(SUBJECT_RE)||[])[0];const candidates=a.filter(x=>x.status!=='done');if(subject){const s=subject.toLowerCase();const hit=candidates.filter(x=>String(x.subject||'').toLowerCase().includes(s));if(hit.length)candidates.splice(0,candidates.length,...hit);}return candidates.sort((x,y)=>priority(y,Date.now())-priority(x,Date.now()))[0]||null;}
 function timeFrom(text){const m=text.match(TIME_RE);if(!m)return null;let h=Number(m[1]);const min=Number(m[2]||0),ap=(m[3]||'').toLowerCase();if(ap==='pm'&&h<12)h+=12;if(ap==='am'&&h===12)h=0;return String(h).padStart(2,'0')+':'+String(min).padStart(2,'0');}
 function tomorrow(){const d=new Date(Date.now()+86400000);return d.toISOString().slice(0,10);}
 function conflicts(study,calendar,date,time,duration=60){if(!time)return[];const start=new Date(date+'T'+time+':00').getTime();const end=start+duration*60000;return [...study,...calendar].filter(x=>{const ds=x.date||x.start?.slice?.(0,10);const ts=x.time||x.start?.slice?.(11,16);if(ds!==date||!ts)return false;const s=new Date(date+'T'+ts+':00').getTime(),e=s+(Number(x.duration||60)*60000);return s<end&&e>start;});}
 function planFor(text,state){
   const g0=goal(text), a=arrays(state), subject=(text.match(SUBJECT_RE)||[])[0]||null, time=timeFrom(text), date=/tomorrow/i.test(text)?tomorrow():new Date().toISOString().slice(0,10);
   if(g0.kind==='conversation'||g0.kind==='cancel')return {kind:g0.kind,executable:false,reason:g0.kind==='cancel'?'cancellation':'conversation'};
   if(g0.kind==='timer'){const m=text.match(/(\d+(?:\.\d+)?)\s*(seconds?|secs?|minutes?|mins?|hours?|hrs?)/i);let seconds=m?Number(m[1]):25;const u=m?m[2].toLowerCase():'minutes';if(/hour|hr/.test(u))seconds*=3600;else if(/minute|min/.test(u))seconds*=60;return {kind:g0.kind,executable:true,complex:false,goal:text,actions:[{type:'start_timer',seconds:Math.max(1,Math.round(seconds)),label:'Nori timer'}],requiresConfirmation:false};}
   if(g0.kind==='math_speed'){const m=text.match(/(\d+)\s*(?:problems?|questions?|items?)/i);return {kind:g0.kind,executable:true,complex:false,goal:text,actions:[{type:'start_math_stopwatch',problemCount:m?Number(m[1]):10,subject:'Mathematics'}],requiresConfirmation:false};}
   if(g0.kind==='time_stop')return {kind:g0.kind,executable:true,complex:false,goal:text,actions:[{type:/stopwatch|watch|timing/i.test(text)?'stop_math_stopwatch':'stop_timer'}],requiresConfirmation:false};
   if(g0.kind==='study_update'){const existing=chooseAssignment(a.study,text);const conflict=conflicts(a.study,a.calendar,date,time,Number(existing?.duration||60));return {kind:g0.kind,executable:!!existing&&!!time,complex:true,goal:text,subject,existing,conflicts:conflict,actions:existing&&time?[{type:'update_study_session',id:existing.id,date,time,subject:existing.subject,title:existing.title,duration:existing.duration||60}]:[],requiresConfirmation:true};}
   if(g0.kind==='plan'){
     const top=chooseAssignment(a.assignments,text);const actions=[];
     if(top&&/assignment|homework|task/i.test(text))actions.push({type:'update_assignment',id:top.id,priority:top.priority||'medium'});
     if(subject||/study|chemistry|biology|physics|math/i.test(text)){actions.push({type:'create_study_session',subject:subject||'General Study',date,time:time||'19:00',duration:60,title:(subject||'Study')+' session'});}
     if(/remind|alarm/i.test(text))actions.push({type:'schedule_alarm',label:(subject||'Study')+' reminder',date,time:time||'19:00',repeat:'none'});
     return {kind:'plan',executable:actions.length>0,complex:true,goal:text,actions,conflicts:actions.filter(x=>x.date&&x.time).flatMap(x=>conflicts(a.study,a.calendar,x.date,x.time,x.duration||60)),requiresConfirmation:true,contextSummary:{openAssignments:a.assignments.filter(x=>x.status!=='done').length,studySessions:a.study.length,calendarEvents:a.calendar.length}};
   }
   if(g0.kind==='alarm')return {kind:'alarm',executable:!!time,complex:false,goal:text,actions:time?[{type:'schedule_alarm',label:subject?subject+' study reminder':'Nori reminder',date,time,repeat:'none'}]:[],requiresConfirmation:true};
   if(g0.kind==='focus')return {kind:'focus',executable:true,complex:false,goal:text,actions:[{type:'focus_start'}],requiresConfirmation:true};
   if(g0.kind==='result'){const m=text.match(/(\d{1,3}(?:\.\d+)?)\s*%?/);return {kind:'result',executable:!!m&&!!subject,complex:false,goal:text,actions:m&&subject?[{type:'record_result',subject,score:Number(m[1]),date}]:[],requiresConfirmation:true};}
   if(g0.kind==='assignment')return {kind:'assignment',executable:true,complex:false,goal:text,actions:[{type:'create_assignment',title:text.replace(/^(add|create|schedule)\s+(an?\s+)?/i,'').trim(),subject:subject||'General',status:'open'}],requiresConfirmation:true};
   if(g0.kind==='study')return {kind:'study',executable:!!subject,complex:false,goal:text,actions:subject?[{type:'create_study_session',subject,date,time:time||'19:00',duration:60,title:subject+' study'}]:[],requiresConfirmation:true};
   if(g0.kind==='navigate')return {kind:'navigate',executable:true,complex:false,goal:text,actions:[{type:'navigate',goal:text}],requiresConfirmation:false};
   return {kind:g0.kind,executable:false,reason:'no_safe_plan'};
 }
 async function decide(text,opts){const state=await readCanonical();const p=planFor(text,state);const decision={id:uid('decision'),version:VERSION,goal:String(text||''),kind:p.kind,executable:p.executable,complex:!!p.complex,plan:p,contextVersion:state?.stateVersion||null,createdAt:new Date().toISOString()};try{g.NoriOperatingProtocolV32?.emit('decision.created',decision,{source:'decision-v34'});}catch(_){}return decision;}
 async function handleText(text,opts){const d=await decide(text,opts);if(!d.executable)return {ok:true,status:d.kind==='cancel'?'cancelled':'conversation',decision:d};if(d.plan.kind==='navigate'){const route=g.NoriNavigationBrain?.routeFor?.(text);if(route==='#__back__')return {ok:true,status:'navigated_back',decision:d};if(route){g.NoriNavigationBrain.go(route);return {ok:true,status:'navigated',route,decision:d};}return {ok:true,status:'navigation_needs_clarification',decision:d};}if(d.plan.conflicts?.length){d.plan.blocked=true;d.plan.blockReason='CONFLICT';return {ok:true,status:'plan_conflict',decision:d};}if(d.plan.actions?.length===1&&!d.plan.complex&&g.NoriOperativeV33)return Object.assign(await g.NoriOperativeV33.execute(d.plan.actions[0].type,d.plan.actions[0],{source:'decision-v34',text,sessionId:opts?.sessionId||'default',confirmed:false}),{decision:d});if(g.NoriOperativeV33)return Object.assign(await g.NoriOperativeV33.executeWorkflow(d.plan.actions,{source:'decision-v34',sessionId:opts?.sessionId||'default',confirmed:false}),{decision:d});return {ok:false,status:'executor_unavailable',decision:d};}
 g.NoriDecisionPlannerV34={version:VERSION,decide,planFor,handleText,priority,readCanonical};
})(window);
