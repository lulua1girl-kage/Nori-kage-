/* Step 47 production auth/admission client. It never decides admin status locally. */
(function(){'use strict';
  const C=()=>window.NORI_PRODUCTION_CONFIG||{};
  function client(){return window.NoriSyncAuth&&window.NoriSyncAuth.supabaseClient?window.NoriSyncAuth.supabaseClient():null;}
  async function session(){const c=client();return c?c.auth.getSession():{data:{session:null}};}
  async function primaryVerified(){const s=(await session()).data.session;return !!(s&&s.user&&s.user.email_confirmed_at);}
  async function admission(){if(!window.NoriSyncAuth)return null;try{return await window.NoriSyncAuth.profile();}catch(e){return null;}}
  async function canEnter(){const s=(await session()).data.session;if(!s)return {ok:false,reason:'SIGN_IN_REQUIRED'};if(!(await primaryVerified()))return {ok:false,reason:'EMAIL_VERIFICATION_REQUIRED'};const p=await admission();if(!p||p.admission_status!=='APPROVED')return {ok:false,reason:'ADMISSION_REQUIRED'};return {ok:true,userId:s.user.id,role:p.role||'STUDENT'};}
  async function adminStart(){const s=(await session()).data.session;if(!s)return {ok:false,reason:'SIGN_IN_REQUIRED'};return call('start',{});}
  async function adminPin(pin){return call('verify_pin',{pin:String(pin)});}
  async function call(action,body){const s=(await session()).data.session;if(!s)throw new Error('SIGN_IN_REQUIRED');const r=await fetch(`${C().supabaseUrl}${C().adminVerifyFunction}`,{method:'POST',headers:{Authorization:`Bearer ${s.access_token}`,'Content-Type':'application/json'},body:JSON.stringify({action,...body})});const j=await r.json();if(!r.ok)throw new Error(j.error||'verification_failed');return j;}
  window.NoriProductionAuth={session,primaryVerified,admission,canEnter,adminStart,adminPin};
})();
