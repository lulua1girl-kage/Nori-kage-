/* NORI AI PROVIDER STATUS V25 — no API keys are stored here. */
(function(g){"use strict";
  function request(){return fetch("api/brain.js",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({mode:"provider_status"})}).then(function(r){return r.json();});}
  function summarize(data){var ps=(data&&data.providers)||[];return {configured:ps.filter(function(p){return p.configured;}).map(function(p){return p.provider;}),usable:ps.filter(function(p){return p.usable;}).map(function(p){return p.provider;}),cooling:ps.filter(function(p){return p.configured&&!p.usable;}).map(function(p){return p.provider;})};}
  g.NoriAIProviderV25={status:request,summarize:summarize,version:"26"};
})(window);
