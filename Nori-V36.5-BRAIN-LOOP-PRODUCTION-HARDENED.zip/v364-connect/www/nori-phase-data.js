/* ==========================================================================
   NORI PHASE — DATA SCHEMA
   ==========================================================================
   Single source of truth for the whole app.
   Hierarchy: NORI PHASE -> PHASE -> SYSTEM -> FORM (PDF page)

   Every field below was taken directly from the source PDFs. Nothing here
   is invented — labels, column order, and fixed rows match the PDF pages.

   Two form "kinds":
   - "table-log"    : you add one row at a time, rows build up in a table.
                       (Assessment trackers, error record, improvement log.)
   - "snapshot-log"  : you fill one whole page per instance (per day / week /
                       month / period), each saved instance becomes a dated
                       entry you can look back at.
                       (Master Scoreboard, Daily Audit, Weekly Review, etc.)
   ========================================================================== */

const NORI_SUBJECTS = [
  "Mathematics", "Physics", "Chemistry", "Biology",
  "English", "Agriculture", "Web / IT"
];

// shared column helper: Gap = Result/Score minus Target
function noriGapFromPercent(resultKey, targetKey) {
  return function (row) {
    const r = parseFloat(row[resultKey]);
    const t = parseFloat(row[targetKey]);
    if (isNaN(r) || isNaN(t)) return "";
    const g = Math.round((r - t) * 10) / 10;
    return (g > 0 ? "+" : "") + g;
  };
}

const NORI_STATUS_OPTIONS = ["On track", "Needs attention", "Recovery"];

/* -------------------------------------------------------------------------
   SYSTEM A — "Master Scoreboard System"
   Source: Phase 1 • Printable Control Pages (8 pages)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_MASTER_SCOREBOARD = {
  id: "master-scoreboard-system",
  title: "Master Scoreboard System",
  subtitle: "The central control system for Phase 1 — 8 pages",
  forms: [
    {
      id: "master-scoreboard",
      title: "Master Scoreboard",
      subtitle: "The central control page for the entire Phase 1 system.",
      kind: "snapshot-log",
      fields: [
        { key: "period", label: "Identity / Period", type: "text" }
      ],
      fixedTable: {
        rowLabel: "Category",
        rows: [
          "Overall Discipline", "Academic Progress", "Consistency",
          "Responsibility", "Focus / Distraction Control", "System Completion"
        ],
        columns: [
          { key: "target", label: "Target / Standard", type: "text" },
          { key: "score", label: "Current Score", type: "select", options: ["A", "B", "C", "D"] },
          { key: "status", label: "Status", type: "select", options: ["A", "B", "C", "D"] }
        ]
      },
      referenceTable: {
        title: "Score Legend",
        columns: ["Level", "Meaning", "Action"],
        rows: [
          ["A", "Strong / consistently maintained", "Maintain"],
          ["B", "Good, but needs attention", "Correct early"],
          ["C", "Unstable / repeated misses", "Apply agreed consequence"],
          ["D", "Serious breakdown", "Reset, review, and escalate within the system"]
        ]
      },
      freeText: [
        { key: "priority", label: "Current Priority — What must improve next?" },
        { key: "notes", label: "Master Notes / Decisions" }
      ]
    },
    {
      id: "assessment-master-tracker",
      title: "Assessment Master Tracker",
      subtitle: "Record assignments, tests, exams, projects, and other major academic checkpoints.",
      kind: "table-log",
      columns: [
        { key: "subject", label: "Subject / Area", type: "text" },
        { key: "assessment", label: "Assessment", type: "text" },
        { key: "date", label: "Date", type: "date" },
        { key: "target", label: "Target", type: "number" },
        { key: "result", label: "Result", type: "number" },
        { key: "gap", label: "Gap", type: "computed", computed: noriGapFromPercent("result", "target") },
        { key: "followup", label: "Follow-up", type: "text" }
      ],
      pageNotes: [
        { key: "patterns", label: "Patterns I Notice" },
        { key: "priorities", label: "Next Assessment Priorities" }
      ]
    },
    {
      id: "detailed-assessment-record",
      title: "Detailed Assessment Record",
      subtitle: "Use one record for an important assessment. Record facts, causes, corrections, and the next action.",
      kind: "snapshot-log",
      fields: [
        { key: "subject", label: "Subject / Area", type: "text" },
        { key: "assessment", label: "Assessment / Assignment", type: "text" },
        { key: "date", label: "Date", type: "date" },
        { key: "target", label: "Target", type: "number" },
        { key: "result", label: "Actual Result", type: "number" },
        { key: "gap", label: "Difference / Gap", type: "computed", computed: noriGapFromPercent("result", "target") },
        { key: "prepared", label: "What was prepared well?", type: "textarea" },
        { key: "missed", label: "What was missed?", type: "textarea" },
        { key: "obstacles", label: "Main obstacle(s)", type: "textarea" },
        { key: "correction", label: "Correction for next time", type: "textarea" },
        { key: "nextAction", label: "Next action + deadline", type: "text" },
        { key: "lesson", label: "Lesson From This Assessment", type: "textarea" }
      ]
    },
    {
      id: "daily-audit",
      title: "Daily Audit",
      subtitle: "A short end-of-day audit. The goal is accurate feedback, not self-criticism.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Check",
        rows: [
          "I completed the planned academic priorities.",
          "I followed the study / work sequence.",
          "I controlled major distractions.",
          "I recorded unfinished work honestly.",
          "I corrected at least one mistake or weakness.",
          "I prepared the next day's priorities."
        ],
        columns: [
          { key: "yesno", label: "Yes / No", type: "select", options: ["Yes", "No"] },
          { key: "notes", label: "Notes", type: "text" }
        ]
      },
      fields: [
        { key: "dailyScore", label: "Daily Score", type: "text" },
        { key: "worked", label: "What worked?", type: "text" },
        { key: "failed", label: "What failed?", type: "text" },
        { key: "tomorrow", label: "Tomorrow's first priority", type: "text" }
      ],
      freeText: [
        { key: "obstacleLog", label: "Obstacle / Downer Log — What made progress harder today?" },
        { key: "smallWin", label: "Small Win — What did I handle better today?" }
      ]
    },
    {
      id: "weekly-review",
      title: "Weekly Review",
      subtitle: "Review the week as a system: evidence first, judgment second.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Area",
        rows: [
          "Academic work", "Assignments / deadlines", "Assessment preparation",
          "Distraction control", "Consistency", "Other responsibility"
        ],
        columns: [
          { key: "target", label: "Target", type: "text" },
          { key: "actual", label: "Actual", type: "text" },
          { key: "score", label: "Score / Grade", type: "text" },
          { key: "correction", label: "Correction", type: "text" }
        ]
      },
      freeText: [
        { key: "wins", label: "3 Biggest Wins" },
        { key: "problems", label: "3 Biggest Problems" },
        { key: "priorities", label: "Next Week's Top 3 Priorities" }
      ]
    },
    {
      id: "monthly-review",
      title: "Monthly Review",
      subtitle: "Identify trends rather than isolated good or bad days.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Area",
        rows: [
          "Academic progress", "Assessments", "Consistency",
          "Distraction control", "Personal responsibility", "System adherence"
        ],
        columns: [
          { key: "target", label: "Month Target", type: "text" },
          { key: "evidence", label: "Evidence / Result", type: "text" },
          { key: "trend", label: "Trend", type: "select", options: ["Up", "Down", "Flat"] },
          { key: "adjustment", label: "Next Adjustment", type: "text" }
        ]
      },
      freeText: [
        { key: "obstacles", label: "Repeated Obstacles / Downers" },
        { key: "improved", label: "What Improved?" },
        { key: "systemChange", label: "One System Change For Next Month" }
      ]
    },
    {
      id: "semester-review",
      title: "Semester Review",
      subtitle: "Compare the semester's actual pattern with the standards you set.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Subject / Area",
        rows: NORI_SUBJECTS,
        columns: [
          { key: "start", label: "Starting Point", type: "text" },
          { key: "result", label: "Semester Result", type: "text" },
          { key: "change", label: "Major Change", type: "text" },
          { key: "nextGoal", label: "Next Goal", type: "text" }
        ]
      },
      fixedTable2: {
        title: "System Area",
        rowLabel: "System Area",
        rows: ["Planning", "Execution", "Distraction control", "Assessment preparation", "Review / correction"],
        columns: [
          { key: "strongest", label: "Strongest Point", type: "text" },
          { key: "weakest", label: "Weakest Point", type: "text" },
          { key: "decision", label: "Decision", type: "text" }
        ]
      },
      freeText: [
        { key: "lesson", label: "Semester Lesson — What should I keep, change, or remove?" }
      ]
    },
    {
      id: "year-end-review",
      title: "Year-End Review",
      subtitle: "The final control page of Phase 1. Turn the year's evidence into the next year's design.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Category",
        rows: [
          "Academic progress", "Discipline / consistency", "Distraction control",
          "Assessments", "Personal responsibility", "Overall system"
        ],
        columns: [
          { key: "result", label: "Year Result", type: "text" },
          { key: "best", label: "Best Period", type: "text" },
          { key: "hardest", label: "Hardest Period", type: "text" },
          { key: "learned", label: "What I Learned", type: "text" }
        ]
      },
      freeText: [
        { key: "obstaclesLessons", label: "Obstacles That Became Lessons" },
        { key: "achievements", label: "Achievements Worth Carrying Forward" },
        { key: "nextYear", label: "Next Year: Keep / Change / Remove" }
      ]
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM B — "Control Pages System"
   Source: Phase 1 Supplement — Missing Control Pages (13 pages)
   ------------------------------------------------------------------------- */

// build the 7 per-subject assessment record pages without repeating code
const NORI_SUBJECT_UNIT_LABEL = {
  "Mathematics": "Topic / unit", "Physics": "Topic / unit", "Chemistry": "Topic / unit",
  "Biology": "Topic / unit", "English": "Skill / unit", "Agriculture": "Topic / unit",
  "Web / IT": "Skill / project"
};

const NORI_SUBJECT_FORMS = NORI_SUBJECTS.map(function (subject) {
  return {
    id: "assessment-record-" + subject.toLowerCase().replace(/[\s/]+/g, "-"),
    title: subject.toUpperCase() + " ASSESSMENT RECORD",
    subtitle: "Assessment / task \u2014 Date \u2014 Marks \u2014 Score % \u2014 Target \u2014 Gap \u2014 " + NORI_SUBJECT_UNIT_LABEL[subject] + " \u2014 Status",
    kind: "table-log",
    columns: [
      { key: "task", label: "Assessment / task", type: "text" },
      { key: "date", label: "Date", type: "date" },
      { key: "marks", label: "Marks", type: "text" },
      { key: "score", label: "Score %", type: "number" },
      { key: "target", label: "Target", type: "number" },
      { key: "gap", label: "Gap", type: "computed", computed: noriGapFromPercent("score", "target") },
      { key: "unit", label: NORI_SUBJECT_UNIT_LABEL[subject], type: "text" },
      { key: "status", label: "Status", type: "select", options: NORI_STATUS_OPTIONS }
    ]
  };
});

const NORI_SYSTEM_CONTROL_PAGES = {
  id: "control-pages-system",
  title: "Control Pages System",
  subtitle: "Supplement to the Phase 1 printable control system — 13 pages",
  forms: [
    {
      id: "progress-performance-overview",
      title: "Progress / Performance Overview",
      subtitle: "Page 1 of the Control Pages supplement",
      kind: "snapshot-log",
      fields: [
        { key: "period", label: "Period", type: "text" },
        { key: "overall", label: "Overall %", type: "number" },
        { key: "target", label: "Target %", type: "number" },
        { key: "gap", label: "Gap", type: "computed", computed: noriGapFromPercent("overall", "target") },
        { key: "trend", label: "Trend", type: "select", options: ["Up", "Down", "Flat"] },
        { key: "strength", label: "Main strength", type: "text" },
        { key: "weakness", label: "Main weakness", type: "text" }
      ]
    },
    {
      id: "subject-performance-record",
      title: "Subject Performance Record",
      subtitle: "One row per subject",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Subject",
        rows: NORI_SUBJECTS,
        columns: [
          { key: "count", label: "Assessment count", type: "number" },
          { key: "avg", label: "Average %", type: "number" },
          { key: "best", label: "Best %", type: "number" },
          { key: "lowest", label: "Lowest %", type: "number" },
          { key: "target", label: "Target %", type: "number" },
          { key: "gap", label: "Gap", type: "computed", computed: noriGapFromPercent("avg", "target") },
          { key: "status", label: "Status", type: "select", options: NORI_STATUS_OPTIONS }
        ]
      }
    },
    // the 7 subject assessment record pages, spread in here
    ...NORI_SUBJECT_FORMS,
    {
      id: "assessment-error-record",
      title: "Assessment Error Record",
      subtitle: "Date \u2014 Subject \u2014 Assessment \u2014 Question/task \u2014 Error type \u2014 Cause \u2014 Corrective action \u2014 Verified",
      kind: "table-log",
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "subject", label: "Subject", type: "text" },
        { key: "assessment", label: "Assessment", type: "text" },
        { key: "question", label: "Question / task", type: "text" },
        { key: "errorType", label: "Error type", type: "text" },
        { key: "cause", label: "Cause", type: "text" },
        { key: "action", label: "Corrective action", type: "text" },
        { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] }
      ]
    },
    {
      id: "improvement-tracking",
      title: "Improvement Tracking",
      subtitle: "Area/weakness \u2014 Starting level \u2014 Target \u2014 Action \u2014 Checkpoint \u2014 Current level \u2014 Evidence \u2014 Status",
      kind: "table-log",
      columns: [
        { key: "area", label: "Area / weakness", type: "text" },
        { key: "starting", label: "Starting level", type: "text" },
        { key: "target", label: "Target", type: "text" },
        { key: "action", label: "Action", type: "text" },
        { key: "checkpoint", label: "Checkpoint", type: "text" },
        { key: "current", label: "Current level", type: "text" },
        { key: "evidence", label: "Evidence", type: "text" },
        { key: "status", label: "Status", type: "select", options: NORI_STATUS_OPTIONS }
      ]
    },
    {
      id: "academic-performance-summary",
      title: "Academic Performance Summary",
      subtitle: "One row per subject, plus the overall figures",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Subject",
        rows: NORI_SUBJECTS,
        columns: [
          { key: "current", label: "Current %", type: "number" },
          { key: "target", label: "Target %", type: "number" },
          { key: "change", label: "Change", type: "text" },
          { key: "best", label: "Best result", type: "text" },
          { key: "weakness", label: "Main weakness", type: "text" },
          { key: "nextAction", label: "Next action", type: "text" }
        ]
      },
      fields: [
        { key: "overallAvg", label: "Overall average", type: "number" },
        { key: "overallTarget", label: "Target", type: "number" },
        { key: "overallGap", label: "Gap", type: "computed", computed: noriGapFromPercent("overallAvg", "overallTarget") }
      ]
    },
    {
      id: "phase1-control-review",
      title: "Phase 1 Control Review",
      subtitle: "Final page of the Control Pages supplement",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Review question",
        rows: [
          "Are assessments being recorded consistently?",
          "Which subject is currently weakest?",
          "Which subject improved most?",
          "What assessment pattern needs attention?",
          "Are errors being transferred into correction work?",
          "Is the 80% academic floor being maintained?",
          "What is the next highest-priority academic action?"
        ],
        columns: [
          { key: "evidence", label: "Evidence / Answer", type: "text" }
        ]
      },
      fields: [
        {
          key: "decision", label: "Control Decision", type: "select",
          options: ["Continue normal control", "Increase monitoring", "Activate recovery", "Other"]
        },
        { key: "decisionRecord", label: "Decision Record", type: "text" }
      ]
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM C — "Academic Systems"
   Source: Phase 2 • Academic Systems (9 pages)
   ------------------------------------------------------------------------- */

const NORI_MASTERY_SUBJECTS = [
  "Mathematics", "Physics", "Chemistry", "Biology",
  "English", "Agriculture", "Web Development", "IT"
];

const NORI_MASTERY_FORMS = NORI_MASTERY_SUBJECTS.map(function (subject) {
  return {
    id: "mastery-" + subject.toLowerCase().replace(/[\s/]+/g, "-"),
    title: subject.toUpperCase() + " MASTERY",
    subtitle: "Baseline \u2192 learning \u2192 practice \u2192 correction \u2192 verification.",
    kind: "snapshot-log",
    fixedTable: {
      rowLabel: "Area",
      rows: [
        "Topics / concepts", "Understanding / application", "Accuracy",
        "Practice / fluency", "Assessment readiness"
      ],
      columns: [
        { key: "baseline", label: "Baseline", type: "text" },
        { key: "target", label: "Target", type: "text" },
        { key: "current", label: "Current", type: "text" },
        { key: "status", label: "Status", type: "select", options: NORI_STATUS_OPTIONS }
      ]
    },
    subLog: {
      key: "practice",
      title: "Topic / Skill Practice Log",
      columns: [
        { key: "topic", label: "Topic / Skill", type: "text" },
        { key: "practice", label: "Practice", type: "text" },
        { key: "errors", label: "Errors", type: "text" },
        { key: "correction", label: "Correction", type: "text" },
        { key: "masteryCheck", label: "Mastery Check", type: "select", options: ["Passed", "Not yet"] }
      ]
    },
    freeText: [
      { key: "weakAreas", label: "Weak Areas To Attack Next" },
      { key: "mastered", label: "Mastered / Verified" }
    ]
  };
});

const NORI_SYSTEM_ACADEMIC_SYSTEMS = {
  id: "academic-systems",
  title: "Academic Systems",
  subtitle: "Error notebook + per-subject mastery tracking \u2014 9 pages",
  forms: [
    {
      id: "error-notebook-system",
      title: "Error Notebook System",
      subtitle: "Central mistake-correction record for every subject.",
      kind: "table-log",
      columns: [
        { key: "subject", label: "Subject", type: "text" },
        { key: "topic", label: "Topic", type: "text" },
        { key: "error", label: "My Error", type: "text" },
        { key: "method", label: "Correct Method", type: "text" },
        { key: "cause", label: "Cause", type: "text" },
        { key: "recheck", label: "Recheck", type: "text" }
      ],
      pageNotes: [
        { key: "patterns", label: "Repeated Error Patterns" },
        { key: "rules", label: "Rules / Methods To Remember" }
      ]
    },
    ...NORI_MASTERY_FORMS
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM D — "Error Correction System"
   Source: Phase 2 — The Second (7 pages)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_ERROR_CORRECTION = {
  id: "error-correction-system",
  title: "Error Correction System",
  subtitle: "Supplement \u2014 turns mistakes into a repeatable correction loop \u2014 7 pages",
  forms: [
    {
      id: "academic-systems-introduction",
      title: "Academic Systems Introduction",
      subtitle: "Phase 2 converts academic mistakes and weak areas into a repeatable correction system. The core loop is: identify \u2192 classify \u2192 correct \u2192 verify \u2192 monitor.",
      kind: "reference",
      referenceTable: {
        title: "System Components",
        columns: ["System component", "Purpose"],
        rows: [
          ["Error Notebook System", "Capture meaningful mistakes rather than letting them disappear."],
          ["Error Classification & Root Cause", "Identify what kind of error occurred and why."],
          ["Error Correction Record", "Document the correction and the method used to prevent repetition."],
          ["Error Verification", "Confirm that the corrected skill or concept actually holds."],
          ["Cross-Subject Weakness Tracker", "Identify patterns that appear across more than one subject."],
          ["Phase 2 Academic Review", "Review whether the academic correction system is working."]
        ]
      }
    },
    {
      id: "error-notebook-control-sheet",
      title: "Error Notebook System",
      subtitle: "Use this page as the control sheet for the error notebook. Individual errors should be transferred into the detailed correction pages.",
      kind: "snapshot-log",
      fields: [
        { key: "section", label: "Notebook / section", type: "text" },
        { key: "purpose", label: "Primary purpose", type: "text" },
        { key: "subjectsMonitored", label: "Subjects currently monitored", type: "text" },
        { key: "recurringError", label: "Main recurring error type", type: "text" },
        { key: "priorityWeakness", label: "Current highest-priority weakness", type: "text" },
        { key: "reviewFrequency", label: "Review frequency", type: "text" },
        { key: "lastReview", label: "Last review date", type: "date" },
        { key: "nextReview", label: "Next review date", type: "date" }
      ]
    },
    {
      id: "error-classification-root-cause",
      title: "Error Classification & Root Cause",
      subtitle: "Date \u2014 Subject \u2014 Error/task \u2014 Error class \u2014 Root cause \u2014 Evidence \u2014 Priority",
      kind: "table-log",
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "subject", label: "Subject", type: "text" },
        { key: "errorTask", label: "Error / task", type: "text" },
        { key: "errorClass", label: "Error class", type: "text" },
        { key: "rootCause", label: "Root cause", type: "text" },
        { key: "evidence", label: "Evidence", type: "text" },
        { key: "priority", label: "Priority", type: "text" }
      ]
    },
    {
      id: "error-correction-record",
      title: "Error Correction Record",
      subtitle: "Date \u2014 Subject \u2014 Error \u2014 Correct method \u2014 Correction completed \u2014 Retest/evidence \u2014 Verified",
      kind: "table-log",
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "subject", label: "Subject", type: "text" },
        { key: "error", label: "Error", type: "text" },
        { key: "method", label: "Correct method", type: "text" },
        { key: "completed", label: "Correction completed", type: "text" },
        { key: "retest", label: "Retest / evidence", type: "text" },
        { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] }
      ]
    },
    {
      id: "error-verification",
      title: "Error Verification",
      subtitle: "Error/skill \u2014 Original result \u2014 Correction \u2014 Verification method \u2014 New result \u2014 Passed? \u2014 Date",
      kind: "table-log",
      columns: [
        { key: "errorSkill", label: "Error / skill", type: "text" },
        { key: "original", label: "Original result", type: "text" },
        { key: "correction", label: "Correction", type: "text" },
        { key: "method", label: "Verification method", type: "text" },
        { key: "newResult", label: "New result", type: "text" },
        { key: "passed", label: "Passed?", type: "select", options: ["Yes", "No"] },
        { key: "date", label: "Date", type: "date" }
      ]
    },
    {
      id: "cross-subject-weakness-tracker",
      title: "Cross-Subject Weakness Tracker",
      subtitle: "Use this page to detect weaknesses that are not isolated to one subject \u2014 for example, reading accuracy, calculation, interpretation, recall, or careless execution.",
      kind: "table-log",
      columns: [
        { key: "weakness", label: "Weakness / pattern", type: "text" }
      ].concat(NORI_SUBJECTS.map(function (s) {
        return { key: "subj_" + s.toLowerCase().replace(/[\s/]+/g, "-"), label: s, type: "select", options: ["Yes"] };
      })).concat([
        { key: "priority", label: "Priority", type: "text" }
      ])
    },
    {
      id: "phase2-academic-review",
      title: "Phase 2 Academic Review",
      subtitle: "Final page of the Error Correction System",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Review question",
        rows: [
          "What error type appeared most often?",
          "Which weakness affected multiple subjects?",
          "Which corrections were successfully verified?",
          "Which errors returned after correction?",
          "What subject currently needs the most correction work?",
          "Is the error system producing measurable improvement?",
          "What is the next highest-priority correction?"
        ],
        columns: [
          { key: "evidence", label: "Evidence / answer", type: "text" }
        ]
      },
      fields: [
        {
          key: "decision", label: "Phase 2 Decision", type: "select",
          options: ["Continue normal academic correction", "Increase error monitoring", "Assign additional verification", "Move priority weakness into recovery"]
        },
        { key: "decisionRecord", label: "Decision Record", type: "text" }
      ]
    }
  ]
};

/* -------------------------------------------------------------------------
   PHASE 3 — "EXAM COMMAND"
   Source: Phase 3 — Exam Command (29 distinct pages, grouped here into
   5 systems that mirror the PDF's own internal groupings: core scoreboard,
   the 12 individual model reports, error analysis, entrance prep, review.
   ------------------------------------------------------------------------- */

const NORI_EXAM_SUBJECTS = ["Mathematics", "Physics", "Chemistry", "Biology", "English", "Agriculture"];
const NORI_ERROR_TYPES = ["Knowledge gap", "Misread", "Calculation", "Careless", "Time pressure", "Guess", "Forgotten fact", "Strategy", "Other"];

/* System 1 — Exam Command Core (intro + 12-model scoreboard + final review) */

function noriBuildScoreboardBlock(modelRange) {
  return {
    id: "master-scoreboard-models-" + modelRange[0] + "-" + modelRange[modelRange.length - 1],
    title: "12-Model Master Scoreboard \u2014 Models " + modelRange[0] + "\u2013" + modelRange[modelRange.length - 1],
    subtitle: "Score, time, and trend for each model exam in this range.",
    kind: "snapshot-log",
    fixedTable: {
      rowLabel: "Model",
      rows: modelRange.map(function (n) { return "Model " + n; }),
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "score", label: "Score %", type: "number" },
        { key: "time", label: "Time", type: "text" },
        { key: "target", label: "Target", type: "number" },
        { key: "gap", label: "Gap", type: "computed", computed: noriGapFromPercent("score", "target") },
        { key: "trend", label: "Trend", type: "select", options: ["Up", "Down", "Flat"] },
        { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] }
      ]
    },
    fixedTable2: {
      title: "Subject \u00d7 Model Grid",
      rowLabel: "Subject",
      rows: NORI_EXAM_SUBJECTS,
      columns: modelRange.map(function (n) { return { key: "m" + n, label: "M" + n, type: "text" }; })
        .concat([
          { key: "strongest", label: "Strongest", type: "text" },
          { key: "weakest", label: "Weakest", type: "text" }
        ])
    }
  };
}

const NORI_SYSTEM_EXAM_CORE = {
  id: "exam-command-core",
  title: "Exam Command Core",
  subtitle: "Rules, the 12-model scoreboard, and the final review \u2014 4 pages",
  forms: [
    {
      id: "phase3-exam-command-intro",
      title: "Phase 3 \u2014 Exam Command",
      subtitle: "Purpose: record every exam, diagnose lost marks, repair weaknesses, and verify improvement.",
      kind: "reference",
      referenceTable: {
        title: "Command Rules",
        columns: ["Command", "Rule"],
        rows: [
          ["Record", "Every model exam gets a complete record."],
          ["Diagnose", "Classify wrong answers by cause."],
          ["Repair", "Turn weaknesses into specific actions."],
          ["Verify", "Retest before closing a weakness."],
          ["Progress", "Compare performance across 12 models."],
          ["Escalate", "Repeated weaknesses become priorities."]
        ]
      }
    },
    noriBuildScoreboardBlock([2, 3, 4, 5, 6]),
    noriBuildScoreboardBlock([7, 8, 9, 10, 11, 12]),
    {
      id: "12-model-final-review",
      title: "12-Model Final Review",
      subtitle: "Compare Model 1 against Model 12.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Measure",
        rows: ["Overall %"].concat(NORI_EXAM_SUBJECTS).concat(["Average time"]),
        columns: [
          { key: "model1", label: "Model 1", type: "text" },
          { key: "model12", label: "Model 12", type: "text" },
          { key: "change", label: "Change", type: "text" },
          { key: "best", label: "Best", type: "text" },
          { key: "lowest", label: "Lowest", type: "text" }
        ]
      },
      fixedTable2: {
        title: "Final Diagnosis",
        rowLabel: "Final diagnosis",
        rows: [
          "Greatest strength", "Most persistent weakness", "Most improved area",
          "Repeated error type", "Main exam-habit problem", "Priority before next cycle"
        ],
        columns: [{ key: "evidence", label: "Evidence", type: "text" }]
      }
    }
  ]
};

/* System 2 — Individual Model Exam Reports (12 near-identical pages) */

const NORI_MODEL_REPORT_FORMS = Array.from({ length: 12 }, function (_, i) {
  const n = i + 1;
  return {
    id: "model-exam-report-" + n,
    title: "Individual Model Exam Report \u2014 Model " + n,
    subtitle: "Complete immediately after the model.",
    kind: "snapshot-log",
    fields: [
      { key: "date", label: "Date", type: "date" },
      { key: "examSource", label: "Exam / source", type: "text" },
      { key: "totalMarks", label: "Total marks", type: "number" },
      { key: "score", label: "Score", type: "number" },
      { key: "percentage", label: "Percentage", type: "number" },
      { key: "timeAllowed", label: "Time allowed", type: "text" },
      { key: "timeUsed", label: "Time used", type: "text" },
      { key: "targetScore", label: "Target score", type: "number" },
      { key: "difference", label: "Difference from target", type: "computed", computed: noriGapFromPercent("score", "targetScore") },
      { key: "difficulty", label: "Difficulty (1\u20135)", type: "number" }
    ],
    fixedTable: {
      rowLabel: "Subject",
      rows: NORI_EXAM_SUBJECTS,
      columns: [
        { key: "score", label: "Score", type: "text" },
        { key: "possible", label: "Possible", type: "text" },
        { key: "pct", label: "%", type: "text" },
        { key: "confidence", label: "Confidence", type: "text" },
        { key: "mainIssue", label: "Main issue", type: "text" }
      ]
    },
    freeText: [
      { key: "wentWell", label: "What went well?" },
      { key: "costMarks", label: "What cost the most marks?" },
      { key: "mustChange", label: "What must change before the next model?" }
    ]
  };
});

const NORI_SYSTEM_MODEL_REPORTS = {
  id: "individual-model-reports",
  title: "Individual Model Reports",
  subtitle: "One complete report per model exam \u2014 12 pages",
  forms: NORI_MODEL_REPORT_FORMS
};

/* System 3 — Error Analysis & Repair */

const NORI_ERROR_ANALYSIS_FORMS = [1, 2, 3].map(function (n) {
  return {
    id: "model-exam-error-analysis-" + n,
    title: "Model Exam Error Analysis \u2014 Sheet " + n,
    subtitle: "Error types: " + NORI_ERROR_TYPES.join(" \u2022 "),
    kind: "table-log",
    columns: [
      { key: "qNum", label: "Q#", type: "text" },
      { key: "subject", label: "Subject", type: "text" },
      { key: "errorType", label: "Error type", type: "select", options: NORI_ERROR_TYPES },
      { key: "whyMissed", label: "Why missed", type: "text" },
      { key: "correctIdea", label: "Correct idea", type: "text" },
      { key: "repairAction", label: "Repair action", type: "text" },
      { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] }
    ]
  };
});

const NORI_SYSTEM_ERROR_ANALYSIS = {
  id: "error-analysis-repair",
  title: "Error Analysis & Repair",
  subtitle: "Classify wrong answers, spot patterns, repair and retest \u2014 5 pages",
  forms: NORI_ERROR_ANALYSIS_FORMS.concat([
    {
      id: "error-pattern-summary",
      title: "Error Pattern Summary",
      subtitle: "Aggregate view across all error analysis sheets.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Error type",
        rows: NORI_ERROR_TYPES,
        columns: [
          { key: "count", label: "Count", type: "number" },
          { key: "subjects", label: "Subjects", type: "text" },
          { key: "repeated", label: "Repeated?", type: "select", options: ["Yes", "No"] },
          { key: "rootCause", label: "Root cause", type: "text" },
          { key: "preventiveRule", label: "Preventive rule", type: "text" }
        ]
      },
      fixedTable2: {
        rowLabel: "Question",
        rows: [
          "Which error cost the most marks?", "Which error repeats most often?",
          "What changes next?", "What must be retested?"
        ],
        columns: [{ key: "answer", label: "Answer", type: "text" }]
      }
    },
    {
      id: "error-repair-verification",
      title: "Error Repair & Verification",
      subtitle: "Weak topic \u2014 Original error \u2014 Correct principle \u2014 Practice \u2014 Retest date \u2014 Result \u2014 Closed?",
      kind: "table-log",
      columns: [
        { key: "weakTopic", label: "Weak topic", type: "text" },
        { key: "originalError", label: "Original error", type: "text" },
        { key: "correctPrinciple", label: "Correct principle", type: "text" },
        { key: "practice", label: "Practice", type: "text" },
        { key: "retestDate", label: "Retest date", type: "date" },
        { key: "result", label: "Result", type: "text" },
        { key: "closed", label: "Closed?", type: "select", options: ["Yes", "No"] }
      ]
    }
  ])
};

/* System 4 — Entrance Preparation */

const NORI_SYSTEM_ENTRANCE_PREP = {
  id: "entrance-preparation",
  title: "Entrance Preparation",
  subtitle: "Topic tracking, weekly control, and score progress \u2014 5 pages",
  forms: [
    {
      id: "entrance-preparation-tracker",
      title: "Entrance Preparation Tracker",
      subtitle: "Status: Not started \u2022 Learning \u2022 Practicing \u2022 Tested \u2022 Secure",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Subject",
        rows: NORI_EXAM_SUBJECTS,
        columns: [
          { key: "topicUnit", label: "Topic / unit", type: "text" },
          { key: "status", label: "Status", type: "select", options: ["Not started", "Learning", "Practicing", "Tested", "Secure"] },
          { key: "confidence", label: "Confidence", type: "text" },
          { key: "lastReview", label: "Last review", type: "date" },
          { key: "nextReview", label: "Next review", type: "date" },
          { key: "tested", label: "Tested?", type: "select", options: ["Yes", "No"] }
        ]
      }
    },
    {
      id: "entrance-topic-command-list",
      title: "Entrance Topic Command List",
      subtitle: "Priority \u2014 Subject \u2014 Topic \u2014 Why it matters \u2014 Current level \u2014 Required action \u2014 Deadline",
      kind: "table-log",
      columns: [
        { key: "priority", label: "Priority", type: "number" },
        { key: "subject", label: "Subject", type: "text" },
        { key: "topic", label: "Topic", type: "text" },
        { key: "whyMatters", label: "Why it matters", type: "text" },
        { key: "currentLevel", label: "Current level", type: "text" },
        { key: "requiredAction", label: "Required action", type: "text" },
        { key: "deadline", label: "Deadline", type: "date" }
      ]
    },
    {
      id: "entrance-preparation-weekly-control",
      title: "Entrance Preparation \u2014 Weekly Control",
      subtitle: "Week \u2014 Main targets \u2014 Practice/tests \u2014 Errors repaired \u2014 Result \u2014 Next priority",
      kind: "table-log",
      columns: [
        { key: "week", label: "Week", type: "number" },
        { key: "mainTargets", label: "Main targets", type: "text" },
        { key: "practiceTests", label: "Practice / tests", type: "text" },
        { key: "errorsRepaired", label: "Errors repaired", type: "text" },
        { key: "result", label: "Result", type: "text" },
        { key: "nextPriority", label: "Next priority", type: "text" }
      ]
    },
    {
      id: "entrance-score-progress",
      title: "Entrance Score Progress",
      subtitle: "Test \u2014 Date \u2014 Score % \u2014 Target \u2014 Gap \u2014 Time \u2014 Main weakness \u2014 Retest",
      kind: "table-log",
      columns: [
        { key: "test", label: "Test", type: "number" },
        { key: "date", label: "Date", type: "date" },
        { key: "score", label: "Score %", type: "number" },
        { key: "target", label: "Target", type: "number" },
        { key: "gap", label: "Gap", type: "computed", computed: noriGapFromPercent("score", "target") },
        { key: "time", label: "Time", type: "text" },
        { key: "mainWeakness", label: "Main weakness", type: "text" },
        { key: "retest", label: "Retest", type: "text" }
      ],
      pageFieldsTitle: "Checkpoint",
      pageFields: [
        { key: "currentAverage", label: "Current average", type: "text" },
        { key: "bestScore", label: "Best score", type: "text" },
        { key: "lowestScore", label: "Lowest score", type: "text" },
        { key: "targetScore", label: "Target score", type: "text" },
        { key: "gapToTarget", label: "Gap to target", type: "text" },
        { key: "mostImprovedSubject", label: "Most improved subject", type: "text" },
        { key: "subjectNeedingWork", label: "Subject needing most work", type: "text" }
      ]
    },
    {
      id: "entrance-score-progress-hand-graph",
      title: "Entrance Score Progress \u2014 Hand Graph",
      subtitle: "Plot each test percentage. Axis: 0\u2013100 in steps of 10, across Tests 1\u201312. Use the Entrance Score Progress log above as the data source \u2014 this page is a plotting reference, not a data entry page.",
      kind: "reference"
    }
  ]
};

/* System 5 — Command Review & Notes */

const NORI_SYSTEM_COMMAND_REVIEW = {
  id: "command-review-notes",
  title: "Command Review & Notes",
  subtitle: "Phase review, a custom page, and the running decision log \u2014 3 pages",
  forms: [
    {
      id: "phase3-command-review",
      title: "Phase 3 Command Review",
      subtitle: "Final review page for Phase 3.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Command question",
        rows: [
          "Did my average score rise?", "Which subject improved most?", "Which subject stayed weak?",
          "Which error type repeated?", "Did time management improve?", "Did careless mistakes decrease?",
          "Which topics remain unfinished?", "What is the next highest-value action?"
        ],
        columns: [{ key: "evidence", label: "Evidence / answer", type: "text" }]
      }
    },
    {
      id: "custom-exam-command-page",
      title: "Custom Exam Command Page",
      subtitle: "A blank command page for anything outside the standard forms.",
      kind: "snapshot-log",
      fields: [
        { key: "examCheckpoint", label: "Exam / checkpoint", type: "text" },
        { key: "purpose", label: "Purpose", type: "text" },
        { key: "score", label: "Score / %", type: "text" },
        { key: "target", label: "Target", type: "text" },
        { key: "strength", label: "Main strength", type: "text" },
        { key: "weakness", label: "Main weakness", type: "text" },
        { key: "nextAction", label: "Next action", type: "text" }
      ],
      subLog: {
        key: "questions",
        title: "Question / Topic Log",
        columns: [
          { key: "questionTopic", label: "Question / topic", type: "text" },
          { key: "note", label: "Error \u2022 lesson \u2022 correction", type: "text" }
        ]
      }
    },
    {
      id: "phase3-notes-decisions",
      title: "Phase 3 Notes & Decisions",
      subtitle: "Record decisions that should affect the next model or entrance-preparation cycle.",
      kind: "table-log",
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "decision", label: "Decision / discovery", type: "text" },
        { key: "action", label: "Action", type: "text" },
        { key: "result", label: "Result", type: "text" }
      ]
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 1 — "Recognition Overview"
   Source: Phase 4 • Recognition (\u00a7\u00a7 1-2, pages 2-3)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_RECOGNITION_OVERVIEW = {
  id: "recognition-overview",
  title: "Recognition Overview",
  subtitle: "What recognition is and the rules that govern it \u2014 2 pages",
  forms: [
    {
      id: "recognition-system-intro",
      title: "Phase 4 \u2014 Recognition System",
      subtitle: "Recognition records achievement without replacing academic responsibility. Awards recognize meaningful performance, consistency, improvement, discipline, and exceptional mastery.",
      kind: "reference",
      referenceTable: {
        title: "Award Levels",
        columns: ["Level", "Award", "Meaning"],
        rows: [
          ["1", "Merit", "Individual qualifying action"],
          ["2", "Distinction", "Repeated consistency or defined streak"],
          ["3", "Excellence", "Sustained high performance or mastery"],
          ["4", "Honor", "Exceptional record over a major period"],
          ["5", "Elite", "Exceptional overall mastery"]
        ]
      }
    },
    {
      id: "recognition-rules",
      title: "Recognition Rules",
      subtitle: "The rules that keep recognition from replacing academic responsibility.",
      kind: "reference",
      referenceTable: {
        title: "Recognition Rules",
        columns: ["Rule", "Application"],
        rows: [
          ["No double counting", "One achievement earns one primary award."],
          ["Requirements remain requirements", "A required corrective task is not automatically an award."],
          ["Awards do not cancel penalties", "Recognition and consequence records remain separate."],
          ["80% academic floor", "Recognition never changes the academic floor."],
          ["Evidence required", "Use scores, streaks, assessments, or verified records."],
          ["Higher levels need stronger evidence", "Sustained achievement outranks isolated performance."],
          ["Rewards remain bounded", "Recognition never overrides academic responsibilities."]
        ]
      }
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 2 — "Award & Merit Records"
   Source: Phase 4 • Recognition (\u00a7\u00a7 3-7, pages 4-8)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_AWARD_MERIT_RECORDS = {
  id: "award-merit-records",
  title: "Award & Merit Records",
  subtitle: "Award Record, Merit Point Ledger, qualification table, and redemption \u2014 4 pages (5 in source)",
  forms: [
    {
      id: "award-record",
      title: "Award Record",
      subtitle: "Continuing record of achievements, levels, and awards. Source pages 4\u20135 share this one continuing table.",
      kind: "table-log",
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "achievement", label: "Achievement", type: "text" },
        { key: "level", label: "Level", type: "text" },
        { key: "award", label: "Award", type: "text" },
        { key: "evidence", label: "Evidence", type: "text" },
        { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] }
      ]
    },
    {
      id: "merit-point-ledger",
      title: "Merit Point Ledger",
      subtitle: "Record every merit point earned, by subject or area.",
      kind: "table-log",
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "subjectArea", label: "Subject / area", type: "text" },
        { key: "achievement", label: "Achievement", type: "text" },
        { key: "basis", label: "Basis", type: "text" },
        { key: "points", label: "Points", type: "number" },
        { key: "evidence", label: "Evidence", type: "text" }
      ],
      pageFieldsTitle: "Point Total",
      pageFields: [
        { key: "currentBalance", label: "Current balance", type: "text" },
        { key: "earnedThisPeriod", label: "Earned this period", type: "text" },
        { key: "redeemed", label: "Redeemed", type: "text" },
        { key: "balanceRemaining", label: "Balance remaining", type: "text" }
      ]
    },
    {
      id: "merit-point-qualification",
      title: "Merit Point Qualification",
      subtitle: "How many points a result is worth.",
      kind: "reference",
      referenceTable: {
        title: "Merit Point Qualification",
        columns: ["Result", "Points"],
        rows: [
          ["80\u201384%", "2"],
          ["85\u201389%", "3"],
          ["90\u201394%", "4"],
          ["95\u201399%", "5"],
          ["100%", "6 + Perfect Score Recognition"]
        ]
      }
    },
    {
      id: "merit-redemption-record",
      title: "Merit Redemption Record",
      subtitle: "Earned leisure remains bounded by responsibilities and current discipline status.",
      kind: "table-log",
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "rewardPrivilege", label: "Reward / privilege", type: "text" },
        { key: "pointsCost", label: "Points cost", type: "number" },
        { key: "approved", label: "Approved", type: "select", options: ["Yes", "No"] },
        { key: "used", label: "Used", type: "select", options: ["Yes", "No"] },
        { key: "notes", label: "Notes", type: "text" }
      ]
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 3 — "Distinction \u2014 Level 2"
   Source: Phase 4 • Recognition (\u00a7\u00a7 8-9, pages 9-10)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_DISTINCTION = {
  id: "distinction-level-2",
  title: "Distinction \u2014 Level 2",
  subtitle: "Distinction tracker and its point milestones \u2014 2 pages",
  forms: [
    {
      id: "distinction-tracker",
      title: "Level 2 \u2014 Distinction Tracker",
      subtitle: "Track progress toward each distinction type.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Type",
        rows: [
          "Consistency streak", "Subject distinction", "Model exam distinction",
          "Comeback distinction", "Discipline streak"
        ],
        columns: [
          { key: "requirement", label: "Requirement / evidence", type: "text" },
          { key: "date", label: "Date", type: "date" },
          { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] },
          { key: "notes", label: "Notes", type: "text" }
        ]
      }
    },
    {
      id: "distinction-milestones",
      title: "Distinction Milestones",
      subtitle: "Point milestones on the way to Distinction.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Milestone",
        rows: ["10 points", "20 points", "40 points", "60 points"],
        columns: [
          { key: "status", label: "Status", type: "text" },
          { key: "date", label: "Date", type: "date" },
          { key: "evidence", label: "Evidence", type: "text" }
        ]
      }
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 4 — "Excellence \u2014 Level 3"
   Source: Phase 4 • Recognition (\u00a7\u00a7 10-11, pages 11-12)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_EXCELLENCE = {
  id: "excellence-level-3",
  title: "Excellence \u2014 Level 3",
  subtitle: "Excellence record and its progress checkpoints \u2014 2 pages",
  forms: [
    {
      id: "excellence-record",
      title: "Level 3 \u2014 Excellence Record",
      subtitle: "Sustained high performance or mastery, by category.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Category",
        rows: [
          "90%+ streak", "Five-subject excellence", "12-model mastery",
          "30-day discipline streak", "60-day discipline streak", "90-day discipline streak"
        ],
        columns: [
          { key: "qualification", label: "Qualification", type: "text" },
          { key: "achieved", label: "Achieved", type: "select", options: ["Yes", "No"] },
          { key: "evidence", label: "Evidence", type: "text" }
        ]
      }
    },
    {
      id: "excellence-progress-tracker",
      title: "Excellence Progress Tracker",
      subtitle: "Checkpoint progress toward Excellence, by category.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Category",
        rows: ["Academic performance", "Subject mastery", "Model exams", "Discipline", "Consistency"],
        columns: [
          { key: "checkpoint1", label: "Checkpoint 1", type: "text" },
          { key: "checkpoint2", label: "Checkpoint 2", type: "text" },
          { key: "checkpoint3", label: "Checkpoint 3", type: "text" },
          { key: "finalEvidence", label: "Final evidence", type: "text" }
        ]
      }
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 5 — "Honor & Elite \u2014 Levels 4-5"
   Source: Phase 4 • Recognition (\u00a7\u00a7 12-13, pages 13-14)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_HONOR_ELITE = {
  id: "honor-elite-levels-4-5",
  title: "Honor & Elite \u2014 Levels 4-5",
  subtitle: "The two highest recognition levels \u2014 2 pages",
  forms: [
    {
      id: "honor-record",
      title: "Level 4 \u2014 Honor Record",
      subtitle: "Exceptional records over a major period.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Category",
        rows: [
          "90% yearly honor", "95% yearly honor", "Complete assessment honor",
          "Five-subject honor", "12-model exam honor", "90-day discipline honor", "180-day discipline honor"
        ],
        columns: [
          { key: "qualification", label: "Qualification", type: "text" },
          { key: "result", label: "Result", type: "text" },
          { key: "evidenceDate", label: "Evidence / date", type: "text" }
        ]
      }
    },
    {
      id: "elite-recognition",
      title: "Level 5 \u2014 Elite Recognition",
      subtitle: "Elite is reserved for exceptional overall mastery; it is not granted merely because lower awards have been collected.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Evidence area",
        rows: [
          "Academic mastery", "Long-term consistency", "Exam performance",
          "Discipline record", "Recovery / comeback record", "Complete recognition record"
        ],
        columns: [
          { key: "evidence", label: "Evidence", type: "text" },
          { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] }
        ]
      }
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 6 — "Rank System"
   Source: Phase 4 • Recognition (\u00a7\u00a7 14-15, pages 15-16)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_RANK = {
  id: "rank-system",
  title: "Rank System",
  subtitle: "Current rank status and the record of rank changes \u2014 2 pages",
  forms: [
    {
      id: "rank-system-status",
      title: "Rank System",
      subtitle: "Current status for each rank.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Rank",
        rows: ["Rank 1 \u2014 Merit", "Rank 2 \u2014 Distinction", "Rank 3 \u2014 Excellence", "Rank 4 \u2014 Honor", "Rank 5 \u2014 Elite"],
        columns: [
          { key: "primaryBasis", label: "Primary basis", type: "text" },
          { key: "dateReached", label: "Date reached", type: "date" },
          { key: "status", label: "Status", type: "text" }
        ]
      }
    },
    {
      id: "rank-progress-record",
      title: "Rank Progress Record",
      subtitle: "A running log of every rank change.",
      kind: "table-log",
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "previousRank", label: "Previous rank", type: "text" },
        { key: "newRank", label: "New rank", type: "text" },
        { key: "reasonEvidence", label: "Reason / evidence", type: "text" },
        { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] }
      ]
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 7 — "Achievement Hall & Milestones"
   Source: Phase 4 • Recognition (\u00a7\u00a7 16-17, pages 17-18)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_ACHIEVEMENT_HALL = {
  id: "achievement-hall-milestones",
  title: "Achievement Hall & Milestones",
  subtitle: "The running achievement log and the major milestone checklist \u2014 2 pages",
  forms: [
    {
      id: "achievement-hall",
      title: "Achievement Hall",
      subtitle: "A running record of achievements and what they meant.",
      kind: "table-log",
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "achievement", label: "Achievement", type: "text" },
        { key: "level", label: "Level", type: "text" },
        { key: "evidenceResult", label: "Evidence / result", type: "text" },
        { key: "reflection", label: "Reflection", type: "text" }
      ]
    },
    {
      id: "major-milestones",
      title: "Major Milestones",
      subtitle: "The defined set of major milestones and why each matters.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Milestone",
        rows: [
          "First 80%+ milestone", "First 90%+ milestone", "Perfect score recognition",
          "First major streak", "12-model completion", "Entrance preparation milestone",
          "Major comeback", "Year-end honor"
        ],
        columns: [
          { key: "date", label: "Date", type: "date" },
          { key: "evidence", label: "Evidence", type: "text" },
          { key: "whyMatters", label: "Why it matters", type: "text" }
        ]
      }
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 8 — "Certificates & Review"
   Source: Phase 4 • Recognition (\u00a7\u00a7 18-20, pages 19-21)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_CERTIFICATES_REVIEW = {
  id: "certificates-review",
  title: "Certificates & Review",
  subtitle: "Certificate register, the printable certificate template, and the phase review \u2014 3 pages",
  forms: [
    {
      id: "certificate-register",
      title: "Certificate Register",
      subtitle: "A record of every certificate issued.",
      kind: "table-log",
      columns: [
        { key: "certificate", label: "Certificate", type: "text" },
        { key: "level", label: "Level", type: "text" },
        { key: "dateIssued", label: "Date issued", type: "date" },
        { key: "reason", label: "Reason", type: "text" },
        { key: "recordId", label: "Record / ID", type: "text" }
      ]
    },
    {
      id: "certificate-master-template",
      title: "Certificate of Achievement \u2014 Master Template",
      subtitle: "This certificate recognizes verified achievement. Fill and use as the printable master.",
      kind: "snapshot-log",
      fields: [
        { key: "recognizes", label: "This certificate recognizes verified achievement in", type: "text" },
        { key: "awardLevel", label: "Award / Level", type: "text" },
        { key: "evidenceAchievement", label: "Evidence / achievement", type: "text" },
        { key: "verifiedBy", label: "Verified", type: "text" }
      ]
    },
    {
      id: "phase4-recognition-review",
      title: "Phase 4 Recognition Review",
      subtitle: "Recognition principle: Awards document earned progress; they do not replace the work that earned them.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Review question",
        rows: [
          "Which level am I currently qualified for?",
          "What achievement has been most meaningful?",
          "Am I demonstrating progress rather than collecting points?",
          "Are points recorded without double counting?",
          "Has any reward interfered with academic responsibility?",
          "What is the next legitimate recognition target?"
        ],
        columns: [{ key: "answer", label: "Answer / evidence", type: "text" }]
      }
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 1 — "Recovery Overview"
   Source: Phase 5 • Recovery (\u00a7 1, page 2)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_RECOVERY_OVERVIEW = {
  id: "recovery-overview",
  title: "Recovery Overview",
  subtitle: "What recovery is and the principles behind it \u2014 1 page",
  forms: [
    {
      id: "recovery-system-intro",
      title: "Phase 5 \u2014 Recovery System",
      subtitle: "Recovery is the controlled process used after a serious disruption, backlog, repeated failure, or loss of academic control. The purpose is to restore normal operation through clear actions and verification. Recovery is not a permanent punishment. It is a structured route back to normal operation.",
      kind: "reference",
      referenceTable: {
        title: "Recovery Principles",
        columns: ["Recovery principle", "Application"],
        rows: [
          ["Stabilize", "Identify what is currently out of control."],
          ["Prioritize", "Separate urgent academic work from lower-priority work."],
          ["Repair", "Complete the highest-value corrective actions."],
          ["Verify", "Use evidence to confirm that control has returned."],
          ["Return", "Resume the normal handbook system."]
        ]
      }
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 2 — "Emergency Recovery"
   Source: Phase 5 • Recovery (\u00a7\u00a7 2-4, pages 3-5)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_EMERGENCY_RECOVERY = {
  id: "emergency-recovery",
  title: "Emergency Recovery",
  subtitle: "Activate, prioritize, and decide at the start of a recovery period \u2014 3 pages",
  forms: [
    {
      id: "emergency-recovery-card",
      title: "Emergency Recovery Card",
      subtitle: "Filed at the start of a recovery period.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Field",
        rows: [
          "Date / time", "Reason for activation", "Current degree / status",
          "Immediate academic risk", "Most urgent unfinished responsibility",
          "Next deadline", "First corrective action", "Verification required",
          "Recovery start", "Expected return to normal"
        ],
        columns: [
          { key: "record", label: "Record", type: "text" }
        ]
      }
    },
    {
      id: "emergency-recovery-priority-order",
      title: "Emergency Recovery \u2014 Priority Order",
      subtitle: "The eight highest-priority tasks for this recovery period, in order.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Priority",
        rows: ["1", "2", "3", "4", "5", "6", "7", "8"],
        columns: [
          { key: "task", label: "Task / responsibility", type: "text" },
          { key: "deadline", label: "Deadline", type: "date" },
          { key: "estimatedWork", label: "Estimated work", type: "text" },
          { key: "status", label: "Status", type: "text" },
          { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] }
        ]
      }
    },
    {
      id: "recovery-decision-page",
      title: "Recovery Decision Page",
      subtitle: "Answer these before acting.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Question",
        rows: [
          "What caused the loss of control?",
          "What work is currently at risk?",
          "What can be recovered first?",
          "What can wait?",
          "What distraction or process failure must be controlled?",
          "What evidence will prove recovery?",
          "What would trigger further escalation?"
        ],
        columns: [{ key: "answer", label: "Answer", type: "text" }]
      }
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 3 — "Backlog Management"
   Source: Phase 5 • Recovery (\u00a7\u00a7 5-7, pages 6-8)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_BACKLOG_MANAGEMENT = {
  id: "backlog-management",
  title: "Backlog Management",
  subtitle: "Track, map, and prioritize the recovery backlog \u2014 3 pages",
  forms: [
    {
      id: "academic-backlog-tracker",
      title: "Academic Backlog Tracker",
      subtitle: "Every backlogged task or topic, tracked to closure.",
      kind: "table-log",
      columns: [
        { key: "taskTopic", label: "Task / topic", type: "text" },
        { key: "subject", label: "Subject", type: "text" },
        { key: "originalDeadline", label: "Original deadline", type: "date" },
        { key: "priority", label: "Priority", type: "text" },
        { key: "newTarget", label: "New target", type: "date" },
        { key: "status", label: "Status", type: "text" },
        { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] }
      ]
    },
    {
      id: "backlog-subject-recovery-map",
      title: "Backlog \u2014 Subject Recovery Map",
      subtitle: "Backlog broken down by subject.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Subject",
        rows: ["Mathematics", "Physics", "Chemistry", "Biology", "English", "Agriculture", "Web / IT"],
        columns: [
          { key: "backlogTopics", label: "Backlog topics", type: "text" },
          { key: "mostUrgent", label: "Most urgent", type: "text" },
          { key: "correctionPlan", label: "Correction plan", type: "text" },
          { key: "testCheck", label: "Test / check", type: "text" },
          { key: "closed", label: "Closed?", type: "select", options: ["Yes", "No"] }
        ]
      }
    },
    {
      id: "backlog-priority-matrix",
      title: "Backlog Priority Matrix",
      subtitle: "Weigh urgency against importance for every backlog item.",
      kind: "table-log",
      columns: [
        { key: "item", label: "Item", type: "text" },
        { key: "urgency", label: "Urgency", type: "text" },
        { key: "importance", label: "Importance", type: "text" },
        { key: "consequenceIfDelayed", label: "Consequence if delayed", type: "text" },
        { key: "priority", label: "Priority", type: "text" },
        { key: "action", label: "Action", type: "text" }
      ]
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 4 — "Recovery Work & Obstacles"
   Source: Phase 5 • Recovery (\u00a7\u00a7 8-9, pages 9-10)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_RECOVERY_WORK_OBSTACLES = {
  id: "recovery-work-obstacles",
  title: "Recovery Work & Obstacles",
  subtitle: "The work log and the obstacle log \u2014 2 pages",
  forms: [
    {
      id: "recovery-work-log",
      title: "Recovery Work Log",
      subtitle: "Every recovery work session, logged as it happens.",
      kind: "table-log",
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "taskCompleted", label: "Task completed", type: "text" },
        { key: "subject", label: "Subject", type: "text" },
        { key: "timeSession", label: "Time / session", type: "text" },
        { key: "evidence", label: "Evidence", type: "text" },
        { key: "nextAction", label: "Next action", type: "text" }
      ]
    },
    {
      id: "recovery-error-obstacle-log",
      title: "Recovery Error / Obstacle Log",
      subtitle: "Anything that got in the way of recovery.",
      kind: "table-log",
      columns: [
        { key: "obstacle", label: "Obstacle", type: "text" },
        { key: "cause", label: "Cause", type: "text" },
        { key: "effect", label: "Effect", type: "text" },
        { key: "correction", label: "Correction", type: "text" },
        { key: "repeated", label: "Repeated?", type: "select", options: ["Yes", "No"] },
        { key: "resolved", label: "Resolved?", type: "select", options: ["Yes", "No"] }
      ]
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 5 — "Recovery Verification"
   Source: Phase 5 • Recovery (\u00a7\u00a7 10-12, pages 11-13)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_RECOVERY_VERIFICATION = {
  id: "recovery-verification",
  title: "Recovery Verification",
  subtitle: "Verify recovery overall, academically, and by discipline \u2014 3 pages",
  forms: [
    {
      id: "recovery-verification-page",
      title: "Recovery Verification Page",
      subtitle: "Recovery is complete only when the required evidence has been checked.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Requirement",
        rows: [
          "Urgent backlog reduced / cleared", "Missed academic work addressed",
          "Priority weaknesses reviewed", "Required retesting completed",
          "Daily control restored", "Normal schedule can resume"
        ],
        columns: [
          { key: "evidence", label: "Evidence", type: "text" },
          { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] },
          { key: "date", label: "Date", type: "date" }
        ]
      }
    },
    {
      id: "recovery-verification-academic",
      title: "Recovery Verification \u2014 Academic",
      subtitle: "Verify recovered work, subject by subject.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Subject",
        rows: ["Mathematics", "Physics", "Chemistry", "Biology", "English", "Agriculture", "Web / IT"],
        columns: [
          { key: "recoveredTopicTask", label: "Recovered topic / task", type: "text" },
          { key: "evidence", label: "Evidence", type: "text" },
          { key: "result", label: "Result", type: "text" },
          { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] }
        ]
      }
    },
    {
      id: "recovery-verification-discipline",
      title: "Recovery Verification \u2014 Discipline",
      subtitle: "Verify that daily control has actually returned.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Control area",
        rows: [
          "Study sequence", "Distraction control", "Assignment completion",
          "Exam preparation", "Daily audit", "Sleep / schedule protection"
        ],
        columns: [
          { key: "requiredCondition", label: "Required condition", type: "text" },
          { key: "evidence", label: "Evidence", type: "text" },
          { key: "verified", label: "Verified", type: "select", options: ["Yes", "No"] }
        ]
      }
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 6 — "Return & Review"
   Source: Phase 5 • Recovery (\u00a7\u00a7 13-14, pages 14-15)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_RETURN_REVIEW = {
  id: "return-review",
  title: "Return & Review",
  subtitle: "Close recovery out and review the period \u2014 2 pages",
  forms: [
    {
      id: "return-to-normal-checklist",
      title: "Return-to-Normal Checklist",
      subtitle: "Every item must be complete before returning to the normal system.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Check",
        rows: [
          "Emergency recovery card closed", "Highest-priority backlog addressed",
          "Academic verification completed", "Required corrections completed",
          "Normal daily system restored", "Next assessment prepared",
          "Recovery record filed", "No unresolved critical item remains"
        ],
        columns: [
          { key: "complete", label: "Complete", type: "select", options: ["Yes", "No"] }
        ]
      }
    },
    {
      id: "recovery-period-review",
      title: "Recovery Period Review",
      subtitle: "Review the recovery period once it's closed.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Question",
        rows: [
          "Recovery start date", "Recovery end date", "Main failure",
          "Most important repair", "Backlog cleared", "Performance after recovery",
          "What prevented relapse?", "What remains vulnerable?"
        ],
        columns: [{ key: "record", label: "Record", type: "text" }]
      }
    }
  ]
};

/* -------------------------------------------------------------------------
   SYSTEM 7 — "Repeat Failure & Final Review"
   Source: Phase 5 • Recovery (\u00a7\u00a7 15-16, pages 16-17)
   ------------------------------------------------------------------------- */

const NORI_SYSTEM_REPEAT_FAILURE_FINAL_REVIEW = {
  id: "repeat-failure-final-review",
  title: "Repeat Failure & Final Review",
  subtitle: "Handle recurrence and close out the phase \u2014 2 pages",
  forms: [
    {
      id: "repeat-failure-re-entry-record",
      title: "Repeat Failure / Re-Entry Record",
      subtitle: "Use this page when a previously recovered problem returns. Record the new evidence before deciding whether escalation is required.",
      kind: "table-log",
      columns: [
        { key: "date", label: "Date", type: "date" },
        { key: "previousIssue", label: "Previous issue", type: "text" },
        { key: "newOccurrence", label: "New occurrence", type: "text" },
        { key: "whatChanged", label: "What changed?", type: "text" },
        { key: "newAction", label: "New action", type: "text" },
        { key: "escalate", label: "Escalate?", type: "select", options: ["Yes", "No"] }
      ]
    },
    {
      id: "phase5-final-recovery-review",
      title: "Phase 5 Final Recovery Review",
      subtitle: "Final recovery rule: Return to the normal system only after the required evidence is complete.",
      kind: "snapshot-log",
      fixedTable: {
        rowLabel: "Review question",
        rows: [
          "What was recovered?",
          "What evidence proves recovery?",
          "Which weakness still needs monitoring?",
          "Did the recovery process work?",
          "What should be changed in the normal system?",
          "What is the next academic priority?"
        ],
        columns: [{ key: "answer", label: "Evidence / answer", type: "text" }]
      }
    }
  ]
};

/* -------------------------------------------------------------------------
   TOP LEVEL — NORI PHASE
   Phase 1 is built from both PDFs above. Phases 2-5 are placeholders until
   their source PDFs are provided — structure only, no invented content.
   ------------------------------------------------------------------------- */

const NORI_PHASE_DATA = {
  appTitle: "NORI PHASE",
  phases: [
    {
      id: "phase-1",
      title: "Phase 1",
      subtitle: "Academic Control System",
      status: "active",
      systems: [NORI_SYSTEM_MASTER_SCOREBOARD, NORI_SYSTEM_CONTROL_PAGES]
    },
    {
      id: "phase-2",
      title: "Phase 2",
      subtitle: "Error Correction & Mastery System",
      status: "active",
      systems: [NORI_SYSTEM_ACADEMIC_SYSTEMS, NORI_SYSTEM_ERROR_CORRECTION]
    },
    {
      id: "phase-3",
      title: "Phase 3",
      subtitle: "Exam Command",
      status: "active",
      systems: [
        NORI_SYSTEM_EXAM_CORE, NORI_SYSTEM_MODEL_REPORTS,
        NORI_SYSTEM_ERROR_ANALYSIS, NORI_SYSTEM_ENTRANCE_PREP, NORI_SYSTEM_COMMAND_REVIEW
      ]
    },
    {
      id: "phase-4",
      title: "Phase 4",
      subtitle: "Recognition",
      status: "active",
      systems: [
        NORI_SYSTEM_RECOGNITION_OVERVIEW, NORI_SYSTEM_AWARD_MERIT_RECORDS,
        NORI_SYSTEM_DISTINCTION, NORI_SYSTEM_EXCELLENCE, NORI_SYSTEM_HONOR_ELITE,
        NORI_SYSTEM_RANK, NORI_SYSTEM_ACHIEVEMENT_HALL, NORI_SYSTEM_CERTIFICATES_REVIEW
      ]
    },
    {
      id: "phase-5",
      title: "Phase 5",
      subtitle: "Recovery",
      status: "active",
      systems: [
        NORI_SYSTEM_RECOVERY_OVERVIEW, NORI_SYSTEM_EMERGENCY_RECOVERY,
        NORI_SYSTEM_BACKLOG_MANAGEMENT, NORI_SYSTEM_RECOVERY_WORK_OBSTACLES,
        NORI_SYSTEM_RECOVERY_VERIFICATION, NORI_SYSTEM_RETURN_REVIEW,
        NORI_SYSTEM_REPEAT_FAILURE_FINAL_REVIEW
      ]
    }
  ]
};
