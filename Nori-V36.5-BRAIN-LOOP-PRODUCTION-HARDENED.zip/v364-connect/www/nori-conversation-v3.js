/* NORI CONVERSATION V3 — coherent thread memory, intent, affect, anti-awkwardness.
   Local-first. No diagnosis. Private Mode never persists conversation text. */
(function(g){'use strict';
  var KEY='nori_conversation_v3';
  var MAX_TURNS=24;
  var INTENTS=['question','venting','planning','analysis','action','correction','testing','academic','research','social','general'];
  function privateMode(){try{return !!(g.noriIntelligenceV20&&g.noriIntelligenceV20.controls&&g.noriIntelligenceV20.controls().privateMode)}catch(e){return false}}
  function load(){try{var x=JSON.parse(localStorage.getItem(KEY)||'null');return x&&typeof x==='object'?x:{turns:[],lastIntent:'general',lastAffect:'calm',threadTopic:''}}catch(e){return {turns:[],lastIntent:'general',lastAffect:'calm',threadTopic:''}}}
  function save(x){if(privateMode())return;try{localStorage.setItem(KEY,JSON.stringify(x))}catch(e){}}
  function clean(s){return String(s||'').replace(/\s+/g,' ').trim()}
  function intent(text){var t=clean(text).toLowerCase();
    if(/\b(test|testing|test nori|let'?s test|does this work|are you sure)\b/.test(t))return 'testing';
    if(/^(no|not exactly|that's wrong|that is wrong|you'?re wrong|incorrect|correction|actually\b|i meant\b)/.test(t)||/\b(correct that|fix your answer|you misunderstood)\b/.test(t))return 'correction';
    if(/\b(do this|build|create|make|add|remove|change|implement|generate|give me|set|start|open|save|forget)\b/.test(t))return 'action';
    if(/\b(why|how|explain|analy[sz]e|compare|evaluate|reason|difference|trade[- ]?off|what caused)\b/.test(t))return 'analysis';
    if(/\b(plan|schedule|organize|prioriti[sz]e|what should i do|next move|study plan)\b/.test(t))return 'planning';
    if(/\b(search|look up|browse|latest|current|verify online|source|url|webpage)\b/.test(t))return 'research';
    if(/\b(i feel|i am|i'm|i just|today was|rough day|fed up|exhausted|frustrated|upset|sad|angry|overwhelmed|stressed|tired)\b/.test(t))return 'venting';
    if(/\b(study|learn|teach|solve|homework|exam|assignment|physics|chemistry|biology|math|agriculture|english)\b/.test(t))return 'academic';
    if(/^((hi|hey|hello|yo)\b|good morning|good night)/.test(t))return 'social';
    if(/\?$/.test(t))return 'question';
    return 'general';
  }
  function affect(text){var t=clean(text).toLowerCase();
    if(/\b(unsafe|emergency|danger|urgent|scared|afraid)\b/.test(t))return 'concerned';
    if(/\b(frustrated|angry|fed up|annoyed|irritated)\b/.test(t))return 'firm';
    if(/\b(sad|upset|rough|hard|hurt|lonely|tired|overwhelmed|stressed|exhausted)\b/.test(t))return 'warm';
    if(/\b(deadline|exam|focus|start now|important|priority|must)\b/.test(t))return 'focused';
    if(/\b(good|great|nice|worked|improved|win|haha|lol)\b/.test(t))return 'encouraging';
    return 'calm';
  }
  function topic(text){var t=clean(text);return t.length>120?t.slice(0,120)+'…':t}
  function antiAwkward(text,reply){var r=clean(reply);if(!r)return r;
    r=r.replace(/^\s*[\[(](?:smiles?|laughs?|chuckles?|sighs?|looks? concerned|pauses?|nods?)[\])]:?\s*/i,'');
    r=r.replace(/\b(I(?:'m| am) always here for you|I'm here whenever you need me|you'?re not alone)\.?/gi,'');
    r=r.replace(/\b(Absolutely!|Of course!|Certainly!|Great question!|Sure thing!)\s*/gi,'');
    r=r.replace(/(^|\n)([ \t]*)(😊|😄|🙂|😂|👍|❤️|✨)(?:\s*\2(?:😊|😄|🙂|😂|👍|❤️|✨))+/g,'$1$2');
    r=r.replace(/\n{3,}/g,'\n\n').trim();
    return r;
  }
  function beginUserTurn(text){var st=load(),i=intent(text),a=affect(text);var turn={role:'user',content:clean(text),intent:i,affect:a,channel:(g.__noriInputChannel==='voice'?'voice':'text'),at:new Date().toISOString()};st.lastIntent=i;st.lastAffect=a;st.threadTopic=topic(text);st.turns=(st.turns||[]).concat([turn]).slice(-MAX_TURNS);save(st);if(g.noriVisualSetAffect)g.noriVisualSetAffect(a);if(g.noriPresence&&g.noriPresence.setState)g.noriPresence.setState(i==='venting'?'CONCERNED':(i==='analysis'||i==='research'?'ANALYZING':'FOCUSED'));g.__noriVoiceEmotion=a;return {intent:i,affect:a,history:st.turns.slice(-10),threadTopic:st.threadTopic};}
  function finishAssistantTurn(reply,meta){var st=load(),r=antiAwkward('',reply),emotion=(meta&&meta.emotion)||st.lastAffect;st.turns=(st.turns||[]).concat([{role:'assistant',content:r,at:new Date().toISOString(),intent:st.lastIntent||'general',emotion:emotion,channel:'text'}]).slice(-MAX_TURNS); g.__noriInputChannel='text';save(st);if(g.noriVisualSetAffect)g.noriVisualSetAffect(emotion);if(g.noriPresence&&g.noriPresence.setState)g.noriPresence.setState(emotion==='concerned'?'CONCERNED':emotion==='firm'?'FOCUSED':'WAITING');g.__noriVoiceEmotion=emotion;return r;}
  function privateTurn(x){try{return !!(g.NoriSensitiveHistory&&g.NoriSensitiveHistory.isSensitive&&g.NoriSensitiveHistory.isSensitive(x.content,x.intent))}catch(e){return false}}
  function safeContent(x){return privateTurn(x)&&!g.__noriSensitiveUnlocked?'[PRIVATE CHAT — LOCKED]':x.content}
  function context(){var st=load();return {recentTurns:privateMode()?[]:(st.turns||[]).slice(-10).map(function(x){return {role:x.role,content:privateTurn(x)?'[PRIVATE CHAT — PROTECTED]':x.content,intent:x.intent,affect:x.affect,emotion:x.emotion,channel:x.channel||'text',at:x.at}}),lastIntent:st.lastIntent||'general',lastAffect:st.lastAffect||'calm',threadTopic:st.threadTopic||'',privateMode:privateMode()};}
  function clear(){try{localStorage.removeItem(KEY);return true}catch(e){return false}}
  g.noriConversationV3={intents:INTENTS,intent:intent,affect:affect,antiAwkward:antiAwkward,beginUserTurn:beginUserTurn,finishAssistantTurn:finishAssistantTurn,context:context,clear:clear};
  /* Compatibility: the V3 layer becomes the active conversation implementation. */
  g.noriConversationV2=g.noriConversationV3;
  g.noriConversationV3.history=function(){var st=load();return (st.turns||[]).slice(-MAX_TURNS).map(function(x){var y=Object.assign({},x);if(privateTurn(x)){y.sensitive=true;if(!g.__noriSensitiveUnlocked)y.content='[PRIVATE CHAT — LOCKED]';}return y})};
})(window);
