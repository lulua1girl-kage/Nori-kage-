/* NORI ACTION CENTER V27
   Human-facing control surface for proposals, simulation, execution,
   verification, audit and rollback. This layer never bypasses Human Override.
*/
(function(g){'use strict';
  const C=()=>g.NoriActionCoreV27;
  const esc=v=>String(v==null?'':v);
  const el=(tag,attrs)=>{const n=document.createElement(tag);Object.keys(attrs||{}).forEach(k=>{if(k==='text')n.textContent=attrs[k];else if(k==='html')n.innerHTML=attrs[k];else n.setAttribute(k,attrs[k])});return n};
  function button(text,cls,fn){const b=el('button',{class:'nori-v27-btn '+(cls||''),text});b.onclick=fn;return b}
  function openModal(title,body,actions){const ov=el('div',{class:'nori-v27-modal'}),m=el('div',{class:'nori-v27-modal-card'});const h=el('div',{class:'nori-v27-head'});h.appendChild(el('div',{}));h.firstChild.appendChild(el('div',{class:'nori-v27-eyebrow',text:'NORI V27'}));h.firstChild.appendChild(el('h2',{text:title}));h.appendChild(button('Close','',()=>ov.remove()));m.appendChild(h);m.appendChild(body);const a=el('div',{class:'nori-v27-actions'});(actions||[]).forEach(x=>a.appendChild(x));m.appendChild(a);ov.appendChild(m);document.body.appendChild(ov);return ov}
  function fmt(x){try{return JSON.stringify(x,null,2)}catch(e){return esc(x)}}
  function proposalCard(p){
    const box=el('div',{class:'nori-v27-proposal'});const h=el('h3',{text:p.definition.label});box.appendChild(h);
    box.appendChild(el('div',{class:'nori-v27-small',text:'ID '+p.id+' · '+new Date(p.createdAt).toLocaleString()}));
    const why=el('div',{class:'nori-v27-evidence'});why.appendChild(el('strong',{text:'Why'}));why.appendChild(el('div',{class:'nori-v27-muted',text:p.reason||'No reason supplied.'}));
    if((p.evidence||[]).length){p.evidence.forEach(e=>why.appendChild(el('div',{class:'nori-v27-muted',text:'• '+esc(typeof e==='string'?e:(e.text||e.label||fmt(e)))})))}
    box.appendChild(why);const ch=el('div',{class:'nori-v27-change',text:'Requested input:\n'+fmt(p.input||{})});box.appendChild(ch);
    const status=el('span',{class:'nori-v27-chip '+String(p.status||'pending').replace(/[^a-z_]/g,''),text:String(p.status||'pending').replace(/_/g,' ').toUpperCase()});box.appendChild(status);
    const acts=el('div',{class:'nori-v27-actions'});
    if(p.status==='pending_confirmation'){
      acts.appendChild(button('SIMULATE', '', ()=>showSimulation(p)));
      acts.appendChild(button('WHY / EVIDENCE','',()=>showWhy(p)));
      acts.appendChild(button('CONFIRM & EXECUTE','primary',async()=>{const r=await C().confirm(p.id);alert(r.ok?'Action executed and verified.':('Action not executed: '+r.reason));render();}));
      acts.appendChild(button('CANCEL','danger',()=>{C().cancel(p.id);render()}));
    } else if(p.status==='executed'&&p.operationId){acts.appendChild(button('VERIFY','',()=>showVerification(p)));acts.appendChild(button('UNDO','danger',()=>{if(confirm('Undo this completed action? Nori will restore the recorded pre-action state.')){const r=C().undo(p.operationId);alert(r.ok?'Action undone.':'Undo failed: '+r.reason);render()}}));}
    else if(p.status==='failed'){acts.appendChild(button('VIEW FAILURE','',()=>showWhy(p)))}
    box.appendChild(acts);return box;
  }
  function showSimulation(p){const r=C().preview(p);const b=el('div',{});if(!r.ok){b.appendChild(el('p',{class:'nori-v27-muted',text:'Simulation could not run: '+r.reason}));openModal('Simulation',b,[button('Close','primary',()=>document.querySelector('.nori-v27-modal')?.remove())]);return}b.appendChild(el('p',{class:'nori-v27-muted',text:'No real data was changed. This is the predicted effect.'}));(r.changes||[]).forEach(c=>{const row=el('div',{class:'nori-v27-change',text:c.target+'\nBEFORE:\n'+fmt(c.before)+'\nAFTER:\n'+fmt(c.after)});b.appendChild(row)});openModal('Simulation',b,[button('Close','primary',()=>document.querySelector('.nori-v27-modal')?.remove())]);}
  function showWhy(p){const b=el('div',{});b.appendChild(el('p',{class:'nori-v27-muted',text:'Nori separates evidence, inference and unknowns. This action is still a proposal until you explicitly confirm it.'}));b.appendChild(el('div',{class:'nori-v27-change',text:'REASON\n'+esc(p.reason)+'\n\nEVIDENCE\n'+fmt(p.evidence||[])+'\n\nINPUT\n'+fmt(p.input||{})}));openModal('Decision basis',b,[button('Close','primary',()=>document.querySelector('.nori-v27-modal')?.remove())]);}
  function showVerification(p){const v=p.execution&&p.execution.verification;const b=el('div',{});b.appendChild(el('p',{class:'nori-v27-muted',text:v&&v.ok?'Verification passed: '+(v.label||'adapter completed'):'Verification status unavailable.'}));b.appendChild(el('div',{class:'nori-v27-change',text:'EXECUTION\n'+fmt(p.execution||{})}));openModal('Execution verification',b,[button('Close','primary',()=>document.querySelector('.nori-v27-modal')?.remove())]);}

  function createActionForm(){
    const body=el('div',{class:'nori-v27-form'});const type=el('select',{});[
      ['create_assignment','Create assignment'],['complete_assignment','Complete assignment'],['reopen_assignment','Reopen assignment'],['create_study_session','Create study session'],['complete_study_session','Complete study session'],['create_calendar_event','Schedule calendar event'],['delete_calendar_event','Delete calendar event'],['schedule_reminder','Schedule reminder'],['schedule_alarm','Schedule voice alarm'],['cancel_alarm','Cancel voice alarm'],['focus_start','Start Focus Mode'],['focus_stop','Stop Focus Mode'],['record_result','Record result'],['recalculate_awards','Recalculate awards'],['recovery_review','Open recovery review']
    ].forEach(x=>{const o=el('option',{value:x[0],text:x[1]});type.appendChild(o)});body.appendChild(label('Action type',type));
    const fields={};const holder=el('div',{class:'nori-v27-form'});body.appendChild(holder);
    function field(k,labelText,type,placeholder){const i=el(type==='textarea'?'textarea':'input',{type:type==='textarea'?'':type,placeholder:placeholder||''});if(type==='textarea')i.rows='3';fields[k]=i;holder.appendChild(label(labelText,i));}
    function rebuild(){holder.innerHTML='';Object.keys(fields).forEach(k=>delete fields[k]);const t=type.value;
      if(/assignment/.test(t)){field('ref','Assignment title or ID','text','Exact title or ID');if(t==='create_assignment'){field('title','New title','text','Assignment');field('subject','Subject','text','Mathematics');field('due','Due date','date')} }
      if(/study_session/.test(t)){field('ref','Session topic or ID','text','Topic or ID');if(t==='create_study_session'){field('topic','Topic','text','Chapter / topic');field('subject','Subject','text','Mathematics');field('minutes','Minutes','number','25');field('date','Date','date')}}
      if(/calendar_event/.test(t)){field('ref','Event title or ID','text','Event title or ID');if(t==='create_calendar_event'){field('title','Title','text','Event');field('start','Date','date');field('notes','Notes','textarea')}}
      if(t==='schedule_reminder'){field('title','Reminder title','text','Reminder');field('when','When (ISO or local date/time)','datetime-local')}
      if(t==='schedule_alarm'){field('label','Alarm purpose','text','Study check');field('date','Date','date');field('time','Time','time')}
      if(t==='cancel_alarm'){field('ref','Alarm label or ID','text','Alarm label or ID')}
      if(t==='record_result'){field('subject','Subject','text','Mathematics');field('score','Score 0–100','number','');field('date','Date','date');field('assessmentType','Assessment type','text','Test / exam / assignment')}
      if(t==='focus_start'){field('packages','Packages (comma separated)','text','Optional package list')} 
      if(t==='recovery_review'||t==='focus_stop'||t==='recalculate_awards')holder.appendChild(el('p',{class:'nori-v27-muted',text:'No extra input is required.'}));
    }
    type.onchange=rebuild;rebuild();
    const actions=el('div',{class:'nori-v27-actions'});actions.appendChild(button('BUILD PROPOSAL','primary',()=>{const i={};Object.keys(fields).forEach(k=>i[k]=fields[k].value);if(i.packages)i.packages=i.packages.split(',').map(x=>x.trim()).filter(Boolean);const p=C().makeProposal(type.value,i,'User-created proposal from Action Center.',['Inputs were explicitly entered by the user.']);if(!p){alert('Could not create proposal.');return}document.querySelector('.nori-v27-modal')?.remove();render();}));return {body,actions};
  }
  function label(t,input){const w=el('label',{});w.appendChild(document.createTextNode(t));w.appendChild(input);return w}

  function render(){
    const old=document.getElementById('nori-v27-center');if(old)old.remove();const root=el('div',{class:'nori-v27-center open'});root.id='nori-v27-center';const main=el('main',{class:'nori-v27-main'});const head=el('div',{class:'nori-v27-head'});const title=el('div',{});title.appendChild(el('div',{class:'nori-v27-eyebrow',text:'ACTION & EXECUTION CORE'}));title.appendChild(el('h2',{text:'Nori Action Center'}));head.appendChild(title);head.appendChild(button('Close','',()=>root.remove()));main.appendChild(head);
    const tabs=el('div',{class:'nori-v27-tabs'});['pending','history','audit'].forEach((x,i)=>{const b=el('button',{class:'nori-v27-tab'+(i===0?' active':''),text:x==='pending'?'Pending':x==='history'?'History':'Audit'});b.onclick=()=>renderTab(main,x);tabs.appendChild(b)});main.appendChild(tabs);renderTab(main,'pending');root.appendChild(main);document.body.appendChild(root);
  }
  function renderTab(main,tab){Array.from(main.querySelectorAll('[data-v27-content]')).forEach(x=>x.remove());const wrap=el('div',{});wrap.dataset.v27Content='1';main.appendChild(wrap);const c=C();if(tab==='pending'){const top=el('div',{class:'nori-v27-card'});top.appendChild(el('div',{class:'nori-v27-stat',text:String(c.list(x=>x.status==='pending_confirmation').length)}));top.appendChild(el('div',{class:'nori-v27-muted',text:'Pending proposals. Nothing here executes without your confirmation.'}));top.appendChild(button('+ NEW PROPOSAL','primary',()=>{const f=createActionForm();openModal('Create action proposal',f.body,[f.actions])}));top.appendChild(button('SELF-IMPROVEMENT LAB','',()=>{if(g.NoriSelfImproveLabV27)g.NoriSelfImproveLabV27.open();else alert('Self-improvement lab is not loaded.') }));wrap.appendChild(top);const list=c.list(x=>x.status==='pending_confirmation');if(!list.length)wrap.appendChild(el('div',{class:'nori-v27-empty',text:'No pending actions.'}));else list.forEach(p=>wrap.appendChild(proposalCard(p)));
    }else if(tab==='history'){const ops=c.operations();if(!ops.length)wrap.appendChild(el('div',{class:'nori-v27-empty',text:'No executed actions yet.'}));ops.forEach(o=>{const box=el('div',{class:'nori-v27-card'});const row=el('div',{class:'nori-v27-row'});row.appendChild(el('div',{}));row.firstChild.appendChild(el('strong',{text:o.actionType}));row.firstChild.appendChild(el('div',{class:'nori-v27-small',text:new Date(o.at).toLocaleString()+' · '+o.id}));row.appendChild(el('span',{class:'nori-v27-chip '+o.status,text:o.status.toUpperCase()}));box.appendChild(row);box.appendChild(el('div',{class:'nori-v27-verify',text:(o.verification&&o.verification.ok?'✓ Verified':'Verification issue')+' · '+(o.verification&&o.verification.label||'')}));const acts=el('div',{class:'nori-v27-actions'});if(o.status==='executed')acts.appendChild(button('UNDO','danger',()=>{if(confirm('Undo this action?')){const r=c.undo(o.id);alert(r.ok?'Undone.':'Undo failed: '+r.reason);render()}}));box.appendChild(acts);wrap.appendChild(box)});
    }else{const a=loadAudit();if(!a.length)wrap.appendChild(el('div',{class:'nori-v27-empty',text:'No audit records.'}));a.slice().reverse().forEach(x=>{const box=el('div',{class:'nori-v27-row'});box.appendChild(el('div',{}));box.firstChild.appendChild(el('strong',{text:x.type||'event'}));box.firstChild.appendChild(el('div',{class:'nori-v27-small',text:new Date(x.at).toLocaleString()}));box.appendChild(el('div',{class:'nori-v27-small',text:x.proposalId||x.operationId||''}));wrap.appendChild(box)});}}
  function loadAudit(){try{return JSON.parse(localStorage.getItem('nori_action_core_v27/operations')||'[]')}catch(e){return[]}}
  function parseAndPropose(text){const p=C().parseText(text);if(!p){alert('Nori could not safely convert that request into a structured action. No change was made.');return null}render();return p}
  g.NoriActionCenterV27={open:render,parseAndPropose,render};
  function launcher(){if(document.getElementById('nori-v27-launch'))return;const b=button('A','',render);b.id='nori-v27-launch';b.title='Nori Action Center';document.body.appendChild(b)}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',launcher);else launcher();
})(window);
