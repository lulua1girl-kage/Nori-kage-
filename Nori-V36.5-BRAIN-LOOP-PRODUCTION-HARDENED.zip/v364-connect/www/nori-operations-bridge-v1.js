/* NORI OPERATIONS BRIDGE V1 — one web entry point for durable local operations. */
(function(g){'use strict';
 function p(){return g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.NoriOperations?g.Capacitor.Plugins.NoriOperations:null;}
 const api={
  available:()=>!!p(),
  capabilities:()=>{const x=p();return x?x.capabilities():Promise.reject(new Error('Nori Operations native bridge unavailable'));},
  commandCenter:()=>{const x=p();return x?x.commandCenter():Promise.reject(new Error('Nori Operations native bridge unavailable'));},
  addTask:o=>p().addTask(o||{}), addAssignment:o=>p().addAssignment(o||{}), addExam:o=>p().addExam(o||{}),
  complete:id=>p().complete({id}), checkIn:o=>p().checkIn(o||{}), recover:()=>p().recover(), search:q=>p().search({query:q||''}),
  explain:q=>p().explain({recommendation:q||'current recommendation'}), exportData:()=>p().exportData(),
  confirm:id=>p().confirm({proposalId:id}), plan:o=>p().plan(o||{})
 };
 g.NoriOperations=api;
 g.NoriCommandIntents=g.NoriCommandIntents||{};
 const intents=[
  ['add task','#/tasks'],['new task','#/tasks'],['add assignment','#/tasks'],['new assignment','#/tasks'],['add exam','#/exams'],['new exam','#/exams'],
  ['command center','#/'],['today plan','#/command'],['recover','#/recover'],['recovery','#/recover'],['timeline','#/timeline'],['search nori','#/command']
 ];
 function norm(s){return String(s||'').toLowerCase().replace(/[^a-z0-9 ]+/g,' ').replace(/\s+/g,' ').trim();}
 g.NoriOperationsIntentRouter=function(text){
   const n=norm(text);
   for(const x of intents)if(n===x[0]||n.includes(x[0])){
     if(g.NoriIntegrationCoreV31)return g.NoriIntegrationCoreV31.dispatch({source:'operations',text:String(text||''),args:{route:x[1]},type:'OPEN_APP'});
     if(g.NoriNavigationBrain&&g.NoriNavigationBrain.go)g.NoriNavigationBrain.go(x[1]);else location.hash=x[1];
     return {ok:true,route:x[1]};
   }
   return {ok:false};
 };
})(window);
