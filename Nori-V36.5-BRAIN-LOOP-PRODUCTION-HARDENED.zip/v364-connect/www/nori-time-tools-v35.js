/* NORI V35 — TIME TOOLS: timer + stopwatch + math-speed recorder. */
(function(g){'use strict';
 const TIMER_KEY='nori_timer_v35', SPEED_KEY='nori_math_speed_v35';
 let timerHandle=null, watchHandle=null;
 const now=()=>Date.now();
 const load=(k,d)=>{try{const v=JSON.parse(localStorage.getItem(k)||'null');return v==null?d:v}catch(_){return d}};
 const save=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch(_){return false}};
 const speak=t=>{try{if(typeof g.noriSpeak==='function')g.noriSpeak(t)}catch(_){}};
 const emit=(type,payload)=>{try{g.NoriOperatingProtocolV32?.emit(type,payload,{source:'time-tools-v35'})}catch(_){}try{g.dispatchEvent(new CustomEvent('nori:time-tool',{detail:{type,payload}}))}catch(_) {}}
 function clearTimer(){if(timerHandle){clearTimeout(timerHandle);timerHandle=null;}}
 function timerState(){return load(TIMER_KEY,null)}
 function setTimer(seconds,label){seconds=Math.max(1,Math.min(86400,Math.round(Number(seconds)||0)));clearTimer();const s={id:'timer_'+now().toString(36),label:String(label||'Nori timer'),durationSeconds:seconds,startedAt:new Date().toISOString(),endsAt:new Date(now()+seconds*1000).toISOString(),status:'running'};save(TIMER_KEY,s);emit('timer.started',s);speak('Start.');try{if(typeof g.noriReminderSchedule==='function')g.noriReminderSchedule(s.label,s.label+' is complete.',new Date(s.endsAt),'nori_timer_v35')}catch(_){}timerHandle=setTimeout(()=>{const x=timerState();if(!x||x.id!==s.id)return;x.status='completed';x.completedAt=new Date().toISOString();save(TIMER_KEY,x);timerHandle=null;emit('timer.completed',x);speak('Stop. '+x.label+' is complete.');if(typeof g.noriNotificationRecord==='function')g.noriNotificationRecord({type:'timer',priority:'action',title:'NORI TIMER',body:x.label+' is complete.',source:'time-tools'});},seconds*1000);return s;}
 function stopTimer(){const s=timerState();if(!s||s.status!=='running')return {ok:false,reason:'no_running_timer'};clearTimer();s.status='stopped';s.stoppedAt=new Date().toISOString();s.elapsedSeconds=Math.max(0,Math.round((now()-new Date(s.startedAt).getTime())/1000));save(TIMER_KEY,s);emit('timer.stopped',s);speak('Stop.');return {ok:true,state:s};}
 function watchState(){return load('nori_math_stopwatch_v35',null)}
 function startStopwatch(problemCount,subject){if(watchHandle)stopStopwatch(false);const s={id:'mathspeed_'+now().toString(36),subject:String(subject||'Mathematics'),problemCount:Math.max(1,Math.min(1000,Number(problemCount)||1)),startedAt:new Date().toISOString(),status:'running'};save('nori_math_stopwatch_v35',s);emit('math_speed.started',s);speak('Start.');watchHandle=setInterval(()=>{const x=watchState();if(x&&x.status==='running')emit('math_speed.tick',{elapsedSeconds:Math.floor((now()-new Date(x.startedAt).getTime())/1000)});},1000);return s;}
 function stopStopwatch(sayStop=true){const s=watchState();if(!s||s.status!=='running')return {ok:false,reason:'no_running_stopwatch'};if(watchHandle){clearInterval(watchHandle);watchHandle=null}const elapsed=Math.max(0,(now()-new Date(s.startedAt).getTime())/1000);s.status='completed';s.stoppedAt=new Date().toISOString();s.elapsedSeconds=Number(elapsed.toFixed(2));s.secondsPerProblem=Number((elapsed/s.problemCount).toFixed(2));s.problemsPerMinute=Number((s.problemCount/(elapsed/60)).toFixed(2));const history=load(SPEED_KEY,[]);history.push(s);save(SPEED_KEY,history.slice(-200));localStorage.removeItem('nori_math_stopwatch_v35');emit('math_speed.completed',s);if(sayStop)speak('Stop.');return {ok:true,state:s};}
 function history(){return load(SPEED_KEY,[])}
 // Voice and text both emit the same control event. A plain "stop" is
 // intentionally sufficient when a time operation is active.
 function handleControlText(text){
   const t=String(text||'').trim().toLowerCase();
   if(!/^stop$/.test(t))return {ok:false,handled:false};
   const w=watchState(); if(w&&w.status==='running')return Object.assign(stopStopwatch(true),{handled:true,control:'math_stopwatch'});
   const tm=timerState(); if(tm&&tm.status==='running')return Object.assign(stopTimer(),{handled:true,control:'timer'});
   return {ok:false,handled:false,reason:'no_active_time_operation'};
 }
 if(typeof g.addEventListener==='function'){
  // The unified V35 voice orchestrator enters NoriOperativeV33 directly.
  // Keep only the generic operative-text fallback for integrations that emit
  // text without going through that orchestrator.
  g.addEventListener('nori:operative-text',function(e){try{const raw=e&&e.detail&&(e.detail.text||'');handleControlText(raw);}catch(_){} });
 }
 function render(){
  const w=noriEl('div',{class:'nori-screen nori-time-tools'});w.appendChild(noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:'TIME TOOLS'}]));
  const top=noriEl('section',{class:'nori-section-card'});top.appendChild(noriEl('div',{class:'nori-section-head'},[noriEl('h2',{text:'Timer & Stopwatch'}),noriEl('span',{class:'nori-state-chip planned',text:'BRAIN CONNECTED'})]));top.appendChild(noriEl('p',{class:'nori-brief-main',text:'Use a timer for timed work or a stopwatch to record Mathematics speed. Nori speaks Start when timing begins and Stop when it ends.'}));
  const grid=noriEl('div',{class:'nori-time-grid'});
  const timer=noriEl('section',{class:'nori-time-card'});timer.innerHTML='<small>TIMER</small><h3 id="nori-timer-display">--:--</h3>';const mins=noriEl('input',{type:'number',min:'1',max:'1440',value:'25',placeholder:'Minutes'});const tl=noriEl('input',{type:'text',value:'Study timer',placeholder:'Label'});const ta=noriEl('div',{class:'nori-inline-actions'});const ts=noriEl('button',{class:'nori-btn nori-btn-primary',text:'START TIMER'}),tx=noriEl('button',{class:'nori-btn nori-btn-ghost',text:'STOP'});ts.onclick=()=>{setTimer(Number(mins.value)*60,tl.value);paint()};tx.onclick=()=>{stopTimer();paint()};ta.append(ts,tx);timer.append(mins,tl,ta);grid.appendChild(timer);
  const sw=noriEl('section',{class:'nori-time-card'});sw.innerHTML='<small>MATH SPEED STOPWATCH</small><h3 id="nori-watch-display">00:00.00</h3>';const pc=noriEl('input',{type:'number',min:'1',max:'1000',value:'10',placeholder:'Problems'});const sa=noriEl('div',{class:'nori-inline-actions'});const ss=noriEl('button',{class:'nori-btn nori-btn-primary',text:'START MATH SPEED'}),sx=noriEl('button',{class:'nori-btn nori-btn-ghost',text:'STOP WATCH'});ss.onclick=()=>{startStopwatch(Number(pc.value),'Mathematics');paint()};sx.onclick=()=>{const r=stopStopwatch(true);if(r.ok)alert('Recorded '+r.state.problemCount+' problems in '+r.state.elapsedSeconds+' seconds · '+r.state.secondsPerProblem+' s/problem.');paint()};sa.append(ss,sx);sw.append(pc,sa);grid.appendChild(sw);top.appendChild(grid);w.appendChild(top);
  const hist=noriEl('section',{class:'nori-section-card'});hist.appendChild(noriEl('div',{class:'nori-section-head'},[noriEl('h2',{text:'Math Speed History'})]));const rows=noriEl('div',{class:'nori-verification-list'});history().slice().reverse().slice(0,12).forEach(x=>{const r=noriEl('div',{class:'nori-verification-row'});r.append(noriEl('strong',{text:x.problemCount+' problems · '+x.secondsPerProblem+' s/problem'}),noriEl('small',{text:x.elapsedSeconds+' seconds · '+x.problemsPerMinute+' problems/min'}));rows.appendChild(r)});if(!rows.children.length)rows.appendChild(noriEl('div',{class:'nori-command-empty',text:'No speed recordings yet.'}));hist.appendChild(rows);w.appendChild(hist);w.appendChild(noriBottomNav('tracker'));return w;
 }
 function paint(){const t=timerState(),w=watchState();const td=document.getElementById('nori-timer-display'),wd=document.getElementById('nori-watch-display');if(td){let sec=t&&t.status==='running'?Math.max(0,Math.ceil((new Date(t.endsAt)-now())/1000)):0;td.textContent=Math.floor(sec/60).toString().padStart(2,'0')+':'+(sec%60).toString().padStart(2,'0')}if(wd){let sec=w&&w.status==='running'?(now()-new Date(w.startedAt).getTime())/1000:(w&&w.elapsedSeconds)||0;wd.textContent=Math.floor(sec/60).toString().padStart(2,'0')+':'+(sec%60).toFixed(2).padStart(5,'0')}}
 function restoreTimer(){const s=timerState();if(!s||s.status!=='running')return;const left=new Date(s.endsAt).getTime()-now();if(left<=0){s.status='completed';s.completedAt=new Date().toISOString();save(TIMER_KEY,s);speak('Stop. '+s.label+' is complete.');emit('timer.completed',s);return;}clearTimer();timerHandle=setTimeout(()=>{const x=timerState();if(!x||x.id!==s.id)return;x.status='completed';x.completedAt=new Date().toISOString();save(TIMER_KEY,x);timerHandle=null;emit('timer.completed',x);speak('Stop. '+x.label+' is complete.');if(typeof g.noriNotificationRecord==='function')g.noriNotificationRecord({type:'timer',priority:'action',title:'NORI TIMER',body:x.label+' is complete.',source:'time-tools'});},left)}
 function tick(){paint();if(!document.getElementById('nori-timer-display')&&!document.getElementById('nori-watch-display'))return;setTimeout(tick,250)}
 restoreTimer();
 g.NoriTimeToolsV35={setTimer,stopTimer,startStopwatch,stopStopwatch,timerState,watchState,history,render,paint};
 if(g.noriEl&&document.readyState!=='loading')tick();else document.addEventListener('DOMContentLoaded',tick);
})(window);
