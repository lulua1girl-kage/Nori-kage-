/* NORI VISUAL SYSTEM V1 — presentation layer only.
   Keeps command/brain logic intact while adding a fast, calm, premium UI. */
(function(){
  'use strict';
  var KEY='nori_visual_theme_v1';
  function el(tag, cls, text){var x=document.createElement(tag);if(cls)x.className=cls;if(text!=null)x.textContent=text;return x;}
  function theme(){return localStorage.getItem(KEY)||'dark';}
  function applyTheme(){document.documentElement.setAttribute('data-nori-theme',theme());}
  function toggleTheme(){localStorage.setItem(KEY,theme()==='dark'?'light':'dark');applyTheme();}
  function status(){
    try{
      if(typeof noriGetContextDecision==='function'){
        var d=noriGetContextDecision(); if(d&&d.mode)return d.mode;
      }
      if(typeof noriGetSmartContext==='function'){var c=noriGetSmartContext();if(c&&c.mode)return c.mode;}
    }catch(e){}
    var h=new Date().getHours(); if(h>=22||h<6)return 'sleep'; return 'normal';
  }
  function statusLabel(s){return ({sleep:'SLEEP PROTECTION',study:'FOCUSED',exam_enhanced:'EXAM PROTECTION',exam_final:'FINAL EXAM',recovery:'RECOVERING',normal:'NORMAL'}[s]||String(s||'READY').replace(/_/g,' ').toUpperCase());}
  function addControls(header){
    var controls=el('div','nori-visual-controls');
    var statusPill=el('span','nori-visual-status');
    var dot=el('i','nori-status-dot'); statusPill.appendChild(dot); statusPill.appendChild(el('span','',statusLabel(status())));
    controls.appendChild(statusPill);
    var themeBtn=el('button','nori-visual-icon-btn',theme()==='dark'?'LIGHT':'DARK'); themeBtn.title='Toggle appearance'; themeBtn.onclick=toggleTheme; controls.appendChild(themeBtn);
    if(typeof noriListenOnce==='function'){
      var voice=el('button','nori-visual-voice','VOICE'); voice.title='Start one voice command';
      voice.onclick=function(){
        voice.disabled=true; voice.classList.add('is-listening'); voice.textContent='LISTENING';
        Promise.resolve(noriListenOnce()).then(function(t){voice.classList.remove('is-listening');voice.textContent='VOICE';voice.disabled=false;if(t&&typeof noriSpeak==='function')noriSpeak('I heard: '+t);}).catch(function(){voice.classList.remove('is-listening');voice.textContent='VOICE';voice.disabled=false;});
      }; controls.appendChild(voice);
    }
    header.appendChild(controls);
  }
  function enhanceHeader(){
    if(typeof window.noriRenderCommandHeader!=='function'||window.__noriVisualHeaderWrapped)return;
    var base=window.noriRenderCommandHeader;
    window.noriRenderCommandHeader=function(active){
      var h=base(active); h.classList.add('nori-visual-header');
      var old=h.querySelector('.nori-visual-controls');if(old)old.remove(); addControls(h);
      return h;
    }; window.__noriVisualHeaderWrapped=true;
  }

  function affectAvatar(emotion){
    var root=document.getElementById('nori-app'); if(!root)return;
    root.setAttribute('data-nori-affect',emotion||'calm');
    var nodes=root.querySelectorAll('.nori-affect-ring');
    if(!nodes.length){
      var a=el('div','nori-affect-ring'); a.setAttribute('aria-hidden','true');
      a.appendChild(el('i','nori-affect-core')); root.appendChild(a);
    }
  }
  function noriVisualSetAffect(emotion){affectAvatar(emotion);}

  function commandHero(root){
    if(!root||root.querySelector('.nori-visual-command-card'))return;
    var first=root.querySelector('.nori-brief-card');
    var card=el('section','nori-visual-command-card');
    var eyebrow=el('div','nori-visual-eyebrow','NORI / NEXT MOVE');
    var title=el('h1','nori-visual-command-title','Your next move');
    var sub=el('p','nori-visual-command-sub','Nori is ready.');
    try{
      if(typeof noriRenderTodayLive==='function'){var s=noriRenderTodayLive();sub.textContent=s&&s.text?s.text:'Nori is ready.';}
    }catch(e){}
    var actions=el('div','nori-visual-command-actions');
    var start=el('a','nori-visual-primary','OPEN COMMAND');start.href='#/command';actions.appendChild(start);
    var details=el('button','nori-visual-secondary','WHY?');details.onclick=function(){
      var p=root.querySelector('.nori-brief-main'); if(p)p.scrollIntoView({behavior:'smooth',block:'center'});
      if(first)first.classList.toggle('nori-visual-expanded');
    };actions.appendChild(details);
    var meta=el('div','nori-visual-command-meta');meta.appendChild(el('span','',statusLabel(status())));meta.appendChild(el('span','',new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})));card.appendChild(eyebrow);card.appendChild(title);card.appendChild(sub);card.appendChild(actions);card.appendChild(meta);
    root.insertBefore(card,root.querySelector('.nori-quote')||first||root.firstChild);
  }
  function layerToggle(root){
    if(!root||root.querySelector('.nori-visual-layers'))return;
    var box=el('section','nori-visual-layers');
    var head=el('div','nori-visual-layer-head');head.appendChild(el('strong','','SYSTEM DETAIL'));var b=el('button','nori-visual-secondary','SHOW');head.appendChild(b);box.appendChild(head);
    var body=el('div','nori-visual-layer-body');body.hidden=true;
    body.innerHTML='<div><b>COMMAND</b><span>What Nori recommends right now.</span></div><div><b>STATE</b><span>Context, deadlines, protection and evidence.</span></div><div><b>SYSTEM</b><span>Local engines, sync and native services.</span></div>';
    b.onclick=function(){body.hidden=!body.hidden;b.textContent=body.hidden?'SHOW':'HIDE';};box.appendChild(body);root.appendChild(box);
  }
  function decorate(){
    applyTheme();
    var root=document.getElementById('nori-app');if(!root)return;
    root.classList.add('nori-visual-root');
    commandHero(root); layerToggle(root);
    root.querySelectorAll('.nori-btn').forEach(function(b){b.classList.add('nori-fast-action');});
  }
  function installRouteHook(){
    if(typeof window.noriRoute!=='function'||window.__noriVisualRouteWrapped)return;
    var base=window.noriRoute;
    window.noriRoute=function(){base.apply(this,arguments);setTimeout(decorate,0);};window.__noriVisualRouteWrapped=true;
  }
  applyTheme();
  enhanceHeader();
  installRouteHook();
  window.noriVisualSystem={applyTheme:applyTheme,toggleTheme:toggleTheme,refresh:decorate,setAffect:noriVisualSetAffect};
  window.noriVisualSetAffect=noriVisualSetAffect;
  setTimeout(function(){enhanceHeader();installRouteHook();decorate();},0);
  window.addEventListener('hashchange',function(){setTimeout(function(){enhanceHeader();installRouteHook();decorate();},0);});
})();
