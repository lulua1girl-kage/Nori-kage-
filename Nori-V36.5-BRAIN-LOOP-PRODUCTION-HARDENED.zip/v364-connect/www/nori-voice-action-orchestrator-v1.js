/* NORI Voice-to-Action Academic Orchestrator — additive Step 7 layer. */
(function(g){'use strict';
 const plugin=()=>g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.NoriVoice;
 const exam=()=>g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.NoriExamIntegrity;
 const visual=()=>g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.NoriVisual;
 function openWorkspace(mode){
   const p=plugin(); if(p&&p.openWorkspace){p.openWorkspace({mode}).catch(()=>{});} else if(typeof g.noriRoute==='function'){ try{g.noriRoute('meet');}catch(e){} }
   return mode;
 }
 async function startExamIntegrity(){const p=exam();if(!p)throw new Error('Exam integrity is native-only.');return p.start();}
 async function stopExamIntegrity(){const p=exam();if(p)return p.stop();}
 async function statusExamIntegrity(){const p=exam();return p?p.status():{active:false};}
 async function onCommand(d){
   const raw=String((d&&d.text)||''); const parts=raw.split('|'); const type=parts[0];
   if(window.NoriWorldWeb&&window.NoriWorldWeb.handle(raw)) return;
   const detail={type,target:parts.slice(1).join('|'),raw:raw,text:raw};
   /* V31: voice commands enter the same intent/event pipeline as typed input.
      Legacy workspace behavior remains only as a fallback for commands that
      are not executable capabilities yet. */
   // V35: voice and text use the same operative entry point. Legacy event
   // routing remains only when the operative layer treats the utterance as
   // ordinary conversation/unsupported legacy control.
   let operativeHandled=false;
   if(g.NoriOperativeV33&&typeof g.NoriOperativeV33.handleText==='function'){
     try{
       const result=await g.NoriOperativeV33.handleText(raw,{source:'voice',sessionId:'default'});
       operativeHandled=!!(result&&result.status&&result.status!=='conversation');
     }catch(_){}
   }
   if(!operativeHandled && g.NoriIntegrationCoreV31){
     g.NoriIntegrationCoreV31.dispatch({source:'voice',type:type,text:raw,args:{target:detail.target}})
       .catch(function(){});
   }
   g.dispatchEvent(new CustomEvent('nori:voice-command',{detail:detail}));
   if(type==='START_EXAM_MODE' && typeof g.noriMeetSendText==='function') g.noriMeetSendText('Exam mode detected. I will use the explicit exam-integrity monitor: foreground-app signals first, screen review only when a suspicious trigger occurs.');
   if(type==='RETURN_TO_CHAT' && typeof g.noriRoute==='function') g.noriRoute('meet');
 }
 async function bind(){const p=plugin();if(p&&p.addListener)await p.addListener('command',onCommand);}
 g.NoriVoiceActionOrchestrator={openWorkspace,startExamIntegrity,stopExamIntegrity,statusExamIntegrity,bind};
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bind);else bind();
})(window);
