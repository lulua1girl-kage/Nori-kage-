/* NORI INTELLIGENCE V20
 * Analytics + Privacy/Control layer.
 * Local-first, evidence-based, no surveillance, Human Override preserved.
 */
(function(g){'use strict';
  var PRIV='nori_privacy_controls_v20';
  var CACHE={at:0,data:null};
  function parse(k,fb){try{var v=JSON.parse(localStorage.getItem(k)||'null');return v==null?fb:v}catch(e){return fb}}
  function save(k,v){try{return typeof noriSafeWrite==='function'?noriSafeWrite(k,v):(localStorage.setItem(k,JSON.stringify(v)),true)}catch(e){return false}}
  function arr(v){return Array.isArray(v)?v:[]}
  function now(){return new Date()}
  function dayKey(d){return new Date(d||Date.now()).toISOString().slice(0,10)}
  function dateOf(x){var d=new Date(x||0);return isNaN(d.getTime())?null:d}
  function daysBetween(a,b){return Math.floor((b-a)/86400000)}
  function state(){
    return {
      results:typeof noriHistoryLoadAll==='function'?noriHistoryLoadAll():parse('nori_eval_history_all_subjects',{}),
      exams:typeof noriExamsLoad==='function'?noriExamsLoad():parse('nori_exams',[]),
      assignments:typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():parse('nori_command_assignments',[]),
      sessions:typeof noriStudySessionsLoad==='function'?noriStudySessionsLoad():parse('nori_study_sessions',[]),
      events:parse('nori_brain_events_v12',[]).concat(parse('nori_adaptive_kage_events_v19',[]))
    }
  }
  function resultScore(r){var n=Number(r&&r.score);return isFinite(n)?n:null}
  function sessionMinutes(s){return Math.max(0,Number(s&&s.actualMinutes!=null?s.actualMinutes:s&&s.minutes!=null?s.minutes:0)||0)}
  function sessionCompleted(s){return /complete|completed|done|finished|verified|success/i.test(String(s&&s.status||s&&s.state||s&&s.outcome||'')) || (s&&s.completed===true)}
  function sessionPlanned(s){return !!s && (s.planned===true || s.status==='planned' || s.expectedMinutes!=null || s.planId!=null || s.scheduled===true)}
  function subjectStats(st){
    var out={};
    Object.keys(st.results||{}).forEach(function(sub){
      var rows=arr(st.results[sub]);
      var scores=rows.map(resultScore).filter(function(x){return x!=null});
      var recent=scores.slice(-5),prev=scores.slice(-10,-5);
      out[sub]={tests:scores.length,latest:scores.length?scores[scores.length-1]:null,recentAverage:recent.length?+(recent.reduce(function(a,b){return a+b},0)/recent.length).toFixed(1):null,previousAverage:prev.length?+(prev.reduce(function(a,b){return a+b},0)/prev.length).toFixed(1):null,trend:recent.length&&prev.length?+((recent.reduce(function(a,b){return a+b},0)/recent.length)-(prev.reduce(function(a,b){return a+b},0)/prev.length)).toFixed(1):0};
    });
    st.sessions.forEach(function(s){var sub=s.subject||'Unassigned';out[sub]=out[sub]||{tests:0,latest:null,recentAverage:null,previousAverage:null,trend:0};out[sub].studyMinutes=(out[sub].studyMinutes||0)+sessionMinutes(s);out[sub].completedSessions=(out[sub].completedSessions||0)+(sessionCompleted(s)?1:0);out[sub].sessionCount=(out[sub].sessionCount||0)+1});
    st.assignments.forEach(function(a){var sub=a.subject||'Unassigned';out[sub]=out[sub]||{};if(a.status!=='done')out[sub].openAssignments=(out[sub].openAssignments||0)+1});
    return out;
  }
  function completionReliability(st,from,to){
    var rows=st.sessions.filter(function(s){var d=dateOf(s.date||s.startedAt||s.createdAt);return d&&d>=from&&d<=to});
    var planned=rows.filter(sessionPlanned).length, completed=rows.filter(sessionCompleted).length;
    var plannedMinutes=rows.filter(sessionPlanned).reduce(function(a,s){return a+Number(s.minutes||s.expectedMinutes||0)},0);
    var completedMinutes=rows.filter(sessionCompleted).reduce(function(a,s){return a+sessionMinutes(s)},0);
    return {planned:planned,completed:completed,reliability:planned?Math.round(completed/planned*100):null,plannedMinutes:plannedMinutes,completedMinutes:completedMinutes,rows:rows};
  }
  function failurePattern(st,rows){
    var counts={};
    rows.forEach(function(s){
      var raw=String(s.failurePattern||s.failure||s.reason||s.outcome||s.status||'').toLowerCase();
      var key=/late|delay|start/.test(raw)?'late starts':/miss|skip|avoid/.test(raw)?'missed/avoided sessions':/interrupt|family|school|conflict/.test(raw)?'external disruption':/capacity|tired|overload/.test(raw)?'capacity limitation':sessionCompleted(s)?'none recorded':'unclassified';
      counts[key]=(counts[key]||0)+1;
    });
    var best='none recorded',n=0;Object.keys(counts).forEach(function(k){if(k!=='none recorded'&&counts[k]>n){best=k;n=counts[k]}});
    return {pattern:best,count:n,counts:counts};
  }
  function weekly(start){
    var st=state(),end=new Date(start||Date.now());end.setHours(23,59,59,999);var from=new Date(end);from.setDate(from.getDate()-6);from.setHours(0,0,0,0);
    var rel=completionReliability(st,from,end), stats=subjectStats(st), results=[];
    Object.keys(st.results||{}).forEach(function(sub){arr(st.results[sub]).forEach(function(r){var d=dateOf(r.date||r.createdAt);if(d&&d>=from&&d<=end){var sc=resultScore(r);if(sc!=null)results.push({subject:sub,score:sc,date:d})}})});
    var avg=results.length?+(results.reduce(function(a,x){return a+x.score},0)/results.length).toFixed(1):null;
    var ranked=Object.keys(stats).map(function(sub){var x=stats[sub];return {subject:sub,trend:x.trend||0,average:x.recentAverage,studyMinutes:x.studyMinutes||0,openAssignments:x.openAssignments||0}}).sort(function(a,b){return (b.trend||0)-(a.trend||0)});
    var improved=ranked.filter(function(x){return x.trend>2}).slice(0,3),deteriorated=ranked.filter(function(x){return x.trend<-2}).slice(0,3);
    var failure=failurePattern(st,rel.rows);
    return {period:{start:dayKey(from),end:dayKey(end)},metrics:{studyMinutes:rel.completedMinutes,studySessions:rel.rows.length,planned:rel.planned,completed:rel.completed,reliability:rel.reliability,averageScore:avg},improved:improved,deteriorated:deteriorated,mainFailurePattern:failure,nextWeek:nextWeek(st),ignore:ignoreList(st),evidenceNote:'Trend and cause signals describe recorded temporal associations; they do not prove causation or diagnose the student.'};
  }
  function nextWeek(st){
    var stats=subjectStats(st),exams=arr(st.exams).filter(function(e){var d=dateOf((e.date||'')+'T23:59:59');return d&&d>=now()}).sort(function(a,b){return new Date(a.date)-new Date(b.date)});
    var weak=Object.keys(stats).sort(function(a,b){return ((stats[b].openAssignments||0)+(stats[b].trend<0?2:0)+(stats[b].recentAverage==null?1:0))-((stats[a].openAssignments||0)+(stats[a].trend<0?2:0)+(stats[a].recentAverage==null?1:0))}).slice(0,3);
    return {focusSubjects:weak,upcomingExams:exams.slice(0,3).map(function(e){return {subject:e.subject||'Academic',date:e.date,title:e.title||'Exam'}}),principle:'Protect imminent deadlines first, then repair persistent weak areas.'};
  }
  function ignoreList(st){
    var noise=arr(st.events).filter(function(e){return /other|general|chat|ui|heartbeat/i.test(String(e.type||e.kind||''))}).length;
    return noise>0?['Unrelated UI/noise events that do not affect academic decisions.']:['No major low-value category identified from recorded data.'];
  }
  function causeAnalysis(subject){
    var st=state(),rows=arr(st.results&&st.results[subject]),sessions=st.sessions.filter(function(s){return (s.subject||'')===subject}).sort(function(a,b){return new Date(a.date||a.createdAt||0)-new Date(b.date||b.createdAt||0)});
    var findings=[];
    rows.forEach(function(r,i){var d=dateOf(r.date||r.createdAt),score=resultScore(r);if(!d||score==null)return;var prior=sessions.filter(function(s){var sd=dateOf(s.date||s.createdAt);return sd&&sd<d}).slice(-3),missed=prior.filter(function(s){return !sessionCompleted(s)}).length;if(missed>=2)findings.push({date:dayKey(d),score:score,precedingMissedSessions:missed,statement:'A lower-performance result followed '+missed+' missed recorded sessions.',strength:'temporal association',notProofOfCausation:true})});
    return {subject:subject,findings:findings.slice(-8),note:'This is temporal pattern analysis. It does not establish that missed sessions caused a grade change.'};
  }
  function dashboard(){
    if(CACHE.data&&Date.now()-CACHE.at<1500)return CACHE.data;
    var st=state(),stats=subjectStats(st),today=new Date();var from=new Date(today);from.setDate(from.getDate()-6);from.setHours(0,0,0,0);var rel=completionReliability(st,from,today);
    var rows=Object.keys(stats).map(function(sub){var x=stats[sub]||{};return {subject:sub,grade:x.recentAverage,trend:x.trend||0,studyMinutes:x.studyMinutes||0,openAssignments:x.openAssignments||0,sessionCompletion:x.sessionCount?Math.round(x.completedSessions/x.sessionCount*100):null}}).sort(function(a,b){return (a.grade==null?999:a.grade)-(b.grade==null?999:b.grade)});
    var d={generatedAt:new Date().toISOString(),subjects:rows,overall:{studyMinutes:st.sessions.reduce(function(a,s){return a+sessionMinutes(s)},0),studyMinutes7d:rel.completedMinutes,planned7d:rel.planned,completed7d:rel.completed,reliability7d:rel.reliability,assignments:st.assignments.length,openAssignments:st.assignments.filter(function(a){return a.status!=='done'}).length,exams:st.exams.length},weakSubjects:rows.filter(function(x){return x.grade!=null&&x.grade<80}).slice(0,5).map(function(x){return x.subject}),trend:weekly(today)};
    CACHE={at:Date.now(),data:d};return d;
  }
  function controls(){return Object.assign({privateMode:false,sendConversationHistory:true,sendAcademicState:true,webSearchExplicitOnly:true,sensitiveMemoryFirewall:true,hiddenRecording:false,silentSurveillance:false,localFirst:true,apiKeysServerSideOnly:true},parse(PRIV,{}))}
  function setControl(k,v){var c=controls();if(['webSearchExplicitOnly','sensitiveMemoryFirewall','hiddenRecording','silentSurveillance','localFirst','apiKeysServerSideOnly'].indexOf(k)>=0)v=(k==='webSearchExplicitOnly'||k==='sensitiveMemoryFirewall'||k==='localFirst'||k==='apiKeysServerSideOnly')?true:false;c[k]=!!v;save(PRIV,c);if(g.noriConversationV2&&g.noriConversationV2.setPrivateMode)g.noriConversationV2.setPrivateMode(c.privateMode);return c}
  function privacyStatus(){
    var c=controls();var exposed=false;try{exposed=Object.keys(g).some(function(k){return /GEMINI_API_KEY|OPENAI_API_KEY|ANTHROPIC_API_KEY/i.test(k)})}catch(e){}
    return {controls:c,checks:{noSilentWeb:c.webSearchExplicitOnly,noHiddenRecording:!c.hiddenRecording,noSilentSurveillance:!c.silentSurveillance,localFirst:c.localFirst,apiKeysServerSideOnly:c.apiKeysServerSideOnly&&!exposed,sensitiveFirewall:c.sensitiveMemoryFirewall},privateModeNote:'Private Mode keeps conversation history and memory out of the request context where possible; the current message still has to reach the configured AI provider to receive an AI response.'};
  }
  function clearConversation(){try{if(g.noriConversationV2&&g.noriConversationV2.clear)g.noriConversationV2.clear();return true}catch(e){return false}}
  function render(){
    var host=document.getElementById('nori-intelligence-v20');if(host){refresh();return}
    host=document.createElement('section');host.id='nori-intelligence-v20';host.className='nori-v20-panel';
    var title=document.createElement('h2');title.textContent='NORI INTELLIGENCE';host.appendChild(title);
    var sub=document.createElement('p');sub.textContent='Evidence dashboard + privacy control center. Local-first; Human Override remains highest authority.';host.appendChild(sub);
    var tabs=document.createElement('div');tabs.className='nori-v20-tabs';['Analytics','Privacy'].forEach(function(t){var b=document.createElement('button');b.textContent=t;b.onclick=function(){show(t)};tabs.appendChild(b)});host.appendChild(tabs);
    var body=document.createElement('div');body.id='nori-v20-body';host.appendChild(body);document.body.appendChild(host);show('Analytics');
    function show(which){body.innerHTML='';if(which==='Analytics'){var d=dashboard(),o=d.overall;body.innerHTML='<div class="nori-v20-grid"><article><b>Study time</b><strong>'+o.studyMinutes7d+' min</strong></article><article><b>Planned / completed</b><strong>'+o.planned7d+' / '+o.completed7d+'</strong></article><article><b>Reliability</b><strong>'+(o.reliability7d==null?'—':o.reliability7d+'%')+'</strong></article><article><b>Open assignments</b><strong>'+o.openAssignments+'</strong></article></div>';
      var h=document.createElement('div');h.className='nori-v20-list';h.innerHTML='<h3>Subject trends</h3>';d.subjects.forEach(function(x){var p=document.createElement('p');p.textContent=x.subject+': '+(x.grade==null?'no grade':x.grade+'%')+' · trend '+(x.trend>=0?'+':'')+x.trend+' · study '+x.studyMinutes+' min';h.appendChild(p)});body.appendChild(h);
      var w=document.createElement('div');w.className='nori-v20-list';w.innerHTML='<h3>Weekly intelligence</h3><p>Improved: '+(d.trend.improved.map(function(x){return x.subject}).join(', ')||'none recorded')+'</p><p>Deteriorated: '+(d.trend.deteriorated.map(function(x){return x.subject}).join(', ')||'none recorded')+'</p><p>Main failure pattern: '+d.trend.mainFailurePattern.pattern+'</p><p>Next week: '+d.trend.nextWeek.focusSubjects.join(', ')+'</p><p>Ignore: '+d.trend.ignore.join(' ')+'</p>';body.appendChild(w);
      var c=document.createElement('button');c.textContent='Refresh analytics';c.onclick=function(){CACHE.at=0;show('Analytics')};body.appendChild(c);
    } else {var p=privacyStatus();body.innerHTML='<h3>Privacy & Control</h3>';Object.keys(p.controls).forEach(function(k){var label=document.createElement('label');label.className='nori-v20-control';var input=document.createElement('input');input.type='checkbox';input.checked=!!p.controls[k];input.disabled=['webSearchExplicitOnly','sensitiveMemoryFirewall','hiddenRecording','silentSurveillance','localFirst','apiKeysServerSideOnly'].indexOf(k)>=0;input.onchange=function(){setControl(k,input.checked);show('Privacy')};label.appendChild(input);label.appendChild(document.createTextNode(' '+k));body.appendChild(label)});var status=document.createElement('pre');status.textContent=JSON.stringify(p.checks,null,2);body.appendChild(status);var clear=document.createElement('button');clear.textContent='Clear private conversation context';clear.onclick=function(){clearConversation();show('Privacy')};body.appendChild(clear);}
    }
  }
  function refresh(){CACHE.at=0;var el=document.getElementById('nori-intelligence-v20');if(el)el.remove();render()}
  g.noriIntelligenceV20={dashboard:dashboard,weekly:weekly,causeAnalysis:causeAnalysis,privacyStatus:privacyStatus,controls:controls,setControl:setControl,clearConversation:clearConversation,render:render,refresh:refresh};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',function(){setTimeout(render,400)});else setTimeout(render,400);
})(window);
