# Background Voice

Added opt-in Android foreground microphone service, wake-word detection, active voice mode, native TTS, Capacitor bridge, and manifest requirements. No covert listening: Android shows an ongoing foreground-service notification while the microphone is active.
