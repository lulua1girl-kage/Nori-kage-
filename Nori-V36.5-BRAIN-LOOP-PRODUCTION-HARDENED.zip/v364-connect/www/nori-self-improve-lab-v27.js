/* NORI SELF-IMPROVEMENT LAB V27
   Sandbox/preview layer around the V26 allowlisted extension system.
   It does not edit protected source files. It validates proposed declarative
   extensions, shows a diff-like preview, and only hands an accepted extension
   to the existing V26 runtime after the existing confirmation flow.
*/
(function(g){'use strict';
  const KEY='nori_v27_self_improve_lab';
  const ALLOWED=['status_card','quick_action','calculator','navigation','insight_rule'];
  const load=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){return[]}};
  const save=x=>localStorage.setItem(KEY,JSON.stringify(x.slice(-100)));
  function validate(x){const errors=[];if(!x||typeof x!=='object')errors.push('Not an object.');if(ALLOWED.indexOf(x&&x.type)<0)errors.push('Type is not allowlisted.');if(typeof (x&&x.title)!=='string'||!x.title||x.title.length>100)errors.push('Title is missing or too long.');if(typeof (x&&x.description)!=='string'||x.description.length>500)errors.push('Description is missing or too long.');if(x&&x.payload&&typeof x.payload!=='object')errors.push('Payload must be declarative JSON.');return {ok:!errors.length,errors};}
  function preview(ext){const v=validate(ext);const row={at:new Date().toISOString(),title:ext&&ext.title||'',type:ext&&ext.type||'',valid:v.ok,errors:v.errors};const a=load();a.push(row);save(a);return row;}
  function open(){
    const ov=document.createElement('div'); ov.className='nori-v27-modal';
    const card=document.createElement('div'); card.className='nori-v27-modal-card';
    card.innerHTML='<div class="nori-v27-head"><div><div class="nori-v27-eyebrow">SANDBOX · PROTECTED BASE</div><h2>Self-Improvement Lab</h2></div><button class="nori-v27-btn">Close</button></div><p class="nori-v27-muted">Test declarative extensions before installation. Protected base files remain outside the writable extension layer.</p><div class="nori-v27-form"><label>Extension JSON<textarea id="nori-v27-ext-json" rows="10" placeholder="{\n  \"type\": \"status_card\",\n  \"title\": \"Example\",\n  \"description\": \"A useful additive card\",\n  \"payload\": {}\n}"></textarea></label></div><div id="nori-v27-lab-result"></div><div class="nori-v27-actions"><button id="nori-v27-lab-test" class="nori-v27-btn primary">RUN SANDBOX TEST</button><button id="nori-v27-lab-open" class="nori-v27-btn" disabled>OPEN V26 3-STEP APPLY</button></div>';
    ov.appendChild(card); document.body.appendChild(ov);
    card.querySelector('.nori-v27-head button').onclick=()=>ov.remove();
    const input=card.querySelector('#nori-v27-ext-json'), out=card.querySelector('#nori-v27-lab-result'), openApply=card.querySelector('#nori-v27-lab-open');
    let parsed=null;
    card.querySelector('#nori-v27-lab-test').onclick=()=>{
      try{
        parsed=JSON.parse(input.value);
        const r=preview(parsed);
        out.innerHTML='<div class="nori-v27-evidence"><strong>'+(r.valid?'SANDBOX PASS':'SANDBOX REJECTED')+'</strong><div class="nori-v27-muted">'+(r.valid?'No protected source is modified. This is an allowlisted declarative extension preview.':r.errors.join(' '))+'</div></div><div class="nori-v27-diff"><div><b>BASE</b><pre>Protected base\nNo source edits\nNo rule edits</pre></div><div><b>PROPOSED</b><pre>'+escapeHtml(JSON.stringify(parsed,null,2))+'</pre></div></div>';
        openApply.disabled=!r.valid;
        if(r.valid) openApply.onclick=()=>{ov.remove(); if(g.NoriSelfImproveV26)g.NoriSelfImproveV26.open(); else alert('V26 self-improvement flow is not loaded.');};
      }catch(e){parsed=null;openApply.disabled=true;out.textContent='Invalid JSON: '+e.message;}
    };
  }
  function escapeHtml(s){return String(s).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));}
  g.NoriSelfImproveLabV27={open,validate,preview,history:load,allowed:ALLOWED};
})(window);
