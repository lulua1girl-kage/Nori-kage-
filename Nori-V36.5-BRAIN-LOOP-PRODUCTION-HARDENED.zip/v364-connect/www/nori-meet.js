/* ==========================================================================
   NORI — MEET NORI (LISTENING & SPEAKING LAYER + BRAIN)
   ==========================================================================
   What this delivers:

     - CONTINUOUS listening that auto-restarts itself if the browser cuts
       it off, so it never feels like it "times out".
     - A live TRANSCRIPT BOX showing exactly what's being heard.
     - A separate, always-available TEXT INPUT — voice is optional.
     - MIC MUTING: while Nori is talking, the mic is muted by default so
       it can't pick up her own voice and interrupt itself. A checkbox
       lets you allow interrupting her on purpose, and a manual Mute
       button lets you silence the mic yourself at any time, independent
       of whether Nori is talking.
     - A QUICK ADD RESULT form (Result System + Award System + Human
       Override, all deterministic, no AI needed) and a REPORT BREACH form
       (System Integrity + Disciplinary System, same deal).
     - A real BRAIN, wired to api/brain.js: Gemini first, OpenAI as an
       automatic fallback if Gemini's free tier or anything else fails.
       Every message is grounded in the actual saved history (subject
       results, override claims, breach history) so the brain can't
       invent progress that isn't real — the deterministic tools above
       still own all actual scoring/saving; the brain talks, coaches,
       and explains, it doesn't classify.

   CONFIGURE THIS ONE LINE before deploying:
   ========================================================================== */
const NORI_BRAIN_ENDPOINT = NORI_API_BASE_URL + "/api/brain"; // base URL set once in nori-native-bridge.js

/* ========================================================================== */

const NORI_MEET_SUBJECTS = [
  "Mathematics", "Physics", "Chemistry", "Biology", "English", "Agriculture",
  "Web Development", "Information Technology"
];
// Note: the Phase 1 handbook PDF only ever had one combined "Web / IT" page,
// so there's a single Phase 1 storage form for it. Band/Degree HISTORY is
// tracked separately per subject (all 8), but both Web Development and
// Information Technology results save into that same shared Phase 1 form —
// that's a real constraint of the source PDF, not something invented here.
const NORI_MEET_SUBJECT_SLUGS = {
  "Mathematics": "mathematics", "Physics": "physics", "Chemistry": "chemistry",
  "Biology": "biology", "English": "english", "Agriculture": "agriculture",
  "Web Development": "web-it", "Information Technology": "web-it"
};
// Assessment types drawn directly from the handbook's own Assessment Categories
// (Continuous Assessment / Practical & Field Work / Evaluation Tasks / Major
// School Exams / Entrance Prep) — nothing invented beyond what it defines.
const NORI_MEET_ASSESSMENT_TYPES = [
  "Quiz", "Classwork", "Homework", "Participation", "Assignment", "Project",
  "Practical / Experiment", "Field work", "Mid-Semester Exam", "Final Exam", "Model Exam", "Other"
];

/* ---------------------------------------------------------------------
   CALCULATION ENGINE — percent + categorization only.
   NORI_MEET_BANDS, NORI_MEET_MERIT_POINTS, and NORI_MEET_DEGREE_ACTIONS now
   live in nori-rules.js, derived from the real nori-award-rules.json /
   nori-exam-result-rules.json at load time — the same JSON the AI backend
   reads. There is exactly one copy of this data now; this file used to
   keep a second hand-typed copy that had no way to stay in sync if the
   JSON ever changed.
   --------------------------------------------------------------------- */

/* ---------------------------------------------------------------------
   SUBJECT HISTORY — reads/writes go through noriHistoryLoadAll /
   noriHistoryAppend in nori-storage.js (the single canonical
   implementation, shared with nori-ai-evaluate.js), so Degree escalation
   works consistently whether a result came in by voice evaluation or by
   the quick form — no more risk of two copies drifting apart.
   --------------------------------------------------------------------- */

// Checks REAL, already-tracked evidence for whether recovery was actually
// completed for a subject — not a self-report field (the previous version
// of this had a `recoveryGateMet` flag that nothing in the app ever set,
// so it silently never fired). Uses two forms that already exist for
// exactly this purpose:
//   - Phase 5 Academic Backlog Tracker: any open (unverified) item for
//     this subject means backlog isn't cleared.
//   - Phase 5 Recovery Verification — Academic: the most recent entry's
//     row for this subject must be marked Verified.
// Still a simplification of the full recovery gate (which the handbook
// also ties to assignments current, Error Notebook updated, model-exam
// schedule, etc.) — but these two are the pieces this app has real,
// checkable evidence for, not a blind score-only assumption.
function noriMeetCheckRecoveryGate(subject) {
  const missing = [];

  const backlogEntries = noriLoadEntries(noriStorageKey("phase-5", "backlog-management", "academic-backlog-tracker"));
  const openBacklog = backlogEntries.filter(function (r) { return r.subject === subject && r.verified !== "Yes"; });
  if (openBacklog.length > 0) {
    missing.push("Backlog not cleared for " + subject + " (" + openBacklog.length + " open item" + (openBacklog.length === 1 ? "" : "s") + " on the Academic Backlog Tracker)");
  }

  const verificationEntries = noriLoadEntries(noriStorageKey("phase-5", "recovery-verification", "recovery-verification-academic"));
  const latest = verificationEntries.length ? verificationEntries[verificationEntries.length - 1] : null;
  const row = latest && latest.fixedTable && latest.fixedTable[subject];
  if (!row || row.verified !== "Yes") {
    missing.push("Recovery not marked Verified for " + subject + " on the Recovery Verification \u2014 Academic form");
  }

  return { met: missing.length === 0, missing: missing };
}

// Degree = 1 + how many consecutive PRIOR failures for this subject
// haven't had their recovery gate actually cleared. A passing score
// (≥80%) only breaks the streak if noriMeetCheckRecoveryGate says the
// real backlog/verification evidence backs it up — a lucky high score
// with backlog still open or nothing verified does NOT reset the Degree,
// because the handbook's recovery gate was never just "pass the next
// one," it's pass-the-next-one AND backlog cleared AND verified. If the
// gate isn't met, the pass is transparent: it neither counts as a new
// failure nor resets anything, and counting continues further back.
function noriMeetDetermineDegree(subject) {
  const history = (noriHistoryLoadAll()[subject] || []);
  const gate = noriMeetCheckRecoveryGate(subject);
  let streak = 0;
  for (let i = history.length - 1; i >= 0; i--) {
    if (history[i].overridden) continue; // paused via Human Override — neither counts nor breaks the streak
    if (history[i].band) { streak++; continue; }
    if (gate.met) break; // a real, evidenced recovery — the streak actually resets here
    // pass without evidenced recovery — doesn't reset, doesn't count as new failure, keep looking back
  }
  return Math.min(streak + 1, 5);
}

/* ---------------------------------------------------------------------
   AWARD SYSTEM LAYER — Merit, two Distinction categories (unchanged from
   before), plus real Excellence and Honor detection now.

   ELITE IS DELIBERATELY NOT AUTO-DETECTED. The handbook itself says so:
   eliteStandard in nori-award-rules.json ends with "The detailed
   qualification thresholds may be defined in the final Award Record once
   the complete handbook architecture is assembled" — the handbook hasn't
   written Elite's criteria yet. Auto-detecting it would mean inventing
   thresholds the source material explicitly hasn't specified, which is
   exactly the kind of fabrication this whole layer has avoided everywhere
   else. Elite stays manual-only (the Phase 4 Elite Recognition form).

   For Excellence and Honor, only categories with real, checkable evidence
   are implemented — nothing is guessed to fill a gap:
     - Excellence "90%+ streak": 5 consecutive results ≥90% in a subject.
     - Excellence "Five-subject excellence": 5+ subjects each independently
       hold that same 5-in-a-row ≥90% streak.
     - Excellence "12-model mastery": 12 Model Exam results across the
       handbook's 5 entrance subjects, all ≥80%.
     - Excellence's 30/60/90-day discipline streaks and Honor's 90/180-day
       discipline streaks: days since the most recent logged breach (or
       since the earliest tracked activity, if no breach has ever been
       logged) — the same self-report trust model the rest of this app
       already runs on (scores, breach reports). This does NOT
       independently verify real-world compliance; it requires genuine
       dated evidence of app usage rather than defaulting to an instant
       streak on a blank install with nothing logged at all.
     - Honor "Five-subject honor": the same idea as Excellence's five-
       subject version but stricter (8-in-a-row instead of 5) — Honor
       "recognizes a record, not a moment," so its bar is higher, not
       just a renamed copy of the Excellence version.
     - Honor "12-model exam honor": same 12 Model Exams, but all ≥90%.
     - Honor "90%/95% yearly honor": a real date-span check — the
       subject's full history must span close to a year AND average at
       or above the threshold. This will rarely fire on a new install,
       which is correct: a yearly honor should require a year of evidence,
       not be gamed by a burst of good scores in one week.
   NOT implemented, deliberately — no real evidence exists for these, so
   nothing is faked: Elite (the handbook itself defers Elite's
   qualification thresholds — "may be defined in the final Award Record
   once the complete handbook architecture is assembled" — there's nothing
   concrete to check without inventing a number the source document
   doesn't provide), and Honor's "Complete Assessment Honor" (the handbook
   doesn't define what counts as "complete" precisely enough to check
   without guessing).
   --------------------------------------------------------------------- */

// Earliest dated activity across all subjects — used as the discipline-
// streak start when no breach has ever been logged, so a fresh install
// can't claim an instant streak from nothing.
function noriMeetEarliestTrackedDate() {
  let earliest = null;
  const allHistory = noriHistoryLoadAll();
  Object.keys(allHistory).forEach(function (subj) {
    allHistory[subj].forEach(function (r) { if (r.date && (!earliest || r.date < earliest)) earliest = r.date; });
  });
  return earliest;
}

function noriMeetLatestBreachDate() {
  let latest = null;
  const allBreach = noriBreachHistoryLoadAll();
  Object.keys(allBreach).forEach(function (cat) {
    allBreach[cat].forEach(function (r) { if (r.date && (!latest || r.date > latest)) latest = r.date; });
  });
  return latest;
}

// Days of clean discipline as of a given date: since the most recent
// logged breach, or since the earliest tracked activity if none exists.
function noriMeetDisciplineStreakDays(asOfDate) {
  const start = noriMeetLatestBreachDate() || noriMeetEarliestTrackedDate();
  if (!start) return 0;
  const a = new Date(start + "T00:00:00");
  const b = new Date(asOfDate + "T00:00:00");
  return Math.round((b - a) / 86400000);
}

// A day-based streak has no single "save" that pushes it from not-met to
// met the way a score streak does — time just passes. So instead of a
// newly-achieved check, this scans whether the award has already been
// recorded in the real Phase 4 form and only awards it once, ever.
function noriMeetAlreadyAwarded(formKey, rowLabel) {
  return noriLoadEntries(formKey).some(function (e) {
    const row = e.fixedTable && e.fixedTable[rowLabel];
    return !!row && (row.achieved === "Yes" || !!row.result);
  });
}

// True if the last `length` entries of a chronological history array are
// ALL scored at/above minScore.
function noriMeetHasStreak(historyArr, minScore, length) {
  if (historyArr.length < length) return false;
  return historyArr.slice(-length).every(function (h) { return typeof h.score === "number" && h.score >= minScore; });
}

// True only on the specific save that PUSHES a streak from not-yet-met to
// met — so a long streak triggers its award exactly once, not on every
// subsequent good score once the threshold is already standing.
function noriMeetStreakNewlyAchieved(priorHistory, currentScore, minScore, length) {
  const withCurrent = priorHistory.concat([{ score: currentScore }]);
  return noriMeetHasStreak(withCurrent, minScore, length) && !noriMeetHasStreak(priorHistory, minScore, length);
}

// Counts saved "Model Exam" results across the handbook's own 5 entrance
// subjects (read from the fetched exam rules, not hardcoded), and whether
// every one of them clears minScore.
function noriMeetCountModelExams(minScore) {
  const entranceSubjects = (NORI_RULES_EXAM && NORI_RULES_EXAM.entranceExam && NORI_RULES_EXAM.entranceExam.subjects) || [];
  let count = 0;
  let allMeetThreshold = true;
  entranceSubjects.forEach(function (subj) {
    const slug = NORI_MEET_SUBJECT_SLUGS[subj];
    if (!slug) return;
    const key = noriStorageKey("phase-1", "control-pages-system", "assessment-record-" + slug);
    noriLoadEntries(key).forEach(function (row) {
      if (row.task === "Model Exam" && row.score !== "" && row.score !== undefined) {
        count++;
        if (Number(row.score) < minScore) allMeetThreshold = false;
      }
    });
  });
  return { count: count, allMeetThreshold: allMeetThreshold };
}

// Real date-span check for a Yearly Honor: the subject's dated results
// must span at least spanDays, and their average must clear thresholdPercent.
function noriMeetYearlyHonorMet(historyArr, thresholdPercent, spanDays) {
  const dated = historyArr.filter(function (h) { return h.date && typeof h.score === "number"; });
  if (dated.length < 2) return false;
  const times = dated.map(function (h) { return new Date(h.date).getTime(); }).filter(function (t) { return !isNaN(t); });
  if (times.length < 2) return false;
  const spanActualDays = (Math.max.apply(null, times) - Math.min.apply(null, times)) / (1000 * 60 * 60 * 24);
  if (spanActualDays < spanDays) return false;
  const avg = dated.reduce(function (sum, h) { return sum + h.score; }, 0) / dated.length;
  return avg >= thresholdPercent;
}

function noriMeetYearlyHonorNewlyAchieved(priorHistory, currentScore, currentDate, thresholdPercent) {
  const SPAN_DAYS = 330; // close to a year, with buffer for real-world gaps between entries
  const withCurrent = priorHistory.concat([{ date: currentDate, score: currentScore }]);
  return noriMeetYearlyHonorMet(withCurrent, thresholdPercent, SPAN_DAYS) && !noriMeetYearlyHonorMet(priorHistory, thresholdPercent, SPAN_DAYS);
}

// priorHistory must be this subject's history BEFORE the current result is
// appended, so streak/date checks are correct. assessmentType is the
// current save's task/type (e.g. "Model Exam") — needed to gate the
// model-exam awards so they only ever evaluate on a save that IS a model
// exam, not re-fire on every unrelated later save.
function noriMeetCheckAwards(subject, percent, priorHistory, currentDate, assessmentType) {
  const awards = [];
  if (percent < 80) return awards; // 80% floor — Award System never applies below it

  const tier = NORI_MEET_MERIT_POINTS.find(function (t) { return percent >= t.min && percent <= t.max; }) ||
    NORI_MEET_MERIT_POINTS[NORI_MEET_MERIT_POINTS.length - 1];
  awards.push({
    level: "Merit",
    points: tier.points,
    perfect: !!tier.perfect,
    reason: (tier.perfect ? "Perfect score" : "Result") + " of " + percent + "% in " + subject
  });

  if (priorHistory.length > 0) {
    const prev = priorHistory[priorHistory.length - 1];
    if (prev.band) {
      awards.push({
        level: "Distinction",
        category: "Comeback distinction",
        reason: "Recovered to " + percent + "% in " + subject + " after a " + prev.band + " result on " + (prev.date || "an earlier date") + "."
      });
    }
  }

  const lastTwo = priorHistory.slice(-2);
  if (lastTwo.length === 2 && lastTwo.every(function (h) { return typeof h.score === "number" && h.score >= 80; })) {
    awards.push({
      level: "Distinction",
      category: "Subject distinction",
      reason: "Three consecutive results at or above 80% in " + subject + "."
    });
  }

  /* ---- Excellence ---- */

  if (percent >= 90 && noriMeetStreakNewlyAchieved(priorHistory, percent, 90, 5)) {
    awards.push({
      level: "Excellence",
      category: "90%+ streak",
      reason: "Five consecutive results at or above 90% in " + subject + " \u2014 repeated under real pressure, not a single result."
    });
  }

  if (percent >= 90 && noriMeetStreakNewlyAchieved(priorHistory, percent, 90, 5)) {
    const allHistory = noriHistoryLoadAll();
    const withCurrent = priorHistory.concat([{ score: percent }]);
    const qualifying = NORI_MEET_SUBJECTS.filter(function (s) {
      return noriMeetHasStreak(s === subject ? withCurrent : (allHistory[s] || []), 90, 5);
    });
    if (qualifying.length >= 5) {
      awards.push({
        level: "Excellence",
        category: "Five-subject excellence",
        reason: qualifying.length + " subjects (" + qualifying.join(", ") + ") each hold a 5-result, 90%+ streak."
      });
    }
  }

  if (assessmentType === "Model Exam") {
    const mastery = noriMeetCountModelExams(80);
    if (mastery.count === 12 && mastery.allMeetThreshold) {
      awards.push({
        level: "Excellence",
        category: "12-model mastery",
        reason: "12 Model Exam results across the entrance subjects, all at or above 80%."
      });
    }
    const honorTier = noriMeetCountModelExams(90);
    if (honorTier.count === 12 && honorTier.allMeetThreshold) {
      awards.push({
        level: "Honor",
        category: "12-model exam honor",
        reason: "12 Model Exam results across the entrance subjects, all at or above 90%."
      });
    }
  }

  /* ---- Honor ---- */

  if (percent >= 90 && noriMeetStreakNewlyAchieved(priorHistory, percent, 90, 8)) {
    const allHistory = noriHistoryLoadAll();
    const withCurrent = priorHistory.concat([{ score: percent }]);
    const qualifying = NORI_MEET_SUBJECTS.filter(function (s) {
      return noriMeetHasStreak(s === subject ? withCurrent : (allHistory[s] || []), 90, 8);
    });
    if (qualifying.length >= 5) {
      awards.push({
        level: "Honor",
        category: "Five-subject honor",
        reason: qualifying.length + " subjects sustain an 8-result, 90%+ streak \u2014 a record, not a moment."
      });
    }
  }

  if (percent >= 90 && noriMeetYearlyHonorNewlyAchieved(priorHistory, percent, currentDate, 90)) {
    awards.push({
      level: "Honor",
      category: "90% yearly honor",
      reason: "Results in " + subject + " span close to a year, averaging at or above 90%."
    });
  }
  if (percent >= 95 && noriMeetYearlyHonorNewlyAchieved(priorHistory, percent, currentDate, 95)) {
    awards.push({
      level: "Honor",
      category: "95% yearly honor",
      reason: "Results in " + subject + " span close to a year, averaging at or above 95%."
    });
  }

  /* ---- Discipline streaks (Excellence + Honor) ---- */

  const streakDays = noriMeetDisciplineStreakDays(currentDate);
  const excellenceKey = noriStorageKey("phase-4", "excellence-level-3", "excellence-record");
  [[30, "30-day discipline streak"], [60, "60-day discipline streak"], [90, "90-day discipline streak"]].forEach(function (pair) {
    if (streakDays >= pair[0] && !noriMeetAlreadyAwarded(excellenceKey, pair[1])) {
      awards.push({
        level: "Excellence",
        category: pair[1],
        reason: streakDays + " days since the last logged breach (or since tracking began), with none logged since."
      });
    }
  });
  const honorKey = noriStorageKey("phase-4", "honor-elite-levels-4-5", "honor-record");
  [[90, "90-day discipline honor"], [180, "180-day discipline honor"]].forEach(function (pair) {
    if (streakDays >= pair[0] && !noriMeetAlreadyAwarded(honorKey, pair[1])) {
      awards.push({
        level: "Honor",
        category: pair[1],
        reason: streakDays + " days clean \u2014 a sustained record, not an isolated stretch."
      });
    }
  });

  return awards;
}

// Writes each award into the real Phase 4 form it belongs in — Merit into
// the Award Record table-log, Distinction/Excellence/Honor into their
// matching fixedTable row on the Distinction Tracker / Excellence Record /
// Honor Record — validated against the actual form shape, same pattern as
// the AI evaluate/check-in backends use.
function noriMeetSaveAwards(awards, date) {
  awards.forEach(function (a) {
    if (a.level === "Merit") {
      const key = noriStorageKey("phase-4", "award-merit-records", "award-record");
      const existing = noriLoadEntries(key);
      existing.push({
        date: date,
        achievement: a.reason,
        level: "1",
        award: a.perfect ? "Perfect Score Recognition" : "Merit",
        evidence: "Quick Add Result",
        verified: "Yes"
      });
      noriSaveEntries(key, existing);
    } else if (a.level === "Distinction") {
      const key = noriStorageKey("phase-4", "distinction-level-2", "distinction-tracker");
      const rows = ["Consistency streak", "Subject distinction", "Model exam distinction", "Comeback distinction", "Discipline streak"];
      const entry = { date: date, values: {}, freeText: {}, fixedTable: {} };
      rows.forEach(function (rowLabel) {
        entry.fixedTable[rowLabel] = { requirement: "", date: "", verified: "", notes: "" };
      });
      if (entry.fixedTable[a.category]) {
        entry.fixedTable[a.category] = { requirement: a.reason, date: date, verified: "Yes", notes: "Auto-detected by Quick Add Result" };
      }
      const existing = noriLoadEntries(key);
      existing.push(entry);
      noriSaveEntries(key, existing);
    } else if (a.level === "Excellence") {
      const key = noriStorageKey("phase-4", "excellence-level-3", "excellence-record");
      const rows = ["90%+ streak", "Five-subject excellence", "12-model mastery", "30-day discipline streak", "60-day discipline streak", "90-day discipline streak"];
      const entry = { date: date, values: {}, freeText: {}, fixedTable: {} };
      rows.forEach(function (rowLabel) { entry.fixedTable[rowLabel] = { qualification: "", achieved: "", evidence: "" }; });
      if (entry.fixedTable[a.category]) {
        entry.fixedTable[a.category] = { qualification: a.category, achieved: "Yes", evidence: a.reason };
      }
      const existing = noriLoadEntries(key);
      existing.push(entry);
      noriSaveEntries(key, existing);
    } else if (a.level === "Honor") {
      const key = noriStorageKey("phase-4", "honor-elite-levels-4-5", "honor-record");
      const rows = ["90% yearly honor", "95% yearly honor", "Complete assessment honor", "Five-subject honor", "12-model exam honor", "90-day discipline honor", "180-day discipline honor"];
      const entry = { date: date, values: {}, freeText: {}, fixedTable: {} };
      rows.forEach(function (rowLabel) { entry.fixedTable[rowLabel] = { qualification: "", result: "", evidenceDate: "" }; });
      if (entry.fixedTable[a.category]) {
        entry.fixedTable[a.category] = { qualification: a.category, result: "Achieved", evidenceDate: a.reason + " (" + date + ")" };
      }
      const existing = noriLoadEntries(key);
      existing.push(entry);
      noriSaveEntries(key, existing);
    }
  });
}

// Given a percent and (for below-80 results) the subject, return which
// system it falls under, the label, and — for below-80 results — the
// Degree (from this subject's history) and the exact recovery actions to
// follow next.
function noriMeetCategorize(percent, subject) {
  const p = Math.max(0, Math.min(100, percent));
  if (p >= 80) {
    const tier = NORI_MEET_MERIT_POINTS.find(function (t) { return p >= t.min && p <= t.max; }) ||
      NORI_MEET_MERIT_POINTS[NORI_MEET_MERIT_POINTS.length - 1];
    return {
      percent: p,
      system: "Award System",
      label: (tier.perfect ? "Perfect Score Recognition" : "Merit") +
        " (+" + tier.points + " point" + (tier.points === 1 ? "" : "s") + ")"
    };
  }
  const band = NORI_MEET_BANDS
    .slice()
    .sort(function (a, b) { return Number(a.min) - Number(b.min); })
    .find(function (b) { return p >= Number(b.min) && p < Number(b.max) + 0.0000001; }) ||
    NORI_MEET_BANDS.slice().sort(function (a, b) { return Number(a.min) - Number(b.min); })
      .filter(function (b) { return p >= Number(b.min); }).pop() || null;
  if (!band) throw new Error("score_outside_band_range");
  const degree = subject ? "Degree " + noriMeetDetermineDegree(subject) : "Degree 1";
  const actions = (NORI_MEET_DEGREE_ACTIONS[degree] && NORI_MEET_DEGREE_ACTIONS[degree].bands[band.id]) || [];
  const recoveryGate = subject ? noriMeetCheckRecoveryGate(subject) : { met: true, missing: [] };
  // The handbook's own recoveryGate text for this Degree, read straight
  // from NORI_RULES_EXAM (fetched JSON) — Degree 1 has none, since it's a
  // first-time correction, not a gate to clear.
  const gateText = (NORI_RULES_EXAM && NORI_RULES_EXAM.degrees[degree] && NORI_RULES_EXAM.degrees[degree].recoveryGate) || null;
  return {
    percent: p,
    system: "Exam Result System",
    label: band.id + " \u2014 " + band.label,
    degree: degree,
    band: band.id,
    actions: actions,
    recoveryGate: { met: recoveryGate.met, missing: recoveryGate.missing, handbookText: gateText }
  };
}

// Parses "5/5", "18 out of 20", "82%", "82 percent", or a bare number into
// a percent. Returns null if nothing recognizable is found.
function noriMeetParseScoreText(text) {
  const lower = (text || "").toLowerCase().trim();

  let m = lower.match(/(\d+(?:\.\d+)?)\s*(?:\/|out of)\s*(\d+(?:\.\d+)?)/);
  if (m) {
    const num = parseFloat(m[1]), den = parseFloat(m[2]);
    if (den > 0) return { marksText: (num % 1 === 0 ? num : m[1]) + "/" + (den % 1 === 0 ? den : m[2]), percent: Math.round((num / den) * 1000) / 10 };
  }

  m = lower.match(/(\d+(?:\.\d+)?)\s*(?:%|percent)/);
  if (m) return { marksText: "", percent: parseFloat(m[1]) };

  m = lower.match(/^(\d+(?:\.\d+)?)$/);
  if (m) return { marksText: "", percent: parseFloat(m[1]) };

  return null;
}

/* ---------------------------------------------------------------------
   HUMAN OVERRIDE LAYER — NORI_MEET_OVERRIDE_CATEGORIES and
   NORI_MEET_OVERRIDE_LEVELS now live in nori-rules.js, derived from
   nori-human-override-rules.json (one copy, not two). The priority-
   severity formula itself (importance x weakness x difficulty x
   immediacy, modified by evidence and impact — ported from the user's
   kage.js) stays here since it's calculation logic, not handbook data.

   Also implements the overrideVsExcuseGuard: if the SAME circumstance
   category has already been claimed twice recently for this subject, a
   third claim is refused and classified normally instead — this is what
   stops Override from becoming a way to dodge accountability for a
   genuinely repeating pattern.
   --------------------------------------------------------------------- */

// factors: { importance, weakness, difficulty, immediacy, evidence, impact }, each 0-10
function noriMeetScoreOverride(factors) {
  const raw = factors.importance * factors.weakness * factors.difficulty * factors.immediacy;
  const score = raw * (0.5 + factors.evidence / 5) * (0.75 + factors.impact / 10);
  let matched = NORI_MEET_OVERRIDE_LEVELS.find(function (l) { return score >= l.minScore; }) ||
    NORI_MEET_OVERRIDE_LEVELS[NORI_MEET_OVERRIDE_LEVELS.length - 1];

  // Hard cap, not just a multiplier: the 4 self-rated factors (importance,
  // difficulty, immediacy, impact) can mathematically clear the Critical
  // threshold on their own even with minimal evidence — the multiplier
  // alone doesn't fully close that gap, since these thresholds were
  // calibrated for 6 meaningfully-rated factors, not 4 maxed ones times a
  // small discount. So evidence gets a real veto: without at least a
  // moderately specific description (computed evidence \u2265 4, roughly
  // 8+ words of real content), the level can never reach High or Critical,
  // no matter how the 4 self-rated sliders are set.
  const levelOrder = ["Monitor", "Low", "Medium", "High", "Critical"];
  if (factors.evidence < 4) {
    const cap = Math.min(levelOrder.indexOf(matched.level), levelOrder.indexOf("Medium"));
    matched = NORI_MEET_OVERRIDE_LEVELS.find(function (l) { return l.level === levelOrder[cap]; }) || matched;
  }

  return { score: Math.round(score), level: matched.level, adjustment: matched.adjustment };
}

// ---- Reducing self-report reliance on 2 of the 6 factors ----
// Letting someone rate their OWN "evidence" and "known recurring issue"
// on a 0-10 scale is circular — nothing stops typing 10 on both regardless
// of what actually happened, which would let anyone force a Critical
// pause every time. Full independent verification isn't possible for a
// personal, local app (no one here can confirm a real family emergency),
// but these two specific factors don't need a human witness — they can be
// computed from evidence the app already has: how much actual detail was
// written, and how often this exact excuse has really been used before.
// importance, difficulty, immediacy, and impact stay self-rated, because
// those are genuinely personal judgment calls with no proxy to compute
// them from — even a human reviewer would need to ask the person directly.

// Evidence: from the actual specificity of the written description, not a
// self-score of how convincing it is.
function noriMeetComputeEvidenceScore(description) {
  const text = (description || "").trim();
  const words = text.split(/\s+/).filter(Boolean);
  let score = 0;
  if (words.length >= 40) score = 10;
  else if (words.length >= 25) score = 8;
  else if (words.length >= 15) score = 6;
  else if (words.length >= 8) score = 4;
  else if (words.length >= 3) score = 2;
  if (/\d/.test(text)) score = Math.min(10, score + 1); // a number, date, or time mentioned
  const properNouns = (text.match(/\b[A-Z][a-z]+\b/g) || []).length;
  if (properNouns >= 2) score = Math.min(10, score + 1); // named people/places, not generic phrasing
  return score;
}

// Weakness (how established a pattern this already is): from real prior
// claims of this exact category for this subject — the same history the
// excuse guard already tracks — rather than a self-report of how much of
// a "known issue" this is for them.
function noriMeetComputeWeaknessScore(subject, category) {
  const history = noriOverrideHistoryLoadAll()[subject] || [];
  const priorClaims = history.filter(function (h) { return h.category === category; }).length;
  if (priorClaims === 0) return 2; // first time — not yet an established pattern
  if (priorClaims === 1) return 6; // a second occurrence — worth real consideration
  return 9; // right at the edge before the guard blocks a 3rd claim outright
}

// A one-word description shouldn't be able to unlock a high severity score
// just because the self-rated factors were maxed out — this is the
// structural floor that makes noriMeetComputeEvidenceScore matter instead
// of being bypassable.
const NORI_MEET_MIN_OVERRIDE_DESCRIPTION_WORDS = 6;

function noriMeetOverrideHistoryKey() { return "nori_override_history_all_subjects"; }

// noriOverrideHistoryLoadAll / noriOverrideHistoryAppend live in
// nori-storage.js now — canonical implementation.

// Refuses Override if this exact category has already been claimed twice
// (i.e. this would be the 3rd time) in this subject's recent Override
// history, with no confirmed break in between.
function noriMeetCheckOverrideGuard(subject, category) {
  const history = noriOverrideHistoryLoadAll()[subject] || [];
  const recentSame = history.filter(function (h) { return h.category === category; });
  if (recentSame.length >= 2) {
    return {
      blocked: true,
      note: "\u201c" + category + "\u201d has been claimed " + recentSame.length + " times recently for " + subject +
        " without new specific evidence. Not granting Override this time \u2014 classifying normally instead. " +
        "(Override protects real circumstances; repeating the same claim without anything new is the pattern the handbook's own Integrity rules exist to catch.)"
    };
  }
  return { blocked: false };
}

/* ---------------------------------------------------------------------
   SYSTEM INTEGRITY + DISCIPLINARY SYSTEM LAYER
   ---------------------------------------------------------------------
   This is the layer that sits ABOVE the Result System in the handbook —
   it governs behavior (distraction, broken restrictions, hidden breaches),
   not academic scores. NORI_MEET_DESTRUCTION_CATEGORIES,
   NORI_MEET_BREACH_TEST, NORI_MEET_DISCIPLINARY_LADDER, and
   NORI_MEET_PROPORTIONALITY_NOTE now live in nori-rules.js, derived from
   nori-system-integrity-rules.json (one copy, not two).

   Deliberately excluded, per the handbook's own Safety Clarification: any
   physical-punishment element from the backup version. This layer only
   ever surfaces the handbook's own protocol TEXT (interrupt/restrict/
   restore/verify-style steps) — it never invents a consequence, and the
   Proportionality Law text is shown alongside every Degree III+ result as
   a standing reminder of that limit.
   --------------------------------------------------------------------- */

function noriMeetBreachHistoryKey() { return "nori_breach_history_by_category"; }

// noriBreachHistoryLoadAll / noriBreachHistoryAppend live in
// nori-storage.js now — canonical implementation.

// Repeat-Pattern Rule: the Disciplinary Degree escalates per CATEGORY, not
// per specific app/tool — Instagram then YouTube then Pinterest is still
// one pattern (High-Dopamine Digital Distraction), so it counts as one
// escalating history, matching the handbook's example exactly.
// Returns the exact key used in NORI_MEET_DISCIPLINARY_LADDER (roman
// numerals, matching the handbook's own "DEGREE I".."DEGREE V" text).
const NORI_MEET_ROMAN_DEGREES = ["Degree I", "Degree II", "Degree III", "Degree IV", "Degree V"];
function noriMeetDetermineDisciplinaryDegree(category) {
  const history = noriBreachHistoryLoadAll()[category] || [];
  const idx = Math.min(history.length, 4); // cap at index 4 = "Degree V"
  return NORI_MEET_ROMAN_DEGREES[idx];
}

function noriMeetRenderPage() {
  const wrap = noriEl("div", { class: "nori-screen" });
  wrap.appendChild(noriRenderBreadcrumb([{ label: "NORI", hash: "#/" }, { label: "Meet Nori" }]));
  wrap.appendChild(noriEl("h1", { class: "nori-title", text: "Meet Nori" }));
  wrap.appendChild(noriEl("p", { class: "nori-lede", text: "Listening and speaking are ready. The brain comes next." }));

  /* ==================== CHAT PANEL ==================== */

  const panel = noriEl("section", { class: "nori-panel nori-meet-panel" });

  const log = noriEl("div", { class: "nori-meet-log" });
  panel.appendChild(log);

  const statusLine = noriEl("p", { class: "nori-meet-status", text: "Mic off." });
  panel.appendChild(statusLine);
  const presenceBtn = noriEl("button", { class: "nori-btn nori-btn-ghost nori-ip-chat-button", text: "◉ Interactive Circle" });
  presenceBtn.addEventListener("click", function(){ if (window.NoriInterfaceMode) window.NoriInterfaceMode.open(); else if (window.NoriInteractivePresence) window.NoriInteractivePresence.open("chat"); });
  panel.appendChild(presenceBtn);

  const transcriptBox = noriEl("div", { class: "nori-meet-transcript-box", text: "" });
  panel.appendChild(transcriptBox);

  const controls = noriEl("div", { class: "nori-meet-controls" });
  const micBtn = noriEl("button", { class: "nori-btn nori-btn-primary nori-meet-mic-btn", text: "\ud83c\udf99\ufe0f Start Listening" });
  const muteBtn = noriEl("button", { class: "nori-btn nori-btn-ghost nori-meet-mute-btn", text: "\ud83d\udd0a Mute Mic" });
  const textInput = noriEl("input", { type: "text", class: "nori-checkin-typed nori-meet-input", placeholder: "Type to Nori\u2026" });
  const sendBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "Send" });
  controls.appendChild(micBtn);
  controls.appendChild(muteBtn);
  controls.appendChild(textInput);
  controls.appendChild(sendBtn);
  panel.appendChild(controls);

  const interruptRow = noriEl("label", { class: "nori-meet-checkbox-row" });
  const interruptCheckbox = noriEl("input", { type: "checkbox" });
  interruptRow.appendChild(interruptCheckbox);
  interruptRow.appendChild(noriEl("span", { text: "Let me interrupt Nori while she's talking" }));
  panel.appendChild(interruptRow);

  const speechSupported = NORI_FEATURES.voice && NORI_SPEECH_SUPPORTED;
  if (!NORI_FEATURES.voice) {
    micBtn.disabled = true;
    muteBtn.disabled = true;
    micBtn.textContent = "\ud83c\udf99\ufe0f Voice \u2014 coming soon";
    transcriptBox.textContent = "";
    statusLine.textContent = "Voice isn't in this build yet \u2014 type below instead.";
  } else if (!speechSupported) {
    micBtn.disabled = true;
    muteBtn.disabled = true;
    micBtn.textContent = "Voice not supported";
    statusLine.textContent = "Voice input isn't supported here \u2014 use the text box.";
  } else if (NORI_IS_NATIVE) {
    // The continuous, partial-results listening below is built on the Web
    // Speech API's event model, which doesn't have a clean native
    // equivalent. On the native Android app, the mic button instead does
    // one tap = one utterance via noriListenOnce() (same bridge used by
    // Check-In / Report Result) — still voice-driven, just turn-based
    // instead of continuously open. Mute/interrupt don't apply to that
    // model, so they're hidden rather than left as controls that do nothing.
    muteBtn.style.display = "none";
    interruptRow.style.display = "none";
    micBtn.addEventListener("click", function () {
      if (micBtn.disabled) return;
      micBtn.disabled = true;
      statusLine.textContent = "\ud83c\udf99\ufe0f Listening\u2026";
      noriListenOnce().then(function (said) {
        textInput.value = (textInput.value ? textInput.value + " " : "") + said;
        transcriptBox.textContent = said;
        statusLine.textContent = "Heard it \u2014 tap the mic again to add more, or Send.";
      }).catch(function (err) {
        statusLine.textContent = err.message === "permission-denied"
          ? "Microphone permission was denied \u2014 enable it in Android Settings > Apps > Nori > Permissions."
          : "Didn't catch that \u2014 tap the mic to try again.";
      }).finally(function () { micBtn.disabled = false; });
    });
  }

  wrap.appendChild(panel);

  /* ---------------- conversation log ---------------- */

  function addMessage(role, text) {
    const bubble = noriEl("div", { class: "nori-meet-bubble nori-meet-bubble-" + role });
    bubble.appendChild(noriEl("div", { class: "nori-meet-bubble-label", text: role === "user" ? "You" : "Nori" }));
    bubble.appendChild(noriEl("div", { class: "nori-meet-bubble-text", text: text }));
    if (role === "user" && window.__noriInputChannel === "voice") bubble.appendChild(noriEl("div", { class: "nori-meet-bubble-channel", text: "VOICE TRANSCRIPT" }));
    log.appendChild(bubble);
    log.scrollTop = log.scrollHeight;
    try { if (window.NoriCanonicalSync) window.NoriCanonicalSync.recordConversationTurn(role, text, null, {channel: window.__noriInputChannel || "text"}); } catch (e) {}
  }

  addMessage("nori", "Hi \u2014 I'm listening and ready to talk. Ask me anything, or tell me what's going on.");

  /* ---------------- state ---------------- */

  let recognizer = null;
  let recognizerRunning = false;   // is the actual SpeechRecognition object currently started
  let listening = false;           // user's intent: session should be active
  let muted = false;               // user's manual mute
  let speaking = false;            // Nori is currently talking (TTS)
  let allowInterrupt = true;      // mic stays hot during Nori's speech if true
  let sessionFinalText = "";

  function effectiveMicShouldRun() {
    return listening && !muted && (!speaking || allowInterrupt);
  }

  function updateStatusLine() {
    if (!listening) { statusLine.textContent = "Mic off."; return; }
    if (muted) { statusLine.textContent = "\ud83d\udd07 Muted \u2014 tap Unmute to resume."; return; }
    if (speaking && !allowInterrupt) { statusLine.textContent = "Nori is speaking \u2014 mic paused so it doesn't hear itself."; return; }
    if (speaking && allowInterrupt) { statusLine.textContent = "\u25cf Nori is speaking \u2014 mic still on, go ahead and interrupt."; return; }
    statusLine.textContent = "\u25cf Listening\u2026";
  }

  function updateTranscriptBox(interim) {
    const shown = sessionFinalText + (interim ? (sessionFinalText ? " " : "") + interim : "");
    transcriptBox.textContent = shown || "\u2026";
  }

  function createRecognizer() {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    const rec = new Recognition();
    rec.lang = "en-US";
    rec.continuous = true;
    rec.interimResults = true;

    rec.onresult = function (e) {
      // Barge-in: if Nori is mid-sentence and we're hearing real speech,
      // stop her immediately so the two voices don't overlap.
      if (speaking && allowInterrupt) {
        // Avoid treating Nori's own TTS echo as a user interruption.
        var echoText = String(window.__noriPresenceSpeakingText || '').toLowerCase();
        var rawPreview = '';
        for (let j = e.resultIndex; j < e.results.length; j++) rawPreview += ' ' + e.results[j][0].transcript;
        rawPreview = rawPreview.toLowerCase().replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim();
        var echoWords = echoText.replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim().split(' ').filter(Boolean);
        var previewWords = rawPreview.split(' ').filter(Boolean);
        var hits = 0;
        previewWords.forEach(function(w){ if (echoWords.indexOf(w) >= 0) hits++; });
        var echoRatio = previewWords.length ? hits / previewWords.length : 0;
        if (echoRatio < 0.65) window.speechSynthesis && window.speechSynthesis.cancel();
        else return;
      }

      let interim = "";
      let finalChunk = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const chunk = e.results[i][0].transcript;
        if (e.results[i].isFinal) finalChunk += chunk;
        else interim += chunk;
      }
      if (finalChunk) {
        sessionFinalText = (sessionFinalText ? sessionFinalText + " " : "") + finalChunk.trim();
        textInput.value = (textInput.value ? textInput.value + " " : "") + finalChunk.trim();
      }
      updateTranscriptBox(interim);
    };

    rec.onerror = function (e) {
      if (e.error === "no-speech" || e.error === "aborted") return;
      statusLine.textContent = "Mic error (" + e.error + ") \u2014 tap Start Listening to retry.";
      listening = false;
      recognizerRunning = false;
      micBtn.textContent = "\ud83c\udf99\ufe0f Start Listening";
      micBtn.classList.remove("nori-meet-mic-active");
    };

    rec.onend = function () {
      recognizerRunning = false;
      // If we should still be running (browser cut us off on its own),
      // restart. If we deliberately paused (mute / Nori speaking without
      // interrupt allowed), do nothing until sync brings it back.
      if (effectiveMicShouldRun()) syncRecognizer();
    };

    return rec;
  }

  function syncRecognizer() {
    const shouldRun = effectiveMicShouldRun();
    if (shouldRun && !recognizerRunning) {
      if (!recognizer) recognizer = createRecognizer();
      try { recognizer.start(); recognizerRunning = true; } catch (err) { /* rapid-call race, ignore */ }
    } else if (!shouldRun && recognizerRunning) {
      if (recognizer) { try { recognizer.stop(); } catch (err) { /* ignore */ } }
      recognizerRunning = false;
    }
    updateStatusLine();
  }

  function startListening() {
    if (!speechSupported) return;
    if (window.noriPresence && noriPresence.setState) noriPresence.setState('LISTENING');
    sessionFinalText = "";
    transcriptBox.textContent = "\u2026";
    listening = true;
    micBtn.textContent = "\u23f9 Stop Listening";
    micBtn.classList.add("nori-meet-mic-active");
    syncRecognizer();
  }

  function stopListening() {
    listening = false;
    if (window.noriPresence && noriPresence.setState) noriPresence.setState('WAITING');
    micBtn.textContent = "\ud83c\udf99\ufe0f Start Listening";
    micBtn.classList.remove("nori-meet-mic-active");
    syncRecognizer();
  }

  // Continuous web-based listening only applies when NOT native — the
  // native tap-per-utterance handler was already wired above instead.
  if (speechSupported && !NORI_IS_NATIVE) {
    micBtn.addEventListener("click", function () {
      if (listening) stopListening(); else startListening();
    });

    muteBtn.addEventListener("click", function () {
      muted = !muted;
      muteBtn.textContent = muted ? "\ud83d\udd07 Unmute Mic" : "\ud83d\udd0a Mute Mic";
      muteBtn.classList.toggle("nori-meet-mute-active", muted);
      syncRecognizer();
    });

    interruptCheckbox.addEventListener("change", function () {
      allowInterrupt = interruptCheckbox.checked;
      syncRecognizer();
    });
  }

  /* ---------------- speaking (TTS) ---------------- */
  // Uses the shared noriSpeak from nori-native-bridge.js, with callbacks
  // wired to this page's barge-in mute logic (see syncRecognizer above).

  /* ---------------- sending (real brain: Gemini primary, OpenAI fallback) ---------------- */

  let conversationHistory = [];
  let stateSummaryCache = { at: 0, value: null };
  let nativeBrainContextCache = null;

  function gatherStateSummary() {
    const now = Date.now();
    if (stateSummaryCache.value && now - stateSummaryCache.at < 1200) return stateSummaryCache.value;
    stateSummaryCache.value = {
      subjectResultHistory: noriHistoryLoadAll(),
      humanOverrideHistory: noriOverrideHistoryLoadAll(),
      breachHistory: noriBreachHistoryLoadAll(),
      assignments: typeof noriAssignmentsLoad === "function" ? noriAssignmentsLoad() : [],
      exams: typeof noriExamsLoad === "function" ? noriExamsLoad() : [],
      studySessions: typeof noriStudySessionsLoad === "function" ? noriStudySessionsLoad() : [],
      activeConsequences: typeof noriActiveConsequences === "function" ? noriActiveConsequences() : [],
      notifications: typeof noriNotificationsLoad === "function" ? noriNotificationsLoad() : []
    };
    stateSummaryCache.at = now;
    return stateSummaryCache.value;
  }

  function tryLocalMemoryCommand(text) {
    try {
      if (!window.noriBrainV13 || !noriBrainV13.memoryCommand) return null;
      const cmd = noriBrainV13.memoryCommand(text);
      if (!cmd) return null;
      if (cmd.type === 'remember') return cmd.result && cmd.result.ok ? 'Got it. I saved that as a confirmed memory.' : 'I could not save that memory because it contains information I am not allowed to store.';
      if (cmd.type === 'recall') {
        const items = cmd.matches || [];
        return items.length ? 'Here is what I remember:\n' + items.slice(0,8).map(function(m,i){ return (i+1) + '. ' + m.text + ' [' + (m.status || 'confirmed') + ']'; }).join('\n') : 'I do not have a matching memory for that.';
      }
      if (cmd.type === 'forget') {
        const items = cmd.matches || [];
        if (items.length !== 1) return items.length ? 'I found several matching memories. Be more specific so I remove the right one.' : 'I could not find a matching memory.';
        noriBrainV13.memoryRemove(items[0].id);
        return 'Done. I forgot that memory.';
      }
    } catch (e) {}
    return null;
  }

  function noriUserExplicitlyRequestedWebSearch(text) {
    return /\b(search (the )?web|search online|look (it|this|that) up|look online|browse (the )?web|browse online|check online|verify online|find (current|latest) (information|info|news|details)|what(?:'|’)s the latest|latest information|current information)\b/i.test(text || "");
  }

  async function sendCurrentText() {
    const text = textInput.value.trim();
    if (!text) return;
    if (/\b(let|can|could|please)\s+(kage|nori)\s+(explain|show)\s+(my\s+)?(status|results|recovery)\b/i.test(text) && window.NoriAvatarV26) { window.NoriAvatarV26.explainStatus(); }
    addMessage("user", text);
    window.__noriInputChannel = "text";
    textInput.value = "";
    sessionFinalText = "";
    transcriptBox.textContent = "";
    const priorStatus = statusLine.textContent;
    const suppliedUrls = (text.match(/https?:\/\/[^\s<>()\[\]"\']+/gi) || []).map(function(u){ return u.replace(/[),.;!?]+$/, ""); });
    const requestedWebSearch = noriUserExplicitlyRequestedWebSearch(text);
    const requestedUrlAnalysis = suppliedUrls.length > 0;
    const privacy = (typeof noriIntelligenceV20 === "object" && noriIntelligenceV20.privacyStatus) ? noriIntelligenceV20.privacyStatus() : {controls:{privateMode:false,sendConversationHistory:true,sendAcademicState:true}};
    const privateMode = !!(privacy.controls && privacy.controls.privateMode);
    const convo = (typeof noriConversationV3 === 'object' && noriConversationV3.beginUserTurn) ? noriConversationV3.beginUserTurn(text) : ((typeof noriConversationV2 === 'object' && noriConversationV2.beginUserTurn) ? noriConversationV2.beginUserTurn(text) : {intent:'general',affect:'calm',history:[]});
    const localMemoryReply = tryLocalMemoryCommand(text);
    if (localMemoryReply) {
      conversationHistory.push({ role: "assistant", content: localMemoryReply });
      if (conversationHistory.length > 20) conversationHistory = conversationHistory.slice(-20);
      if (typeof noriConversationV2 === 'object' && noriConversationV2.finishAssistantTurn) noriConversationV2.finishAssistantTurn(localMemoryReply, {emotion:'calm'});
      addMessage("nori", localMemoryReply);
      statusLine.textContent = priorStatus || "Ready";
      return;
    }

    // V33: deterministic/explicit operative requests enter the same operative
    // loop as model-generated actions. Ordinary conversation continues to the
    // LLM brain below.
    if (window.NoriOperativeV33 && !requestedWebSearch && !requestedUrlAnalysis) {
      try {
        const operative = await window.NoriOperativeV33.handleText(text, {source: "text", sessionId: "default"});
        if (operative && operative.status === "confirmation_required") {
          addMessage("nori", "I can perform that operation. Confirm it to continue.");
          const proposalAction = Object.assign({type: operative.proposal.type}, operative.proposal.input || {}, {reason: "V33 operative plan", __v33Plan: operative.proposal.plan, __v33ProposalId: operative.proposal.id});
          offerAction(proposalAction);
          statusLine.textContent = priorStatus || "Ready";
          return;
        }
        if (operative && operative.status === "success" && operative.handled !== false) {
          addMessage("nori", "The operation completed and was verified.");
          statusLine.textContent = priorStatus || "Ready";
          return;
        }
      } catch (operativeError) {
        // Do not turn an operative parser failure into a fake success. Fall
        // through to normal conversation so the model can explain or clarify.
      }
    }
    // V36: ordinary conversation is routed through the Assistance Engine first.
    // Web/URL requests retain the established research path; explicit operations remain V33-owned.
    if (window.NoriAssistanceV36 && !requestedWebSearch && !requestedUrlAnalysis) {
      statusLine.textContent = priorStatus || "Nori is thinking\u2026";
      try {
        const assistance = await window.NoriAssistanceV36.assist(text, { mode: convo.intent === "planning" ? "planning" : "assistance", externalAvailable: requestedWebSearch || requestedUrlAnalysis, userInitiatedAction: true });
        if (assistance && assistance.decision && assistance.decision.nativeBrain) nativeBrainContextCache = assistance.decision.nativeBrain;
        if (assistance && assistance.status === "needs_clarification") {
          addMessage("nori", assistance.question);
          statusLine.textContent = priorStatus || "Ready";
          return;
        }
        if (assistance && assistance.status === "assisted" && assistance.decision) {
          const d = assistance.decision;
          let answer = String(d.interpretation || "").trim();
          if (!answer) answer = "I have analyzed the current context, but I need more information before making a useful recommendation.";
          if (Array.isArray(d.what_i_noticed) && d.what_i_noticed.length) answer += "\n\nWhat I noticed: " + d.what_i_noticed.join("; ");
          if (Array.isArray(d.why_it_matters) && d.why_it_matters.length) answer += "\nWhy it matters: " + d.why_it_matters.join("; ");
          if (d.proposal) answer += "\n\nProposal: " + (typeof d.proposal === "string" ? d.proposal : JSON.stringify(d.proposal));
          if (Array.isArray(d.risks) && d.risks.length) answer += "\nRisks: " + d.risks.join("; ");
          if (d.next_step) answer += "\nNext: " + (typeof d.next_step === "string" ? d.next_step : JSON.stringify(d.next_step));
          conversationHistory.push({ role: "assistant", content: answer });
          if (conversationHistory.length > 20) conversationHistory = conversationHistory.slice(-20);
          if (typeof noriConversationV2 === "object" && noriConversationV2.finishAssistantTurn) noriConversationV2.finishAssistantTurn(answer, {emotion: d.confidence != null && d.confidence < .45 ? "concerned" : "calm"});
          addMessage("nori", answer);
          statusLine.textContent = priorStatus || "Ready";
          return;
        }
      } catch (assistanceError) {
        // Fall through to the established model path; a new layer must never create a fake success.
      }
    }
    statusLine.textContent = requestedWebSearch ? "Nori is searching the web\u2026" : "Nori is thinking\u2026";

    const historyForRequest = privateMode || privacy.controls.sendConversationHistory === false ? [] : conversationHistory.slice(-12);
    conversationHistory.push({ role: "user", content: text });

    let reply, memorySuggestions = [], actions = [], emotion = "calm", sources = [];
    try {
      const resp = await fetch(NORI_BRAIN_ENDPOINT, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          history: historyForRequest,
          stateSummary: (privateMode || privacy.controls.sendAcademicState === false) ? {} : gatherStateSummary(),
          brainContext: Object.assign({}, (typeof noriBrainV10 === "object" && noriBrainV10.buildChatContext) ? noriBrainV10.buildChatContext(text, { publicVoice: !!(noriBrainV10.publicMode && noriBrainV10.publicMode()) }) : {}, { nativeBrain: nativeBrainContextCache || null }),
          userMemory: (typeof noriBrainV10 === "object" && noriBrainV10.publicVoiceMemory) ? noriBrainV10.publicVoiceMemory(text) : [],
          conversationContext: privateMode ? {intent:convo.intent,affect:convo.affect,recentTurns:[],threadTopic:'',privateMode:true} : ((typeof noriConversationV3 === 'object' && noriConversationV3.context) ? noriConversationV3.context() : ((typeof noriConversationV2 === 'object' && noriConversationV2.context) ? noriConversationV2.context() : {intent:convo.intent,affect:convo.affect})),
          nextMove: (typeof noriBrainV13 === 'object' && noriBrainV13.contextualNextMove) ? noriBrainV13.contextualNextMove() : null,
          webSearch: requestedWebSearch,
          urls: suppliedUrls,
          privateMode: privateMode,
          visualContext: (!privateMode && window.NoriVisualContextV1 && window.NoriVisualContextV1.dataUrl) ? { kind: window.NoriVisualContextV1.kind, dataUrl: window.NoriVisualContextV1.dataUrl } : null
        })
      });
      if (!resp.ok) throw new Error("Backend returned " + resp.status);
      const data = await resp.json();
      if (window.NoriVisualContextV1 && window.NoriVisualContextV1.clear) window.NoriVisualContextV1.clear();
      reply = data.reply || "I didn't get a usable reply back \u2014 try again in a moment.";
      memorySuggestions = data.memorySuggestions || [];
      actions = data.actions || [];
      emotion = data.emotion || "calm";
      sources = Array.isArray(data.sources) ? data.sources : [];
    } catch (err) {
      reply = "I couldn't reach my brain just now (" + err.message + "). Check that api/brain.js is deployed and GEMINI_API_KEY / OPENAI_API_KEY are set.";
    }

    conversationHistory.push({ role: "assistant", content: reply });
    if (conversationHistory.length > 20) conversationHistory = conversationHistory.slice(-20);

    if (typeof noriConversationV3 === 'object' && noriConversationV3.finishAssistantTurn) reply = noriConversationV3.finishAssistantTurn(reply, {emotion:emotion}); else if (typeof noriConversationV2 === 'object' && noriConversationV2.finishAssistantTurn) reply = noriConversationV2.finishAssistantTurn(reply, {emotion:emotion});
    addMessage("nori", reply);
    if (sources.length) {
      const sourceLine = document.createElement("div");
      sourceLine.className = "nori-web-sources";
      sourceLine.textContent = "Sources: ";
      sources.slice(0, 6).forEach(function (src, i) {
        if (!src || !src.url) return;
        const a = document.createElement("a");
        a.href = src.url; a.target = "_blank"; a.rel = "noopener noreferrer";
        a.textContent = (src.title || src.host || "Source") + (src.quality === "primary_or_authoritative" ? " ✓" : "") + (i < sources.length - 1 ? " · " : "");
        sourceLine.appendChild(a);
      });
      const messages = document.querySelectorAll(".nori-meet-message");
      const last = messages[messages.length - 1];
      if (last) last.appendChild(sourceLine);
    }
    if (typeof noriBrainV10 === "object" && noriBrainV10.setAffect) noriBrainV10.setAffect(emotion);
    if (NORI_FEATURES.voice) {
      if (window.NoriInterfaceMode) window.NoriInterfaceMode.open(); else if (window.NoriInteractivePresence) window.NoriInteractivePresence.open("chat"); if (window.NoriInteractivePresence) { window.NoriInteractivePresence.setTranscript(reply); window.NoriInteractivePresence.setState("SPEAKING"); }
      noriSpeak(reply, {
        onStart: function () { speaking = true; syncRecognizer(); },
        onEnd: function () { speaking = false; syncRecognizer(); },
        onError: function () { speaking = false; syncRecognizer(); }
      });
    }
    statusLine.textContent = priorStatus;

    if (memorySuggestions.length) offerMemorySuggestions(memorySuggestions);
    if (window.NoriOperativeV33 && actions.length > 1) offerWorkflow(actions);
    else actions.forEach(function (action) { offerAction(action); });
  }

  // Shared entry point for the interactive circle; voice and typed messages use the same chat pipeline.
  window.noriMeetSendText = function(text){ if(!text) return Promise.resolve(); textInput.value = String(text); window.__noriInputChannel = "voice"; return sendCurrentText(); };

  function offerWorkflow(actions) {
    const box = noriEl("div", { class: "nori-meet-dup-warning" });
    box.appendChild(noriEl("p", { class: "nori-checkin-entry-title", text: "Execute Nori plan" }));
    box.appendChild(noriEl("p", { class: "nori-history-line", text: actions.map(function(a){ return a.type; }).join(" → ") }));
    const row=noriEl("div",{class:"nori-checkin-actions"});
    const yes=noriEl("button",{class:"nori-btn nori-btn-primary",text:"Review & Do it"});
    const no=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"Not now"}); row.appendChild(yes);row.appendChild(no);box.appendChild(row);log.appendChild(box);log.scrollTop=log.scrollHeight;
    yes.addEventListener("click",function(){box.remove(); if(window.NoriOperativeV33){window.NoriOperativeV33.executeWorkflow(actions,{source:window.__noriInputChannel||"text",confirmed:true,sessionId:"default"}).then(function(r){addMessage("nori",r&&r.ok?"The plan completed and each operation was verified.":"The plan stopped after a failure; I will not pretend the remaining steps were completed.");}).catch(function(e){addMessage("nori","The plan failed: "+e.message);});}});
    no.addEventListener("click",function(){box.remove();});
  }

  // Nori can PROPOSE an action mid-conversation (start_focus_mode,
  // schedule_reminder, request_verification_photo) but never execute one
  // on its own — every action shows here as its own confirm/cancel card,
  // same pattern as memory suggestions, and only runs after a tap.
  function offerAction(action) {
    const box = noriEl("div", { class: "nori-meet-dup-warning" });
    const labels = {
      start_focus_mode: "\ud83d\udd12 Start Focus Mode",
      schedule_reminder: "\u23f0 Schedule a Reminder",
      request_verification_photo: "\ud83d\udcf7 Take a Verification Photo"
    };
    box.appendChild(noriEl("p", { class: "nori-checkin-entry-title", text: labels[action.type] || action.type }));
    if (action.reason) box.appendChild(noriEl("p", { class: "nori-history-line", text: action.reason }));
    if (action.type === "start_focus_mode" && action.apps) {
      box.appendChild(noriEl("p", { class: "nori-history-line", text: "Apps: " + action.apps.join(", ") }));
    }
    if (action.type === "schedule_reminder") {
      box.appendChild(noriEl("p", { class: "nori-history-line", text: (action.label || "Reminder") + " in " + action.minutesFromNow + " min" }));
    }
    if (action.type === "request_verification_photo" && action.claim) {
      box.appendChild(noriEl("p", { class: "nori-history-line", text: "Claim: " + action.claim }));
    }

    const actionsRow = noriEl("div", { class: "nori-checkin-actions" });
    const yesBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "Do it" });
    const noBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "Not now" });
    actionsRow.appendChild(yesBtn);
    actionsRow.appendChild(noBtn);
    box.appendChild(actionsRow);
    log.appendChild(box);
    log.scrollTop = log.scrollHeight;

    yesBtn.addEventListener("click", function () {
      box.remove();
      if (action.__v33ProposalId && window.NoriOperativeV33 && window.NoriOperativeV33.confirm) {
        window.NoriOperativeV33.confirm(action.__v33ProposalId).then(function(result){
          if (result && result.ok) addMessage("nori", "The operation completed and was verified.");
          else addMessage("nori", "The operation was not completed: " + ((result && result.error && result.error.message) || (result && result.reason) || "verification failed") + ".");
        }).catch(function(err){ addMessage("nori", "The operation was not executed: " + err.message); });
      } else runAction(action);
    });
    noBtn.addEventListener("click", function () { box.remove(); });
  }

  function runAction(action) {
    // V31: all AI side effects enter the same capability/action lifecycle used
    // by voice and deterministic commands. The legacy inline executor below
    // remains only as a compatibility fallback for builds where V31 is absent.
    if (window.NoriOperativeV33) {
      window.NoriOperativeV33.execute(action.type, Object.assign({}, action, {type: undefined}), {source: window.__noriInputChannel === "voice" ? "voice" : "text", confirmed: true, idempotencyKey: "ui:" + String(action.type) + ":" + Date.now()}).then(function(result){
        if (result && result.ok) {
          var label=(result.proposal&&result.proposal.definition&&result.proposal.definition.label)||action.type;
          addMessage("nori", label + " completed and was verified.");
        } else if (result && result.status === "confirmation_required") {
          addMessage("nori", "This action is ready for confirmation.");
        } else {
          addMessage("nori", "The action was not completed: " + ((result&&result.reason)||"verification failed") + ".");
        }
      }).catch(function(err){ addMessage("nori", "The action was not executed: " + err.message); });
      return;
    }
    // Defense-in-depth compatibility path for pre-V31 builds.
    if (!action || typeof action !== "object") { addMessage("nori", "That action was invalid, so nothing was executed."); return; }
    if (action.type === "start_focus_mode") {
      if (!Array.isArray(action.apps) || action.apps.length < 1 || action.apps.length > 12) { addMessage("nori", "Invalid Focus Mode proposal — nothing started."); return; }
    } else if (action.type === "schedule_reminder") {
      var mins = Number(action.minutesFromNow);
      if (!Number.isInteger(mins) || mins < 1 || mins > 10080 || typeof action.label !== "string" || !action.label.trim()) { addMessage("nori", "Invalid reminder proposal — nothing scheduled."); return; }
    } else if (action.type === "request_verification_photo") {
      var claim = String(action.claim || "").trim();
      if (!claim || /shower|bath|hygiene|wash|naked|body|exercise|workout|gym|push-up|pushup|squat|weight|physical|undressed|shirtless/i.test(claim) || !/assignment|homework|worksheet|notes?|problem|question|exam|test|project|lab|essay|answer|solution|school|class|chapter|page/i.test(claim)) { addMessage("nori", "Invalid verification proposal — nothing opened."); return; }
    } else { addMessage("nori", "Unknown action — nothing was executed."); return; }
    if (action.type === "start_focus_mode") {
      if (typeof noriBlockerStart !== "function") { addMessage("nori", "Focus Mode isn't available in this build."); return; }
      const appMap = {};
      (typeof NORI_BLOCKABLE_APPS !== "undefined" ? NORI_BLOCKABLE_APPS : []).forEach(function (a) { appMap[a.label.toLowerCase()] = a.package; });
      const packages = (action.apps || []).map(function (label) { return appMap[String(label).toLowerCase()]; }).filter(Boolean);
      if (!packages.length) { addMessage("nori", "I didn't recognize any of those app names \u2014 nothing started."); return; }
      noriBlockerStart(packages).then(function () {
        addMessage("nori", "Focus Mode started \u2014 " + packages.length + " app(s) paused.");
      }).catch(function (err) { addMessage("nori", "Couldn't start Focus Mode: " + err.message); });
    } else if (action.type === "schedule_reminder") {
      if (typeof noriReminderSchedule !== "function") { addMessage("nori", "Reminders aren't available in this build."); return; }
      const when = new Date(Date.now() + (Number(action.minutesFromNow) || 0) * 60000);
      noriReminderSchedule(action.label || "Nori reminder", action.reason || "", when).then(function () {
        addMessage("nori", "Reminder set for " + when.toLocaleTimeString() + ".");
      }).catch(function (err) { addMessage("nori", "Couldn't schedule that: " + err.message); });
    } else if (action.type === "request_verification_photo") {
      if (typeof noriCameraVerify !== "function") { addMessage("nori", "Camera verification isn't available in this build."); return; }
      addMessage("nori", "Opening the camera\u2026");
      noriCameraVerify(action.claim || "").then(function (result) {
        const verdict = result.plausible ? "\u2713 Looks consistent with that." : "\u26a0 Doesn't look consistent with that.";
        addMessage("nori", verdict + " " + (result.whatISee || "") + " " + (result.assessment || ""));
      }).catch(function (err) { addMessage("nori", "Couldn't verify that: " + err.message); });
    }
  }

  // Nori only ever PROPOSES remembering something the student explicitly
  // said (enforced in api/brain.js's system prompt) — but nothing gets
  // saved without the student confirming here, same pattern as every other
  // save in this app (duplicate detection, Human Override readouts, etc.).
  function offerMemorySuggestions(suggestions) {
    const box = noriEl("div", { class: "nori-meet-dup-warning" });
    box.appendChild(noriEl("p", { class: "nori-checkin-entry-title", text: "\ud83d\udcad Nori noticed something worth remembering" }));
    suggestions.forEach(function (s) { box.appendChild(noriEl("p", { class: "nori-history-line", text: "\u201c" + s + "\u201d" })); });
    const actions = noriEl("div", { class: "nori-checkin-actions" });
    const yesBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "Remember this" });
    const noBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "Don't save" });
    actions.appendChild(yesBtn);
    actions.appendChild(noBtn);
    box.appendChild(actions);
    log.appendChild(box);
    log.scrollTop = log.scrollHeight;

    yesBtn.addEventListener("click", function () {
      suggestions.forEach(function (s) {
        if (window.noriBrainV12 && noriBrainV12.memoryAdd) noriBrainV12.memoryAdd(s, {source:"brain_confirmed", confidence:1, status:"confirmed"});
        else noriMemoryAddItem(s, "brain");
      });
      box.remove();
      addMessage("nori", "Got it, I'll remember that.");
    });
    noBtn.addEventListener("click", function () { box.remove(); });
  }

  sendBtn.addEventListener("click", sendCurrentText);
  textInput.addEventListener("keydown", function (e) {
    if (e.key === "Enter") sendCurrentText();
  });

  /* ==================== WHAT NORI REMEMBERS ==================== */

  const memoryCard = noriEl("section", { class: "nori-panel" });
  const memoryToggle = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "\ud83e\udde0 What Nori Remembers" });
  memoryCard.appendChild(memoryToggle);

  const memoryBody = noriEl("div", { class: "nori-meet-quick-form", style: "display:none" });
  const memoryList = noriEl("div", { class: "nori-history-list" });
  const memoryAddRow = noriEl("div", { class: "nori-meet-marks-row" });
  const memoryAddInput = noriEl("input", { type: "text", class: "nori-checkin-typed", placeholder: "Tell Nori something to remember\u2026" });
  const memoryAddBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "Add" });
  memoryAddRow.appendChild(memoryAddInput);
  memoryAddRow.appendChild(memoryAddBtn);
  memoryBody.appendChild(memoryList);
  memoryBody.appendChild(memoryAddRow);
  memoryCard.appendChild(memoryBody);
  const publicVoiceToggle = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "PUBLIC VOICE: SAFE" });
  publicVoiceToggle.title = "Keep sensitive memories out of ordinary voice context.";
  publicVoiceToggle.addEventListener("click", function () {
    if (!window.noriBrainV10) return;
    const next = !noriBrainV10.publicMode();
    noriBrainV10.setPublicMode(next);
    publicVoiceToggle.textContent = next ? "PUBLIC VOICE: SAFE" : "PUBLIC VOICE: NORMAL";
  });
  memoryCard.appendChild(publicVoiceToggle);
  wrap.appendChild(memoryCard);

  memoryToggle.addEventListener("click", function () {
    memoryBody.style.display = memoryBody.style.display === "none" ? "flex" : "none";
    if (memoryBody.style.display !== "none") renderMemoryList();
  });

  function renderMemoryList() {
    memoryList.innerHTML = "";
    const v12 = window.noriBrainV12;
    const memory = v12 && v12.getMemory ? v12.getMemory() : [];
    if (!memory.length) {
      memoryList.appendChild(noriEl("p", { class: "nori-empty-note", text: "Nothing remembered yet." }));
      return;
    }
    memory.forEach(function (item) {
      const row = noriEl("div", { class: "nori-checkin-entry-preview" });
      const confidence = Math.round((Number(item.confidence == null ? 1 : item.confidence) * 100));
      row.appendChild(noriEl("p", { class: "nori-history-line", text: item.text + " (" + (item.status || "confirmed") + ", " + confidence + "% confidence)" }));
      const forgetBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "Forget" });
      forgetBtn.addEventListener("click", function () {
        if (v12 && v12.memoryRemove) v12.memoryRemove(item.id);
        else if (typeof noriMemoryRemoveItem === "function") noriMemoryRemoveItem(0);
        renderMemoryList();
      });
      row.appendChild(forgetBtn);
      memoryList.appendChild(row);
    });
  }

  memoryAddBtn.addEventListener("click", function () {
    if (!memoryAddInput.value.trim()) return;
    if (window.noriBrainV12 && noriBrainV12.memoryAdd) noriBrainV12.memoryAdd(memoryAddInput.value, {source:"user_confirmed", confidence:1, status:"confirmed"});
    else noriMemoryAddItem(memoryAddInput.value, "user");
    memoryAddInput.value = "";
    renderMemoryList();
  });

  /* ==================== QUICK ADD RESULT FORM ==================== */

  const quickCard = noriEl("section", { class: "nori-panel" });
  const quickToggle = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "\ud83d\udcdd Quick Add Result" });
  if (!NORI_FEATURES.quickAddResult) { quickToggle.disabled = true; quickToggle.textContent = "\ud83d\udcdd Quick Add Result \u2014 coming soon"; }
  quickCard.appendChild(quickToggle);

  const quickForm = noriEl("div", { class: "nori-meet-quick-form", style: "display:none" });

  const subjectSelect = noriEl("select", { class: "nori-meet-select" });
  NORI_MEET_SUBJECTS.forEach(function (s) { subjectSelect.appendChild(noriEl("option", { value: s, text: s })); });

  const typeSelect = noriEl("select", { class: "nori-meet-select" });
  NORI_MEET_ASSESSMENT_TYPES.forEach(function (t) { typeSelect.appendChild(noriEl("option", { value: t, text: t })); });

  const scoreInput = noriEl("input", { type: "number", min: "0", max: "100", class: "nori-checkin-typed", placeholder: "Score % (0-100)" });
  const topicInput = noriEl("input", { type: "text", class: "nori-checkin-typed", placeholder: "Topic / unit (optional)" });
  const marksRow = noriEl("div", { class: "nori-meet-marks-row" });
  const marksInput = noriEl("input", { type: "text", class: "nori-checkin-typed", placeholder: "Marks, e.g. 40/50 or 5/5 (optional)" });
  const speakScoreBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "\ud83c\udf99\ufe0f Speak" });
  marksRow.appendChild(marksInput);
  marksRow.appendChild(speakScoreBtn);
  const dateInput = noriEl("input", { type: "date", class: "nori-checkin-typed" });
  dateInput.value = new Date().toISOString().slice(0, 10);

  const categoryReadout = noriEl("p", { class: "nori-meet-category-readout" });

  // Recovery-gate check — only shown when this subject already has an
  // unresolved prior failure (streak ≥ 1), since the question only makes
  // sense as "was recovery from LAST time completed before this one?"
  const gateRow = noriEl("div", { style: "display:none" });
  const gateSelect = noriEl("select", { class: "nori-meet-select" });
  [
    ["", "Recovery gate from last time \u2014 was it completed? (re-test passed, backlog cleared)"],
    ["yes", "Yes \u2014 recovery from last time was completed"],
    ["no", "No \u2014 recovery from last time was NOT completed"],
    ["unsure", "Not sure / not tracked"]
  ].forEach(function (pair) { gateSelect.appendChild(noriEl("option", { value: pair[0], text: pair[1] })); });
  gateRow.appendChild(noriEl("label", { class: "nori-meet-field-label", text: "Recovery gate check" }));
  gateRow.appendChild(gateSelect);

  // Human Override section — only relevant when logging a below-80 result.
  const overrideSelect = noriEl("select", { class: "nori-meet-select" });
  overrideSelect.appendChild(noriEl("option", { value: "", text: "None \u2014 no circumstance to report" }));
  NORI_MEET_OVERRIDE_CATEGORIES.forEach(function (c) { overrideSelect.appendChild(noriEl("option", { value: c, text: c })); });

  const overrideDescInput = noriEl("textarea", {
    class: "nori-checkin-typed nori-meet-override-desc", rows: "3",
    placeholder: "What actually happened? Be specific \u2014 this is read for real detail, not scored by you."
  });

  // The remaining 4 factors below are still self-ratable by hand, but this
  // button offers an AI estimate instead — reads the description above the
  // same way a human reviewer would, and is explicitly instructed to be
  // skeptical of vague claims. Not independent verification (it only has
  // the same description the student wrote), but a specific, plausible
  // narrative is genuinely harder to construct than dragging four sliders
  // to 10, and the model is told to default low unless the text supports
  // otherwise. Evidence/weakness stay locally computed either way — the
  // AI's guesses for those two are discarded in favor of the real-data
  // versions above, which are already grounded, not estimated.
  const estimateBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "\ud83c\udfaf Estimate with Nori" });
  const estimateStatus = noriEl("p", { class: "nori-meet-status" });

  // Only importance, difficulty, immediacy, and impact are self-rated now —
  // evidence and weakness are computed (see noriMeetComputeEvidenceScore /
  // noriMeetComputeWeaknessScore above), not typed in by the student.
  const factorLabels = [
    ["importance", "Importance (how central to wellbeing/safety) 0-10"],
    ["difficulty", "How hard to resolve right now 0-10"],
    ["immediacy", "How time-sensitive 0-10"],
    ["impact", "How much it affects doing recovery work 0-10"]
  ];
  const factorInputs = {};
  const factorBlock = noriEl("div", { class: "nori-meet-factor-block", style: "display:none" });
  factorBlock.appendChild(noriEl("label", { class: "nori-meet-field-label", text: "Describe the circumstance" }));
  factorBlock.appendChild(overrideDescInput);
  factorBlock.appendChild(estimateBtn);
  factorBlock.appendChild(estimateStatus);
  factorLabels.forEach(function (pair) {
    const input = noriEl("input", { type: "number", min: "0", max: "10", class: "nori-checkin-typed", placeholder: "0" });
    factorInputs[pair[0]] = input;
    factorBlock.appendChild(noriEl("label", { class: "nori-meet-field-label", text: pair[1] }));
    factorBlock.appendChild(input);
  });
  const overrideReadout = noriEl("p", { class: "nori-meet-category-readout", style: "display:none" });

  estimateBtn.addEventListener("click", function () {
    const description = overrideDescInput.value.trim();
    const wordCount = description.split(/\s+/).filter(Boolean).length;
    if (wordCount < NORI_MEET_MIN_OVERRIDE_DESCRIPTION_WORDS) {
      estimateStatus.textContent = "Write at least " + NORI_MEET_MIN_OVERRIDE_DESCRIPTION_WORDS + " words describing what happened first.";
      return;
    }
    estimateStatus.textContent = "Asking Nori to estimate\u2026";
    fetch(NORI_BRAIN_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ mode: "estimate_override_factors", description: description, category: overrideSelect.value })
    }).then(function (resp) {
      if (!resp.ok) throw new Error("Backend returned " + resp.status);
      return resp.json();
    }).then(function (data) {
      if (!data.factors) throw new Error("No estimate returned");
      ["importance", "difficulty", "immediacy", "impact"].forEach(function (key) {
        if (factorInputs[key]) factorInputs[key].value = data.factors[key];
      });
      estimateStatus.textContent = "\u2713 " + (data.note || "Estimated \u2014 you can still adjust any value below.");
      refreshOverrideReadout();
    }).catch(function (err) {
      estimateStatus.textContent = "Couldn't reach Nori for an estimate (" + err.message + ") \u2014 enter the values below by hand instead.";
    });
  });

  overrideSelect.addEventListener("change", function () {
    factorBlock.style.display = overrideSelect.value ? "block" : "none";
    overrideReadout.style.display = "none";
  });
  overrideDescInput.addEventListener("input", refreshOverrideReadout);
  Object.keys(factorInputs).forEach(function (key) {
    factorInputs[key].addEventListener("input", refreshOverrideReadout);
  });

  // Builds the full 6-factor object: 4 self-rated + evidence/weakness
  // computed from real signals, never typed in.
  function noriMeetGatherOverrideFactors() {
    const factors = {};
    Object.keys(factorInputs).forEach(function (key) { factors[key] = Number(factorInputs[key].value) || 0; });
    factors.evidence = noriMeetComputeEvidenceScore(overrideDescInput.value);
    factors.weakness = noriMeetComputeWeaknessScore(subjectSelect.value, overrideSelect.value);
    return factors;
  }

  function refreshOverrideReadout() {
    if (!overrideSelect.value) { overrideReadout.style.display = "none"; return; }
    const wordCount = overrideDescInput.value.trim().split(/\s+/).filter(Boolean).length;
    overrideReadout.style.display = "block";
    if (wordCount < NORI_MEET_MIN_OVERRIDE_DESCRIPTION_WORDS) {
      overrideReadout.textContent = "Describe what actually happened (at least " + NORI_MEET_MIN_OVERRIDE_DESCRIPTION_WORDS + " words) before this can be scored \u2014 a vague entry can't unlock a high severity level no matter how the other sliders are set.";
      return;
    }
    const factors = noriMeetGatherOverrideFactors();
    const result = noriMeetScoreOverride(factors);
    const guard = noriMeetCheckOverrideGuard(subjectSelect.value, overrideSelect.value);
    overrideReadout.textContent = guard.blocked
      ? "\u26d4 " + guard.note
      : "Priority level: " + result.level + " (score " + result.score + ") \u2192 " + result.adjustment +
        "\n(Evidence " + factors.evidence + "/10 from what you wrote, known-pattern " + factors.weakness + "/10 from your actual history \u2014 not self-rated.)";
  }

  const saveBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "\u2713 Save Result" });
  const quickStatus = noriEl("p", { class: "nori-meet-status" });

  [
    noriEl("label", { class: "nori-meet-field-label", text: "Subject" }), subjectSelect,
    noriEl("label", { class: "nori-meet-field-label", text: "Assessment type" }), typeSelect,
    noriEl("label", { class: "nori-meet-field-label", text: "Marks" }), marksRow,
    noriEl("label", { class: "nori-meet-field-label", text: "Score" }), scoreInput,
    categoryReadout,
    noriEl("label", { class: "nori-meet-field-label", text: "Topic / unit" }), topicInput,
    noriEl("label", { class: "nori-meet-field-label", text: "Date" }), dateInput,
    noriEl("label", { class: "nori-meet-field-label", text: "Circumstance affecting this result? (optional)" }), overrideSelect,
    factorBlock, overrideReadout,
    saveBtn, quickStatus
  ].forEach(function (el) { quickForm.appendChild(el); });

  let usedVoiceInput = false;

  function refreshCategoryReadout() {
    const val = scoreInput.value.trim();
    if (!val) { categoryReadout.textContent = ""; return; }
    const subject = subjectSelect.value;
    const cat = noriMeetCategorize(Number(val), subject);
    let text = cat.percent + "% \u2192 " + cat.system + ": " + cat.label;
    if (cat.actions && cat.actions.length) {
      text += "\nNext (" + cat.degree + "): " + cat.actions.join(" \u2022 ");
    }
    if (cat.recoveryGate && !cat.recoveryGate.met && cat.recoveryGate.missing.length) {
      text += "\n\u26a0\ufe0f Recovery gate not yet cleared \u2014 " + cat.recoveryGate.missing.join("; ") +
        ". A passing score alone won't reset the Degree until this is verified.";
    }
    if (cat.percent >= 80) {
      const priorHistory = (noriHistoryLoadAll()[subject] || []);
      const preview = noriMeetCheckAwards(subject, cat.percent, priorHistory, dateInput.value, typeSelect.value);
      if (preview.length) {
        const bits = preview.map(function (a) {
          return a.level === "Merit" ? "Merit +" + a.points + " pts" : a.level + ": " + a.category;
        });
        text += "\n\ud83c\udfc6 Will earn: " + bits.join(" \u00b7 ");
      }
    }
    categoryReadout.textContent = text;
  }

  subjectSelect.addEventListener("change", refreshCategoryReadout);
  typeSelect.addEventListener("change", refreshCategoryReadout);
  dateInput.addEventListener("change", refreshCategoryReadout);

  // Typing "5/5" (or "40/50") directly into Marks auto-computes the percent —
  // no need to do the division yourself.
  marksInput.addEventListener("input", function () {
    usedVoiceInput = false;
    const parsed = noriMeetParseScoreText(marksInput.value);
    if (parsed) { scoreInput.value = parsed.percent; refreshCategoryReadout(); }
  });
  scoreInput.addEventListener("input", function () { usedVoiceInput = false; refreshCategoryReadout(); });

  speakScoreBtn.addEventListener("click", function () {
    if (!NORI_SPEECH_SUPPORTED) {
      quickStatus.textContent = "Voice input isn't supported here.";
      return;
    }
    quickStatus.textContent = "\ud83c\udf99\ufe0f Listening \u2014 say a score, e.g. \u201c18 out of 20\u201d or \u201c82 percent\u201d\u2026";
    noriListenOnce().then(function (heard) {
      const parsed = noriMeetParseScoreText(heard);
      if (!parsed) {
        quickStatus.textContent = "Didn't catch a score in \u201c" + heard + "\u201d \u2014 try again, e.g. \u201c18 out of 20\u201d.";
        return;
      }
      if (parsed.marksText) marksInput.value = parsed.marksText;
      scoreInput.value = parsed.percent;
      usedVoiceInput = true;
      refreshCategoryReadout();
      quickStatus.textContent = "\ud83c\udf99\ufe0f Heard \u201c" + heard + "\u201d \u2192 " + parsed.percent + "%.";
    }).catch(function (err) {
      quickStatus.textContent = err.message === "no-speech" ? "Didn't hear anything \u2014 try again." : "Mic error (" + err.message + ").";
    });
  });

  const dupWarning = noriEl("div", { class: "nori-meet-dup-warning", style: "display:none" });
  const dupReasonText = noriEl("p", { class: "nori-meet-dup-reason" });
  const dupActions = noriEl("div", { class: "nori-checkin-actions" });
  const dupSaveAnywayBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "Save anyway" });
  const dupCancelBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "Don't save" });
  dupActions.appendChild(dupSaveAnywayBtn);
  dupActions.appendChild(dupCancelBtn);
  dupWarning.appendChild(noriEl("p", { class: "nori-checkin-entry-title", text: "\u26a0 This might already be saved" }));
  dupWarning.appendChild(dupReasonText);
  dupWarning.appendChild(dupActions);
  quickForm.appendChild(dupWarning);

  quickCard.appendChild(quickForm);
  wrap.appendChild(quickCard);

  quickToggle.addEventListener("click", function () {
    quickForm.style.display = quickForm.style.display === "none" ? "flex" : "none";
  });

  /* ---------------- duplicate detection ---------------- */

  // Looks for an existing row that matches the candidate closely enough to
  // be worth flagging before saving \u2014 checked strongest signal first.
  function findPossibleDuplicate(existingRows, candidate) {
    for (const row of existingRows) {
      const sameDate = row.date && candidate.date && row.date === candidate.date;
      const sameScore = row.score !== "" && row.score !== undefined && row.score !== null &&
        Number(row.score) === Number(candidate.score);
      const sameTask = row.task && candidate.task &&
        row.task.trim().toLowerCase() === candidate.task.trim().toLowerCase();
      const sameUnit = row.unit && candidate.unit &&
        row.unit.trim().toLowerCase() === candidate.unit.trim().toLowerCase();
      const sameMarks = (row.marks || "") === (candidate.marks || "");

      if (sameDate && sameScore && sameTask && sameUnit && sameMarks) {
        return { reason: "This is identical to an entry already saved on " + row.date + ": \u201c" + row.task + "\u201d, " + row.score + "%." };
      }
      if (sameDate && sameScore) {
        return { reason: "Same date (" + row.date + ") and same score (" + row.score + "%) as an existing entry: \u201c" + row.task + "\u201d." };
      }
      if (sameDate && sameTask) {
        return { reason: "Same date (" + row.date + ") and same assessment type (\u201c" + row.task + "\u201d) as an existing entry." };
      }
      if (sameScore && sameTask && sameUnit) {
        return { reason: "Same score (" + row.score + "%), assessment type, and topic (\u201c" + row.unit + "\u201d) as an entry from " + (row.date || "an earlier date") + "." };
      }
    }
    return null;
  }

  const NORI_BRAIN_ASSESSMENT_TYPES = {
    "Practice": "practice", "Assignment": "assignment", "Quiz": "quiz",
    "Weekly Assessment": "weekly_assessment", "Unit Test": "unit_test",
    "Mock Examination": "mock_examination", "Final Examination": "final_examination",
    "Model Exam": "mock_examination"
  };
  const NORI_BRAIN_DOMAIN_BY_CATEGORY = {
    "High-Dopamine Digital Distraction": "digital_social",
    "Entertainment Before Obligation": "entertainment",
    "Unauthorized Communication & FOMO": "digital_social",
    "Academic Rabbit Holes & Hyper-Curiosity": "academic_rabbit_hole",
    "Fake Productivity & Over-Planning": "planning_system",
    "Academic Delay & Last-Minute Rescue": "academic_rabbit_hole",
    "Boredom Escape": "entertainment",
    "Loophole & Purpose Violation": "planning_system",
    "False Status & Concealment": "status_recognition"
  };
  const NORI_BRAIN_OVERRIDE_REASON = {
    "Emergency": "emergency", "Legitimate academic use": "legitimate_academic_use",
    "Technical failure": "technical_failure", "Incorrect data": "incorrect_data",
    "Assessment error": "assessment_error", "Extraordinary circumstance": "extraordinary_circumstance",
    "System misclassification": "system_misclassification"
  };

  function noriMeetBrainHistory(subject, domain) {
    const all = noriHistoryLoadAll();
    const prior = all[subject] || [];
    const breachAll = noriBreachHistoryLoadAll();
    const breaches = [];
    Object.keys(NORI_BRAIN_DOMAIN_BY_CATEGORY).forEach(function(k){ if (NORI_BRAIN_DOMAIN_BY_CATEGORY[k] === domain) (breachAll[k] || []).forEach(function(x){ breaches.push(x); }); });
    return {
      degree1EventsUnresolved: prior.filter(function(r){ return typeof r.score === "number" && r.score < 80 && !r.overridden; }).length,
      degree1EventsTotal: prior.filter(function(r){ return typeof r.score === "number" && r.score < 80; }).length,
      sameDomainRepeatCount: breaches.length,
      degree2EventsTotal: prior.filter(function(r){ return r.degree === 2; }).length,
      priorIneffectiveIds: []
    };
  }

  async function noriMeetRunBrainResult(subject, row, override) {
    const domain = override && override.category ? (NORI_BRAIN_DOMAIN_BY_CATEGORY[override.category] || "academic_rabbit_hole") : "academic_correction";
    const input = {
      subject: subject,
      assessment: { type: NORI_BRAIN_ASSESSMENT_TYPES[row.task] || "quiz", percentage: Number(row.score), missedConcepts: row.unit ? [row.unit] : [], totalConceptsCovered: row.unit ? 1 : 0, carelessErrorCount: 0, applicationErrorCount: 0 },
      contextEvent: { domain: domain, durationMinutes: 0, statedPurpose: "academic result", isEmergency: false, wasAccidental: false, continuedAfterAwareness: false, reportedDifficultDay: false, evidenceSources: ["user_report"] },
      history: noriMeetBrainHistory(subject, domain)
    };
    const result = await noriBrainEngine.processAcademicEvent(input);
    if (override && override.category && override.granted && result && result.auditRecord && result.auditRecord.eventId) {
      const reason = NORI_BRAIN_OVERRIDE_REASON[override.category] || "extraordinary_circumstance";
      await noriBrainEngine.requestOverride(result.auditRecord.eventId, { reason: reason, evidence: [overrideDescInput.value.trim()], requestedScope: "consequence" }, { recentOverrideCount: 0 });
    }
    return result;
  }

  async function noriMeetScheduleDecisionReminders(brainResult, row) {
    if (!NORI_FEATURES.reminders || typeof noriReminderRequestPermission !== "function") return;
    const c = brainResult && brainResult.consequences && brainResult.consequences.primary;
    if (!c || typeof noriReminderSchedule !== "function") return;
    try {
      await noriReminderRequestPermission();
      if (c.defaultDurationHours) {
        const end = new Date(Date.now() + c.defaultDurationHours * 3600000);
        await noriReminderSchedule("Nori consequence ending", c.label + " is scheduled to end now. Review recovery before restoring normal access.", end);
      } else {
        await noriReminderSchedule("Nori recovery review", "An active Nori consequence is awaiting recovery review.", new Date(Date.now() + 24 * 3600000));
      }
    } catch (_) {}
  }

  async function commitSave(subject, key, row, status, cat, override) {
    let brainResult;
    try { brainResult = await noriMeetRunBrainResult(subject, row, override); }
    catch (err) { quickStatus.textContent = "Decision engine unavailable — result was NOT saved. " + err.message; return; }
    const priorHistory = (noriHistoryLoadAll()[subject] || []).slice();
    const paused = override && override.granted && (override.result.level === "Critical" || override.result.level === "High");

    const existing = noriLoadEntries(key);
    existing.push(row);
    if (!noriSaveEntries(key, existing)) {
      quickStatus.textContent = "Result was evaluated but could not be saved on this device. Check storage space and try again.";
      return;
    }

    // Consequence reminders are tied to the same authoritative brain result
    // that produced the event. This is deliberately best-effort on web and
    // becomes a real local notification only in the Android app.
    noriMeetScheduleDecisionReminders(brainResult, row).catch(function () {});

    // Award System — deterministic brain result is now the authority.
    let awards = [];
    if (!paused && brainResult) {
      const ledger = (brainResult.state && brainResult.state.meritLedger) || null;
      try {
        const merit = await noriBrainEngine.grantScoreBandMerit(ledger, row.score, row.task === "Model Exam" ? "model_exam" : "academic_score", brainResult.auditRecord && brainResult.auditRecord.eventId);
        if (merit && merit.granted) awards.push({ level: "Merit", points: merit.entry.meritPoints, perfect: !!merit.entry.badge, reason: merit.entry.title + " — " + row.score + "%" });
      } catch (_) {}
      if (awards.length) noriMeetSaveAwards(awards, row.date);
    }

    // Record this result in the subject's history so Degree escalation
    // works next time. A PAUSED (Critical/High Override) entry is marked
    // overridden so it neither extends nor resets the failure streak —
    // pausing is not automatically failure, per Human Override's core rule.
    noriHistoryAppend(subject, {
      date: row.date, score: row.score,
      band: paused ? null : ((brainResult && brainResult.academicResult && brainResult.academicResult.band) || null),
      degree: paused ? null : ((brainResult && brainResult.academicResult && brainResult.academicResult.band) ? brainResult.degree : null),
      overridden: paused
    });

    if (override && override.category) {
      noriOverrideHistoryAppend(subject, { date: row.date, category: override.category, granted: !!override.granted });
    }

    if (paused) {
      const decKey = noriStorageKey("phase-5", "emergency-recovery", "recovery-decision-page");
      const rows = ["What caused the loss of control?", "What work is currently at risk?", "What can be recovered first?",
        "What can wait?", "What distraction or process failure must be controlled?", "What evidence will prove recovery?",
        "What would trigger further escalation?"];
      const entry = { date: row.date, values: {}, freeText: {}, fixedTable: {} };
      rows.forEach(function (r) { entry.fixedTable[r] = { answer: "" }; });
      entry.fixedTable["What caused the loss of control?"].answer =
        override.category + ": " + overrideDescInput.value.trim() +
        " (Priority level: " + override.result.level + ", score " + override.result.score + ") \u2014 " + override.result.adjustment;
      const decExisting = noriLoadEntries(decKey);
      decExisting.push(entry);
      noriSaveEntries(decKey, decExisting);
    }

    const voiceTag = usedVoiceInput ? "\ud83c\udf99\ufe0f Saved via voice \u2014 " : "Saved \u2014 ";
    let statusLine;
    if (paused) {
      statusLine = voiceTag + "Human Override (" + override.result.level + ") \u2014 " + subject + " logged, recovery plan paused. Recorded on the Phase 5 Recovery Decision Page.";
    } else {
      statusLine = voiceTag + subject + " Assessment Record (" + status + ").";
      if (override && override.category) statusLine += " Circumstance noted (" + override.result.level + " \u2014 " + override.result.adjustment + ")";
      if (awards.length) {
        const awardBits = awards.map(function (a) {
          return a.level === "Merit" ? "Merit +" + a.points + " pts" : a.category.charAt(0).toUpperCase() + a.category.slice(1);
        });
        statusLine += " \ud83c\udfc6 " + awardBits.join(" \u00b7 ") + ".";
      }
    }
    quickStatus.textContent = statusLine;

    scoreInput.value = "";
    topicInput.value = "";
    marksInput.value = "";
    categoryReadout.textContent = "";
    overrideSelect.value = "";
    overrideDescInput.value = "";
    Object.keys(factorInputs).forEach(function (key) { factorInputs[key].value = ""; });
    factorBlock.style.display = "none";
    overrideReadout.style.display = "none";
    usedVoiceInput = false;
    dupWarning.style.display = "none";
    // Deliberately not calling noriRoute() here — this page's own chat
    // and listening state must not be wiped by a re-render.
  }

  saveBtn.addEventListener("click", function () {
    dupWarning.style.display = "none";
    quickStatus.textContent = "";
    const score = scoreInput.value.trim();
    if (!score) { quickStatus.textContent = "Enter a score first."; return; }
    const numScore = Number(score);
    const status = numScore >= 80 ? "On track" : (numScore >= 60 ? "Needs attention" : "Recovery");

    const subject = subjectSelect.value;
    const cat = noriMeetCategorize(numScore, subject);

    let override = null;
    if (overrideSelect.value) {
      const wordCount = overrideDescInput.value.trim().split(/\s+/).filter(Boolean).length;
      if (wordCount < NORI_MEET_MIN_OVERRIDE_DESCRIPTION_WORDS) {
        quickStatus.textContent = "Describe the circumstance (at least " + NORI_MEET_MIN_OVERRIDE_DESCRIPTION_WORDS + " words) before saving \u2014 or clear the circumstance selection to log this as a plain result.";
        return;
      }
      const guard = noriMeetCheckOverrideGuard(subject, overrideSelect.value);
      if (guard.blocked) {
        override = { category: overrideSelect.value, granted: false, guardNote: guard.note };
      } else {
        const factors = noriMeetGatherOverrideFactors();
        override = { category: overrideSelect.value, granted: true, result: noriMeetScoreOverride(factors) };
      }
    }

    const slug = NORI_MEET_SUBJECT_SLUGS[subject];
    const key = noriStorageKey("phase-1", "control-pages-system", "assessment-record-" + slug);
    const row = {
      task: typeSelect.value,
      date: dateInput.value,
      marks: marksInput.value.trim(),
      score: numScore,
      target: "",
      unit: topicInput.value.trim(),
      status: status
    };

    const existing = noriLoadEntries(key);
    const dup = findPossibleDuplicate(existing, row);

    if (dup) {
      dupReasonText.textContent = dup.reason;
      dupWarning.style.display = "block";
      dupSaveAnywayBtn.onclick = function () { commitSave(subject, key, row, status, cat, override); };
      dupCancelBtn.onclick = function () { dupWarning.style.display = "none"; quickStatus.textContent = "Not saved."; };
      return;
    }

    commitSave(subject, key, row, status, cat, override);
  });

  /* ==================== REPORT BREACH (System Integrity + Disciplinary) ==================== */

  const breachCard = noriEl("section", { class: "nori-panel" });
  const breachToggle = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "\u26a0\ufe0f Report Distraction / Breach" });
  if (!NORI_FEATURES.reportBreach) { breachToggle.disabled = true; breachToggle.textContent = "\u26a0\ufe0f Report Distraction / Breach \u2014 coming soon"; }
  breachCard.appendChild(breachToggle);

  const breachForm = noriEl("div", { class: "nori-meet-quick-form", style: "display:none" });

  const breachCategorySelect = noriEl("select", { class: "nori-meet-select" });
  NORI_MEET_DESTRUCTION_CATEGORIES.forEach(function (c) { breachCategorySelect.appendChild(noriEl("option", { value: c, text: c })); });

  const breachDescInput = noriEl("input", { type: "text", class: "nori-checkin-typed", placeholder: "What happened? (optional detail)" });

  const breachKindSelect = noriEl("select", { class: "nori-meet-select" });
  breachKindSelect.appendChild(noriEl("option", { value: "deliberate", text: "Deliberate \u2014 I knowingly chose this over my obligation" }));
  NORI_MEET_BREACH_TEST.isNotAutomaticallyABreach.forEach(function (reason) {
    breachKindSelect.appendChild(noriEl("option", { value: reason, text: "Not a breach \u2014 " + reason }));
  });

  const breachDateInput = noriEl("input", { type: "date", class: "nori-checkin-typed" });
  breachDateInput.value = new Date().toISOString().slice(0, 10);

  const breachReadout = noriEl("p", { class: "nori-meet-category-readout" });
  const breachSubmitBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "\u2713 Log It" });
  const breachStatus = noriEl("p", { class: "nori-meet-status" });

  [
    noriEl("label", { class: "nori-meet-field-label", text: "Destruction category" }), breachCategorySelect,
    noriEl("label", { class: "nori-meet-field-label", text: "What kind of situation is this?" }), breachKindSelect,
    noriEl("label", { class: "nori-meet-field-label", text: "Description" }), breachDescInput,
    noriEl("label", { class: "nori-meet-field-label", text: "Date" }), breachDateInput,
    breachReadout, breachSubmitBtn, breachStatus
  ].forEach(function (el) { breachForm.appendChild(el); });

  breachCard.appendChild(breachForm);
  wrap.appendChild(breachCard);

  breachToggle.addEventListener("click", function () {
    breachForm.style.display = breachForm.style.display === "none" ? "flex" : "none";
  });

  function refreshBreachReadout() {
    const category = breachCategorySelect.value;
    const kind = breachKindSelect.value;
    let text = "";

    if (kind !== "deliberate") {
      const guard = noriMeetCheckOverrideGuard("breach:" + category, kind);
      if (guard.blocked) {
        text = "\u26d4 " + guard.note.replace("for breach:" + category, "for this category") +
          "\nTreating this as a breach instead \u2014 see below.\n\n";
      } else {
        breachReadout.textContent = "Not classified as a breach (\u201c" + kind + "\u201d). No escalation. Logged for the record only.";
        return;
      }
    }

    const degree = noriMeetDetermineDisciplinaryDegree(category);
    const protocol = NORI_MEET_DISCIPLINARY_LADDER[degree];
    text += degree + " \u2014 " + protocol.name + "\n" + protocol.steps.join("\n");
    if (NORI_MEET_ROMAN_DEGREES.indexOf(degree) >= 2) text += "\n\n" + NORI_MEET_PROPORTIONALITY_NOTE;
    breachReadout.textContent = text;
  }

  breachCategorySelect.addEventListener("change", refreshBreachReadout);
  breachKindSelect.addEventListener("change", refreshBreachReadout);
  refreshBreachReadout();

  breachSubmitBtn.addEventListener("click", async function () {
    const category = breachCategorySelect.value;
    const kind = breachKindSelect.value;
    const date = breachDateInput.value;
    const desc = breachDescInput.value.trim();

    let isBreach = kind === "deliberate";
    let guardOverrode = false;
    if (!isBreach) {
      const guard = noriMeetCheckOverrideGuard("breach:" + category, kind);
      if (guard.blocked) { isBreach = true; guardOverrode = true; }
    }

    if (!isBreach) {
      // Not a breach — log the reason itself in the excuse-guard history so
      // repeated identical claims are still tracked, but nothing escalates.
      noriOverrideHistoryAppend("breach:" + category, { date: date, category: kind, granted: true });
      breachStatus.textContent = "Logged \u2014 not treated as a breach (" + kind + ").";
    } else {
      noriOverrideHistoryAppend("breach:" + category, { date: date, category: kind, granted: false });

      const domain = NORI_BRAIN_DOMAIN_BY_CATEGORY[category] || "entertainment";
      const history = noriMeetBrainHistory(subjectSelect.value, domain);
      let brainResult;
      try {
        brainResult = await noriBrainEngine.processAcademicEvent({
          subject: subjectSelect.value,
          assessment: { type: "practice", percentage: 100, missedConcepts: [], totalConceptsCovered: 0, carelessErrorCount: 0, applicationErrorCount: 0 },
          contextEvent: { domain: domain, durationMinutes: 15, statedPurpose: "distraction", isEmergency: false, wasAccidental: false, continuedAfterAwareness: true, reportedDifficultDay: false, evidenceSources: ["user_report", "breach_form"] },
          history: history
        });
      } catch (err) { breachStatus.textContent = "Decision engine unavailable — breach was NOT saved. " + err.message; return; }
      const degree = brainResult.degree ? "Degree " + brainResult.degree : noriMeetDetermineDisciplinaryDegree(category);
      noriBreachHistoryAppend(category, { date: date, degree: degree, description: desc });

      // Save into the real Phase 5 Recovery Error / Obstacle Log.
      const key = noriStorageKey("phase-5", "recovery-work-obstacles", "recovery-error-obstacle-log");
      const existing = noriLoadEntries(key);
      existing.push({
        obstacle: category,
        cause: guardOverrode ? "Claimed \u201c" + kind + "\u201d again \u2014 excuse guard applied" : "Deliberate",
        effect: desc || category,
        correction: degree + " \u2014 " + NORI_MEET_DISCIPLINARY_LADDER[degree].name,
        repeated: NORI_MEET_ROMAN_DEGREES.indexOf(degree) > 0 ? "Yes" : "No",
        resolved: "No"
      });
      noriSaveEntries(key, existing);

      breachStatus.textContent = "Logged as a breach \u2014 " + degree + " (" + category + "). Saved to Phase 5 Recovery Error / Obstacle Log.";
    }

    breachDescInput.value = "";
    refreshBreachReadout();
  });

  /* ==================== FOCUS MODE (native app blocking) ==================== */

  const focusCard = noriEl("section", { class: "nori-panel" });
  const focusToggle = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "\ud83d\udd12 Focus Mode" });
  if (!NORI_FEATURES.focusMode) { focusToggle.disabled = true; focusToggle.textContent = "\ud83d\udd12 Focus Mode \u2014 coming soon"; }
  focusCard.appendChild(focusToggle);

  const focusBody = noriEl("div", { class: "nori-meet-quick-form", style: "display:none" });
  const focusStatus = noriEl("p", { class: "nori-meet-status" });

  if (typeof noriBlockerAvailable !== "function" || !noriBlockerAvailable()) {
    focusBody.appendChild(noriEl("p", {
      class: "nori-empty-note",
      text: "Focus Mode only works in the installed Android app \u2014 a website can't see or control other apps on your phone."
    }));
  } else {
    const permStatus = noriEl("p", { class: "nori-meet-status" });
    const usageBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "Grant Usage Access" });
    const overlayBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "Grant Overlay Permission" });
    focusBody.appendChild(permStatus);
    focusBody.appendChild(usageBtn);
    focusBody.appendChild(overlayBtn);

    const appChecks = {};
    NORI_BLOCKABLE_APPS.forEach(function (app) {
      const row = noriEl("label", { class: "nori-meet-checkbox-row" });
      const cb = noriEl("input", { type: "checkbox" });
      appChecks[app.package] = cb;
      row.appendChild(cb);
      row.appendChild(noriEl("span", { text: app.label }));
      focusBody.appendChild(row);
    });

    const startBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "\u25b6 Start Focus Mode" });
    const stopBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "\u23f9 Stop" });
    focusBody.appendChild(startBtn);
    focusBody.appendChild(stopBtn);
    focusBody.appendChild(focusStatus);

    async function refreshPermStatus() {
      const perms = await noriBlockerCheckPermissions();
      permStatus.textContent = "Usage Access: " + (perms.usageAccess ? "\u2713 granted" : "\u2717 not granted") +
        " \u2014 Overlay: " + (perms.overlay ? "\u2713 granted" : "\u2717 not granted");
    }
    refreshPermStatus();

    usageBtn.addEventListener("click", function () { noriBlockerRequestUsageAccess().then(refreshPermStatus); });
    overlayBtn.addEventListener("click", function () { noriBlockerRequestOverlayPermission().then(refreshPermStatus); });

    startBtn.addEventListener("click", function () {
      const chosen = NORI_BLOCKABLE_APPS.filter(function (app) { return appChecks[app.package].checked; }).map(function (app) { return app.package; });
      if (!chosen.length) { focusStatus.textContent = "Pick at least one app first."; return; }
      noriBlockerStart(chosen).then(function () {
        focusStatus.textContent = "Focus Mode started \u2014 " + chosen.length + " app(s) paused.";
      }).catch(function (err) { focusStatus.textContent = err.message; });
    });
    stopBtn.addEventListener("click", function () {
      noriBlockerStop().then(function () { focusStatus.textContent = "Focus Mode stopped."; });
    });
  }

  focusCard.appendChild(focusBody);
  wrap.appendChild(focusCard);
  focusToggle.addEventListener("click", function () {
    focusBody.style.display = focusBody.style.display === "none" ? "flex" : "none";
  });

  return wrap;
}
