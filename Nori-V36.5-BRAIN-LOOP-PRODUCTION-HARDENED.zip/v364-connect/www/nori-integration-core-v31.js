/* NORI INTEGRATION CORE V31
   One coordination protocol for text, voice, navigation, actions, permissions,
   verification, audit events and capability health.

   Design:
   interface -> intent -> capability -> policy/permission -> proposal/confirm
   -> execution -> verification -> event -> context update -> response.

   Existing feature modules remain adapters during migration. This file does
   not grant the AI authority; ActionCore/native execution remains the only
   side-effect path and every consequential action keeps explicit confirmation.
*/
(function(g){
  'use strict';

  const VERSION='31.0';
  const MAX_EVENTS=300;
  const MAX_PENDING=100;
  const listeners=new Map();
  const events=[];
  const pending=new Map();
  const capabilities=new Map();
  const sessions=new Map();
  const now=()=>new Date().toISOString();
  const id=(p)=>String(p||'nori')+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,9);
  const clone=x=>x==null?x:JSON.parse(JSON.stringify(x));

  function emit(type,payload,meta){
    const e={id:id('evt'),type:String(type),at:now(),correlationId:(meta&&meta.correlationId)||id('corr'),payload:clone(payload||{}),source:(meta&&meta.source)||'integration-core'};
    events.push(e); while(events.length>MAX_EVENTS)events.shift();
    const direct=listeners.get(type)||[], all=listeners.get('*')||[];
    direct.concat(all).forEach(fn=>{try{fn(clone(e));}catch(_){}});
    return e;
  }
  function on(type,fn){if(typeof fn!=='function')throw new Error('listener_required');if(!listeners.has(type))listeners.set(type,[]);listeners.get(type).push(fn);return()=>{const a=listeners.get(type)||[],i=a.indexOf(fn);if(i>=0)a.splice(i,1);};}

  function register(def){
    if(!def||!def.id)throw new Error('capability_id_required');
    const d=Object.assign({
      version:'1',description:'',actions:[],permissions:[],risk:'low',
      confirmation:'required',authority:'adapter',status:'unknown',operationClasses:['READ','PROPOSE','MUTATE','DELETE','NAVIGATE','SPEAK'],canRollback:false,rollbackWindowMs:0,sideEffects:[],
      executor:null,verify:null,rollback:null,dependencies:[]
    },def);
    d.actions=Array.isArray(d.actions)?d.actions.map(String):[];
    capabilities.set(d.id,d);
    emit('capability.registered',{id:d.id,version:d.version,actions:d.actions},{source:'capability-registry'});
    return d;
  }
  function getCap(idv){return capabilities.get(String(idv));}
  function listCaps(){return Array.from(capabilities.values()).map(clone);}
  async function health(idv){
    const c=getCap(idv); if(!c)return {id:idv,status:'unavailable',reason:'unknown_capability'};
    if(typeof c.health==='function'){try{const r=await c.health();return Object.assign({id:c.id},r||{});}catch(e){return {id:c.id,status:'degraded',reason:e.message};}}
    const missing=(c.dependencies||[]).filter(d=>!getCap(d));
    if(missing.length)return {id:c.id,status:'degraded',reason:'missing_dependencies',missing};
    return {id:c.id,status:c.status||'available',reason:''};
  }

  function session(idv,patch){
    const sid=idv||'default';
    const old=sessions.get(sid)||{id:sid,createdAt:now(),version:0};
    const next=Object.assign({},old,patch||{}, {version:old.version+1,updatedAt:now()});
    sessions.set(sid,next);
    return clone(next);
  }
  function currentSession(idv){return clone(sessions.get(idv||'default')||session(idv||'default',{}));}

  async function authSession(){
    try{
      if(g.NoriProductionAuth&&typeof g.NoriProductionAuth.session==='function'){
        return (await g.NoriProductionAuth.session()).data.session||null;
      }
      if(g.NoriSyncAuth&&typeof g.NoriSyncAuth.supabaseClient==='function'){
        const c=g.NoriSyncAuth.supabaseClient(); if(c&&c.auth){return (await c.auth.getSession()).data.session||null;}
      }
    }catch(_){}
    return null;
  }

  async function canonicalSnapshot(){
    const s=await authSession();
    if(!s)throw new Error('SIGN_IN_REQUIRED');
    const r=await fetch((g.NORI_API_BASE_URL||'')+'/api/brain',{
      method:'POST',
      headers:{'Content-Type':'application/json',Authorization:'Bearer '+s.access_token},
      body:JSON.stringify({mode:'canonical_state'})
    });
    const j=await r.json().catch(()=>({}));
    if(!r.ok||!j.ok)throw new Error(j.code||j.error||'CANONICAL_STATE_UNAVAILABLE');
    emit('state.snapshot',{version:j.context&&j.context.stateVersion||0,hash:j.context&&j.context.stateHash||''},{source:'canonical-state'});
    return j.context;
  }

  function permission(name){
    return {
      name,
      async status(){
        if(name==='notifications' && g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.LocalNotifications&&g.Capacitor.Plugins.LocalNotifications.checkPermissions){
          try{return await g.Capacitor.Plugins.LocalNotifications.checkPermissions();}catch(_){}
        }
        return {display:'unknown'};
      },
      async request(){
        if(name==='notifications' && g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.LocalNotifications&&g.Capacitor.Plugins.LocalNotifications.requestPermissions){
          return g.Capacitor.Plugins.LocalNotifications.requestPermissions();
        }
        if(name==='microphone' && navigator.mediaDevices&&navigator.mediaDevices.getUserMedia){
          const stream=await navigator.mediaDevices.getUserMedia({audio:true});stream.getTracks().forEach(t=>t.stop());return {microphone:'granted'};
        }
        if(name==='camera' && navigator.mediaDevices&&navigator.mediaDevices.getUserMedia){
          const stream=await navigator.mediaDevices.getUserMedia({video:true});stream.getTracks().forEach(t=>t.stop());return {camera:'granted'};
        }
        throw new Error('PERMISSION_UNAVAILABLE');
      }
    };
  }

  const ACTION_MAP={
    create_assignment:'assignments.create',update_assignment:'assignments.update',
    complete_assignment:'assignments.complete',reopen_assignment:'assignments.reopen',
    create_study_session:'study.create',complete_study_session:'study.complete',
    create_calendar_event:'calendar.create',delete_calendar_event:'calendar.delete',
    schedule_reminder:'reminders.create',schedule_alarm:'alarms.create',cancel_alarm:'alarms.cancel',
    focus_start:'focus.start',focus_stop:'focus.stop',record_result:'results.record',
    recalculate_awards:'awards.recalculate',recovery_review:'recovery.review'
  };

  Object.keys(ACTION_MAP).forEach(function(type){
    const cap=ACTION_MAP[type].split('.')[0];
    register({
      id:cap,
      version:'31',
      description:'Unified Nori capability adapter for '+cap,
      actions:[type],
      risk:['delete_calendar_event','cancel_alarm','focus_stop'].indexOf(type)>=0?'medium':'low',
      confirmation:'required',
      operationClasses:['PROPOSE','MUTATE','DELETE'],
      canRollback:true,rollbackWindowMs:300000,sideEffects:['canonical_or_local_state'],
      authority:'NORI_ACTION_CORE_V27_ADAPTER',
      status:'transitional_local_adapter',
      dependencies:[],
      executor:async function(input,ctx){
        if(!g.NoriActionCoreV27)throw new Error('ACTION_CORE_UNAVAILABLE');
        const proposal=g.NoriActionCoreV27.makeProposal(type,input||{},ctx&&ctx.reason||'Requested through Nori Orchestrator',ctx&&ctx.evidence||[]);
        if(!proposal)throw new Error('UNSUPPORTED_ACTION');
        pending.set(proposal.id,{proposal,correlationId:ctx.correlationId,capability:cap});
        while(pending.size>MAX_PENDING){const first=pending.keys().next().value;pending.delete(first);}
        emit('action.proposed',{proposalId:proposal.id,actionType:type,capability:cap,input:clone(input||{})},{correlationId:ctx.correlationId,source:'orchestrator'});
        return {ok:true,status:'confirmation_required',proposal};
      }
    });
  });

  register({id:'verification',version:'31',description:'Academic evidence capture/verification',actions:['request_verification_photo'],risk:'medium',confirmation:'required',authority:'VERIFICATION_ADAPTER',status:'available',executor:async function(input,ctx){
    const claim=String(input&&input.claim||'').trim();
    if(!claim)throw new Error('CLAIM_REQUIRED');
    if(!g.noriCameraVerify)throw new Error('CAMERA_VERIFICATION_UNAVAILABLE');
    emit('verification.started',{claim},{correlationId:ctx.correlationId});
    const result=await g.noriCameraVerify(claim);
    emit('verification.completed',{claim,result:clone(result)},{correlationId:ctx.correlationId});
    return {ok:true,status:'executed',result};
  }});
  register({id:'navigation',version:'31',description:'Goal-directed workspace navigation',actions:['navigate'],risk:'low',confirmation:'none',authority:'NAVIGATION_ADAPTER',status:'available',executor:async function(input,ctx){
    if(!g.NoriNavigationBrain||typeof g.NoriNavigationBrain.go!=='function')throw new Error('NAVIGATION_UNAVAILABLE');
    const route=String(input&&input.route||'');
    if(!/^#\/[a-z0-9_\/-]*$/i.test(route))throw new Error('INVALID_ROUTE');
    const ok=g.NoriNavigationBrain.go(route); if(!ok)throw new Error('NAVIGATION_FAILED');
    emit('navigation.completed',{route},{correlationId:ctx.correlationId});
    return {ok:true,status:'executed',route};
  }});
  register({id:'voice',version:'31',description:'Unified voice interface',actions:['listen','speak'],risk:'low',confirmation:'none',authority:'VOICE_ADAPTER',status:'available'});
  register({id:'planning',version:'31',description:'Planning and replanning context',actions:['plan'],risk:'low',confirmation:'none',authority:'PLANNING_ADAPTER',status:'available'});
  register({id:'state',version:'31',description:'Canonical state snapshot',actions:['read'],risk:'low',confirmation:'none',authority:'CANONICAL_SERVER_STATE',status:'available'});
  register({id:'native_operations',version:'31',description:'Android operational adapter',actions:['native_operation'],risk:'medium',confirmation:'required',authority:'NATIVE_BRAIN_ADAPTER',status:'available',health:async function(){
    return {status:(g.NoriOperations&&g.NoriOperations.available&&g.NoriOperations.available())?'available':'web_only',reason:''};
  }});

  async function proposeAction(type,input,opts){
    const capId=ACTION_MAP[type]&&ACTION_MAP[type].split('.')[0];
    const cap=getCap(capId); if(!cap)throw new Error('CAPABILITY_UNAVAILABLE:'+type);
    const correlationId=(opts&&opts.correlationId)||id('corr');
    const h=await health(cap.id); if(h.status==='unavailable'||h.status==='degraded')throw new Error('CAPABILITY_NOT_READY:'+cap.id);
    return cap.executor(input||{},Object.assign({},opts||{},{correlationId}));
  }

  async function confirmAction(proposalId){
    const entry=pending.get(proposalId);
    if(!entry||!g.NoriActionCoreV27)throw new Error('PROPOSAL_NOT_FOUND');
    const correlationId=entry.correlationId||id('corr');
    emit('action.confirmed',{proposalId,actionType:entry.proposal.type},{correlationId,source:'orchestrator'});
    try{
      const result=await g.NoriActionCoreV27.confirm(proposalId);
      pending.delete(proposalId);
      if(result&&result.ok){
        emit('action.executed',{proposalId,actionType:entry.proposal.type,operationId:result.proposal&&result.proposal.operationId,verification:result.verification},{correlationId,source:'orchestrator'});
        emit('state.changed',{actionType:entry.proposal.type,result:clone(result.proposal&&result.proposal.execution||result)},{correlationId,source:'orchestrator'});
      }else emit('action.failed',{proposalId,reason:result&&result.reason||'execution_failed'},{correlationId,source:'orchestrator'});
      return result;
    }catch(e){
      emit('action.failed',{proposalId,reason:e.message},{correlationId,source:'orchestrator'});
      throw e;
    }
  }

  async function undo(operationId){
    if(!g.NoriActionCoreV27)throw new Error('ACTION_CORE_UNAVAILABLE');
    const result=await g.NoriActionCoreV27.undo(operationId);
    emit(result&&result.ok?'action.undone':'action.undo_failed',{operationId,result:clone(result)},{source:'orchestrator'});
    return result;
  }

  function normalizeIntent(input){
    const source=(input&&input.source)||'text';
    const text=String((input&&input.text)||'').trim();
    const type=String((input&&input.type)||'').trim().toUpperCase();
    const args=Object.assign({},input&&input.args||{});
    const voiceMap={
      NEW_RESULT:{action:'record_result',workspace:'#/meet-nori'},
      NEW_ASSESSMENT:{workspace:'#/meet-nori'},
      NEW_ASSIGNMENT:{action:'create_assignment',workspace:'#/tasks'},
      ADD_SUBJECT:{workspace:'#/meet-nori'},
      START_EXAM_MODE:{workspace:'#/exams'},
      RETURN_TO_CHAT:{route:'#/meet-nori'},
      OPEN_APP:{route:args.route||''}
    };
    if(type&&voiceMap[type])return {source,type,text,args,route:voiceMap[type].route||null,action:voiceMap[type].action||null,workspace:voiceMap[type].workspace||null};
    if(g.NoriActionCoreV27&&typeof g.NoriActionCoreV27.parseText==='function'){
      const p=g.NoriActionCoreV27.parseText(text);
      if(p)return {source,text,args,action:p.type,proposal:p};
    }
    if(g.NoriNavigationBrain&&typeof g.NoriNavigationBrain.routeFor==='function'){
      const route=g.NoriNavigationBrain.routeFor(text);
      if(route)return {source,text,args,route};
    }
    return {source,text,args,kind:'conversation'};
  }

  async function dispatch(input){
    const correlationId=(input&&input.correlationId)||id('corr');
    const sid=(input&&input.sessionId)||'default';
    const text=String((input&&input.text)||'').trim();
    const current=currentSession(sid);
    if(/^(yes|yeah|yep|confirm|do it|go ahead|okay|ok)$/i.test(text) && current.pendingProposalId){
      const r=await confirmAction(current.pendingProposalId);
      session(sid,{correlationId,pendingProposalId:null,lastConfirmation:r&&r.ok?'confirmed':'failed'});
      return Object.assign({correlationId,status:r&&r.ok?'executed':'failed'},r||{});
    }
    if(/^(no|nope|cancel|not now|stop)$/i.test(text) && current.pendingProposalId){
      if(g.NoriActionCoreV27&&typeof g.NoriActionCoreV27.cancel==='function')g.NoriActionCoreV27.cancel(current.pendingProposalId);
      emit('action.cancelled',{proposalId:current.pendingProposalId},{correlationId,source:'orchestrator'});
      session(sid,{correlationId,pendingProposalId:null,lastConfirmation:'cancelled'});
      return {ok:true,status:'cancelled',correlationId};
    }
    const intent=normalizeIntent(input);
    session(sid,{correlationId,lastIntent:intent,source:intent.source});
    emit('intent.received',{intent:clone(intent)},{correlationId,source:'orchestrator'});
    if(intent.action){
      if(intent.proposal){
        const cap=ACTION_MAP[intent.action];
        emit('intent.resolved',{action:intent.action,capability:cap},{correlationId,source:'orchestrator'});
        const proposed=await proposeAction(intent.action,intent.proposal.input,{correlationId,reason:'User request via unified intent pipeline'});
        if(proposed&&proposed.proposal)session(sid,{pendingProposalId:proposed.proposal.id});
        emit('action.confirmation_required',{proposal:clone(proposed&&proposed.proposal),correlationId},{correlationId,source:'orchestrator'});
        return Object.assign({correlationId},proposed);
      }
      if(intent.action==='record_result' && input&&input.args){
        const proposed=await proposeAction('record_result',input.args,{correlationId,reason:'Voice result request'});
        if(proposed&&proposed.proposal)session(sid,{pendingProposalId:proposed.proposal.id});
        emit('action.confirmation_required',{proposal:clone(proposed&&proposed.proposal),correlationId},{correlationId,source:'orchestrator'});
        return Object.assign({correlationId},proposed);
      }
    }
    if(intent.route){
      return Object.assign({correlationId},await getCap('navigation').executor({route:intent.route},{correlationId}));
    }
    if(intent.workspace){
      const route=intent.workspace;
      if(g.NoriNavigationBrain&&g.NoriNavigationBrain.go)g.NoriNavigationBrain.go(route);
      return {ok:true,status:'navigated',route,correlationId};
    }
    return {ok:true,status:'conversation',correlationId,intent};
  }

  async function proposeAIAction(action){
    if(!action||typeof action!=='object')throw new Error('INVALID_ACTION');
    const type=String(action.type||'');
    const map={start_focus_mode:'focus_start',stop_focus_mode:'focus_stop',schedule_reminder:'schedule_reminder',schedule_alarm:'schedule_alarm',cancel_alarm:'cancel_alarm',create_assignment:'create_assignment',complete_assignment:'complete_assignment',create_study_session:'create_study_session',complete_study_session:'complete_study_session',create_calendar_event:'create_calendar_event',delete_calendar_event:'delete_calendar_event',record_result:'record_result',recalculate_awards:'recalculate_awards',recovery_review:'recovery_review'};
    const mapped=map[type]; if(!mapped)throw new Error('UNSUPPORTED_AI_ACTION:'+type);
    const input=Object.assign({},action); delete input.type; delete input.reason;
    if(type==='start_focus_mode'){
      if(!Array.isArray(action.apps)||action.apps.length<1||action.apps.length>12)throw new Error('INVALID_FOCUS_APPS');
      const appMap={};(g.NORI_BLOCKABLE_APPS||[]).forEach(a=>appMap[String(a.label).toLowerCase()]=a.package);
      input.packages=action.apps.map(x=>appMap[String(x).toLowerCase()]).filter(Boolean); if(!input.packages.length)throw new Error('NO_VALID_FOCUS_APPS'); delete input.apps;
    }
    if(type==='schedule_reminder'){const mins=Number(action.minutesFromNow);if(!Number.isInteger(mins)||mins<1||mins>10080)throw new Error('INVALID_REMINDER_MINUTES');input.when=new Date(Date.now()+mins*60000).toISOString();delete input.minutesFromNow;input.title=String(action.label||'Nori reminder');}
    return proposeAction(mapped,input,{correlationId:id('corr'),reason:action.reason||'Nori Brain proposed action'});
  }

  async function executeAIAction(action){
    if(!action||typeof action!=='object')throw new Error('INVALID_ACTION');
    const type=String(action.type||'');
    if(type==='request_verification_photo'){
      return getCap('verification').executor({claim:String(action.claim||'').trim()},{correlationId:id('corr')});
    }
    if(type==='navigate'){
      return getCap('navigation').executor({route:String(action.route||'')},{correlationId:id('corr')});
    }
    const map={
      start_focus_mode:'focus_start',stop_focus_mode:'focus_stop',
      schedule_reminder:'schedule_reminder',schedule_alarm:'schedule_alarm',cancel_alarm:'cancel_alarm',
      create_assignment:'create_assignment',complete_assignment:'complete_assignment',
      create_study_session:'create_study_session',complete_study_session:'complete_study_session',
      create_calendar_event:'create_calendar_event',delete_calendar_event:'delete_calendar_event',
      record_result:'record_result',recalculate_awards:'recalculate_awards',recovery_review:'recovery_review'
    };
    const mapped=map[type]; if(!mapped)throw new Error('UNSUPPORTED_AI_ACTION:'+type);
    const input=Object.assign({},action);
    delete input.type; delete input.reason;
    if(type==='start_focus_mode'){
      if(!Array.isArray(action.apps)||action.apps.length<1||action.apps.length>12)throw new Error('INVALID_FOCUS_APPS');
      const appMap={};(g.NORI_BLOCKABLE_APPS||[]).forEach(a=>appMap[String(a.label).toLowerCase()]=a.package);
      input.packages=action.apps.map(x=>appMap[String(x).toLowerCase()]).filter(Boolean);
      if(!input.packages.length)throw new Error('NO_VALID_FOCUS_APPS');
      delete input.apps;
    }
    if(type==='schedule_reminder'){
      const mins=Number(action.minutesFromNow);
      if(!Number.isInteger(mins)||mins<1||mins>10080)throw new Error('INVALID_REMINDER_MINUTES');
      input.when=new Date(Date.now()+mins*60000).toISOString();
      delete input.minutesFromNow; input.title=String(action.label||'Nori reminder');
    }
    const r=await proposeAction(mapped,input,{correlationId:id('corr'),reason:action.reason||'AI-proposed action'});
    if(r&&r.proposal)return confirmAction(r.proposal.id);
    return r;
  }

  function bindActionCoreEvents(){
    if(!g.NoriActionCoreV27||g.__NORI_V31_ACTION_PATCHED)return;
    g.__NORI_V31_ACTION_PATCHED=true;
    const originalUndo=g.NoriActionCoreV27.undo;
    g.NoriActionCoreV27.undo=async function(op){const r=await originalUndo.apply(this,arguments);emit(r&&r.ok?'action.undone':'action.undo_failed',{operationId:op,result:clone(r)},{source:'action-core-adapter'});return r;};
  }

  async function refreshNativeCapabilities(){
    try{
      if(g.NoriOperations&&typeof g.NoriOperations.capabilities==='function'){
        const list=await g.NoriOperations.capabilities();
        (Array.isArray(list)?list:(list&&Array.isArray(list.capabilities)?list.capabilities:[])).forEach(function(x){
          if(!x||!x.id)return;
          register({id:'native.'+x.id,version:'31',description:x.label||x.id,actions:['native_operation:'+x.id],
            permissions:[],risk:'medium',confirmation:'required',authority:'NATIVE_BRAIN_ADAPTER',
            status:x.status||'unknown',dependencies:[],health:async()=>({status:x.status||'unknown',reason:x.reason||''})});
        });
        emit('capability.health_refreshed',{count:list&&list.capabilities?list.capabilities.length:0},{source:'native-capability-adapter'});
      }
    }catch(_){}
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',refreshNativeCapabilities);else setTimeout(refreshNativeCapabilities,0);

  on('action.confirmation_required',function(e){
    try{
      if(e&&e.source==='orchestrator' && typeof g.noriSpeak==='function' && e.payload&&e.payload.proposal){
        const p=e.payload.proposal;
        g.noriSpeak('I can '+String((p.definition&&p.definition.label)||p.type)+'. Say yes to confirm, or no to cancel.');
      }
    }catch(_){}
  });
  async function context(sessionId){
    const sid=sessionId||'default';
    let canonical=null, canonicalError=null;
    try{canonical=await canonicalSnapshot();}catch(e){canonicalError=e.message;}
    return {
      version:VERSION,
      session:currentSession(sid),
      route:(g.NoriNavigationBrain&&typeof g.NoriNavigationBrain.active==='function')?g.NoriNavigationBrain.active():null,
      canonical,
      canonicalError,
      capabilities:listCaps()
    };
  }
  const api={
    version:VERSION,on,emit,register,getCapability:getCap,listCapabilities:listCaps,health,
    session,currentSession,canonicalSnapshot,context,permission,normalizeIntent,dispatch,
    proposeAction,proposeAIAction,confirmAction,executeAIAction,undo,
    events:()=>clone(events),pending:()=>Array.from(pending.values()).map(clone)
  };
  g.NoriIntegrationCoreV31=api;
  g.NoriEventBusV31={on,emit,events:api.events};
  bindActionCoreEvents();
  if(typeof g.noriStorageOnWrite==='function'){
    g.noriStorageOnWrite(function(key){emit('local_state.write',{key:String(key)},{source:'storage-adapter'});});
  }
  g.addEventListener('nori:voice-command',function(e){
    const d=e&&e.detail||{};const raw=String(d.raw||d.text||'');
    if(!raw)return;
    dispatch({source:'voice',text:raw,type:String(d.type||raw.split('|')[0]||'')});
  });
})(window);
