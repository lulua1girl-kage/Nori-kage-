/* NORI V28 — VERIFICATION + ROLLBACK
   Adds independent integrity checks around V27 actions. It does not replace V27.
   A failed verification never gets promoted to a successful state.
*/
(function(g){'use strict';
  const KEY='nori_v28_verification_log';
  const MAX=200;
  const now=()=>new Date().toISOString();
  const load=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){return[]}};
  const save=x=>{try{localStorage.setItem(KEY,JSON.stringify(x.slice(-MAX)));return true}catch(e){return false}};
  const hash=s=>{let h=2166136261;String(s).split('').forEach(c=>{h^=c.charCodeAt(0);h=Math.imul(h,16777619)});return (h>>>0).toString(16).padStart(8,'0')};
  function digestState(state){try{return hash(JSON.stringify(state||{}))}catch(e){return 'unavailable'}}
  function verifyOperation(op){
    if(!op||!op.actionType)return {ok:false,code:'invalid_operation',message:'Operation record is incomplete.'};
    if(op.status!=='executed')return {ok:false,code:'not_executed',message:'Only executed operations can be verified.'};
    const base={operationId:op.id,actionType:op.actionType,checkedAt:now(),beforeDigest:digestState(op.before),afterDigest:digestState(op.after),checks:[]};
    base.checks.push({name:'operation_record',ok:!!op.proposalId});
    base.checks.push({name:'before_snapshot',ok:!!op.before&&typeof op.before==='object'});
    base.checks.push({name:'verification_record',ok:!!op.verification&&op.verification.ok!==false});
    base.ok=base.checks.every(x=>x.ok);
    base.status=base.ok?'verified':'needs_review';
    const log=load();log.push(base);save(log);return base;
  }
  function verifyAll(){const ops=g.NoriActionCoreV27?g.NoriActionCoreV27.operations():[];return ops.map(verifyOperation)}
  function rollback(id){if(!g.NoriActionCoreV27||typeof g.NoriActionCoreV27.undo!=='function')return {ok:false,reason:'rollback_adapter_unavailable'};const r=g.NoriActionCoreV27.undo(id);const log=load();log.push({operationId:id,checkedAt:now(),event:'rollback',ok:!!r.ok});save(log);return r}
  function reconcile(){const ops=g.NoriActionCoreV27?g.NoriActionCoreV27.operations():[];return {checked:ops.length,verified:ops.filter(x=>x.verification&&x.verification.ok).length,rollbackAvailable:ops.filter(x=>x.undoable&&x.status==='executed').length,generatedAt:now()}}
  g.NoriVerificationV28={verifyOperation,verifyAll,rollback,reconcile,log:load,digestState,version:'28'};
})(window);
