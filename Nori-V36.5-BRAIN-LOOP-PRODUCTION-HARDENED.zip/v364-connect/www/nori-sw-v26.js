/* NORI SERVICE WORKER V32 — network-first application shell, cache fallback offline. */
const CACHE='nori-v32-shell';
const ASSETS=['./','./index.html','./nori-phase.css','./nori-presence-v21.css','./nori-control-center-v26.css','./nori-avatar-v26.css','./nori-self-improve-v26.css','./nori-visual-v26.css','./nori-phase-app.js','./nori-storage.js','./nori-brain-v14.js','./nori-performance-v24.js','./nori-ai-provider-v25.js'];
self.addEventListener('install',e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS).catch(()=>{})).then(()=>self.skipWaiting())));
self.addEventListener('activate',e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim())));
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(u.pathname.includes('/api/') || e.request.method!=='GET') return;
  // App shell: network-first prevents an old JS/CSS bundle from silently
  // surviving a release. If offline, use the last known-good cached copy.
  e.respondWith(fetch(e.request).then(r=>{
    if(r.ok&&u.origin===location.origin){const copy=r.clone();caches.open(CACHE).then(c=>c.put(e.request,copy)).catch(()=>{});}
    return r;
  }).catch(()=>caches.match(e.request).then(c=>c||caches.match('./'))));
});
