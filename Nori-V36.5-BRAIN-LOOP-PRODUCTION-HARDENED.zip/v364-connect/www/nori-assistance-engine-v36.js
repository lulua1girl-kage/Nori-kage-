/* NORI V36 — ASSISTANCE ENGINE
 * Turns the existing app capabilities into a person-aware assistance loop.
 * Model = reasoning worker. Canonical app state = truth. Human Override = authority.
 * Durable personal context is structured, explicit, confidence-scored and locally stored.
 */
(function(g){'use strict';
  const VERSION='36';
  const KEYS={profile:'nori_assistance_profile_v36',sessions:'nori_assistance_sessions_v36',patterns:'nori_assistance_patterns_v36',experiments:'nori_assistance_experiments_v36',plans:'nori_assistance_plans_v36',outcomes:'nori_assistance_outcomes_v36',events:'nori_assistance_events_v36'};
  const MAX=300;
  const clone=x=>{try{return JSON.parse(JSON.stringify(x));}catch(_){return x;}};
  const now=()=>new Date().toISOString();
  const uid=p=>(p||'v36')+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);
  const load=(k,d)=>{try{const x=JSON.parse(localStorage.getItem(k)||'null');return x==null?clone(d):x;}catch(_){return clone(d);}};
  const save=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true;}catch(_){return false;}};
  const arr=k=>{const x=load(k,[]);return Array.isArray(x)?x:[];};
  const emit=(type,payload)=>{const a=arr(KEYS.events);a.push({id:uid('evt'),type,at:now(),payload:clone(payload||{})});save(KEYS.events,a.slice(-MAX));return a[a.length-1];};

  const PROFILE_DEFAULT={version:1,identity:{},academic:{grade:null,school:null,subjects:[],courses:[],calendar:null,goals:[]},preferences:{studyStyle:null,communication:null,languages:[],accessibility:null},constraints:{schedule:[],timeLimits:[],device:null},goals:[],confirmedFacts:[],lastUpdated:null};
  function profile(){return load(KEYS.profile,PROFILE_DEFAULT);}
  function setProfile(path,value,meta){
    const p=profile(); const parts=String(path||'').split('.').filter(Boolean); if(!parts.length)return {ok:false,error:'PATH_REQUIRED'};
    let cur=p; for(let i=0;i<parts.length-1;i++){if(!cur[parts[i]]||typeof cur[parts[i]]!=='object')cur[parts[i]]={};cur=cur[parts[i]];}
    cur[parts[parts.length-1]]=clone(value); p.lastUpdated=now();
    if(meta&&meta.confirmed) {p.confirmedFacts=(p.confirmedFacts||[]).filter(x=>x.path!==path).concat([{id:uid('fact'),path,value:clone(value),confirmedAt:now(),source:meta.source||'user'}]).slice(-200);}
    save(KEYS.profile,p); emit('profile.updated',{path,value:clone(value),confirmed:!!(meta&&meta.confirmed)}); return {ok:true,profile:p};
  }
  function addFact(f){if(!f||!f.path)return {ok:false,error:'FACT_INVALID'};return setProfile(f.path,f.value,{confirmed:true,source:f.source||'user'});}
  function getFact(path){let c=profile();for(const k of String(path||'').split('.')){if(!k)continue;if(c==null)return null;c=c[k];}return c==null?null:clone(c);}

  // V36.2 — deterministic goal evaluation. Computed status is derived evidence,
  // not a silent rewrite of the user's goal. Notifications are proposed signals.
  function goalProgress(ctx){
    const p=ctx&&ctx.profile||profile(); const goals=Array.isArray(p.goals)?p.goals:[];
    const state=ctx&&ctx.state||{}; const results=resultsMap(state);
    const rows=goals.map((g,i)=>{
      const subject=g.subject||g.targetSubject||g.academicSubject||null;
      const target=Number(g.target!=null?g.target:g.targetScore);
      const currentRaw=g.current!=null?g.current:g.currentValue;
      let current=Number(currentRaw);
      if(!Number.isFinite(current)&&subject&&results[subject]){
        const scores=numericScores(results[subject]); current=scores.length?scores[scores.length-1]:NaN;
      }
      const deadline=g.deadline||g.targetDate||null;
      const days=deadline?Math.ceil((new Date(deadline).getTime()-Date.now())/86400000):null;
      let status='NO_BASELINE';
      if(Number.isFinite(target)&&Number.isFinite(current)){
        if(current>=target)status='ACHIEVED';
        else if(days!=null&&days<0)status='OVERDUE';
        else if(days!=null&&days<=14 && target-current>=10)status='AT_RISK';
        else status='ON_TRACK';
      }
      return {index:i,id:g.id||('goal_'+i),title:g.title||g.name||subject||'Untitled goal',subject,target:Number.isFinite(target)?target:null,current:Number.isFinite(current)?current:null,deadline,daysRemaining:days,status,priority:g.priority||'normal',evidence:subject&&results[subject]?{source:'recent_results',subject}:null};
    });
    return {rows,updatedAt:now()};
  }
  function goalNotifications(ctx,progress){
    const rows=(progress&&progress.rows)||[]; const prev=load('nori_assistance_goal_status_v36',{}); const next={};
    rows.forEach(r=>{next[r.id]=r.status; const changed=prev[r.id]!==r.status; const important=r.status==='AT_RISK'||r.status==='OVERDUE'||r.status==='ACHIEVED';
      if(changed&&important&&typeof g.noriKagePushNotification==='function'){
        const title=r.status==='ACHIEVED'?'GOAL ACHIEVED':r.status==='OVERDUE'?'GOAL DEADLINE PASSED':'GOAL AT RISK';
        const body=r.current!=null&&r.target!=null?`${r.title}: ${r.current}% current vs ${r.target}% target${r.daysRemaining!=null?' · '+Math.max(0,r.daysRemaining)+' days remaining':''}.`:`${r.title}: ${r.status.toLowerCase().replace('_',' ')}.`;
        g.noriKagePushNotification({id:'goal:'+r.id+':'+r.status,title,body,type:'goal',priority:r.status==='OVERDUE'?'high':'normal',source:'goal progress',action:'#/settings'});
      }
    });
    save('nori_assistance_goal_status_v36',next);
    return rows;
  }

  function readLocalState(){
    const keys=['nori_command_assignments','nori_study_sessions','nori_calendar_events_v1','nori_voice_alarms','nori_v27_reminders','nori_eval_history_all_subjects','nori_exams','nori_focus_sessions','nori_time_tools_v35','nori_active_focus','nori_current_page'];
    const out={}; keys.forEach(k=>{const v=load(k,null);if(v!=null)out[k]=v;});
    try{if(g.NoriTimeToolsV35)out.timeTools={watch:g.NoriTimeToolsV35.watchState&&g.NoriTimeToolsV35.watchState(),timer:g.NoriTimeToolsV35.timerState&&g.NoriTimeToolsV35.timerState()};}catch(_){ }
    try{out.protection=g.NoriContextIntelligence&&g.NoriContextIntelligence.snapshot?g.NoriContextIntelligence.snapshot():null;}catch(_){ }
    try{out.pendingActions=g.NoriOperativeV33&&g.NoriOperativeV33.pending?g.NoriOperativeV33.pending():[];}catch(_){ }
    return out;
  }
  async function canonical(){
    try{
      if(!g.NORI_API_BASE_URL)return {available:false,state:{}};
      const r=await fetch(String(g.NORI_API_BASE_URL)+'/api/brain',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({mode:'canonical_state'})});
      const j=await r.json(); if(!r.ok||!j.ok)return {available:false,state:{},error:j.error||'CANONICAL_UNAVAILABLE'};
      return {available:true,state:(j.context&&j.context.canonicalState&&j.context.canonicalState.state)||{},version:j.context&&j.context.stateVersion||0,authority:j.context&&j.context.authority||'CANONICAL_SERVER_STATE'};
    }catch(e){return {available:false,state:{},error:e.message};}
  }
  function conversation(){try{return g.noriConversationV3&&g.noriConversationV3.context?g.noriConversationV3.context():{recentTurns:[]};}catch(_){return {recentTurns:[]};}}
  function currentPage(){return location.hash||location.pathname||'';}

  async function buildContext(){
    const c=await canonical(); const local=readLocalState();
    const state=Object.assign({},c.state||{},local); const conv=conversation();
    const pending=Array.isArray(state.pendingActions)?state.pendingActions:[];
    const out={version:1,builtAt:now(),authority:c.authority||'LOCAL_EVIDENCE',canonicalAvailable:c.available,canonicalVersion:c.version||0,profile:profile(),current:{page:currentPage(),conversation:conv,lastTurn:conv.recentTurns&&conv.recentTurns.length?conv.recentTurns[conv.recentTurns.length-1]:null},state,pendingAction:pending[0]||null,sourcePriority:['human_override','safety','canonical_state','confirmed_profile','recent_conversation','derived_patterns','model_inference']};
    out.goals=goalProgress(out); goalNotifications(out,out.goals); return out;
  }

  function normalizeSubject(s){return String(s||'').trim().toLowerCase().replace(/\s+/g,' ');}
  function resultsMap(state){const h=state.nori_eval_history_all_subjects;return h&&typeof h==='object'&&!Array.isArray(h)?h:{};}
  function numericScores(xs){return (Array.isArray(xs)?xs:[]).map(x=>Number(x.score)).filter(Number.isFinite);}
  function mean(xs){return xs.length?xs.reduce((a,b)=>a+b,0)/xs.length:null;}
  function academicDiagnosis(ctx){
    const s=ctx.state||{}, results=resultsMap(s), sessions=Array.isArray(s.nori_study_sessions)?s.nori_study_sessions:[], assignments=Array.isArray(s.nori_command_assignments)?s.nori_command_assignments:[];
    const subjects=new Set([...Object.keys(results),...sessions.map(x=>x.subject).filter(Boolean)]); const rows=[];
    subjects.forEach(sub=>{const scores=numericScores(results[sub]);const recent=scores.slice(-5);const avg=mean(recent);const prior=mean(scores.slice(Math.max(0,scores.length-10),Math.max(0,scores.length-5)));const trend=avg!=null&&prior!=null?avg-prior:null;const study=sessions.filter(x=>normalizeSubject(x.subject)===normalizeSubject(sub));const completed=study.filter(x=>x.status==='completed').length;const planned=study.length;const open=assignments.filter(x=>normalizeSubject(x.subject)===normalizeSubject(sub)&&x.status!=='done').length;rows.push({subject:sub,recentScores:recent,average:avg,trend,studySessions:planned,completedStudySessions:completed,openAssignments:open});});
    rows.sort((a,b)=>(a.average==null?101:a.average)-(b.average==null?101:b.average));
    return {rows,flags:rows.flatMap(r=>{const f=[];if(r.average!=null&&r.average<80)f.push('performance_below_target');if(r.trend!=null&&r.trend<-5)f.push('declining_trend');if(r.openAssignments>=2)f.push('deadline_load');if(r.studySessions>0&&r.completedStudySessions/r.studySessions<0.6)f.push('low_completion');return f.map(type=>({subject:r.subject,type}));})};
  }

  function patternEvidence(ctx){
    const s=ctx.state||{}, out=[]; const results=resultsMap(s), sessions=Array.isArray(s.nori_study_sessions)?s.nori_study_sessions:[], assignments=Array.isArray(s.nori_command_assignments)?s.nori_command_assignments:[];
    Object.keys(results).forEach(sub=>{const scores=numericScores(results[sub]);if(scores.length>=3){const recent=scores.slice(-3),avg=mean(recent),older=mean(scores.slice(0,-3));if(avg!=null&&older!=null&&avg<older-5)out.push({type:'declining_performance',subject:sub,evidence:{recentAverage:avg,olderAverage:older,count:scores.length},confidence:Math.min(.95,.55+scores.length*.04)});}});
    const bySub={}; sessions.forEach(x=>{const k=normalizeSubject(x.subject||'unknown');bySub[k]=(bySub[k]||[]).concat(x);}); Object.keys(bySub).forEach(k=>{const xs=bySub[k],ab=xs.filter(x=>x.status==='abandoned'||x.status==='skipped').length;if(xs.length>=3&&ab/xs.length>=.4)out.push({type:'repeated_session_abandonment',subject:k,evidence:{sessions:xs.length,abandoned:ab,rate:ab/xs.length},confidence:.65});});
    const open=assignments.filter(x=>x.status!=='done'), overdue=open.filter(x=>x.due&&new Date(x.due).getTime()<Date.now()); if(overdue.length>=2)out.push({type:'repeated_deadline_pressure',evidence:{open:open.length,overdue:overdue.length},confidence:.7});
    return out;
  }
  function detectPatterns(ctx){const fresh=patternEvidence(ctx), old=arr(KEYS.patterns);const merged={};old.forEach(x=>merged[x.signature||JSON.stringify(x)]=x);fresh.forEach(x=>{const signature=x.type+'|'+(x.subject||'all');const prev=merged[signature];merged[signature]=Object.assign({},prev||{},x,{signature,observations:(prev&&prev.observations||0)+1,lastSeen:now()});});const rows=Object.values(merged).sort((a,b)=>(b.confidence||0)-(a.confidence||0));save(KEYS.patterns,rows.slice(-MAX));return rows;}

  function resolveReference(text,ctx){
    const raw=String(text||'').trim(), t=raw.toLowerCase(), c=ctx||{}, candidates=[];
    const last=c.current&&c.current.lastTurn;
    const recent=Array.isArray(c.current&&c.current.conversation&&c.current.conversation.recentTurns)?c.current.conversation.recentTurns:[];
    const priorTurns=recent.slice(-8);
    if(last&&last.content)candidates.push({kind:'conversation',ref:last.content,label:last.content,score:.52,source:'last_turn'});
    const sessions=Array.isArray(c.state&&c.state.nori_study_sessions)?c.state.nori_study_sessions:[];
    sessions.filter(x=>['active','in_progress','planned'].includes(x.status)).slice(-8).forEach(x=>candidates.push({kind:'study_session',id:x.id,label:[x.subject,x.topic,x.title].filter(Boolean).join(' '),score:x.status==='active'?0.92:0.80,source:'study'}));
    const assignments=Array.isArray(c.state&&c.state.nori_command_assignments)?c.state.nori_command_assignments:[];
    assignments.filter(x=>x.status!=='done').slice(-10).forEach(x=>candidates.push({kind:'assignment',id:x.id,label:[x.title,x.subject].filter(Boolean).join(' '),score:0.76,source:'assignment'}));
    const calendar=Array.isArray(c.state&&c.state.nori_calendar_events_v1)?c.state.nori_calendar_events_v1:[];
    calendar.slice(-10).forEach(x=>candidates.push({kind:'calendar',id:x.id,label:[x.title,x.subject].filter(Boolean).join(' '),score:0.72,source:'calendar'}));
    const alarms=Array.isArray(c.state&&c.state.nori_voice_alarms)?c.state.nori_voice_alarms:[];
    alarms.slice(-8).forEach(x=>candidates.push({kind:'alarm',id:x.id,label:[x.label,x.title,x.subject].filter(Boolean).join(' '),score:0.70,source:'alarm'}));
    const pronoun=/\b(it|that|this|those|these|the session|the assignment|the exam|that one|this one|the reminder|the alarm)\b/i.test(raw);
    if(!pronoun)return {resolved:false,reason:'NO_REFERENCE'};
    const priorText=priorTurns.map(x=>String(x&&x.content||'')).join(' ').toLowerCase();
    const subjectHints=(raw+' '+priorText).match(/\b(math(?:ematics)?|chemistry|physics|biology|english|agriculture|web design)\b/gi)||[];
    const hint=subjectHints.length?subjectHints[subjectHints.length-1].toLowerCase():'';
    const ranked=candidates.map(x=>{
      const label=String(x.label||'').toLowerCase(); let score=x.score;
      if(hint&&label.includes(hint))score+=0.18;
      if(label&&priorText&&priorText.includes(label))score+=0.14;
      if(x.source==='last_turn')score+=0.08;
      return Object.assign({},x,{score:Number(Math.min(0.99,score).toFixed(3))});
    }).sort((a,b)=>b.score-a.score);
    if(!ranked.length)return {resolved:false,reason:'NO_CANDIDATE'};
    const top=ranked[0], second=ranked[1];
    if(second&&top.score-second.score<.10)return {resolved:false,reason:'AMBIGUOUS',confidence:top.score,candidates:ranked.slice(0,4)};
    return {resolved:true,confidence:top.score,target:top,candidates:ranked.slice(0,4)};
  }

  function summarizeConversation(ctx,limit){
    const c=ctx||{}, conv=c.current&&c.current.conversation||{}, turns=Array.isArray(conv.recentTurns)?conv.recentTurns:[];
    const max=Math.max(4,Math.min(Number(limit)||12,24));
    const selected=turns.slice(-max).filter(x=>x&&x.content);
    const userTurns=selected.filter(x=>x.role==='user');
    const intents=[...new Set(selected.map(x=>x.intent).filter(Boolean))];
    const subjects=[...new Set((selected.map(x=>String(x.content||'').match(/\b(math(?:ematics)?|chemistry|physics|biology|english|agriculture|web design)\b/gi)||[]).flat()).map(x=>x.toLowerCase()))];
    const openActions=Array.isArray(c.pendingAction)?c.pendingAction:[];
    return {version:1,generatedAt:now(),threadTopic:conv.threadTopic||'',lastIntent:conv.lastIntent||'general',turnCount:selected.length,userTurnCount:userTurns.length,intents,subjects,openActionCount:openActions.length,keyTurns:selected.slice(-8).map(x=>({role:x.role,intent:x.intent,content:String(x.content).slice(0,500),at:x.at})),compression:'recent-turns-with-entities-and-intent'};
  }

  function missingForAction(text,ctx){
    const t=String(text||'').toLowerCase(), refs=resolveReference(t,ctx), asks=[];
    if(/\bmove\b/.test(t)&&!/(tomorrow|today|monday|tuesday|wednesday|thursday|friday|saturday|sunday|\b\d{1,2}(?::\d{2})?\s*(am|pm)?\b)/i.test(t))asks.push('target time/date');
    if(/\bmove\b/.test(t)&&refs.resolved===false&&refs.reason!=='NO_REFERENCE')asks.push('which item');
    if(/\b(schedule|set)\b/.test(t)&&!/\b\d{1,2}(?::\d{2})?\s*(am|pm)?\b/i.test(t)&&!/\b(tomorrow|today|monday|tuesday|wednesday|thursday|friday|saturday|sunday)\b/i.test(t))asks.push('time/date');
    return {asks,reference:refs};
  }

  function createPlan(goal,steps,ctx){const p={id:uid('plan'),goal:String(goal||''),steps:Array.isArray(steps)?clone(steps):[],createdAt:now(),expected:ctx&&ctx.expected||{},status:'proposed',contextVersion:ctx&&ctx.canonicalVersion||0};const a=arr(KEYS.plans);a.push(p);save(KEYS.plans,a.slice(-MAX));emit('plan.created',{id:p.id,goal:p.goal});return p;}
  function recordOutcome(planId,outcome){const a=arr(KEYS.outcomes),row={id:uid('outcome'),planId,at:now(),outcome:clone(outcome||{}),evaluated:null};a.push(row);save(KEYS.outcomes,a.slice(-MAX));emit('outcome.recorded',row);return row;}
  function evaluateOutcome(id){const a=arr(KEYS.outcomes),x=a.find(o=>o.id===id);if(!x)return {ok:false,error:'OUTCOME_NOT_FOUND'};const expected=x.outcome&&x.outcome.expected||{},actual=x.outcome&&x.outcome.actual||{};const keys=Object.keys(expected);const matched=keys.filter(k=>String(expected[k])===String(actual[k])).length;const score=keys.length?matched/keys.length:null;x.evaluated={score,matched,compared:keys.length,at:now()};save(KEYS.outcomes,a);emit('outcome.evaluated',{id,score});return {ok:true,outcome:x};}

  function proactive(ctx){const suggestions=[];const d=academicDiagnosis(ctx),patterns=detectPatterns(ctx);d.flags.slice(0,5).forEach(f=>suggestions.push({type:'academic',priority:'medium',reason:f.type+' in '+f.subject,proposal:'Review the recent evidence and adjust the next study block for '+f.subject+'.',requiresConfirmation:true}));patterns.filter(x=>x.confidence>=.65).slice(0,5).forEach(p=>suggestions.push({type:'pattern',priority:'medium',reason:p.type+(p.subject?' in '+p.subject:''),proposal:'Run a small intervention and measure the next outcome before changing the long-term strategy.',requiresConfirmation:true}));
    const as=Array.isArray(ctx.state&&ctx.state.nori_command_assignments)?ctx.state.nori_command_assignments:[], due=as.filter(x=>x.status!=='done'&&x.due).sort((a,b)=>new Date(a.due)-new Date(b.due)); if(due.length>=2)suggestions.push({type:'schedule_conflict',priority:'high',reason:'Multiple open assignments have due dates.',proposal:'Review the next deadlines and compare them with scheduled study sessions before changing anything.',requiresConfirmation:true});
    return suggestions.slice(0,8);
  }

  function compactContext(ctx){return {profile:ctx.profile,current:ctx.current,conversationSummary:summarizeConversation(ctx,12),state:ctx.state,patterns:arr(KEYS.patterns).slice(-10),diagnosis:academicDiagnosis(ctx),goals:ctx.goals||goalProgress(ctx),plans:arr(KEYS.plans).slice(-10),outcomes:arr(KEYS.outcomes).slice(-10),pendingAction:ctx.pendingAction};}
  function extractJSON(s){const text=String(s||'').trim().replace(/^```json\s*/i,'').replace(/```$/,'').trim();try{return JSON.parse(text);}catch(_){const a=text.indexOf('{'),b=text.lastIndexOf('}');if(a>=0&&b>a)try{return JSON.parse(text.slice(a,b+1));}catch(__){}return null;}}
  async function askModel(message,ctx,opts){
    let nativeBrain={available:false,reason:'NATIVE_BRAIN_NOT_ATTEMPTED'};
    try{
      if(g.NoriNativeAssistanceV36&&g.NoriNativeAssistanceV36.available&&g.NoriNativeAssistanceV36.available()){
        nativeBrain=await g.NoriNativeAssistanceV36.process(message,ctx,{
          externalAvailable:!!(opts&&opts.externalAvailable),
          userInitiatedAction:opts&&opts.userInitiatedAction!==undefined?opts.userInitiatedAction:true,
          freshDataRequested:!!(opts&&opts.freshDataRequested),
          capacity:opts&&opts.capacity||'NORMAL'
        });
      }
    }catch(e){nativeBrain={available:false,reason:String(e&&e.message||e)};}
    const prompt=[
      'You are Nori Assistance Engine V36. You are the reasoning worker inside a larger deterministic app.',
      'Authority: Human Override > Safety/System Integrity > canonical state > confirmed user context > derived patterns > model inference.',
      'Never invent state. Never silently mutate app records. Propose consequential actions and require confirmation.',
      'Use the supplied context to resolve references, diagnose academic evidence, identify patterns, and propose adaptive actions.',
      'Do not expose hidden chain-of-thought. Return concise decision reasoning in the requested fields.',
      'OUTPUT JSON ONLY:',
      '{"interpretation":"","confidence":0,"what_i_noticed":[],"why_it_matters":[],"proposal":null,"changes":[],"risks":[],"missing_information":[],"resolved_reference":null,"next_step":null,"action":null}',
      'CONTEXT:\n'+JSON.stringify(compactContext(ctx)),
      'USER MESSAGE:\n'+String(message||''),
      opts&&opts.mode==='planning'?'Focus on an adaptive plan with expected outcomes and verification criteria.':'Focus on useful assistance, not generic chat.'
    ].join('\n\n');
    try{
      const body={message:prompt,history:ctx.current&&ctx.current.conversation&&ctx.current.conversation.recentTurns||[],conversationContext:ctx.current&&ctx.current.conversation||{},stateSummary:ctx.state,userMemory:ctx.profile&&ctx.profile.confirmedFacts||[],brainContext:{assistanceEngine:VERSION,patterns:arr(KEYS.patterns).slice(-12),diagnosis:academicDiagnosis(ctx),nativeBrain:nativeBrain},nextMove:null,webSearch:false,voiceMode:'Tutor'};
      const r=await fetch((g.NORI_API_BASE_URL||'')+'/api/brain',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); const j=await r.json(); if(!r.ok)throw new Error(j.error||'AI_REQUEST_FAILED');
      const parsed=extractJSON(j.reply); if(parsed)return Object.assign(parsed,{provider:j.provider||null,model:j.model||null,rawReply:j.reply});
      return {interpretation:j.reply,confidence:.45,what_i_noticed:[],why_it_matters:[],proposal:null,changes:[],risks:['Model did not return structured JSON.'],missing_information:[],resolved_reference:null,next_step:null,action:null,provider:j.provider||null,model:j.model||null,nativeBrain:nativeBrain};
    }catch(e){return {interpretation:'Model assistance is unavailable right now; deterministic context and pattern analysis remain available.',confidence:.2,what_i_noticed:[],why_it_matters:[],proposal:null,changes:[],risks:[e.message],missing_information:[],resolved_reference:null,next_step:null,action:null,degraded:true,nativeBrain:nativeBrain};}
  }

  async function assist(message,opts){
    const ctx=await buildContext(); const miss=missingForAction(message,ctx); const patterns=detectPatterns(ctx); const diagnosis=academicDiagnosis(ctx); const suggestions=proactive(ctx);
    if(miss.asks.length)return {ok:true,status:'needs_clarification',question:'I need '+miss.asks.join(' and ')+' before I change anything.',missing:miss.asks,reference:miss.reference,context:ctx};
    const model=await askModel(message,ctx,opts||{}); const result={ok:true,status:'assisted',version:VERSION,message:String(message||''),context:ctx,patterns,diagnosis,proactive:suggestions,decision:model};
    const session=arr(KEYS.sessions);session.push({id:uid('session'),at:now(),message:String(message||''),interpretation:model.interpretation,confidence:model.confidence,provider:model.provider||null});save(KEYS.sessions,session.slice(-MAX));emit('assistance.completed',{message:String(message||''),confidence:model.confidence,provider:model.provider||null});return result;
  }
  function dashboard(){return {version:VERSION,profile:profile(),patterns:arr(KEYS.patterns).slice(-20),plans:arr(KEYS.plans).slice(-20),outcomes:arr(KEYS.outcomes).slice(-20),sessions:arr(KEYS.sessions).slice(-20),capabilities:{personalContext:true,continuity:true,userState:true,patterns:true,academicDiagnosis:true,adaptivePlanning:true,proactiveAssistance:true,ambiguityResolution:true,decisionExplanation:true,outcomeLearning:true,crossFeatureReasoning:true,modelOrchestration:true}};}
  function resetDerived(){save(KEYS.patterns,[]);save(KEYS.plans,[]);save(KEYS.outcomes,[]);save(KEYS.sessions,[]);return true;}
  g.NoriAssistanceV36={version:VERSION,profile,setProfile,addFact,getFact,buildContext,goalProgress,goalNotifications,academicDiagnosis,detectPatterns,resolveReference,summarizeConversation,missingForAction,createPlan,recordOutcome,evaluateOutcome,proactive,askModel,assist,dashboard,resetDerived,events:()=>arr(KEYS.events)};
  g.NoriAssistanceEngine=g.NoriAssistanceV36;
})(window);
