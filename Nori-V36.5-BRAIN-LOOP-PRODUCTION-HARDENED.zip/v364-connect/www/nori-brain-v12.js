/* NORI BRAIN V12 — Core Intelligence Layer
   Memory 2.0 • Reasoning/uncertainty • Tool routing • KAGE retrieval
   • self-check • academic model
   Local-first, privacy-first, human override preserved.
*/
(function(g){'use strict';
  var K={memory:'nori_brain_memory_v12',profile:'nori_academic_profile_v12',events:'nori_brain_events_v12',prefs:'nori_brain_prefs_v12'};
  var SECRET=/\b(sk-[A-Za-z0-9_-]{12,}|ghp_[A-Za-z0-9_]+|AIza[\w-]+|Bearer\s+\S+|password\s*=|token\s*=|secret\s*=)\b/i;
  var SENSITIVE=/(password|passcode|pin|api key|secret|token|bank|credit card|card number|address|location|medical|diagnos|medication|trauma|abuse|self[- ]?harm|suicide|sexual|private|family conflict|legal case)/i;
  var now=function(){return new Date().toISOString()};
  function load(k,fb){try{var x=JSON.parse(localStorage.getItem(k)||'null');return x==null?fb:x}catch(e){return fb}}
  function save(k,v){try{if(typeof noriSafeWrite==='function')return noriSafeWrite(k,v);localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function uid(p){return p+'_'+Date.now()+'_'+Math.random().toString(36).slice(2,8)}
  function text(x){return String(x==null?'':x).replace(/[\u0000-\u001F]/g,' ').replace(/\s+/g,' ').trim()}
  function tokens(s){return text(s).toLowerCase().split(/[^a-z0-9%]+/).filter(function(x){return x.length>1})}
  function redact(s){s=text(s);return SECRET.test(s)?'[redacted credential]':s}

  /* ---------- Memory 2.0 ---------- */
  function memoryRows(){
    var rows=load(K.memory,[]).filter(function(m){return m&&typeof m.text==='string'});
    try{
      if(typeof noriMemoryLoad==='function') (noriMemoryLoad().items||[]).forEach(function(m){
        if(!m||typeof m.text!=='string'||SENSITIVE.test(m.text)||SECRET.test(m.text))return;
        if(!rows.some(function(x){return x.text===m.text})) rows.push({id:m.id||uid('legacy'),text:m.text,source:'legacy_confirmed',createdAt:m.date||now(),updatedAt:m.date||now(),importance:3,confidence:1,scope:'user',status:'confirmed'});
      });
    }catch(e){}
    return rows;
  }
  function memoryPolicy(t){t=redact(t);if(!t||SECRET.test(t))return {allow:false,reason:'secret'};if(SENSITIVE.test(t))return {allow:false,reason:'sensitive'};return {allow:true}}
  function addMemory(t,meta){
    t=text(t);var p=memoryPolicy(t);if(!p.allow)return {ok:false,reason:p.reason};
    meta=meta||{};var rows=memoryRows(), n=t.toLowerCase();
    var existing=rows.find(function(m){return m.text.toLowerCase()===n});
    if(existing){existing.updatedAt=now();existing.status='confirmed';existing.confidence=1;save(K.memory,rows);return {ok:true,duplicate:true,item:existing}}
    var item={id:uid('mem'),text:t,source:meta.source||'user_confirmed',createdAt:now(),updatedAt:now(),importance:Math.max(1,Math.min(5,Number(meta.importance)||3)),confidence:Math.max(0,Math.min(1,Number(meta.confidence)==null?1:Number(meta.confidence))),scope:meta.scope||'user',status:meta.status||'confirmed',tags:Array.isArray(meta.tags)?meta.tags.slice(0,8):[]};
    rows.push(item);save(K.memory,rows.slice(-500));return {ok:true,item:item};
  }
  function updateMemory(id,patch){var rows=memoryRows(),m=rows.find(function(x){return x.id===id});if(!m)return {ok:false,reason:'not_found'};if(patch&&patch.text){var p=memoryPolicy(patch.text);if(!p.allow)return {ok:false,reason:p.reason};m.text=text(patch.text)};['importance','confidence','status'].forEach(function(k){if(patch&&patch[k]!=null)m[k]=patch[k]});m.updatedAt=now();save(K.memory,rows);return {ok:true,item:m}}
  function removeMemory(id){var rows=memoryRows().filter(function(x){return x.id!==id});save(K.memory,rows);return rows}
  function recall(q,limit){
    var ts=tokens(q), nowMs=Date.now();
    return memoryRows().map(function(m){
      var mt=tokens(m.text), overlap=ts.filter(function(x){return mt.indexOf(x)>=0}).length;
      var ageDays=Math.max(0,(nowMs-Date.parse(m.updatedAt||m.createdAt||now()))/86400000);
      var recency=Math.exp(-ageDays/90), importance=(m.importance||3)/5, confidence=m.confidence==null?1:m.confidence;
      var score=overlap*2.5+importance*0.8+confidence*0.6+recency*0.7;
      return {m:m,score:score,overlap:overlap};
    }).filter(function(x){return x.overlap>0}).sort(function(a,b){return b.score-a.score}).slice(0,limit||8).map(function(x){return x.m});
  }
  function publicVoiceMemory(q){return recall(q,8).filter(function(m){return !SENSITIVE.test(m.text)&&!SECRET.test(m.text)}).map(function(m){return m.text})}

  /* ---------- Academic model ---------- */
  function state(){
    var out={};
    try{out.results=typeof noriHistoryLoadAll==='function'?noriHistoryLoadAll():{};}catch(e){out.results={}}
    try{out.assignments=typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():load('nori_command_assignments',[])}catch(e){out.assignments=[]}
    try{out.exams=typeof noriExamsLoad==='function'?noriExamsLoad():load('nori_exams',[])}catch(e){out.exams=[]}
    try{out.sessions=typeof noriStudySessionsLoad==='function'?noriStudySessionsLoad():load('nori_study_sessions',[])}catch(e){out.sessions=[]}
    try{out.context=typeof noriGetProtectionContext==='function'?noriGetProtectionContext():{mode:'normal'}}catch(e){out.context={mode:'normal'}}
    return out;
  }
  function daysUntil(d){if(!d)return 999;var x=new Date(d+'T23:59:59'),n=new Date();return Math.ceil((x-n)/86400000)}
  function academicModel(s){
    var subjects={};
    Object.keys(s.results||{}).forEach(function(sub){var arr=s.results[sub]||[];var scores=arr.map(function(r){return Number(r.score)}).filter(function(x){return isFinite(x)});if(!scores.length)return;var latest=scores[scores.length-1],avg=scores.reduce(function(a,b){return a+b},0)/scores.length;var trend=scores.length>1?latest-scores[0]:0;subjects[sub]={latest:latest,average:Math.round(avg*10)/10,trend:Math.round(trend*10)/10,confidence:'observed'};});
    (s.assignments||[]).forEach(function(a){var sub=a.subject||'Academic';subjects[sub]=subjects[sub]||{};subjects[sub].openAssignments=(subjects[sub].openAssignments||0)+(a.status==='done'?0:1)});
    (s.exams||[]).forEach(function(e){var sub=e.subject||'Academic';subjects[sub]=subjects[sub]||{};var d=daysUntil(e.date);if(d>=0&&d<=30)subjects[sub].nextExamDays=Math.min(subjects[sub].nextExamDays==null?999:subjects[sub].nextExamDays,d)});
    var rows=Object.keys(subjects).map(function(sub){var x=subjects[sub],risk=0;if(typeof x.latest==='number'&&x.latest<80)risk+=(80-x.latest)*1.2;if(x.openAssignments)risk+=x.openAssignments*8;if(x.nextExamDays!=null&&x.nextExamDays<=7)risk+=20;if(x.trend<0)risk+=Math.min(15,Math.abs(x.trend)/2);return {subject:sub,data:x,risk:Math.round(risk*10)/10}}).sort(function(a,b){return b.risk-a.risk});
    var profile={generatedAt:now(),subjects:rows,topWeaknesses:rows.slice(0,3).map(function(x){return x.subject}),note:'Scores show performance, not cause. Low performance alone does not establish laziness, ability, or motivation.'};
    save(K.profile,profile);return profile;
  }

  /* ---------- Reasoning + uncertainty ---------- */
  function reason(input,ctx){
    var t=text(input), assumptions=[],unknowns=[],evidence=[];
    var st=state(), profile=academicModel(st);
    if(profile.topWeaknesses.length)evidence.push('Recorded academic data identifies '+profile.topWeaknesses.join(', ')+' as higher-risk areas.');
    if(!st.assignments.length&&!st.exams.length&&!Object.keys(st.results||{}).length)unknowns.push('No useful academic records are available.');
    if(/why|cause|reason|because/i.test(t)&&!/record|score|result/i.test(t))assumptions.push('The available records may show a pattern but cannot establish its cause.');
    return {evidence:evidence,assumptions:assumptions,unknowns:unknowns,confidence:unknowns.length?'low':assumptions.length?'medium':'high',academic:profile};
  }

  /* ---------- Tool router ---------- */
  function route(message,opts){
    opts=opts||{};var m=text(message), web=!!opts.webSearch, t=m.toLowerCase();
    var route='model',tools=[];
    if(web){route='web_research';tools.push('web_search')}
    else if(/^(what is|calculate|convert|define|translate)\b/i.test(m)&&m.length<220){route='fast_model'}
    if(/kage|handbook|human override|system integrity|award|exam result|new era|rule|breach|consequence|phase/i.test(t))tools.push('kage_retrieval');
    if(/grade|score|exam|assignment|study|subject|physics|chemistry|biology|math|english|agriculture|deadline/i.test(t))tools.push('academic_model');
    if(/remember|forget|memory/i.test(t))tools.push('memory');
    if(/schedule|remind|focus mode|calendar|alarm/i.test(t))tools.push('app_action');
    return {route:route,tools:tools,reason:web?'Explicit web request.':tools.length?'Relevant local intelligence is available.':'General conversation/reasoning.'};
  }

  function context(message,opts){opts=opts||{};var st=state(),profile=academicModel(st),r=reason(message),rt=route(message,opts),mem=opts.publicVoice?publicVoiceMemory(message):recall(message,8);var legacy=(g.noriBrainV10Legacy&&g.noriBrainV10Legacy.buildChatContext)?g.noriBrainV10Legacy.buildChatContext(message,opts):null;return {version:'12',route:rt,reasoning:r,memory:mem,academic:profile,worldState:legacy&&legacy.worldState||null,decision:legacy&&legacy.decision||null,privacy:{sensitiveExcluded:true,secretsExcluded:true},psychology:{mode:'general-support',nonDiagnostic:true,principles:['separate facts from interpretations','reduce cognitive load','use concrete next steps','protect autonomy','preserve standards when capacity permits']}}}

  /* ---------- Tier 2 contextual next move ---------- */
  function contextualNextMove(){
    var s=state(),p=academicModel(s),best=null;
    (s.assignments||[]).forEach(function(a){if(a.status==='done')return;var d=daysUntil(a.dueDate||a.deadline||a.date);var score=(d<999?Math.max(0,40-d):0)+10;if(!best||score>best.score)best={type:'assignment',subject:a.subject||'Academic',title:a.title||a.name||'Open assignment',score:score};});
    (s.exams||[]).forEach(function(e){var d=daysUntil(e.date);if(d>=0&&d<=30){var score=55+(30-d);if(!best||score>best.score)best={type:'exam',subject:e.subject||'Academic',title:e.title||'Upcoming exam',days:d,score:score};}});
    if(!best&&p.topWeaknesses.length)best={type:'weakness',subject:p.topWeaknesses[0],title:'Work the highest-risk subject',score:20};
    return best?{available:true,type:best.type,subject:best.subject,title:best.title,days:best.days,reason:'Selected from current recorded academic state; it is not a claim about motivation or cause.'}:{available:false,reason:'Not enough current task, exam, or result data.'};
  }

  function setPublicMode(v){var p=load(K.prefs,{});p.publicVoiceMode=!!v;save(K.prefs,p);return p.publicVoiceMode}
  function publicMode(){return !!load(K.prefs,{publicVoiceMode:false}).publicVoiceMode}
  function affect(message,decision){var t=text(message).toLowerCase(),a='calm';if(/sad|tired|overwhelmed|hard|rough|upset/.test(t))a='warm';if(/urgent|unsafe|emergency/.test(t))a='concerned';if(/deadline|exam|focus|start now/.test(t))a='focused';if(decision&&decision.action==='protect_sleep')a='caring';return a}
  function setAffect(e){if(typeof noriVisualSetAffect==='function')noriVisualSetAffect(e);return e}
  function rememberConfirmed(t,m){return addMemory(t,Object.assign({source:'user_confirmed',status:'confirmed',confidence:1},m||{}))}
  function buildChatContext(m,o){var c=context(m,o||{});c.emotion=affect(m,c.decision);c.emotionMeta={face:c.emotion,motion:c.emotion==='focused'?'precise':'steady',tone:c.emotion};return c}
  g.noriBrainV12={version:'12',contextualNextMove:contextualNextMove,memoryAdd:addMemory,memoryUpdate:updateMemory,memoryRemove:removeMemory,getMemory:memoryRows,recall:recall,publicVoiceMemory:publicVoiceMemory,rememberConfirmed:rememberConfirmed,academicModel:academicModel,reason:reason,route:route,buildChatContext:buildChatContext,setAffect:setAffect,publicMode:publicMode,setPublicMode:setPublicMode,redact:redact};
  /* compatibility: V11 client expects this name */
  g.noriBrainV10=g.noriBrainV12;
})(window);
