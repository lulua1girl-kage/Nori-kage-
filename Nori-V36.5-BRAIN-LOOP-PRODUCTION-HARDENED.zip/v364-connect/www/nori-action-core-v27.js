/* NORI ACTION & EXECUTION CORE V27
   Deterministic execution layer. AI may propose; this layer executes only after
   explicit human confirmation. Every mutation gets a before-snapshot, result,
   verification record, and safe rollback path.
*/
(function(g){'use strict';
  const KEY='nori_action_core_v27';
  const OPKEY=KEY+'/operations';
  const PKEY=KEY+'/proposals';
  const MAX=150;
  const now=()=>new Date().toISOString();
  const uid=p=>(p||'op')+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);
  const load=(k,fb)=>{try{if(g.NoriState&&typeof g.NoriState.readSync==='function'){const x=g.NoriState.readSync(k);return x==null?fb:x;}const x=JSON.parse(localStorage.getItem(k)||'null');return x==null?fb:x}catch(e){return fb}};
  const save=(k,v)=>{try{if(g.NoriState&&typeof g.NoriState.writeSync==='function')return g.NoriState.writeSync(k,v,{requestId:'action-core-v27'});return typeof g.noriSafeWrite==='function'?g.noriSafeWrite(k,v):(localStorage.setItem(k,JSON.stringify(v)),true)}catch(e){return false}};
  const clone=x=>JSON.parse(JSON.stringify(x));
  const get=(k,fb)=>load(k,fb);
  const put=(k,v)=>save(k,v);
  const audit=(event)=>{const a=load(OPKEY,[]);a.push(Object.assign({at:now()},event));save(OPKEY,a.slice(-MAX));};
  const readProposals=()=>load(PKEY,[]);
  const writeProposals=x=>save(PKEY,x.slice(-MAX));

  const SUBJECTS=['Mathematics','Physics','Chemistry','Biology','English','Agriculture','Web Development','Information Technology'];
  function snapshot(keys){const out={};keys.forEach(k=>{out[k]=g.NoriState&&typeof g.NoriState.readSync==='function'?JSON.stringify(g.NoriState.readSync(k)):localStorage.getItem(k)});return out}
  function restore(s){let ok=true;Object.keys(s||{}).forEach(k=>{try{if(g.NoriState&&typeof g.NoriState.writeSync==='function'){const v=s[k]===null?null:JSON.parse(s[k]);if(v===null){localStorage.removeItem(k);}else g.NoriState.writeSync(k,v,{requestId:'action-core-v27-rollback'});}else if(s[k]===null)localStorage.removeItem(k);else localStorage.setItem(k,s[k]);}catch(e){ok=false}});return ok}
  function currentState(){
    const assignments=typeof g.noriAssignmentsLoad==='function'?g.noriAssignmentsLoad():get('nori_command_assignments',[]);
    const exams=typeof g.noriExamsLoad==='function'?g.noriExamsLoad():get('nori_exams',[]);
    const sessions=typeof g.noriStudySessionsLoad==='function'?g.noriStudySessionsLoad():get('nori_study_sessions',[]);
    const calendar=g.noriCalendar&&typeof g.noriCalendar.events==='function'?g.noriCalendar.events():get('nori_calendar_events_v1',[]);
    const alarms=g.noriVoiceAlarms&&typeof g.noriVoiceAlarms.allAlarms==='function'?g.noriVoiceAlarms.allAlarms():get('nori_voice_alarms',[]);
    return {assignments,exams,sessions,calendar,alarms,results:typeof g.noriHistoryLoadAll==='function'?g.noriHistoryLoadAll():get('nori_eval_history_all_subjects',{}),recovery:typeof g.noriGetRecoverySummary==='function'?g.noriGetRecoverySummary():null,activeConsequences:typeof g.noriActiveConsequences==='function'?g.noriActiveConsequences():[]};
  }
  function findByIdOrTitle(items,ref){const r=String(ref||'').trim().toLowerCase();return items.find(x=>String(x.id||'').toLowerCase()===r)||items.find(x=>String(x.title||x.topic||x.label||'').toLowerCase()===r)||items.find(x=>String(x.title||x.topic||x.label||'').toLowerCase().includes(r));}
  function dateOrToday(v){return v||new Date().toISOString().slice(0,10)}
  function num(v,d){const n=Number(v);return Number.isFinite(n)?n:d}

  function makeProposal(type,input,reason,evidence){
    const definitions={
      create_assignment:{label:'Create assignment',keys:['nori_command_assignments']},
      update_assignment:{label:'Update assignment',keys:['nori_command_assignments']},
      complete_assignment:{label:'Mark assignment complete',keys:['nori_command_assignments']},
      reopen_assignment:{label:'Reopen assignment',keys:['nori_command_assignments']},
      create_study_session:{label:'Create study session',keys:['nori_study_sessions']},
      complete_study_session:{label:'Complete study session',keys:['nori_study_sessions']},
      create_calendar_event:{label:'Schedule calendar event',keys:['nori_calendar_events_v1']},
      delete_calendar_event:{label:'Delete calendar event',keys:['nori_calendar_events_v1','nori_calendar_exceptions_v1']},
      schedule_reminder:{label:'Schedule reminder',keys:['nori_v27_reminders']},
      schedule_alarm:{label:'Schedule voice alarm',keys:['nori_voice_alarms']},
      cancel_alarm:{label:'Cancel voice alarm',keys:['nori_voice_alarms']},
      focus_start:{label:'Start Focus Mode',keys:[]},
      focus_stop:{label:'Stop Focus Mode',keys:[]},
      record_result:{label:'Record result',keys:['nori_eval_history_all_subjects']},
      recalculate_awards:{label:'Recalculate awards',keys:[]},
      recovery_review:{label:'Open recovery review',keys:[]}
    };
    const d=definitions[type];if(!d)return null;
    const p={id:uid('proposal'),createdAt:now(),type,definition:d,input:clone(input||{}),reason:reason||'Requested action.',evidence:Array.isArray(evidence)?clone(evidence):[],status:'pending_confirmation',confirmation:{required:true,confirmedAt:null,confirmedBy:'human'},simulation:null};
    const a=readProposals();a.push(p);writeProposals(a);audit({type:'proposal_created',proposalId:p.id,actionType:type});return p;
  }

  function parseText(text){
    const t=String(text||'').trim(), l=t.toLowerCase(); if(!t)return null;
    let subject=SUBJECTS.find(s=>l.includes(s.toLowerCase()));
    if(/complete|finish|mark.*done/.test(l)&&/assignment|task/.test(l)) return makeProposal('complete_assignment',{ref:extractQuoted(t)||extractAfter(t,/(?:assignment|task)\s+/i)},'The request explicitly asks to complete an assignment.');
    if(/reopen|open again/.test(l)&&/assignment|task/.test(l)) return makeProposal('reopen_assignment',{ref:extractQuoted(t)||extractAfter(t,/(?:assignment|task)\s+/i)},'The request explicitly asks to reopen an assignment.');
    if(/start.*focus|enable.*focus|focus mode.*start/.test(l)) return makeProposal('focus_start',{packages:g.NORI_BLOCKABLE_APPS?g.NORI_BLOCKABLE_APPS.map(x=>x.package):[]},'The request explicitly asks to start Focus Mode.');
    if(/stop.*focus|disable.*focus|focus mode.*stop/.test(l)) return makeProposal('focus_stop',{},'The request explicitly asks to stop Focus Mode.');
    if(/recalculate.*award|refresh.*award|check.*award/.test(l)) return makeProposal('recalculate_awards',{},'The request explicitly asks Nori to recalculate award qualification from recorded evidence.');
    if(/recovery review|review recovery|reassess recovery/.test(l)) return makeProposal('recovery_review',{},'The request explicitly asks for a recovery review.');
    if(/schedule|set|create|add/.test(l)&&/study/.test(l)){
      const minutes=num((t.match(/(\d+)\s*(?:min|minutes?)/i)||[])[1],25); const date=(t.match(/(20\d{2}-\d{2}-\d{2})/)||[])[1]||dateOrToday();
      return makeProposal('create_study_session',{subject:subject||'Mathematics',topic:extractAfter(t,/study(?: session)?\s+(?:for\s+)?/i)||'Study session',minutes,date},'The request explicitly asks to create a study session.');
    }
    if(/schedule|set|create|add/.test(l)&&/assignment|task/.test(l)){
      const due=(t.match(/(20\d{2}-\d{2}-\d{2})/)||[])[1]||''; const ref=extractQuoted(t)||extractAfter(t,/(?:assignment|task)\s+/i)||'New assignment';
      return makeProposal('create_assignment',{title:ref,subject:subject||'Mathematics',due},'The request explicitly asks to create an assignment.');
    }
    if(/remind me|schedule reminder/.test(l)){
      const when=(t.match(/(20\d{2}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2})?)/)||[])[1]; return makeProposal('schedule_reminder',{title:extractAfter(t,/remind me(?: to)?\s+/i)||'Nori reminder',when},'The request explicitly asks for a reminder.');
    }
    if(/alarm/.test(l)&&/set|schedule|create/.test(l)){
      const tm=(t.match(/\b([01]?\d|2[0-3]):[0-5]\d\b/)||[])[0]; return makeProposal('schedule_alarm',{label:extractAfter(t,/alarm(?: at)?\s+/i)||'Nori alarm',date:dateOrToday(),time:tm||'20:00',repeat:'none'},'The request explicitly asks to schedule an alarm.');
    }
    return null;
  }
  function extractQuoted(t){const m=t.match(/["“](.*?)["”]/);return m&&m[1]?m[1].trim():''}
  function extractAfter(t,re){const m=t.match(re);return m?m[1].replace(/\s+(?:due|on)\s+20\d{2}-\d{2}-\d{2}.*/i,'').trim():''}

  function preview(p){
    if(!p||p.status==='cancelled')return {ok:false,reason:'proposal_not_available'};
    const s=currentState(), i=p.input||{}, changes=[]; const add=(target,before,after)=>changes.push({target,before:before===undefined?null:before,after:after===undefined?null:after});
    switch(p.type){
      case 'create_assignment': add('assignment',null,{title:i.title||'New assignment',subject:i.subject||'Mathematics',due:i.due||'',status:'open'});break;
      case 'update_assignment': {const x=findByIdOrTitle(s.assignments,i.ref); if(!x)return {ok:false,reason:'assignment_not_found'}; add('assignment '+x.id,x,{...x,...(i.patch||{})});break;}
      case 'complete_assignment': {const x=findByIdOrTitle(s.assignments,i.ref); if(!x)return {ok:false,reason:'assignment_not_found'};add('assignment '+x.id,x,{...x,status:'done',updatedAt:now()});break;}
      case 'reopen_assignment': {const x=findByIdOrTitle(s.assignments,i.ref); if(!x)return {ok:false,reason:'assignment_not_found'};add('assignment '+x.id,x,{...x,status:'open',updatedAt:now()});break;}
      case 'create_study_session': add('study session',null,{subject:i.subject||'Mathematics',topic:i.topic||'Study session',minutes:num(i.minutes,25),date:dateOrToday(i.date),status:'planned'});break;
      case 'complete_study_session': {const x=findByIdOrTitle(s.sessions,i.ref);if(!x)return {ok:false,reason:'study_session_not_found'};add('study session '+x.id,x,{...x,status:'completed',completedAt:now()});break;}
      case 'create_calendar_event': add('calendar event',null,{title:i.title||'Untitled event',type:i.type||'academic',start:dateOrToday(i.start),notes:i.notes||''});break;
      case 'delete_calendar_event': {const x=findByIdOrTitle(s.calendar,i.ref);if(!x)return {ok:false,reason:'calendar_event_not_found'};add('calendar event '+x.id,x,null);break;}
      case 'schedule_reminder': add('reminder',null,{title:i.title||'Nori reminder',when:i.when||''});break;
      case 'schedule_alarm': add('voice alarm',null,{label:i.label||'Nori alarm',date:dateOrToday(i.date),time:i.time||'20:00',repeat:i.repeat||'none'});break;
      case 'cancel_alarm': {const x=findByIdOrTitle(s.alarms,i.ref);if(!x)return {ok:false,reason:'alarm_not_found'};add('voice alarm '+x.id,x,null);break;}
      case 'focus_start': add('Focus Mode',false,true);break;
      case 'focus_stop': add('Focus Mode',true,false);break;
      case 'record_result': {const score=num(i.score,NaN);if(!i.subject||!Number.isFinite(score)||score<0||score>100)return {ok:false,reason:'result_requires_explicit_subject_and_score_0_to_100'};add('result',null,{subject:i.subject,score,date:dateOrToday(i.date),assessmentType:i.assessmentType||'Recorded result'});break;}
      case 'recalculate_awards': add('awards','current evidence','recomputed qualification');break;
      case 'recovery_review': add('recovery','current state','review screen opened');break;
      default:return {ok:false,reason:'unsupported_action'};
    }
    const out={ok:true,proposalId:p.id,changes};p.simulation=out;const arr=readProposals();const idx=arr.findIndex(x=>x.id===p.id);if(idx>=0){arr[idx]=p;writeProposals(arr)}audit({type:'simulation',proposalId:p.id,changes});return out;
  }

  async function execute(p,actor){
    if(!p||p.status!=='pending_confirmation')return {ok:false,reason:'proposal_not_pending'};
    const prev=preview(p); if(!prev.ok)return prev;
    const i=p.input||{}, touched=(p.definition&&p.definition.keys)||[]; const before=snapshot(touched); let result=null;
    try{
      switch(p.type){
        case 'create_assignment': result=typeof g.noriAssignmentAdd==='function'?g.noriAssignmentAdd({title:i.title||'New assignment',subject:i.subject||'Mathematics',due:i.due||'',status:'open'}):null; if(!result){const a=get('nori_command_assignments',[]);result={id:uid('assignment'),title:i.title||'New assignment',subject:i.subject||'Mathematics',due:i.due||'',status:'open',createdAt:now()};a.push(result);if(!put('nori_command_assignments',a))throw Error('assignment_save_failed')}break;
        case 'update_assignment': {const x=findByIdOrTitle(get('nori_command_assignments',[]),i.ref);if(!x)throw Error('assignment_not_found');result=typeof g.noriAssignmentUpdate==='function'?g.noriAssignmentUpdate(x.id,i.patch||{}):null;if(!result){const a=get('nori_command_assignments',[]);const ix=a.findIndex(y=>y.id===x.id);a[ix]=Object.assign({},a[ix],i.patch||{}, {updatedAt:now()});if(!put('nori_command_assignments',a))throw Error('assignment_save_failed')}break;}
        case 'complete_assignment': {const x=findByIdOrTitle(get('nori_command_assignments',[]),i.ref);if(!x)throw Error('assignment_not_found');if(typeof g.noriAssignmentUpdate==='function')result=g.noriAssignmentUpdate(x.id,{status:'done',updatedAt:now()});else{const a=get('nori_command_assignments',[]);const ix=a.findIndex(y=>y.id===x.id);a[ix]=Object.assign({},a[ix],{status:'done',updatedAt:now()});put('nori_command_assignments',a);result=a[ix]}break;}
        case 'reopen_assignment': {const x=findByIdOrTitle(get('nori_command_assignments',[]),i.ref);if(!x)throw Error('assignment_not_found');if(typeof g.noriAssignmentUpdate==='function')result=g.noriAssignmentUpdate(x.id,{status:'open',verification:'reopened',updatedAt:now()});else{const a=get('nori_command_assignments',[]);const ix=a.findIndex(y=>y.id===x.id);a[ix]=Object.assign({},a[ix],{status:'open',verification:'reopened',updatedAt:now()});put('nori_command_assignments',a);result=a[ix]}break;}
        case 'create_study_session': {const a=get('nori_study_sessions',[]);result={id:uid('study'),subject:i.subject||'Mathematics',topic:i.topic||'Study session',minutes:num(i.minutes,25),date:dateOrToday(i.date),status:'planned',createdAt:now()};a.push(result);if(!put('nori_study_sessions',a))throw Error('study_session_save_failed');break;}
        case 'complete_study_session': {const a=get('nori_study_sessions',[]),x=findByIdOrTitle(a,i.ref);if(!x)throw Error('study_session_not_found');x.status='completed';x.completedAt=now();put('nori_study_sessions',a);result=x;break;}
        case 'create_calendar_event': if(!g.noriCalendar||typeof g.noriCalendar.add!=='function')throw Error('calendar_unavailable');result=g.noriCalendar.add({title:i.title||'Untitled event',type:i.type||'academic',start:dateOrToday(i.start),notes:i.notes||''});break;
        case 'delete_calendar_event': {if(!g.noriCalendar)throw Error('calendar_unavailable');const x=findByIdOrTitle(g.noriCalendar.events(),i.ref);if(!x)throw Error('calendar_event_not_found');if(x.readonly)throw Error('linked_event_is_read_only');result=g.noriCalendar.remove(x.id);break;}
        case 'schedule_reminder': {const when=new Date(i.when||'');if(isNaN(when))throw Error('reminder_time_invalid');const arr=get('nori_v27_reminders',[]);result={id:uid('rem'),title:i.title||'Nori reminder',when:when.toISOString(),createdAt:now(),status:'scheduled'};if(g.NORI_IS_NATIVE&&typeof g.noriReminderSchedule==='function'){result.nativeId=await g.noriReminderSchedule(result.title,'Nori reminder: '+result.title,when,'nori_action');}arr.push(result);if(!put('nori_v27_reminders',arr))throw Error('reminder_save_failed');break;}
        case 'schedule_alarm': if(!g.noriVoiceAlarms||typeof g.noriVoiceAlarms.add!=='function')throw Error('voice_alarm_unavailable');result=await g.noriVoiceAlarms.add({label:i.label||'Nori alarm',date:dateOrToday(i.date),time:i.time||'20:00',repeat:i.repeat||'none'});break;
        case 'cancel_alarm': {if(!g.noriVoiceAlarms)throw Error('voice_alarm_unavailable');const x=findByIdOrTitle(g.noriVoiceAlarms.allAlarms(),i.ref);if(!x)throw Error('alarm_not_found');await g.noriVoiceAlarms.remove(x.id);result={cancelled:x};break;}
        case 'focus_start': if(typeof g.noriBlockerStart!=='function')throw Error('focus_mode_unavailable');result=await g.noriBlockerStart(i.packages||[]);break;
        case 'focus_stop': if(typeof g.noriBlockerStop!=='function')throw Error('focus_mode_unavailable');result=await g.noriBlockerStop();break;
        case 'record_result': {const score=num(i.score,NaN);if(!i.subject||!Number.isFinite(score)||score<0||score>100)throw Error('result_requires_explicit_subject_and_score_0_to_100');const rec={score,date:dateOrToday(i.date),assessmentType:i.assessmentType||'Recorded result',source:'human_confirmed_action',recordedAt:now()};if(typeof g.noriHistoryAppend==='function')g.noriHistoryAppend(i.subject,rec);else{const h=get('nori_eval_history_all_subjects',{});if(!h[i.subject])h[i.subject]=[];h[i.subject].push(rec);put('nori_eval_history_all_subjects',h)}result=rec;break;}
        case 'recalculate_awards': if(typeof g.noriEvaluateHigherAwards==='function')result=g.noriEvaluateHigherAwards();else result={note:'Award evaluator unavailable; no data changed.'};break;
        case 'recovery_review': if(typeof g.noriRoute==='function'){g.location.hash='#/recover'} result={opened:'#/recover'};break;
        default:throw Error('unsupported_action');
      }
      const verification=verify(p,result); if(!verification.ok)throw Error(verification.reason||'verification_failed');
      p.status='executed';p.confirmedAt=now();p.confirmedBy=actor||'human';p.operationId=uid('operation');p.execution={at:now(),result:clone(result),verification};
      const ops=load(OPKEY,[]);ops.push({type:'operation',id:p.operationId,proposalId:p.id,actionType:p.type,at:now(),before,after:snapshot(touched),result:clone(result),verification,undoable:true,status:'executed'});save(OPKEY,ops.slice(-MAX));
      const arr=readProposals();const idx=arr.findIndex(x=>x.id===p.id);if(idx>=0){arr[idx]=p;writeProposals(arr)}
      audit({type:'executed',proposalId:p.id,operationId:p.operationId,actionType:p.type,verification});
      if(typeof g.noriRoute==='function')setTimeout(()=>g.noriRoute(),50);
      return {ok:true,proposal:p,verification};
    }catch(e){restore(before);p.status='failed';p.failure={at:now(),reason:e.message};const arr=readProposals();const idx=arr.findIndex(x=>x.id===p.id);if(idx>=0){arr[idx]=p;writeProposals(arr)}audit({type:'execution_failed',proposalId:p.id,reason:e.message});return {ok:false,reason:e.message,rolledBack:true,proposal:p};}
  }
  function verify(p,result){
    const s=currentState(),i=p.input||{};
    switch(p.type){
      case 'create_assignment':return {ok:!!findByIdOrTitle(s.assignments,i.title),label:'Assignment exists in app data'};
      case 'complete_assignment':{const x=findByIdOrTitle(s.assignments,i.ref);return {ok:!!x&&x.status==='done',label:'Assignment status is done'};}
      case 'reopen_assignment':{const x=findByIdOrTitle(s.assignments,i.ref);return {ok:!!x&&x.status==='open',label:'Assignment status is open'};}
      case 'create_study_session':return {ok:!!findByIdOrTitle(s.sessions,i.topic),label:'Study session exists in app data'};
      case 'complete_study_session':{const x=findByIdOrTitle(s.sessions,i.ref);return {ok:!!x&&x.status==='completed',label:'Study session status is completed'};}
      case 'create_calendar_event':return {ok:!!findByIdOrTitle(s.calendar,i.title),label:'Calendar event exists'};
      case 'delete_calendar_event':return {ok:!findByIdOrTitle(s.calendar,i.ref),label:'Calendar event no longer exists'};
      case 'schedule_reminder':return {ok:!!findByIdOrTitle(get('nori_v27_reminders',[]),i.title),label:'Reminder is recorded'};
      case 'schedule_alarm':return {ok:!!findByIdOrTitle(s.alarms,i.label),label:'Alarm is recorded'};
      case 'cancel_alarm':return {ok:!findByIdOrTitle(s.alarms,i.ref),label:'Alarm is no longer recorded'};
      case 'record_result':return {ok:!!s.results[i.subject]&&s.results[i.subject].some(r=>r===result||r.recordedAt===result.recordedAt),label:'Result exists in history'};
      default:return {ok:true,label:'Action adapter completed'};
    }
  }
  function undo(operationId){
    const ops=load(OPKEY,[]),op=ops.find(x=>x.id===operationId&&x.status==='executed');if(!op)return {ok:false,reason:'operation_not_found'};
    if(op.actionType==='schedule_reminder'&&op.result&&op.result.nativeId&&typeof g.noriReminderCancel==='function'){g.noriReminderCancel(op.result.nativeId).catch(()=>{})}
    if(op.actionType==='focus_start'&&typeof g.noriBlockerStop==='function'){g.noriBlockerStop().catch(()=>{})}
    const ok=restore(op.before);op.status=ok?'undone':'undo_failed';op.undoneAt=now();save(OPKEY,ops.slice(-MAX));audit({type:'undo',operationId,status:op.status});if(ok&&typeof g.noriRoute==='function')setTimeout(()=>g.noriRoute(),50);return {ok,operation:op};
  }
  function confirm(id){const arr=readProposals(),p=arr.find(x=>x.id===id);if(!p)return {ok:false,reason:'proposal_not_found'};return execute(p,'human')}
  function cancel(id){const arr=readProposals(),p=arr.find(x=>x.id===id);if(!p)return {ok:false,reason:'proposal_not_found'};p.status='cancelled';p.cancelledAt=now();writeProposals(arr);audit({type:'proposal_cancelled',proposalId:id});return {ok:true,proposal:p}}
  function list(filter){const arr=readProposals().slice().reverse();return filter?arr.filter(filter):arr}
  function operations(){return load(OPKEY,[]).filter(x=>x&&x.type==='operation').slice().reverse()}

  g.NoriActionCoreV27={makeProposal,parseText,preview,confirm,cancel,execute,undo,list,operations,currentState,snapshot,restore,version:'27'};
  // Patch the old router only by exposing the new execution path; its route logic remains preserved.
  if(g.NoriToolRouterV22){g.NoriToolRouterV22.execute=g.NoriActionCoreV27.confirm;g.NoriToolRouterV22.simulate=function(p){return g.NoriActionCoreV27.preview(p)};g.NoriToolRouterV22.undo=g.NoriActionCoreV27.undo;}
})(window);
/* V22 -> V27 bridge: preserve the old router API while routing supported side-effects through V27. */
(function(g){'use strict';if(!g.NoriToolRouterV22||!g.NoriActionCoreV27)return;var oldPropose=g.NoriToolRouterV22.propose;g.NoriToolRouterV22.propose=function(message,opts){var p=g.NoriActionCoreV27.parseText(message);return p||oldPropose.call(g.NoriToolRouterV22,message,opts)};g.NoriToolRouterV22.confirm=function(id){var p=g.NoriActionCoreV27.list(x=>x.id===id)[0];return p?g.NoriActionCoreV27.confirm(id):{ok:false,reason:'proposal_not_found'};};})(window);
