/* NORI V48 — Digital SAT Intelligence.
 * Uses official/current SAT structure as the schema, but does not copy protected question-bank text.
 */
(function(){'use strict';
 const sections={RW:{name:'Reading and Writing',domains:['Information and Ideas','Craft and Structure','Expression of Ideas','Standard English Conventions']},MATH:{name:'Math',domains:['Algebra','Advanced Math','Problem-Solving and Data Analysis','Geometry and Trigonometry']}};
 const modes=['DIAGNOSTIC','SKILL_BUILD','TIMED_MODULE','FULL_PRACTICE_REVIEW','ERROR_REPAIR','VOCABULARY','GRAMMAR','MATH_STRATEGY'];
 const traps=['misread-question','unit-error','sign-error','algebra-slip','evidence-overreach','grammar-rule-confusion','vocabulary-in-context','timing-rush','careless-calculation','wrong-strategy'];
 function blueprint(){return {test:'Digital SAT',sections,adaptive:true,modulesPerSection:2,modes,traps,officialPractice:'Use Bluebook for official full-length adaptive practice.'};}
 function diagnose(attempts){const a=Array.isArray(attempts)?attempts:[];const by={};a.forEach(x=>{const k=x.skill||x.domain||'UNKNOWN';by[k]=by[k]||{n:0,correct:0,time:0,errors:[]};by[k].n++;if(x.correct)by[k].correct++;if(Number.isFinite(x.seconds))by[k].time+=x.seconds;if(x.error)by[k].errors.push(x.error);});return Object.entries(by).map(([skill,v])=>({skill,accuracy:v.n?Math.round(v.correct/v.n*100):0,attempts:v.n,avgSeconds:v.n?Math.round(v.time/v.n):0,errors:v.errors}));}
 function nextSession(profile){const d=diagnose(profile&&profile.attempts);const weak=d.filter(x=>x.accuracy<80).sort((a,b)=>a.accuracy-b.accuracy);return {priority:weak.slice(0,3),session:[['concept repair',20],['guided questions',20],['timed mini-set',15],['error review',10]],rule:'Master the skill before increasing speed.'};}
 function scoreModel(raw){const r=Number(raw);return {raw:r,valid:Number.isFinite(r),note:'Nori tracks official score reports when supplied; it does not invent an official College Board score.'};}
 function explainWrong(q){return {steps:['identify what the question is testing','state the governing rule or concept','show the shortest valid route','explain why the tempting alternative fails','name the reusable trap','give one transfer question']};}
 window.NoriSAT={blueprint,diagnose,nextSession,scoreModel,explainWrong};
})();
