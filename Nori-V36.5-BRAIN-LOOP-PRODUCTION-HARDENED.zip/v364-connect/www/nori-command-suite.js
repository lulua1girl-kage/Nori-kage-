/* NORI COMMAND SUITE — live extensions around the original Phase/Brain architecture. */
(function(){
  const SUBJECTS = (typeof NORI_MEET_SUBJECTS !== 'undefined' ? NORI_MEET_SUBJECTS : ["Mathematics","Physics","Chemistry","Biology","English","Agriculture","Web Development","Information Technology"]);
  function escText(v){ return String(v == null ? '' : v); }
  function today(){ return new Date().toISOString().slice(0,10); }
  function load(key, fallback){ try { const x=JSON.parse(localStorage.getItem(key)||'null'); return x==null?fallback:x; } catch(e){ return fallback; } }
  function save(key,val){ try { localStorage.setItem(key, JSON.stringify(val)); return true; } catch(e){ return false; } }
  function uid(prefix){ return prefix+'_'+Date.now()+'_'+Math.random().toString(36).slice(2,7); }
  function addPanelTitle(text, action){ const head=noriEl('div',{class:'nori-section-head'}); head.appendChild(noriEl('h2',{text:text})); if(action) head.appendChild(action); return head; }
  function btn(text, cls, fn){ const b=noriEl('button',{class:'nori-btn '+(cls||'nori-btn-ghost'),text:text}); if(fn)b.addEventListener('click',fn); return b; }
  function route(h){ location.hash=h; }
  function latestResults(){
    const all=typeof noriHistoryLoadAll==='function'?noriHistoryLoadAll():{}; const out=[];
    Object.keys(all).forEach(s=>(all[s]||[]).forEach(r=>{if(typeof r.score==='number')out.push({subject:s,score:r.score,date:r.date||''});}));
    return out.sort((a,b)=>String(a.date).localeCompare(String(b.date)));
  }
  function latestBySubject(){ const out={}; latestResults().forEach(r=>out[r.subject]=r); return out; }
  function activeConsequences(){ return typeof noriActiveConsequences==='function'?noriActiveConsequences():[]; }
  function assignments(){ return typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():load('nori_command_assignments',[]); }

  function renderTodayLive(){
    const all=latestResults(), latest=all[all.length-1], active=activeConsequences();
    const a=assignments().filter(x=>x.status!=='done');
    const due=a.filter(x=>x.due).sort((x,y)=>String(x.due).localeCompare(String(y.due)))[0];
    let text='No task selected yet.';
    if(active.length) text='Resolve the active restriction and its recovery requirement.';
    else if(due) text='Next: '+due.title+' — due '+due.due+'.';
    else if(latest && latest.score<80) text='Review '+latest.subject+' after the latest result of '+latest.score+'%.';
    else if(a.length) text='Start with '+a[0].title+'.';
    else text='Add a real assignment or study session to establish today’s command.';
    return {text,latest,active,assignment:due};
  }

  function noriRenderVerification(){
    const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});
    wrap.appendChild(noriRenderCommandHeader(false));
    wrap.appendChild(noriRenderSuiteCrumb('Verification'));
    const card=noriEl('section',{class:'nori-section-card'}); card.appendChild(addPanelTitle('Verification'));
    const list=noriEl('div',{class:'nori-verification-list'});
    const items=assignments().filter(x=>x.status==='done' || x.verification);
    if(!items.length) list.appendChild(noriEl('div',{class:'nori-command-empty',text:'No completed items awaiting verification.'}));
    items.slice().reverse().forEach(x=>{
      const row=noriEl('div',{class:'nori-verification-row'});
      const left=noriEl('div',{}); left.appendChild(noriEl('strong',{text:x.title})); left.appendChild(noriEl('small',{text:(x.subject||'')+(x.due?' · due '+x.due:'')})); row.appendChild(left);
      const status=x.verification||'unverified'; row.appendChild(noriEl('span',{class:'nori-state-chip '+status,text:status.toUpperCase()}));
      const act=noriEl('div',{class:'nori-inline-actions'});
      act.appendChild(btn('VERIFY','nori-btn-primary',function(){ noriAssignmentUpdate(x.id,{verification:'verified',verifiedAt:new Date().toISOString()}); noriRoute(); }));
      act.appendChild(btn('REOPEN','nori-btn-ghost',function(){ noriAssignmentUpdate(x.id,{status:'open',verification:'reopened'}); noriRoute(); }));
      row.appendChild(act); list.appendChild(row);
    }); card.appendChild(list); wrap.appendChild(card); wrap.appendChild(noriBottomNav('profile')); return wrap;
  }

  function noriRenderStudy(){
    const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'}); wrap.appendChild(noriRenderCommandHeader('study')); wrap.appendChild(noriRenderSuiteCrumb('Study'));
    const sessions=load('nori_study_sessions',[]), latest=latestBySubject();
    // Everything a student actually uses to study lives on this one screen:
    // Nori (the AI) front and center, subject sessions below, exam prep one tap away.
    const ai=noriEl('section',{class:'nori-section-card nori-ask-nori-card'});
    ai.appendChild(addPanelTitle('Nori', btn('EXAM CENTER','nori-btn-ghost',()=>route('#/exams'))));
    const aiBody=noriEl('div',{class:'nori-ask-nori-body'});
    aiBody.appendChild(noriEl('img',{src:'assets/nori-avatar-home.png',alt:'',class:'nori-ask-nori-avatar'}));
    const aiText=noriEl('div',{});
    aiText.appendChild(noriEl('strong',{text:'Your AI study mentor'}));
    aiText.appendChild(noriEl('p',{class:'nori-lede',text:'Ask Nori to explain a topic, quiz you, plan a study session, or record a real result.'}));
    aiText.appendChild(btn('ASK NORI →','nori-btn-primary',()=>route('#/meet-nori')));
    aiBody.appendChild(aiText);
    ai.appendChild(aiBody);
    wrap.appendChild(ai);
    const hero=noriEl('section',{class:'nori-section-card nori-study-hero'});
    hero.appendChild(addPanelTitle('Study Center',btn('+ SESSION','nori-btn-primary',()=>noriStudySessionModal())));
    const grid=noriEl('div',{class:'nori-study-grid'});
    SUBJECTS.forEach(s=>{const ls=latest[s], count=sessions.filter(x=>x.subject===s&&x.status==='completed').length; const c=noriEl('button',{class:'nori-study-subject'}); c.appendChild(noriEl('strong',{text:s})); c.appendChild(noriEl('span',{text:ls?'Latest '+ls.score+'%':'No result yet'})); c.appendChild(noriEl('small',{text:count+' completed session'+(count===1?'':'s')})); c.addEventListener('click',()=>noriStudySessionModal(s)); grid.appendChild(c);}); hero.appendChild(grid); wrap.appendChild(hero);
    const recent=noriEl('section',{class:'nori-section-card'}); recent.appendChild(addPanelTitle('Recent Study Sessions'));
    const list=noriEl('div',{class:'nori-verification-list'}); const sorted=sessions.slice().sort((a,b)=>String(b.date||'').localeCompare(String(a.date||''))).slice(0,10);
    if(!sorted.length) list.appendChild(noriEl('div',{class:'nori-command-empty',text:'No study sessions recorded yet.'}));
    sorted.forEach(s=>{const r=noriEl('div',{class:'nori-verification-row'}); const l=noriEl('div',{});l.appendChild(noriEl('strong',{text:s.subject+' — '+s.topic}));l.appendChild(noriEl('small',{text:(s.date||'')+' · '+s.minutes+' min'}));r.appendChild(l);r.appendChild(noriEl('span',{class:'nori-state-chip '+s.status,text:s.status.toUpperCase()})); if(s.status!=='completed')r.appendChild(btn('COMPLETE','nori-btn-primary',()=>{s.status='completed';s.completedAt=new Date().toISOString();save('nori_study_sessions',sessions);noriRoute();}));list.appendChild(r);}); recent.appendChild(list); wrap.appendChild(recent); wrap.appendChild(noriBottomNav('study')); return wrap;
  }
  function noriStudySessionModal(subject){
    const ov=noriEl('div',{class:'nori-modal'}), m=noriEl('div',{class:'nori-modal-card'}); const h=noriEl('div',{class:'nori-modal-head'});h.appendChild(noriEl('h2',{text:'New Study Session'}));h.appendChild(btn('Close','nori-btn-ghost',()=>ov.remove()));m.appendChild(h);
    const fields={}; [['subject','Subject','select'],['topic','Topic','text'],['minutes','Minutes','number'],['date','Date','date']].forEach(x=>{const box=noriEl('div',{class:'nori-field'});box.appendChild(noriEl('label',{text:x[1]}));let el;if(x[2]==='select'){el=noriEl('select',{});SUBJECTS.forEach(s=>el.appendChild(noriEl('option',{value:s,text:s})));if(subject)el.value=subject;}else el=noriEl('input',{type:x[2]});fields[x[0]]=el;if(x[0]==='minutes')el.value='25';if(x[0]==='date')el.value=today();box.appendChild(el);m.appendChild(box);});m.appendChild(btn('SAVE SESSION','nori-btn-primary',()=>{if(!fields.topic.value.trim()){alert('Topic is required.');return;}const arr=load('nori_study_sessions',[]);arr.push({id:uid('study'),subject:fields.subject.value,topic:fields.topic.value.trim(),minutes:Math.max(1,Number(fields.minutes.value)||25),date:fields.date.value||today(),status:'planned',createdAt:new Date().toISOString()});if(!save('nori_study_sessions',arr)){alert('Could not save.');return;}ov.remove();noriRoute();}));ov.appendChild(m);document.body.appendChild(ov);
  }

  function noriRenderExams(){
    const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});wrap.appendChild(noriRenderCommandHeader('study'));wrap.appendChild(noriRenderSuiteCrumb('Exam Center'));
    const exams=load('nori_exams',[]);const card=noriEl('section',{class:'nori-section-card'});card.appendChild(addPanelTitle('Exam Center',btn('+ EXAM','nori-btn-primary',()=>noriExamModal())));const list=noriEl('div',{class:'nori-exam-list'});const sorted=exams.slice().sort((a,b)=>String(a.date).localeCompare(String(b.date)));
    if(!sorted.length)list.appendChild(noriEl('div',{class:'nori-command-empty',text:'No exams recorded. Add real exam dates to activate preparation planning.'}));
    sorted.forEach(e=>{const row=noriEl('div',{class:'nori-exam-row'});const days=Math.ceil((new Date(e.date+'T23:59:59')-new Date())/86400000);row.appendChild(noriEl('div',{class:'nori-exam-days',text:days>=0?String(days):'—'}));const body=noriEl('div',{});body.appendChild(noriEl('strong',{text:e.subject+' — '+e.title}));body.appendChild(noriEl('small',{text:e.date+' · '+(days>=0?days+' day'+(days===1?'':'s')+' remaining':'past')}));row.appendChild(body);row.appendChild(noriEl('span',{class:'nori-state-chip '+(e.status||'planned'),text:(e.status||'planned').toUpperCase()}));row.appendChild(btn('RESULT','nori-btn-ghost',()=>route('#/meet-nori')));list.appendChild(row);});card.appendChild(list);wrap.appendChild(card);
    const prep=noriEl('section',{class:'nori-section-card'});prep.appendChild(addPanelTitle('Preparation Signals'));const lr=latestBySubject();SUBJECTS.forEach(s=>{const r=lr[s];const line=noriEl('div',{class:'nori-signal-row'});line.appendChild(noriEl('span',{text:s}));line.appendChild(noriEl('strong',{text:r?r.score+'%':'—'}));line.appendChild(noriEl('small',{text:r?(r.score<80?'Priority review':'On record'):'No evidence yet'}));prep.appendChild(line);});wrap.appendChild(prep);wrap.appendChild(noriBottomNav('study'));return wrap;
  }
  function noriExamModal(){const ov=noriEl('div',{class:'nori-modal'}),m=noriEl('div',{class:'nori-modal-card'});const h=noriEl('div',{class:'nori-modal-head'});h.appendChild(noriEl('h2',{text:'Add Exam'}));h.appendChild(btn('Close','nori-btn-ghost',()=>ov.remove()));m.appendChild(h);const f={};[['subject','Subject','select'],['title','Exam title','text'],['date','Exam date','date']].forEach(x=>{const b=noriEl('div',{class:'nori-field'});b.appendChild(noriEl('label',{text:x[1]}));let el;if(x[2]==='select'){el=noriEl('select',{});SUBJECTS.forEach(s=>el.appendChild(noriEl('option',{value:s,text:s})));}else el=noriEl('input',{type:x[2]});f[x[0]]=el;b.appendChild(el);m.appendChild(b);});m.appendChild(btn('SAVE EXAM','nori-btn-primary',()=>{if(!f.title.value.trim()||!f.date.value){alert('Title and date are required.');return;}const arr=load('nori_exams',[]);arr.push({id:uid('exam'),subject:f.subject.value,title:f.title.value.trim(),date:f.date.value,status:'planned'});save('nori_exams',arr);ov.remove();noriRoute();}));ov.appendChild(m);document.body.appendChild(ov);}

  // Tracker is the one screen that holds everything that isn't a daily
  // driver (Home) or a study action (Study): schedule, upcoming work, every
  // analytics view, merit progress, awards, and backup — consolidated here
  // instead of split across the old orphaned "Current State" route (which
  // rendered with no bottom nav at all) and this file's own tracker.
  function noriRenderTracker(){
    const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});wrap.appendChild(noriRenderCommandHeader('tracker'));wrap.appendChild(noriRenderSuiteCrumb('Tracker'));
    const results=latestResults(), avg=results.length?Math.round(results.reduce((a,r)=>a+r.score,0)/results.length):0, sessions=load('nori_study_sessions',[]), completed=sessions.filter(x=>x.status==='completed').length, active=activeConsequences();
    const top=noriEl('section',{class:'nori-section-card'});top.appendChild(addPanelTitle('Academic Tracker'));const stats=noriEl('div',{class:'nori-kpi-grid'});[['Average',avg?avg+'%':'—'],['Results',results.length],['Study sessions',completed],['Active consequences',active.length]].forEach(x=>{const k=noriEl('div',{class:'nori-kpi'});k.appendChild(noriEl('small',{text:x[0]}));k.appendChild(noriEl('strong',{text:String(x[1])}));stats.appendChild(k);});top.appendChild(stats);wrap.appendChild(top);

    // Schedule & upcoming.
    const scheduleHead=noriEl('div',{class:'nori-schedule-links'});
    scheduleHead.appendChild(btn('OPEN CALENDAR','nori-btn-ghost',()=>route('#/calendar')));
    scheduleHead.appendChild(btn('VOICE ALARMS','nori-btn-ghost',()=>route('#/alarms')));
    wrap.appendChild(noriEl('section',{class:'nori-section-card'},[addPanelTitle('Schedule',scheduleHead)]));
    if (typeof noriRenderAssignmentPanel==='function') wrap.appendChild(noriRenderAssignmentPanel());
    const exams=load('nori_exams',[]).slice().sort((a,b)=>String(a.date).localeCompare(String(b.date))).filter(e=>{const days=Math.ceil((new Date(e.date+'T23:59:59')-new Date())/86400000);return days>=-1;});
    const examCard=noriEl('section',{class:'nori-section-card'});examCard.appendChild(addPanelTitle('Upcoming Exams',btn('EXAM CENTER','nori-btn-ghost',()=>route('#/exams'))));
    const examList=noriEl('div',{class:'nori-exam-list'});
    if(!exams.length) examList.appendChild(noriEl('div',{class:'nori-command-empty',text:'No upcoming exams recorded.'}));
    exams.slice(0,5).forEach(e=>{const days=Math.ceil((new Date(e.date+'T23:59:59')-new Date())/86400000);const row=noriEl('div',{class:'nori-exam-row'});row.appendChild(noriEl('div',{class:'nori-exam-days',text:days>=0?String(days):'—'}));const body=noriEl('div',{});body.appendChild(noriEl('strong',{text:e.subject+' — '+e.title}));body.appendChild(noriEl('small',{text:e.date}));row.appendChild(body);examList.appendChild(row);});
    examCard.appendChild(examList); wrap.appendChild(examCard);

    const trend=noriEl('section',{class:'nori-section-card'});trend.appendChild(addPanelTitle('Score Trend'));trend.appendChild(noriRenderTrendSvg(results.slice(-12)));wrap.appendChild(trend);
    const by=noriEl('section',{class:'nori-section-card'});by.appendChild(addPanelTitle('Subject Snapshot'));const lb=latestBySubject();SUBJECTS.forEach(s=>{const r=lb[s];const row=noriEl('div',{class:'nori-signal-row'});row.appendChild(noriEl('span',{text:s}));const meter=noriEl('div',{class:'nori-inline-meter'});meter.appendChild(noriEl('span',{style:'width:'+(r?Math.max(0,Math.min(100,r.score)):'0')+'%'}));row.appendChild(meter);row.appendChild(noriEl('strong',{text:r?r.score+'%':'—'}));by.appendChild(row);});wrap.appendChild(by);

    // Merit / awards / backup — previously the orphaned "Current State" route.
    const meritCard=noriEl('section',{class:'nori-section-card'});meritCard.appendChild(addPanelTitle('Merit Progress'));
    const ledger=(typeof NORI_DECIDE_STATE!=='undefined'&&NORI_DECIDE_STATE&&NORI_DECIDE_STATE.meritLedger)||null;const points=ledger&&typeof ledger.balance==='number'?ledger.balance:0;
    const nextTier=points<10?10:points<25?25:points<50?50:points<100?100:150;const pct=Math.max(0,Math.min(100,Math.round((points/nextTier)*100)));
    meritCard.appendChild(noriEl('p',{class:'nori-history-line',text:points+' Merit Points · next tier at '+nextTier}));
    const meter=noriEl('div',{class:'nori-merit-meter'});const fill=noriEl('div',{class:'nori-merit-meter-fill'});fill.style.width=pct+'%';meter.appendChild(fill);meritCard.appendChild(meter);
    wrap.appendChild(meritCard);
    if (typeof noriRenderHigherAwardsCard==='function') wrap.appendChild(noriRenderHigherAwardsCard());
    if (typeof noriRenderDataBackupCard==='function') wrap.appendChild(noriRenderDataBackupCard());

    wrap.appendChild(noriBottomNav('tracker'));return wrap;
  }
  function noriRenderTrendSvg(rows){
    const box=noriEl('div',{class:'nori-trend-wrap'}); if(!rows.length){box.appendChild(noriEl('div',{class:'nori-command-empty',text:'Record results to build the trend.'}));return box;}
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 600 180');svg.setAttribute('class','nori-trend-svg');
    [20,60,100,140].forEach(y=>{const l=document.createElementNS('http://www.w3.org/2000/svg','line');l.setAttribute('x1','35');l.setAttribute('x2','590');l.setAttribute('y1',y);l.setAttribute('y2',y);l.setAttribute('class','trend-grid');svg.appendChild(l);});
    const pts=rows.map((r,i)=>{const x=40+(550*Math.min(i,rows.length-1)/Math.max(1,rows.length-1));const y=160-(Math.max(0,Math.min(100,r.score))/100*130);return [x,y];});const p=document.createElementNS('http://www.w3.org/2000/svg','polyline');p.setAttribute('points',pts.map(x=>x.join(',')).join(' '));p.setAttribute('class','trend-line');svg.appendChild(p);pts.forEach((pt,i)=>{const c=document.createElementNS('http://www.w3.org/2000/svg','circle');c.setAttribute('cx',pt[0]);c.setAttribute('cy',pt[1]);c.setAttribute('r','4');c.setAttribute('class','trend-point');c.setAttribute('title',rows[i].subject+' '+rows[i].score+'%');svg.appendChild(c);});box.appendChild(svg);const labels=noriEl('div',{class:'nori-trend-labels'});rows.forEach(r=>labels.appendChild(noriEl('span',{text:r.date+' · '+r.score+'%'})));box.appendChild(labels);return box;
  }

  function noriRenderNotifications(){
    const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});wrap.appendChild(noriRenderCommandHeader(false));wrap.appendChild(noriRenderSuiteCrumb('Notifications'));
    const card=noriEl('section',{class:'nori-section-card'});card.appendChild(addPanelTitle('Notification Center',btn('MARK ALL READ','nori-btn-ghost',()=>{const a=load('nori_notifications',[]);a.forEach(x=>x.read=true);save('nori_notifications',a);noriRoute();})));const list=noriEl('div',{class:'nori-notification-list'});const now=Date.now();const generated=[];
    assignments().filter(x=>x.status!=='done'&&x.due).forEach(x=>{const days=Math.ceil((new Date(x.due+'T23:59:59')-now)/86400000);if(days<=2)generated.push({id:'due_'+x.id,title:'Assignment due '+(days<0?'overdue':days===0?'today':'soon'),body:x.title+' · '+x.subject,date:x.due,type:'assignment'});});
    load('nori_exams',[]).forEach(x=>{const days=Math.ceil((new Date(x.date+'T23:59:59')-now)/86400000);if(days>=0&&days<=7)generated.push({id:'exam_'+x.id,title:'Exam approaching',body:x.subject+' — '+x.title,date:x.date,type:'exam'});});
    activeConsequences().forEach(x=>generated.push({id:'con_'+x.eventId+'_'+x.consequenceId,title:'Active consequence',body:x.label+(x.endsAt?' · ends '+new Date(x.endsAt).toLocaleString():''),date:x.startedAt,type:'system'}));
    const persisted=load('nori_notifications',[]);const merged=generated.concat(persisted.filter(p=>!generated.some(g=>g.id===p.id)));save('nori_notifications',merged);
    if(!merged.length)list.appendChild(noriEl('div',{class:'nori-command-empty',text:'No notifications. Nori will surface due dates and active system events here.'}));merged.slice().reverse().forEach(x=>{const r=noriEl('div',{class:'nori-notification-row '+(x.read?'read':'unread')});r.appendChild(noriEl('div',{class:'nori-notification-mark',text:x.read?'':'•'}));const b=noriEl('div',{});b.appendChild(noriEl('strong',{text:x.title}));b.appendChild(noriEl('small',{text:x.body+' · '+(x.date||'')}));r.appendChild(b);r.appendChild(btn(x.read?'READ':'ACK','nori-btn-ghost',()=>{x.read=true;save('nori_notifications',merged);noriRoute();}));list.appendChild(r);});card.appendChild(list);wrap.appendChild(card);wrap.appendChild(noriBottomNav('profile'));return wrap;
  }

  function noriRenderProfile(){
    const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});wrap.appendChild(noriRenderCommandHeader('profile'));wrap.appendChild(noriRenderSuiteCrumb('Profile'));
    const results=latestResults(), active=activeConsequences(), ledger=(typeof NORI_DECIDE_STATE!=='undefined'&&NORI_DECIDE_STATE&&NORI_DECIDE_STATE.meritLedger)||null,points=ledger&&typeof ledger.balance==='number'?ledger.balance:0;
    const card=noriEl('section',{class:'nori-section-card nori-profile-card'});card.appendChild(addPanelTitle('Profile'));const identity=noriEl('div',{class:'nori-profile-identity'});identity.appendChild(noriEl('img',{src:'assets/nori-emblem.png',alt:'Nori emblem'}));const idt=noriEl('div',{});idt.appendChild(noriEl('strong',{text:'NORI USER'}));idt.appendChild(noriEl('small',{text:'Personal academic command system'}));identity.appendChild(idt);card.appendChild(identity);const grid=noriEl('div',{class:'nori-kpi-grid'});[['Results',results.length],['Average',results.length?Math.round(results.reduce((a,r)=>a+r.score,0)/results.length)+'%':'—'],['Merit',points],['Active',active.length]].forEach(x=>{const k=noriEl('div',{class:'nori-kpi'});k.appendChild(noriEl('small',{text:x[0]}));k.appendChild(noriEl('strong',{text:String(x[1])}));grid.appendChild(k);});card.appendChild(grid);wrap.appendChild(card);
    const links=noriEl('section',{class:'nori-section-card'});links.appendChild(addPanelTitle('System'));[['Calendar','#/calendar'],['Voice Alarms','#/alarms'],['Tracker','#/progress'],['Exam Center','#/exams'],['Verification','#/verification'],['Notifications','#/notifications'],['Meet Nori','#/meet-nori'],['Phase Forms','#/phases'],['Active Consequences','#/consequences'],['Adaptive Command','#/command'],['Academic Diagnostic','#/diagnostic'],['System Timeline','#/timeline'],['Integration Audit','#/smart-integrity']].forEach(x=>links.appendChild(noriEl('a',{class:'nori-system-link',href:x[1]},[noriEl('span',{text:x[0]}),noriEl('span',{text:'→'})])));wrap.appendChild(links);
    const offline=navigator.onLine?'ONLINE':'OFFLINE';const st=noriEl('section',{class:'nori-section-card nori-system-health'});st.appendChild(addPanelTitle('System Health'));st.appendChild(noriEl('div',{class:'nori-health-row',text:'Network: '+offline}));st.appendChild(noriEl('div',{class:'nori-health-row',text:'Local storage: '+(storageAvailable()?'READY':'UNAVAILABLE')}));st.appendChild(noriEl('div',{class:'nori-health-row',text:'Brain bridge: '+(typeof noriBrainEngine!=='undefined'?'LOADED':'UNAVAILABLE')}));st.appendChild(btn('BACKUP DATA','nori-btn-ghost',()=>{if(typeof noriDownloadBackup==='function')noriDownloadBackup();}));wrap.appendChild(st);wrap.appendChild(noriBottomNav('profile'));return wrap;
  }
  function storageAvailable(){try{const k='__nori_test';localStorage.setItem(k,'1');localStorage.removeItem(k);return true;}catch(e){return false;}}
  function noriRenderSuiteCrumb(label){return noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:label}]);}

  function noriRenderNoriBrief(){
    const s=noriRenderTodayLive(), card=noriEl('section',{class:'nori-section-card nori-brief-card'});card.appendChild(addPanelTitle('Nori Brief'));card.appendChild(noriEl('p',{class:'nori-brief-main',text:s.text}));const row=noriEl('div',{class:'nori-brief-grid'});row.appendChild(noriEl('div',{text:'Latest result: '+(s.latest?s.latest.subject+' '+s.latest.score+'%':'None')}));row.appendChild(noriEl('div',{text:'Open assignments: '+assignments().filter(x=>x.status!=='done').length}));row.appendChild(noriEl('div',{text:'Active consequences: '+s.active.length}));card.appendChild(row);card.appendChild(btn('ASK NORI','nori-btn-primary',()=>route('#/meet-nori')));return card;
  }
  window.noriRenderStudy=noriRenderStudy;window.noriRenderExams=noriRenderExams;window.noriRenderTracker=noriRenderTracker;window.noriRenderProfile=noriRenderProfile;window.noriRenderNotifications=noriRenderNotifications;window.noriRenderVerification=noriRenderVerification;window.noriRenderNoriBrief=noriRenderNoriBrief;
  window.noriSuiteBoot=function(){
    window.addEventListener('online',()=>{if(location.hash==='#/profile')noriRoute();});
    window.addEventListener('offline',()=>{if(location.hash==='#/profile')noriRoute();});
  };
})();
if (typeof noriSuiteBoot === 'function') noriSuiteBoot();
