# Nori Calendar

The Calendar is an additive layer around the existing Nori systems. It does not replace assignment, exam, recovery, study, consequence, or Phase storage.

## Automatically indexed
- Assignments and due dates
- Exams
- Study sessions
- Active consequences
- Recorded brain decision events involving consequences

## Manual events
Manual calendar events are persisted under `nori_calendar_events_v1` and included automatically in Nori backups because the storage key uses the `nori_` prefix.

## Repetition
Manual events support: once, daily, weekdays, weekly (with selected days), monthly, and every N days. A series can have an end date or maximum occurrence count.

## Event memory
A skipped occurrence is remembered as an exception without deleting the rest of a recurring series. Completed occurrences are also remembered.

## Recovery
The RECOVER screen can schedule a recovery session for the whole backlog or a specific subject. Recovery scheduling is a calendar event; it does not create or alter a disciplinary breach.
