/* ==========================================================================
   NORI PHASE — AI CHECK-IN (CLIENT)
   ==========================================================================
   A floating "Check-In" button, available on every screen. Tap it, say
   whether you studied (subject / topic / how it went), and it:
     1. transcribes your voice (noriListenOnce, from nori-native-bridge.js —
        works on both web and the native Android app),
     2. sends the transcript to the AI backend (api/checkin.js),
     3. reads back what it understood and asks you to confirm — by voice
        or by tapping,
     4. on confirmation, saves the entry into the correct table-log form(s)
        using the exact same storage functions the forms themselves use
        (noriStorageKey / noriLoadEntries / noriSaveEntries from
        nori-storage.js), so history and manual entry stay in sync.

   noriListenOnce / noriSpeak / NORI_SPEECH_SUPPORTED now live in
   nori-native-bridge.js (load that before this file) — single shared
   implementation instead of a separate copy in every file that needs
   speech, same principle as the storage-layer consolidation.

   CONFIGURE THIS ONE LINE before deploying:
   ========================================================================== */
const NORI_AI_ENDPOINT = NORI_API_BASE_URL + "/api/checkin"; // base URL set once in nori-native-bridge.js

/* ========================================================================== */

/* ---------------------------- MODAL UI ---------------------------- */

function noriCheckinBuildModal() {
  const overlay = noriEl("div", { class: "nori-checkin-overlay" });
  const modal = noriEl("div", { class: "nori-checkin-modal" });
  overlay.appendChild(modal);

  const title = noriEl("h2", { class: "nori-panel-title", text: "Voice Check-In" });
  const status = noriEl("p", { class: "nori-checkin-status", text: "Tap the mic and say what you studied." });
  const transcriptBox = noriEl("p", { class: "nori-checkin-transcript" });
  const actions = noriEl("div", { class: "nori-checkin-actions" });
  const resultBox = noriEl("div", { class: "nori-checkin-result" });
  const closeBtn = noriEl("button", { class: "nori-btn nori-btn-ghost nori-checkin-close", text: "Close" });

  modal.appendChild(closeBtn);
  modal.appendChild(title);
  modal.appendChild(status);
  modal.appendChild(transcriptBox);
  modal.appendChild(actions);
  modal.appendChild(resultBox);

  closeBtn.addEventListener("click", function () {
    window.speechSynthesis && window.speechSynthesis.cancel();
    overlay.remove();
  });

  return { overlay: overlay, status: status, transcriptBox: transcriptBox, actions: actions, resultBox: resultBox };
}

function noriCheckinRenderEntry(entry) {
  const phase = noriFindPhase(entry.phaseId);
  const system = phase && noriFindSystem(phase, entry.systemId);
  const form = system && noriFindForm(system, entry.formId);
  const wrap = noriEl("div", { class: "nori-checkin-entry-preview" });
  wrap.appendChild(noriEl("div", { class: "nori-checkin-entry-title", text: (form ? form.title : entry.formId) }));
  const cols = form ? form.columns : [];
  Object.keys(entry.row || {}).forEach(function (key) {
    const val = entry.row[key];
    if (!val) return;
    const col = cols.find(function (c) { return c.key === key; });
    wrap.appendChild(noriEl("p", { class: "nori-history-line", text: (col ? col.label : key) + ": " + val }));
  });
  return wrap;
}

function noriCheckinSaveEntries(entries) {
  entries.forEach(function (entry) {
    const key = noriStorageKey(entry.phaseId, entry.systemId, entry.formId);
    const existing = noriLoadEntries(key);
    existing.push(entry.row);
    noriSaveEntries(key, existing);
  });
  // If the form currently on screen just changed, refresh it.
  noriRoute();
}

async function noriCheckinRunFlow(ui) {
  let transcript;
  try {
    ui.status.textContent = "Listening\u2026";
    transcript = await noriListenOnce();
  } catch (err) {
    if (err.message === "no-speech-api") {
      // Fallback: typed input for browsers without SpeechRecognition.
      ui.status.textContent = "Voice input isn't supported in this browser \u2014 type instead.";
      const input = noriEl("input", { type: "text", class: "nori-checkin-typed", placeholder: "e.g. studied physics, momentum, went okay" });
      const submitBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "Submit" });
      ui.actions.appendChild(input);
      ui.actions.appendChild(submitBtn);
      transcript = await new Promise(function (resolve) {
        submitBtn.addEventListener("click", function () { resolve(input.value.trim()); });
      });
      ui.actions.innerHTML = "";
    } else {
      ui.status.textContent = "Didn't catch that \u2014 tap the mic to try again.";
      const retryBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "\ud83c\udf99\ufe0f Try again" });
      ui.actions.appendChild(retryBtn);
      retryBtn.addEventListener("click", function () { ui.actions.innerHTML = ""; noriCheckinRunFlow(ui); });
      return;
    }
  }

  if (!transcript) {
    ui.status.textContent = "Nothing recorded \u2014 tap the mic to try again.";
    const retryBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "\ud83c\udf99\ufe0f Try again" });
    ui.actions.appendChild(retryBtn);
    retryBtn.addEventListener("click", function () { ui.actions.innerHTML = ""; noriCheckinRunFlow(ui); });
    return;
  }

  ui.transcriptBox.textContent = "\u201c" + transcript + "\u201d";
  ui.status.textContent = "Thinking\u2026";

  let data;
  try {
    const resp = await fetch(NORI_AI_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ transcript: transcript })
    });
    if (!resp.ok) throw new Error("Backend returned " + resp.status);
    data = await resp.json();
  } catch (err) {
    ui.status.textContent = "Couldn't reach the AI backend. Check that it's deployed and NORI_AI_ENDPOINT is correct.";
    return;
  }

  if (!data.entries || data.entries.length === 0) {
    const msg = data.summary || "I couldn't tell what to save from that \u2014 try adding the subject and how it went.";
    ui.status.textContent = msg;
    noriSpeak(msg);
    const retryBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "\ud83c\udf99\ufe0f Try again" });
    ui.actions.appendChild(retryBtn);
    retryBtn.addEventListener("click", function () { ui.actions.innerHTML = ""; ui.transcriptBox.textContent = ""; noriCheckinRunFlow(ui); });
    return;
  }

  ui.status.textContent = data.summary || "Here's what I understood \u2014 confirm to save.";
  noriSpeak((data.summary || "Here's what I understood.") + " Say yes to save, or no to cancel.");

  data.entries.forEach(function (entry) { ui.resultBox.appendChild(noriCheckinRenderEntry(entry)); });

  const confirmBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "\u2713 Save" });
  const cancelBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "\u2717 Cancel" });
  ui.actions.appendChild(confirmBtn);
  ui.actions.appendChild(cancelBtn);

  confirmBtn.addEventListener("click", function () {
    noriCheckinSaveEntries(data.entries);
    ui.status.textContent = "Saved.";
    noriSpeak("Saved.");
    ui.actions.innerHTML = "";
  });
  cancelBtn.addEventListener("click", function () {
    ui.status.textContent = "Not saved.";
    ui.resultBox.innerHTML = "";
    ui.actions.innerHTML = "";
  });

  // Optional voice confirmation: listen once more for "yes"/"no".
  if (NORI_SPEECH_SUPPORTED) {
    noriListenOnce().then(function (said) {
      const lower = said.toLowerCase();
      if (lower.indexOf("yes") !== -1) confirmBtn.click();
      else if (lower.indexOf("no") !== -1) cancelBtn.click();
    }).catch(function () { /* ignore — tap buttons still work */ });
  }
}

function noriCheckinOpen() {
  const ui = noriCheckinBuildModal();
  document.body.appendChild(ui.overlay);
  noriCheckinRunFlow(ui);
}

function noriCheckinMountButton() {
  const btn = noriEl("button", { class: "nori-checkin-fab", text: "\ud83c\udf99\ufe0f Check-In" });
  btn.addEventListener("click", noriCheckinOpen);
  document.body.appendChild(btn);
}

window.addEventListener("DOMContentLoaded", noriCheckinMountButton);
