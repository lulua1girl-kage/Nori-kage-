/* NORI SMART CORE — additive intelligence layer.
   Turns existing records into explainable planning, diagnosis, scheduling,
   timeline, integrity checks and recovery suggestions. No destructive resets. */
(function(){
  'use strict';
  const K={plan:'nori_smart_plan_v1',diag:'nori_smart_diagnostic_v1',timeline:'nori_smart_timeline_v1',settings:'nori_smart_settings_v1'};
  const load=(k,fb)=>{try{const v=JSON.parse(localStorage.getItem(k)||'null');return v==null?fb:v}catch(e){return fb}};
  const save=(k,v)=>{try{if(typeof noriSafeWrite==='function')return noriSafeWrite(k,v);localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}};
  const iso=()=>new Date().toISOString(), day=()=>iso().slice(0,10), uid=p=>p+'_'+Date.now()+'_'+Math.random().toString(36).slice(2,7);
  const subjects=()=>typeof NORI_MEET_SUBJECTS!=='undefined'?NORI_MEET_SUBJECTS:['Mathematics','Physics','Chemistry','Biology','English','Agriculture','Web Development','Information Technology'];
  function results(){const all=typeof noriHistoryLoadAll==='function'?noriHistoryLoadAll():{};const a=[];Object.keys(all||{}).forEach(s=>(all[s]||[]).forEach(r=>{if(typeof r.score==='number')a.push({subject:s,score:Number(r.score),date:r.date||day(),id:r.id||null})}));return a.sort((a,b)=>String(a.date).localeCompare(String(b.date)))}
  const assignments=()=>typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():load('nori_command_assignments',[]);
  const exams=()=>load('nori_exams',[]), sessions=()=>load('nori_study_sessions',[]);
  const consequences=()=>typeof noriActiveConsequences==='function'?noriActiveConsequences():[];
  function latestBySubject(){const o={};results().forEach(r=>o[r.subject]=r);return o}
  function avg(arr){return arr.length?arr.reduce((a,b)=>a+b.score,0)/arr.length:null}
  function diagnosis(){
    const rs=results(), by=latestBySubject(), ex=exams(), as=assignments(), ss=sessions();
    const out=[];
    subjects().forEach(s=>{
      const r=by[s], hist=rs.filter(x=>x.subject===s).slice(-4), upcoming=ex.filter(e=>e.subject===s&&e.date>=day()).sort((a,b)=>a.date.localeCompare(b.date))[0], open=as.filter(a=>a.subject===s&&a.status!=='done'), completed=ss.filter(x=>x.subject===s&&x.status==='completed').length;
      if(!r){out.push({subject:s,score:null,trend:'unknown',priority:20,reason:'No recorded result; evidence gap.',method:'baseline session'});return}
      const prev=hist.length>1?hist[hist.length-2].score:null, trend=prev==null?'baseline':r.score>prev+2?'improving':r.score<prev-2?'declining':'stable';
      let priority=(100-r.score)*0.9 + Math.min(25,open.length*5)+(upcoming?25:0)-(completed>3?5:0);
      let method=r.score<60?'concept rebuild':r.score<75?'guided practice':r.score<85?'targeted problems':'retrieval + exam simulation';
      if(trend==='declining')priority+=10;
      out.push({subject:s,score:r.score,trend,priority:Math.round(priority),reason:(r.score<80?'performance below target; ':'')+(trend==='declining'?'recent decline; ':'')+(open.length?'open responsibility; ':'')+(upcoming?'exam approaching':'no immediate exam signal'),method});
    });
    out.sort((a,b)=>b.priority-a.priority);const model={generatedAt:iso(),overall:avg(rs),subjects:out,top:out.slice(0,3)};save(K.diag,model);return model;
  }
  function workload(){const a=assignments().filter(x=>x.status!=='done'), s=sessions().filter(x=>x.status!=='completed'), overdue=a.filter(x=>x.due&&x.due<day());return {open:a.length,overdue:overdue.length,plannedSessions:s.length,load:a.length+s.length*0.7}}
  function nextDays(n){const out=[];const d=new Date();for(let i=0;i<n;i++){const x=new Date(d);x.setDate(d.getDate()+i);out.push(x.toISOString().slice(0,10))}return out}
  function estimateMinutes(item){if(Number(item.minutes)>0)return Number(item.minutes);const title=String(item.title||item.topic||'');return Math.max(25,Math.min(90,25+Math.ceil(title.length/30)*10))}
  function buildPlan(){
    const d=diagnosis(), w=workload(), as=assignments().filter(x=>x.status!=='done'), ex=exams().filter(x=>x.date>=day()).sort((a,b)=>a.date.localeCompare(b.date)), ss=sessions().filter(x=>x.status!=='completed');
    const pool=[];d.top.forEach((x,i)=>{pool.push({kind:'study',subject:x.subject,topic:'Priority work — '+x.method,minutes:x.score==null?25:x.score<70?45:35,priority:x.priority+20-i*2,why:x.reason})});
    as.forEach(x=>pool.push({kind:'assignment',id:x.id,subject:x.subject||'Academic',topic:x.title,minutes:estimateMinutes(x),priority:(x.due&&x.due<day()?100:70)+(x.due===day()?25:0),why:x.due&&x.due<day()?'overdue responsibility':'due responsibility'}));
    ss.forEach(x=>pool.push({kind:'study',id:x.id,subject:x.subject,topic:x.topic,minutes:estimateMinutes(x),priority:55,why:'planned session'}));
    ex.slice(0,4).forEach(x=>pool.push({kind:'exam',subject:x.subject,topic:'Prepare: '+x.title,minutes:40,priority:80,why:'exam on '+x.date}));
    pool.sort((a,b)=>b.priority-a.priority);const days=nextDays(7), plan=[];let used=0;
    days.forEach((date,di)=>{let cap=di===0?120:90;pool.filter(x=>!x._placed).forEach(x=>{if(used>=8)return;if(cap>=x.minutes){x._placed=true;plan.push(Object.assign({},x,{date,slot:plan.filter(p=>p.date===date).length+1}));cap-=x.minutes;used++}})});
    const result={generatedAt:iso(),window:days,capacityRule:'soft cap 120 minutes today / 90 minutes future day',load:w,items:plan,unplaced:pool.filter(x=>!x._placed).map(x=>({subject:x.subject,topic:x.topic,priority:x.priority,why:x.why}))};save(K.plan,result);return result;
  }
  function recordPlanToSessions(plan){const ss=sessions();let added=0;plan.items.filter(x=>x.kind==='study'&&x.id==null).forEach(x=>{ss.push({id:uid('smartstudy'),subject:x.subject,topic:x.topic,minutes:x.minutes,date:x.date,status:'planned',source:'smart-command',createdAt:iso()});added++});if(added)save('nori_study_sessions',ss);return added}
  function timeline(){const out=[];results().forEach(x=>out.push({at:x.date+'T12:00:00',type:'result',title:x.subject+' result',detail:x.score+'%'}));assignments().forEach(x=>out.push({at:(x.due||x.createdAt||day())+'T09:00:00',type:'assignment',title:x.title,detail:(x.status||'open')+' · '+(x.subject||'Academic')}));exams().forEach(x=>out.push({at:x.date+'T09:00:00',type:'exam',title:x.subject+' — '+x.title,detail:'exam'}));sessions().forEach(x=>out.push({at:(x.date||day())+'T'+(x.time||'12:00')+':00',type:'study',title:x.subject+' — '+x.topic,detail:(x.status||'planned')+' · '+(x.minutes||0)+' min'}));consequences().forEach(x=>out.push({at:x.startedAt||iso(),type:'system',title:x.label||'Consequence',detail:'active'}));return out.sort((a,b)=>String(b.at).localeCompare(String(a.at))).slice(0,100)}
  function integrity(){
    const checks=[];const ls=(()=>{try{localStorage.setItem('__nori_integrity','1');localStorage.removeItem('__nori_integrity');return 'CLEAR'}catch(e){return 'DEGRADED'}})();checks.push(['Local persistence',ls,'Core records need writable storage.']);
    checks.push(['Brain bridge',typeof noriBrainEngine!=='undefined'?'CLEAR':'DEGRADED','Brain engine '+(typeof noriBrainEngine!=='undefined'?'loaded':'missing')+'.']);
    checks.push(['Result history',typeof noriHistoryLoadAll==='function'?'CLEAR':'DEGRADED','Academic history interface '+(typeof noriHistoryLoadAll==='function'?'available':'missing')+'.']);
    const aa=assignments();checks.push(['Assignment IDs',aa.every(x=>x.id)?'CLEAR':'DEGRADED',aa.filter(x=>!x.id).length+' assignment record(s) without IDs.']);
    const ss=sessions();checks.push(['Study sessions',ss.every(x=>x.subject&&x.topic)?'CLEAR':'DEGRADED',ss.filter(x=>!x.subject||!x.topic).length+' malformed session(s).']);
    checks.push(['Calendar',window.noriCalendar&&typeof noriCalendar.allOccurrences==='function'?'CLEAR':'DEGRADED','Calendar integration '+(window.noriCalendar?'available':'missing')+'.']);
    checks.push(['Voice',typeof noriSpeak==='function'?'CLEAR':'DEGRADED','Speech layer '+(typeof noriSpeak==='function'?'available':'missing')+'.']);
    checks.push(['Notifications',typeof noriKageGenerateNotifications==='function'?'CLEAR':'DEGRADED','Notification generator '+(typeof noriKageGenerateNotifications==='function'?'available':'missing')+'.']);
    return checks.map(x=>({name:x[0],state:x[1],detail:x[2]}));
  }
  function smartMessage(){const d=diagnosis(),w=workload(),top=d.top[0];if(consequences().length)return ['RECOVERY FIRST','An active consequence exists. Resolve the recovery path before adding workload.'];if(w.overdue)return ['REASSESS','There are '+w.overdue+' overdue responsibilities. Nori is protecting priority rather than stacking everything into today.'];if(top&&top.score!=null)return ['NEXT BEST ACTION',top.subject+' — '+top.method+'. Current evidence: '+top.score+'%.'];if(top)return ['EVIDENCE GAP','No result is recorded for '+top.subject+'. A short baseline session will create useful evidence.'];return ['STABLE','No high-confidence priority is available from current records.'];}
  function command(){const p=buildPlan();recordPlanToSessions(p);if(typeof noriKageGenerateNotifications==='function')noriKageGenerateNotifications();if(typeof noriKageAfterRoute==='function'&&document.getElementById('nori-app')){}return p}
  function renderCommand(){const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});if(typeof noriRenderCommandHeader==='function')wrap.appendChild(noriRenderCommandHeader(false));wrap.appendChild(noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:'Daily Command'}]));const m=smartMessage();const msg=noriEl('section',{class:'nori-kage-message'});msg.appendChild(noriEl('div',{class:'nori-kage-message-label',text:m[0]}));msg.appendChild(noriEl('div',{class:'nori-kage-message-text',text:m[1]}));wrap.appendChild(msg);
    const p=buildPlan(),w=p.load,d=p;const top=noriEl('section',{class:'nori-section-card'});top.appendChild(noriEl('div',{class:'nori-section-head'},[noriEl('h2',{text:"TODAY'S COMMAND"}),noriEl('span',{text:'SMART / EXPLAINABLE'})]));top.appendChild(noriEl('div',{class:'nori-kpi-grid'},[['Open',w.open],['Overdue',w.overdue],['Planned sessions',w.plannedSessions],['Plan items',p.items.filter(x=>x.date===day()).length]].map(x=>{const k=noriEl('div',{class:'nori-kpi'});k.appendChild(noriEl('small',{text:x[0]}));k.appendChild(noriEl('strong',{text:String(x[1])}));return k})));const actions=noriEl('div',{class:'nori-inline-actions'});const regen=noriEl('button',{class:'nori-btn nori-btn-primary',text:'REBUILD COMMAND'});regen.onclick=()=>{buildPlan();noriRoute()};actions.appendChild(regen);const commit=noriEl('button',{class:'nori-btn nori-btn-ghost',text:'ADD STUDY ITEMS'});commit.onclick=()=>{const n=recordPlanToSessions(p);if(n)alert(n+' study item(s) added.');noriRoute()};actions.appendChild(commit);top.appendChild(actions);wrap.appendChild(top);
    const list=noriEl('section',{class:'nori-section-card'});list.appendChild(noriEl('div',{class:'nori-section-head'},[noriEl('h2',{text:'PLAN'})]));const rows=noriEl('div',{class:'nori-verification-list'});p.items.slice(0,20).forEach(x=>{const r=noriEl('div',{class:'nori-verification-row'});const l=noriEl('div',{});l.appendChild(noriEl('strong',{text:x.date+' · '+x.subject}));l.appendChild(noriEl('small',{text:x.topic+' · '+x.minutes+' min · '+x.why}));r.appendChild(l);r.appendChild(noriEl('span',{class:'nori-state-chip planned',text:'P'+x.priority}));rows.appendChild(r)});if(!p.items.length)rows.appendChild(noriEl('div',{class:'nori-command-empty',text:'No plan items can be generated from current evidence.'}));list.appendChild(rows);wrap.appendChild(list);wrap.appendChild(noriBottomNav('home'));return wrap}
  function renderDiagnostic(){
    const d=diagnosis(); const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});
    wrap.appendChild(noriRenderCommandHeader(false));
    wrap.appendChild(noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:'Diagnostic'}]));
    const card=noriEl('section',{class:'nori-section-card'});
    const head=noriEl('div',{class:'nori-section-head'}); head.appendChild(noriEl('h2',{text:'ACADEMIC DIAGNOSTIC'})); head.appendChild(noriEl('span',{text:d.overall==null?'NO BASELINE':Math.round(d.overall)+'%'})); card.appendChild(head);
    d.subjects.forEach(x=>{const r=noriEl('div',{class:'nori-integrity-row '+(x.priority>80?'bad':'')});r.appendChild(noriEl('strong',{text:x.subject}));r.appendChild(noriEl('span',{text:x.score==null?'NO DATA':x.score+'%'}));r.appendChild(noriEl('small',{text:x.method+' · '+x.trend+' · priority '+x.priority+' · '+x.reason}));card.appendChild(r)});
    wrap.appendChild(card); wrap.appendChild(noriBottomNav('tracker')); return wrap;
  }
  function renderTimeline(){
    const rows=timeline(),wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'}); wrap.appendChild(noriRenderCommandHeader(false));
    wrap.appendChild(noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:'Timeline'}]));
    const card=noriEl('section',{class:'nori-section-card'}); const head=noriEl('div',{class:'nori-section-head'}); head.appendChild(noriEl('h2',{text:'SYSTEM TIMELINE'})); head.appendChild(noriEl('span',{text:rows.length+' records'})); card.appendChild(head);
    const list=noriEl('div',{class:'nori-inbox-list'}); rows.forEach(x=>{const r=noriEl('div',{class:'nori-inbox-row'});r.appendChild(noriEl('div',{class:'nori-inbox-time',text:new Date(x.at).toLocaleString()}));r.appendChild(noriEl('strong',{text:x.title}));r.appendChild(noriEl('p',{text:x.detail}));r.appendChild(noriEl('small',{text:x.type}));list.appendChild(r)});
    if(!rows.length)list.appendChild(noriEl('div',{class:'nori-command-empty',text:'No historical events recorded yet.'})); card.appendChild(list); wrap.appendChild(card); wrap.appendChild(noriBottomNav('profile')); return wrap;
  }
  function renderIntegrity(){
    const checks=integrity(),wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'}); wrap.appendChild(noriRenderCommandHeader(false));
    wrap.appendChild(noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:'Integration Audit'}]));
    const card=noriEl('section',{class:'nori-section-card'}); const head=noriEl('div',{class:'nori-section-head'}); head.appendChild(noriEl('h2',{text:'INTEGRATION AUDIT'})); card.appendChild(head);
    checks.forEach(x=>{const r=noriEl('div',{class:'nori-integrity-row '+(x.state!=='CLEAR'?'bad':'')});r.appendChild(noriEl('strong',{text:x.name}));r.appendChild(noriEl('span',{text:x.state}));r.appendChild(noriEl('small',{text:x.detail}));card.appendChild(r)}); wrap.appendChild(card);
    const b=noriEl('section',{class:'nori-section-card'}); const bh=noriEl('div',{class:'nori-section-head'}); bh.appendChild(noriEl('h2',{text:'SMART ENGINE STATUS'})); b.appendChild(bh); b.appendChild(noriEl('p',{class:'nori-kage-copy',text:'Planning, diagnosis, scheduling, timeline and integrity analysis are derived from existing records. Nori explains decisions; Human Override remains available.'})); b.appendChild(noriEl('a',{class:'nori-system-link',href:'#/integrity',text:'Open governing integrity layer →'})); wrap.appendChild(b); wrap.appendChild(noriBottomNav('profile')); return wrap;
  }
  window.noriSmart={diagnosis,buildPlan,command,timeline,integrity,smartMessage,recordPlanToSessions};window.noriRenderDailyCommand=renderCommand;window.noriRenderDiagnostic=renderDiagnostic;window.noriRenderTimeline=renderTimeline;window.noriRenderSmartIntegrity=renderIntegrity;
})();
