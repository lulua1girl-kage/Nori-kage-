# Smart Alarm — 2026-09-15

- Added real alarm-channel sound configuration for Android scheduled notifications.
- Added local foreground ring before spoken alarm briefing.
- Added alarm session state machine and persistent alarm history.
- Added time-of-day greeting and explicit reason for the contact.
- Added confirmation gate before the related briefing.
- Added wait/reschedule choices: 5, 10, 15 minutes.
- Recurring alarms keep their original recurrence when a single ringing instance is delayed.
- Added busy/context/Human Override branches.
- Added native background voice speech-event handoff when the opt-in NoriVoice service is active.
- Fixed alarm due-time comparison to use the device's local clock rather than UTC.
