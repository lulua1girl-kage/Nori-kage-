/* NORI BRAIN V10 — unified state, evidence, decision, memory, safety and affect layer.
   Additive: existing engines remain authoritative for their domains. This layer coordinates them.
   Local-first. No diagnosis. No sensitive-data leverage. No hidden body/health surveillance. */
(function(g){'use strict';
  var K={memory:'nori_brain_memory_v10',events:'nori_brain_events_v10',state:'nori_brain_state_v10',prefs:'nori_brain_prefs_v10',affect:'nori_brain_affect_v10'};
  var SECRET=/\b(sk-[A-Za-z0-9_-]{12,}|ghp_[A-Za-z0-9_]+|AIza[\w-]+|Bearer\s+\S+|password\s*=|token\s*=|secret\s*=)\b/i;
  var SENSITIVE=/(password|passcode|pin|api key|secret|token|bank|credit card|card number|address|location|medical|diagnos|medication|trauma|abuse|self[- ]?harm|suicide|sexual|private|family conflict|legal case)/i;
  var now=function(){return new Date().toISOString()};
  function load(k,fb){try{var x=JSON.parse(localStorage.getItem(k)||'null');return x==null?fb:x}catch(e){return fb}}
  function save(k,v){try{if(typeof noriSafeWrite==='function')return noriSafeWrite(k,v);localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function uid(p){return p+'_'+Date.now()+'_'+Math.random().toString(36).slice(2,8)}
  function safeText(x){return String(x||'').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g,'').trim()}
  function redact(text){var s=safeText(text); if(SECRET.test(s))return '[redacted credential]'; return s}
  function memoryRows(){
    var rows=load(K.memory,[]).filter(function(m){return m&&typeof m.text==='string'});
    try{
      if(typeof noriMemoryLoad==='function'){
        var legacy=noriMemoryLoad();
        (legacy&&legacy.items||[]).forEach(function(m){
          if(!m||typeof m.text!=='string')return;
          if(!rows.some(function(x){return x.text===m.text}))rows.push({id:m.id||uid('legacy'),text:m.text,source:m.source||'legacy_confirmed',createdAt:m.date||now(),updatedAt:m.date||now(),importance:3,scope:'user'});
        });
      }
    }catch(e){}
    return rows;
  }
  function memoryPolicy(text,source,scope){var t=redact(text); if(!t||SECRET.test(t))return {allow:false,reason:'secret'}; if(SENSITIVE.test(t))return {allow:false,reason:'sensitive'}; return {allow:true,reason:'durable user-stated preference/fact',scope:scope||'user',source:source||'confirmed'} }
  function addMemory(text,meta){var p=memoryPolicy(text,meta&&meta.source,meta&&meta.scope);if(!p.allow)return {ok:false,reason:p.reason};var rows=memoryRows();var norm=t=>t.toLowerCase().replace(/\s+/g,' ').trim();var n=norm(text);if(rows.some(function(x){return norm(x.text)===n}))return {ok:true,duplicate:true,item:rows.find(function(x){return norm(x.text)===n})};var item={id:uid('mem'),text:safeText(text),source:(meta&&meta.source)||'user_confirmed',createdAt:now(),updatedAt:now(),importance:Math.max(1,Math.min(5,Number(meta&&meta.importance)||3)),scope:'user'};rows.push(item);save(K.memory,rows.slice(-300));return {ok:true,item:item}}
  function removeMemory(id){var rows=memoryRows().filter(function(x){return x.id!==id});save(K.memory,rows);return rows}
  function recall(query,limit){var q=safeText(query).toLowerCase();var terms=q.split(/\W+/).filter(Boolean);return memoryRows().map(function(m){var t=m.text.toLowerCase();var score=terms.reduce(function(n,w){return n+(t.indexOf(w)>=0?1:0)},0)+((m.importance||3)/10);return {m:m,score:score}}).filter(function(x){return x.score>0}).sort(function(a,b){return b.score-a.score}).slice(0,limit||8).map(function(x){return x.m})}
  function recentSensitiveMemory(){return []}
  function publicVoiceMemory(query){return recall(query,8).filter(function(m){return !SENSITIVE.test(m.text)&&!SECRET.test(m.text)}).map(function(m){return m.text})}
  function currentTime(){var d=new Date();return {iso:d.toISOString(),hour:d.getHours(),minute:d.getMinutes(),date:d.toISOString().slice(0,10)}}
  function collectRawState(){
    var out={time:currentTime()};
    try{out.results=typeof noriHistoryLoadAll==='function'?noriHistoryLoadAll():{};}catch(e){out.results={}}
    try{out.assignments=typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():load('nori_command_assignments',[])}catch(e){out.assignments=[]}
    try{out.exams=typeof noriExamsLoad==='function'?noriExamsLoad():load('nori_exams',[])}catch(e){out.exams=[]}
    try{out.sessions=typeof noriStudySessionsLoad==='function'?noriStudySessionsLoad():load('nori_study_sessions',[])}catch(e){out.sessions=[]}
    try{out.context=typeof noriGetProtectionContext==='function'?noriGetProtectionContext():{mode:'normal'}}catch(e){out.context={mode:'normal'}}
    try{out.consequences=typeof noriActiveConsequences==='function'?noriActiveConsequences():[]}catch(e){out.consequences=[]}
    return out;
  }
  function evidence(state){
    var ev=[];
    Object.keys(state.results||{}).forEach(function(s){
      var a=state.results[s]||[];
      if(a.length){var r=a[a.length-1]; if(typeof r.score==='number') ev.push({kind:'observed_result',subject:s,value:r.score,date:r.date||null,confidence:1,source:'result-history'});}
    });
    (state.assignments||[]).forEach(function(a){if(a.status!=='done')ev.push({kind:'open_assignment',subject:a.subject||'Academic',value:a.title,due:a.due||null,confidence:1,source:'assignment'});});
    (state.exams||[]).forEach(function(e){ev.push({kind:'exam',subject:e.subject||'Academic',value:e.title,date:e.date,confidence:1,source:'exam-calendar'});});
    (state.sessions||[]).forEach(function(s){
      if(s.status==='active'||s.status==='in_progress')ev.push({kind:'active_study',subject:s.subject,value:s.topic,confidence:1,source:'study-session'});
      if(s.status==='interrupted')ev.push({kind:'interruption',subject:s.subject,value:s.topic,confidence:.9,source:'study-session'});
    });
    ev.push({kind:'context',value:(state.context&&state.context.mode)||'normal',confidence:.95,source:'context-engine'});
    return ev;
  }
  function classify(ev){return ev.map(function(x){var c='fact';if(x.kind==='observed_result')c=x.value<70?'performance_risk':x.value<80?'below_target':'stable_performance';if(x.kind==='open_assignment')c='responsibility';if(x.kind==='exam')c='deadline';if(x.kind==='interruption')c='execution_disruption';return Object.assign({},x,{classification:c})})}
  function daysUntil(d){if(!d)return 999;var a=new Date();var b=new Date(d+'T23:59:59');return Math.ceil((b-a)/86400000)}
  function feasibility(options){var cap=0;var h=new Date().getHours();if(h<7)cap=30;else if(h>=22)cap=0;else cap=Math.max(20,Math.min(180,(22-h)*20));var total=options.reduce(function(n,x){return n+(Number(x.minutes)||0)},0);return {availableMinutes:cap,requiredMinutes:total,feasible:total<=cap,ratio:cap?Math.min(1,cap/Math.max(1,total)):0}}
  function priorities(state,ev){
    var list=[];
    (state.assignments||[]).filter(function(a){return a.status!=='done'}).forEach(function(a){
      var d=daysUntil(a.due);
      list.push({type:'assignment',subject:a.subject||'Academic',title:a.title,minutes:Number(a.minutes)||35,score:70+(d<=0?30:d<=2?25:d<=7?15:0),reason:d<=0?'overdue':d<=2?'near deadline':'open responsibility'});
    });
    (state.exams||[]).forEach(function(e){
      var d=daysUntil(e.date);
      if(d>=0&&d<=14) list.push({type:'exam',subject:e.subject||'Academic',title:'Prepare: '+e.title,minutes:45,score:80+(d<=2?20:d<=7?10:0),reason:'exam in '+d+' day(s)'});
    });
    Object.keys(state.results||{}).forEach(function(s){
      var a=state.results[s]||[], r=a[a.length-1];
      if(r&&typeof r.score==='number'&&r.score<80) list.push({type:'review',subject:s,title:'Review '+s,minutes:45,score:100-r.score,reason:'latest recorded result '+r.score+'%'});
    });
    return list.sort(function(a,b){return b.score-a.score});
  }
  function conflictResolution(state,candidates){var mode=state.context&&state.context.mode;if(mode==='sleep')return {winner:null,reason:'sleep protection outranks optimization',constraint:'sleep'};if(state.consequences&&state.consequences.length)return {winner:null,reason:'active recovery/consequence path must be resolved before stacking work',constraint:'recovery'};return {winner:candidates[0]||null,reason:'highest supported priority after constraints',constraint:null}}
  function worldState(){var raw=collectRawState(),ev=classify(evidence(raw)),candidates=priorities(raw,ev),conf=conflictResolution(raw,candidates),fit=feasibility(candidates.slice(0,3));var confidence=conf.winner?(conf.winner.score>=90?'high':conf.winner.score>=70?'medium':'low'):'high';var st={generatedAt:now(),raw:raw,evidence:ev,beliefs:{topPriority:conf.winner||null,confidence:confidence,uncertainties:conf.winner&&conf.winner.type==='review'?['Cause of low result is not established from score alone.']:[]},constraints:{context:raw.context.mode||'normal',conflict:conf},feasibility:fit};save(K.state,st);return st}
  function explain(st){var b=st.beliefs;return {decision:b.topPriority?b.topPriority.title:'No action',confidence:b.confidence,evidence:st.evidence.filter(function(x){return x.classification!=='fact'}).slice(0,6),uncertainty:b.uncertainties||[],constraint:st.constraints.conflict.reason}}
  function decide(){var st=worldState();if(st.constraints.conflict.constraint==='sleep')return {action:'protect_sleep',title:'Protect sleep',reason:'Sleep protection outranks academic optimization right now.',confidence:'high',state:st};if(st.constraints.conflict.constraint==='recovery')return {action:'recover',title:'Resolve the recovery path',reason:'Nori will not stack new demands onto an active recovery path.',confidence:'high',state:st};if(!st.beliefs.topPriority)return {action:'gather_evidence',title:'Gather useful evidence',reason:'Nori does not have enough evidence for a confident priority.',confidence:'medium',state:st};return {action:'execute',title:st.beliefs.topPriority.title,reason:st.beliefs.topPriority.reason,task:st.beliefs.topPriority,confidence:st.beliefs.confidence,state:st}}
  function logEvent(type,payload){var rows=load(K.events,[]);rows.push({id:uid('evt'),at:now(),type:type,payload:payload||{}});save(K.events,rows.slice(-500));return rows[rows.length-1]}
  function outcome(eventId,outcome){return logEvent('decision_outcome',{eventId:eventId,outcome:outcome})}
  function affectFor(input,decision){var t=safeText(input).toLowerCase();var a='calm';if(/great|nice|good job|proud|win|improv/.test(t))a='encouraging';if(/sad|tired|overwhelmed|hard|rough|upset/.test(t))a='warm';if(/urgent|emergency|unsafe/.test(t))a='concerned';if(decision&&decision.action==='execute')a='focused';if(decision&&decision.action==='protect_sleep')a='caring';if(decision&&decision.action==='recover')a='firm';if(/haha|lol|funny/.test(t))a='amused';save(K.affect,{emotion:a,at:now()});return a}
  function affectMeta(emotion){var map={calm:{face:'calm',motion:'slow',tone:'steady'},encouraging:{face:'smile',motion:'bright',tone:'warm'},warm:{face:'soft',motion:'gentle',tone:'quiet'},concerned:{face:'concerned',motion:'steady',tone:'serious'},focused:{face:'focused',motion:'precise',tone:'direct'},caring:{face:'soft',motion:'slow',tone:'protective'},firm:{face:'serious',motion:'steady',tone:'firm'},amused:{face:'smile',motion:'light',tone:'light'}};return map[emotion]||map.calm}
  function setAffect(emotion){emotion=affectMeta(emotion)?emotion:'calm';save(K.affect,{emotion:emotion,at:now()});if(typeof noriVisualSetAffect==='function')noriVisualSetAffect(emotion);return affectMeta(emotion)}
  function toneGuidance(input){var t=safeText(input).toLowerCase();if(/why|explain|how/.test(t))return 'clear';if(/i can't|impossible|hate|tired|overwhelmed|sad/.test(t))return 'supportive_direct';if(/focus|start|deadline|exam/.test(t))return 'firm_practical';return 'natural_student'}
  function buildChatContext(message,opts){opts=opts||{};var st=worldState(),d=decide(),em=affectFor(message,d);return {worldState:st,decision:{action:d.action,title:d.title,reason:d.reason,confidence:d.confidence},tone:toneGuidance(message),emotion:em,emotionMeta:affectMeta(em),memory:opts.publicVoice?publicVoiceMemory(message):recall(message,8),memoryPolicy:{sensitiveExcluded:true,secretsExcluded:true},psychology:{mode:'general-support',principles:['validate without automatically agreeing','separate facts from interpretations','use small actionable steps when overwhelmed','avoid diagnosis','protect autonomy','keep standards when capacity allows']}}}
  function rememberConfirmed(text,meta){return addMemory(text,Object.assign({source:'user_confirmed'},meta||{}))}
  function getMemory(){return memoryRows()}
  function publicMode(){return !!load(K.prefs,{publicVoiceMode:false}).publicVoiceMode}
  function setPublicMode(v){var p=load(K.prefs,{});p.publicVoiceMode=!!v;save(K.prefs,p);return p.publicVoiceMode}
  g.noriBrainV10Legacy={worldState,decide,explain,feasibility,priorities,conflictResolution,logEvent,outcome,buildChatContext,rememberConfirmed,recall,getMemory,removeMemory,publicVoiceMemory,setAffect,affectMeta,publicMode,setPublicMode,redact};
})(window);
