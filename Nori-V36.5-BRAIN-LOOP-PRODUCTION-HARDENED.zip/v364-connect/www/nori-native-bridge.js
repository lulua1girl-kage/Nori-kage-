/* ==========================================================================
   NORI — NATIVE BRIDGE (Capacitor / Android hybrid)
   ==========================================================================
   Detects whether Nori is running inside the native Capacitor Android app
   or a regular browser, and provides ONE shared speech implementation for
   both — noriListenOnce() and noriSpeak() — used everywhere instead of
   each file talking to the Web Speech API directly. Before this file,
   there were 4 separate places doing that (nori-ai-checkin.js,
   nori-meet.js's continuous listener, and nori-meet.js's Quick Add Result
   mic button) — same fragmentation problem the storage layer fixed,
   applied here to speech instead of localStorage.

   THE IMPORTANT GOTCHA: Android's native WebView (what a Capacitor app
   actually runs in) does NOT reliably support the Web Speech API's
   SpeechRecognition interface — that's a Chrome-specific feature tied to
   Google's cloud speech service, not a standard WebView capability.
   speechSynthesis (text-to-speech) generally DOES work fine in WebView.
   So on native Android, speech-to-text needs a real native plugin
   instead of the browser API — that's what NORI_IS_NATIVE below routes
   around. This needs the @capacitor-community/speech-recognition plugin
   installed (see package.json) and microphone + speech-recognition
   permissions declared (see android/app/src/main/AndroidManifest.xml
   notes in the README) — and it genuinely needs testing on a real
   device; WebView speech behavior varies by Android version/OEM in ways
   a sandbox can't fully verify.

   Load this AFTER nori-storage.js and BEFORE every other feature file.
   ========================================================================== */

const NORI_IS_NATIVE = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());

// IMPORTANT FOR THE NATIVE ANDROID BUILD: Capacitor serves the app from a
// local origin (https://localhost on Android), not from your deployed
// backend's domain — so relative fetch("/api/...") calls that work fine on
// the web will NOT reach your backend from inside the native app. Set this
// to your deployed backend's full URL before building for Android (e.g.
// "https://your-nori-app.vercel.app"). Leave it empty for the web version,
// where relative paths correctly mean "same origin as this page".
// Every endpoint constant (NORI_AI_ENDPOINT, NORI_EVAL_ENDPOINT,
// NORI_BRAIN_ENDPOINT) derives from this ONE value, so there's only one
// place to change instead of three separate ones that could drift.
const NORI_API_BASE_URL = ""; // e.g. "https://your-nori-app.vercel.app" for the Android build

const NORI_SPEECH_SUPPORTED = NORI_IS_NATIVE
  ? !!((window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.SpeechRecognition) || (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.NoriVoice))
  : !!(window.SpeechRecognition || window.webkitSpeechRecognition);

/* ---------------- single-shot listen ---------------- */

function noriListenOnceWeb() {
  return new Promise(function (resolve, reject) {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) { reject(new Error("no-speech-api")); return; }
    const rec = new Recognition();
    rec.lang = "en-US";
    rec.interimResults = false;
    rec.maxAlternatives = 1;
    rec.onresult = function (e) { resolve(e.results[0][0].transcript); };
    rec.onerror = function (e) { reject(new Error(e.error || "speech-error")); };
    rec.start();
  });
}

function noriListenOnceNative() {
  const Plugins = window.Capacitor && window.Capacitor.Plugins;
  const Plugin = Plugins && Plugins.SpeechRecognition;
  const NoriVoice = Plugins && Plugins.NoriVoice;
  // Prefer the real Capacitor speech-recognition plugin when installed.
  if (Plugin) {
    return Plugin.requestPermissions().catch(function () { return { speechRecognition: "denied" }; }).then(function (perm) {
      if (perm.speechRecognition !== "granted") throw new Error("permission-denied");
      return new Promise(function (resolve, reject) {
        let settled=false, removeListener=function(){}, silenceTimer=null, latest="";
        function finish(value){if(settled)return;settled=true;if(silenceTimer)clearTimeout(silenceTimer);removeListener();Plugin.stop().catch(function(){});value?resolve(value):reject(new Error("no-speech"));}
        Plugin.addListener("partialResults",function(data){if(settled)return;if(data&&data.matches&&data.matches[0]){latest=String(data.matches[0]).trim();if(silenceTimer)clearTimeout(silenceTimer);silenceTimer=setTimeout(function(){finish(latest)},850);}}).then(function(h){removeListener=function(){h.remove();}});
        Plugin.start({language:"en-US",maxResults:1,partialResults:true,popup:false}).catch(function(e){if(!settled){settled=true;removeListener();reject(e);}});
        setTimeout(function(){if(!settled)finish(latest)},12000);
      });
    });
  }
  // Nori's bundled Android voice bridge is also a valid native path. It emits
  // explicit speech events and never silently records in the background.
  if (NoriVoice) {
    return new Promise(function(resolve,reject){
      let settled=false,handle=null;
      const done=function(v,err){if(settled)return;settled=true;try{handle&&handle.remove()}catch(_){};err?reject(err):resolve(v)};
      Promise.resolve(NoriVoice.addListener('speech',function(d){const t=String(d&&d.text||'').trim();if(t)done(t,t?null:new Error('no-speech'));})).then(function(h){handle=h;return NoriVoice.openWorkspace?NoriVoice.openWorkspace({mode:'RETURN_TO_CHAT'}):null;}).catch(function(e){done('',e)});
      setTimeout(function(){done('',new Error('native-voice-timeout'))},15000);
    });
  }
  return Promise.reject(new Error("no-speech-api"));
}

// Used throughout the app for a single "say one thing, get the text back"
// interaction — Check-In, Report Result's voice confirm, Quick Add
// Result's Speak button. Works the same from the caller's side on both
// platforms.
function noriListenOnce() {
  if (window.NoriInteractivePresence && window.NoriInteractivePresence.setState) window.NoriInteractivePresence.setState('LISTENING');
  try { document.dispatchEvent(new CustomEvent('nori:voice-state',{detail:{state:'LISTENING'}})); } catch(e) {}
  const p = NORI_IS_NATIVE ? noriListenOnceNative() : noriListenOnceWeb();
  return p.then(function(text){
    try { document.dispatchEvent(new CustomEvent('nori:voice-state',{detail:{state:'PROCESSING',transcript:text}})); } catch(e) {}
    return text;
  }).catch(function(err){
    try { document.dispatchEvent(new CustomEvent('nori:voice-state',{detail:{state:'ERROR'}})); } catch(e) {}
    throw err;
  });
}

/* ---------------- text-to-speech ---------------- */
// speechSynthesis is generally available in Android WebView too, so this
// stays shared rather than needing a native plugin. If it proves
// unreliable on a real device, swap this for the @capacitor/text-to-speech
// plugin's Plugins.TextToSpeech.speak() — same call shape, easy swap.

// options: { onStart, onEnd, onError } — all optional. Used by Meet Nori's
// barge-in logic (tracking when Nori is actively speaking) as well as
// plain fire-and-forget calls elsewhere in the app.
function noriSpeak(text, options) {
  if (!window.speechSynthesis) return;
  options = options || {};
  window.speechSynthesis.cancel();
  try { document.dispatchEvent(new CustomEvent('nori:voice-state',{detail:{state:'SPEAKING',transcript:text}})); } catch(e) {}
  if (window.NoriInteractivePresence && window.NoriInteractivePresence.setState) window.NoriInteractivePresence.setState('SPEAKING');
  const utter = new SpeechSynthesisUtterance(text);
  const voiceEmotion = window.__noriVoiceEmotion || 'calm';
  const voiceMap = { calm:{rate:0.98,pitch:1.0}, encouraging:{rate:1.02,pitch:1.02}, warm:{rate:0.94,pitch:1.0}, concerned:{rate:0.96,pitch:0.98}, focused:{rate:1.0,pitch:0.98}, caring:{rate:0.94,pitch:0.98}, firm:{rate:0.98,pitch:0.96}, amused:{rate:1.01,pitch:1.01} };
  const vm = voiceMap[voiceEmotion] || voiceMap.calm;
  utter.rate = options.rate == null ? vm.rate : options.rate;
  utter.pitch = options.pitch == null ? vm.pitch : options.pitch;
  if (options.onStart) utter.onstart = options.onStart;
  utter.onend = function(e){ try { document.dispatchEvent(new CustomEvent('nori:voice-state',{detail:{state:'IDLE'}})); } catch(x) {} if (window.NoriInteractivePresence && window.NoriInteractivePresence.setState) window.NoriInteractivePresence.setState('IDLE'); if(options.onEnd) options.onEnd(e); };
  if (options.onError) utter.onerror = options.onError;
  window.speechSynthesis.speak(utter);
}
