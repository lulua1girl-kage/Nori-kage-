/* NORI NAVIGATION BRAIN V1 — unified feature map + voice navigation + workspace chrome. */
(function(g){'use strict';
  const FEATURES=[
    {id:'home',label:'HOME',icon:'⌂',route:'#/',group:'CORE'},
    {id:'command',label:'COMMAND',icon:'◆',route:'#/command',group:'CORE'},
    {id:'meet',label:'MEET NORI',icon:'◉',route:'#/meet-nori',group:'CORE'},
    {id:'tasks',label:'TASKS',icon:'▣',route:'#/tasks',group:'ACADEMICS'},
    {id:'study',label:'STUDY CENTER',icon:'▤',route:'#/study',group:'ACADEMICS'},
    {id:'results',label:'RESULTS',icon:'▥',route:'#/results',group:'ACADEMICS'},
    {id:'progress',label:'PROGRESS',icon:'▦',route:'#/progress',group:'ACADEMICS'},
    {id:'calendar',label:'CALENDAR',icon:'□',route:'#/calendar',group:'PLANNING'},
    {id:'alarms',label:'ALARMS',icon:'◷',route:'#/alarms',group:'PLANNING'},
    {id:'time-tools',label:'TIME TOOLS',icon:'◴',route:'#/time-tools',group:'PLANNING'},
    {id:'exams',label:'EXAMS',icon:'△',route:'#/exams',group:'PLANNING'},
    {id:'focus',label:'FOCUS',icon:'⊙',route:'#/focus',group:'PROTECTION'},
    {id:'recover',label:'RECOVER',icon:'↻',route:'#/recover',group:'PROTECTION'},
    {id:'consequences',label:'ACTIVE CONTROLS',icon:'!',route:'#/consequences',group:'PROTECTION'},
    {id:'notifications',label:'NOTIFICATIONS',icon:'◇',route:'#/notifications',group:'SYSTEM'},
    {id:'inbox',label:'INBOX',icon:'▱',route:'#/inbox',group:'SYSTEM'},
    {id:'diagnostic',label:'DIAGNOSTIC',icon:'⌁',route:'#/diagnostic',group:'INTELLIGENCE'},
    {id:'timeline',label:'TIMELINE',icon:'↕',route:'#/timeline',group:'INTELLIGENCE'},
    {id:'integrity',label:'INTEGRITY',icon:'◆',route:'#/integrity',group:'SYSTEM'},
    {id:'smart-integrity',label:'INTEGRATION AUDIT',icon:'✓',route:'#/smart-integrity',group:'SYSTEM'},
    {id:'profile',label:'PROFILE',icon:'♙',route:'#/profile',group:'SYSTEM'},
    {id:'settings',label:'SETTINGS',icon:'⚙',route:'#/settings',group:'SYSTEM'},
    {id:'phases',label:'PHASE FORMS',icon:'≡',route:'#/phases',group:'SYSTEM'}
  ];
  const ACTIONS=[
    ['open home','#/'],['go home','#/'],['open command','#/command'],['daily command','#/command'],
    ['meet nori','#/meet-nori'],['open chat','#/meet-nori'],['open tasks','#/tasks'],['new task','#/tasks'],
    ['study center','#/study'],['open study','#/study'],['results','#/results'],['record result','#/meet-nori'],['new result','#/meet-nori'],['new assessment','#/meet-nori'],['new assignment','#/tasks'],['add subject','#/meet-nori'],['start study','#/study'],['start focus','#/focus'],['set alarm','#/alarms'],
    ['progress','#/progress'],['analytics','#/progress'],['calendar','#/calendar'],['alarms','#/alarms'],['timer','#/time-tools'],['stopwatch','#/time-tools'],['math speed','#/math-speed'],['math stopwatch','#/math-speed'],
    ['exams','#/exams'],['focus mode','#/focus'],['focus','#/focus'],['recover','#/recover'],
    ['recovery','#/recover'],['notifications','#/notifications'],['inbox','#/inbox'],['diagnostic','#/diagnostic'],
    ['timeline','#/timeline'],['integrity','#/integrity'],['profile','#/profile'],['settings','#/settings'],['phase forms','#/phases'],['standard interface','#/profile'],['nori standard','#/profile'],['kage interface','#/profile'],['kage avatar','#/profile'],['interactive circle','#/profile'],['circle interface','#/profile'],['hybrid interface','#/profile'],['compact mode','#/profile'],['fast mode','#/profile']
  ];
  function norm(s){return String(s||'').toLowerCase().replace(/[^a-z0-9 ]+/g,' ').replace(/\s+/g,' ').trim();}
  function routeFor(text){const raw=String(text||'').trim();const typed=raw.split('|')[0].toUpperCase();const typedMap={NEW_RESULT:'#/meet-nori',NEW_ASSESSMENT:'#/meet-nori',NEW_ASSIGNMENT:'#/tasks',ADD_SUBJECT:'#/meet-nori',SCAN_STUDY_LIBRARY:'#/study',OPEN_STUDY_RESOURCE:'#/study',START_EXAM_MODE:'#/exams',RETURN_TO_CHAT:'#/meet-nori',OPEN_APP:null};if(typedMap.hasOwnProperty(typed)&&typedMap[typed])return typedMap[typed];const n=norm(raw).replace(/^nori /,''); if(/\b(go back|back)\b/.test(n)){history.back();return '#__back__';} const semantic=[[/\b(math|mathematics).*(result|score|grade|mark)/,'#/results'],[/\b(chemistry|physics|biology|english|agriculture).*(result|score|grade|mark)/,'#/results'],[/\b(today|daily).*(assignment|homework|task)/,'#/tasks'],[/\b(recovery|recover)/,'#/recover'],[/\b(alarm|alarms|reminder)/,'#/alarms'],[/\b(timer|countdown)/,'#/time-tools'],[/\b(stopwatch|stop watch|math speed|speed test)/,'#/math-speed'],[/\b(focus|concentrate)/,'#/focus'],[/\b(calendar|schedule|events?)/,'#/calendar'],[/\b(exam|test)/,'#/exams'],[/\b(settings|preferences)/,'#/settings'],[/\b(profile|account)/,'#/profile'],[/\b(chat|meet nori|talk to nori)/,'#/meet-nori']]; for(const pair of semantic){if(pair[0].test(n))return pair[1];} for(const [k,r] of ACTIONS){if(n===k||n.includes(k))return r;} return null;}
  function go(route){if(!route)return false; location.hash=route; return true;}
  function active(){const h=location.hash||'#/';return FEATURES.find(f=>h===f.route||h.startsWith(f.route+'/'))||FEATURES[0];}
  function addFeatureCard(root,f){const c=document.createElement('a');c.className='nori-nav-feature-card';c.href=f.route;c.innerHTML='<span class="nori-nav-icon">'+f.icon+'</span><span><b>'+f.label+'</b><small>'+f.group+'</small></span><span class="nori-nav-arrow">→</span>';root.appendChild(c);}
  function drawer(){
    if(document.getElementById('nori-navigation-drawer'))return;
    const shell=document.createElement('aside');shell.id='nori-navigation-drawer';shell.className='nori-nav-drawer';
    const head=document.createElement('div');head.className='nori-nav-head';head.innerHTML='<div><strong>NORI</strong><small>COMMAND MAP</small></div><button aria-label="Close navigation">×</button>';shell.appendChild(head);
    const groups={};FEATURES.forEach(f=>(groups[f.group]||(groups[f.group]=[])).push(f));
    Object.keys(groups).forEach(gr=>{const sec=document.createElement('section');sec.className='nori-nav-group';sec.innerHTML='<div class="nori-nav-group-title">'+gr+'</div>';groups[gr].forEach(f=>{const a=document.createElement('a');a.href=f.route;a.className='nori-nav-link';a.dataset.route=f.route;a.innerHTML='<span>'+f.icon+'</span><b>'+f.label+'</b>';sec.appendChild(a)});shell.appendChild(sec)});
    shell.querySelector('button').onclick=close;shell.addEventListener('click',e=>{if(e.target===shell)close()});document.body.appendChild(shell);
    function close(){shell.classList.remove('open');document.body.classList.remove('nori-nav-open')}
    window.NoriNavigation={open:()=>{shell.classList.add('open');document.body.classList.add('nori-nav-open')},close,features:FEATURES,routeFor,go};
  }
  function toolbar(){
    if(document.querySelector('.nori-nav-launch'))return;
    const bar=document.querySelector('.nori-topbar');
    const host=bar||document.querySelector('.nori-shell-header')||document.querySelector('.nori-header')||document.querySelector('#nori-app');
    if(!host)return;
    const b=document.createElement('button');b.className='nori-nav-launch';b.type='button';b.setAttribute('aria-label','Open Nori navigation');b.textContent='☰  MENU';b.onclick=()=>window.NoriNavigation&&NoriNavigation.open();
    if(bar){bar.appendChild(b);}else{b.style.marginLeft='auto';b.style.position='relative';host.appendChild(b);}
  }
  function injectPageTools(root){
    if(!root||root.querySelector('.nori-page-tools'))return;
    const tools=document.createElement('div');tools.className='nori-page-tools';
    const title=document.createElement('span');title.innerHTML='<b>'+active().label+'</b><small>CONNECTED TO NORI BRAIN</small>';tools.appendChild(title);
    const actions=document.createElement('div');
    [['MEET NORI','#/meet-nori'],['COMMAND','#/command']].forEach(x=>{const a=document.createElement('a');a.className='nori-tool-btn';a.href=x[1];a.textContent=x[0];actions.appendChild(a)});
    tools.appendChild(actions);root.insertBefore(tools,root.firstChild);
  }
  function brainRoute(text){const n=norm(text);if(g.NoriInterfaceMode){var m=n.includes('interactive circle')||n.includes('circle interface')?'circle':n.includes('kage avatar')||n.includes('kage interface')?'kage':n.includes('hybrid interface')?'hybrid':n.includes('compact mode')||n.includes('fast mode')?'compact':n.includes('standard interface')||n.includes('nori standard')?'standard':null;if(m){g.NoriInterfaceMode.set(m);return {ok:true,interface:m};}}const r=routeFor(text);if(r){go(r);return {ok:true,route:r};}return {ok:false,reason:'No matching Nori workspace'};}
  function bindVoice(){g.addEventListener('nori:voice-command',e=>{const d=e&&e.detail||{};const raw=d.raw||d.text||d.target||''; if(typeof raw==='string')brainRoute(raw);});}
  function exposeBrain(){
    g.NoriNavigationBrain={features:FEATURES,routeFor,go,handleVoice:brainRoute,active};
    if(g.noriBrainEngine&&typeof g.noriBrainEngine.registerNavigation==='function')g.noriBrainEngine.registerNavigation(g.NoriNavigationBrain);
  }
  function featureMap(root){if(!root||location.hash!=='#/'||root.querySelector('.nori-feature-map'))return;const sec=document.createElement('section');sec.className='nori-feature-map nori-panel';const h=document.createElement('div');h.className='nori-section-head';h.innerHTML='<div><small>WORKSPACE MAP</small><h2>Everything in one place</h2></div><span>VOICE NAVIGATION READY</span>';sec.appendChild(h);const grid=document.createElement('div');grid.className='nori-feature-map-grid';FEATURES.filter(f=>f.id!=='home').forEach(f=>addFeatureCard(grid,f));sec.appendChild(grid);root.appendChild(sec)}
  function decorate(){drawer();toolbar();const root=document.getElementById('nori-app');if(root){root.classList.add('nori-connected-ui');injectPageTools(root);featureMap(root)};document.querySelectorAll('.nori-card').forEach(c=>{if(c.classList.contains('nori-card-locked'))return;if(!c.querySelector('.nori-card-cta')){const s=document.createElement('span');s.className='nori-card-cta';s.textContent='OPEN →';c.appendChild(s)}})}
  function boot(){exposeBrain();bindVoice();decorate();setTimeout(decorate,50);setTimeout(decorate,400)}
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot);else boot();
  g.addEventListener('hashchange',()=>setTimeout(decorate,0));
})(window);
