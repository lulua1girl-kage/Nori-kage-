/* NORI PRESENCE EVOLUTION V2
 * Additive feature layer for Kage Avatar + JARVIS Interactive Circle.
 * Same Brain, same conversation. No background recording by default.
 * Inspired by current assistant UX patterns: interruption, pause/resume,
 * live captions, same-chat voice+text, adjustable speech pace, visual-context
 * entry points, session continuity, quick actions and explicit permissions.
 */
(function(g){'use strict';
  var KEY='nori_presence_evolution_v2';
  var cfg={speechRate:1.0,captions:true,background:false,visualContext:false,autoListen:false,acknowledgePauses:true};
  var session={active:false,paused:false,state:'IDLE',startedAt:0,lastTranscript:'',lastResponse:'',interrupted:false};
  var visualContext={kind:null,dataUrl:null,capturedAt:0};
  var originalSpeak=null,wrapped=false;
  function load(){try{var x=JSON.parse(localStorage.getItem(KEY)||'{}');Object.keys(cfg).forEach(function(k){if(typeof x[k]===typeof cfg[k])cfg[k]=x[k]})}catch(e){}}
  function save(){try{localStorage.setItem(KEY,JSON.stringify(cfg))}catch(e){}}
  function emit(type,detail){try{document.dispatchEvent(new CustomEvent('nori:presence-evolution',{detail:Object.assign({type:type},detail||{})}))}catch(e){}}
  function setState(s,extra){session.state=String(s||'IDLE').toUpperCase();if(g.noriInteractiveSetState)g.noriInteractiveSetState(session.state,extra&&extra.text);emit('state',{state:session.state,text:extra&&extra.text});}
  function start(){session.active=true;session.paused=false;session.interrupted=false;session.startedAt=Date.now();setState('IDLE');emit('session',{active:true});return snapshot()}
  function stop(){session.active=false;session.paused=false;setState('IDLE');emit('session',{active:false});return snapshot()}
  function pause(){if(!session.active)return false;session.paused=true;setState('IDLE',{text:'PAUSED'});emit('pause',{paused:true});return true}
  function resume(){if(!session.active)return false;session.paused=false;setState('IDLE',{text:'READY'});emit('pause',{paused:false});return true}
  function interrupt(){session.interrupted=true;session.paused=false;setState('IDLE',{text:'INTERRUPTED'});try{if(g.speechSynthesis)speechSynthesis.cancel()}catch(e){};if(g.NoriVoiceV28&&g.NoriVoiceV28.stop)try{g.NoriVoiceV28.stop()}catch(e){};emit('interrupt',{});return true}
  function captureTranscript(text,partial){session.lastTranscript=String(text||'');setState('LISTENING',{text:partial?'LISTENING':'HEARD'});if(g.NoriInteractivePresence&&g.NoriInteractivePresence.setTranscript)g.NoriInteractivePresence.setTranscript(session.lastTranscript);emit('transcript',{text:session.lastTranscript,partial:!!partial});}
  function beforeSpeak(text){session.lastResponse=String(text||'');if(!session.active)start();setState('SPEAKING');emit('response',{text:session.lastResponse});}
  function wrapSpeak(){if(wrapped||typeof g.noriSpeak!=='function')return;originalSpeak=g.noriSpeak;g.noriSpeak=function(text,options){options=options||{};beforeSpeak(text);var oldStart=options.onStart,oldEnd=options.onEnd,oldError=options.onError;var merged=Object.assign({},options,{rate:cfg.speechRate,onStart:function(){setState('SPEAKING');if(oldStart)oldStart()},onEnd:function(){setState('IDLE');if(oldEnd)oldEnd()},onError:function(){setState('ERROR',{text:'SPEECH ERROR'});if(oldError)oldError()}});try{return originalSpeak(text,merged)}catch(e){setState('ERROR',{text:e.message});throw e;}};wrapped=true}
  function repeat(){if(!session.lastResponse)return false;return speakAgain(session.lastResponse)}
  function speakAgain(text){if(typeof g.noriSpeak!=='function')return false;g.noriSpeak(text,{rate:cfg.speechRate});return true}
  function setRate(v){v=Math.max(.65,Math.min(1.5,Number(v)||1));cfg.speechRate=v;save();emit('setting',{key:'speechRate',value:v});return v}
  function setCaptions(v){cfg.captions=!!v;save();emit('setting',{key:'captions',value:cfg.captions});return cfg.captions}
  function setBackground(v){cfg.background=!!v;save();emit('setting',{key:'background',value:cfg.background});return cfg.background}
  function setVisualContext(v){cfg.visualContext=!!v;save();emit('setting',{key:'visualContext',value:cfg.visualContext});return cfg.visualContext}
  function visualPlugin(){return g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.NoriVisual?g.Capacitor.Plugins.NoriVisual:null}
  function rememberVisual(kind,dataUrl){visualContext={kind:kind,dataUrl:dataUrl||null,capturedAt:Date.now()};g.NoriVisualContextV1={kind:visualContext.kind,dataUrl:visualContext.dataUrl,capturedAt:visualContext.capturedAt,clear:function(){visualContext={kind:null,dataUrl:null,capturedAt:0};g.NoriVisualContextV1={kind:null,dataUrl:null,capturedAt:0}}};emit('visual-context',{kind:kind,available:!!dataUrl,capturedAt:visualContext.capturedAt});return visualContext}
  function requestVisualContext(kind){kind=kind==='screen'?'screen':'camera';if(!cfg.visualContext)return Promise.resolve({ok:false,reason:'Visual context is disabled in Presence settings.'});emit('visual-context-request',{kind:kind,explicit:true});var p=visualPlugin();if(!p)return Promise.resolve({ok:false,reason:'Native visual context is not available in this build.'});var eventName=kind==='screen'?'screenContext':'cameraContext';var errName=kind==='screen'?'screenError':'cameraError';return new Promise(function(resolve){var settled=false,handles=[];function done(r){if(settled)return;settled=true;handles.forEach(function(h){try{h.remove()}catch(e){}});resolve(r)};Promise.all([p.addListener(eventName,function(d){if(d&&d.ok&&d.dataUrl){rememberVisual(kind,d.dataUrl);done({ok:true,kind:kind,dataUrl:d.dataUrl})}}),p.addListener(errName,function(d){done({ok:false,reason:(d&&d.error)||'Visual capture failed'})})]).then(function(h){handles=h;return kind==='screen'?p.captureScreen():p.captureCamera()}).then(function(r){if(r&&r.ok===false)done({ok:false,reason:r.error||'Visual capture canceled'})}).catch(function(e){done({ok:false,reason:e.message})});setTimeout(function(){done({ok:false,reason:'Visual capture timed out.'})},45000)})}
  function quickAction(action){var map={simpler:'Explain that more simply.',repeat:'Repeat your last response.',summary:'Give me the key points only.',pause:'Pause and wait for me.',continue:'Continue from where we stopped.'};var text=map[action];if(!text)return false;if(action==='pause'){pause();return true}if(action==='continue'){resume();return true}if(action==='repeat')return repeat();if(typeof g.noriMeetSendText==='function'){g.__noriInputChannel='text';return g.noriMeetSendText(text)}return false}
  function snapshot(){return {config:Object.assign({},cfg),session:Object.assign({},session)}}
  function button(label,fn){var b=document.createElement('button');b.type='button';b.textContent=label;b.onclick=fn;return b;}
  function mountCircleControls(){
    var shell=document.querySelector('.nori-ip-shell'); if(!shell||shell.querySelector('.nori-presence-v2-controls'))return;
    var host=shell.querySelector('.nori-ip-bottom'); if(!host)return;
    var controls=document.createElement('div');controls.className='nori-presence-v2-controls';
    controls.appendChild(button('PAUSE',pause));
    controls.appendChild(button('RESUME',resume));
    controls.appendChild(button('INTERRUPT',interrupt));
    controls.appendChild(button('REPEAT',repeat));
    controls.appendChild(button('SLOWER',function(){setRate(cfg.speechRate-.1)}));
    controls.appendChild(button('FASTER',function(){setRate(cfg.speechRate+.1)}));
    var cam=button('CAMERA',function(){if(!cfg.visualContext){setVisualContext(true);}requestVisualContext('camera').then(function(r){if(!r.ok&&g.NoriInteractivePresence)g.NoriInteractivePresence.setTranscript(r.reason);});});
    var screen=button('SCREEN',function(){if(!cfg.visualContext){setVisualContext(true);}requestVisualContext('screen').then(function(r){if(!r.ok&&g.NoriInteractivePresence)g.NoriInteractivePresence.setTranscript(r.reason);});});
    var bg=button('BG VOICE',function(){var p=g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.NoriVoice;if(!p){if(g.NoriInteractivePresence)g.NoriInteractivePresence.setTranscript('Native background voice is unavailable.');return;}p.start({wakeWord:'nori'}).then(function(){setBackground(true);if(g.NoriInteractivePresence)g.NoriInteractivePresence.setTranscript('Background voice started. Stop it from the notification or here.');}).catch(function(e){if(g.NoriInteractivePresence)g.NoriInteractivePresence.setTranscript(e.message);});});
    controls.appendChild(cam);controls.appendChild(screen);controls.appendChild(bg);host.appendChild(controls);
    var q=document.createElement('div');q.className='nori-presence-v2-quick';
    [['SIMPLER','simpler'],['SUMMARY','summary'],['CONTINUE','continue']].forEach(function(x){q.appendChild(button(x[0],function(){quickAction(x[1])}))});
    host.appendChild(q);
    var cap=document.createElement('div');cap.className='nori-presence-v2-caption';cap.setAttribute('aria-live','polite');cap.textContent='Live captions ready.';host.appendChild(cap);
    document.addEventListener('nori:presence-evolution',function(e){var d=e.detail||{};if(d.type==='transcript')cap.textContent=(d.partial?'Listening: ':'Heard: ')+(d.text||'');if(d.type==='response')cap.textContent='Nori: '+(d.text||'');if(d.type==='state'&&d.state==='ERROR')cap.textContent=d.text||'Voice error.';});
  }
  function mountAvatarControls(){
    var overlay=document.querySelector('.nori-avatar-v26'); if(!overlay||overlay.querySelector('.nori-avatar-v2-live'))return;
    var live=document.createElement('div');live.className='nori-avatar-v2-live';
    var cap=document.createElement('div');cap.className='nori-avatar-v2-caption';cap.textContent='Kage is ready.';live.appendChild(cap);
    var tr=document.createElement('div');tr.className='nori-avatar-v2-transcript';tr.textContent='Live transcription appears here while you speak.';live.appendChild(tr);
    var actions=document.createElement('div');actions.className='nori-avatar-v2-actions';
    actions.appendChild(button('INTERRUPT',interrupt));actions.appendChild(button('PAUSE',pause));actions.appendChild(button('RESUME',resume));actions.appendChild(button('REPEAT',repeat));actions.appendChild(button('SIMPLER',function(){quickAction('simpler')}));actions.appendChild(button('SUMMARY',function(){quickAction('summary')}));actions.appendChild(button('CAMERA',function(){if(!cfg.visualContext)setVisualContext(true);requestVisualContext('camera').then(function(r){if(!r.ok)cap.textContent=r.reason;});}));actions.appendChild(button('SCREEN',function(){if(!cfg.visualContext)setVisualContext(true);requestVisualContext('screen').then(function(r){if(!r.ok)cap.textContent=r.reason;});}));actions.appendChild(button('BG VOICE',function(){var p=g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.NoriVoice;if(!p){cap.textContent='Native background voice is unavailable.';return;}p.start({wakeWord:'nori'}).then(function(){setBackground(true);cap.textContent='Background voice started.';}).catch(function(e){cap.textContent=e.message;});}));
    live.appendChild(actions);overlay.appendChild(live);
    document.addEventListener('nori:presence-evolution',function(e){var d=e.detail||{};if(d.type==='transcript')tr.textContent=(d.partial?'Listening: ':'Heard: ')+(d.text||'');if(d.type==='response')cap.textContent=d.text||'';if(d.type==='state'&&d.state==='LISTENING')cap.textContent='Kage is listening…';if(d.type==='state'&&d.state==='SPEAKING')cap.textContent='Kage is speaking…';});
  }
  function install(){wrapSpeak();mountCircleControls();mountAvatarControls();}
  load();wrapSpeak();
  if(g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.NoriVisual){try{g.Capacitor.Plugins.NoriVisual.addListener('cameraContext',function(d){if(d&&d.dataUrl)rememberVisual('camera',d.dataUrl)});g.Capacitor.Plugins.NoriVisual.addListener('screenContext',function(d){if(d&&d.dataUrl)rememberVisual('screen',d.dataUrl)});}catch(e){}}
  document.addEventListener('nori:voice-state',function(e){var d=e.detail||{};if(d.transcript!=null)captureTranscript(d.transcript,!!d.partial);if(d.state)setState(d.state,{text:d.text})});
  document.addEventListener('nori:presence-evolution',function(e){
    var d=e.detail||{}; if(d.type!=='state')return;
    var map={IDLE:'neutral',LISTENING:'focused',PROCESSING:'analytical',THINKING:'analytical',SPEAKING:'encouraging',ALARM:'strict',ERROR:'concerned'};
    if(g.NoriAvatarV26&&g.NoriAvatarV26.setState&&map[d.state]){try{g.NoriAvatarV26.setState(map[d.state])}catch(_){}}
    if(g.NoriAvatarV26&&g.NoriAvatarV26.talk){try{g.NoriAvatarV26.talk(d.state==='SPEAKING')}catch(_){}}
  });
  install();
  var observer=new MutationObserver(function(){mountCircleControls();mountAvatarControls()});
  observer.observe(document.body,{childList:true,subtree:true});
  g.NoriPresenceEvolutionV2={start:start,stop:stop,pause:pause,resume:resume,interrupt:interrupt,captureTranscript:captureTranscript,repeat:repeat,speakAgain:speakAgain,setRate:setRate,setCaptions:setCaptions,setBackground:setBackground,setVisualContext:setVisualContext,requestVisualContext:requestVisualContext,rememberVisual:rememberVisual,quickAction:quickAction,snapshot:function(){var x=snapshot();x.visual=Object.assign({},visualContext,{dataUrl:visualContext.dataUrl?'[available]':null});return x}};
})(window);
