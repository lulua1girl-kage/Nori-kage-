/* Nori live world information — additive bridge. */
(function(g){'use strict';
  function plugin(){return g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.NoriWorld;}
  function native(){return !!(plugin());}
  function ask(method,args){var p=plugin();if(!p||!p[method])return Promise.reject(new Error('live-world-native-bridge-unavailable'));return p[method](args||{});}
  function send(text){if(typeof g.noriMeetSendText==='function')return g.noriMeetSendText(text);return Promise.resolve();}
  function format(o){
    if(!o||!o.ok)return 'I could not retrieve live information right now. '+((o&&o.error)||'The source did not respond.');
    var lines=[]; for(var i=0;i<5;i++){var t=o['item'+i+'Title'];if(!t)continue;lines.push((i+1)+'. '+t+(o['item'+i+'Summary']?' — '+o['item'+i+'Summary']:''));}
    if(o.kind==='WEATHER'&&o.summary)lines.unshift('Current weather: '+o.summary);
    return (o.summary||('Live '+String(o.kind||'web').toLowerCase()+' information retrieved.'))+(lines.length?'\n'+lines.join('\n'):'');
  }
  async function latestNews(query){var o=await ask('latestNews',{query:query||''});await send(format(o));return o;}
  async function weather(location){var o=await ask('weather',{location:location||''});await send(format(o));return o;}
  async function trends(query){var o=await ask('trends',{query:query||''});await send(format(o));return o;}
  async function webSearch(query){var o=await ask('webSearch',{query:query||''});await send(format(o));return o;}
  async function openChrome(url){return ask('openChrome',{url:url});}
  async function searchChrome(query){return ask('searchChrome',{query:query});}
  async function newsInChrome(query){return ask('newsInChrome',{query:query||''});}
  function handle(raw){
    var q=String(raw||'').trim(),n=q.toLowerCase();
    if(!native())return false;
    if(/\b(open|show|search|look)\b.*\b(news)\b.*\b(chrome|browser)\b/.test(n)){newsInChrome(q.replace(/^.*?\bnews\b/i,'').replace(/\b(in|on)\s+(chrome|browser)\b/i,'').trim());return true;}
    if(/\b(open|search|look)\b.*\b(chrome|browser)\b/.test(n)){searchChrome(q.replace(/^.*?\b(search|look)\b/i,'').replace(/\b(in|on)\s+(chrome|browser)\b/i,'').trim());return true;}
    if(/\b(weather|forecast|temperature)\b/.test(n)){var loc=q.replace(/^.*?\b(weather|forecast|temperature)\b/i,'').replace(/\b(in|for|at)\b/i,'').trim();weather(loc);return true;}
    if(/\b(trending|trends|what'?s trending)\b/.test(n)){trends(q);return true;}
    if(/\b(latest|today'?s|current)\b.*\b(news|headlines)\b|\b(news|headlines)\b.*\b(latest|today'?s|current)\b/.test(n)){latestNews(q);return true;}
    return false;
  }
  g.NoriWorldWeb={latestNews,weather,trends,webSearch,openChrome,searchChrome,newsInChrome,handle};
})(window);
