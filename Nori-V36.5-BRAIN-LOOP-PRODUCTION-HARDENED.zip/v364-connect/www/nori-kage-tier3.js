/* NORI KAGE TIER 3 — serious KAGE system
   Advanced analytics • automatic replanning • failure patterns
   • weekly intelligence • rule conflict/audit
   Local-first, evidence-based, Human Override preserved. */
(function(g){'use strict';
  var KEY='nori_kage_tier3_v1';
  function load(k,fb){try{var x=JSON.parse(localStorage.getItem(k)||'null');return x==null?fb:x}catch(e){return fb}}
  function save(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function now(){return new Date()}
  function iso(){return now().toISOString()}
  function day(d){return new Date(d||Date.now()).toISOString().slice(0,10)}
  function daysUntil(d){if(!d)return 999;var x=new Date(d+'T23:59:59'),n=now();return Math.ceil((x-n)/86400000)}
  function arr(v){return Array.isArray(v)?v:[]}
  function state(){
    var s={results:{},assignments:[],exams:[],sessions:[],events:[]};
    try{s.results=typeof noriHistoryLoadAll==='function'?noriHistoryLoadAll():{}}catch(e){}
    try{s.assignments=typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():load('nori_command_assignments',[])}catch(e){}
    try{s.exams=typeof noriExamsLoad==='function'?noriExamsLoad():load('nori_exams',[])}catch(e){}
    try{s.sessions=typeof noriStudySessionsLoad==='function'?noriStudySessionsLoad():load('nori_study_sessions',[])}catch(e){}
    try{s.events=load('nori_brain_events_v12',[])}catch(e){}
    return s;
  }
  function analytics(){
    var s=state(),subjects={};
    Object.keys(s.results||{}).forEach(function(sub){var a=arr(s.results[sub]),scores=a.map(function(x){return Number(x.score)}).filter(isFinite);if(!scores.length)return;var recent=scores.slice(-5),avg=recent.reduce(function(x,y){return x+y},0)/recent.length;var prev=scores.slice(-10,-5);var prevAvg=prev.length?prev.reduce(function(x,y){return x+y},0)/prev.length:null;subjects[sub]={tests:scores.length,latest:scores[scores.length-1],recentAverage:+avg.toFixed(1),trend:prevAvg==null?0:+(avg-prevAvg).toFixed(1)};});
    arr(s.assignments).forEach(function(a){var sub=a.subject||'Academic';subjects[sub]=subjects[sub]||{};if(a.status!=='done')subjects[sub].openAssignments=(subjects[sub].openAssignments||0)+1;if(a.due){var d=daysUntil(a.due);if(d>=0)subjects[sub].nearestAssignment=Math.min(subjects[sub].nearestAssignment==null?999:subjects[sub].nearestAssignment,d)}});
    arr(s.exams).forEach(function(e){var sub=e.subject||'Academic';subjects[sub]=subjects[sub]||{};var d=daysUntil(e.date);if(d>=0)subjects[sub].nearestExam=Math.min(subjects[sub].nearestExam==null?999:subjects[sub].nearestExam,d)});
    var rows=Object.keys(subjects).map(function(sub){var x=subjects[sub],risk=0;if(typeof x.latest==='number'&&x.latest<80)risk+=(80-x.latest);if(x.trend<0)risk+=Math.min(15,-x.trend);if(x.openAssignments)risk+=x.openAssignments*6;if(x.nearestExam!=null&&x.nearestExam<=7)risk+=18;return {subject:sub,data:x,risk:+risk.toFixed(1)}}).sort(function(a,b){return b.risk-a.risk});
    var out={generatedAt:iso(),subjects:rows,overall:{subjects:rows.length,openAssignments:arr(s.assignments).filter(function(a){return a.status!=='done'}).length,upcomingExams:arr(s.exams).filter(function(e){var d=daysUntil(e.date);return d>=0&&d<=14}).length},evidenceNote:'Analytics describe recorded patterns; they do not establish personal causes.'};
    save(KEY+'/analytics',out);return out;
  }
  function failurePatterns(){
    var s=state(),ev=arr(s.events),counts={};
    ev.forEach(function(e){var t=String(e.type||e.event||e.outcome||'').toLowerCase();var k=/interrupt|fail|could.?nt|miss|skip|breach/.test(t)?'interruption_or_missed':/partial/.test(t)?'partial_completion':/complete|success|done/.test(t)?'completed':'other';counts[k]=(counts[k]||0)+1});
    var sessions=arr(s.sessions);var starts=sessions.length,completed=sessions.filter(function(x){return /complete|done|finished/i.test(String(x.status||x.state||''))}).length;
    var patterns=[];if(counts.interruption_or_missed)patterns.push({pattern:'interruption_or_missed',count:counts.interruption_or_missed});if(counts.partial_completion)patterns.push({pattern:'partial_completion',count:counts.partial_completion});if(starts&&completed<starts)patterns.push({pattern:'low_recorded_completion',count:starts-completed});
    patterns.sort(function(a,b){return b.count-a.count});return {generatedAt:iso(),patterns:patterns.slice(0,8),sampleSize:ev.length+sessions.length,interpretation:'Patterns are operational signals, not diagnoses or character judgments.'};
  }
  function replan(){
    var s=state(),items=[];
    arr(s.assignments).forEach(function(a){if(a.status==='done')return;var d=daysUntil(a.due),score=(d<0?100:d<=1?80:d<=3?60:d<=7?40:15)+(a.priority==='high'?20:a.priority==='low'?-5:0);items.push({type:'assignment',id:a.id||a.title,title:a.title||'Assignment',subject:a.subject||'Academic',due:a.due||null,days:d,score:score})});
    arr(s.exams).forEach(function(e){var d=daysUntil(e.date);if(d<0)return;items.push({type:'exam',id:e.id||e.date,title:(e.subject||'Exam')+' exam preparation',subject:e.subject||'Academic',due:e.date,days:d,score:(d<=1?100:d<=3?85:d<=7?65:d<=14?40:20)+25})});
    items.sort(function(a,b){return b.score-a.score});
    var plan=items.slice(0,8).map(function(x,i){return {order:i+1,action:x.title,subject:x.subject,reason:x.days<0?'Overdue':x.days<=3?'Deadline pressure':x.type==='exam'?'Upcoming exam':'Open assignment',source:x.type,days:x.days}});
    var out={generatedAt:iso(),plan:plan,assumptions:['Only recorded assignments and exams are used.','Available time and capacity may still be unknown.'],override:'Human Override may supersede this plan.'};save(KEY+'/replan',out);return out;
  }
  function weeklyReport(date){
    var end=new Date(date||Date.now()),start=new Date(end);start.setDate(start.getDate()-6);var a=analytics(),f=failurePatterns(),s=state();
    var sessions=arr(s.sessions).filter(function(x){var d=new Date(x.date||x.createdAt||x.startedAt||0);return d>=start&&d<=end});
    var results=[];Object.keys(s.results||{}).forEach(function(sub){arr(s.results[sub]).forEach(function(r){var d=new Date(r.date||r.createdAt||0);if(d>=start&&d<=end)results.push({subject:sub,score:Number(r.score)})})});
    var avg=results.length?results.reduce(function(x,r){return x+r.score},0)/results.length:null;
    var report={period:{start:day(start),end:day(end)},generatedAt:iso(),headline:results.length?'Recorded academic results are available for this week.':'No weekly result records were found.',metrics:{studySessions:sessions.length,results:results.length,average:avg==null?null:+avg.toFixed(1),openAssignments:a.overall.openAssignments,upcomingExams:a.overall.upcomingExams},riskAreas:a.subjects.slice(0,3),failurePatterns:f.patterns,nextPlan:replan().plan.slice(0,5),limitations:['This report uses recorded app data only.','It does not infer motivation, ability, emotions, or causes from the data.']};save(KEY+'/weekly/'+report.period.end,report);return report;
  }
  function auditRules(){
    var names=['nori-human-override-rules.json','nori-system-integrity-rules.json','nori-exam-result-rules.json','nori-award-rules.json'];var issues=[];var loaded=[];
    names.forEach(function(name){try{var req=new XMLHttpRequest();req.open('GET',name,false);req.send(null);if(req.status>=200&&req.status<300){var j=JSON.parse(req.responseText);loaded.push({name:name,data:j});}else issues.push({severity:'unknown',rule:name,message:'Could not load rule file in this environment.'})}catch(e){issues.push({severity:'unknown',rule:name,message:'Rule audit could not inspect this file.'})}});
    var precedence=['human override','system integrity','recovery','academic priority','convenience'];
    loaded.forEach(function(x){var text=JSON.stringify(x.data).toLowerCase();if(/physical|push.?up|squat|workout|exercise/.test(text))issues.push({severity:'warning',rule:x.name,message:'Contains physical-action language; review to ensure consequences are not physical punishment.'});});
    var out={generatedAt:iso(),rules:loaded.map(function(x){return x.name}),precedence:precedence,issues:issues,method:'Static consistency audit; it does not replace human review.'};save(KEY+'/audit',out);return out;
  }
  function lastWeekly(){var keys=[];for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(k&&k.indexOf(KEY+'/weekly/')===0)keys.push(k)}keys.sort();return keys.length?load(keys[keys.length-1],null):null}
  function snapshot(){return {analytics:analytics(),failures:failurePatterns(),replan:replan(),weekly:lastWeekly(),audit:auditRules()}}
  function render(){
    var wrap=noriEl('section',{class:'nori-tier3-panel'}),head=noriEl('div',{class:'nori-tier3-head'});head.appendChild(noriEl('div',{class:'nori-tier3-eyebrow',text:'KAGE / SYSTEM INTELLIGENCE'}));head.appendChild(noriEl('h2',{text:'Serious KAGE System'}));head.appendChild(noriEl('p',{text:'Analytics, replanning, failure patterns, weekly intelligence and rule integrity.'}));wrap.appendChild(head);
    var grid=noriEl('div',{class:'nori-tier3-grid'});var a=analytics(),f=failurePatterns(),r=replan(),q=lastWeekly()||weeklyReport();
    function card(title,body){var c=noriEl('article',{class:'nori-tier3-card'});c.appendChild(noriEl('h3',{text:title}));c.appendChild(body);return c}
    var ab=noriEl('div',{});ab.appendChild(noriEl('strong',{text:String(a.overall.openAssignments)}));ab.appendChild(noriEl('span',{text:' open assignments'}));ab.appendChild(noriEl('br'));ab.appendChild(noriEl('strong',{text:String(a.overall.upcomingExams)}));ab.appendChild(noriEl('span',{text:' exams within 14 days'}));grid.appendChild(card('ADVANCED ANALYTICS',ab));
    var rb=noriEl('div',{});if(!r.plan.length)rb.appendChild(noriEl('p',{text:'No recorded assignments or exams require replanning.'}));r.plan.slice(0,3).forEach(function(x){rb.appendChild(noriEl('div',{class:'nori-tier3-row',text:x.order+'. '+x.action+' — '+x.reason}))});grid.appendChild(card('AUTOMATIC REPLAN',rb));
    var fb=noriEl('div',{});if(!f.patterns.length)fb.appendChild(noriEl('p',{text:'No recurring failure pattern is supported by recorded events yet.'}));f.patterns.slice(0,3).forEach(function(x){fb.appendChild(noriEl('div',{class:'nori-tier3-row',text:x.pattern.replace(/_/g,' ')+' · '+x.count}))});grid.appendChild(card('FAILURE PATTERNS',fb));
    var qb=noriEl('div',{});qb.appendChild(noriEl('div',{class:'nori-tier3-row',text:q.period.start+' → '+q.period.end}));qb.appendChild(noriEl('div',{class:'nori-tier3-row',text:q.metrics.results+' results · '+q.metrics.studySessions+' study sessions'}));qb.appendChild(noriEl('div',{class:'nori-tier3-row',text:q.headline}));grid.appendChild(card('WEEKLY INTELLIGENCE',qb));
    var audit=auditRules(),ib=noriEl('div',{});ib.appendChild(noriEl('div',{class:'nori-tier3-row',text:audit.issues.length+' audit issue(s) requiring review'}));ib.appendChild(noriEl('div',{class:'nori-tier3-row',text:'Human Override remains highest authority.'}));grid.appendChild(card('RULE AUDIT',ib));
    wrap.appendChild(grid);var actions=noriEl('div',{class:'nori-tier3-actions'});['RECALCULATE','WEEKLY REPORT','AUDIT RULES'].forEach(function(t,i){var b=noriEl('button',{class:'nori-btn nori-btn-ghost',text:t});b.onclick=function(){if(i===0){analytics();replan();failurePatterns()}else if(i===1)weeklyReport();else auditRules();noriRoute()};actions.appendChild(b)});wrap.appendChild(actions);return wrap;
  }
  g.noriKageTier3={analytics:analytics,failurePatterns:failurePatterns,replan:replan,weeklyReport:weeklyReport,auditRules:auditRules,snapshot:snapshot,render:render};
  g.noriKageGetWeeklyReport=function(){return lastWeekly()||weeklyReport()};
})(window);
