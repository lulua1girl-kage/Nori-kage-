const {cors,requireUser,rateLimit,userRateLimit,bodyLimit,parsedBodyLimit,safeError}=require("./_security");
/* NORI deterministic decision API with persistent brain state. */
const path = require("path");
const brain = require(path.join(process.cwd(), "brain-engine", "brain"));
const canonicalState = require("./canonicalState");
const stateWriter = require("./stateWriter");

const ACTIONS = {
  processAcademicEvent: (a) => brain.processAcademicEvent(a[0]),
  requestOverride: (a) => brain.requestOverride(a[0], a[1], a[2]),
  completeRecovery: (a) => brain.completeRecovery(a[0], a[1]),
  escalateToDegree3: (a) => brain.escalateToDegree3(a[0], a[1], a[2]),
  advanceMasteryGate: (a) => brain.advanceMasteryGate(a[0], a[1], a[2]),
  escalateToDegree4: (a) => brain.escalateToDegree4(a[0], a[1], a[2]),
  checkAntiGaming: (a) => brain.checkAntiGaming(a[0]),
  consolidateEvents: (a) => brain.consolidateEvents(a[0]),
  startStabilityCycle: (a) => brain.startStabilityCycle(a[0], a[1]),
  logStabilityDay: (a) => brain.logStabilityDay(a[0], a[1]),
  escalateToDegree5: (a) => brain.escalateToDegree5(a[0], a[1], a[2]),
  reviewHandbookBoundary: (a) => brain.reviewHandbookBoundary(a[0], a[1]),
  finalizeHandbookTransition: (a) => brain.finalizeHandbookTransition(a[0], a[1], a[2]),
  meritRedeem: (a) => brain.meritShop.redeem(a[0], a[1], a[2]),
  meritRedeemLevelTier: (a) => brain.meritShop.redeemLevelTier(a[0], a[1], a[2], a[3]),
  getEvent: (a) => brain.auditEngine.getEvent(a[0]),
  listEvents: () => brain.auditEngine.all(),
  getAwardCatalog: (a) => brain.getAwardCatalog(a[0] ?? null),
  getAward: (a) => brain.getAward(a[0]),
  checkAward: (a) => brain.checkAward(a[0], a[1]),
  createMeritLedger: () => brain.createMeritLedger(),
  grantAward: (a) => { const ledger=a[0]; const result=brain.grantAward(ledger,a[1],a[2],a[3]??null); return {...result,ledger}; },
  grantScoreBandMerit: (a) => { const ledger=a[0]; const result=brain.grantScoreBandMerit(ledger,a[1],a[2]??"academic_score",a[3]??null); return {...result,ledger}; },
};

const DEFAULT_STATE = { version: 1, events: [], meritLedger: null, updatedAt: null };
module.exports = async function handler(req,res) {
  cors(req,res);
  res.setHeader("Access-Control-Allow-Methods","POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers","Content-Type, Authorization");
  if(req.method==="OPTIONS"){res.status(204).end();return;}
  if(req.method!=="POST"){res.status(405).json({error:"POST only"});return;}
  const action=req.body&&req.body.action, args=(req.body&&req.body.args)||[];
  const fn=ACTIONS[action];
  if(!fn){res.status(400).json({error:`Unknown action "${action}"`,validActions:Object.keys(ACTIONS)});return;}
  if (!bodyLimit(req)) { res.status(413).json({error:"Request too large"}); return; }
  if (!rateLimit(req,"decide",120,60000)) { res.status(429).json({error:"Rate limit exceeded"}); return; }
  try {
    const user=await requireUser(req,res);
    if(!user) return;
    if(!parsedBodyLimit(req.body, 1500000)){res.status(413).json({error:"Request body too large"});return;}
    if(!userRateLimit(req,user.id,"decide-user",60,60000)){res.status(429).json({error:"User rate limit exceeded"});return;}

    const contract=stateWriter.validateAction(action,args);
    const canonical=await canonicalState.getState(user.id);
    const baseState=canonical && canonical.state && typeof canonical.state === "object" ? canonical.state : DEFAULT_STATE;
    const state={...DEFAULT_STATE,...baseState};
    brain.auditEngine.hydrate(Array.isArray(state.events)?state.events:[]);

    // Read actions are read-only. They never receive a writable state object and
    // never create an audit event merely because a screen asked for data.
    if(stateWriter.READ_ACTIONS.has(contract.action)) {
      const result=fn(contract.args);
      res.status(200).json({ok:true,result,state,canonicalVersion:Number(canonical.state_version||0),stateHash:canonical.state_hash,authority:"CANONICAL_SERVER_STATE",readOnly:true});
      return;
    }

    let ledger=state.meritLedger;
    if(!ledger && action.startsWith("grant")) ledger=brain.createMeritLedger();
    const effectiveArgs=contract.args.slice();
    if(action.startsWith("grant") && ledger) effectiveArgs[0]=ledger;
    const result=fn(effectiveArgs);
    if(result && result.ledger) state.meritLedger=result.ledger;
    else if(action.startsWith("grant") && ledger) state.meritLedger=ledger;
    state.events=brain.auditEngine.snapshot();
    state.updatedAt=new Date().toISOString();

    const committed=await stateWriter.commit({
      userId:user.id,
      expectedVersion:Number(canonical.state_version||0),
      expectedHash:String(canonical.state_hash||""),
      nextState:state,
      action,
      result
    });
    const committedState=committed.state || state;
    res.status(200).json({ok:true,result,state:committedState,persisted:true,authority:"CANONICAL_SERVER_STATE",canonicalVersion:Number(committed.state_version||0),stateHash:committed.state_hash,auditId:committed.audit_id});
  } catch(err) {
    const message=String(err && err.message || err);
    if(message.includes("canonical_state_version_conflict")) {
      res.status(409).json({ok:false,error:"State changed before this mutation committed",code:"CANONICAL_STATE_CONFLICT",retryable:true});
      return;
    }
    if(message.includes("action_not_permitted") || message.includes("client_user_target_forbidden") || message.includes("invalid_action") || message.includes("invalid_action_args") || message.includes("read_action_cannot_mutate")) {
      res.status(400).json({ok:false,error:"Mutation request rejected",code:"INVALID_MUTATION_REQUEST"});
      return;
    }
    res.status(500).json({ok:false,error:safeError(err)});
  }
};
