const {cors,requireUser,rateLimit,userRateLimit,bodyLimit,parsedBodyLimit,safeError}=require("./_security");
/* ==========================================================================
   NORI — PHOTO VERIFICATION (image analysis)
   ==========================================================================
   Same deployment pattern as the other api/*.js files. Takes a photo (base64)
   plus what it's supposed to show, and asks a vision-capable model whether
   the image plausibly supports the claim. Gemini primary, OpenAI fallback —
   same two providers as api/brain.js, both support image input, so this
   reuses your existing GEMINI_API_KEY / OPENAI_API_KEY env vars, nothing new
   to configure.

   HONEST LIMITS, stated plainly rather than oversold:
   - This is plausibility analysis, not proof. A model looking at a single
     photo cannot confirm WHEN it was taken, WHO took it, or whether it's
     staged — it can only assess whether the image's visible content is
     consistent with the claim (e.g. "does this look like a completed
     Chemistry worksheet" vs "this is a photo of a beach").
   - Treat the result as a supporting signal for Nori's coaching
     conversation, not as an unforgeable checkmark on its own.
   ========================================================================== */

const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const OPENAI_MODEL = process.env.OPENAI_MODEL || "gpt-5.2-chat-latest";
const OPENAI_BACKUP_MODEL = process.env.OPENAI_BACKUP_MODEL || OPENAI_MODEL;
const OPENAI_BACKUP_BASE_URL = process.env.OPENAI_BACKUP_BASE_URL || "https://api.openai.com/v1";

function buildPrompt(claim) {
  return [
    "You are looking at a photo a student submitted as evidence for this claim:",
    "\"" + claim + "\"",
    "",
    "Assess honestly whether the image's visible content is plausibly consistent with that claim.",
    "You cannot confirm when the photo was taken or that it wasn't staged \u2014 only whether what's",
    "actually visible in the image supports or contradicts the claim. Be specific about what you",
    "see. Do not be generous just because a photo was submitted \u2014 a blank page, an unrelated",
    "object, or a photo of a screen showing something else should be flagged as NOT supporting it.",
    "",
    "Respond with ONLY a JSON object, no prose, no markdown fences, exactly this shape:",
    '{ "plausible": true or false, "confidence": "high"|"medium"|"low",',
    '  "whatISee": "one short factual sentence describing the actual image content",',
    '  "assessment": "one short sentence explaining the plausible/not-plausible call" }'
  ].join("\n");
}

async function callGeminiVision(prompt, base64Image, mimeType) {
  const resp = await fetch(
    "https://generativelanguage.googleapis.com/v1beta/models/" + GEMINI_MODEL + ":generateContent",
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": process.env.GEMINI_API_KEY },
      body: JSON.stringify({
        contents: [{
          role: "user",
          parts: [
            { text: prompt },
            { inline_data: { mime_type: mimeType, data: base64Image } }
          ]
        }]
      })
    }
  );
  if (!resp.ok) {
    const errText = await resp.text().catch(function () { return ""; });
    throw new Error("Gemini " + resp.status + ": " + errText.slice(0, 300));
  }
  const data = await resp.json();
  const parts = data.candidates && data.candidates[0] && data.candidates[0].content && data.candidates[0].content.parts;
  const text = parts && parts.map(function (p) { return p.text || ""; }).join("");
  if (!text) throw new Error("Gemini returned no text");
  return text;
}

async function callOpenAIVision(baseUrl, apiKey, model, prompt, base64Image, mimeType) {
  const resp = await fetch(baseUrl.replace(/\/$/, "") + "/chat/completions", {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": "Bearer " + apiKey },
    body: JSON.stringify({
      model: model,
      messages: [{
        role: "user",
        content: [
          { type: "text", text: prompt },
          { type: "image_url", image_url: { url: "data:" + mimeType + ";base64," + base64Image } }
        ]
      }],
      max_tokens: 400
    })
  });
  if (!resp.ok) {
    const errText = await resp.text().catch(function () { return ""; });
    throw new Error(baseUrl + " " + resp.status + ": " + errText.slice(0, 300));
  }
  const data = await resp.json();
  const text = data.choices && data.choices[0] && data.choices[0].message && data.choices[0].message.content;
  if (!text) throw new Error("OpenAI-compatible endpoint returned no text");
  return text;
}

module.exports = async function handler(req, res) {
  cors(req,res);
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  
  if (req.method === "OPTIONS") { res.status(204).end(); return; }
  if (req.method !== "POST") { res.status(405).json({ error: "POST only" }); return; }
  if (!bodyLimit(req)) { res.status(413).json({error:"Request too large"}); return; }
  if (!rateLimit(req,"verify-photo.js",60,60000)) { res.status(429).json({error:"Rate limit exceeded"}); return; }
  const authUser = await requireUser(req,res);
  if (!authUser) return;
  if (!parsedBodyLimit(req.body, 1500000)) { res.status(413).json({error:"Request body too large"}); return; }
  if (!userRateLimit(req, authUser.id, "verify-photo-user", 12, 60000)) { res.status(429).json({error:"User rate limit exceeded"}); return; }

  const claim = (req.body && req.body.claim || "").trim();
  const base64Image = req.body && req.body.imageBase64;
  const mimeType = (req.body && req.body.mimeType) || "image/jpeg";
  if (!claim || !base64Image) { res.status(400).json({ error: "Missing claim or imageBase64" }); return; }

  // Hard rule, enforced here directly (not just at the brain's action layer,
  // in case this endpoint is ever called another way): photo verification
  // exists only for academic evidence, never for showering, hygiene,
  // exercise, or anything bodily.
  const forbiddenTerms = [
    "shower", "bath", "hygiene", "wash", "naked", "body", "exercise", "workout",
    "gym", "push-up", "pushup", "squat", "weight", "physical", "undressed", "shirtless"
  ];
  const lowerClaim = claim.toLowerCase();
  if (forbiddenTerms.some(function (t) { return lowerClaim.indexOf(t) !== -1; })) {
    res.status(400).json({ error: "This endpoint doesn't verify hygiene, exercise, or bodily claims — academic evidence only." });
    return;
  }

  const prompt = buildPrompt(claim);
  const attempted = [];

  async function respondWith(raw, provider) {
    const cleaned = raw.trim().replace(/^```json\s*/i, "").replace(/```$/, "").trim();
    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch (parseErr) {
      res.status(502).json({ error: "Model returned unparseable output", raw: cleaned });
      return;
    }
    res.status(200).json({
      plausible: !!parsed.plausible,
      confidence: parsed.confidence || "low",
      whatISee: parsed.whatISee || "",
      assessment: parsed.assessment || "",
      provider: provider
    });
  }

  if (process.env.GEMINI_API_KEY) {
    try {
      const raw = await callGeminiVision(prompt, base64Image, mimeType);
      await respondWith(raw, "gemini");
      return;
    } catch (err) {
      attempted.push("gemini: " + err.message);
      console.error("Gemini vision failed, trying OpenAI:", err.message);
    }
  }

  if (process.env.OPENAI_API_KEY) {
    try {
      const raw = await callOpenAIVision("https://api.openai.com/v1", process.env.OPENAI_API_KEY, OPENAI_MODEL, prompt, base64Image, mimeType);
      await respondWith(raw, "openai");
      return;
    } catch (err) {
      attempted.push("openai: " + err.message);
      console.error("OpenAI vision failed, trying 2nd GPT backup:", err.message);
    }
  }

  if (process.env.OPENAI_BACKUP_API_KEY) {
    try {
      const raw = await callOpenAIVision(OPENAI_BACKUP_BASE_URL, process.env.OPENAI_BACKUP_API_KEY, OPENAI_BACKUP_MODEL, prompt, base64Image, mimeType);
      await respondWith(raw, "openai-backup");
      return;
    } catch (err) {
      attempted.push("openai-backup: " + err.message);
    }
  }

  if (attempted.length) {
    res.status(502).json({ error: "All configured vision-capable providers failed", detail: attempted });
  } else {
    res.status(500).json({ error: "No AI provider configured. Set at least one of GEMINI_API_KEY, OPENAI_API_KEY, OPENAI_BACKUP_API_KEY." });
  }
};
