const crypto = require("crypto");

function cfg(){
  return {
    url: String(process.env.SUPABASE_URL || "").replace(/\/$/, ""),
    key: String(process.env.SUPABASE_SERVICE_ROLE_KEY || "")
  };
}
function headers(){
  const c=cfg();
  return { apikey:c.key, Authorization:"Bearer "+c.key, "Content-Type":"application/json" };
}
function ready(){ const c=cfg(); return !!(c.url && c.key); }
function hashState(state){
  return crypto.createHash("sha256").update(JSON.stringify(state || {})).digest("hex");
}
async function rest(path, init){
  const c=cfg();
  if(!ready()) throw new Error("canonical_state_backend_unconfigured");
  const r=await fetch(c.url+path,Object.assign({headers:headers()},init||{}));
  const text=await r.text();
  if(!r.ok) throw new Error("canonical_state_backend_error:"+r.status+":"+text.slice(0,180));
  return text ? JSON.parse(text) : null;
}
async function getState(userId){
  const rows=await rest("/rest/v1/nori_canonical_state?user_id=eq."+encodeURIComponent(userId)+"&select=user_id,schema_version,state_version,state,state_hash,updated_at,updated_by&limit=1");
  return Array.isArray(rows) && rows[0] ? rows[0] : {
    user_id:userId, schema_version:1, state_version:0, state:{}, state_hash:hashState({}), updated_at:null, updated_by:"none"
  };
}
async function getAudit(userId, limit=100){
  const safe=Math.max(1,Math.min(500,Number(limit)||100));
  return await rest("/rest/v1/nori_audit_events?user_id=eq."+encodeURIComponent(userId)+"&select=id,sequence,event_type,schema_version,source,authority,verified,payload,created_at&order=sequence.desc&limit="+safe);
}
async function commitMutation(userId, mutation){
  if(!mutation || typeof mutation!=='object') throw new Error('invalid_state_mutation');
  const body={
    p_user_id:userId,
    p_expected_version:Number(mutation.expectedVersion||0),
    p_expected_hash:String(mutation.expectedHash||''),
    p_next_state:mutation.nextState && typeof mutation.nextState==='object' ? mutation.nextState : {},
    p_event_type:String(mutation.eventType||'DECISION_EXECUTED').slice(0,120),
    p_source:String(mutation.source||'server').slice(0,120),
    p_authority:String(mutation.authority||'KAGE_DETERMINISTIC_ENGINE').slice(0,120),
    p_verified:mutation.verified===true,
    p_payload:mutation.payload && typeof mutation.payload==='object' ? mutation.payload : {}
  };
  const rows=await rest('/rest/v1/rpc/nori_apply_canonical_mutation',{method:'POST',body:JSON.stringify(body)});
  const row=Array.isArray(rows)?rows[0]:rows;
  if(!row) throw new Error('canonical_mutation_empty_result');
  return row;
}

function buildContext(state,audit){
  return {
    canonicalState:state,
    canonicalAudit:Array.isArray(audit)?audit:[],
    authority:"CANONICAL_SERVER_STATE",
    clientStateAcceptedAsEvidence:false,
    stateHash:state.state_hash,
    stateVersion:state.state_version,
    auditCount:Array.isArray(audit)?audit.length:0
  };
}
module.exports={ready,getState,getAudit,buildContext,hashState,commitMutation};
