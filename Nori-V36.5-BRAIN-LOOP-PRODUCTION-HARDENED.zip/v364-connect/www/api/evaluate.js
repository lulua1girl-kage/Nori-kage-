const {cors,requireUser,rateLimit,userRateLimit,bodyLimit,parsedBodyLimit,safeError}=require("./_security");
/* ==========================================================================
   NORI PHASE — AI EVALUATION BACKEND
   ==========================================================================
   Serverless endpoint (same deployment pattern as api/checkin.js). Takes a
   reported result ("I got 65% on my chemistry test, I was really tired
   this week") plus that subject's recent evaluation history, and returns:

     - the Band/Degree classification (Exam Result System)
     - a Human Override screening, using the priority-severity formula
       ported from the user's own kage.js, so a circumstance only pauses
       or softens the plan proportionally to how real/severe it is —
       never an all-or-nothing excuse switch
     - any awards earned (Award System)
     - the exact form entries this should write, validated against the
       real NORI PHASE schema before they're trusted
     - a proposed recovery schedule (dated study blocks)
     - one summary sentence for voice/text readback

   DEPLOYMENT: identical to api/checkin.js — same project, same
   ANTHROPIC_API_KEY env var. Put this file at api/evaluate.js alongside
   it. Needs these JSON files in the project root (all provided):
     nori-form-schema-full.json
     nori-exam-result-rules.json
     nori-award-rules.json
     nori-human-override-rules.json
   ========================================================================== */

const Anthropic = require("@anthropic-ai/sdk");
const fs = require("fs");
const path = require("path");

function loadJSON(name) {
  return JSON.parse(fs.readFileSync(path.join(process.cwd(), name), "utf8"));
}

const FORM_SCHEMA = loadJSON("nori-form-schema-full.json");
const EXAM_RULES = loadJSON("nori-exam-result-rules.json");
const AWARD_RULES = loadJSON("nori-award-rules.json");
const OVERRIDE_RULES = loadJSON("nori-human-override-rules.json");

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function buildSystemPrompt() {
  return [
    "You are the evaluation layer for NORI PHASE, a personal academic tracking app",
    "built around a specific handbook. A student gives a short spoken or typed report",
    "of a result (a score, a subject, sometimes a mentioned circumstance). Your job:",
    "",
    "1. IDENTIFY the subject and numeric score (0-100 percent, or converted from a",
    "   points score like '480/600' using the entranceExam rules if it's an entrance",
    "   model exam). If no clear score is stated, do not fabricate one.",
    "",
    "2. CLASSIFY using the Exam Result System below: find the Band from the score,",
    "   and determine the Degree using degreeEscalationRule. SUBJECT_HISTORY below is",
    "   an object keyed by subject name, each value a list of that subject's recent",
    "   prior evaluations (date/band/degree) \u2014 use only the entries under the",
    "   subject you identified in step 1. No history for that subject = Degree 1.",
    "   List the exact recovery actions for that Degree x Band from the rules.",
    "   A score at or above the 80 academic floor is NOT a failure \u2014 do not classify",
    "   a Degree/Band for it at all; route it straight to award consideration instead.",
    "",
    "3. SCREEN for Human Override using the rules below. Only flag a circumstance if",
    "   the check-in text actually, specifically describes one (not vague filler).",
    "   If flagged, estimate the six factors (importance, weakness, difficulty,",
    "   immediacy, evidence, impact), each 0-10, from what was actually said \u2014 be",
    "   conservative, don't inflate factors the text doesn't support \u2014 then compute",
    "   the score with scoreFormula and map it to a level via `levels`. Apply",
    "   overrideVsExcuseGuard: if SUBJECT_HISTORY shows this same vague circumstance",
    "   claimed repeatedly with no new specific evidence, do NOT grant an adjustment;",
    "   classify normally and say so plainly and kindly in the summary \u2014 name the",
    "   pattern, don't accuse. This check exists so the student can't use Override to",
    "   avoid accountability for genuinely repeating patterns \u2014 apply it honestly.",
    "",
    "4. CREDIT AWARDS using the Award System below, only for scores at or above 80,",
    "   only using meritPoints/distinctionCategories/etc. as written \u2014 never invent",
    "   a new award reason. Respect No Double Counting and Evidence First.",
    "",
    "5. PROPOSE form entries using ONLY forms/columns/fixedTable rows from",
    "   FORM_SCHEMA below \u2014 never invent a form, column key, fixedTable row label,",
    "   or select option that isn't listed there. Routing guidance:",
    "   - Any classified result (Degree 1+) \u2192 the matching Phase 1 subject",
    "     assessment-record form (table-log) AND, for Degree 2+, the Phase 2",
    "     error-notebook/error-classification table-log forms.",
    "   - Degree 3+ \u2192 also propose Phase 5 backlog-management forms",
    "     (academic-backlog-tracker row, or the backlog-subject-recovery-map",
    "     snapshot-log row for that subject).",
    "   - Degree 4-5 \u2192 also propose the Phase 5 emergency-recovery snapshot-log",
    "     forms (emergency-recovery-card, emergency-recovery-priority-order).",
    "   - A verified Human Override at High or Critical level \u2192 do NOT propose a",
    "     Phase 1/2 breach-style entry yet \u2014 propose only a Phase 5",
    "     recovery-decision-page or emergency-recovery-card note capturing the",
    "     circumstance, and set humanOverride.adjustment accordingly.",
    "   - A qualifying award \u2192 the matching Phase 4 form (award-record for a",
    "     Merit entry, distinction-tracker fixedTable row for a Distinction, etc.)",
    "   For a table-log form, `row` keys must exactly match its columns[].key.",
    "   For a snapshot-log form with fixedTable, `fixedTableRow` must be one exact",
    "   string from that form's fixedTable.rows, and `values` keys must match",
    "   fixedTable.columns[].key. Leave anything not actually supported by the",
    "   check-in as an empty string \u2014 never guess. Use today's date " + todayISO() +
    "   for any date field with nothing stated.",
    "",
    "6. PROPOSE a recoverySchedule: a short list of dated study blocks matching the",
    "   Degree's recovery actions (durations/day-counts come directly from the",
    "   handbook text, e.g. a '60-minute recovery' becomes one block; a '14-day",
    "   Academic Recovery Protocol' becomes one block per day for 14 days starting",
    "   tomorrow). If Human Override paused the plan, return an empty schedule and",
    "   say so in the summary instead.",
    "",
    "Respond with ONLY a JSON object, no prose, no markdown fences, exactly this shape:",
    JSON.stringify({
      subject: "string or null",
      reportedScore: "number 0-100 or null",
      band: "string like 'Band 3' or null",
      degree: "string like 'Degree 2' or null",
      recoveryActions: ["string", "..."],
      humanOverride: {
        circumstanceDetected: "boolean",
        category: "string or null",
        priorityLevel: "Critical|High|Medium|Low|Monitor or null",
        adjustment: "pause|extend_deadline|reduce_plan|small_adjustment|none",
        note: "string"
      },
      awards: [{ level: "Merit|Distinction|Excellence|Honor|Elite", points: "number or null", reason: "string" }],
      formEntries: [{
        phaseId: "string", systemId: "string", formId: "string", kind: "table-log|snapshot-log",
        row: "object (table-log only)",
        fixedTableRow: "string (snapshot-log fixedTable only)",
        values: "object (snapshot-log fixedTable only)"
      }],
      recoverySchedule: [{ date: "YYYY-MM-DD", task: "string", durationMinutes: "number" }],
      summary: "one short paragraph, plain language, for voice/text readback: what was understood, the classification, any override note, and what will be saved"
    }),
    "",
    "EXAM_RESULT_SYSTEM:", JSON.stringify(EXAM_RULES),
    "AWARD_SYSTEM:", JSON.stringify(AWARD_RULES),
    "HUMAN_OVERRIDE_RULES:", JSON.stringify(OVERRIDE_RULES),
    "FORM_SCHEMA:", JSON.stringify(FORM_SCHEMA)
  ].join("\n");
}

function validateFormEntries(entries) {
  const byFormId = {};
  FORM_SCHEMA.forEach(function (f) { byFormId[f.formId] = f; });

  return (entries || []).filter(function (e) {
    const formDef = byFormId[e.formId];
    if (!formDef || formDef.phaseId !== e.phaseId || formDef.systemId !== e.systemId || formDef.kind !== e.kind) return false;

    if (e.kind === "table-log") {
      if (!formDef.columns) return false;
      const validKeys = formDef.columns.map(function (c) { return c.key; });
      Object.keys(e.row || {}).forEach(function (k) { if (validKeys.indexOf(k) === -1) delete e.row[k]; });
      return true;
    }

    if (e.kind === "snapshot-log") {
      if (!formDef.fixedTable) return false;
      if (formDef.fixedTable.rows.indexOf(e.fixedTableRow) === -1) return false;
      const validKeys = formDef.fixedTable.columns.map(function (c) { return c.key; });
      Object.keys(e.values || {}).forEach(function (k) { if (validKeys.indexOf(k) === -1) delete e.values[k]; });
      return true;
    }

    return false;
  });
}

module.exports = async function handler(req, res) {
  cors(req,res);
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  
  if (req.method === "OPTIONS") { res.status(204).end(); return; }
  if (req.method !== "POST") { res.status(405).json({ error: "POST only" }); return; }
  if (!bodyLimit(req)) { res.status(413).json({error:"Request too large"}); return; }
  if (!rateLimit(req,"evaluate.js",60,60000)) { res.status(429).json({error:"Rate limit exceeded"}); return; }
  const authUser = await requireUser(req,res);
  if (!authUser) return;
  if (!parsedBodyLimit(req.body, 1500000)) { res.status(413).json({error:"Request body too large"}); return; }
  if (!userRateLimit(req, authUser.id, "evaluate-user", 20, 60000)) { res.status(429).json({error:"User rate limit exceeded"}); return; }

  const transcript = (req.body && req.body.transcript || "").trim();
  const subjectHistory = (req.body && req.body.subjectHistory) || [];
  if (!transcript) { res.status(400).json({ error: "Missing transcript" }); return; }

  try {
    const response = await client.messages.create({
      model: "claude-sonnet-5",
      max_tokens: 3000,
      system: buildSystemPrompt(),
      messages: [{
        role: "user",
        content: "CHECK-IN: " + transcript + "\n\nSUBJECT_HISTORY: " + JSON.stringify(subjectHistory)
      }]
    });

    const raw = response.content
      .map(function (block) { return block.type === "text" ? block.text : ""; })
      .join("")
      .trim()
      .replace(/^```json\s*/i, "")
      .replace(/```$/, "")
      .trim();

    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (parseErr) {
      res.status(502).json({ error: "Model returned unparseable output", raw: raw });
      return;
    }

    parsed.formEntries = validateFormEntries(parsed.formEntries);
    res.status(200).json(parsed);
  } catch (err) {
    res.status(500).json({ error: "AI evaluation failed", detail: String(err && err.message || err) });
  }
};
