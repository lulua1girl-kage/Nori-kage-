/* V30 — Canonical State Writer Boundary.
 * Only authenticated server code reaches this module. It validates the mutation
 * envelope, prevents client-controlled target users, bounds payloads, and commits
 * state + audit atomically through the Supabase RPC.
 */
const canonicalState = require('./canonicalState');

const READ_ACTIONS = new Set([
  'getEvent','listEvents','getAwardCatalog','getAward','checkAward'
]);
const MUTATION_ACTIONS = new Set([
  'processAcademicEvent','requestOverride','completeRecovery','escalateToDegree3',
  'advanceMasteryGate','escalateToDegree4','checkAntiGaming','consolidateEvents',
  'startStabilityCycle','logStabilityDay','escalateToDegree5','reviewHandbookBoundary',
  'finalizeHandbookTransition','meritRedeem','meritRedeemLevelTier',
  'createMeritLedger','grantAward','grantScoreBandMerit'
]);

function isPlainObject(v){
  if(v===null || typeof v!=='object') return false;
  const p=Object.getPrototypeOf(v);
  return p===Object.prototype || p===null;
}
function walk(v, depth=0, asKey=false){
  if(depth>8) throw new Error('mutation_payload_too_deep');
  if(typeof v==='string') { if(v.length>12000) throw new Error('mutation_string_too_large'); return; }
  if(Array.isArray(v)){ if(v.length>200) throw new Error('mutation_array_too_large'); v.forEach(x=>walk(x,depth+1,false)); return; }
  if(isPlainObject(v)) { const keys=Object.keys(v); if(keys.length>100) throw new Error('mutation_object_too_large'); for(const k of keys){ if(k==='__proto__'||k==='prototype'||k==='constructor') throw new Error('unsafe_mutation_key'); if(/^(user_?id|owner_?id|account_?id|auth_?user_?id)$/i.test(k)) throw new Error('client_user_target_forbidden'); walk(v[k],depth+1,false); } }
  else if(v!==null && typeof v!=='number' && typeof v!=='boolean') throw new Error('unsupported_mutation_value');
}
function validateAction(action,args){
  if(typeof action!=='string' || !/^[A-Za-z][A-Za-z0-9_]{1,80}$/.test(action)) throw new Error('invalid_action');
  if(!MUTATION_ACTIONS.has(action) && !READ_ACTIONS.has(action)) throw new Error('action_not_permitted');
  if(!Array.isArray(args) || args.length>6) throw new Error('invalid_action_args');
  walk(args);
  // The authenticated user is always derived from the access token. These keys
  // must never be accepted as a client mechanism for selecting another user.
  return {action,args};
}
function isMutation(action){ return MUTATION_ACTIONS.has(action); }

async function commit({userId, expectedVersion, expectedHash, nextState, action, result}){
  if(!userId) throw new Error('missing_authenticated_user');
  if(!isMutation(action)) throw new Error('read_action_cannot_mutate');
  walk(nextState);
  const payload={action, result: result===undefined ? null : result};
  walk(payload);
  return canonicalState.commitMutation(userId, {
    expectedVersion:Number(expectedVersion||0), expectedHash:String(expectedHash||''),
    nextState, eventType:'DECISION_EXECUTED', source:'stateWriter:'+action,
    authority:'KAGE_DETERMINISTIC_ENGINE', verified:true, payload
  });
}

module.exports={READ_ACTIONS,MUTATION_ACTIONS,validateAction,isMutation,commit};
