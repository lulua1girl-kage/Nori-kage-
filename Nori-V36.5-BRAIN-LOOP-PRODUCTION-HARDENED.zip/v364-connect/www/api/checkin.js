const {cors,requireUser,rateLimit,userRateLimit,bodyLimit,parsedBodyLimit,safeError}=require("./_security");
/* ==========================================================================
   NORI PHASE — AI CHECK-IN BACKEND
   ==========================================================================
   A minimal serverless endpoint (Vercel-style: module.exports default
   handler(req, res)) that takes a spoken/typed check-in and asks Claude to
   decide which of NORI PHASE's table-log forms it belongs in, and what to
   fill in.

   WHY A BACKEND AT ALL:
   The Anthropic API cannot be called directly from a browser — it will
   reject cross-origin requests, and it should never see your API key
   client-side anyway. This function is the only place your API key lives.

   DEPLOYMENT (Vercel, the simplest path):
   1. Put this file at  api/checkin.js  in a project whose other files are
      your existing NORI PHASE site (index.html, nori-phase.css,
      nori-phase-app.js, nori-phase-data.js) plus nori-table-log-schema.json
      and nori-ai-checkin.js (both provided alongside this file).
   2. `npm init -y` then `npm install @anthropic-ai/sdk` in that project.
   3. In the Vercel dashboard, add an environment variable:
        ANTHROPIC_API_KEY = <your key from console.anthropic.com>
   4. `vercel deploy` (or connect the git repo in the Vercel dashboard).
   Vercel automatically turns anything in /api into a serverless function
   reachable at yoursite.vercel.app/api/checkin — no server to run yourself.

   If you'd rather use Netlify Functions or Cloudflare Workers instead, the
   logic below (steps 1-4 in the handler) is the same — only the function
   signature and how you read the request body changes.
   ========================================================================== */

const Anthropic = require("@anthropic-ai/sdk");
const fs = require("fs");
const path = require("path");

// Loaded once per cold start, not per request.
const FORM_SCHEMA = JSON.parse(
  fs.readFileSync(path.join(process.cwd(), "nori-table-log-schema.json"), "utf8")
);

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

function buildSystemPrompt() {
  return [
    "You are the intake layer for NORI PHASE, a personal academic tracking app.",
    "The user gives a short spoken or typed check-in describing what they studied,",
    "whether they studied at all, what subject/topic, and how it went.",
    "",
    "Your ONLY job: decide which of the app's existing table-log forms this",
    "check-in should create an entry in, and fill in only the columns that",
    "form actually has, using only information the user actually said.",
    "",
    "Rules:",
    "- Use ONLY forms and column keys from the schema below. Never invent a",
    "  form, a column key, or a select option that isn't listed.",
    "- Only fill a column if the check-in actually supports a value. Leave",
    "  anything unstated as an empty string \"\" — never guess or pad.",
    "- For a \"select\" column, the value MUST be exactly one of its listed",
    "  options, or \"\" if unclear.",
    "- For a \"date\" column with no date mentioned, use today's date: " + todayISO() + ".",
    "- It's fine to return zero forms if the check-in is too vague to safely",
    "  fill anything (e.g. just \"hey\" with no study content).",
    "- It's fine to return more than one form if the check-in clearly",
    "  supports separate entries in different systems (e.g. a subject",
    "  assessment record AND an error/obstacle log).",
    "- Do not fill in forms whose whole purpose (awards, certificates, rank,",
    "  backlog planning, etc.) has nothing to do with what was said. A plain",
    "  \"studied math today, went okay\" should usually match at most one or",
    "  two forms — not every form that happens to have a \"subject\" column.",
    "",
    "Respond with ONLY a JSON object, no prose, no markdown fences, matching",
    "exactly this shape:",
    '{ "entries": [ { "phaseId": "...", "systemId": "...", "formId": "...",',
    '    "row": { "<columnKey>": "<value>", ... } } ],',
    '  "summary": "one short plain-language sentence describing what was',
    '    understood and saved, for the app to read back to the user" }',
    "",
    "Form schema (the only forms/columns you may use):",
    JSON.stringify(FORM_SCHEMA)
  ].join("\n");
}

module.exports = async function handler(req, res) {
  // CORS: allows this endpoint to be called from a frontend hosted on a
  // different domain than the backend (e.g. site on GitHub Pages, backend
  // on Vercel). If frontend and backend share a domain this is harmless.
  cors(req,res);
  res.setHeader("Access-Control-Allow-Methods", "POST, OPTIONS");
  
  if (req.method === "OPTIONS") {
    res.status(204).end();
    return;
  }

  if (req.method !== "POST") {
    res.status(405).json({ error: "POST only" });
    return;
  }
  if (!bodyLimit(req, 500000)) { res.status(413).json({error:"Request too large"}); return; }
  if (!rateLimit(req,"checkin",60,60000)) { res.status(429).json({error:"Rate limit exceeded"}); return; }
  const authUser = await requireUser(req,res);
  if (!authUser) return;
  if (!parsedBodyLimit(req.body, 1500000)) { res.status(413).json({error:"Request body too large"}); return; }
  if (!userRateLimit(req, authUser.id, "checkin-user", 30, 60000)) { res.status(429).json({error:"User rate limit exceeded"}); return; }

  const transcript = (req.body && req.body.transcript || "").trim();
  if (!transcript) {
    res.status(400).json({ error: "Missing transcript" });
    return;
  }

  try {
    const response = await client.messages.create({
      model: "claude-sonnet-5",
      max_tokens: 1500,
      system: buildSystemPrompt(),
      messages: [{ role: "user", content: transcript }]
    });

    const raw = response.content
      .map(function (block) { return block.type === "text" ? block.text : ""; })
      .join("")
      .trim()
      .replace(/^```json\s*/i, "")
      .replace(/```$/, "")
      .trim();

    let parsed;
    try {
      parsed = JSON.parse(raw);
    } catch (parseErr) {
      res.status(502).json({ error: "Model returned unparseable output", raw: raw });
      return;
    }

    // Validate every entry against the real schema before trusting it —
    // never let the model write a form/column that doesn't exist.
    const byFormId = {};
    FORM_SCHEMA.forEach(function (f) { byFormId[f.formId] = f; });

    const validEntries = (parsed.entries || []).filter(function (e) {
      const formDef = byFormId[e.formId];
      if (!formDef || formDef.phaseId !== e.phaseId || formDef.systemId !== e.systemId) return false;
      const validKeys = formDef.columns.map(function (c) { return c.key; });
      Object.keys(e.row || {}).forEach(function (k) {
        if (validKeys.indexOf(k) === -1) delete e.row[k];
      });
      return true;
    });

    res.status(200).json({
      entries: validEntries,
      summary: parsed.summary || ""
    });
  } catch (err) {
    res.status(500).json({ error: "AI check-in failed", detail: String(err && err.message || err) });
  }
};
