# Nori Calendar Integration — 2026-09-15

- Added persistent Calendar screen with month grid and selected-day schedule.
- Added manual event memory with once/daily/weekdays/weekly/monthly/custom recurrence.
- Added recurrence end date, occurrence count, weekly day selection, skip exceptions, and occurrence completion memory.
- Automatically indexes assignments, exams, study sessions, active consequences, and recorded consequence decision events.
- Added Calendar access to the command header and Profile system links while preserving the five-item bottom navigation.
- Added subject-specific recovery scheduling from RECOVER.
- Routed calendar persistence through the existing Nori storage write hook so cloud sync/backup can observe calendar writes.
- Mirrored Calendar files into the Android `www` bundle.
