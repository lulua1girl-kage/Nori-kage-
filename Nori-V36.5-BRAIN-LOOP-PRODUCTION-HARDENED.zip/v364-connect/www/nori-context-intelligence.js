/* NORI CONTEXT INTELLIGENCE — unified context layer
 * Reuses existing calendar/study/exam/recovery stores. No duplicate tracker.
 * Decision order: emergency/override -> sleep -> study/exam protection -> normal.
 */
(function(g){
  'use strict';
  const KEY='nori_context_intelligence_v1';
  const APPS={
    instagram:{label:'Instagram',package:'com.instagram.android',category:'digital_social'},
    pinterest:{label:'Pinterest',package:'com.pinterest',category:'digital_social'},
    snapchat:{label:'Snapchat',package:'com.snapchat.android',category:'digital_social'},
    tiktok:{label:'TikTok',package:'com.zhiliaoapp.musically',category:'digital_social'},
    youtube:{label:'YouTube',package:'com.google.android.youtube',category:'entertainment'},
    wps:{label:'WPS Office',package:'cn.wps.moffice_eng',category:'academic'}
  };
  const defaults={sleepStart:'22:00',sleepEnd:'06:00',examEnhancedDays:14,examFinalDays:7,tempAccessMinutes:5,adaptiveStudyMinutes:45};
  const load=(k,d)=>{try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}};
  const save=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}};
  function cfg(){return Object.assign({},defaults,load(KEY,{}));}
  function hm(s){const p=String(s||'').split(':').map(Number);return (p[0]||0)*60+(p[1]||0)}
  function nowMin(d){d=d||new Date();return d.getHours()*60+d.getMinutes()}
  function inWindow(now,start,end){start=hm(start);end=hm(end);return start<=end?now>=start&&now<end:now>=start||now<end}
  function daysUntil(date,now){const a=new Date(date+'T00:00:00'),b=new Date((now||new Date()).toISOString().slice(0,10)+'T00:00:00');return Math.ceil((a-b)/86400000)}
  function safeArray(key){const v=load(key,[]);return Array.isArray(v)?v:[]}
  function studySessions(){return safeArray('nori_study_sessions')}
  function exams(){return safeArray('nori_exams')}
  function activeStudy(d){
    const date=d.toISOString().slice(0,10),m=nowMin(d);
    return studySessions().filter(s=>{
      if(s.status==='completed'||s.status==='skipped')return false;
      if(s.date && String(s.date).slice(0,10)!==date)return false;
      if(!s.time)return s.date===date;
      const start=hm(s.time),minutes=Number(s.minutes||45),end=start+minutes;
      return m>=start&&m<end;
    }).sort((a,b)=>(Number(b.priority||0)-Number(a.priority||0)))[0]||null;
  }
  function nearestExam(d){
    const date=d.toISOString().slice(0,10);
    return exams().filter(e=>e.date && e.date>=date).map(e=>Object.assign({},e,{daysUntil:daysUntil(String(e.date).slice(0,10),d)})).sort((a,b)=>a.daysUntil-b.daysUntil)[0]||null;
  }
  function classify(pkg){
    if(!pkg)return {label:'Unknown',category:'unknown',package:'',known:false};
    const p=String(pkg).toLowerCase();
    for(const k of Object.keys(APPS)){if(APPS[k].package===p)return Object.assign({},APPS[k],{known:true})}
    if(p.includes('office')||p.includes('docs')||p.includes('drive')||p.includes('acrobat')||p.includes('notion'))return {label:'Academic/Productivity',category:'academic',package:pkg,known:false};
    return {label:'Unknown app',category:'unknown',package:pkg,known:false};
  }
  function activeRecovery(){try{return typeof noriActiveConsequences==='function'?noriActiveConsequences():[]}catch(e){return []}}
  function smartPriority(){try{return window.noriSmart&&typeof noriSmart.smartMessage==='function'?noriSmart.smartMessage():null}catch(e){return null}}
  function integrityState(){try{const rows=window.noriSmart&&typeof noriSmart.integrity==='function'?noriSmart.integrity():[];return {ok:rows.every(x=>x.state==='CLEAR'),degraded:rows.filter(x=>x.state!=='CLEAR').map(x=>x.name)}}catch(e){return {ok:true,degraded:[]}}}
  function adaptiveStudy(d){
    const date=d.toISOString().slice(0,10),m=nowMin(d);
    return studySessions().filter(s=>s.date===date && (s.status==='active'||s.status==='in_progress'||s.status==='started')).map(s=>{
      const start=s.time?hm(s.time):Math.max(0,m-Number(s.minutes||45));
      const end=start+Number(s.minutes||45);
      return m>=start&&m<end?Object.assign({},s,{adaptive:true}):null;
    }).filter(Boolean).sort((a,b)=>Number(b.priority||0)-Number(a.priority||0))[0]||null;
  }

  function buildContext(d){
    d=d||new Date(); const c=cfg(),scheduledStudy=activeStudy(d),adaptive=scheduledStudy||adaptiveStudy(d),study=scheduledStudy||adaptive,exam=nearestExam(d);
    const sleep=inWindow(nowMin(d),c.sleepStart,c.sleepEnd),recovery=activeRecovery(),priority=smartPriority(),integrity=integrityState(),temporaryAccess=load('nori_temp_access',[]).filter(x=>Number(x.expiresAt)>Date.now());
    let mode='normal',level=0,reason='No active protection context.';
    if(sleep){mode='sleep';level=1;reason='Configured sleep-protection window is active.'}
    else if(study){mode='study';level=2;reason=(study.subject||'Academic')+' study block is active'+(study.topic?' for '+study.topic:'')+'.'}
    if(!sleep&&exam&&exam.daysUntil<=c.examEnhancedDays){mode=exam.daysUntil<=c.examFinalDays?'exam_final':'exam_enhanced';level=Math.max(level,exam.daysUntil<=c.examFinalDays?4:3);reason=(exam.subject||'Upcoming exam')+' is '+exam.daysUntil+' day(s) away; exam protection is active.'}
    if(recovery.length && mode!=='sleep') reason += ' Recovery-aware mode: restore normal functioning before adding escalation.';
    return {version:1,timestamp:d.toISOString(),mode,level,reason,confidence:study||exam?'high':'medium',sleepWindow:{start:c.sleepStart,end:c.sleepEnd,active:sleep},study:study?{id:study.id||null,subject:study.subject||'Academic',topic:study.topic||'',minutes:Number(study.minutes||45),date:study.date,time:study.time||null,adaptive:!!study.adaptive}:null,exam:exam?{id:exam.id||null,subject:exam.subject||'',title:exam.title||'',date:exam.date,daysUntil:exam.daysUntil}:null,recovery:{active:recovery.length>0,count:recovery.length},dailyCommand:priority?{label:priority[0],message:priority[1]}:null,integrity,settings:c,temporaryAccess};
  }
  function decision(pkg,d){
    const c=buildContext(d),a=classify(pkg);
    if(hasTempAccess(pkg))return {action:'allow',reason:'Temporary necessary/emergency access is active until expiry.',confidence:'high',app:a,context:c};
    if(a.category==='academic')return {action:'allow',reason:'Academic/productivity app detected.',confidence:'high',app:a,context:c};
    if(c.mode==='normal')return {action:'allow',reason:'No active academic protection window.',confidence:'high',app:a,context:c};
    if(a.category==='unknown')return {action:'allow',reason:'Unknown app: Nori will not assume harmful intent.',confidence:'low',app:a,context:c};
    if(c.mode==='sleep')return {action:'interrupt',reason:'Sleep protection is active.',confidence:'high',app:a,context:c};
    if(['digital_social','entertainment'].includes(a.category))return {action:'interrupt',reason:c.reason,confidence:c.confidence,app:a,context:c};
    return {action:'allow',reason:'No restriction matched this app.',confidence:'medium',app:a,context:c};
  }
  function tempAccess(pkg,reason){
    const c=cfg(),now=Date.now(),arr=load('nori_temp_access',[]).filter(x=>Number(x.expiresAt)>now);arr.push({package:pkg,reason:reason||'necessary',createdAt:now,expiresAt:now+c.tempAccessMinutes*60000});save('nori_temp_access',arr);return arr[arr.length-1];
  }
  function hasTempAccess(pkg){const now=Date.now(),arr=load('nori_temp_access',[]).filter(x=>Number(x.expiresAt)>now);save('nori_temp_access',arr);return arr.some(x=>x.package===pkg)}
  function audit(event){const a=load('nori_context_audit',[]);a.push(Object.assign({at:new Date().toISOString()},event));save('nori_context_audit',a.slice(-300));}
  function snapshot(){return buildContext(new Date())}
  g.NoriContextIntelligence={apps:APPS,config:cfg,configure:function(p){save(KEY,Object.assign({},cfg(),p||{}));return cfg()},classify,buildContext,decision,tempAccess,hasTempAccess,audit,snapshot};
  g.noriGetProtectionContext=snapshot;
  g.noriDecideAppAccess=decision;
  g.noriGrantTemporaryAccess=tempAccess;
})(window);

