# Nori Visual Pass — 2026-09-15

Updated HOME and RECOVER to more closely match the supplied reference screens while preserving live interactions.

- Reworked command header, quote panel, assignment split, priority/status/focus layout.
- Added reference-style monochrome artwork areas using user-supplied reference artwork crops.
- Reworked RECOVER hero, subject table, progress presentation, and recovery banner.
- Tightened typography, borders, spacing, button sizing, and mobile responsive behavior.
- Kept real data only; no sample grades or assignments were inserted.
- Mirrored web changes into the Android `www` bundle.
