/* NORI AVATAR CIRCLE — base interaction surface.
   Minimal monochrome/low-saturation ring. Character layer can be added later.
   Primary uses: voice chat + smart alarm/call. */
(function(g){'use strict';
  var mounted=false;
  function el(tag,cls,text){var x=document.createElement(tag);if(cls)x.className=cls;if(text!=null)x.textContent=text;return x}
  function mount(){
    if(mounted)return;var root=document.getElementById('nori-app');if(!root)return;
    var shell=el('section','nori-avatar-shell');shell.setAttribute('aria-label','Nori voice and alarm control');
    var ring=el('button','nori-avatar-circle');ring.type='button';ring.setAttribute('aria-label','Start Nori voice chat');
    ring.appendChild(el('span','nori-avatar-aura'));ring.appendChild(el('span','nori-avatar-core'));ring.appendChild(el('span','nori-avatar-character-slot'));
    ring.onclick=function(){
      ring.classList.add('is-listening');
      if(typeof noriListenOnce==='function')Promise.resolve(noriListenOnce()).then(function(t){ring.classList.remove('is-listening');if(t&&typeof noriMeetSendText==='function')noriMeetSendText(t);else if(t&&typeof noriSpeak==='function')noriSpeak('I heard you.');}).catch(function(){ring.classList.remove('is-listening')});
    };
    shell.appendChild(ring);var label=el('div','nori-avatar-label','VOICE / CALL');shell.appendChild(label);
    var alarm=el('button','nori-avatar-alarm','SMART ALARM');alarm.type='button';alarm.onclick=function(){location.hash='#/alarms'};shell.appendChild(alarm);
    root.appendChild(shell);mounted=true;
  }
  function state(emotion){var v=String(emotion||'calm').toLowerCase();var root=document.getElementById('nori-app');if(root)root.setAttribute('data-nori-avatar-state',v);var shell=document.querySelector('.nori-avatar-shell');if(shell){shell.setAttribute('data-presence-state',v);var label=shell.querySelector('.nori-avatar-label');if(label)label.textContent=v.toUpperCase();}}
  g.noriAvatarCircle={mount:mount,setState:state};
  g.noriAvatarSetState=state;
  setTimeout(mount,250);window.addEventListener('hashchange',function(){setTimeout(mount,50)});
})(window);
