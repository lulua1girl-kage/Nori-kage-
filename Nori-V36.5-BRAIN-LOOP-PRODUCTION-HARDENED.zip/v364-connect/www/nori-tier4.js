/* NORI TIER 4 — ADVANCED ORCHESTRATION
   Multi-model routing • Research mode • document/handbook RAG • tool workflows
   Side-effect rule: workflows PLAN by default; actions require explicit confirmation. */
(function(g){'use strict';
  var KEY='nori_tier4_v1';
  function load(k,fb){try{var v=JSON.parse(localStorage.getItem(k)||'null');return v==null?fb:v}catch(e){return fb}}
  function save(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function el(tag,attrs){var n=document.createElement(tag);attrs=attrs||{};Object.keys(attrs).forEach(function(k){if(k==='text')n.textContent=attrs[k];else n.setAttribute(k,attrs[k])});return n}
  function log(kind,data){var x=load(KEY+'/events',[]);x.push({at:new Date().toISOString(),kind:kind,data:data});save(KEY+'/events',x.slice(-100));}
  function request(payload){return fetch('/api/brain',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)}).then(function(r){return r.json().then(function(x){if(!r.ok)throw new Error(x.error||'Request failed');return x})})}
  function state(){var s={};try{s.results=typeof noriHistoryLoadAll==='function'?noriHistoryLoadAll():{}}catch(e){}try{s.assignments=typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():[]}catch(e){}try{s.exams=typeof noriExamsLoad==='function'?noriExamsLoad():[]}catch(e){}try{s.nextMove=typeof noriGetContextualNextMove==='function'?noriGetContextualNextMove():null}catch(e){}return s}
  function research(message,history){return request({mode:'research',message:message,history:history||[],stateSummary:state(),webSearch:true}).then(function(x){log('research',x);return x})}
  function rag(message,history){return request({mode:'document_rag',message:message,history:history||[],stateSummary:state()}).then(function(x){log('rag',x);return x})}
  function workflow(message,history){return request({mode:'workflow_plan',message:message,history:history||[],stateSummary:state()}).then(function(x){log('workflow_plan',x);return x})}
  function route(message){var t=String(message||'').toLowerCase();if(/\b(search|research|latest|current|verify online|look up|browse)\b/.test(t))return'research';if(/\b(handbook|kage rule|according to kage|what does the system say|document|pdf|rule)\b/.test(t))return'rag';if(/\b(do all|handle this|take care of|set up|organize|execute|workflow|automate)\b/.test(t))return'workflow';return'chat'}
  function render(){var wrap=el('section',{class:'nori-tier4-panel'});wrap.appendChild(el('div',{class:'nori-tier4-eyebrow',text:'KAGE / ADVANCED INTELLIGENCE'}));wrap.appendChild(el('h2',{text:'Advanced Operations'}));wrap.appendChild(el('p',{class:'nori-tier4-muted',text:'Research, document retrieval and multi-step planning. Side effects remain human-confirmed.'}));
    var grid=el('div',{class:'nori-tier4-grid'});
    function card(title,desc,fn){var c=el('article',{class:'nori-tier4-card'});c.appendChild(el('h3',{text:title}));c.appendChild(el('p',{text:desc}));var b=el('button',{class:'nori-btn nori-btn-ghost',text:'OPEN'});b.onclick=fn;c.appendChild(b);grid.appendChild(c)}
    card('RESEARCH MODE','Use current external sources only when you explicitly request research.',function(){window.dispatchEvent(new CustomEvent('nori:tier4:open',{detail:{mode:'research'}}))});
    card('HANDBOOK / RAG','Retrieve relevant KAGE documents before asking the model to explain them.',function(){window.dispatchEvent(new CustomEvent('nori:tier4:open',{detail:{mode:'rag'}}))});
    card('WORKFLOW PLANNER','Turn a complex request into ordered tool steps. No side effect runs without confirmation.',function(){window.dispatchEvent(new CustomEvent('nori:tier4:open',{detail:{mode:'workflow'}}))});
    wrap.appendChild(grid);return wrap;
  }
  g.noriTier4={research:research,rag:rag,workflow:workflow,route:route,render:render,events:function(){return load(KEY+'/events',[])}};
})(window);
