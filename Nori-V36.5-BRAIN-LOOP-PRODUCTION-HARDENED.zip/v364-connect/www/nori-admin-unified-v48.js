/* NORI V48 — Unified administrator identity + quiet admin control plane.
 * One logical admin identity can contain many verified sign-in emails.
 * Authorization remains server-side; this file is UI/state orchestration only.
 */
(function(){'use strict';
  const KEY='nori.admin.identity.v48';
  const defaults={displayName:'Administrator',groupId:'admin-primary',emails:[],quiet:true};
  function state(){try{return Object.assign({},defaults,JSON.parse(localStorage.getItem(KEY)||'{}'));}catch(e){return Object.assign({},defaults);}}
  function save(s){localStorage.setItem(KEY,JSON.stringify(s));return s;}
  function isAdmin(profile){return !!profile&&['ADMIN','OWNER'].includes(String(profile.role||'').toUpperCase())&&profile.admission_status==='APPROVED';}
  function renderSettings(root,profile){if(!root||!isAdmin(profile))return;const s=state();const card=document.createElement('section');card.className='nori-admin-dossier-card';card.innerHTML=`<div class="nori-admin-dossier-kicker">ADMINISTRATOR / CONTROL PLANE</div><div class="nori-admin-dossier-title">${escapeHtml(s.displayName)}</div><div class="nori-admin-dossier-sub">One administrator identity · ${s.emails.length||1} linked sign-in${s.emails.length===1?'':'s'} · quiet by default</div><div class="nori-admin-dossier-grid"><button data-admin-users>USERS</button><button data-admin-admins>ADMIN ACCOUNTS</button><button data-admin-reports>REPORTS</button><button data-admin-system>SYSTEM</button></div><div class="nori-admin-dossier-foot"><button data-admin-name>CHANGE ADMIN NAME</button><button data-admin-quiet>${s.quiet?'QUIET MODE: ON':'QUIET MODE: OFF'}</button></div></section>`;root.appendChild(card);
    card.querySelector('[data-admin-name]').onclick=()=>{const n=prompt('Administrator display name',s.displayName);if(!n||!n.trim())return;s.displayName=n.trim();save(s);renderSettings(root,profile);};
    card.querySelector('[data-admin-quiet]').onclick=()=>{s.quiet=!s.quiet;save(s);renderSettings(root,profile);};
    card.querySelector('[data-admin-users]').onclick=()=>window.NoriAdminUnified.open('users');
    card.querySelector('[data-admin-admins]').onclick=()=>window.NoriAdminUnified.open('admins');
    card.querySelector('[data-admin-reports]').onclick=()=>window.NoriAdminUnified.open('reports');
    card.querySelector('[data-admin-system]').onclick=()=>window.NoriAdminUnified.open('system');
  }
  function escapeHtml(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
  function open(section){const el=document.getElementById('nori-admin-console');if(!el)return;el.scrollIntoView({behavior:'smooth',block:'start'});window.dispatchEvent(new CustomEvent('nori:admin-open',{detail:{section}}));}
  window.NoriAdminUnified={state,save,isAdmin,renderSettings,open};
})();
