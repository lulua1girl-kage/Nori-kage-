/* ==========================================================================
   NORI — FOCUS MODE (native app blocking bridge)
   ==========================================================================
   Talks to the NoriBlocker native Capacitor plugin (native-blocker/ folder
   — see its README for install steps). Does nothing on the web version;
   a website cannot see or control other apps on the device, by OS design,
   regardless of what's built here — this only works inside the native
   Android app, once the plugin is actually compiled in.

   IMPORTANT — untested: unlike everything else in this app, this hasn't
   been run on a real device (no Android environment in the sandbox this
   was built in). The plugin code is structurally correct against the real
   Android APIs, but treat the first real run as a test, not a known-good
   feature.
   ========================================================================== */

// The common distracting apps named earlier in this project. Package names
// are Google Play Store IDs — accurate as of when this was written, but
// worth spot-checking if blocking silently doesn't trigger for one of them.
const NORI_BLOCKABLE_APPS = [
  { label: "Instagram", package: "com.instagram.android" },
  { label: "Snapchat", package: "com.snapchat.android" },
  { label: "Pinterest", package: "com.pinterest" },
  { label: "TikTok", package: "com.zhiliaoapp.musically" },
  { label: "YouTube", package: "com.google.android.youtube" }
];

function noriBlockerPlugin() {
  return (window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.NoriBlocker) || null;
}

function noriBlockerAvailable() {
  return NORI_IS_NATIVE && !!noriBlockerPlugin();
}

async function noriBlockerCheckPermissions() {
  const plugin = noriBlockerPlugin();
  if (!plugin) return { usageAccess: false, overlay: false };
  return plugin.checkPermissions();
}

async function noriBlockerRequestUsageAccess() {
  const plugin = noriBlockerPlugin();
  if (plugin) await plugin.requestUsageAccess();
}

async function noriBlockerRequestOverlayPermission() {
  const plugin = noriBlockerPlugin();
  if (plugin) await plugin.requestOverlayPermission();
}

async function noriBlockerStart(packages) {
  const plugin = noriBlockerPlugin();
  if (!plugin) throw new Error("Focus Mode isn't available here \u2014 it only works in the installed Android app.");
  const endpoint = (typeof NORI_API_BASE_URL !== "undefined" ? NORI_API_BASE_URL : "") + "/api/domain-status";
  const token = (typeof noriSyncGetAccessToken === "function" ? (noriSyncGetAccessToken() || "") : "");
  return plugin.startBlocking({ packages: packages, statusEndpoint: endpoint, authToken: token, context: JSON.stringify(window.noriGetProtectionContext ? noriGetProtectionContext() : {}) });
}

async function noriBlockerSetContext(context) {
  const plugin = noriBlockerPlugin();
  if (!plugin || !plugin.setContext) return false;
  return plugin.setContext({ context: JSON.stringify(context || (window.noriGetProtectionContext ? noriGetProtectionContext() : {})) });
}

async function noriBlockerGetContext() {
  const plugin = noriBlockerPlugin();
  if (!plugin || !plugin.getContext) return window.noriGetProtectionContext ? noriGetProtectionContext() : {};
  return plugin.getContext();
}

async function noriBlockerSetSmartContext() {
  const context = window.noriGetProtectionContext ? noriGetProtectionContext() : {};
  await noriBlockerSetContext(context);
  return context;
}

// Keep the single existing Focus Mode synchronized with the unified context;
// this does not create a second blocker.
setInterval(function(){
  if (typeof NORI_IS_NATIVE !== 'undefined' && NORI_IS_NATIVE && window.noriGetProtectionContext) {
    noriBlockerSetSmartContext().catch(function(){});
  }
}, 5000);

async function noriBlockerRefreshRestrictions() {
  const plugin = noriBlockerPlugin();
  if (!plugin) return false;
  const endpoint = (typeof NORI_API_BASE_URL !== "undefined" ? NORI_API_BASE_URL : "") + "/api/domain-status";
  const token = (typeof noriSyncGetAccessToken === "function" ? (noriSyncGetAccessToken() || "") : "");
  return plugin.refreshRestrictions({ statusEndpoint: endpoint, authToken: token });
}

async function noriBlockerStop() {
  const plugin = noriBlockerPlugin();
  if (plugin) await plugin.stopBlocking();
}

/* ---------------------------------------------------------------------
   REMINDERS — @capacitor/local-notifications. Local, not a true system
   AlarmManager alarm, but functionally the same for study reminders (a
   scheduled notification that fires even if the app isn't open). No-op
   on web, same pattern as everything else here.
   --------------------------------------------------------------------- */

function noriNotificationsPlugin() {
  return (window.Capacitor && window.Capacitor.Plugins && (window.Capacitor.Plugins.LocalNotifications || window.Capacitor.Plugins.NoriDevice)) || null;
}

async function noriReminderRequestPermission() {
  const plugin = noriNotificationsPlugin();
  if (plugin && plugin.requestPermissions) { const result=await plugin.requestPermissions(); return result && (result.display==='granted'||result.granted===true); }
  if ('Notification' in window) { const p=await Notification.requestPermission(); return p==='granted'; }
  return false;
}

// title/body: strings. atDate: a JS Date for when it should fire.
async function noriReminderSchedule(title, body, atDate, channelId) {
  const plugin = noriNotificationsPlugin();
  if (!plugin) throw new Error("Reminders aren't available here \u2014 they only work in the installed Android app.");
  const id = Math.floor(Math.random() * 1000000);
  await plugin.schedule({
    notifications: [{
      id: id, title: title, body: body,
      schedule: { at: atDate },
      channelId: channelId || "default",
      smallIcon: "ic_launcher"
    }]
  });
  return id;
}

async function noriReminderCancel(id) {
  const plugin = noriNotificationsPlugin();
  if (plugin) { if(plugin === (window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.NoriDevice)) await plugin.cancel({id:id}); else if(plugin.cancel) await plugin.cancel({notifications:[{id:id}]}); }
}

/* ---------------------------------------------------------------------
   CAMERA VERIFICATION — @capacitor/camera to take the photo, then
   api/verify-photo.js (Gemini/OpenAI vision) to assess it against a
   claim. Photo capture works natively; the analysis call works from
   anywhere (it's a normal fetch to the deployed backend), so this half
   still works even in a browser preview — only the camera capture step
   is native-only.
   --------------------------------------------------------------------- */

const NORI_VERIFY_PHOTO_ENDPOINT = (typeof NORI_API_BASE_URL !== "undefined" ? NORI_API_BASE_URL : "") + "/api/verify-photo";

function noriCameraPlugin() {
  const p=window.Capacitor&&window.Capacitor.Plugins;
  return (p&&p.Camera) || (p&&p.NoriVisual) || null;
}

// Returns { base64, mimeType } or throws. Native only — no browser camera
// fallback here, since the ask was specifically about verification via
// the device camera, not a generic file upload.
async function noriCameraCapture() {
  const plugin = noriCameraPlugin();
  if (!plugin) throw new Error("Camera capture isn't available here \u2014 it only works in the installed Android app.");
  if (plugin.captureCamera) {
    const photo=await plugin.captureCamera();
    const dataUrl=String(photo&&photo.dataUrl||'');
    const m=dataUrl.match(/^data:([^;]+);base64,(.*)$/);
    if(!m) throw new Error('Camera returned no image data.');
    return {base64:m[2],mimeType:m[1]};
  }
  const photo = await plugin.getPhoto({quality:70,allowEditing:false,resultType:'base64',source:'CAMERA'});
  return {base64:photo.base64String,mimeType:'image/'+(photo.format||'jpeg')};
}

// Captures a photo AND sends it for analysis in one call. claim: what the
// photo is supposed to show, in plain language.
async function noriCameraVerify(claim) {
  const captured = await noriCameraCapture();
  const resp = await fetch(NORI_VERIFY_PHOTO_ENDPOINT, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ claim: claim, imageBase64: captured.base64, mimeType: captured.mimeType })
  });
  if (!resp.ok) throw new Error("Verification backend returned " + resp.status);
  return resp.json();
}
