/* NORI TIER 2 — natural conversation, anti-awkwardness, affect bridge,
   contextual next move, and voice-session coordination.
   Local-first. Does not invent personal facts or diagnose emotion. */
(function(g){'use strict';
  var KEY='nori_conversation_v2';
  function load(){try{return JSON.parse(localStorage.getItem(KEY)||'null')||{turns:[],lastIntent:'',lastAffect:'calm'}}catch(e){return {turns:[],lastIntent:'',lastAffect:'calm'}}}
  function privateMode(){try{return !!(g.noriIntelligenceV20&&g.noriIntelligenceV20.controls&&g.noriIntelligenceV20.controls().privateMode)}catch(e){return false}}
  function save(x){try{if(privateMode())return;localStorage.setItem(KEY,JSON.stringify(x));}catch(e){}}
  function clean(s){return String(s||'').replace(/\s+/g,' ').trim()}
  function intent(text){var t=clean(text).toLowerCase();
    if(/\b(why|how|explain|analy[sz]e|compare|evaluate|reason|difference)\b/.test(t))return 'analysis';
    if(/\b(plan|schedule|organize|what should i do|next|priorit)/.test(t))return 'planning';
    if(/\b(i feel|i am|i'm|sad|angry|upset|tired|overwhelmed|frustrated|stressed)\b/.test(t))return 'support';
    if(/\b(study|learn|teach|solve|homework|exam|assignment|physics|chemistry|biology|math)\b/.test(t))return 'academic';
    if(/^((hi|hey|hello|yo)\b|good morning|good night)/.test(t))return 'social';
    if(/\b(search|look up|browse|latest|current|verify online)\b/.test(t))return 'research';
    return 'general';
  }
  function affect(text){var t=clean(text).toLowerCase();
    if(/\b(unsafe|emergency|danger|urgent)\b/.test(t))return 'concerned';
    if(/\b(sad|upset|rough|hard|hurt|lonely|tired|overwhelmed|frustrated)\b/.test(t))return 'warm';
    if(/\b(deadline|exam|focus|start now|important)\b/.test(t))return 'focused';
    if(/\b(good|great|nice|worked|improved|win|haha|lol)\b/.test(t))return 'encouraging';
    return 'calm';
  }
  function antiAwkward(text,reply){
    var r=clean(reply); if(!r)return r;
    // Remove stage directions and canned assistant theatre.
    r=r.replace(/^\s*[\[(](?:smiles?|laughs?|chuckles?|sighs?|looks? concerned|pauses?)[\])]:?\s*/i,'');
    r=r.replace(/\b(I(?:'m| am) always here for you|I'm here whenever you need me)\.?/gi,'');
    r=r.replace(/\b(Absolutely!|Of course!|Certainly!|Great question!)\s*(?=\b)/gi,'');
    r=r.replace(/\n{3,}/g,'\n\n').trim();
    return r;
  }
  function nextMove(){
    try{
      if(g.noriBrainV12&&g.noriBrainV12.contextualNextMove)return g.noriBrainV12.contextualNextMove();
    }catch(e){}
    return null;
  }
  function beginUserTurn(text){var st=load(),i=intent(text),a=affect(text);st.lastIntent=i;st.lastAffect=a;st.turns=(st.turns||[]).concat([{role:'user',intent:i,affect:a,at:new Date().toISOString()}]).slice(-30);save(st);if(g.noriVisualSetAffect)g.noriVisualSetAffect(a);g.__noriVoiceEmotion=a;return {intent:i,affect:a,history:st.turns.slice(-8)};}
  function finishAssistantTurn(reply,meta){var st=load(),r=antiAwkward('',reply);st.turns=(st.turns||[]).concat([{role:'assistant',at:new Date().toISOString(),length:r.length,emotion:(meta&&meta.emotion)||st.lastAffect}]).slice(-30);save(st);if(meta&&meta.emotion){if(g.noriVisualSetAffect)g.noriVisualSetAffect(meta.emotion);g.__noriVoiceEmotion=meta.emotion;}return r;}
  function conversationalContext(){var st=load();return {recentTurns:privateMode()?[]:(st.turns||[]).slice(-8),lastIntent:st.lastIntent||'general',lastAffect:st.lastAffect||'calm',privateMode:privateMode()};}
  function setPrivateMode(v){try{var c=g.noriIntelligenceV20&&g.noriIntelligenceV20.controls?g.noriIntelligenceV20.controls():{};c.privateMode=!!v;localStorage.setItem('nori_privacy_controls_v20',JSON.stringify(c));}catch(e){}}
  function clear(){try{localStorage.removeItem(KEY);return true}catch(e){return false}}
  g.noriConversationV2={intent:intent,affect:affect,antiAwkward:antiAwkward,beginUserTurn:beginUserTurn,finishAssistantTurn:finishAssistantTurn,context:conversationalContext,nextMove:nextMove,setPrivateMode:setPrivateMode,clear:clear};
})(window);
