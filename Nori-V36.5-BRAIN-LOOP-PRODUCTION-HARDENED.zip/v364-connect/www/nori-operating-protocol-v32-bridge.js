/* V31 -> V32 Operating Protocol bridge.
 * Makes the existing Orchestrator participate in the common protocol without
 * creating a second brain. Specialist engines remain executors/adapters.
 */
(function(g){'use strict';
  function boot(){
    const p=g.NoriOperatingProtocolV32, core=g.NoriIntegrationCoreV31;
    if(!p||!core||g.__NORI_V32_BRIDGED)return;
    g.__NORI_V32_BRIDGED=true;
    const clone=x=>{try{return JSON.parse(JSON.stringify(x));}catch(_){return x;}};
    const originalDispatch=core.dispatch.bind(core);
    const originalExecute=core.executeAIAction.bind(core);

    /* Capability contract enrichment: identity, requirements, policy, rollback,
       verification, events and health are now queryable through one protocol. */
    if(core.capabilities&&typeof core.capabilities==='function'){
      // no mutation of the existing registry API; discover() filters it dynamically.
    }

    function traceStore(rec){
      try{
        const k='nori_protocol_v32_trace',a=JSON.parse(localStorage.getItem(k)||'[]');
        a.push(rec);localStorage.setItem(k,JSON.stringify(a.slice(-250)));
      }catch(_){ }
    }

    core.dispatch=async function(input){
      const raw=input||{};
      const i=p.intent(raw);
      const ctx=p.beginTrace(i,{requestId:raw.requestId,correlationId:raw.correlationId,intentId:i.id,idempotencyKey:raw.idempotencyKey});
      p.setSession(i.sessionId,{correlationId:ctx.correlationId,requestId:ctx.requestId,intentId:i.id,source:i.source,lastIntent:i,context:i.context});
      if(p.isCancelled(ctx))return p.normalizeResult({ok:false,reason:'cancelled'},ctx);
      if(raw.idempotencyKey){const replay=p.replayIdempotency(raw.idempotencyKey);if(replay){return Object.assign({},clone(replay),{status:'idempotent_replay',idempotencyKey:raw.idempotencyKey});}}
      p.emit('intent.received',{intent:i},{correlationId:ctx.correlationId,requestId:ctx.requestId,intentId:i.id,actionId:ctx.actionId,source:'v32-bridge'});
      let out;
      try{
        out=await originalDispatch(Object.assign({},raw,{sessionId:i.sessionId,correlationId:ctx.correlationId,intentId:i.id}));
      }catch(e){
        out=p.normalizeResult({ok:false,reason:e.message,error:{code:'EXECUTION_FAILED',message:e.message}},ctx);
      }
      const normalized=out&&out.status==='confirmation_required'
        ?Object.assign({ok:false,status:'confirmation_required',correlationId:ctx.correlationId,requestId:ctx.requestId,intentId:i.id},out)
        :p.normalizeResult(out,ctx);
      if(normalized.status==='confirmation_required'&&normalized.proposal){
        const pending=p.pending().find(x=>x.proposal&&x.proposal.id===normalized.proposal.id);
        if(!pending)p.requireConfirmation(i,normalized.capability||i.requestedAction||'unknown',normalized.proposal,ctx).catch(()=>{});
        p.setSession(i.sessionId,{pendingActionId:pending&&pending.id||null,pendingProposalId:normalized.proposal.id,correlationId:ctx.correlationId});
      }
      if(raw.idempotencyKey&&normalized.status!=='confirmation_required')p.rememberIdempotency(raw.idempotencyKey,normalized);
      traceStore({requestId:ctx.requestId,correlationId:ctx.correlationId,intentId:i.id,actionId:ctx.actionId,source:i.source,action:i.requestedAction,status:normalized.status,at:new Date().toISOString()});
      p.emit('request.completed',{status:normalized.status,result:normalized},{correlationId:ctx.correlationId,requestId:ctx.requestId,intentId:i.id,actionId:ctx.actionId,source:'v32-bridge'});
      return normalized;
    };

    core.executeAIAction=async function(action){
      const a=Object.assign({},action||{}), key=a.idempotencyKey||null;
      const i=p.intent({source:a.source||'ai',action:a.type,args:a,goal:a.reason||a.type,sessionId:a.sessionId||'default',userConfirmation:a.userConfirmed===true});
      const ctx=p.beginTrace(i,{requestId:a.requestId,correlationId:a.correlationId,intentId:i.id,idempotencyKey:key});
      if(key){const replay=p.replayIdempotency(key);if(replay)return Object.assign({},clone(replay),{status:'idempotent_replay',idempotencyKey:key});}
      if(p.isCancelled(ctx))return p.normalizeResult({ok:false,reason:'cancelled'},ctx);
      const opClass=p.operationClass(a.type), pol=p.policy(a.type,a.type,{userConfirmation:a.userConfirmed===true?'confirmed':null});
      p.emit('action.started',{type:a.type,operationClass:opClass,risk:pol.risk},{correlationId:ctx.correlationId,requestId:ctx.requestId,intentId:i.id,actionId:ctx.actionId,source:'ai'});
      if(pol.confirmationRequired && a.userConfirmed!==true){
        const map={start_focus_mode:'focus_start',stop_focus_mode:'focus_stop',schedule_reminder:'schedule_reminder',schedule_alarm:'schedule_alarm',cancel_alarm:'cancel_alarm',create_assignment:'create_assignment',complete_assignment:'complete_assignment',create_study_session:'create_study_session',complete_study_session:'complete_study_session',create_calendar_event:'create_calendar_event',delete_calendar_event:'delete_calendar_event',record_result:'record_result',recalculate_awards:'recalculate_awards',recovery_review:'recovery_review'};
        const mapped=map[a.type];
        if(mapped && typeof core.proposeAction==='function'){
          const input=Object.assign({},a);delete input.type;delete input.reason;delete input.userConfirmed;
          const proposal=await core.proposeAction(mapped,input,{correlationId:ctx.correlationId,reason:a.reason||'AI-proposed action requires human confirmation'});
          const pending= p.requireConfirmation(i,a.type,proposal&&proposal.proposal||proposal,ctx);
          const pa=await pending;
          p.setSession(i.sessionId,{pendingActionId:pa&&pa.id||null,pendingProposalId:proposal&&proposal.proposal&&proposal.proposal.id||null});
          return {ok:false,status:'confirmation_required',correlationId:ctx.correlationId,requestId:ctx.requestId,intentId:i.id,proposal:proposal&&proposal.proposal||proposal,pendingAction:pa,policy:pol};
        }
      }
      let raw;
      try{raw=await originalExecute(Object.assign({},a,{correlationId:ctx.correlationId,requestId:ctx.requestId,userConfirmed:true}));}
      catch(e){raw={ok:false,reason:e.message,error:{code:e.code||'EXECUTION_FAILED',message:e.message}};}
      const normalized=p.normalizeResult(raw,ctx);
      if(key)p.rememberIdempotency(key,normalized);
      p.emit(normalized.ok?'action.completed':'action.failed',{type:a.type,result:normalized},{correlationId:ctx.correlationId,requestId:ctx.requestId,intentId:i.id,actionId:ctx.actionId,source:'ai'});
      return normalized;
    };

    /* Universal cancellation: stop requests through the same protocol. */
    p.subscribe('request.cancelled',function(e){
      const sid=(e.payload&&e.payload.sessionId)||'default';
      p.setSession(sid,{cancelledRequestId:e.payload&&e.payload.requestId});
    });

    /* Convert legacy state-change signals into the common change stream. */
    p.subscribe('state.changed',function(e){
      p.emit('change.observed',{change:e.payload},{correlationId:e.correlationId,requestId:e.requestId,source:'change-stream'});
    });

    /* Capability discovery is filtered at the protocol boundary. */
    g.NoriCapabilityDiscoveryV32={list:function(){return p.discover(core,{platform:g.NORI_IS_NATIVE?'android':'web'});}};

    /* Standardized capability contract helper for future specialist adapters. */
    g.NoriCapabilityProtocolV32={
      define:function(def){
        const d=Object.assign({version:'32',operationClasses:['READ','PROPOSE','MUTATE','DELETE','NAVIGATE','SPEAK'],risk:'low',confirmation:'required',dependencies:[],canRollback:false,rollbackWindowMs:0,sideEffects:[]},def||{});
        return d;
      },
      result:p.normalizeResult,
      error:p.ERRORS,
      operationClass:p.operationClass,
      policy:p.policy,
      simulate:p.simulate,
      transaction:p.transaction,
      lock:p.locks,
      time:p.Time,
      state:p.State,
      cancel:p.cancel
    };

    p.emit('protocol.bridge.ready',{version:'32',orchestrator:'NoriIntegrationCoreV31',capabilityDiscovery:true,unifiedLifecycle:true},{source:'v32-bridge'});
  }
  if(g.NoriOperatingProtocolV32&&g.NoriIntegrationCoreV31)boot();
  else window.addEventListener('nori:protocol-event',function(){if(g.NoriOperatingProtocolV32&&g.NoriIntegrationCoreV31)boot();},{once:true});
})(window);
