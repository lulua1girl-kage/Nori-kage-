/* NORI V33 — OPERATIVE EXECUTION CORE
 * One goal-to-operation loop over the V32 Operating Protocol.
 * The model proposes; V33 validates, plans, gates, executes, verifies, commits,
 * emits and reports. Specialist engines remain executors/adapters.
 */
(function(g){'use strict';
  const P=g.NoriOperatingProtocolV32, I=g.NoriIntegrationCoreV31;
  const VERSION='33';
  const clone=x=>{try{return JSON.parse(JSON.stringify(x));}catch(_){return x;}};
  const uid=p=>(p||'v33')+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,9);
  const ACTIONS={
    create_assignment:{key:'nori_command_assignments',risk:'medium'},update_assignment:{key:'nori_command_assignments',risk:'medium'},complete_assignment:{key:'nori_command_assignments',risk:'medium'},reopen_assignment:{key:'nori_command_assignments',risk:'medium'},
    create_study_session:{key:'nori_study_sessions',risk:'medium'},update_study_session:{key:'nori_study_sessions',risk:'medium'},complete_study_session:{key:'nori_study_sessions',risk:'medium'},
    create_calendar_event:{key:'nori_calendar_events_v1',risk:'medium'},update_calendar_event:{key:'nori_calendar_events_v1',risk:'medium'},delete_calendar_event:{key:'nori_calendar_events_v1',risk:'high'},
    schedule_reminder:{key:'nori_v27_reminders',risk:'medium'},schedule_alarm:{key:'nori_voice_alarms',risk:'medium'},cancel_alarm:{key:'nori_voice_alarms',risk:'high'},
    record_result:{key:'nori_eval_history_all_subjects',risk:'medium'},focus_start:{risk:'medium'},focus_stop:{risk:'medium'},recalculate_awards:{risk:'low'},recovery_review:{risk:'low'},start_timer:{risk:'low'},stop_timer:{risk:'low'},start_math_stopwatch:{risk:'low'},stop_math_stopwatch:{risk:'low'}
  };
  const events=[]; const pending=new Map(); const MAX=200;
  function emit(type,payload,ctx){const e={id:uid('evt'),type,at:new Date().toISOString(),correlationId:ctx&&ctx.correlationId||uid('corr'),requestId:ctx&&ctx.requestId||null,intentId:ctx&&ctx.intentId||null,actionId:ctx&&ctx.actionId||null,payload:clone(payload||{}),source:'operative-v33'};events.push(e);if(events.length>MAX)events.shift();try{P&&P.emit(type,e.payload,e);}catch(_){}return e;}
  function fail(code,message,ctx,extra){return Object.assign({ok:false,status:'failed',error:{code,message:message||code},trace:ctx||null},extra||{});}
  function success(data,ctx,extra){return Object.assign({ok:true,status:'success',data:clone(data),trace:ctx||null,errors:[]},extra||{});}
  function trace(intent,opts){return P?P.beginTrace(intent,Object.assign({},opts||{},{actionId:(opts&&opts.actionId)||uid('action')})):{requestId:uid('req'),correlationId:uid('corr'),intentId:intent.id,actionId:uid('action')};}
  function authHeaders(){return g.NoriProductionAuth&&g.NoriProductionAuth.session?g.NoriProductionAuth.session().then(r=>{const s=r&&r.data&&r.data.session;return s&&s.access_token?{Authorization:'Bearer '+s.access_token}:{};}):Promise.resolve({});}
  async function canonicalAction(action,args,ctx,opts){
    const headers=Object.assign({'Content-Type':'application/json'},await authHeaders());
    const base=String(g.NORI_API_BASE_URL||''); if(!base) throw new Error('API_BASE_UNAVAILABLE');
    const r=await fetch(base+'/api/brain',{method:'POST',headers,body:JSON.stringify({mode:'capability_action',action,args,requestId:ctx.requestId,correlationId:ctx.correlationId,idempotencyKey:opts&&opts.idempotencyKey||ctx.actionId,confirmed:opts&&opts.confirmed===true})});
    let j={};try{j=await r.json();}catch(_){}
    if(!r.ok||!j.ok) {const e=new Error(j.error||j.code||('CAPABILITY_ACTION_'+r.status));e.code=j.code||'EXECUTION_FAILED';e.retryable=!!j.retryable;throw e;}
    return j;
  }
  function mirrorAppData(appData){
    if(!appData||typeof appData!=='object')return;
    Object.keys(appData).forEach(k=>{try{if(P&&P.State&&P.State.writeSync)P.State.writeSync(k,appData[k],{requestId:uid('mirror')});}catch(_) {try{localStorage.setItem(k,JSON.stringify(appData[k]));}catch(__){}}});
  }
  async function verifyCanonical(action,expected,ctx){
    try{
      const headers=Object.assign({'Content-Type':'application/json'},await authHeaders());
      const r=await fetch(String(g.NORI_API_BASE_URL||'')+'/api/brain',{method:'POST',headers,body:JSON.stringify({mode:'canonical_state'})});
      const j=await r.json(); if(!r.ok||!j.ok) return {ok:false,uncertain:true,reason:'canonical_state_unavailable'};
      const state=j.context&&j.context.canonicalState&&j.context.canonicalState.state||{};
      const data=state.appData||{};
      const key=ACTIONS[action]&&ACTIONS[action].key;
      if(!key)return {ok:true,source:'specialist'};
      const actual=data[key];
      let ok=true;
      if(expected&&expected.kind==='exists') ok=Array.isArray(actual)?actual.some(x=>String(x.id||'')===String(expected.ref)||String(x.title||x.topic||x.label||'').toLowerCase()===String(expected.ref||'').toLowerCase()):false;
      else if(expected&&expected.kind==='state') ok=JSON.stringify(actual)===JSON.stringify(expected.value);
      else ok=actual!==undefined;
      return {ok,source:'canonical-server',stateVersion:j.context.stateVersion||0,actual:clone(actual)};
    }catch(e){return {ok:false,uncertain:true,reason:e.message};}
  }
  function find(items,ref){const r=String(ref||'').trim().toLowerCase();return (Array.isArray(items)?items:[]).find(x=>String(x.id||'').toLowerCase()===r)||(Array.isArray(items)?items:[]).find(x=>String(x.title||x.topic||x.label||'').toLowerCase()===r)||(Array.isArray(items)?items:[]).find(x=>String(x.title||x.topic||x.label||'').toLowerCase().includes(r));}
  async function plan(action,input,ctx){
    const d=ACTIONS[action]; if(!d)return fail('CAPABILITY_UNAVAILABLE','No V33 capability contract for '+action,ctx);
    const steps=[{id:'inspect',kind:'READ',description:'Read authoritative state and constraints.'},{id:'policy',kind:'PROPOSE',description:'Apply capability policy and Human Override.'},{id:'execute',kind:'MUTATE',description:'Execute the capability through its owner.'},{id:'verify',kind:'READ',description:'Verify the requested outcome from authoritative state.'},{id:'commit',kind:'STATE',description:'Commit and emit the resulting state change.'}];
    return {ok:true,status:'planned',planId:uid('plan'),action,input:clone(input||{}),steps,complexity:steps.length>2?'standard':'simple',risk:d.risk};
  }
  async function execute(action,input,opts){
    opts=opts||{}; const intent=P?P.intent({source:opts.source||'text',text:opts.text||action,action,args:input,sessionId:opts.sessionId||'default'}):{id:uid('intent')};
    const ctx=trace(intent,{correlationId:opts.correlationId,idempotencyKey:opts.idempotencyKey||null});
    const d=ACTIONS[action]; if(!d)return fail('CAPABILITY_UNAVAILABLE','Unknown capability '+action,ctx);
    const replay=P&&P.replayIdempotency?P.replayIdempotency(opts.idempotencyKey):null; if(replay)return Object.assign({},replay,{status:'idempotent_replay',trace:ctx});
    emit('operative.intent',{intent:clone(intent)},ctx);
    const pl=await plan(action,input,ctx); if(!pl.ok)return pl;
    emit('operative.plan',{plan:clone(pl.plan||pl)},ctx);
    if(opts.simulate){emit('operative.simulation',{plan:clone(pl)},ctx);return success(pl,ctx,{status:'simulated',verification:{verified:false,simulation:true}});}
    if(!opts.confirmed && d.risk!=='low'){const proposal={id:uid('proposal'),type:action,input:clone(input),plan:pl,createdAt:new Date().toISOString(),status:'pending_confirmation',trace:ctx};pending.set(proposal.id,proposal);emit('operative.confirmation_required',{proposal:clone(proposal)},ctx);return {ok:true,status:'confirmation_required',proposal,trace:ctx};}
    if(P&&P.interrupt&&P.isCancelled&&P.isCancelled(ctx.actionId))return fail('CANCELLED','Action was cancelled before execution.',ctx);
    emit('operative.authorized',{action,input:clone(input)},ctx);
    let raw, canonicalCommitted=false;
    const canonicalActions=new Set(Object.keys(ACTIONS).filter(x=>!['focus_start','focus_stop','recalculate_awards','recovery_review'].includes(x)));
    try{
      if(['start_timer','stop_timer','start_math_stopwatch','stop_math_stopwatch'].includes(action)) {
        const T=g.NoriTimeToolsV35;
        if(!T) throw new Error('TIME_TOOLS_UNAVAILABLE');
        if(action==='start_timer') raw={ok:true,timeTool:T.setTimer(input.seconds||input.durationSeconds||60,input.label||'Nori timer')};
        else if(action==='stop_timer') raw=T.stopTimer();
        else if(action==='start_math_stopwatch') raw={ok:true,timeTool:T.startStopwatch(input.problemCount||input.problems||10,input.subject||'Mathematics')};
        else raw=T.stopStopwatch(true);
        if(!raw||raw.ok===false) throw new Error(raw&&raw.reason||'TIME_TOOL_FAILED');
      } else if(canonicalActions.has(action)) {
        // The server is the authority for durable app records. The local UI is mirrored only after commit.
        raw=await canonicalAction(action,input,ctx,opts); canonicalCommitted=true; mirrorAppData(raw.appData||raw.state&&raw.state.appData||{});
      } else if(I&&I.executeAIAction) {
        raw=await I.executeAIAction(Object.assign({type:action},input,{__v33_internal:true}));
      } else throw new Error('EXECUTOR_UNAVAILABLE');
      emit('operative.executed',{action,result:clone(raw)},ctx);
    }catch(e){
      emit('operative.failed',{action,code:e.code||'EXECUTION_FAILED',message:e.message},ctx);
      return fail(e.code||'EXECUTION_FAILED',e.message,ctx,{retryable:!!e.retryable,canonicalCommitted});
    }
    let verification=await verifyCanonical(action,{kind:'exists',ref:input.id||input.title||input.topic||input.label},ctx);
    if(!canonicalActions.has(action)) verification={ok:true,source:'specialist-adapter'};
    emit(verification.ok?'operative.verified':'operative.verification_failed',{action,verification:clone(verification)},ctx);
    const out=verification.ok?success(raw,ctx,{verification,status:'committed'}):fail('VERIFICATION_FAILED','The requested change could not be verified in authoritative state.',ctx,{verification,data:raw});
    if(P&&P.rememberIdempotency&&opts.idempotencyKey)P.rememberIdempotency(opts.idempotencyKey,out);
    emit(out.ok?'operative.committed':'operative.uncertain',{action,result:clone(out)},ctx);
    return out;
  }
  async function confirm(proposalId){
    const p=pending.get(proposalId); if(!p)return fail('PROPOSAL_NOT_FOUND','Operative proposal not found.',null);
    pending.delete(proposalId); return execute(p.type,p.input,{source:'confirmation',confirmed:true,sessionId:p.trace&&p.trace.sessionId,idempotencyKey:'proposal:'+proposalId,correlationId:p.trace&&p.trace.correlationId});
  }
  async function confirmLatest(sessionId){const list=Array.from(pending.values()).reverse();const p=list.find(x=>!sessionId||!x.trace||x.trace.sessionId===sessionId)||list[0];return p?confirm(p.id):fail('PROPOSAL_NOT_FOUND','No pending operative proposal.',null);}
  function pendingList(){return Array.from(pending.values()).map(clone);}

  async function planWorkflow(actions,opts){
    const list=(Array.isArray(actions)?actions:[]).filter(x=>x&&x.type); const plans=[]; for(const a of list){const p=await plan(a.type,Object.assign({},a),{source:(opts&&opts.source)||'text'});if(!p.ok)return p;plans.push(p);} return {ok:true,status:'planned',workflowId:uid('workflow'),actions:list.map(clone),plans};
  }
  async function executeWorkflow(actions,opts){
    const list=(Array.isArray(actions)?actions:[]).filter(x=>x&&x.type); if(!list.length)return fail('EMPTY_WORKFLOW','No executable actions.',null);
    const planned=await planWorkflow(list,opts); if(!planned.ok)return planned;
    if(!(opts&&opts.confirmed===true)) {const proposal={id:uid('workflow_proposal'),type:'workflow',actions:clone(list),plan:planned};pending.set(proposal.id,proposal);emit('operative.workflow_confirmation_required',{proposal:clone(proposal)},null);return {ok:true,status:'confirmation_required',proposal};}
    const traceCtx={requestId:uid('req'),correlationId:uid('corr'),intentId:uid('intent'),actionId:uid('workflow'),sessionId:(opts&&opts.sessionId)||'default'};
    const results=[]; for(let i=0;i<list.length;i++){const a=list[i]; if(P&&P.isCancelled&&P.isCancelled(traceCtx.actionId))return {ok:false,status:'cancelled',results,failedAt:i,trace:traceCtx}; const r=await execute(a.type,Object.assign({},a),{source:(opts&&opts.source)||'workflow',confirmed:true,sessionId:traceCtx.sessionId,correlationId:traceCtx.correlationId,idempotencyKey:'workflow:'+traceCtx.correlationId+':'+i}); results.push({action:a,result:r}); if(!r.ok){emit('operative.workflow_partial',{workflowId:traceCtx.actionId,failedAt:i,results:clone(results)},{correlationId:traceCtx.correlationId});return {ok:false,status:results.length>1?'partial_failure':'failed',results,failedAt:i,trace:traceCtx};}}
    emit('operative.workflow_committed',{workflowId:traceCtx.actionId,results:clone(results)},traceCtx); return {ok:true,status:'committed',results,trace:traceCtx};
  }
  async function confirmWorkflow(proposalId){const p=pending.get(proposalId);if(!p)return fail('PROPOSAL_NOT_FOUND','Workflow proposal not found.',null);pending.delete(proposalId);return executeWorkflow(p.actions,{confirmed:true,sessionId:p.plan&&p.plan.actions&&p.plan.actions[0]&&p.plan.actions[0].sessionId});}

  async function handleText(text,opts){
    const t=String(text||'').trim(); if(!t)return {ok:true,status:'empty'};
    const sid=opts&&opts.sessionId||'default';
    if (/^(yes|yeah|yep|confirm|do it|go ahead|okay|ok)$/i.test(t)) return confirmLatest(sid);
    if (/^(stop|cancel|no|nope|not now)$/i.test(t)) {
      const list=Array.from(pending.values()).reverse(); const p=list.find(x=>!sid||!x.trace||x.trace.sessionId===sid)||list[0];
      if(p){pending.delete(p.id);emit('operative.cancelled',{proposalId:p.id},{correlationId:p.trace&&p.trace.correlationId});return {ok:true,status:'cancelled',proposalId:p.id};}
      // A bare spoken/textual "stop" is an explicit control command for an
      // active timer/stopwatch. Do this before normal intent interpretation so
      // the user never has to say "stop stopwatch" to end math timing.
      if(/^stop$/i.test(t) && g.NoriTimeToolsV35){
        try {
          const w=g.NoriTimeToolsV35.watchState?.();
          if(w&&w.status==='running') return Object.assign(g.NoriTimeToolsV35.stopStopwatch(true),{status:'stopped',control:'math_stopwatch'});
          const tm=g.NoriTimeToolsV35.timerState?.();
          if(tm&&tm.status==='running') return Object.assign(g.NoriTimeToolsV35.stopTimer(),{status:'stopped',control:'timer'});
        } catch(_) {}
      }
      if(P){const ps=P.session(sid);if(ps.pendingProposalId)return P.cancel(ps.pendingProposalId);}
    }
    // V34 is the decision/planning layer. It gets first opportunity to turn a goal
    // into a context-aware plan. V33 remains the only execution owner.
    if(g.NoriDecisionPlannerV34&&g.NoriDecisionPlannerV34.handleText){
      try {
        const d=await g.NoriDecisionPlannerV34.handleText(t,Object.assign({},opts||{},{sessionId:sid}));
        if(d&&d.status&&d.status!=='conversation') return d;
      } catch(_) {}
    }
    // Deterministic direct capability extraction is fallback only; model-generated actions enter execute().
    const p=g.NoriActionCoreV27&&g.NoriActionCoreV27.parseText?g.NoriActionCoreV27.parseText(t):null;
    if(p&&p.type){return execute(p.type,p.input,{source:opts&&opts.source||'text',text:t,sessionId:sid,confirmed:false,idempotencyKey:'text:'+sid+':'+t.toLowerCase()});}
    if(I&&I.dispatch){const r=await I.dispatch({source:opts&&opts.source||'text',text:t,sessionId:sid});if(r&&r.status!=='conversation')return r;}
    return {ok:true,status:'conversation',handled:false};
  }
  function cancel(actionId){try{P&&P.cancel&&P.cancel(actionId);emit('operative.cancelled',{actionId},{actionId});return {ok:true,status:'cancelled'};}catch(e){return {ok:false,status:'failed',error:{code:'CANCEL_FAILED',message:e.message}};}}
  function capabilities(){return Object.keys(ACTIONS).map(id=>({id,available:true,risk:ACTIONS[id].risk,owner:'NORI_OPERATIVE_V33'}));}
  const api={version:VERSION,execute,handleText,plan,planWorkflow,executeWorkflow,confirm,confirmLatest,confirmWorkflow,cancel,pending:pendingList,capabilities,events:()=>clone(events),mirrorAppData};
  g.NoriOperativeV33=api;
  try{if(P&&P.on)P.on('protocol.event',()=>{});}catch(_){ }
})(window);
