/* ==========================================================================
   NORI PHASE — APPLICATION ENGINE
   ==========================================================================
   Reads NORI_PHASE_DATA and renders every screen from it. One generic
   engine drives all forms, so adding Phase 2-5 later means adding data,
   not writing new pages.

   Routing is hash-based so back/forward and the breadcrumb both work:
   #/                              -> Nori Phase home (5 phase cards)
   #/phase-1                       -> Phase 1 (system cards)
   #/phase-1/master-scoreboard-system            -> system (form list)
   #/phase-1/master-scoreboard-system/daily-audit -> a single form
   ========================================================================== */

const NORI_APP_ROOT = document.getElementById("nori-app");

function noriFindPhase(phaseId) {
  return NORI_PHASE_DATA.phases.find(function (p) { return p.id === phaseId; });
}
function noriFindSystem(phase, systemId) {
  return phase.systems.find(function (s) { return s.id === systemId; });
}
function noriFindForm(system, formId) {
  return system.forms.find(function (f) { return f.id === formId; });
}

// noriStorageKey / noriLoadEntries / noriSaveEntries now live in
// nori-storage.js (loaded before this file) — single implementation,
// used here and by every AI feature file.

function noriEl(tag, attrs, children) {
  const el = document.createElement(tag);
  if (attrs) {
    Object.keys(attrs).forEach(function (k) {
      if (k === "text") el.textContent = attrs[k];
      else if (k === "html") el.innerHTML = attrs[k];
      else el.setAttribute(k, attrs[k]);
    });
  }
  (children || []).forEach(function (c) { if (c) el.appendChild(c); });
  return el;
}

/* ---------------------------- BREADCRUMB ---------------------------- */

function noriRenderBreadcrumb(parts) {
  // parts: [{label, hash}]
  const nav = noriEl("nav", { class: "nori-breadcrumb" });
  parts.forEach(function (part, i) {
    if (i > 0) nav.appendChild(noriEl("span", { class: "nori-crumb-sep", text: "/" }));
    if (part.hash) {
      const a = noriEl("a", { href: part.hash, class: "nori-crumb", text: part.label });
      nav.appendChild(a);
    } else {
      nav.appendChild(noriEl("span", { class: "nori-crumb nori-crumb-current", text: part.label }));
    }
  });
  return nav;
}

/* ---------------------------- HUB (Current State / Phase Forms / Meet Nori) ---------------------------- */

function noriRenderAccountBar() {
  const bar = noriEl("div", { class: "nori-account-bar" });
  const configured = typeof noriSyncConfigured === "function" && noriSyncConfigured();
  const user = configured && typeof noriSyncGetCurrentUser === "function" ? noriSyncGetCurrentUser() : null;

  if (!configured) {
    bar.appendChild(noriEl("span", { class: "nori-account-status", text: "Cloud sync not set up (see SUPABASE_SETUP.md) \u2014 using this device only." }));
    return bar;
  }

  if (user) {
    bar.appendChild(noriEl("span", { class: "nori-account-status", text: "Synced as " + user.email }));
    const logoutBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "Log out" });
    logoutBtn.addEventListener("click", function () { noriSyncLogOut().then(noriRoute); });
    bar.appendChild(logoutBtn);
    return bar;
  }

  bar.appendChild(noriEl("span", { class: "nori-account-status", text: "Not signed in \u2014 data stays on this device only." }));
  const openBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "Sign in / Sign up" });
  bar.appendChild(openBtn);

  const overlay = noriEl("div", { class: "nori-checkin-overlay", style: "display:none" });
  const modal = noriEl("div", { class: "nori-checkin-modal" });
  const closeBtn = noriEl("button", { class: "nori-btn nori-btn-ghost nori-checkin-close", text: "Close" });
  modal.appendChild(closeBtn);
  modal.appendChild(noriEl("h2", { class: "nori-panel-title", text: "Sync across devices" }));
  modal.appendChild(noriEl("p", { class: "nori-meet-status", text: "Signing in syncs your data to this account and merges anything already on this device." }));

  const emailInput = noriEl("input", { type: "email", class: "nori-checkin-typed", placeholder: "Email" });
  const passwordInput = noriEl("input", { type: "password", class: "nori-checkin-typed", placeholder: "Password (6+ characters)" });
  const status = noriEl("p", { class: "nori-meet-status" });
  const actions = noriEl("div", { class: "nori-checkin-actions" });
  const loginBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "Log in" });
  const signupBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "Sign up" });
  actions.appendChild(loginBtn);
  actions.appendChild(signupBtn);
  modal.appendChild(emailInput);
  modal.appendChild(passwordInput);
  modal.appendChild(actions);
  modal.appendChild(status);
  overlay.appendChild(modal);
  bar.appendChild(overlay);

  openBtn.addEventListener("click", function () { overlay.style.display = "flex"; });
  closeBtn.addEventListener("click", function () { overlay.style.display = "none"; });

  loginBtn.addEventListener("click", function () {
    status.textContent = "Logging in\u2026";
    noriSyncLogIn(emailInput.value.trim(), passwordInput.value).then(function () {
      status.textContent = "Logged in \u2014 syncing\u2026";
      noriRoute();
    }).catch(function (err) { status.textContent = err.message || "Login failed."; });
  });

  signupBtn.addEventListener("click", function () {
    status.textContent = "Signing up\u2026";
    noriSyncSignUp(emailInput.value.trim(), passwordInput.value).then(function () {
      status.textContent = "Account created \u2014 check your email if confirmation is required, then log in.";
    }).catch(function (err) { status.textContent = err.message || "Sign-up failed."; });
  });

  return bar;
}

// Builds a hub card that's either a real clickable link (feature on) or a
// visibly-present but disabled card with a "Coming soon" status (feature
// off) — the "visible but greyed out" pattern used across this reduced
// build, so the shape of the full app is visible without being usable yet.
function noriBuildFeatureCard(title, subtitle, href, enabled, onStatus, offStatus) {
  if (enabled) {
    return noriEl("a", { class: "nori-card", href: href }, [
      noriEl("div", { class: "nori-card-title", text: title }),
      noriEl("div", { class: "nori-card-subtitle", text: subtitle }),
      noriEl("div", { class: "nori-card-status", text: onStatus || "OPEN" }),
      noriEl("span", { class: "nori-card-cta", text: "OPEN →" })
    ]);
  }
  return noriEl("div", { class: "nori-card nori-card-locked" }, [
    noriEl("div", { class: "nori-card-title", text: title }),
    noriEl("div", { class: "nori-card-subtitle", text: subtitle }),
    noriEl("div", { class: "nori-card-status", text: offStatus || "COMING SOON" })
  ]);
}

function noriRenderProtocolPanel() {
  const card = noriEl("section", { class: "nori-panel" });
  card.appendChild(noriEl("h2", { class: "nori-panel-title", text: "Protocol" }));

  const noriRow = noriEl("div", { class: "nori-snapshot-stat" });
  noriRow.appendChild(noriEl("span", { class: "nori-snapshot-stat-label", text: "Nori Protocol \u2014 ACTIVE" }));
  card.appendChild(noriRow);
  card.appendChild(noriEl("p", { class: "nori-history-line", text: "Study-and-recovery focused. Consequences are academic (recovery blocks, restricted access, restored privileges) \u2014 never physical." }));

  const kageRow = noriEl("div", { class: "nori-snapshot-stat" });
  kageRow.appendChild(noriEl("span", { class: "nori-snapshot-stat-label", text: "Kage Protocol \u2014 NOT AVAILABLE" }));
  card.appendChild(kageRow);
  card.appendChild(noriEl("p", { class: "nori-history-line", text: "This mode isn't offered here. A system that prescribes or tracks physical punishment (cold exposure, forced exercise) as a consequence for behavior won't be built into this app \u2014 permanently, not pending a future update." }));

  return card;
}

function noriRenderDailyCommand() {
  const card = noriEl("section", { class: "nori-panel nori-command-card" });
  card.appendChild(noriEl("h2", { class: "nori-panel-title", text: "Today" }));
  const all = typeof noriHistoryLoadAll === "function" ? noriHistoryLoadAll() : {};
  const rows = [];
  Object.keys(all).forEach(function(subject){ (all[subject]||[]).forEach(function(r){ if(typeof r.score === "number") rows.push({subject:subject, score:r.score, date:r.date||""}); }); });
  rows.sort(function(a,b){ return String(b.date).localeCompare(String(a.date)); });
  const latest = rows[0];
  const active = typeof noriActiveConsequences === "function" ? noriActiveConsequences() : [];
  let next = latest ? (latest.score < 80 ? "Review the latest result and complete its recovery work." : "Record the next assessment when it happens; don't manufacture work just to fill the dashboard.") : "Record your first real assessment so Nori can establish a baseline.";
  if (active.length) next = "Resolve the active consequence/recovery requirement before restoring normal access.";
  card.appendChild(noriEl("p", { class:"nori-lede", text: next }));
  const grid=noriEl("div",{class:"nori-card-grid nori-command-grid"});
  grid.appendChild(noriEl("div",{class:"nori-mini-stat",text:"Latest result: "+(latest ? latest.subject+" — "+latest.score+"%" : "None recorded")}));
  grid.appendChild(noriEl("div",{class:"nori-mini-stat",text:"Active consequences: "+active.length}));
  grid.appendChild(noriEl("div",{class:"nori-mini-stat",text:"Tracked subjects: "+Object.keys(all).length}));
  card.appendChild(grid);
  const actions=noriEl("div",{class:"nori-checkin-actions"});
  const resultBtn=noriEl("button",{class:"nori-btn nori-btn-primary",text:"Open Meet Nori"});
  resultBtn.addEventListener("click",function(){location.hash="#/meet-nori";});
  actions.appendChild(resultBtn);
  if(active.length){const cbtn=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"View Consequences"});cbtn.addEventListener("click",function(){location.hash="#/consequences";});actions.appendChild(cbtn);}
  card.appendChild(actions);
  return card;
}

function noriLocalDateISO() {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return y + "-" + m + "-" + day;
}
function noriFormatCommandDate() {
  const d = new Date();
  return d.toLocaleDateString(undefined,{weekday:"long",day:"2-digit",month:"short",year:"numeric"}).toUpperCase();
}
function noriCommandLogo() { return "assets/kage-emblem.png"; }
function noriGetRecoverySummary() {
  const key=noriStorageKey("phase-5","backlog-mapping-priority","backlog-subject-recovery-map");
  const rows=typeof noriLoadEntries==="function"?noriLoadEntries(key):[];
  let total=0, done=0;
  rows.forEach(r=>{ total++; if(String(r.verified||r.status||"").toLowerCase().match(/yes|complete|caught|done/)) done++; });
  const pct=total?Math.round(done/total*100):0;
  return {total,done,pct,rows};
}
function noriAssignmentEditor(existing,onDone){
  const overlay=noriEl("div",{class:"nori-modal"}); const modal=noriEl("div",{class:"nori-modal-card"});
  const head=noriEl("div",{class:"nori-modal-head"}); head.appendChild(noriEl("h2",{text:existing?"Edit assignment":"Add assignment"}));
  const close=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"Close"}); head.appendChild(close); modal.appendChild(head);
  const grid=noriEl("div",{class:"nori-assignment-form-grid"}); const fields={};
  [["subject","Subject","text"],["title","Assignment / task","text"],["due","Due date","date"],["priority","Priority","select"]].forEach(([key,label,type])=>{
    const box=noriEl("div",{class:key==="title"?"full":""}); box.appendChild(noriEl("label",{class:"nori-block-title",text:label}));
    let input;
    if(type==="select"){input=noriEl("select",{});["High","Medium","Low"].forEach(v=>input.appendChild(noriEl("option",{value:v.toLowerCase(),text:v})));}
    else input=noriEl("input",{type:type,placeholder:label});
    if(existing&&existing[key]!=null) input.value=existing[key]; fields[key]=input; box.appendChild(input); grid.appendChild(box);
  });
  const notes=noriEl("div",{class:"full"}); notes.appendChild(noriEl("label",{class:"nori-block-title",text:"Notes"})); fields.notes=noriEl("textarea",{rows:"3",placeholder:"Optional details"}); fields.notes.value=existing&&existing.notes||""; notes.appendChild(fields.notes); grid.appendChild(notes); modal.appendChild(grid);
  const actions=noriEl("div",{class:"nori-form-actions"});
  const save=noriEl("button",{class:"nori-btn nori-btn-primary",text:"Save assignment"}); actions.appendChild(save);
  if (existing) {
    const complete=noriEl("button",{class:"nori-btn nori-btn-ghost",text:existing.status === "done" ? "Reopen" : "Mark complete"});
    const remove=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"Delete"});
    actions.appendChild(complete); actions.appendChild(remove);
    complete.addEventListener("click",function(){ noriAssignmentUpdate(existing.id,{status:existing.status === "done" ? "open" : "done"}); done(); });
    remove.addEventListener("click",function(){ if(confirm("Delete this assignment?")){ noriAssignmentDelete(existing.id); done(); } });
  }
  modal.appendChild(actions); overlay.appendChild(modal); document.body.appendChild(overlay);
  function done(){overlay.remove();if(onDone)onDone();} close.addEventListener("click",done);
  save.addEventListener("click",function(){if(!fields.subject.value.trim()||!fields.title.value.trim()){alert("Subject and task are required.");return;} const item={subject:fields.subject.value.trim(),title:fields.title.value.trim(),due:fields.due.value,priority:fields.priority.value,notes:fields.notes.value.trim()}; const ok=existing?noriAssignmentUpdate(existing.id,item):noriAssignmentAdd(item); if(ok===false||ok===null){alert("Could not save the assignment. Check device storage.");return;} done();});
}
function noriRenderAssignmentPanel(){
  const card=noriEl("section",{class:"nori-section-card"}); const head=noriEl("div",{class:"nori-section-head"}); head.appendChild(noriEl("h2",{text:"Upcoming Assignments"}));
  const add=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"+ Add"}); add.addEventListener("click",()=>noriAssignmentEditor(null,noriRoute)); head.appendChild(add); card.appendChild(head);
  const items=(typeof noriAssignmentsLoad==="function"?noriAssignmentsLoad():[]).filter(x=>x.status!=="done").sort((a,b)=>String(a.due||"9999").localeCompare(String(b.due||"9999")));
  const cols=noriEl("div",{class:"nori-assignment-columns"}); const buckets=[[],[]]; const today=Date.now(); items.forEach(x=>{const t=x.due?new Date(x.due).getTime():0;buckets[(t&&t<=today+7*86400000)?0:1].push(x)});
  ["THIS WEEK","BEYOND 1 WEEK"].forEach((label,i)=>{const col=noriEl("div",{class:"nori-assignment-column"});col.appendChild(noriEl("div",{class:"nori-column-title",text:label})); if(!buckets[i].length) col.appendChild(noriEl("div",{class:"nori-command-empty",text:"No assignments recorded."})); buckets[i].slice(0,6).forEach(x=>{const row=noriEl("div",{class:"nori-assignment"});row.appendChild(noriEl("div",{class:"nori-assignment-icon",text:(x.subject||"?").slice(0,1).toUpperCase()}));const body=noriEl("div",{});body.appendChild(noriEl("div",{class:"nori-assignment-title",text:x.title}));body.appendChild(noriEl("div",{class:"nori-assignment-meta",text:(x.subject||"")+" · "+(x.due?"DUE "+x.due:"NO DATE")}));row.appendChild(body);row.appendChild(noriEl("span",{class:"nori-priority "+(x.priority||"medium"),text:x.priority||"medium"}));row.addEventListener("click",()=>noriAssignmentEditor(x,noriRoute));col.appendChild(row)});cols.appendChild(col)}); card.appendChild(cols); return card;
}
function noriRenderPriorityPanel(){
  const card=noriEl("section",{class:"nori-section-card"}); const head=noriEl("div",{class:"nori-section-head"});head.appendChild(noriEl("h2",{text:"Short List of Priorities"}));const manage=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"Manage"});manage.addEventListener("click",()=>{const first=(noriAssignmentsLoad()||[])[0];noriAssignmentEditor(first,noriRoute)});head.appendChild(manage);card.appendChild(head);
  const items=noriAssignmentsLoad().filter(x=>x.status!=="done").sort((a,b)=>({high:0,medium:1,low:2}[a.priority]??1)-({high:0,medium:1,low:2}[b.priority]??1)).slice(0,4);const list=noriEl("div",{class:"nori-priority-list"});
  if(!items.length)list.appendChild(noriEl("div",{class:"nori-command-empty",text:"Add real assignments or academic priorities to build this list."}));items.forEach((x,i)=>{const r=noriEl("div",{class:"nori-priority-row"});r.appendChild(noriEl("div",{class:"nori-priority-num",text:String(i+1)}));r.appendChild(noriEl("div",{class:"nori-priority-text",text:x.title}));r.appendChild(noriEl("div",{class:"nori-priority-action",text:(x.priority||"medium").toUpperCase()}));r.addEventListener("click",()=>noriAssignmentEditor(x,noriRoute));list.appendChild(r)});card.appendChild(list);return card;
}
function noriRenderFocusCard(){
  const card=noriEl("section",{class:"nori-section-card"});
  card.appendChild(noriEl("div",{class:"nori-section-head"},[noriEl("h2",{text:"Today's Focus"}),noriEl("span",{text:"One task at a time"})]));
  const open=(typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():[]).filter(x=>x.status!=="done").sort((a,b)=>({high:0,medium:1,low:2}[a.priority]??1)-({high:0,medium:1,low:2}[b.priority]??1)||String(a.due||"9999").localeCompare(String(b.due||"9999")));
  const chosen=open[0]||null;
  const inner=noriEl("div",{class:"nori-focus-card"});
  const msg=noriEl("div",{class:"nori-focus-message"});msg.appendChild(noriEl("div",{class:"nori-focus-target",text:"•"}));
  const mt=noriEl("div",{});mt.appendChild(noriEl("strong",{text:chosen?chosen.title:"No priority task selected"}));mt.appendChild(noriEl("div",{text:chosen?(chosen.subject+" · "+(chosen.priority||"medium").toUpperCase()):"Add an assignment to make today's focus automatic."}));msg.appendChild(mt);inner.appendChild(msg);
  const saved=load('nori_focus_state',{seconds:1500,running:false,taskId:chosen&&chosen.id||null}); let seconds=Number(saved.seconds)||1500; let timer=null;
  const time=noriEl("div",{class:"nori-focus-time",text:""});inner.appendChild(time);const actions=noriEl("div",{class:"nori-focus-actions"});const start=noriEl("button",{class:"nori-btn nori-btn-primary",text:"START"});const reset=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"RESET"});actions.appendChild(start);actions.appendChild(reset);if(chosen){const done=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"MARK TASK DONE"});done.addEventListener("click",()=>{if(typeof noriAssignmentUpdate==='function')noriAssignmentUpdate(chosen.id,{status:"done"});save('nori_focus_state',{seconds:1500,running:false,taskId:null});noriRoute();});actions.appendChild(done);}inner.appendChild(actions);
  function paint(){time.textContent=String(Math.floor(seconds/60)).padStart(2,"0")+":"+String(seconds%60).padStart(2,"0");save('nori_focus_state',{seconds:seconds,running:!!timer,taskId:chosen&&chosen.id||null});}
  function stop(){if(timer){clearInterval(timer);timer=null;}start.textContent="START";paint();}
  start.addEventListener("click",()=>{if(timer){stop();return;}if(!seconds)seconds=1500;start.textContent="PAUSE";timer=setInterval(()=>{seconds=Math.max(0,seconds-1);paint();if(!seconds){stop();alert("Focus session complete. Verify or continue the task.");}},1000);paint();});
  reset.addEventListener("click",()=>{seconds=1500;stop();});paint();card.appendChild(inner);return card;
}
// tab: "home" | "recover" | "study" | "tracker" | "profile", or the legacy
// boolean (true = recover, false = home) kept so every existing call site
// across the other feature files keeps working unchanged.
function noriRenderCommandHeader(tab){
  const key = tab===true ? "recover" : (tab===false || tab==null) ? "home" : tab;
  const COPY = {
    home:{name:"HOME",sub:"Command Center"},
    recover:{name:"RECOVER",sub:"Where I'm left behind"},
    study:{name:"STUDY",sub:"Study Center"},
    tracker:{name:"TRACKER",sub:"Progress & Schedule"},
    profile:{name:"PROFILE",sub:"Account & System"}
  };
  const copy = COPY[key] || COPY.home;
  const header=noriEl("header",{class:"nori-shell-header"});
  const brand=noriEl("div",{class:"nori-brand"});
  const logo=noriEl("img",{class:"nori-brand-mark",src:noriCommandLogo(),alt:"KAGE Elite Academy emblem"});
  brand.appendChild(logo);
  const btxt=noriEl("div",{});
  btxt.appendChild(noriEl("div",{class:"nori-brand-name",text:copy.name}));
  btxt.appendChild(noriEl("div",{class:"nori-brand-sub",text:copy.sub}));
  brand.appendChild(btxt);
  header.appendChild(brand);
  const meta=noriEl("div",{class:"nori-header-meta"});
  const d=noriFormatCommandDate();
  const bits=d.split(",");
  meta.appendChild(noriEl("strong",{text:bits[0]||d}));
  meta.appendChild(noriEl("span",{text:bits.slice(1).join(",").trim()}));
  if (key==="recover") meta.appendChild(noriEl("div",{class:"nori-header-tagline",text:"No Excuses. Only Results."}));
  const headerActions=noriEl("div",{class:"nori-header-actions"});
  const cal=noriEl("a",{class:"nori-calendar-header-btn",href:"#/calendar",title:"Open Calendar",text:"CALENDAR"});
  headerActions.appendChild(cal);
  const cmd=noriEl("a",{class:"nori-calendar-header-btn",href:"#/command",title:"Open Daily Command",text:"COMMAND"});
  headerActions.appendChild(cmd);
  header.appendChild(headerActions);
  header.appendChild(meta);
  if (key==="home") header.appendChild(noriEl("img",{class:"nori-header-avatar",src:"assets/nori-avatar-home.png",alt:""}));
  return header;
}
function noriBottomNav(active){
  const nav=noriEl("nav",{class:"nori-bottom-nav","aria-label":"Primary navigation"});
  [["home","⌂","HOME","#/"],["recover","↻","RECOVER","#/recover"],["study","▤","STUDY","#/study"],["tracker","▥","TRACKER","#/progress"],["profile","♙","PROFILE","#/profile"]].forEach(x=>{
    const a=noriEl("a",{href:x[3],class:active===x[0]?"active":"",title:x[2]});
    a.appendChild(noriEl("span",{class:"nori-nav-icon",text:x[1]}));
    a.appendChild(noriEl("span",{text:x[2]}));
    nav.appendChild(a);
  });
  return nav;
}
function noriRenderHomeCommand(){
  const wrap=noriEl("div",{class:"nori-command-wrap nori-command-screen"});
  wrap.appendChild(noriRenderCommandHeader(false));

  const quote=noriEl("div",{class:"nori-quote"});
  quote.appendChild(noriEl("span",{class:"nori-quote-mark",text:"“"}));
  quote.appendChild(noriEl("span",{class:"nori-quote-text",text:"Discipline today. Freedom tomorrow."}));
  quote.appendChild(noriEl("span",{class:"nori-quote-author",text:"— Nori Rule"}));
  quote.appendChild(noriEl("span",{class:"nori-quote-mark nori-quote-mark-right",text:"”"}));
  wrap.appendChild(quote);
  if (typeof noriRenderNoriBrief === "function") wrap.appendChild(noriRenderNoriBrief());

  const assignments=noriRenderAssignmentPanel();
  wrap.appendChild(assignments);

  const lower=noriEl("div",{class:"nori-dashboard-grid nori-home-lower"});
  const left=noriEl("div",{});
  left.appendChild(noriRenderPriorityPanel());
  const active=noriActiveConsequences();
  const status=noriEl("section",{class:"nori-section-card nori-status-card"});
  const sh=noriEl("div",{class:"nori-section-head"});
  sh.appendChild(noriEl("h2",{text:"System Status"}));
  sh.appendChild(noriEl("span",{text:active.length?"Attention required":"Normal"}));
  status.appendChild(sh);
  const sb=noriEl("div",{class:"nori-status-body"});
  const statusTitle=active.length?"Active consequence":"System clear";
  sb.appendChild(noriEl("div",{class:"nori-status-title",text:statusTitle}));
  sb.appendChild(noriEl("p",{class:"nori-history-line",text:active.length?active.length+" active consequence(s). Review the restriction and recovery requirement before restoring normal access.":"No active consequence recorded. Continue with the highest academic priority."}));
  if(active.length){const b=noriEl("button",{class:"nori-btn nori-btn-primary",text:"VIEW CONSEQUENCES"});b.addEventListener("click",()=>location.hash="#/consequences");sb.appendChild(b)}
  status.appendChild(sb); left.appendChild(status);
  lower.appendChild(left);

  const right=noriEl("div",{});
  right.appendChild(noriRenderFocusCard());
  const art=noriEl("div",{class:"nori-command-art nori-command-art-home"});
  art.appendChild(noriEl("div",{class:"nori-art-label",text:"NORI / COMMAND"}));
  art.appendChild(noriEl("img",{src:"assets/nori-command-figure.png",alt:"Nori command artwork"}));
  right.appendChild(art);
  lower.appendChild(right);
  wrap.appendChild(lower);
  wrap.appendChild(noriBottomNav("home"));
  return wrap;
}
function noriRenderRecoverCommand(){
  const wrap=noriEl("div",{class:"nori-command-wrap nori-command-screen"});
  wrap.appendChild(noriRenderCommandHeader(true));
  const r=noriGetRecoverySummary();
  const hero=noriEl("section",{class:"nori-recovery-hero"});
  const main=noriEl("div",{class:"nori-recovery-main"});
  const l=noriEl("div",{});
  const recoveryHead=noriEl("div",{class:"nori-recovery-head"});
  recoveryHead.appendChild(noriEl("div",{class:"nori-block-title",text:"Academic Recovery Status"}));
  const schedule=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"SCHEDULE RECOVERY"});
  schedule.addEventListener("click",function(){if(window.noriCalendar&&window.noriCalendar.scheduleRecovery)window.noriCalendar.scheduleRecovery();});
  recoveryHead.appendChild(schedule); l.appendChild(recoveryHead);
  l.appendChild(noriEl("div",{class:"nori-recovery-percent",text:r.pct+"%"}));
  const tr=noriEl("div",{class:"nori-progress-track"}); tr.appendChild(noriEl("div",{class:"nori-progress-fill",style:"width:"+r.pct+"%"})); l.appendChild(tr);
  l.appendChild(noriEl("p",{class:"nori-lede",text:r.total?"Keep moving forward.":"No recovery backlog has been recorded yet."}));
  main.appendChild(l);
  const stats=noriEl("div",{class:"nori-recovery-stats"});
  [["Total topics",r.total],["Behind",Math.max(0,r.total-r.done)],["Caught up",r.done]].forEach(x=>{const q=noriEl("div",{class:"nori-recovery-stat"});q.appendChild(noriEl("span",{text:x[0]}));q.appendChild(noriEl("strong",{text:String(x[1])}));stats.appendChild(q)});
  main.appendChild(stats); hero.appendChild(main); wrap.appendChild(hero);

  const table=noriEl("section",{class:"nori-section-card"});
  const head=noriEl("div",{class:"nori-section-head"});
  head.appendChild(noriEl("h2",{text:"Subject Breakdown"}));
  const view=noriEl("a",{class:"nori-btn nori-btn-ghost",href:"#/phases/phase-5/backlog-mapping-priority/backlog-subject-recovery-map",text:"OVERVIEW"});
  head.appendChild(view); table.appendChild(head);
  const t=noriEl("table",{class:"nori-subject-table"});
  const hr=noriEl("tr",{}); ["Subject","Behind topics","Recovery progress","Action"].forEach(x=>hr.appendChild(noriEl("th",{text:x}))); t.appendChild(hr);
  const subjects=typeof NORI_TRACKED_SUBJECTS!=="undefined"?NORI_TRACKED_SUBJECTS:[];
  subjects.forEach(sub=>{
    const tr=noriEl("tr",{}); const name=noriEl("td",{}); name.appendChild(noriEl("span",{class:"nori-subject-dot",text:(sub.name||"?").slice(0,1).toUpperCase()})); name.appendChild(noriEl("strong",{text:sub.name})); tr.appendChild(name);
    const count=r.rows.filter(x=>String(x.subject||x.Subject||"").toLowerCase()===String(sub.name||"").toLowerCase()&&!String(x.verified||x.status||"").match(/yes|complete|done/i)).length;
    tr.appendChild(noriEl("td",{text:String(count)}));
    const prog=Math.max(0,Math.min(100,100-Math.min(100,count*10))); const td=noriEl("td",{}); td.appendChild(noriEl("div",{class:"nori-progress-value",text:prog+"%"})); const meter=noriEl("div",{class:"nori-mini-meter"}); meter.appendChild(noriEl("span",{style:"width:"+prog+"%"})); td.appendChild(meter); tr.appendChild(td);
    const act=noriEl("td",{}); const b=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"RECOVER"}); b.addEventListener("click",function(){if(window.noriCalendar&&window.noriCalendar.scheduleRecovery)window.noriCalendar.scheduleRecovery(sub.name);}); act.appendChild(b); const overview=noriEl("a",{class:"nori-btn nori-btn-ghost",href:"#/phases/phase-5/backlog-mapping-priority/backlog-subject-recovery-map",text:"MAP"}); act.appendChild(overview); tr.appendChild(act); t.appendChild(tr);
  });
  if(!subjects.length)t.appendChild(noriEl("tr",{},[noriEl("td",{colspan:"4",text:"No tracked subjects loaded."})]));
  table.appendChild(t); wrap.appendChild(table);

  const note=noriEl("section",{class:"nori-recovery-banner"});
  note.appendChild(noriEl("div",{class:"nori-recovery-banner-art"}));
  const nt=noriEl("div",{}); nt.appendChild(noriEl("strong",{text:"Being behind is not failure."})); nt.appendChild(noriEl("p",{text:"Recover. Catch up. Return to normal operation."})); note.appendChild(nt); wrap.appendChild(note);
  wrap.appendChild(noriBottomNav("recover")); return wrap;
}
function noriRenderHub() { return noriRenderHomeCommand(); }

/* ---------------------------- MEET NORI (stub — detailed build later) ---------------------------- */

function noriRenderMeetNori() {
  if (typeof noriMeetRenderPage !== "function") {
    // Never expose a dead placeholder for the primary Nori surface. If the
    // specialist renderer is unavailable, fall back to the integrated V31
    // conversation surface or a live command surface.
    if (typeof noriRenderIntegratedV31 === "function") return noriRenderIntegratedV31();
    const wrap = noriEl("div", { class: "nori-screen" });
    wrap.appendChild(noriRenderBreadcrumb([{ label: "NORI", hash: "#/" }, { label: "Meet Nori" }]));
    wrap.appendChild(noriEl("h1", { class: "nori-title", text: "Meet Nori" }));
    const card = noriEl("section", { class: "nori-panel" });
    card.appendChild(noriEl("p", { class: "nori-lede", text: "Nori's primary conversation surface is unavailable in this runtime." }));
    card.appendChild(noriEl("a", { class: "nori-btn nori-btn-primary", href: "#/command", text: "OPEN COMMAND CENTER →" }));
    wrap.appendChild(card);
    return wrap;
  }

  // Meet Nori's calculator reads handbook rules fetched by nori-rules.js
  // (nori-exam-result-rules.json etc. — the same files the AI backend
  // uses). That fetch is async, so this shows a brief loading state and
  // swaps in the real page once NORI_RULES_READY resolves, rather than
  // rendering with the rules constants still empty.
  const wrapper = noriEl("div", { class: "nori-screen" });
  wrapper.appendChild(noriEl("p", { class: "nori-empty-note", text: "Loading Nori\u2026" }));

  const rulesReady = (typeof NORI_RULES_READY !== "undefined") ? NORI_RULES_READY : Promise.resolve();
  rulesReady.then(function () {
    wrapper.innerHTML = "";
    if (typeof noriRenderNoriBrief === "function") wrapper.appendChild(noriRenderNoriBrief());
    wrapper.appendChild(noriMeetRenderPage());
  }).catch(function () {
    wrapper.innerHTML = "";
    wrapper.appendChild(noriRenderBreadcrumb([{ label: "NORI", hash: "#/" }, { label: "Meet Nori" }]));
    wrapper.appendChild(noriEl("p", { class: "nori-empty-note", text: "Nori's rules failed to load \u2014 check your connection and reload the page." }));
  });

  return wrapper;
}

/* ---------------------------- PHASES HOME (5 phase cards) ---------------------------- */

function noriRenderPhasesHub() {
  const wrap = noriEl("div", { class: "nori-screen" });
  wrap.appendChild(noriRenderBreadcrumb([{ label: "NORI", hash: "#/" }, { label: "Phase Forms" }]));
  wrap.appendChild(noriEl("h1", { class: "nori-title", text: "NORI PHASE" }));
  wrap.appendChild(noriEl("p", { class: "nori-lede", text: "Select a phase to open its systems." }));

  const grid = noriEl("div", { class: "nori-card-grid" });
  NORI_PHASE_DATA.phases.forEach(function (phase) {
    const locked = phase.status !== "active";
    const card = noriEl("a", {
      class: "nori-card" + (locked ? " nori-card-locked" : ""),
      href: locked ? "#" : "#/" + phase.id
    }, [
      noriEl("div", { class: "nori-card-title", text: phase.title }),
      noriEl("div", { class: "nori-card-subtitle", text: phase.subtitle }),
      noriEl("div", { class: "nori-card-status", text: locked ? "LOCKED" : "OPEN" }),
      noriEl("span", { class: "nori-card-cta", text: locked ? "VIEW STATUS →" : "OPEN →" })
    ]);
    grid.appendChild(card);
  });
  wrap.appendChild(grid);
  return wrap;
}

/* ---------------------------- PHASE VIEW (system cards) ---------------------------- */

function noriRenderPhase(phaseId) {
  const phase = noriFindPhase(phaseId);
  const wrap = noriEl("div", { class: "nori-screen" });
  wrap.appendChild(noriRenderBreadcrumb([
    { label: "NORI", hash: "#/" },
    { label: "Phase Forms", hash: "#/phases" },
    { label: phase.title }
  ]));
  wrap.appendChild(noriEl("h1", { class: "nori-title", text: phase.title }));
  wrap.appendChild(noriEl("p", { class: "nori-lede", text: phase.subtitle }));

  if (phase.systems.length === 0) {
    wrap.appendChild(noriEl("p", { class: "nori-empty-note", text: "No source PDF has been mapped for this phase yet." }));
    return wrap;
  }

  const grid = noriEl("div", { class: "nori-card-grid" });
  phase.systems.forEach(function (system) {
    const card = noriEl("a", {
      class: "nori-card",
      href: "#/" + phase.id + "/" + system.id
    }, [
      noriEl("div", { class: "nori-card-title", text: system.title }),
      noriEl("div", { class: "nori-card-subtitle", text: system.subtitle }),
      noriEl("div", { class: "nori-card-status", text: system.forms.length + " PAGES" }),
      noriEl("span", { class: "nori-card-cta", text: "OPEN SYSTEM →" })
    ]);
    grid.appendChild(card);
  });
  wrap.appendChild(grid);
  return wrap;
}

/* ---------------------------- SYSTEM VIEW (form list) ---------------------------- */

function noriRenderSystem(phaseId, systemId) {
  const phase = noriFindPhase(phaseId);
  const system = noriFindSystem(phase, systemId);
  const wrap = noriEl("div", { class: "nori-screen" });
  wrap.appendChild(noriRenderBreadcrumb([
    { label: "NORI", hash: "#/" },
    { label: "Phase Forms", hash: "#/phases" },
    { label: phase.title, hash: "#/" + phase.id },
    { label: system.title }
  ]));
  wrap.appendChild(noriEl("h1", { class: "nori-title", text: system.title }));
  wrap.appendChild(noriEl("p", { class: "nori-lede", text: system.subtitle }));

  const list = noriEl("div", { class: "nori-form-list" });
  system.forms.forEach(function (form, i) {
    const item = noriEl("a", {
      class: "nori-form-list-item",
      href: "#/" + phase.id + "/" + system.id + "/" + form.id
    }, [
      noriEl("span", { class: "nori-form-list-index", text: String(i + 1).padStart(2, "0") }),
      noriEl("span", { class: "nori-form-list-title", text: form.title }),
      noriEl("span", { class: "nori-form-list-arrow", text: "\u2192" }),
      noriEl("span", { class: "nori-form-list-cta", text: "OPEN" })
    ]);
    list.appendChild(item);
  });
  wrap.appendChild(list);
  return wrap;
}

/* ---------------------------- FIELD INPUT BUILDER ---------------------------- */

function noriBuildInput(field, idPrefix, currentValue) {
  const id = idPrefix + "-" + field.key;
  if (field.type === "textarea") {
    const t = noriEl("textarea", { id: id, rows: "3" });
    t.value = currentValue || "";
    return t;
  }
  if (field.type === "select") {
    const s = noriEl("select", { id: id });
    s.appendChild(noriEl("option", { value: "", text: "\u2014" }));
    field.options.forEach(function (opt) {
      const o = noriEl("option", { value: opt, text: opt });
      if (currentValue === opt) o.setAttribute("selected", "selected");
      s.appendChild(o);
    });
    return s;
  }
  const input = noriEl("input", { id: id, type: field.type === "number" ? "number" : field.type === "date" ? "date" : "text" });
  input.value = currentValue || "";
  return input;
}

/* ---------------------------- TABLE-LOG FORM ---------------------------- */

function noriRenderTableLog(form, storageKey) {
  const container = noriEl("div", {});
  const entries = noriLoadEntries(storageKey);

  // add-row form
  const addCard = noriEl("section", { class: "nori-panel" });
  addCard.appendChild(noriEl("h2", { class: "nori-panel-title", text: "Add entry" }));
  const formEl = noriEl("form", { class: "nori-entry-form" });

  form.columns.forEach(function (col) {
    if (col.type === "computed") return;
    const field = noriEl("div", { class: "nori-field" }, [
      noriEl("label", { for: "row-" + col.key, text: col.label }),
      noriBuildInput(col, "row", "")
    ]);
    formEl.appendChild(field);
  });

  const errorMsg = noriEl("p", { class: "nori-error", hidden: "hidden" });
  formEl.appendChild(errorMsg);
  formEl.appendChild(noriEl("button", { type: "submit", class: "nori-btn nori-btn-primary", text: "Add entry" }));
  addCard.appendChild(formEl);
  container.appendChild(addCard);

  // table
  const tableCard = noriEl("section", { class: "nori-panel" });
  tableCard.appendChild(noriEl("h2", { class: "nori-panel-title", text: "Records" }));
  const tableWrap = noriEl("div", { class: "nori-table-scroll" });
  const table = noriEl("table", { class: "nori-table" });
  const thead = noriEl("thead", {});
  const headRow = noriEl("tr", {});
  form.columns.forEach(function (col) { headRow.appendChild(noriEl("th", { text: col.label })); });
  headRow.appendChild(noriEl("th", { text: "" }));
  thead.appendChild(headRow);
  table.appendChild(thead);
  const tbody = noriEl("tbody", {});
  table.appendChild(tbody);
  tableWrap.appendChild(table);
  tableCard.appendChild(tableWrap);
  const emptyNote = noriEl("p", { class: "nori-empty-note", text: "No entries yet. Add the first one above." });
  tableCard.appendChild(emptyNote);
  container.appendChild(tableCard);

  function renderRows() {
    tbody.innerHTML = "";
    emptyNote.hidden = entries.length !== 0;
    entries.forEach(function (row, idx) {
      const tr = noriEl("tr", {});
      form.columns.forEach(function (col) {
        const val = col.type === "computed" ? col.computed(row) : (row[col.key] || "");
        tr.appendChild(noriEl("td", { text: val }));
      });
      const del = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "Delete" });
      del.addEventListener("click", function () {
        entries.splice(idx, 1);
        noriSaveEntries(storageKey, entries);
        renderRows();
      });
      tr.appendChild(noriEl("td", {}, [del]));
      tbody.appendChild(tr);
    });
  }
  renderRows();

  formEl.addEventListener("submit", function (e) {
    e.preventDefault();
    const row = {};
    let hasValue = false;
    form.columns.forEach(function (col) {
      if (col.type === "computed") return;
      const el = document.getElementById("row-" + col.key);
      row[col.key] = el.value;
      if (el.value) hasValue = true;
    });
    if (!hasValue) {
      errorMsg.textContent = "Fill in at least one field before adding.";
      errorMsg.hidden = false;
      return;
    }
    errorMsg.hidden = true;
    entries.push(row);
    noriSaveEntries(storageKey, entries);
    formEl.reset();
    renderRows();
  });

  // page-level persistent fields (e.g. a "checkpoint" summary block that sits
  // above/below the growing table, not tied to any single row)
  if (form.pageFields) {
    const fieldsKey = storageKey;
    const savedFields = noriLoadPageFields(fieldsKey);
    const fieldsCard = noriEl("section", { class: "nori-panel" });
    fieldsCard.appendChild(noriEl("h2", { class: "nori-panel-title", text: form.pageFieldsTitle || "Checkpoint" }));
    form.pageFields.forEach(function (pf) {
      const wrap = noriEl("div", { class: "nori-field" });
      wrap.appendChild(noriEl("label", { for: "pf-" + pf.key, text: pf.label }));
      const input = noriBuildInput(pf, "pf", savedFields[pf.key] || "");
      input.id = "pf-" + pf.key;
      input.addEventListener("input", function () {
        savedFields[pf.key] = input.value;
        noriSavePageFields(fieldsKey, savedFields);
      });
      wrap.appendChild(input);
      fieldsCard.appendChild(wrap);
    });
    container.appendChild(fieldsCard);
  }

  // page-level free text notes (single persistent block, not per-row)
  if (form.pageNotes) {
    const notesKey = storageKey + "_notes";
    const savedNotes = JSON.parse(localStorage.getItem(notesKey) || "{}");
    const notesCard = noriEl("section", { class: "nori-panel" });
    notesCard.appendChild(noriEl("h2", { class: "nori-panel-title", text: "Notes" }));
    form.pageNotes.forEach(function (note) {
      const field = noriEl("div", { class: "nori-field" });
      field.appendChild(noriEl("label", { for: "note-" + note.key, text: note.label }));
      const ta = noriEl("textarea", { id: "note-" + note.key, rows: "3" });
      ta.value = savedNotes[note.key] || "";
      ta.addEventListener("input", function () {
        savedNotes[note.key] = ta.value;
        localStorage.setItem(notesKey, JSON.stringify(savedNotes));
      });
      field.appendChild(ta);
      notesCard.appendChild(field);
    });
    container.appendChild(notesCard);
  }

  return container;
}

/* ---------------------------- SNAPSHOT-LOG FORM ---------------------------- */

function noriBuildFixedTableBlock(fixedTable, idPrefix, savedRows) {
  const block = noriEl("div", { class: "nori-fixed-table-wrap" });
  if (fixedTable.title) block.appendChild(noriEl("h3", { class: "nori-block-title", text: fixedTable.title }));
  const scroll = noriEl("div", { class: "nori-table-scroll" });
  const table = noriEl("table", { class: "nori-table nori-table-input" });
  const thead = noriEl("thead", {});
  const headRow = noriEl("tr", {});
  headRow.appendChild(noriEl("th", { text: fixedTable.rowLabel }));
  fixedTable.columns.forEach(function (col) { headRow.appendChild(noriEl("th", { text: col.label })); });
  thead.appendChild(headRow);
  table.appendChild(thead);
  const tbody = noriEl("tbody", {});
  fixedTable.rows.forEach(function (rowLabel, rIdx) {
    const tr = noriEl("tr", {});
    tr.appendChild(noriEl("td", { class: "nori-fixed-row-label", text: rowLabel }));
    fixedTable.columns.forEach(function (col) {
      const cellId = idPrefix + "-r" + rIdx + "-" + col.key;
      const savedVal = savedRows && savedRows[rowLabel] ? savedRows[rowLabel][col.key] : "";
      const input = noriBuildInput({ key: cellId, type: col.type, options: col.options }, "cell", savedVal);
      input.id = cellId;
      tr.appendChild(noriEl("td", {}, [input]));
    });
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  scroll.appendChild(table);
  block.appendChild(scroll);
  return block;
}

function noriReadFixedTable(fixedTable, idPrefix) {
  const result = {};
  fixedTable.rows.forEach(function (rowLabel, rIdx) {
    const rowData = {};
    fixedTable.columns.forEach(function (col) {
      const cellId = idPrefix + "-r" + rIdx + "-" + col.key;
      const el = document.getElementById(cellId);
      rowData[col.key] = el ? el.value : "";
    });
    result[rowLabel] = rowData;
  });
  return result;
}

function noriRenderSnapshotLog(form, storageKey) {
  const container = noriEl("div", {});
  const entries = noriLoadEntries(storageKey);

  const addCard = noriEl("section", { class: "nori-panel" });
  addCard.appendChild(noriEl("h2", { class: "nori-panel-title", text: "New entry" }));
  const formEl = noriEl("form", { class: "nori-entry-form" });

  // date, always present for a snapshot
  const dateField = noriEl("div", { class: "nori-field" }, [
    noriEl("label", { for: "snap-date", text: "Date" })
  ]);
  const dateInput = noriEl("input", { id: "snap-date", type: "date" });
  dateInput.value = new Date().toISOString().slice(0, 10);
  dateField.appendChild(dateInput);
  formEl.appendChild(dateField);

  // simple top-level fields
  (form.fields || []).forEach(function (field) {
    if (field.type === "computed") return;
    const wrap = noriEl("div", { class: "nori-field" }, [
      noriEl("label", { for: "snap-" + field.key, text: field.label }),
      noriBuildInput({ key: field.key, type: field.type, options: field.options }, "snap", "")
    ]);
    formEl.appendChild(wrap);
  });

  // reference table (static, informational only, not part of saved data)
  if (form.referenceTable) {
    const refBlock = noriEl("div", { class: "nori-reference-wrap" });
    refBlock.appendChild(noriEl("h3", { class: "nori-block-title", text: form.referenceTable.title }));
    const scroll = noriEl("div", { class: "nori-table-scroll" });
    const table = noriEl("table", { class: "nori-table nori-table-reference" });
    const thead = noriEl("thead", {});
    const headRow = noriEl("tr", {});
    form.referenceTable.columns.forEach(function (c) { headRow.appendChild(noriEl("th", { text: c })); });
    thead.appendChild(headRow);
    table.appendChild(thead);
    const tbody = noriEl("tbody", {});
    form.referenceTable.rows.forEach(function (row) {
      const tr = noriEl("tr", {});
      row.forEach(function (cell) { tr.appendChild(noriEl("td", { text: cell })); });
      tbody.appendChild(tr);
    });
    table.appendChild(tbody);
    scroll.appendChild(table);
    refBlock.appendChild(scroll);
    formEl.appendChild(refBlock);
  }

  // fixed-row table(s)
  if (form.fixedTable) formEl.appendChild(noriBuildFixedTableBlock(form.fixedTable, "fx1"));
  if (form.fixedTable2) formEl.appendChild(noriBuildFixedTableBlock(form.fixedTable2, "fx2"));

  // free text sections
  (form.freeText || []).forEach(function (ft) {
    const wrap = noriEl("div", { class: "nori-field" }, [
      noriEl("label", { for: "ft-" + ft.key, text: ft.label })
    ]);
    const ta = noriEl("textarea", { id: "ft-" + ft.key, rows: "3" });
    wrap.appendChild(ta);
    formEl.appendChild(wrap);
  });

  formEl.appendChild(noriEl("button", { type: "submit", class: "nori-btn nori-btn-primary", text: "Save entry" }));
  addCard.appendChild(formEl);
  container.appendChild(addCard);

  // history
  const historyCard = noriEl("section", { class: "nori-panel" });
  historyCard.appendChild(noriEl("h2", { class: "nori-panel-title", text: "History" }));
  const historyList = noriEl("div", { class: "nori-history-list" });
  historyCard.appendChild(historyList);
  const emptyNote = noriEl("p", { class: "nori-empty-note", text: "No saved entries yet." });
  historyCard.appendChild(emptyNote);
  container.appendChild(historyCard);

  function renderHistory() {
    historyList.innerHTML = "";
    emptyNote.hidden = entries.length !== 0;
    entries.slice().reverse().forEach(function (entry) {
      const realIdx = entries.indexOf(entry);
      const details = noriEl("details", { class: "nori-history-entry" });
      const summary = noriEl("summary", { text: entry.date || "(no date)" });
      details.appendChild(summary);
      const body = noriEl("div", { class: "nori-history-body" });

      Object.keys(entry.values || {}).forEach(function (k) {
        if (!entry.values[k]) return;
        body.appendChild(noriEl("p", { class: "nori-history-line", text: k + ": " + entry.values[k] }));
      });
      if (entry.freeText) {
        Object.keys(entry.freeText).forEach(function (k) {
          if (!entry.freeText[k]) return;
          body.appendChild(noriEl("p", { class: "nori-history-line", text: k + ": " + entry.freeText[k] }));
        });
      }
      const del = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "Delete this entry" });
      del.addEventListener("click", function () {
        entries.splice(realIdx, 1);
        noriSaveEntries(storageKey, entries);
        renderHistory();
      });
      body.appendChild(del);
      details.appendChild(body);
      historyList.appendChild(details);
    });
  }
  renderHistory();

  // sub-log: a growing table nested inside this snapshot page (e.g. a
  // Topic/Skill practice log that lives alongside a Mastery status table).
  // Reuses the table-log renderer with its own storage key.
  if (form.subLog) {
    const subWrap = noriEl("div", {});
    subWrap.appendChild(noriEl("h2", { class: "nori-section-heading", text: form.subLog.title }));
    subWrap.appendChild(noriRenderTableLog({ columns: form.subLog.columns }, storageKey + "_sublog_" + form.subLog.key));
    container.appendChild(subWrap);
  }

  formEl.addEventListener("submit", function (e) {
    e.preventDefault();
    const entry = { date: dateInput.value, values: {}, freeText: {} };
    (form.fields || []).forEach(function (field) {
      if (field.type === "computed") {
        entry.values[field.label] = "";
        return;
      }
      const el = document.getElementById("snap-" + field.key);
      entry.values[field.label] = el ? el.value : "";
    });
    if (form.fixedTable) entry.fixedTable = noriReadFixedTable(form.fixedTable, "fx1");
    if (form.fixedTable2) entry.fixedTable2 = noriReadFixedTable(form.fixedTable2, "fx2");
    (form.freeText || []).forEach(function (ft) {
      const el = document.getElementById("ft-" + ft.key);
      entry.freeText[ft.label] = el ? el.value : "";
    });
    entries.push(entry);
    noriSaveEntries(storageKey, entries);
    renderHistory();
  });

  return container;
}

/* ---------------------------- FORM VIEW ---------------------------- */

function noriRenderForm(phaseId, systemId, formId) {
  const phase = noriFindPhase(phaseId);
  const system = noriFindSystem(phase, systemId);
  const form = noriFindForm(system, formId);
  const storageKey = noriStorageKey(phaseId, systemId, formId);

  const wrap = noriEl("div", { class: "nori-screen" });
  wrap.appendChild(noriRenderBreadcrumb([
    { label: "NORI", hash: "#/" },
    { label: "Phase Forms", hash: "#/phases" },
    { label: phase.title, hash: "#/" + phase.id },
    { label: system.title, hash: "#/" + phase.id + "/" + system.id },
    { label: form.title }
  ]));
  wrap.appendChild(noriEl("h1", { class: "nori-title", text: form.title }));
  wrap.appendChild(noriEl("p", { class: "nori-lede", text: form.subtitle || "" }));

  if (form.kind === "reference") {
    // pure reference page — nothing to fill in, just the documentation table
    if (form.referenceTable) {
      const refCard = noriEl("section", { class: "nori-panel" });
      refCard.appendChild(noriEl("h2", { class: "nori-panel-title", text: form.referenceTable.title }));
      const scroll = noriEl("div", { class: "nori-table-scroll" });
      const table = noriEl("table", { class: "nori-table nori-table-reference" });
      const thead = noriEl("thead", {});
      const headRow = noriEl("tr", {});
      form.referenceTable.columns.forEach(function (c) { headRow.appendChild(noriEl("th", { text: c })); });
      thead.appendChild(headRow);
      table.appendChild(thead);
      const tbody = noriEl("tbody", {});
      form.referenceTable.rows.forEach(function (row) {
        const tr = noriEl("tr", {});
        row.forEach(function (cell) { tr.appendChild(noriEl("td", { text: cell })); });
        tbody.appendChild(tr);
      });
      table.appendChild(tbody);
      scroll.appendChild(table);
      refCard.appendChild(scroll);
      wrap.appendChild(refCard);
    }
  } else if (form.kind === "table-log") wrap.appendChild(noriRenderTableLog(form, storageKey));
  else wrap.appendChild(noriRenderSnapshotLog(form, storageKey));

  // prev / next within the same system
  const idx = system.forms.findIndex(function (f) { return f.id === formId; });
  const nav = noriEl("div", { class: "nori-form-nav" });
  if (idx > 0) {
    nav.appendChild(noriEl("a", {
      class: "nori-btn nori-btn-ghost", href: "#/" + phase.id + "/" + system.id + "/" + system.forms[idx - 1].id,
      text: "\u2190 " + system.forms[idx - 1].title
    }));
  }
  if (idx < system.forms.length - 1) {
    nav.appendChild(noriEl("a", {
      class: "nori-btn nori-btn-ghost", href: "#/" + phase.id + "/" + system.id + "/" + system.forms[idx + 1].id,
      text: system.forms[idx + 1].title + " \u2192"
    }));
  }
  wrap.appendChild(nav);

  return wrap;
}

/* ---------------------------- PROGRESS MAP ---------------------------- */

const NORI_TRACKED_SUBJECTS = [
  { name: "Mathematics", slug: "mathematics" },
  { name: "Physics", slug: "physics" },
  { name: "Chemistry", slug: "chemistry" },
  { name: "Biology", slug: "biology" },
  { name: "English", slug: "english" },
  { name: "Agriculture", slug: "agriculture" },
  { name: "Web / IT", slug: "web-it" }
];

// noriLoadPageFields lives in nori-storage.js now (canonical version,
// key matches directly — no separate "_pagefields" suffix needed here
// since the storage layer handles that internally).

// Combines AI-evaluated results (Band/Degree) with manually-filled Phase 1
// subject assessment records (raw score, no AI classification) into one
// chronological trend per subject.
function noriComputeSubjectTrend(subject) {
  const records = [];

  const evalHistory = noriHistoryLoadAll();
  (evalHistory[subject.name] || []).forEach(function (r) {
    records.push({ date: r.date || "", score: r.score, band: r.band, degree: r.degree, source: "AI evaluation" });
  });

  const formId = "assessment-record-" + subject.slug;
  const manualKey = noriStorageKey("phase-1", "control-pages-system", formId);
  noriLoadEntries(manualKey).forEach(function (row) {
    if (!row.score && !row.date) return;
    records.push({ date: row.date || "", score: row.score ? Number(row.score) : null, band: null, degree: null, source: "Manual entry" });
  });

  records.sort(function (a, b) { return (a.date || "").localeCompare(b.date || ""); });
  return records;
}

function noriRenderSubjectTrendRow(subject) {
  const records = noriComputeSubjectTrend(subject);
  const row = noriEl("div", { class: "nori-progress-subject-row" });
  row.appendChild(noriEl("div", { class: "nori-progress-subject-name", text: subject.name }));

  if (records.length === 0) {
    row.appendChild(noriEl("p", { class: "nori-empty-note", text: "No results recorded yet." }));
    return row;
  }

  const scored = records.filter(function (r) { return typeof r.score === "number" && !isNaN(r.score); });
  const latest = records[records.length - 1];
  const prevScored = scored.length > 1 ? scored[scored.length - 2] : null;
  const lastScored = scored.length ? scored[scored.length - 1] : null;

  const summary = noriEl("div", { class: "nori-progress-summary-line" });
  if (lastScored) {
    let trendMark = "";
    if (prevScored && typeof lastScored.score === "number" && typeof prevScored.score === "number") {
      if (lastScored.score > prevScored.score) trendMark = " \u2191";
      else if (lastScored.score < prevScored.score) trendMark = " \u2193";
      else trendMark = " \u2192";
    }
    summary.appendChild(noriEl("span", { text: "Latest: " + lastScored.score + "%" + trendMark }));
  }
  if (latest.band) summary.appendChild(noriEl("span", { text: " \u2014 " + latest.band + " / " + latest.degree }));
  row.appendChild(summary);

  if (lastScored) {
    const track = noriEl("div", { class: "nori-progress-bar-track" });
    const pct = Math.max(0, Math.min(100, lastScored.score));
    const fill = noriEl("div", { class: "nori-progress-bar-fill", style: "width:" + pct + "%" });
    track.appendChild(fill);
    row.appendChild(track);
  }

  const historyList = noriEl("div", { class: "nori-progress-history" });
  records.slice(-5).reverse().forEach(function (r) {
    const line = (r.date || "(no date)") + " \u2014 " + (typeof r.score === "number" ? r.score + "%" : "\u2014") +
      (r.band ? " \u2014 " + r.band + " / " + r.degree : "") + " (" + r.source + ")";
    historyList.appendChild(noriEl("p", { class: "nori-history-line", text: line }));
  });
  row.appendChild(historyList);
  if (scored.length >= 2) {
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("viewBox", "0 0 300 90"); svg.setAttribute("class", "nori-score-chart"); svg.setAttribute("aria-label", "Score trend");
    const points = scored.slice(-10); const poly = document.createElementNS("http://www.w3.org/2000/svg", "polyline");
    poly.setAttribute("fill","none"); poly.setAttribute("stroke","currentColor"); poly.setAttribute("stroke-width","2");
    poly.setAttribute("points", points.map(function(p,i){ const x=10+(i*280/Math.max(1,points.length-1)); const y=80-(Math.max(0,Math.min(100,p.score))*0.7); return x+","+y; }).join(" "));
    svg.appendChild(poly); row.appendChild(svg);
  }

  return row;
}

function noriRenderSystemSnapshot() {
  const box = noriEl("div", {});

  // Backlog (Phase 5)
  const backlogEntries = noriLoadEntries(noriStorageKey("phase-5", "backlog-management", "academic-backlog-tracker"));
  const backlogTotal = backlogEntries.length;
  const backlogResolved = backlogEntries.filter(function (r) { return r.verified === "Yes"; }).length;

  // Recovery status (Phase 5)
  const recoveryCards = noriLoadEntries(noriStorageKey("phase-5", "emergency-recovery", "emergency-recovery-card"));
  const latestRecovery = recoveryCards.length ? recoveryCards[recoveryCards.length - 1] : null;
  const checklistEntries = noriLoadEntries(noriStorageKey("phase-5", "return-review", "return-to-normal-checklist"));
  const latestChecklist = checklistEntries.length ? checklistEntries[checklistEntries.length - 1] : null;
  let checklistDone = 0, checklistTotal = 0;
  if (latestChecklist && latestChecklist.fixedTable) {
    Object.keys(latestChecklist.fixedTable).forEach(function (rowLabel) {
      checklistTotal++;
      if (latestChecklist.fixedTable[rowLabel].complete === "Yes") checklistDone++;
    });
  }

  // Awards (Phase 4)
  const awardEntries = noriLoadEntries(noriStorageKey("phase-4", "award-merit-records", "award-record"));
  const rankEntries = noriLoadEntries(noriStorageKey("phase-4", "rank-system", "rank-progress-record"));
  const latestRank = rankEntries.length ? rankEntries[rankEntries.length - 1].newRank : null;
  const meritFields = noriLoadPageFields(noriStorageKey("phase-4", "award-merit-records", "merit-point-ledger"));

  const stats = [
    { label: "Open backlog items", value: (backlogTotal - backlogResolved) + " of " + backlogTotal },
    {
      label: "Recovery status",
      value: latestRecovery
        ? (checklistTotal ? checklistDone + "/" + checklistTotal + " return checks complete" : "Active \u2014 no checklist yet")
        : "No recovery period on record"
    },
    { label: "Awards recorded", value: String(awardEntries.length) },
    { label: "Current rank", value: latestRank || "\u2014" },
    { label: "Merit balance", value: meritFields.balanceRemaining || meritFields.currentBalance || "\u2014" }
  ];

  stats.forEach(function (s) {
    const line = noriEl("div", { class: "nori-snapshot-stat" });
    line.appendChild(noriEl("span", { class: "nori-snapshot-stat-label", text: s.label }));
    line.appendChild(noriEl("span", { class: "nori-snapshot-stat-value", text: s.value }));
    box.appendChild(line);
  });

  const meritNumber = Number(meritFields.balanceRemaining || meritFields.currentBalance || (typeof NORI_DECIDE_STATE !== "undefined" && NORI_DECIDE_STATE && NORI_DECIDE_STATE.meritLedger ? NORI_DECIDE_STATE.meritLedger.balance : 0)) || 0;
  const tiers=[5,10,20,30]; const next=tiers.find(function(v){return meritNumber<v;})||30;
  const meritWrap=noriEl("div",{class:"nori-merit-progress"}); meritWrap.appendChild(noriEl("p",{class:"nori-history-line",text:"Merit progress: "+meritNumber+" / "+next+" points to next reward tier"}));
  const mt=noriEl("div",{class:"nori-progress-bar-track"}); const mf=noriEl("div",{class:"nori-progress-bar-fill",style:"width:"+Math.min(100,(meritNumber/next)*100)+"%"}); mt.appendChild(mf); meritWrap.appendChild(mt); box.appendChild(meritWrap);
  return box;
}

/* ---------------------------------------------------------------------
   EXCELLENCE / HONOR / ELITE — computed from real saved history, not
   auto-saved. These need longer-horizon evidence (streaks, yearly
   averages, model-exam cycles) the app can actually check from what's
   already recorded — some Honor/Elite criteria are inherently a judgment
   call the handbook itself calls "difficult to dispute", and are marked
   for manual review rather than guessed at.
   --------------------------------------------------------------------- */

const NORI_HIGHER_AWARD_SUBJECT_SLUGS = ["mathematics", "physics", "chemistry", "biology", "english", "agriculture", "web-it"];

function noriCollectAllModelExamEntries() {
  const entries = [];
  NORI_HIGHER_AWARD_SUBJECT_SLUGS.forEach(function (slug) {
    const key = noriStorageKey("phase-1", "control-pages-system", "assessment-record-" + slug);
    noriLoadEntries(key).forEach(function (row) {
      if (row.task === "Model Exam" && row.score !== "" && row.score !== undefined) {
        entries.push({ date: row.date || "", score: Number(row.score) });
      }
    });
  });
  entries.sort(function (a, b) { return a.date.localeCompare(b.date); });
  return entries;
}

function noriDaysSince(dateStr) {
  if (!dateStr) return 0;
  const then = new Date(dateStr + "T00:00:00");
  const now = new Date();
  const days = Math.floor((now - then) / (1000 * 60 * 60 * 24));
  return isNaN(days) ? 0 : days;
}

// Days since the last recorded breach — or, if none ever recorded, days
// since the earliest tracked activity (so an app with zero usage doesn't
// falsely read as an infinite streak).
function noriComputeDisciplineStreakDays() {
  const breachHistory = noriBreachHistoryLoadAll();
  let latestBreachDate = null;
  Object.keys(breachHistory).forEach(function (cat) {
    breachHistory[cat].forEach(function (r) {
      if (r.date && (!latestBreachDate || r.date > latestBreachDate)) latestBreachDate = r.date;
    });
  });
  if (latestBreachDate) return noriDaysSince(latestBreachDate);

  const allHistory = noriHistoryLoadAll();
  let earliest = null;
  Object.keys(allHistory).forEach(function (subj) {
    allHistory[subj].forEach(function (r) { if (r.date && (!earliest || r.date < earliest)) earliest = r.date; });
  });
  return earliest ? noriDaysSince(earliest) : 0;
}

function noriComputeYearlyAverage(subject) {
  const records = noriComputeSubjectTrend(subject).filter(function (r) { return typeof r.score === "number"; });
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 365);
  const cutoffStr = cutoff.toISOString().slice(0, 10);
  const recent = records.filter(function (r) { return r.date >= cutoffStr; });
  if (recent.length < 3) return null;
  const avg = recent.reduce(function (s, r) { return s + r.score; }, 0) / recent.length;
  return { avg: avg, count: recent.length };
}

function noriEvaluateHigherAwards() {
  const results = { excellence: [], honor: [], elite: [] };
  const modelExams = noriCollectAllModelExamEntries();
  const disciplineDays = noriComputeDisciplineStreakDays();

  let streak90Evidence = null;
  const latestPerSubject = [];
  NORI_TRACKED_SUBJECTS.forEach(function (subject) {
    const records = noriComputeSubjectTrend(subject).filter(function (r) { return typeof r.score === "number"; });
    let run = 0, maxRun = 0;
    records.forEach(function (r) { if (r.score >= 90) { run++; maxRun = Math.max(maxRun, run); } else run = 0; });
    if (maxRun >= 5 && !streak90Evidence) streak90Evidence = subject.name + " (" + maxRun + " results in a row \u2265 90%)";
    latestPerSubject.push(records.length ? records[records.length - 1].score : null);
  });
  results.excellence.push({ row: "90%+ streak", qualified: !!streak90Evidence, evidence: streak90Evidence || "No subject currently has 5 consecutive results \u2265 90%." });

  const fiveSubjCount = latestPerSubject.filter(function (s) { return s !== null && s >= 90; }).length;
  results.excellence.push({ row: "Five-subject excellence", qualified: fiveSubjCount >= 5, evidence: fiveSubjCount + " of 8 subjects currently \u2265 90% on their latest result." });

  const last12Models = modelExams.slice(-12);
  const modelMastery = last12Models.length >= 12 && last12Models.every(function (m) { return m.score >= 80; });
  results.excellence.push({
    row: "12-model mastery", qualified: modelMastery,
    evidence: modelExams.length + " Model Exam entries recorded" + (modelExams.length >= 12 ? ", last 12 all \u2265 80%: " + (modelMastery ? "yes" : "no") : " (needs 12).")
  });

  [30, 60, 90].forEach(function (n) {
    results.excellence.push({ row: n + "-day discipline streak", qualified: disciplineDays >= n, evidence: disciplineDays + " days since the last recorded breach." });
  });

  const yearly90 = [], yearly95 = [], fiveSubjHonor = [];
  NORI_TRACKED_SUBJECTS.forEach(function (subject) {
    const y = noriComputeYearlyAverage(subject);
    if (y && y.avg >= 90) { yearly90.push(subject.name + " (" + y.avg.toFixed(1) + "%)"); fiveSubjHonor.push(subject.name); }
    if (y && y.avg >= 95) yearly95.push(subject.name);
  });
  results.honor.push({ row: "90% yearly honor", qualified: yearly90.length > 0, evidence: yearly90.length ? yearly90.join("; ") : "No subject has a 365-day average \u2265 90% yet (needs at least 3 results in the window)." });
  results.honor.push({ row: "95% yearly honor", qualified: yearly95.length > 0, evidence: yearly95.length ? yearly95.join(", ") + " at or above 95% yearly average." : "No subject has a 365-day average \u2265 95% yet." });
  results.honor.push({ row: "Complete assessment honor", qualified: false, manual: true, evidence: "Not automatically computable \u2014 needs weighted coverage across all assessment categories, which this app doesn't track. Review manually." });
  results.honor.push({ row: "Five-subject honor", qualified: fiveSubjHonor.length >= 5, evidence: fiveSubjHonor.length + " of 8 subjects at a 365-day average \u2265 90%." });
  const last12ModelsHonor = modelExams.slice(-12);
  const modelHonor = last12ModelsHonor.length >= 12 && last12ModelsHonor.every(function (m) { return m.score >= 90; });
  results.honor.push({
    row: "12-model exam honor", qualified: modelHonor,
    evidence: modelExams.length + " Model Exam entries recorded" + (modelExams.length >= 12 ? ", last 12 all \u2265 90%: " + (modelHonor ? "yes" : "no") : " (needs 12).")
  });
  results.honor.push({ row: "90-day discipline honor", qualified: disciplineDays >= 90, evidence: disciplineDays + " days since the last recorded breach." });
  results.honor.push({ row: "180-day discipline honor", qualified: disciplineDays >= 180, evidence: disciplineDays + " days since the last recorded breach." });

  const distinctionEntries = noriLoadEntries(noriStorageKey("phase-4", "distinction-level-2", "distinction-tracker"));
  const hasComeback = distinctionEntries.some(function (e) {
    return e.fixedTable && e.fixedTable["Comeback distinction"] && e.fixedTable["Comeback distinction"].verified === "Yes";
  });
  const anyExcellence = results.excellence.some(function (r) { return r.qualified; });
  results.elite.push({ row: "Academic mastery", qualified: anyExcellence, evidence: "Based on whether any Excellence category above is currently met." });
  results.elite.push({ row: "Long-term consistency", qualified: disciplineDays >= 60, evidence: disciplineDays + " days since the last recorded breach." });
  results.elite.push({ row: "Exam performance", qualified: modelMastery || modelHonor, evidence: "Based on 12-model mastery/honor above." });
  results.elite.push({ row: "Discipline record", qualified: disciplineDays >= 90, evidence: disciplineDays + " days since the last recorded breach." });
  results.elite.push({ row: "Recovery / comeback record", qualified: hasComeback, evidence: hasComeback ? "At least one verified Comeback Distinction on file." : "No verified Comeback Distinction on file yet." });
  results.elite.push({ row: "Complete recognition record", qualified: false, manual: true, evidence: "The handbook reserves Elite for a record \u201cdifficult to dispute\u201d \u2014 that's a holistic judgment call this app won't make for you. Review manually." });

  return results;
}

function noriSaveHigherAwardGroup(phaseId, systemId, formId, qualifyingRows, buildColumns) {
  const phase = noriFindPhase(phaseId);
  const system = noriFindSystem(phase, systemId);
  const form = noriFindForm(system, formId);
  const entry = { date: new Date().toISOString().slice(0, 10), values: {}, freeText: {}, fixedTable: {} };
  form.fixedTable.rows.forEach(function (rowLabel) {
    entry.fixedTable[rowLabel] = {};
    form.fixedTable.columns.forEach(function (col) { entry.fixedTable[rowLabel][col.key] = ""; });
  });
  qualifyingRows.forEach(function (r) {
    if (entry.fixedTable[r.row]) Object.assign(entry.fixedTable[r.row], buildColumns(r));
  });
  const key = noriStorageKey(phaseId, systemId, formId);
  const existing = noriLoadEntries(key);
  existing.push(entry);
  noriSaveEntries(key, existing);
}

function noriRenderHigherAwardsCard() {
  const card = noriEl("section", { class: "nori-panel" });
  card.appendChild(noriEl("h2", { class: "nori-panel-title", text: "Excellence, Honor & Elite" }));
  card.appendChild(noriEl("p", { class: "nori-lede", text: "Computed from your saved history. Items marked \u2753 need a judgment call the app won't make for you." }));

  const evalResult = noriEvaluateHigherAwards();

  function renderGroup(title, rows, phaseId, systemId, formId, buildColumns) {
    const group = noriEl("div", { class: "nori-progress-subject-row" });
    group.appendChild(noriEl("div", { class: "nori-progress-subject-name", text: title }));
    rows.forEach(function (r) {
      const mark = r.manual ? "\u2753 " : (r.qualified ? "\u2705 " : "\u2716\ufe0f ");
      group.appendChild(noriEl("p", { class: "nori-history-line", text: mark + r.row + " \u2014 " + r.evidence }));
    });
    const qualifying = rows.filter(function (r) { return r.qualified && !r.manual; });
    if (qualifying.length) {
      const saveBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "Save " + qualifying.length + " qualifying item(s) to Phase 4" });
      const status = noriEl("p", { class: "nori-meet-status" });
      saveBtn.addEventListener("click", function () {
        noriSaveHigherAwardGroup(phaseId, systemId, formId, qualifying, buildColumns);
        status.textContent = "Saved to " + title + ".";
        saveBtn.disabled = true;
      });
      group.appendChild(saveBtn);
      group.appendChild(status);
    }
    return group;
  }

  card.appendChild(renderGroup("Excellence (Level 3)", evalResult.excellence, "phase-4", "excellence-level-3", "excellence-record",
    function (r) { return { qualification: r.row, achieved: "Yes", evidence: r.evidence }; }));
  card.appendChild(renderGroup("Honor (Level 4)", evalResult.honor, "phase-4", "honor-elite-levels-4-5", "honor-record",
    function (r) { return { qualification: r.row, result: r.evidence, evidenceDate: new Date().toISOString().slice(0, 10) }; }));
  card.appendChild(renderGroup("Elite (Level 5)", evalResult.elite, "phase-4", "honor-elite-levels-4-5", "elite-recognition",
    function (r) { return { evidence: r.evidence, verified: "Yes" }; }));

  return card;
}
function noriFormatBytes(bytes) {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(2) + " MB";
}

function noriRenderDataBackupCard() {
  const card = noriEl("section", { class: "nori-panel" });
  card.appendChild(noriEl("h2", { class: "nori-panel-title", text: "Data & Backup" }));

  const report = noriStorageReport();
  card.appendChild(noriEl("p", { class: "nori-history-line", text: report.totalKeys + " stored items \u2014 " + noriFormatBytes(report.totalBytes) + " total" }));

  const actions = noriEl("div", { class: "nori-checkin-actions" });
  const exportBtn = noriEl("button", { class: "nori-btn nori-btn-primary", text: "\ud83d\udcbe Download Backup" });
  const importInput = noriEl("input", { type: "file", accept: "application/json", style: "display:none" });
  const importBtn = noriEl("button", { class: "nori-btn nori-btn-ghost", text: "\ud83d\udcc5 Import Backup" });
  actions.appendChild(exportBtn);
  actions.appendChild(importBtn);
  actions.appendChild(importInput);
  card.appendChild(actions);

  const status = noriEl("p", { class: "nori-meet-status" });
  card.appendChild(status);

  exportBtn.addEventListener("click", function () {
    noriDownloadBackup();
    status.textContent = "Backup downloaded.";
  });

  importBtn.addEventListener("click", function () { importInput.click(); });
  importInput.addEventListener("change", function () {
    const file = importInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function () {
      const backup = noriSafeParse(reader.result, null);
      const result = noriImportBackup(backup, "merge");
      if (result.error) { status.textContent = result.error; return; }
      status.textContent = "Imported " + result.imported + " item(s), skipped " + result.skipped + " already-present item(s). Reloading\u2026";
      setTimeout(function () { location.reload(); }, 1200);
    };
    reader.readAsText(file);
  });

  return card;
}


/* ---------------------------- ACTIVE CONSEQUENCES ---------------------------- */
function noriActiveConsequences() {
  const events = (typeof NORI_DECIDE_STATE !== "undefined" && NORI_DECIDE_STATE && Array.isArray(NORI_DECIDE_STATE.events)) ? NORI_DECIDE_STATE.events : [];
  const labels = {
    social_media_lock_short:"Short social media lock", short_form_content_lock:"Short-form content lock",
    non_academic_browsing_restriction:"Non-academic browsing restriction", academic_use_only_mode:"Academic-use-only mode",
    streaming_restriction:"Streaming restriction", binge_content_restriction:"Binge-content restriction", entertainment_browsing_lock:"Entertainment browsing lock", delayed_entertainment_unlock:"Delayed entertainment unlock",
    gaming_suspension_short:"Short gaming suspension", online_game_restriction:"Online game restriction", protected_hour_gaming_lock:"Protected-hour gaming lock", gaming_suspension_full:"Full gaming suspension",
    academic_purpose_only_research:"Academic-purpose-only research mode", curiosity_reserve:"Curiosity Reserve", research_queue:"Research Queue",
    planning_window_lock:"Planning window lock", planning_capture_only:"Planning capture only",
  };
  const hours = { social_media_lock_short:24, short_form_content_lock:48, non_academic_browsing_restriction:48, academic_use_only_mode:72, streaming_restriction:48, binge_content_restriction:48, delayed_entertainment_unlock:24, gaming_suspension_short:48, online_game_restriction:48 };
  const out=[]; const now=Date.now();
  events.forEach(function(e){
    if (String(e.recoveryStatus || "pending").toLowerCase() === "recovered" || String(e.overrideStatus || "").toLowerCase() === "accept") return;
    [e.appliedConsequence,e.secondaryConsequence].forEach(function(id){ if(!id)return; const start=new Date(e.timestamp||Date.now()).getTime(); const h=hours[id]; const end=h?start+h*3600000:null; if(!end||end>now) out.push({eventId:e.eventId,degree:e.degree,domain:e.primaryDomain,consequenceId:id,label:labels[id]||id,startedAt:e.timestamp,endsAt:end?new Date(end).toISOString():null,recoveryStatus:e.recoveryStatus||"pending"}); });
  });
  return out;
}
function noriRenderActiveConsequences() {
  const wrap=noriEl("div",{class:"nori-screen"});
  wrap.appendChild(noriRenderBreadcrumb([{label:"NORI",hash:"#/"},{label:"Active Consequences"}]));
  wrap.appendChild(noriEl("h1",{class:"nori-title",text:"Active Consequences"}));
  wrap.appendChild(noriEl("p",{class:"nori-lede",text:"A single view of current restrictions and their recovery state."}));
  const card=noriEl("section",{class:"nori-panel"}); const active=noriActiveConsequences();
  if(!active.length) card.appendChild(noriEl("p",{class:"nori-empty-note",text:"No active consequences recorded."}));
  active.forEach(function(c){ const item=noriEl("div",{class:"nori-consequence-item"}); item.appendChild(noriEl("div",{class:"nori-progress-subject-name",text:c.label})); item.appendChild(noriEl("p",{class:"nori-history-line",text:"Degree "+c.degree+" · "+(c.domain||"domain")+" · recovery: "+c.recoveryStatus})); item.appendChild(noriEl("p",{class:"nori-history-line",text:c.endsAt?"Ends: "+new Date(c.endsAt).toLocaleString():"Ends when recovery conditions are satisfied."})); card.appendChild(item); });
  wrap.appendChild(card);
  const refresh=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"Refresh"}); refresh.addEventListener("click",function(){noriRoute();}); wrap.appendChild(refresh);
  if (typeof noriBrainEngine !== "undefined") { noriBrainEngine.listEvents().then(function(){ if(location.hash.indexOf("#/consequences")===0) noriRoute(); }).catch(function(){}); }
  return wrap;
}

/* ---------------------------- DEGREE 5 CASE FILE ---------------------------- */
const NORI_CASE_FIELDS=["caseId","initialEvent","evidence","context","assessmentType","classification","capacityAssessment","causeAnalysis","failureSignature","degreeHistory","interventionHistory","interventionEffectiveness","recoveryHistory","stabilityHistory","stabilityCycleHistory","overrideHistory","recurrencePattern","academicImpact","systemIntegrityAudit","reasonForD5","reasonInternalExhausted","handbookBoundaryStatus"];
function noriRenderHandbookCaseFile(){
  const wrap=noriEl("div",{class:"nori-screen"}); wrap.appendChild(noriRenderBreadcrumb([{label:"NORI",hash:"#/"},{label:"Handbook Boundary"}]));
  wrap.appendChild(noriEl("h1",{class:"nori-title",text:"Handbook Boundary Case File"}));
  wrap.appendChild(noriEl("p",{class:"nori-lede",text:"Terminal review only. Complete the record before any Handbook Authority transition is considered."}));
  const events=(typeof NORI_DECIDE_STATE!=="undefined"&&NORI_DECIDE_STATE&&NORI_DECIDE_STATE.events)||[];
  const d5=events.filter(function(e){return Number(e.degree)===5;});
  const card=noriEl("section",{class:"nori-panel"});
  if(!d5.length){card.appendChild(noriEl("p",{class:"nori-empty-note",text:"No Degree 5 event is currently recorded. This screen remains available for audit, but it does not create a Degree 5 case by itself."})); wrap.appendChild(card); if (typeof noriBrainEngine !== "undefined") noriBrainEngine.listEvents().then(function(){if(location.hash.indexOf("#/handbook-boundary")===0)noriRoute();}).catch(function(){}); return wrap;}
  const event=d5[d5.length-1]; card.appendChild(noriEl("p",{class:"nori-history-line",text:"Latest Degree 5 event: "+event.eventId+" · "+(event.subject||"Unknown subject")+" · "+(event.timestamp||"")}));
  const inputs={}; NORI_CASE_FIELDS.forEach(function(k){ const label=noriEl("label",{class:"nori-meet-field-label",text:k}); const input=noriEl("textarea",{class:"nori-checkin-typed",rows:"2",placeholder:k}); inputs[k]=input; card.appendChild(label); card.appendChild(input); });
  inputs.caseId.value=event.eventId; inputs.initialEvent.value=JSON.stringify(event,null,2); inputs.assessmentType.value=event.assessmentType||""; inputs.classification.value=(event.failureType||"")+" / Degree "+event.degree; inputs.failureSignature.value=JSON.stringify(event.failureSignature||{},null,2); inputs.degreeHistory.value=JSON.stringify(events.map(function(e){return {eventId:e.eventId,degree:e.degree,timestamp:e.timestamp};}),null,2); inputs.academicImpact.value=event.band||"";
  const status=noriEl("p",{class:"nori-meet-status"}); const reviewBtn=noriEl("button",{class:"nori-btn nori-btn-primary",text:"Review Boundary"}); const finalizeBtn=noriEl("button",{class:"nori-btn nori-btn-ghost",text:"Finalize Transition"}); card.appendChild(reviewBtn); card.appendChild(finalizeBtn); card.appendChild(status);
  reviewBtn.addEventListener("click",async function(){try{const r=await noriBrainEngine.reviewHandbookBoundary(event.eventId,inputs.handbookBoundaryStatus.value||"STATE_A");status.textContent=(r.review&&r.review.state)||JSON.stringify(r);}catch(e){status.textContent="Review failed: "+e.message;}});
  finalizeBtn.addEventListener("click",async function(){const data={}; for(const k of NORI_CASE_FIELDS){ if(!inputs[k].value.trim()){status.textContent="Missing: "+k;return;} data[k]=inputs[k].value.trim(); } try{const r=await noriBrainEngine.finalizeHandbookTransition(event.eventId,data,[]);status.textContent=r.success?"Case file finalized — transition recorded.":(r.reason||"Not finalized.");}catch(e){status.textContent="Finalize failed: "+e.message;}});
  wrap.appendChild(card); return wrap;
}

function noriRenderProgress() {
  const wrap = noriEl("div", { class: "nori-screen" });
  wrap.appendChild(noriRenderBreadcrumb([{ label: "NORI", hash: "#/" }, { label: "Current State" }]));
  wrap.appendChild(noriEl("h1", { class: "nori-title", text: "Current State" }));
  wrap.appendChild(noriEl("p", { class: "nori-lede", text: "Subject trends and a whole-system snapshot, read from what's already saved." }));

  const trendCard = noriEl("section", { class: "nori-panel" });
  trendCard.appendChild(noriEl("h2", { class: "nori-panel-title", text: "Subject Trends" }));
  NORI_TRACKED_SUBJECTS.forEach(function (subject) { trendCard.appendChild(noriRenderSubjectTrendRow(subject)); });
  wrap.appendChild(trendCard);

  const snapshotCard = noriEl("section", { class: "nori-panel" });
  snapshotCard.appendChild(noriEl("h2", { class: "nori-panel-title", text: "System Snapshot" }));
  snapshotCard.appendChild(noriRenderSystemSnapshot());
  wrap.appendChild(snapshotCard);

  const meritCard = noriEl("section", { class: "nori-panel" });
  meritCard.appendChild(noriEl("h2", { class: "nori-panel-title", text: "Merit Progress" }));
  const ledger = (typeof NORI_DECIDE_STATE !== "undefined" && NORI_DECIDE_STATE && NORI_DECIDE_STATE.meritLedger) || null;
  const points = ledger && typeof ledger.balance === "number" ? ledger.balance : 0;
  const nextTier = points < 10 ? 10 : points < 25 ? 25 : points < 50 ? 50 : points < 100 ? 100 : 150;
  const pct = Math.max(0, Math.min(100, Math.round((points / nextTier) * 100)));
  meritCard.appendChild(noriEl("p", { class:"nori-history-line", text: points + " Merit Points · next tier at " + nextTier }));
  const meter=noriEl("div",{class:"nori-merit-meter"}); const fill=noriEl("div",{class:"nori-merit-meter-fill"}); fill.style.width=pct+"%"; meter.appendChild(fill); meritCard.appendChild(meter);
  wrap.appendChild(meritCard);
  wrap.appendChild(noriRenderHigherAwardsCard());

  wrap.appendChild(noriRenderDataBackupCard());

  return wrap;
}

/* ---------------------------- ROUTER ---------------------------- */


function noriRenderTasks() {
  const wrap = noriEl("div", { class: "nori-command-wrap nori-command-screen" });
  wrap.appendChild(noriRenderCommandHeader(false));
  wrap.appendChild(noriRenderBreadcrumb([{ label: "NORI", hash: "#/" }, { label: "Tasks" }]));
  wrap.appendChild(noriEl("h1", { class: "nori-title", text: "TASK COMMAND" }));
  wrap.appendChild(noriEl("p", { class: "nori-lede", text: "Create, edit, complete and verify academic responsibilities from one place." }));
  wrap.appendChild(noriRenderAssignmentPanel());
  const actions=noriEl("div",{class:"nori-checkin-actions"});
  const add=noriEl("button",{class:"nori-btn nori-btn-primary",text:"+ NEW TASK"});
  add.addEventListener("click",function(){noriAssignmentEditor(null,noriRoute);});
  actions.appendChild(add);
  const study=noriEl("a",{class:"nori-btn nori-btn-ghost",href:"#/study",text:"STUDY CENTER →"}); actions.appendChild(study);
  wrap.appendChild(actions); wrap.appendChild(noriBottomNav("home")); return wrap;
}

function noriRenderFocus() {
  const wrap=noriEl("div", { class: "nori-command-wrap nori-command-screen" });
  wrap.appendChild(noriRenderCommandHeader(false));
  wrap.appendChild(noriRenderBreadcrumb([{ label: "NORI", hash: "#/" }, { label: "Focus Mode" }]));
  wrap.appendChild(noriEl("h1", { class: "nori-title", text: "FOCUS MODE" }));
  wrap.appendChild(noriEl("p", { class: "nori-lede", text: "Choose the task, start a bounded focus session, and review selected-app restrictions." }));
  wrap.appendChild(noriRenderFocusCard());
  const card=noriEl("section",{class:"nori-section-card"});
  const head=noriEl("div",{class:"nori-section-head"}); head.appendChild(noriEl("h2",{text:"App Restrictions"}));
  const b=noriEl("button",{class:"nori-btn nori-btn-primary",text:"OPEN FOCUS SETTINGS"});
  b.addEventListener("click",function(){if(window.NoriFocusPolicyV2){const ov=noriEl("div",{class:"nori-modal"}),m=noriEl("div",{class:"nori-modal-card"});const h=noriEl("div",{class:"nori-modal-head"});h.appendChild(noriEl("h2",{text:"Focus App Selection"}));h.appendChild(noriEl("button",{class:"nori-btn nori-btn-ghost",text:"Close"}));h.lastChild.addEventListener("click",()=>ov.remove());m.appendChild(h);const body=noriEl("div",{class:"nori-focus-policy-host"});m.appendChild(body);ov.appendChild(m);document.body.appendChild(ov);NoriFocusPolicyV2.render(body);}else alert("Focus settings are unavailable in this build.");});
  head.appendChild(b); card.appendChild(head);
  card.appendChild(noriEl("p",{class:"nori-history-line",text:"Nori reasons about selected apps by context: academic calls/chats can remain allowed, while scrolling, reels, unnecessary messaging and posting can be restricted."}));
  wrap.appendChild(card); wrap.appendChild(noriBottomNav("home")); return wrap;
}

function noriRenderResults() {
  const wrap=noriEl("div", { class: "nori-command-wrap nori-command-screen" });
  wrap.appendChild(noriRenderCommandHeader(false));
  wrap.appendChild(noriRenderBreadcrumb([{ label: "NORI", hash: "#/" }, { label: "Results" }]));
  wrap.appendChild(noriEl("h1", { class: "nori-title", text: "RESULTS" }));
  wrap.appendChild(noriEl("p", { class: "nori-lede", text: "Review recorded results and open the controlled result-entry workflow." }));
  const all=noriHistoryLoadAll(), rows=[]; Object.keys(all).forEach(function(subject){(all[subject]||[]).forEach(function(r){rows.push({subject:subject,score:r.score,date:r.date||"",band:r.band||"",degree:r.degree||""});});});
  rows.sort(function(a,b){return String(b.date).localeCompare(String(a.date));});
  const card=noriEl("section",{class:"nori-section-card"});
  const head=noriEl("div",{class:"nori-section-head"}); head.appendChild(noriEl("h2",{text:"Recorded Results"}));
  const add=noriEl("button",{class:"nori-btn nori-btn-primary",text:"+ RECORD RESULT"}); add.addEventListener("click",function(){location.hash="#/meet-nori";}); head.appendChild(add); card.appendChild(head);
  const list=noriEl("div",{class:"nori-verification-list"});
  if(!rows.length) list.appendChild(noriEl("div",{class:"nori-command-empty",text:"No results recorded yet. Use Record Result to establish real evidence."}));
  rows.slice(0,20).forEach(function(r){const row=noriEl("div",{class:"nori-verification-row"});const l=noriEl("div",{});l.appendChild(noriEl("strong",{text:r.subject+" — "+r.score+"%"}));l.appendChild(noriEl("small",{text:(r.date||"No date")+(r.band?" · "+r.band:"")+(r.degree?" · Degree "+r.degree:"")}));row.appendChild(l);row.appendChild(noriEl("span",{class:"nori-state-chip",text:"RECORDED"}));list.appendChild(row);});
  card.appendChild(list); wrap.appendChild(card);
  const actions=noriEl("div",{class:"nori-checkin-actions"}); actions.appendChild(noriEl("a",{class:"nori-btn nori-btn-ghost",href:"#/progress",text:"VIEW ANALYTICS →"})); actions.appendChild(noriEl("a",{class:"nori-btn nori-btn-ghost",href:"#/meet-nori",text:"MEET NORI →"})); wrap.appendChild(actions); wrap.appendChild(noriBottomNav("tracker")); return wrap;
}

function noriRenderFeatureLocked(label) {
  const wrap = noriEl("div", { class: "nori-screen" });
  wrap.appendChild(noriRenderBreadcrumb([{ label: "NORI", hash: "#/" }, { label: label }]));
  wrap.appendChild(noriEl("h1", { class: "nori-title", text: label }));
  const card = noriEl("section", { class: "nori-panel" });
  card.appendChild(noriEl("p", { class: "nori-empty-note", text: "Coming soon \u2014 not available in this build yet." }));
  wrap.appendChild(card);
  return wrap;
}

function noriRoute() {
  const hash = location.hash.replace(/^#\/?/, "");
  const parts = hash.split("/").filter(Boolean);
  NORI_APP_ROOT.innerHTML = "";

  // Router-level guard, in addition to the hub cards showing "Coming soon"
  // — a direct link/bookmark to a locked route shouldn't bypass the flag.
  const routeFlag = parts[0] === "progress" ? "currentState"
    : parts[0] === "calendar" ? "currentState"
    : parts[0] === "alarms" ? "reminders"
    : parts[0] === "time-tools" ? "currentState"
    : parts[0] === "math-speed" ? "currentState"
    : parts[0] === "settings" ? "currentState"
    : parts[0] === "meet-nori" ? "aiChat"
    : parts[0] === "consequences" ? "currentState"
    : parts[0] === "recover" ? "currentState"
    : parts[0] === "tasks" ? "currentState"
    : parts[0] === "focus" ? "currentState"
    : parts[0] === "results" ? "currentState"
    : parts[0] === "analytics" ? "currentState"
    : parts[0] === "handbook-boundary" ? "phaseForms"
    : parts[0] === "study" ? "phaseForms"
    : parts[0] === "exams" ? "currentState"
    : parts[0] === "profile" ? "currentState"
    : parts[0] === "notifications" ? "currentState"
    : parts[0] === "inbox" ? "currentState"
    : parts[0] === "integrity" ? "currentState"
    : parts[0] === "command" ? "currentState"
    : parts[0] === "diagnostic" ? "currentState"
    : parts[0] === "timeline" ? "currentState"
    : parts[0] === "smart-integrity" ? "currentState"
    : parts[0] === "verification" ? "currentState"
    : (parts[0] === "phases" || parts.length >= 1) ? "phaseForms"
    : null;

  let view;
  if (routeFlag && !NORI_FEATURES[routeFlag]) {
    view = noriRenderFeatureLocked(
      parts[0] === "progress" ? "Current State" : parts[0] === "meet-nori" ? "Meet Nori" : "Phase Forms"
    );
  } else if (parts.length === 0) view = noriRenderHub();
  else if (parts[0] === "progress") view = noriRenderTracker();
  else if (parts[0] === "recover") view = noriRenderRecoverCommand();
  else if (parts[0] === "tasks") view = noriRenderTasks();
  else if (parts[0] === "focus") view = noriRenderFocus();
  else if (parts[0] === "results") view = noriRenderResults();
  else if (parts[0] === "analytics") view = noriRenderTracker();
  else if (parts[0] === "calendar") view = typeof noriRenderCalendar === "function" ? noriRenderCalendar() : noriRenderFeatureLocked("Calendar");
  else if (parts[0] === "alarms") view = typeof noriRenderAlarms === "function" ? noriRenderAlarms() : noriRenderFeatureLocked("Voice Alarms");
  else if (parts[0] === "time-tools" || parts[0] === "math-speed") view = window.NoriTimeToolsV35 ? window.NoriTimeToolsV35.render() : noriRenderFeatureLocked("Timer & Stopwatch");
  else if (parts[0] === "consequences") view = noriRenderActiveConsequences();
  else if (parts[0] === "handbook-boundary") view = noriRenderHandbookCaseFile();
  else if (parts[0] === "meet-nori") view = noriRenderMeetNori();
  else if (parts[0] === "study") view = noriRenderStudy();
  else if (parts[0] === "exams") view = noriRenderExams();
  else if (parts[0] === "settings") view = typeof noriRenderSettingsV34 === "function" ? noriRenderSettingsV34() : noriRenderProfile();
  else if (parts[0] === "profile") view = noriRenderProfile();
  else if (parts[0] === "notifications") view = typeof noriKageRenderNotifications === "function" ? noriKageRenderNotifications() : noriRenderNotifications();
  else if (parts[0] === "inbox") view = typeof noriKageRenderInbox === "function" ? noriKageRenderInbox() : noriRenderFeatureLocked("Nori Inbox");
  else if (parts[0] === "integrity") view = typeof noriKageRenderIntegrity === "function" ? noriKageRenderIntegrity() : noriRenderFeatureLocked("System Integrity");
  else if (parts[0] === "command") view = typeof noriRenderAdaptiveCommand === "function" ? noriRenderAdaptiveCommand() : (typeof noriRenderDailyCommand === "function" ? noriRenderDailyCommand() : noriRenderFeatureLocked("Daily Command"));
  else if (parts[0] === "diagnostic") view = typeof noriRenderDiagnostic === "function" ? noriRenderDiagnostic() : noriRenderFeatureLocked("Academic Diagnostic");
  else if (parts[0] === "timeline") view = typeof noriRenderTimeline === "function" ? noriRenderTimeline() : noriRenderFeatureLocked("System Timeline");
  else if (parts[0] === "smart-integrity") view = typeof noriRenderSmartIntegrity === "function" ? noriRenderSmartIntegrity() : noriRenderFeatureLocked("Integration Audit");
  else if (parts[0] === "verification") view = noriRenderVerification();
  else if (parts[0] === "phases") view = noriRenderPhasesHub();
  else if (parts.length === 1) view = noriRenderPhase(parts[0]);
  else if (parts.length === 2) view = noriRenderSystem(parts[0], parts[1]);
  else view = noriRenderForm(parts[0], parts[1], parts[2]);

  NORI_APP_ROOT.appendChild(view);
  if (typeof noriKageAfterRoute === "function") noriKageAfterRoute(parts, view);
  window.scrollTo(0, 0);
}

window.addEventListener("hashchange", noriRoute);
window.addEventListener("DOMContentLoaded", noriRoute);
