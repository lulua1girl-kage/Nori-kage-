/* NORI V48 — Language Specialist.
 * English is Nori's operating language. Arabic/Spanish/Japanese are first-class
 * specialist modes with dictionary, explanation, correction, translation and teaching routes.
 */
(function(){'use strict';
 const LANG={en:{name:'English',locale:'en-US',role:'PRIMARY_OPERATING_LANGUAGE',depth:'expert'},ar:{name:'Arabic',locale:'ar',role:'SPECIALIST',depth:'expert'},es:{name:'Español',locale:'es',role:'SPECIALIST',depth:'expert'},ja:{name:'日本語',locale:'ja',role:'SPECIALIST',depth:'expert'}};
 const DICT={
  en:{hello:{definition:'a greeting used when meeting or addressing someone',examples:['Hello, how are you?']},however:{definition:'used to introduce a contrast or qualification',examples:['The plan is difficult; however, it is possible.']}},
  ar:{مرحبا:{definition:'a common greeting',transliteration:'marḥaban'}},
  es:{hola:{definition:'a common greeting',english:'hello'}},
  ja:{こんにちは:{definition:'a daytime greeting',romaji:'konnichiwa'}}
 };
 function normalize(x){return String(x||'').trim().toLowerCase();}
 function detect(text){const t=String(text||'');if(/[\u3040-\u30ff\u4e00-\u9faf]/.test(t))return'ja';if(/[\u0600-\u06ff]/.test(t))return'ar';if(/[ñáéíóúü¿¡]/i.test(t))return'es';return'en';}
 function lookup(word,lang){lang=lang||detect(word);const d=(DICT[lang]||{})[normalize(word)]||(DICT[lang]||{})[word];return d?Object.assign({language:lang,word,found:true},d):{language:lang,word,found:false};}
 function teach(request){const lang=request.language&&LANG[request.language]?request.language:detect(request.text);return {language:lang,languageProfile:LANG[lang],mode:request.mode||'teach',text:request.text||'',strategy:['diagnose meaning and level','explain clearly in English unless user chooses the target language','give a natural example','check understanding','correct errors without shaming','adapt difficulty and register']};}
 function capabilities(){return {operatingLanguage:'en',languages:Object.keys(LANG),features:['dictionary','definition','translation','grammar','writing-correction','reading','listening','speaking-practice','register','examples','contrastive-learning','vocabulary-review','spaced-retrieval','mistake-tracking']};}
 window.NoriLanguageSpecialist={LANG,detect,lookup,teach,capabilities};
})();
