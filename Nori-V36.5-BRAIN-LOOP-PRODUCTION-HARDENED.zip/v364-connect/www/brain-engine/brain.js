/**
 * THE BRAIN
 * ---------------------------------------------------------------------------
 * Orchestrates the full decision flow from the specs:
 *
 *   RESULT/EVENT -> VERIFY -> CLASSIFY ASSESSMENT -> ANALYZE CONTEXT
 *   -> IDENTIFY CAUSE -> CHECK HISTORY -> DETERMINE DEGREE
 *   -> SELECT FIXED CONSEQUENCE -> ACADEMIC CORRECTION -> VERIFY -> AUDIT
 *
 * Engines stay separate on purpose (Degree 1 §26, Degree 2 §35):
 * academic / context / degree / consequence / override / audit /
 * degree3 / degree4 / degree5. No single function here is allowed to skip
 * straight from "low score" to "consequence" — see processAcademicEvent().
 *
 * Degree 5 is fully wired in here (not a separate patch file) — it is the
 * terminal internal escalation level: if its 10-step Escalation Proof Gate
 * fails, the event does NOT escalate further; it stops and changes
 * strategy. There is no Degree 6. If Degree 5 genuinely exhausts every
 * internal option, the only next step is Handbook Boundary review, which
 * still never lets an unsafe action execute automatically (safetyGuard is
 * re-run at that transition too).
 * ---------------------------------------------------------------------------
 */

const academicEngine = require("./engines/academicEngine");
const contextEngine = require("./engines/contextEngine");
const degreeEngine = require("./engines/degreeEngine");
const consequenceEngine = require("./engines/consequenceEngine");
const overrideEngine = require("./engines/overrideEngine");
const degree3Engine = require("./engines/degree3Engine");
const degree4Engine = require("./engines/degree4Engine");
const degree5Engine = require("./engines/degree5Engine");
const awardEngine = require("./engines/awardEngine");
const auditEngine = require("./engines/auditEngine");
const meritShop = require("./data/meritShop");
const { DOMAINS } = require("./data/consequenceLibrary");

/**
 * Main entry point for a new academic result / behavioral event.
 *
 * @param {object} input
 *   subject: string
 *   assessment: { type, percentage, missedConcepts, totalConceptsCovered,
 *                 carelessErrorCount, applicationErrorCount }
 *   contextEvent: { domain, durationMinutes, statedPurpose, isEmergency,
 *                   wasAccidental, continuedAfterAwareness,
 *                   reportedDifficultDay, evidenceSources }
 *   secondaryContextEvent: same shape as contextEvent, optional
 *   history: { degree1EventsUnresolved, degree1EventsTotal,
 *              sameDomainRepeatCount, degree2EventsTotal, priorIneffectiveIds }
 */
function processAcademicEvent(input) {
  // 1. VERIFY + CLASSIFY ASSESSMENT
  const academicResult = academicEngine.analyzeAssessment(input.assessment);

  // 2. ANALYZE CONTEXT (primary domain, and secondary if present)
  const contextResult = contextEngine.classifyContext(input.contextEvent);
  const secondaryContextResult = input.secondaryContextEvent
    ? contextEngine.classifyContext(input.secondaryContextEvent)
    : null;

  // 3. IDENTIFY CAUSE / FAILURE TYPE (Academic / Disciplinary / Combined)
  const failureType = degreeEngine.classifyFailureType(academicResult, contextResult);

  // 4. CHECK HISTORY + DETERMINE DEGREE (rule-based, never AI "feeling")
  const degreeDecision = degreeEngine.determineDegree(input.history || {}, failureType, contextResult);

  // 5. SELECT FIXED CONSEQUENCE — only if a breach was actually established.
  //    Academic-only failures get correction, not a domain consequence.
  let consequences = { primary: null, secondary: null };
  if (contextResult.breachEligible) {
    consequences = consequenceEngine.selectConsequenceSet({
      primaryDomain: input.contextEvent.domain,
      secondaryDomain: secondaryContextResult?.breachEligible ? input.secondaryContextEvent.domain : null,
      degree: degreeDecision.degree,
      band: academicResult.band,
      priorIneffectiveIds: input.history?.priorIneffectiveIds || [],
    });
  }

  // 6. ACADEMIC CORRECTION — independent of discipline, applies whenever
  //    there's a real academic band, regardless of breach status.
  const academicCorrection = academicResult.band
    ? consequenceEngine.selectConsequence(DOMAINS.ACADEMIC_CORRECTION, degreeDecision.degree, academicResult.band, [])
    : null;

  // 7. AUDIT — record everything, observation separated from inference.
  const auditRecord = auditEngine.recordEvent({
    subject: input.subject,
    assessmentType: academicResult.type,
    score: academicResult.percentage,
    band: academicResult.band,
    errorDistribution: academicResult.errorDistribution,
    observed: input.contextEvent,
    inferred: { contextType: contextResult.type, reasoning: contextResult.reasoning },
    confidence: contextResult.confidence,
    failureType,
    degree: degreeDecision.degree,
    degreeReasons: degreeDecision.reasons,
    primaryDomain: input.contextEvent.domain,
    secondaryDomain: secondaryContextResult?.breachEligible ? input.secondaryContextEvent.domain : null,
    appliedConsequence: consequences.primary?.id || null,
    secondaryConsequence: consequences.secondary?.id || null,
    academicCorrection: academicCorrection?.id || null,
    missedConcepts: academicResult.concepts.missed,
    overrideStatus: "none_requested",
    recoveryStatus: "pending",
  });

  // 8. SUGGESTED MERIT — Level 1's two score-band awards (Academic Score
  //    Merit / Model Exam Merit) are directly derivable from the score just
  //    analyzed, so surface them here for the caller to grant onto a ledger
  //    if they choose to (grantScoreBandMerit still requires an explicit
  //    call — this never auto-writes to any ledger).
  const suggestedMerit = {
    academicScore: awardEngine.evaluateScoreBandMerit(academicResult.percentage),
  };

  return {
    academicResult,
    contextResult,
    secondaryContextResult,
    failureType,
    degree: degreeDecision.degree,
    degreeReasons: degreeDecision.reasons,
    consequences,
    academicCorrection,
    suggestedMerit,
    auditRecord,
  };
}

/**
 * Handle a Human Override request against a previously recorded event.
 */
function requestOverride(eventId, overrideRequest, history) {
  const priorEvent = auditEngine.getEvent(eventId);
  if (!priorEvent) return { success: false, reason: "Event not found" };

  const decision = overrideEngine.evaluateOverride(
    { ...overrideRequest, originalConfidence: priorEvent.confidence },
    history
  );

  priorEvent.overrideStatus = decision.outcome;
  priorEvent.overrideReasoning = decision.reasoning;
  priorEvent.overrideScope = decision.scope;

  if (decision.outcome === "accept") {
    priorEvent.appliedConsequence = null;
    priorEvent.secondaryConsequence = null;
  } else if (decision.outcome === "partial_accept" && decision.scope === "consequence") {
    priorEvent.secondaryConsequence = null; // narrow, don't erase the primary record
  }

  return { success: true, decision, event: priorEvent };
}

/**
 * Mark recovery conditions met and restore normal operation for an event.
 * History remains; only the active state changes (Degree 1 §24).
 */
function completeRecovery(eventId, verification) {
  const updated = auditEngine.updateRecoveryStatus(eventId, {
    status: "recovered",
    verification,
    completedAt: new Date().toISOString(),
  });
  return updated;
}

/**
 * Attempt to escalate a previously recorded event to Degree 3.
 * Only proceeds if predefined Degree 3 entry conditions are actually met
 * (Degree 3 spec §2) — this function will not escalate just because it's
 * called; checkDegree3Entry is the real gate.
 */
function escalateToDegree3(eventId, history, diagnosisInput) {
  const priorEvent = auditEngine.getEvent(eventId);
  if (!priorEvent) return { success: false, reason: "Event not found" };

  const entryCheck = degree3Engine.checkDegree3Entry(history);
  if (!entryCheck.eligible) {
    return {
      success: false,
      reason: "Degree 3 entry conditions not met — remaining at current degree.",
      checkedConditions: entryCheck,
    };
  }

  const diagnosis = degree3Engine.diagnoseFailureState({
    academicResult: { band: priorEvent.band },
    contextResult: { breachEligible: !!priorEvent.appliedConsequence, type: diagnosisInput.contextType },
    systemIntegrityIssue: !!diagnosisInput.systemIntegrityIssue,
    understoodMaterial: diagnosisInput.understoodMaterial ?? null,
  });

  const causeBoard = degree3Engine.buildCauseBoard(diagnosisInput.causeBoardInputs || {});

  const response = degree3Engine.selectDegree3Response(
    diagnosis.state,
    priorEvent.primaryDomain,
    history.priorIneffectiveIds || []
  );

  const signature = degree3Engine.generateFailureSignature({
    eventId,
    domain: priorEvent.primaryDomain,
    failureState: diagnosis.state,
    academicImpact: priorEvent.band,
  });

  const mirror = degree3Engine.buildConsequenceMirror(diagnosisInput.mirrorInputs || {});

  const masteryGates = (priorEvent.missedConcepts || []).map((c) => degree3Engine.initMasteryGate(c));

  // Update the historical record in place — history remains, active state changes.
  priorEvent.degree = 3;
  priorEvent.degree3EntryReasons = entryCheck.reasons;
  priorEvent.degree3FailureState = diagnosis.state;
  priorEvent.degree3Reasoning = diagnosis.reasoning;
  priorEvent.causeBoard = causeBoard;
  priorEvent.failureSignature = signature;
  priorEvent.consequenceMirror = mirror;
  priorEvent.masteryGates = masteryGates;
  priorEvent.appliedConsequence = response.consequence?.id || (response.systemCorrectionRequired ? null : priorEvent.appliedConsequence);
  priorEvent.systemCorrectionRequired = !!response.systemCorrectionRequired;
  priorEvent.recoveryStatus = "pending_degree3_recovery";

  return {
    success: true,
    entryCheck,
    diagnosis,
    causeBoard,
    response,
    signature,
    mirror,
    masteryGates,
    event: priorEvent,
  };
}

/**
 * Advance one concept's Mastery Gate with new evidence. When every gate on
 * the event reaches verified/stable, the event's recovery status updates —
 * this is what "recovery" actually requires under Degree 3, not just time
 * passing (Degree 3 spec §34).
 */
function advanceMasteryGate(eventId, concept, evidenceOfNextState) {
  const priorEvent = auditEngine.getEvent(eventId);
  if (!priorEvent || !priorEvent.masteryGates) return { success: false, reason: "Event or mastery gates not found" };

  const gate = priorEvent.masteryGates.find((g) => g.concept === concept);
  if (!gate) return { success: false, reason: `No mastery gate for concept "${concept}"` };

  degree3Engine.advanceMastery(gate, evidenceOfNextState);

  const allComplete = priorEvent.masteryGates.every(degree3Engine.isMasteryComplete);
  if (allComplete) {
    priorEvent.recoveryStatus = "mastery_complete_pending_stability_window";
  }

  return { success: true, gate, allComplete, event: priorEvent };
}

/**
 * Attempt to escalate a previously recorded (Degree 3) event to Degree 4.
 * Only proceeds if predefined Degree 4 entry conditions are met.
 */
function escalateToDegree4(eventId, history, input) {
  const priorEvent = auditEngine.getEvent(eventId);
  if (!priorEvent) return { success: false, reason: "Event not found" };

  const entryCheck = degree4Engine.checkDegree4Entry(history);
  if (!entryCheck.eligible) {
    return { success: false, reason: "Degree 4 entry conditions not met.", checkedConditions: entryCheck };
  }

  // System self-correction takes priority over everything else (spec §36):
  // if this event was actually a system defect, correct it and stop here.
  if (input.systemDefectConfirmed) {
    const correction = degree4Engine.systemSelfCorrection(input.systemDefectReason || "Unspecified system defect confirmed at Degree 4 review.");
    priorEvent.degree = 4;
    priorEvent.systemSelfCorrection = correction;
    priorEvent.appliedConsequence = null;
    priorEvent.secondaryConsequence = null;
    priorEvent.recoveryStatus = "system_corrected_no_user_action_required";
    return { success: true, systemCorrected: true, correction, event: priorEvent };
  }

  const rootCauseGraph = degree4Engine.buildRootCauseGraph(input.causes || []);
  const breakpointResult = degree4Engine.identifyBreakpoint(input.timeline || []);
  const realityLayers = degree4Engine.buildRealityLayers(input.realityLayers || {});
  const confidence = degree4Engine.tagEvidenceConfidence(input.evidenceSources || []);

  const response = degree4Engine.selectDegree4Response(
    rootCauseGraph,
    priorEvent.primaryDomain,
    history.priorIneffectiveIds || []
  );

  priorEvent.degree = 4;
  priorEvent.degree4EntryReasons = entryCheck.reasons;
  priorEvent.rootCauseGraph = rootCauseGraph;
  priorEvent.breakpoint = breakpointResult;
  priorEvent.realityLayers = realityLayers;
  priorEvent.degree4Confidence = confidence;
  priorEvent.appliedConsequence = response.consequence?.id || null;
  priorEvent.autonomyState = priorEvent.autonomyState
    ? degree4Engine.stepAutonomy(priorEvent.autonomyState, "restrict")
    : "monitored";
  priorEvent.recoveryStatus = "pending_degree4_recovery";

  return { success: true, entryCheck, rootCauseGraph, breakpointResult, realityLayers, confidence, response, event: priorEvent };
}

/** Check a set of events for gaming patterns. Investigation only — never automatic guilt. */
function checkAntiGaming(signals) {
  return degree4Engine.evaluateAntiGaming(signals);
}

/** Group related events into causal chains so only the root gets a full consequence. */
function consolidateEvents(events) {
  return degree4Engine.consolidateCausalChains(events);
}

/** Start, log, and review a 14-day Verified Stability Cycle for an event's domain. */
function startStabilityCycle(eventId, lengthDays = 14) {
  const priorEvent = auditEngine.getEvent(eventId);
  if (!priorEvent) return { success: false, reason: "Event not found" };
  priorEvent.stabilityCycle = degree4Engine.initiateStabilityCycle(priorEvent.primaryDomain, lengthDays);
  return { success: true, cycle: priorEvent.stabilityCycle };
}

function logStabilityDay(eventId, dayResult) {
  const priorEvent = auditEngine.getEvent(eventId);
  if (!priorEvent || !priorEvent.stabilityCycle) return { success: false, reason: "No active stability cycle for this event" };
  degree4Engine.recordStabilityDay(priorEvent.stabilityCycle, dayResult);
  const review = degree4Engine.reviewStabilityCycle(priorEvent.stabilityCycle);
  if (review.verdict === "verified_stable") {
    priorEvent.recoveryStatus = "stable_pending_restoration";
    priorEvent.autonomyState = degree4Engine.stepAutonomy(priorEvent.autonomyState || "controlled", "restore");
  }
  return { success: true, cycle: priorEvent.stabilityCycle, review };
}

// ---------------------------------------------------------------------------
// DEGREE 5 — terminal internal escalation, behavioral accountability &
// Handbook Boundary. Fully wired in (previously shipped as a separate
// integration patch — now applied directly).
// ---------------------------------------------------------------------------

/**
 * Attempt to escalate a previously recorded (Degree 4) event to Degree 5.
 * Only proceeds if predefined Degree 5 entry conditions are met AND the
 * Escalation Proof Gate (10 steps) passes. This is the last internal
 * degree — if it also fails, the event moves to Handbook Boundary review
 * rather than any further internal escalation (there is no Degree 6).
 *
 * @param {string} eventId
 * @param {object} history — matches degree5Engine.checkDegree5Entry shape,
 *   plus priorIneffectiveIds / interventionHistoryMatrix / failurePattern
 * @param {object} input
 *   proofGateSteps: object matching runEscalationProofGate() shape
 *   failureEvidence: object matching classifyFailure() shape
 *   disciplineEvidence: object matching checkDisciplineFirstCondition() shape
 *   candidateInterventions: array matching selectMinimumEffectiveIntervention() shape
 *   systemicAuditChecklist: object matching runSystemicFailureTest() shape
 *   overrideRequest: object matching evaluateOverrideValidity() shape (optional)
 */
function escalateToDegree5(eventId, history, input = {}) {
  const priorEvent = auditEngine.getEvent(eventId);
  if (!priorEvent) return { success: false, reason: "Event not found" };

  const entryCheck = degree5Engine.checkDegree5Entry(history);
  if (!entryCheck.eligible) {
    return { success: false, reason: "Degree 5 entry conditions not met.", checkedConditions: entryCheck };
  }

  // Audit Nori itself before touching the user (spec §20).
  const systemicTest = degree5Engine.runSystemicFailureTest(input.systemicAuditChecklist || {});
  if (systemicTest.systemDefectConfirmed) {
    priorEvent.degree = 5;
    priorEvent.systemSelfCorrection = systemicTest;
    priorEvent.appliedConsequence = null;
    priorEvent.recoveryStatus = "system_corrected_no_user_action_required";
    return { success: true, systemCorrected: true, systemicTest, event: priorEvent };
  }

  // Escalation Proof Gate — the real gate. If step 10 fails, stop here.
  const proofGate = degree5Engine.runEscalationProofGate(input.proofGateSteps || {});
  if (!proofGate.escalationJustified) {
    return {
      success: false,
      reason: "Escalation Proof Gate not satisfied — change strategy instead of escalating.",
      proofGate,
    };
  }

  // Classify the failure (ordinary resistance vs. capacity/context/academic/system/mixed).
  const classification = degree5Engine.classifyFailure(input.failureEvidence || {});

  // Academic-first routing + discipline-first justification check.
  const disciplineCheck = degree5Engine.checkDisciplineFirstCondition(input.disciplineEvidence || {});

  // Minimum Effective Intervention selection (never default to the harshest option).
  const matrix = history.interventionHistoryMatrix || degree5Engine.createInterventionHistoryMatrix();
  const interventionChoice = degree5Engine.selectMinimumEffectiveIntervention(
    input.candidateInterventions || [],
    matrix,
    history.failurePattern || classification.classification
  );

  const saturation = degree5Engine.checkConsequenceSaturation(matrix.rows.filter(
    (r) => r.failurePattern === (history.failurePattern || classification.classification)
  ));

  let overrideResult = null;
  if (input.overrideRequest) {
    overrideResult = degree5Engine.evaluateOverrideValidity(input.overrideRequest);
  }

  priorEvent.degree = 5;
  priorEvent.degree5EntryReasons = entryCheck.reasons;
  priorEvent.degree5ProofGate = proofGate;
  priorEvent.degree5Classification = classification;
  priorEvent.degree5DisciplineCheck = disciplineCheck;
  priorEvent.degree5InterventionChoice = interventionChoice;
  priorEvent.degree5Saturation = saturation;
  priorEvent.degree5Override = overrideResult;
  priorEvent.appliedConsequence = interventionChoice.chosen?.id || null;
  priorEvent.autonomyState = degree5Engine.stepD5Autonomy(priorEvent.autonomyState || "NORMAL", "restrict");
  priorEvent.recoveryStatus = "pending_degree5_recovery";

  return {
    success: true,
    entryCheck,
    systemicTest,
    proofGate,
    classification,
    disciplineCheck,
    interventionChoice,
    saturation,
    overrideResult,
    event: priorEvent,
  };
}

/**
 * Run the Handbook Boundary review for an event that has been through
 * Degree 5. Returns STATE_A (stay internal), STATE_B (review incomplete),
 * or STATE_C (boundary conditions satisfied).
 */
function reviewHandbookBoundary(eventId, status) {
  const priorEvent = auditEngine.getEvent(eventId);
  if (!priorEvent) return { success: false, reason: "Event not found" };
  const review = degree5Engine.reviewHandbookBoundary(status);
  priorEvent.handbookBoundaryState = review.state;
  return { success: true, review, event: priorEvent };
}

/**
 * Build the full Handbook Case File and, only if complete, transition to
 * Handbook Authority. Any proposed automated action is still re-checked
 * against safetyGuard — a downstream Handbook can never authorize an
 * unsafe consequence through this system.
 */
function finalizeHandbookTransition(eventId, caseFileData, proposedAutomatedActions = []) {
  const priorEvent = auditEngine.getEvent(eventId);
  if (!priorEvent) return { success: false, reason: "Event not found" };

  const caseFileResult = degree5Engine.buildHandbookCaseFile(caseFileData);
  if (!caseFileResult.complete) {
    return { success: false, reason: "Case file incomplete.", caseFileResult };
  }
  const transition = degree5Engine.transitionToHandbookAuthority(caseFileResult, proposedAutomatedActions);
  priorEvent.handbookCaseFile = caseFileResult.caseFile;
  priorEvent.handbookTransition = transition;
  return { success: true, caseFileResult, transition, event: priorEvent };
}

// ---------------------------------------------------------------------------
// AWARD / MERIT SYSTEM — Level 1 (Merit) through Level 5 (Elite Honor).
// Pure passthrough to awardEngine: the ledger is caller-owned (same pattern
// as meritShop's `account`), so brain.js never persists points itself.
// ---------------------------------------------------------------------------

/** List every level's title/purpose, or one level's full categories+awards. */
function getAwardCatalog(level = null) {
  return level ? awardEngine.getLevel(level) : awardEngine.listLevels();
}

/** Look up a single award definition by id, wherever it lives in the catalog. */
function getAward(awardId) {
  return awardEngine.getAward(awardId);
}

/** Check (without granting) whether evidence satisfies an award's requirements. */
function checkAward(awardId, evidence) {
  return awardEngine.checkAwardEligibility(awardId, evidence);
}

/** Create a fresh, empty merit ledger for a new user/profile. */
function createMeritLedger() {
  return awardEngine.createMeritLedger();
}

/**
 * Grant an award onto a ledger if — and only if — its requirements are met.
 * `evidenceKey` should identify the specific instance (an eventId, a
 * semester id, a streak id) so the same achievement can't be double-counted
 * (Level 1 RULE 2 / Level 2 PROTECTION 2) while a genuinely new instance of
 * the same award still can be granted later.
 */
function grantAward(ledger, awardId, evidence, evidenceKey = null) {
  return awardEngine.grantAward(ledger, awardId, evidence, evidenceKey);
}

/** Grant the Level 1 score-band merit (Academic Score Merit / Model Exam Merit). */
function grantScoreBandMerit(ledger, percentage, kind = "academic_score", evidenceKey = null) {
  return awardEngine.grantScoreBandMerit(ledger, percentage, kind, evidenceKey);
}

module.exports = {
  processAcademicEvent,
  requestOverride,
  completeRecovery,
  escalateToDegree3,
  advanceMasteryGate,
  escalateToDegree4,
  checkAntiGaming,
  consolidateEvents,
  startStabilityCycle,
  logStabilityDay,
  escalateToDegree5,
  reviewHandbookBoundary,
  finalizeHandbookTransition,
  getAwardCatalog,
  getAward,
  checkAward,
  createMeritLedger,
  grantAward,
  grantScoreBandMerit,
  meritShop,
  auditEngine,
  degree3Engine,
  degree4Engine,
  degree5Engine,
  awardEngine,
  DOMAINS,
};
