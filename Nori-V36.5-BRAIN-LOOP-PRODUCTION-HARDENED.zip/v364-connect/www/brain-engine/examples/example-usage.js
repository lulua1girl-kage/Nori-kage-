const brain = require("../brain");
const { assertSafe, UnsafeConsequenceError } = require("../engines/safetyGuard");

console.log("=== Example 1: Legitimate academic YouTube use, poor quiz score ===");
const r1 = brain.processAcademicEvent({
  subject: "chemistry",
  assessment: {
    type: "quiz", percentage: 62,
    missedConcepts: ["stoichiometry"], totalConceptsCovered: 5,
    carelessErrorCount: 0, applicationErrorCount: 0,
  },
  contextEvent: {
    domain: "digital_social", durationMinutes: 12,
    statedPurpose: "academic - watching a stoichiometry lesson",
    isEmergency: false, wasAccidental: false, continuedAfterAwareness: false,
    reportedDifficultDay: false, evidenceSources: ["system_log", "user_report"],
  },
  history: { degree1EventsUnresolved: 0, degree1EventsTotal: 0, sameDomainRepeatCount: 0 },
});
console.log(JSON.stringify(r1, null, 2));

console.log("\n=== Example 2: Sustained deliberate distraction, repeated domain, Degree 2 ===");
const r2 = brain.processAcademicEvent({
  subject: "physics",
  assessment: {
    type: "unit_test", percentage: 48,
    missedConcepts: ["kinematics", "forces", "energy", "momentum"], totalConceptsCovered: 5,
    carelessErrorCount: 1, applicationErrorCount: 1,
  },
  contextEvent: {
    domain: "entertainment", durationMinutes: 45,
    statedPurpose: null, isEmergency: false, wasAccidental: false,
    continuedAfterAwareness: true, reportedDifficultDay: false,
    evidenceSources: ["system_log", "user_report"],
  },
  history: { degree1EventsUnresolved: 1, degree1EventsTotal: 3, sameDomainRepeatCount: 3 },
});
console.log(JSON.stringify(r2, null, 2));

console.log("\n=== Example 3: Override request on Example 2's event ===");
const overrideResult = brain.requestOverride(
  r2.auditRecord.eventId,
  { reason: "technical_failure", evidence: ["screen-time tracker double-counted an idle window"], requestedScope: "consequence" },
  { recentOverrideCount: 0 }
);
console.log(JSON.stringify(overrideResult, null, 2));

console.log("\n=== Example 4: Merit Shop redemption ===");
const account = { balance: 25, activeLocks: [] };
console.log(brain.meritShop.redeem(account, "major", "entertainment"));

console.log("\n=== Example 5: Degree 3 escalation on the physics event from Example 2 ===");
const d3history = {
  degree2EventsUnresolved: 1,
  failedRecoveryCount: 2,
  sameDomainRepeatCountSinceDegree2: 2,
  distinctDomainsInvolved: ["entertainment", "gaming"],
  confirmedBypassCount: 0,
  degree2EventsTotal: 2,
  confirmedExecutionFailure: true,
  priorIneffectiveIds: ["delayed_entertainment_unlock"],
};
const d3result = brain.escalateToDegree3(r2.auditRecord.eventId, d3history, {
  understoodMaterial: true,
  contextType: "sustained_deliberate_distraction",
  causeBoardInputs: {
    whatHappened: "Physics unit test scored 48% after a 45-minute deliberate entertainment session during a protected study block.",
    whyItHappened: "Study block was abandoned in favor of a show already restricted once before.",
    whatWasUnderstood: "Kinematics and forces basics.",
    whatWasNotUnderstood: "Momentum problems requiring multi-step application.",
    whatWasPlanned: "90-minute protected physics block.",
    whatWasActuallyExecuted: "12 minutes of study, then entertainment for the remainder.",
    whatInterruptedExecution: "Deliberate switch to entertainment app after a prior Degree 2 consequence in the same domain.",
    withinControl: "Choosing to stop and resume the study block.",
    outsideControl: "None identified.",
    activeRule: "Protected study block / entertainment domain restriction.",
    deliberatelyViolated: true,
    pattern: "Second entertainment-domain breach following an unresolved Degree 2 event.",
  },
  mirrorInputs: {
    whatHappened: "Entertainment was chosen over the protected physics study block for the second time.",
    cost: "Momentum and multi-step application problems remain unpracticed.",
    interrupted: "The planned physics reconstruction for this unit.",
    weaknessExposed: "Execution follow-through when a prior consequence in the same domain hasn't fully resolved.",
    whatMustChange: "Complete the physics mastery gate and demonstrate one full protected block before the entertainment domain reopens.",
  },
});
console.log(JSON.stringify(d3result, null, 2));

console.log("\n=== Example 6: Advancing a Degree 3 mastery gate ===");
const advance1 = brain.advanceMasteryGate(r2.auditRecord.eventId, "momentum", true);
console.log(JSON.stringify(advance1, null, 2));

console.log("\n=== Example 7: Degree 4 escalation (Root-Cause Graph + Breakpoint + Stability Cycle) ===");
const d4history = {
  degree3EventsUnresolved: 1,
  repeatedRecoveryFailureCount: 2,
  failedStabilityCycleCount: 0,
  connectedDomainChainLength: 3,
  confirmedBypassCount: 0,
  executionCollapseConfirmed: true,
  systemIntegrityFailureConfirmed: false,
  academicDisciplineRecoveryAllDeclining: false,
  priorIneffectiveIds: ["delayed_entertainment_unlock", "streaming_restriction"],
};
const d4result = brain.escalateToDegree4(r2.auditRecord.eventId, d4history, {
  causes: [
    { id: "c1", description: "Repeated entertainment-domain avoidance", classification: "primary" },
    { id: "c2", description: "Unresolved momentum concept from Degree 3", classification: "contributing" },
    { id: "c3", description: "No fixed evening study slot", classification: "contributing" },
  ],
  timeline: [
    { time: "2026-09-10T18:00:00-07:00", description: "Study block scheduled", isDeviation: false },
    { time: "2026-09-10T18:10:00-07:00", description: "Phone picked up, entertainment app opened", isDeviation: true, withinControl: true },
    { time: "2026-09-10T18:45:00-07:00", description: "Study abandoned for the evening", isDeviation: true, withinControl: true },
  ],
  realityLayers: {
    observation: "Entertainment app open 45+ minutes during three of the last four protected blocks.",
    inference: "User is choosing entertainment over the protected block when both are available.",
    classification: "execution/discipline breach, entertainment domain",
    authority: "Degree 4 intervention eligible per entry conditions",
  },
  evidenceSources: ["system_log", "user_report", "prior_degree3_signature"],
  systemDefectConfirmed: false,
});
console.log(JSON.stringify(d4result, null, 2));

console.log("\n=== Example 8: Degree 5 escalation (terminal internal escalation) ===");
const d5history = {
  repeatedDegree4Failure: true,
  verifiedRecurrenceCount: 2,
  failedRecoveryCount: 2,
  persistentConfirmedDisciplineFailure: true,
  interventionHistoryMatrix: brain.degree5Engine.createInterventionHistoryMatrix(),
  failurePattern: "entertainment_domain_avoidance",
  priorIneffectiveIds: ["delayed_entertainment_unlock"],
};
const d5result = brain.escalateToDegree5(r2.auditRecord.eventId, d5history, {
  systemicAuditChecklist: { ruleClarity: true, classificationAccuracy: true, consequenceClarity: true,
    implementationReliability: true, verificationQuality: true, recoveryDesign: true,
    academicInterventionQuality: true, restorationTiming: true, overrideBehavior: true,
    monitoringQuality: true, technicalReliability: true, notificationReliability: true, dataIntegrity: true },
  proofGateSteps: {
    priorIntervention: "streaming_restriction",
    correctlyTargeted: true, correctlyImplemented: true, implementationVerified: true,
    adequateOpportunity: true, causeStillPresent: true, recurrenceConfirmed: true,
    attributionConfident: true, systemIntegrityOk: true, escalationLikelyBetter: true,
  },
  failureEvidence: {
    capable: true, understoodTask: true, resourcesAvailable: true,
    contextualDisruption: false, safetyIssue: false, academicSkillGap: false,
    evidenceStrength: "strong",
  },
  disciplineEvidence: {
    taskUnderstood: true, resourcesAvailable: true, adequateCapacity: true,
    noMeaningfulDisruption: true, reasonableOpportunity: true,
    deliberateOrStronglySupportedAvoidance: true, repeatedOrMaterial: true,
  },
  candidateInterventions: [
    { id: "entertainment_browsing_restriction", domain: "entertainment", severity: 2,
      causalRelevance: 0.8, evidenceConfidence: 0.7, academicCompatible: true, implementationReliability: 0.9 },
    { id: "gaming_suspension", domain: "gaming", severity: 4,
      causalRelevance: 0.5, evidenceConfidence: 0.6, academicCompatible: true, implementationReliability: 0.8 },
  ],
});
console.log(JSON.stringify(d5result, null, 2));

console.log("\n=== Example 9: Safety guard actively blocking a tampered consequence ===");
try {
  assertSafe({ id: "cold_shower", domain: "physical_conditioning", label: "Cold shower", severity: 3 });
} catch (e) {
  if (e instanceof UnsafeConsequenceError) {
    console.log("Blocked as expected:", e.message);
  } else {
    throw e;
  }
}
