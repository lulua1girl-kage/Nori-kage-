/**
 * DEGREE ENGINE
 * ---------------------------------------------------------------------------
 * Decides which Degree applies, using only predefined entry conditions
 * (Degree 1 §2-3, Degree 2 §3). This module never invents a trigger — it
 * only checks history + current classification against the fixed rules.
 * ---------------------------------------------------------------------------
 */

const FAILURE_TYPES = Object.freeze({
  ACADEMIC: "academic_problem",       // TYPE A
  DISCIPLINARY: "disciplinary_breach", // TYPE B
  COMBINED: "combined_failure",        // TYPE C
});

/**
 * @param {object} academicResult  — output of academicEngine.analyzeAssessment
 * @param {object} contextResult   — output of contextEngine.classifyContext
 */
function classifyFailureType(academicResult, contextResult) {
  const academicIssue = academicResult.band !== null; // any Degree 1 band = academic underperformance
  const disciplinaryIssue = contextResult.breachEligible === true;

  if (academicIssue && disciplinaryIssue) return FAILURE_TYPES.COMBINED;
  if (disciplinaryIssue) return FAILURE_TYPES.DISCIPLINARY;
  return FAILURE_TYPES.ACADEMIC;
}

/**
 * @param {object} history
 *   degree1EventsUnresolved: number
 *   degree1EventsTotal: number
 *   sameDomainRepeatCount: number
 *   degree2EventsTotal: number
 * @param {string} failureType
 * @param {object} contextResult
 */
function determineDegree(history, failureType, contextResult) {
  // Degree 2 entry conditions (Degree 2 §3, A-F)
  const degree2Reasons = [];
  if ((history.degree1EventsUnresolved || 0) >= 1) {
    degree2Reasons.push("persistent_unresolved_degree1_failure");
  }
  if ((history.sameDomainRepeatCount || 0) >= 3) {
    degree2Reasons.push("repeated_same_domain_breach");
  }
  if (contextResult.type === "sustained_deliberate_distraction" &&
      (history.sameDomainRepeatCount || 0) >= 1) {
    degree2Reasons.push("serious_single_event_with_prior_pattern");
  }
  if (failureType === FAILURE_TYPES.COMBINED &&
      (history.degree1EventsTotal || 0) >= 2) {
    degree2Reasons.push("combined_repeated_failure");
  }

  if (degree2Reasons.length > 0) {
    return { degree: 2, reasons: degree2Reasons };
  }

  return { degree: 1, reasons: ["default_entry_no_degree2_condition_met"] };
}

module.exports = { classifyFailureType, determineDegree, FAILURE_TYPES };
