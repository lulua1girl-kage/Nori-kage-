/**
 * CONSEQUENCE ENGINE
 * ---------------------------------------------------------------------------
 * Selects a consequence from the fixed library (data/consequenceLibrary.js).
 * This engine NEVER creates a new consequence, adjusts severity by "feel",
 * or stacks unrelated domains — per Degree 1 §14/16/17 and Degree 2 §22/23.
 * Every selection passes through safetyGuard.assertSafe() before return.
 * ---------------------------------------------------------------------------
 */

const { getConsequencesByDomain } = require("../data/consequenceLibrary");
const { assertSafe } = require("./safetyGuard");

// Degree/band -> severity ceiling. Keeps consequences proportionate instead
// of jumping straight to the harshest option in the domain.
const BAND_TO_SEVERITY_CEILING = Object.freeze({
  "D1-A": 1, "D1-B": 2, "D1-C": 2, "D1-D": 3, "D1-E": 3,
});
const DEGREE2_SEVERITY_CEILING = 4;

/**
 * @param {string} domain        — from consequenceLibrary DOMAINS
 * @param {number} degree        — 1 or 2
 * @param {string|null} band     — D1-A..D1-E, only meaningful for degree 1
 * @param {string[]} priorIneffectiveIds — consequences already tried & failed for this pattern
 */
function selectConsequence(domain, degree, band, priorIneffectiveIds = []) {
  const ceiling = degree === 1
    ? (BAND_TO_SEVERITY_CEILING[band] || 1)
    : DEGREE2_SEVERITY_CEILING;

  const candidates = getConsequencesByDomain(domain)
    .filter((c) => c.severity <= ceiling)
    .filter((c) => !priorIneffectiveIds.includes(c.id))
    .sort((a, b) => a.severity - b.severity); // minimum-effective-intervention first

  if (candidates.length === 0) {
    // Nothing untried at this ceiling — fall back to the least severe
    // option overall rather than escalating arbitrarily.
    const fallback = getConsequencesByDomain(domain).sort((a, b) => a.severity - b.severity)[0];
    return fallback ? assertSafe(fallback) : null;
  }

  return assertSafe(candidates[0]);
}

/**
 * No automatic stacking (Degree 1 §17, Degree 2 §23): only a primary domain
 * consequence, plus a secondary domain consequence IF that secondary domain
 * was independently confirmed as breach-eligible.
 */
function selectConsequenceSet({ primaryDomain, secondaryDomain, degree, band, priorIneffectiveIds }) {
  const primary = selectConsequence(primaryDomain, degree, band, priorIneffectiveIds);
  const secondary = secondaryDomain
    ? selectConsequence(secondaryDomain, degree, band, priorIneffectiveIds)
    : null;
  return { primary, secondary };
}

module.exports = { selectConsequence, selectConsequenceSet };
