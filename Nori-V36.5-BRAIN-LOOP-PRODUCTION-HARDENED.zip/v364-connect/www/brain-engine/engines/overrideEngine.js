/**
 * OVERRIDE ENGINE
 * ---------------------------------------------------------------------------
 * Human Override sits above the consequence engine but is bounded — it can
 * correct misclassification, it cannot become "I just don't want this."
 * Implements the validity/necessity/scope checks from Degree 1 §21 and
 * Degree 2 §27-28.
 * ---------------------------------------------------------------------------
 */

const OUTCOMES = Object.freeze({
  ACCEPT: "accept",
  PARTIAL_ACCEPT: "partial_accept",
  REJECT: "reject",
  DEFER: "defer",
  RECLASSIFY: "reclassify",
});

const VALID_REASONS = Object.freeze([
  "false_detection", "incorrect_data", "technical_failure", "emergency",
  "legitimate_academic_use", "extraordinary_circumstance", "assessment_error",
  "duplicate_event", "system_misclassification", "system_integrity_issue",
]);

/**
 * @param {object} request
 *   reason: string             — should match VALID_REASONS to be strong evidence
 *   evidence: string[]         — supporting evidence descriptions
 *   requestedScope: "event"|"consequence"|"classification"|"system"
 *   originalConfidence: "confirmed"|"probable"|"unclear"
 */
function evaluateOverride(request, history = {}) {
  const reasonRecognized = VALID_REASONS.includes(request.reason);
  const hasEvidence = (request.evidence || []).length > 0;
  const recentOverrideCount = history.recentOverrideCount || 0;

  // Repeated override requests trigger a classification-accuracy review
  // rather than automatic rejection or automatic acceptance (Degree 1 §22).
  const triggersClassificationReview = recentOverrideCount >= 3;

  if (!reasonRecognized && !hasEvidence) {
    return {
      outcome: OUTCOMES.REJECT,
      scope: null,
      reasoning: "No recognized reason and no evidence — 'I don't want this consequence' is not grounds for override.",
      triggersClassificationReview,
    };
  }

  if (reasonRecognized && hasEvidence && request.originalConfidence !== "confirmed") {
    return {
      outcome: OUTCOMES.ACCEPT,
      scope: request.requestedScope,
      reasoning: `Recognized reason (${request.reason}) with evidence, and original classification was not confirmed.`,
      triggersClassificationReview,
    };
  }

  if (reasonRecognized && hasEvidence && request.originalConfidence === "confirmed") {
    return {
      outcome: OUTCOMES.PARTIAL_ACCEPT,
      scope: "consequence", // narrow the scope even if reason is valid, per §13 "never larger than necessary"
      reasoning: "Valid reason present, but original event was confirmed — narrowing scope rather than erasing the event.",
      triggersClassificationReview,
    };
  }

  if (!hasEvidence) {
    return {
      outcome: OUTCOMES.DEFER,
      scope: null,
      reasoning: "Reason recognized but insufficient evidence — deferred pending more information.",
      triggersClassificationReview,
    };
  }

  return {
    outcome: OUTCOMES.REJECT,
    scope: null,
    reasoning: "Did not meet override validity criteria.",
    triggersClassificationReview,
  };
}

module.exports = { evaluateOverride, OUTCOMES, VALID_REASONS };
