/**
 * RULE-TUNING REVIEW ENGINE — V28
 * Detects repeated ineffective interventions and creates OWNER REVIEW flags.
 * It never changes rules, selects a replacement, or escalates automatically.
 */

function normalizeIds(ids) {
  return Array.isArray(ids) ? ids.map(String).filter(Boolean) : [];
}

function buildReviewFlags(events = [], options = {}) {
  const minRepeats = Number.isInteger(options.minRepeats) ? Math.max(2, options.minRepeats) : 2;
  const groups = new Map();

  for (const event of Array.isArray(events) ? events : []) {
    const ids = normalizeIds([
      event.appliedConsequence,
      event.academicCorrection
    ]);
    for (const id of ids) {
      const key = [
        event.subject || "*",
        event.primaryDomain || "*",
        id
      ].join("|");
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key).push(event);
    }
  }

  const flags = [];
  for (const [key, rows] of groups.entries()) {
    if (rows.length < minRepeats) continue;
    const [subject, domain, interventionId] = key.split("|");
    const failedRecovery = rows.filter(r => {
      const s = String(r.recoveryStatus || "").toLowerCase();
      return s === "failed" || s === "incomplete" || s === "unresolved";
    }).length;

    // A repeated intervention is evidence for review; it is NOT proof that
    // the intervention caused failure or that it should be replaced.
    flags.push({
      reviewId: `RULE-REVIEW-${subject}-${domain}-${interventionId}`.slice(0, 180),
      type: "repeated_intervention_review",
      status: "OWNER_REVIEW_REQUIRED",
      subject,
      domain,
      interventionId,
      timesApplied: rows.length,
      failedOrUnresolvedCount: failedRecovery,
      eventIds: rows.map(r => r.eventId).filter(Boolean),
      evidence: "The same predefined intervention was applied repeatedly within the supplied audit records.",
      interpretation: "Review whether the intervention is effective in this pattern; do not infer causation or silently escalate.",
      prohibitedAutomaticActions: [
        "rewrite_rule",
        "increase_severity",
        "replace_consequence",
        "alter_degree_threshold",
        "change_band"
      ]
    });
  }
  return {
    reviewVersion: "28.0",
    readOnly: true,
    ownerApprovalRequired: true,
    flags
  };
}

module.exports = { buildReviewFlags };
