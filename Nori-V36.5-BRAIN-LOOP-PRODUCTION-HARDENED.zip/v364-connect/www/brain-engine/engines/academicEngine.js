/**
 * ACADEMIC ENGINE
 * ---------------------------------------------------------------------------
 * Determines what an assessment result actually MEANS — separate from
 * whether any discipline breach occurred. Implements Degree 1 §3-5.
 * ---------------------------------------------------------------------------
 */

const ASSESSMENT_TYPES = Object.freeze([
  "practice", "assignment", "quiz", "weekly_assessment",
  "unit_test", "mock_examination", "final_examination",
]);

// Fixed D1-A..D1-E bands (Degree 1 §3)
const SCORE_BANDS = Object.freeze([
  { id: "D1-A", min: 76, max: 79, label: "Near target / minor underperformance" },
  { id: "D1-B", min: 71, max: 75, label: "Clear underperformance" },
  { id: "D1-C", min: 66, max: 70, label: "Significant underperformance" },
  { id: "D1-D", min: 51, max: 65, label: "Major underperformance" },
  { id: "D1-E", min: 0, max: 50, label: "Critical Degree 1 result" },
]);

function getScoreBand(percentage) {
  if (percentage >= 80) return null; // above Degree 1 territory entirely
  return SCORE_BANDS.find((b) => percentage >= b.min && percentage <= b.max) || null;
}

const ERROR_DISTRIBUTIONS = Object.freeze({
  LOCALIZED_WEAKNESS: "localized_weakness",
  BROAD_ACADEMIC_WEAKNESS: "broad_academic_weakness",
  EXECUTION_ERROR: "execution_error",
  CARELESS_ERROR_PATTERN: "careless_error_pattern",
  UNKNOWN: "unknown",
});

/**
 * @param {object} assessment
 *   type: one of ASSESSMENT_TYPES
 *   percentage: 0-100
 *   missedConcepts: string[]      — distinct concepts errors trace back to
 *   totalConceptsCovered: number
 *   carelessErrorCount: number
 *   applicationErrorCount: number — knew concept, misapplied it
 */
function analyzeAssessment(assessment) {
  if (!ASSESSMENT_TYPES.includes(assessment.type)) {
    throw new Error(`Unknown assessment type: ${assessment.type}`);
  }

  const band = getScoreBand(assessment.percentage);
  const conceptRatio = assessment.totalConceptsCovered
    ? (assessment.missedConcepts?.length || 0) / assessment.totalConceptsCovered
    : null;

  let errorDistribution = ERROR_DISTRIBUTIONS.UNKNOWN;
  if (conceptRatio !== null) {
    if ((assessment.carelessErrorCount || 0) > (assessment.missedConcepts?.length || 0)) {
      errorDistribution = ERROR_DISTRIBUTIONS.CARELESS_ERROR_PATTERN;
    } else if ((assessment.applicationErrorCount || 0) > (assessment.missedConcepts?.length || 0)) {
      errorDistribution = ERROR_DISTRIBUTIONS.EXECUTION_ERROR;
    } else if (conceptRatio <= 0.3) {
      errorDistribution = ERROR_DISTRIBUTIONS.LOCALIZED_WEAKNESS;
    } else {
      errorDistribution = ERROR_DISTRIBUTIONS.BROAD_ACADEMIC_WEAKNESS;
    }
  }

  // Weight: quiz/practice results matter less than unit/mock/final for
  // triggering escalation, per "50% quiz != 50% final" rule (Degree 1 §4).
  const weightByType = {
    practice: 0.2, assignment: 0.4, quiz: 0.5, weekly_assessment: 0.6,
    unit_test: 0.8, mock_examination: 0.9, final_examination: 1.0,
  };

  return {
    type: assessment.type,
    percentage: assessment.percentage,
    band: band ? band.id : null,
    bandLabel: band ? band.label : "Above Degree 1 threshold",
    errorDistribution,
    escalationWeight: weightByType[assessment.type] ?? 0.5,
    concepts: {
      missed: assessment.missedConcepts || [],
      totalCovered: assessment.totalConceptsCovered || null,
      ratio: conceptRatio,
    },
  };
}

module.exports = { analyzeAssessment, getScoreBand, ASSESSMENT_TYPES, SCORE_BANDS, ERROR_DISTRIBUTIONS };
