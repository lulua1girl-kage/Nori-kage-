/**
 * SAFETY GUARD
 * ---------------------------------------------------------------------------
 * Last line of defense. Every consequence that is about to be applied to a
 * user MUST pass through assertSafe() first. This is intentionally
 * independent of the consequence library's own good behavior — if a bug,
 * a future edit, or a bad merge ever introduces something physical/harmful
 * into the library or into a hand-built override, this still blocks it.
 * ---------------------------------------------------------------------------
 */

const { FOREVER_BANNED } = require("../data/consequenceLibrary");

// Each term is wrapped in \b...\b so short/ambiguous words (e.g. "ice")
// only match as a whole word — otherwise "ice" would false-positive on
// ordinary words like "services" or "notice". Terms end in "s?" (or already
// use \w*) to still catch plurals/variants ("push-ups", "insults").
// Before matching, underscores/hyphens in the haystack are normalized to
// spaces so snake_case/kebab-case ids ("food_restriction_meal_skip") break
// into real word boundaries instead of being treated as one long word.
// FOREVER_BANNED entries are snake_case ("food_restriction"); convert their
// underscores to a flexible separator so they match the space-normalized
// haystack below regardless of how the id/label punctuates the phrase.
const BANNED_TERMS = FOREVER_BANNED.map((t) => t.replace(/_/g, "[ _-]?")).concat([
  "exercise", "push.?ups?", "sit.?ups?", "planks?", "cold", "showers?", "ice",
  "starv\\w*", "hunger", "sleep.?depriv\\w*", "pains?", "hurts?",
  "humiliat\\w*", "degrad\\w*", "shames?", "insults?", "threats?",
  "intimidat\\w*", "physical",
]);
const BANNED_PATTERN = new RegExp(
  BANNED_TERMS.map((t) => `\\b${t}\\b`).join("|"),
  "i"
);

function normalize(text) {
  return text.replace(/[_-]/g, " ");
}

class UnsafeConsequenceError extends Error {
  constructor(reason, payload) {
    super(`Blocked unsafe consequence: ${reason}`);
    this.name = "UnsafeConsequenceError";
    this.payload = payload;
  }
}

/**
 * Throws if the consequence is unsafe. Returns the consequence unchanged
 * if it passes. Call this immediately before persisting/applying anything.
 */
function assertSafe(consequence) {
  if (!consequence || typeof consequence !== "object") {
    throw new UnsafeConsequenceError("no consequence object provided", consequence);
  }
  if (consequence.physical === true) {
    throw new UnsafeConsequenceError("explicit physical flag set", consequence);
  }
  if (!consequence.domain) {
    throw new UnsafeConsequenceError("consequence has no recognized domain", consequence);
  }
  const haystack = normalize(`${consequence.id || ""} ${consequence.label || ""} ${consequence.description || ""}`);
  if (BANNED_PATTERN.test(haystack)) {
    throw new UnsafeConsequenceError(`matched banned pattern in "${haystack}"`, consequence);
  }
  return consequence;
}

module.exports = { assertSafe, UnsafeConsequenceError };
