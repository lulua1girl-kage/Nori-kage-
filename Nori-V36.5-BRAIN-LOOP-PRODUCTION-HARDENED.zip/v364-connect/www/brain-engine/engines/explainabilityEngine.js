/**
 * EXPLAINABILITY ENGINE — V28
 * Read-only rendering of the deterministic decision chain.
 * It never recomputes, changes, or recommends a different decision.
 */

const LABELS = Object.freeze({
  event: "Observed event",
  rule: "Rule matched",
  degree: "Degree determined",
  consequence: "Consequence selected",
  correction: "Academic correction",
  override: "Override status",
});

function clean(v, max=500) {
  return String(v == null ? "" : v).trim().slice(0, max);
}

function explainDecision(record = {}) {
  const steps = [];
  steps.push({
    stage: "event",
    label: LABELS.event,
    fact: record.subject
      ? `${clean(record.subject)} result/event was recorded${record.score != null ? ` at ${clean(record.score)}%` : ""}.`
      : "A KAGE event was recorded.",
    source: "AUDIT_RECORD",
    verified: true
  });

  if (record.band != null) {
    steps.push({
      stage: "rule",
      label: LABELS.rule,
      fact: `The deterministic academic engine assigned ${clean(record.band)}.`,
      detail: record.degreeReasons || null,
      source: "KAGE_DETERMINISTIC_ENGINE",
      verified: true
    });
  }

  if (record.failureType) {
    steps.push({
      stage: "classification",
      label: "Failure classification",
      fact: `The event was classified as ${clean(record.failureType)}.`,
      source: "KAGE_DETERMINISTIC_ENGINE",
      verified: true
    });
  }

  if (record.degree != null) {
    steps.push({
      stage: "degree",
      label: LABELS.degree,
      fact: `Degree ${clean(record.degree)} was selected.`,
      detail: Array.isArray(record.degreeReasons) ? record.degreeReasons.map(clean) : [],
      source: "DEGREE_ENGINE",
      verified: true
    });
  }

  if (record.appliedConsequence || record.secondaryConsequence) {
    steps.push({
      stage: "consequence",
      label: LABELS.consequence,
      fact: `Recorded consequence${record.appliedConsequence ? `: ${clean(record.appliedConsequence)}` : ""}${record.secondaryConsequence ? `; secondary: ${clean(record.secondaryConsequence)}` : ""}.`,
      source: "CONSEQUENCE_ENGINE",
      verified: true
    });
  } else {
    steps.push({
      stage: "consequence",
      label: LABELS.consequence,
      fact: "No disciplinary consequence was recorded for this event.",
      source: "AUDIT_RECORD",
      verified: true
    });
  }

  if (record.academicCorrection) {
    steps.push({
      stage: "correction",
      label: LABELS.correction,
      fact: `Academic correction recorded: ${clean(record.academicCorrection)}.`,
      source: "CONSEQUENCE_ENGINE",
      verified: true
    });
  }

  if (record.overrideStatus) {
    steps.push({
      stage: "override",
      label: LABELS.override,
      fact: `Override status: ${clean(record.overrideStatus)}.`,
      source: "AUDIT_RECORD",
      verified: true
    });
  }

  return {
    explanationVersion: "28.0",
    eventId: record.eventId || null,
    readOnly: true,
    statement: buildPlainSummary(record),
    steps
  };
}

function buildPlainSummary(record = {}) {
  const subject = clean(record.subject || "The event");
  const score = record.score != null ? ` at ${clean(record.score)}%` : "";
  const band = record.band ? `, assigned ${clean(record.band)}` : "";
  const degree = record.degree != null ? ` and Degree ${clean(record.degree)}` : "";
  return `${subject}${score}${band}${degree}. This explanation reports the recorded deterministic chain; it does not recalculate or modify the decision.`;
}

function explainWhy(record = {}) {
  return explainDecision(record);
}

module.exports = { explainDecision, explainWhy, buildPlainSummary };
