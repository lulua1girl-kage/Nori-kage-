/**
 * AWARD ENGINE
 * ---------------------------------------------------------------------------
 * Turns the data/awardLibrary.js catalog into actual decisions. Same
 * philosophy as the rest of brain-engine: this module never invents an
 * award or a point value — it only checks caller-supplied `evidence`
 * against a catalog entry's `requirements[]`, the same "evidence, not
 * vibes" pattern used throughout Degree 1-5.
 *
 * State: a "merit ledger" is a plain object the caller owns and persists
 * (mirrors how meritShop.js treats `account` — this engine never keeps its
 * own hidden state), shape:
 *   { balance: number, history: [{ awardId, level, meritPoints, grantedAt, evidenceKey }] }
 * ---------------------------------------------------------------------------
 */

const { LEVELS } = require("../data/awardLibrary");

// ---------------------------------------------------------------------------
// 1. CATALOG LOOKUP
// ---------------------------------------------------------------------------
function listLevels() {
  return LEVELS.map((l) => ({ level: l.level, title: l.title, purpose: l.purpose }));
}

function getLevel(levelNumber) {
  return LEVELS.find((l) => l.level === levelNumber) || null;
}

function listCategories(levelNumber) {
  const level = getLevel(levelNumber);
  if (!level) return [];
  return level.categories.map((c) => ({ id: c.id, title: c.title, awardIds: (c.awards || []).map((a) => a.id) }));
}

/** Finds an award definition by id across every level/category. */
function getAward(awardId) {
  for (const level of LEVELS) {
    for (const category of level.categories) {
      const found = (category.awards || []).find((a) => a.id === awardId);
      if (found) return { ...found, level: level.level, categoryId: category.id, categoryTitle: category.title };
    }
  }
  return null;
}

// ---------------------------------------------------------------------------
// 2. REQUIREMENTS DSL EVALUATOR
// ---------------------------------------------------------------------------
const OPS = {
  gte: (a, b) => typeof a === "number" && a >= b,
  gt: (a, b) => typeof a === "number" && a > b,
  lte: (a, b) => typeof a === "number" && a <= b,
  lt: (a, b) => typeof a === "number" && a < b,
  eq: (a, b) => a === b,
  true: (a) => a === true,
};

/**
 * @param {string} awardId
 * @param {object} evidence — flat object; keys match each requirement's `key`
 * @returns { eligible, missing: string[], award }
 */
function checkAwardEligibility(awardId, evidence = {}) {
  const award = getAward(awardId);
  if (!award) return { eligible: false, missing: ["unknown_award_id"], award: null };
  if (award.meritPoints === null) {
    return {
      eligible: false,
      missing: ["threshold_not_yet_defined"],
      award,
      note: award.notes || "This award's requirement is intentionally undefined pending real-world confirmation — do not auto-grant it.",
    };
  }

  const missing = (award.requirements || [])
    .filter((req) => {
      const op = OPS[req.op];
      if (!op) return true; // unknown op => treat as unmet, fail closed
      return !op(evidence[req.key], req.value);
    })
    .map((req) => (req.op === "true" ? req.key : `${req.key} ${req.op} ${req.value}`));

  return { eligible: missing.length === 0, missing, award };
}

// ---------------------------------------------------------------------------
// 3. SCORE-BAND AWARDS (Level 1, Category 2 & Category 5) — not requirements[]
// ---------------------------------------------------------------------------
function evaluateScoreBandMerit(percentage) {
  const bands = getLevel(1).categories.find((c) => c.id === "l1_academic_score").bands;
  const band = bands.find((b) => percentage >= b.min && percentage <= b.max);
  if (!band) return { eligible: false, meritPoints: 0, note: "Below the 80% Level 1 floor — no Academic Score Merit." };
  return { eligible: true, meritPoints: band.meritPoints, badge: band.badge || null, band: `${band.min}-${band.max}` };
}

function evaluateModelExamMerit(percentage) {
  const bands = getLevel(1).categories.find((c) => c.id === "l1_entrance_prep").bands;
  const band = bands.find((b) => percentage >= b.min && percentage <= b.max);
  if (!band) return { eligible: false, meritPoints: 0, note: "Below the 80% Level 1 floor — no Model Exam Merit." };
  return { eligible: true, meritPoints: band.meritPoints, badge: band.badge || null, band: `${band.min}-${band.max}` };
}

// ---------------------------------------------------------------------------
// 4. MERIT LEDGER
// ---------------------------------------------------------------------------
function createMeritLedger() {
  return { balance: 0, history: [] };
}

/**
 * Grants an award onto a ledger, enforcing:
 *   - RULE 2 / PROTECTION 2 (no double counting): the same awardId cannot be
 *     granted twice for the same `evidenceKey` (a caller-supplied identifier
 *     for the underlying period/assessment/streak instance — e.g. an
 *     eventId, or "2026-S1" for a semester award). Different evidenceKeys
 *     for the same award (a new streak, a new period) are allowed.
 *   - RULE 3 (awards never cancel penalties): grantAward only ever adds to
 *     the ledger; it has no access to auditEngine and cannot clear an
 *     appliedConsequence, by construction.
 *
 * @param {object} ledger        — from createMeritLedger()
 * @param {string} awardId
 * @param {object} evidence
 * @param {string} evidenceKey   — identifies this specific instance of the
 *                                 achievement, for duplicate protection
 */
function grantAward(ledger, awardId, evidence, evidenceKey = null) {
  const check = checkAwardEligibility(awardId, evidence);
  if (!check.eligible) {
    return { granted: false, reason: "Requirements not met.", missing: check.missing, award: check.award };
  }

  if (evidenceKey) {
    const duplicate = ledger.history.find((h) => h.awardId === awardId && h.evidenceKey === evidenceKey);
    if (duplicate) {
      return { granted: false, reason: "Already granted for this evidenceKey — no double counting.", duplicateOf: duplicate };
    }
  }

  const entry = {
    awardId,
    level: check.award.level,
    title: check.award.title,
    badge: check.award.badge || null,
    meritPoints: check.award.meritPoints,
    evidenceKey,
    grantedAt: new Date().toISOString(),
  };
  ledger.history.push(entry);
  ledger.balance += entry.meritPoints;

  return { granted: true, entry, newBalance: ledger.balance };
}

/** Same idea as grantAward, but for the two score-band awards (Level 1 Cat 2 / Cat 5). */
function grantScoreBandMerit(ledger, percentage, kind = "academic_score", evidenceKey = null) {
  const evalFn = kind === "model_exam" ? evaluateModelExamMerit : evaluateScoreBandMerit;
  const result = evalFn(percentage);
  if (!result.eligible) return { granted: false, reason: result.note };

  if (evidenceKey) {
    const duplicate = ledger.history.find((h) => h.awardId === `score_band:${kind}` && h.evidenceKey === evidenceKey);
    if (duplicate) return { granted: false, reason: "Already granted for this evidenceKey — no double counting.", duplicateOf: duplicate };
  }

  const entry = {
    awardId: `score_band:${kind}`,
    level: 1,
    title: kind === "model_exam" ? "Model Exam Merit" : "Academic Score Merit",
    badge: result.badge,
    meritPoints: result.meritPoints,
    evidenceKey,
    grantedAt: new Date().toISOString(),
  };
  ledger.history.push(entry);
  ledger.balance += entry.meritPoints;

  return { granted: true, entry, newBalance: ledger.balance };
}

module.exports = {
  listLevels,
  getLevel,
  listCategories,
  getAward,
  checkAwardEligibility,
  evaluateScoreBandMerit,
  evaluateModelExamMerit,
  createMeritLedger,
  grantAward,
  grantScoreBandMerit,
};
