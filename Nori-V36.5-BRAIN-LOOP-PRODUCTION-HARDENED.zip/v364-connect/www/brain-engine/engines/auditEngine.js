/**
 * AUDIT ENGINE
 * ---------------------------------------------------------------------------
 * Every decision the Brain makes gets a permanent, structured record.
 * Recovery changes the ACTIVE state; it never rewrites this history
 * (Degree 1 §24, Degree 2 §33-34).
 *
 * In this reference build, records are kept in-memory. Swap `store` for a
 * real DB adapter (must implement append(record) and all()) in production.
 * ---------------------------------------------------------------------------
 */

let _sequence = 0;
const _store = [];

function nextEventId() {
  _sequence += 1;
  return `EVT-${Date.now()}-${_sequence}`;
}

/**
 * @param {object} record
 *   subject, assessmentType, score, band, errorDistribution,
 *   observed, reported, inferred, confidence,
 *   failureType, degree, degreeReasons,
 *   primaryDomain, secondaryDomain,
 *   appliedConsequence, academicCorrection,
 *   overrideStatus, recoveryStatus
 */
function recordEvent(record) {
  const entry = {
    eventId: nextEventId(),
    timestamp: new Date().toISOString(),
    ...record,
  };
  _store.push(entry);
  return entry;
}

function getEvent(eventId) {
  return _store.find((e) => e.eventId === eventId) || null;
}

function getHistoryForSubject(subject, { domain = null } = {}) {
  return _store.filter((e) => e.subject === subject && (!domain || e.primaryDomain === domain));
}

function updateRecoveryStatus(eventId, recoveryStatus) {
  const entry = getEvent(eventId);
  if (!entry) return null;
  entry.recoveryStatus = recoveryStatus;
  entry.recoveryUpdatedAt = new Date().toISOString();
  return entry; // history entry itself is never deleted, only appended-to
}

function all() {
  return [..._store];
}

module.exports = { recordEvent, getEvent, getHistoryForSubject, updateRecoveryStatus, all };
