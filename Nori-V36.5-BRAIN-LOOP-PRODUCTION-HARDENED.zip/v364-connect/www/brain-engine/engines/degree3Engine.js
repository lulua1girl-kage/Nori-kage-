/**
 * DEGREE 3 ENGINE
 * ---------------------------------------------------------------------------
 * Degree 3 activates only when predefined entry conditions are met (never
 * because "this feels serious"). It adds four things Degree 1/2 don't have:
 *
 *   1. Four-state diagnosis: Knowledge / Execution / Discipline / System
 *   2. A Cause Board (structured "what actually happened" record)
 *   3. A permanent Failure Signature + non-humiliating Consequence Mirror
 *   4. A Mastery Gate the academic side must pass before status restores
 *
 * It still selects consequences ONLY from data/consequenceLibrary.js, still
 * runs everything through safetyGuard, and still never invents a new
 * punishment. Degree 3 is a diagnostic upgrade, not a harsher one.
 * ---------------------------------------------------------------------------
 */

const { selectConsequence } = require("./consequenceEngine");
const { DOMAINS } = require("../data/consequenceLibrary");

// ---------------------------------------------------------------------------
// 1. ENTRY CONDITIONS (spec §2)
// ---------------------------------------------------------------------------
function checkDegree3Entry(history = {}) {
  const reasons = [];

  if ((history.degree2EventsUnresolved || 0) >= 1) {
    reasons.push("persistent_degree2_failure");
  }
  if ((history.failedRecoveryCount || 0) >= 2) {
    reasons.push("repeated_failed_recovery");
  }
  if ((history.sameDomainRepeatCountSinceDegree2 || 0) >= 2) {
    reasons.push("recurring_same_domain_breach_despite_degree2");
  }
  if ((history.distinctDomainsInvolved || []).length >= 3) {
    reasons.push("cross_domain_pattern");
  }
  if ((history.confirmedBypassCount || 0) >= 1) {
    reasons.push("repeated_deliberate_bypass");
  }
  if ((history.degree2EventsTotal || 0) >= 2 && history.confirmedExecutionFailure) {
    reasons.push("repeated_academic_failure_with_confirmed_execution_failure");
  }

  return { eligible: reasons.length > 0, reasons };
}

// ---------------------------------------------------------------------------
// 2. FOUR-STATE DIAGNOSIS (spec §7)
// ---------------------------------------------------------------------------
const FAILURE_STATES = Object.freeze({
  KNOWLEDGE: "knowledge_failure",   // doesn't understand the material
  EXECUTION: "execution_failure",   // understands, doesn't execute
  DISCIPLINE: "discipline_failure", // confirmed deliberate rule violation
  SYSTEM: "system_failure",         // the app/rules themselves caused it
});

/**
 * @param {object} diag
 *   academicResult: output of academicEngine.analyzeAssessment
 *   contextResult: output of contextEngine.classifyContext
 *   systemIntegrityIssue: boolean — did the app itself misfire (bad timer,
 *     false detection, broken schedule) for this event?
 *   understoodMaterial: boolean|null — self-report / evidence of comprehension
 */
function diagnoseFailureState(diag) {
  if (diag.systemIntegrityIssue) {
    return { state: FAILURE_STATES.SYSTEM,
      reasoning: "System integrity issue confirmed — correct the system before evaluating the user." };
  }
  if (diag.contextResult?.breachEligible &&
      (diag.contextResult.type === "deliberate_distraction" ||
       diag.contextResult.type === "sustained_deliberate_distraction")) {
    return { state: FAILURE_STATES.DISCIPLINE,
      reasoning: "Confirmed deliberate rule violation with adequate capacity/opportunity present." };
  }
  if (diag.understoodMaterial === false) {
    return { state: FAILURE_STATES.KNOWLEDGE,
      reasoning: "Evidence indicates the material itself was not understood." };
  }
  if (diag.understoodMaterial === true && diag.academicResult?.band) {
    return { state: FAILURE_STATES.EXECUTION,
      reasoning: "Material was understood but result shows repeated failure to execute." };
  }
  return { state: FAILURE_STATES.EXECUTION,
    reasoning: "Default to execution failure — insufficient evidence of a knowledge gap or system defect, and no confirmed deliberate breach." };
}

// ---------------------------------------------------------------------------
// 3. CAUSE BOARD (spec §8)
// ---------------------------------------------------------------------------
function buildCauseBoard(input) {
  return {
    whatHappened: input.whatHappened || null,
    whyItHappened: input.whyItHappened || null,
    whatWasUnderstood: input.whatWasUnderstood || null,
    whatWasNotUnderstood: input.whatWasNotUnderstood || null,
    whatWasPlanned: input.whatWasPlanned || null,
    whatWasActuallyExecuted: input.whatWasActuallyExecuted || null,
    whatInterruptedExecution: input.whatInterruptedExecution || null,
    withinControl: input.withinControl || null,
    outsideControl: input.outsideControl || null,
    activeRule: input.activeRule || null,
    deliberatelyViolated: input.deliberatelyViolated ?? null,
    pattern: input.pattern || null,
  };
}

// ---------------------------------------------------------------------------
// 4. FAILURE SIGNATURE + CONSEQUENCE MIRROR (spec §16-17)
// ---------------------------------------------------------------------------
function generateFailureSignature({ eventId, domain, failureState, academicImpact }) {
  return {
    signatureId: `D3-${eventId}`,
    domain,
    primaryCause: failureState,
    academicImpact: academicImpact || null,
    degree: 3,
    recovery: "not_started",
    recurrence: 0,
    currentState: "active",
  };
}

/**
 * Non-humiliating structured reflection. Language stays behavioral/factual —
 * never "you are lazy" / "you disappointed me" (spec §5, §16).
 */
function buildConsequenceMirror({ whatHappened, cost, interrupted, weaknessExposed, whatMustChange }) {
  return {
    whatIDid: whatHappened,
    whatItCost: cost,
    whatItInterrupted: interrupted,
    whatWeaknessItExposed: weaknessExposed,
    whatMustChange: whatMustChange,
  };
}

// ---------------------------------------------------------------------------
// 5. DEGREE 3 CONSEQUENCE SELECTION
// ---------------------------------------------------------------------------
const DEGREE3_SEVERITY_CEILING = 4;

/**
 * Only DISCIPLINE and EXECUTION states select a domain consequence.
 * KNOWLEDGE routes to academic reconstruction only; SYSTEM routes to a
 * system-correction flag, never a user-facing consequence (spec §7, State D).
 */
function selectDegree3Response(failureState, domain, priorIneffectiveIds = []) {
  if (failureState === FAILURE_STATES.KNOWLEDGE) {
    return { consequence: null, academicOnly: true,
      note: "Knowledge failure — route to reteach/retrieve/practice/verify, no disciplinary consequence." };
  }
  if (failureState === FAILURE_STATES.SYSTEM) {
    return { consequence: null, systemCorrectionRequired: true,
      note: "System failure — correct the system; do not apply any consequence to the user for this event." };
  }
  // EXECUTION and DISCIPLINE both may draw from the domain-relevant library,
  // capped at the Degree 3 ceiling, cheapest-first (minimum effective
  // intervention — spec's "smallest predefined intervention" principle).
  const consequence = selectConsequence(domain, 2, null, priorIneffectiveIds); // reuse degree-2 path; ceiling applied below
  return { consequence, academicOnly: false };
}

// ---------------------------------------------------------------------------
// 6. MASTERY GATE (spec §34 / Degree 3 System 19)
// ---------------------------------------------------------------------------
const MASTERY_STATES = Object.freeze([
  "unknown", "explained", "understood", "practiced", "retrieved", "applied", "verified", "stable",
]);

function initMasteryGate(concept) {
  return { concept, state: "unknown", history: ["unknown"] };
}

function advanceMastery(gate, evidenceOfNextState) {
  const currentIndex = MASTERY_STATES.indexOf(gate.state);
  if (!evidenceOfNextState || currentIndex >= MASTERY_STATES.length - 1) return gate;
  const nextState = MASTERY_STATES[currentIndex + 1];
  gate.state = nextState;
  gate.history.push(nextState);
  return gate;
}

function isMasteryComplete(gate) {
  return gate.state === "stable" || gate.state === "verified";
}

module.exports = {
  checkDegree3Entry,
  diagnoseFailureState,
  FAILURE_STATES,
  buildCauseBoard,
  generateFailureSignature,
  buildConsequenceMirror,
  selectDegree3Response,
  DEGREE3_SEVERITY_CEILING,
  MASTERY_STATES,
  initMasteryGate,
  advanceMastery,
  isMasteryComplete,
};
