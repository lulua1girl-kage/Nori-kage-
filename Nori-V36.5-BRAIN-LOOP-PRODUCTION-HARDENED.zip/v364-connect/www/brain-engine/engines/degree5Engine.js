/**
 * DEGREE 5 ENGINE — Terminal Internal Escalation, Behavioral Accountability
 * & Handbook Boundary
 * ---------------------------------------------------------------------------
 * D5 does not ask "was this event bad?" (Degree 3) or "is the loop still
 * working?" (Degree 4). D5 asks one final question:
 *
 *   "After accurate classification, appropriate intervention, verified
 *    recovery attempts, system-integrity checks, and repeated evidence,
 *    does Nori still have a legitimate internal intervention capable of
 *    correcting the confirmed failure?"
 *
 * D5 adds, on top of Degree 1-4:
 *
 *   1. Human Override / ordinary-resistance classification (§3-8)
 *   2. Escalation Proof Gate — 10-step gate before any escalation (§10)
 *   3. Intervention Effectiveness Engine + History Matrix (§11-12)
 *   4. Academic-First / Discipline-First routing (§13-15)
 *   5. Consequence Saturation handling (§19)
 *   6. Systemic Failure Test — audit Nori before blaming the user (§20)
 *   7. Human Override Validity Engine — 10 tests (§25-26)
 *   8. Recovery Quality + Restoration pipeline (§27-29)
 *   9. Controlled Autonomy (D5 states) + System Modification Lock (§34-35)
 *  10. Handbook Boundary review, Case File, Authority Transition (§38-41)
 *  11. Final D5 Audit — 20-question checklist (§42)
 *
 * Hard rule carried over unchanged from Degree 1-4: D5 NEVER introduces a
 * new consequence category. It only ever selects from
 * data/consequenceLibrary.js, and every selection still passes through
 * engines/safetyGuard.js before it can be applied. D5 also explicitly
 * cannot authorize physical, painful, or degrading consequences even if a
 * downstream "Handbook" claims to contain them (§18, §40).
 * ---------------------------------------------------------------------------
 */

const { selectConsequence } = require("./consequenceEngine");
const { CONFIDENCE } = require("./contextEngine");
const { assertSafe } = require("./safetyGuard");

// ---------------------------------------------------------------------------
// CORE LAWS (spec §44) — exported for reference / UI display, not executable
// logic on their own, but every function below is written to satisfy them.
// ---------------------------------------------------------------------------
const CORE_LAWS = Object.freeze([
  "Reality Before Consequence",
  "Evidence Before Certainty",
  "Cause Before Escalation",
  "Laziness Must Remain Possible",
  "Context Must Remain Possible",
  "Academic Failure Is Not Automatically Discipline Failure",
  "Consequence Must Match Cause",
  "Minimum Effective Intervention",
  "Failed Intervention Requires Investigation",
  "System Defects Must Be Corrected",
  "Academic Objective Has Priority",
  "No Infinite Escalation",
  "History Remains",
  "Active Consequences End After Verified Recovery",
  "Restoration Requires Demonstrated Stability",
  "Override Protects Integrity",
  "Anti-Gaming Requires Evidence",
  "No Double Punishment",
  "Strictness Is Consistency, Not Cruelty",
  "Person != Failure Signature",
  "Punishment Never Replaces Education",
  "Discipline Never Replaces Execution",
  "Nori Can Be Wrong",
  "The System Must Eventually Become Less Necessary",
]);

// ---------------------------------------------------------------------------
// 1. D5 ENTRY CONDITIONS (spec §9)
// ---------------------------------------------------------------------------
function checkDegree5Entry(history = {}) {
  const reasons = [];
  if (history.repeatedDegree4Failure) reasons.push("repeated_degree4_failure");
  if ((history.verifiedRecurrenceCount || 0) >= 2) reasons.push("repeated_verified_recurrence");
  if ((history.failedRecoveryCount || 0) >= 2) reasons.push("repeated_failed_recovery");
  if ((history.failedStabilityCycleCount || 0) >= 2) reasons.push("repeated_14day_cycle_failure");
  if (history.persistentConfirmedDisciplineFailure) reasons.push("persistent_confirmed_disciplinary_failure");
  if (history.repeatedOrdinaryResistanceWithCapacity) reasons.push("repeated_ordinary_resistance_despite_capacity");
  if ((history.deliberateCircumventionCount || 0) >= 2) reasons.push("repeated_deliberate_circumvention");
  if ((history.interventionResistanceCount || 0) >= 2) reasons.push("repeated_intervention_resistance");
  if ((history.connectedDomainChainLength || 0) >= 3) reasons.push("cross_domain_systemic_recurrence");
  if (history.executionCollapseConfirmed) reasons.push("persistent_execution_collapse");
  if (history.internalInterventionExhaustionDemonstrated) reasons.push("demonstrated_internal_intervention_exhaustion");
  if (history.criticalSystemIntegrityConcern) reasons.push("critical_system_integrity_concern");

  // §9 explicit non-triggers — never let a single bad day count as a reason.
  const disqualifiers = [];
  if (history.singleBadExam) disqualifiers.push("single_bad_exam_is_not_sufficient");
  if (history.singleFailedStudySession) disqualifiers.push("single_failed_session_is_not_sufficient");
  if (history.singleUnmotivatedInstance) disqualifiers.push("single_unmotivated_instance_is_not_sufficient");
  if (history.singleIneffectiveConsequence) disqualifiers.push("single_ineffective_consequence_is_not_sufficient");
  if (history.userRequestedOverrideOnly) disqualifiers.push("override_request_alone_is_not_sufficient");
  if (history.singleDifficultDay) disqualifiers.push("single_difficult_day_is_not_sufficient");

  return {
    eligible: reasons.length > 0 && disqualifiers.length === 0,
    reasons,
    disqualifiers,
    note: disqualifiers.length > 0
      ? "Disqualifying condition present — D5 must not activate on this evidence alone."
      : "Evidence-based entry reasons found.",
  };
}

// ---------------------------------------------------------------------------
// 2. ORDINARY RESISTANCE / HUMAN OVERRIDE CLASSIFICATION (spec §3-8)
// ---------------------------------------------------------------------------
const FAILURE_CLASSIFICATIONS = Object.freeze([
  "ordinary_resistance",   // A — "I don't want to."
  "capacity_problem",      // B
  "contextual_disruption", // C
  "safety_condition",      // D
  "academic_problem",      // E
  "system_problem",        // F
  "mixed",
  "unresolved",
]);

/**
 * Runs the 9-question Human Override Decision (spec §6) and returns the
 * best-supported classification. This function must never manufacture a
 * deeper explanation when the simple one is adequately evidenced (§3),
 * and must never collapse every failure into laziness either (§5).
 *
 * @param {object} evidence
 *   capable: boolean|null            — physically/cognitively capable?
 *   understoodTask: boolean|null
 *   resourcesAvailable: boolean|null
 *   contextualDisruption: boolean|null
 *   safetyIssue: boolean|null
 *   academicSkillGap: boolean|null
 *   systemContributed: boolean|null
 *   evidenceStrength: "weak"|"moderate"|"strong"
 */
function classifyFailure(evidence = {}) {
  const {
    capable = null, understoodTask = null, resourcesAvailable = null,
    contextualDisruption = null, safetyIssue = null, academicSkillGap = null,
    systemContributed = null, evidenceStrength = "weak",
  } = evidence;

  if (safetyIssue) {
    return { classification: "safety_condition", reasoning: "A legitimate safety issue is present and takes priority (§7)." };
  }
  if (systemContributed) {
    return { classification: "system_problem", reasoning: "Evidence indicates the plan/rule/system itself contributed to the failure (§20)." };
  }
  if (contextualDisruption) {
    return { classification: "contextual_disruption", reasoning: "A meaningful contextual disruption is evidenced — do not manufacture laziness against it (Law 5)." };
  }
  if (academicSkillGap && !(capable === false)) {
    return { classification: "academic_problem", reasoning: "The user attempted the work but lacks the required knowledge/skill (§4E, §13)." };
  }
  if (capable === false || resourcesAvailable === false) {
    return { classification: "capacity_problem", reasoning: "Capacity or resources were not actually available — this is not ordinary resistance (§6)." };
  }

  const hasFullOpportunity = capable !== false && understoodTask !== false && resourcesAvailable !== false
    && !contextualDisruption && !safetyIssue;

  if (hasFullOpportunity && evidenceStrength !== "weak") {
    return {
      classification: "ordinary_resistance",
      reasoning: "Capacity, understanding, resources, and opportunity are all present with adequate evidence and no disruption — laziness must remain a permitted conclusion (Law 4, §4).",
      statement: "You are avoiding the work because you do not want to do it. The objective has not changed. Restore execution.",
    };
  }

  return {
    classification: "unresolved",
    reasoning: evidenceStrength === "weak"
      ? "Evidence is not strong enough to support any single classification yet — gather more before acting (§6.9)."
      : "Signals point in more than one direction — treat as mixed and investigate further before intervening.",
  };
}

// ---------------------------------------------------------------------------
// 3. ESCALATION PROOF GATE — 10 steps (spec §10)
// ---------------------------------------------------------------------------
/**
 * @param {object} steps — booleans/values answering each numbered step.
 *   priorIntervention: string|null
 *   correctlyTargeted: boolean|null
 *   correctlyImplemented: boolean|null
 *   implementationVerified: boolean|null
 *   adequateOpportunity: boolean|null
 *   causeStillPresent: boolean|null
 *   recurrenceConfirmed: boolean|null
 *   attributionConfident: boolean|null
 *   systemIntegrityOk: boolean|null
 *   escalationLikelyBetter: boolean|null
 */
function runEscalationProofGate(steps = {}) {
  const checklist = [
    { id: 1, label: "Previous intervention identified", pass: !!steps.priorIntervention },
    { id: 2, label: "Correctly targeted at the confirmed failure", pass: steps.correctlyTargeted === true },
    { id: 3, label: "Correctly implemented as defined", pass: steps.correctlyImplemented === true },
    { id: 4, label: "Implementation verified", pass: steps.implementationVerified === true },
    { id: 5, label: "Adequate opportunity to show effect", pass: steps.adequateOpportunity === true },
    { id: 6, label: "Original failure mechanism still present", pass: steps.causeStillPresent === true },
    { id: 7, label: "Target failure actually recurred", pass: steps.recurrenceConfirmed === true },
    { id: 8, label: "Sufficient attribution (intervention failed, not another variable)", pass: steps.attributionConfident === true },
    { id: 9, label: "System itself operated correctly", pass: steps.systemIntegrityOk === true },
    { id: 10, label: "Escalation would materially improve odds of correction", pass: steps.escalationLikelyBetter === true },
  ];

  const failedSteps = checklist.filter((c) => !c.pass);
  // Step 10 is the actual gate (§10 final paragraph): if it's false, stop
  // and change strategy regardless of the other steps.
  const escalationJustified = steps.escalationLikelyBetter === true && failedSteps.length === 0;

  return {
    checklist,
    failedSteps: failedSteps.map((c) => c.label),
    escalationJustified,
    verdict: escalationJustified
      ? "ESCALATE — all ten steps satisfied."
      : "DO NOT ESCALATE. CHANGE STRATEGY.",
  };
}

// ---------------------------------------------------------------------------
// 4. INTERVENTION EFFECTIVENESS ENGINE + HISTORY MATRIX (spec §11)
// ---------------------------------------------------------------------------
const EFFECTIVENESS_STATES = Object.freeze([
  "EFFECTIVE", "PARTIALLY_EFFECTIVE", "INEFFECTIVE", "INCORRECTLY_TARGETED",
  "INADEQUATELY_VERIFIED", "SYSTEM_DEFECTED", "UNKNOWN",
]);

function createInterventionHistoryMatrix() {
  return { rows: [] }; // { failurePattern, intervention, target, result, effectiveness }
}

function recordInterventionOutcome(matrix, row) {
  const effectiveness = EFFECTIVENESS_STATES.includes(row.effectiveness) ? row.effectiveness : "UNKNOWN";
  matrix.rows.push({ ...row, effectiveness, recordedAt: new Date().toISOString() });
  return matrix;
}

/** Historical effectiveness against a specific failure pattern — never reuse
 *  a repeatedly-ineffective intervention just because it's harsher (§11-12). */
function getHistoricalEffectiveness(matrix, failurePattern, interventionId) {
  const rows = matrix.rows.filter((r) => r.failurePattern === failurePattern && r.intervention === interventionId);
  if (rows.length === 0) return { effectiveness: "UNKNOWN", sampleSize: 0 };
  const ineffectiveCount = rows.filter((r) => ["INEFFECTIVE", "INCORRECTLY_TARGETED", "SYSTEM_DEFECTED"].includes(r.effectiveness)).length;
  const effectiveCount = rows.filter((r) => r.effectiveness === "EFFECTIVE").length;
  let verdict = "UNKNOWN";
  if (effectiveCount > ineffectiveCount) verdict = "EFFECTIVE";
  else if (ineffectiveCount > effectiveCount) verdict = "INEFFECTIVE";
  else verdict = "PARTIALLY_EFFECTIVE";
  return { effectiveness: verdict, sampleSize: rows.length, ineffectiveCount, effectiveCount };
}

// ---------------------------------------------------------------------------
// 5. MINIMUM EFFECTIVE INTERVENTION SELECTION (spec §12, §33)
// ---------------------------------------------------------------------------
/**
 * Ranks candidate interventions and returns the smallest one with adequate
 * evidence of being able to correct the confirmed failure — never the
 * harshest merely because it's available (Law 8).
 *
 * @param {Array} candidates — [{ id, domain, severity, causalRelevance (0-1),
 *   evidenceConfidence (0-1), academicCompatible: bool, implementationReliability (0-1) }]
 * @param {object} matrix — Intervention History Matrix
 * @param {string} failurePattern
 */
function selectMinimumEffectiveIntervention(candidates = [], matrix, failurePattern) {
  const scored = candidates
    .map((c) => {
      const hist = getHistoricalEffectiveness(matrix, failurePattern, c.id);
      const historyPenalty = hist.effectiveness === "INEFFECTIVE" ? -0.5 : 0;
      const score =
        (c.causalRelevance ?? 0.5) * 0.3 +
        (c.evidenceConfidence ?? 0.5) * 0.25 +
        (c.implementationReliability ?? 0.5) * 0.2 +
        (c.academicCompatible ? 0.15 : 0) +
        historyPenalty;
      return { ...c, historicalEffectiveness: hist.effectiveness, score };
    })
    .filter((c) => c.historicalEffectiveness !== "INEFFECTIVE")
    .sort((a, b) => (a.severity - b.severity) || (b.score - a.score)); // smallest severity first, tiebreak by score

  const viable = scored.filter((c) => c.score >= 0.4);
  const chosen = viable[0] || null;

  return {
    chosen,
    ranked: scored,
    note: chosen
      ? `Selected the smallest sufficiently-evidenced intervention: "${chosen.id}".`
      : "No candidate has adequate evidence — do not select the harshest option by default; investigate further (§11).",
  };
}

// ---------------------------------------------------------------------------
// 6. ACADEMIC-FIRST / DISCIPLINE-FIRST ROUTING (spec §13-15)
// ---------------------------------------------------------------------------
function routeAcademicFirst(cause) {
  const routes = {
    knowledge_failure: "academic_reconstruction",
    retrieval_failure: "retrieval_and_reassessment",
    execution_failure: "execution_controls",
    confirmed_distraction: "relevant_distraction_controls",
    ordinary_resistance: "predefined_disciplinary_response",
    multiple_causes: "targeted_combined_response",
  };
  const route = routes[cause] || null;
  return {
    route,
    note: route
      ? `Routed per Academic-First Rule (§13): ${cause} -> ${route}.`
      : "Unrecognized cause — do not default to a digital/entertainment ban; classify further first.",
  };
}

/** §14 — is a disciplinary response actually justified? */
function checkDisciplineFirstCondition(evidence = {}) {
  const required = [
    "taskUnderstood", "resourcesAvailable", "adequateCapacity",
    "noMeaningfulDisruption", "reasonableOpportunity", "deliberateOrStronglySupportedAvoidance",
    "repeatedOrMaterial",
  ];
  const missing = required.filter((k) => evidence[k] !== true);
  return {
    justified: missing.length === 0,
    missing,
    reasoning: missing.length === 0
      ? "All discipline-first conditions are met — the problem may be choice, not incapacity (§14)."
      : `Not all conditions are evidenced (missing: ${missing.join(", ") || "none"}) — do not default to a disciplinary framing.`,
  };
}

// ---------------------------------------------------------------------------
// 7. INDEPENDENT ACADEMIC / DISCIPLINE STATES (spec §15)
// ---------------------------------------------------------------------------
const ACADEMIC_STATES = Object.freeze(["strong", "stable", "weak", "declining", "critical", "unknown"]);
const DISCIPLINE_STATES = Object.freeze([
  "stable", "local_breach", "repeated_breach", "persistent_resistance", "systemic_execution_failure", "critical",
]);

function setAcademicState(profile, state) {
  if (!ACADEMIC_STATES.includes(state)) throw new Error(`Invalid academic state: ${state}`);
  return { ...profile, academicState: state, academicStateUpdatedAt: new Date().toISOString() };
}
function setDisciplineState(profile, state) {
  if (!DISCIPLINE_STATES.includes(state)) throw new Error(`Invalid discipline state: ${state}`);
  return { ...profile, disciplineState: state, disciplineStateUpdatedAt: new Date().toISOString() };
}

// ---------------------------------------------------------------------------
// 8. CONSEQUENCE SATURATION (spec §19)
// ---------------------------------------------------------------------------
function checkConsequenceSaturation(interventionHistoryForPattern = []) {
  const recentFailures = interventionHistoryForPattern.filter((r) =>
    ["INEFFECTIVE", "PARTIALLY_EFFECTIVE"].includes(r.effectiveness)
  ).length;

  if (recentFailures < 2) {
    return { saturated: false, note: "Not enough repeated failure yet to declare saturation." };
  }

  return {
    saturated: true,
    action: "CAUSE_RECHECK_THEN_INTERVENTION_REVIEW",
    questions: [
      "Was the intervention incorrectly targeted?",
      "Was ordinary resistance misclassified?",
      "Was an academic problem misclassified as discipline?",
      "Was the intervention too weak?",
      "Was it too unrelated?",
      "Was it implemented incorrectly?",
      "Did the system fail?",
      "Did the environment change?",
      "Did the user circumvent it?",
      "Is another intervention more causally relevant?",
    ],
    note: "Do NOT escalate severity indefinitely — recheck the cause before selecting a different intervention (§19).",
  };
}

// ---------------------------------------------------------------------------
// 9. SYSTEMIC FAILURE TEST (spec §20)
// ---------------------------------------------------------------------------
function runSystemicFailureTest(auditChecklist = {}) {
  const dimensions = [
    "ruleClarity", "classificationAccuracy", "consequenceClarity", "implementationReliability",
    "verificationQuality", "recoveryDesign", "academicInterventionQuality", "restorationTiming",
    "overrideBehavior", "monitoringQuality", "technicalReliability", "notificationReliability", "dataIntegrity",
  ];
  const failing = dimensions.filter((d) => auditChecklist[d] === false);
  return {
    systemDefectConfirmed: failing.length > 0,
    failingDimensions: failing,
    note: failing.length > 0
      ? "Repair the system before escalating the user (§20)."
      : "No system defect found in the audited dimensions.",
  };
}

// ---------------------------------------------------------------------------
// 10. HUMAN OVERRIDE VALIDITY ENGINE — 10 tests (spec §25-26)
// ---------------------------------------------------------------------------
/**
 * @param {object} request
 *   eventOccurred, hadCapacity, genuineDisruption, safetyIssue, correctRuleTriggered,
 *   eventCausedFailure, correctionNecessary, requestedScopeAppropriate,
 *   evidenceStrength: "weak"|"moderate"|"strong", integrityPreserved: boolean
 */
function evaluateOverrideValidity(request = {}) {
  const tests = {
    reality: request.eventOccurred === true,
    capacity: request.hadCapacity !== undefined ? request.hadCapacity === false : null,
    context: request.genuineDisruption === true,
    safety: request.safetyIssue === true,
    rule: request.correctRuleTriggered === false, // override valid if the WRONG rule fired
    causality: request.eventCausedFailure === true,
    necessity: request.correctionNecessary === true,
    scope: request.requestedScopeAppropriate !== false,
    evidence: request.evidenceStrength === "strong" || request.evidenceStrength === "moderate",
    integrity: request.integrityPreserved !== false,
  };

  if (!tests.reality) {
    return { outcome: "REJECT", reasoning: "Reality Test failed — the claimed event is not established as having occurred.", tests };
  }
  if (!tests.evidence) {
    return { outcome: "DEFER", reasoning: "Evidence is too weak to decide — gather more before ruling.", tests };
  }
  if (!tests.integrity) {
    return { outcome: "REJECT", reasoning: "Accepting would not preserve system integrity.", tests };
  }

  const supportingTests = [tests.capacity, tests.context, tests.safety, tests.rule].filter(Boolean).length;

  if (supportingTests === 0) {
    return { outcome: "REJECT", reasoning: "No capacity, context, safety, or rule-error basis supports this override.", tests };
  }
  if (!tests.causality || !tests.necessity) {
    return { outcome: "RECLASSIFY", reasoning: "An underlying issue is evidenced but it doesn't map cleanly onto the original consequence — reclassify the event instead.", tests };
  }
  if (tests.scope) {
    return { outcome: "ACCEPT", reasoning: "Override is supported, causally linked, necessary, and appropriately scoped.", tests };
  }
  return { outcome: "PARTIAL_ACCEPT", reasoning: "Override is substantively valid but the requested scope is larger than necessary — narrow it.", tests, scope: "narrowed" };
}

// ---------------------------------------------------------------------------
// 11. RECOVERY QUALITY (spec §27)
// ---------------------------------------------------------------------------
const RECOVERY_QUALITY_STATES = Object.freeze([
  "INCOMPLETE", "SUPERFICIAL", "PARTIAL", "COMPLETE", "VERIFIED", "STABLE", "FAILED",
]);

function classifyRecoveryQuality({ stepsCompletedRatio = 0, verifiedByEvidence = false, stableAcrossCycle = false, recurrenceSinceRecovery = false }) {
  if (recurrenceSinceRecovery) return { quality: "FAILED", reasoning: "Recurrence occurred after recovery was claimed." };
  if (stableAcrossCycle && verifiedByEvidence) return { quality: "STABLE", reasoning: "Verified and held stable across a review cycle." };
  if (verifiedByEvidence) return { quality: "VERIFIED", reasoning: "Evidence confirms recovery, but sustained stability isn't yet demonstrated." };
  if (stepsCompletedRatio >= 1) return { quality: "COMPLETE", reasoning: "All required recovery steps were completed but not yet independently verified." };
  if (stepsCompletedRatio >= 0.5) return { quality: "PARTIAL", reasoning: "Roughly half or more of recovery steps are done." };
  if (stepsCompletedRatio > 0) return { quality: "SUPERFICIAL", reasoning: "Minimal recovery steps completed — checking a box is not recovery (§27)." };
  return { quality: "INCOMPLETE", reasoning: "No meaningful recovery steps completed yet." };
}

// ---------------------------------------------------------------------------
// 12. RESTORATION PIPELINE (spec §29)
// ---------------------------------------------------------------------------
const RESTORATION_STAGES = Object.freeze([
  "correction", "verification", "stability", "controlled_restoration", "normal_autonomy",
]);

function stepRestoration(currentStage) {
  const idx = RESTORATION_STAGES.indexOf(currentStage);
  if (idx === -1) return RESTORATION_STAGES[0];
  return RESTORATION_STAGES[Math.min(idx + 1, RESTORATION_STAGES.length - 1)];
}

// ---------------------------------------------------------------------------
// 13. D5 CONTROLLED AUTONOMY (spec §34) + SYSTEM MODIFICATION LOCK (§35)
// ---------------------------------------------------------------------------
const D5_AUTONOMY_STATES = Object.freeze(["NORMAL", "GUIDED", "RESTRICTED", "CONTROLLED_RESTORATION", "RESTORED"]);

function stepD5Autonomy(currentState, direction) {
  const idx = D5_AUTONOMY_STATES.indexOf(currentState);
  if (idx === -1) return D5_AUTONOMY_STATES[0];
  if (direction === "restrict") return D5_AUTONOMY_STATES[Math.min(idx + 1, D5_AUTONOMY_STATES.length - 1)];
  if (direction === "restore") return D5_AUTONOMY_STATES[Math.max(idx - 1, 0)];
  return currentState;
}

/** §35 — block system redesign as a stand-in for doing the actual task. */
function checkSystemModificationLock({ activeExecutionRequired, genuineSystemDefectDemonstrated }) {
  const locked = !!activeExecutionRequired && !genuineSystemDefectDemonstrated;
  return {
    locked,
    note: locked
      ? "System redesign is locked during active execution unless a genuine defect is demonstrated (§35)."
      : "No lock in effect — either no active execution is pending, or a genuine defect justifies a system change.",
  };
}

// ---------------------------------------------------------------------------
// 14. HANDBOOK BOUNDARY REVIEW (spec §38-40)
// ---------------------------------------------------------------------------
/**
 * @param {object} status
 *   internalInterventionsAttempted, correctlyTargeted, implementationVerified,
 *   recoveryGenuinelyAttempted, recurrenceConfirmed, systemDefectsExcluded,
 *   overrideReviewComplete, legitimateInternalInterventionRemains
 */
function reviewHandbookBoundary(status = {}) {
  if (status.legitimateInternalInterventionRemains) {
    return { state: "STATE_A_INTERNAL_RECOVERY", note: "A legitimate internal solution remains — stay inside the internal system." };
  }
  const requiredComplete = [
    "internalInterventionsAttempted", "correctlyTargeted", "implementationVerified",
    "recoveryGenuinelyAttempted", "recurrenceConfirmed", "systemDefectsExcluded", "overrideReviewComplete",
  ];
  const incomplete = requiredComplete.filter((k) => status[k] !== true);

  if (incomplete.length > 0) {
    return {
      state: "STATE_B_CONTROLLED_HANDBOOK_REVIEW",
      incomplete,
      note: "Internal authority is approaching exhaustion but the review is not yet complete — do not silently finalize (§39).",
    };
  }
  return {
    state: "STATE_C_HANDBOOK_BOUNDARY",
    note: "Predefined conditions for leaving Nori's internal escalation architecture are satisfied.",
  };
}

/** §39 — full case record required before any Handbook Boundary finalization. */
function buildHandbookCaseFile(data = {}) {
  const required = [
    "caseId", "initialEvent", "evidence", "context", "assessmentType", "classification",
    "capacityAssessment", "causeAnalysis", "failureSignature", "degreeHistory",
    "interventionHistory", "interventionEffectiveness", "recoveryHistory", "stabilityHistory",
    "stabilityCycleHistory", "overrideHistory", "recurrencePattern", "academicImpact",
    "systemIntegrityAudit", "reasonForD5", "reasonInternalExhausted", "handbookBoundaryStatus",
  ];
  const missing = required.filter((k) => data[k] === undefined || data[k] === null);
  return {
    caseFile: data,
    complete: missing.length === 0,
    missingFields: missing,
    note: missing.length === 0
      ? "Case file complete — ready for Handbook Authority Transition."
      : "Case file incomplete — do not finalize the Handbook Boundary until all fields are present.",
  };
}

/**
 * §40-41 — Authority Transition. Nori's role becomes record/verify/explain/
 * monitor/audit. It must still refuse to autonomously implement anything
 * unsafe, even if an external Handbook nominally contains it, and it must
 * not be used as a standing threat (§41).
 */
function transitionToHandbookAuthority(caseFileResult, proposedAutomatedActions = []) {
  if (!caseFileResult.complete) {
    return { transitioned: false, reason: "Case file is incomplete — cannot transition yet." };
  }

  const safeActions = [];
  const flaggedActions = [];
  for (const action of proposedAutomatedActions) {
    try {
      assertSafe(action);
      safeActions.push(action);
    } catch (e) {
      flaggedActions.push({ action, reason: e.message, escalateTo: "human_authority_or_safe_alternative" });
    }
  }

  return {
    transitioned: true,
    norisRole: ["record", "verify", "explain", "monitor", "audit", "maintain_historical_continuity"],
    automatedActionsApproved: safeActions,
    automatedActionsFlagged: flaggedActions,
    note: "Handbook Boundary is a system state, not a threat — do not repeatedly invoke it outside genuine review (§41).",
  };
}

// ---------------------------------------------------------------------------
// 15. FINAL D5 AUDIT — 20-question checklist (spec §42)
// ---------------------------------------------------------------------------
const FINAL_D5_AUDIT_QUESTIONS = Object.freeze([
  "Was the original event real?",
  "Was it correctly classified?",
  "Was ordinary resistance considered?",
  "Was laziness considered without being manufactured?",
  "Were legitimate contextual explanations considered?",
  "Was capacity considered?",
  "Was academic weakness separated from discipline failure?",
  "Was the intervention correctly targeted?",
  "Was it actually implemented?",
  "Was implementation verified?",
  "Was recovery adequately tested?",
  "Did recurrence genuinely occur?",
  "Was anti-gaming evidence sufficient?",
  "Was double punishment avoided?",
  "Was the system itself audited?",
  "Was academic priority protected?",
  "Was Human Override properly evaluated?",
  "Was the minimum effective intervention considered?",
  "Is further internal intervention actually useful?",
  "Is the Handbook Boundary genuinely justified?",
]);

function runFinalD5Audit(answers = {}) {
  const results = FINAL_D5_AUDIT_QUESTIONS.map((q, i) => ({
    question: q,
    resolved: answers[i] === true,
  }));
  const unresolved = results.filter((r) => !r.resolved).map((r) => r.question);
  return {
    results,
    unresolved,
    finalized: unresolved.length === 0,
    verdict: unresolved.length === 0 ? "HANDBOOK_BOUNDARY_JUSTIFIED" : "DO_NOT_FINALIZE_ESCALATION",
  };
}

// ---------------------------------------------------------------------------
// 16. D5 CONSEQUENCE SELECTION WRAPPER
// ---------------------------------------------------------------------------
/**
 * Ties the routing + minimum-effective-intervention logic together for a
 * single domain, still going through the shared consequenceEngine/
 * safetyGuard pipeline used by every other degree.
 */
function selectDegree5Response({ cause, domain, degree = 5, band = null, priorIneffectiveIds = [] }) {
  const routing = routeAcademicFirst(cause);
  if (!routing.route || routing.route === "academic_reconstruction" || routing.route === "retrieval_and_reassessment") {
    return { consequence: null, routing, note: "Academic-origin cause — route to academic correction, not a disciplinary consequence (§13)." };
  }
  const consequence = selectConsequence(domain, degree, band, priorIneffectiveIds);
  return { consequence, routing };
}

module.exports = {
  CORE_LAWS,
  checkDegree5Entry,
  FAILURE_CLASSIFICATIONS,
  classifyFailure,
  runEscalationProofGate,
  EFFECTIVENESS_STATES,
  createInterventionHistoryMatrix,
  recordInterventionOutcome,
  getHistoricalEffectiveness,
  selectMinimumEffectiveIntervention,
  routeAcademicFirst,
  checkDisciplineFirstCondition,
  ACADEMIC_STATES,
  DISCIPLINE_STATES,
  setAcademicState,
  setDisciplineState,
  checkConsequenceSaturation,
  runSystemicFailureTest,
  evaluateOverrideValidity,
  RECOVERY_QUALITY_STATES,
  classifyRecoveryQuality,
  RESTORATION_STAGES,
  stepRestoration,
  D5_AUTONOMY_STATES,
  stepD5Autonomy,
  checkSystemModificationLock,
  reviewHandbookBoundary,
  buildHandbookCaseFile,
  transitionToHandbookAuthority,
  FINAL_D5_AUDIT_QUESTIONS,
  runFinalD5Audit,
  selectDegree5Response,
};
