/**
 * DEGREE 4 ENGINE
 * ---------------------------------------------------------------------------
 * Degree 4 asks a different question than Degree 3. Degree 3 diagnoses a
 * single event. Degree 4 asks whether the whole Detect->Classify->
 * Consequence->Correct->Verify->Recover LOOP is still working, across
 * multiple events and domains. It adds:
 *
 *   1. Root-Cause Graph      — multiple simultaneous causes, not one story
 *   2. Breakpoint ID         — earliest preventable point, not just the end
 *   3. Four-Layer Reality    — Observation / Inference / Classification / Authority
 *   4. Anti-Gaming Engine    — suspicion triggers investigation, never guilt
 *   5. No-Double-Punishment  — one causal chain != N stacked consequences
 *   6. Controlled Autonomy   — graduated, reviewable, never permanent
 *   7. Verified Stability Cycle (14-day) — evidence-gathering, not a countdown
 *   8. Precommitment Engine  — predefined "if X then Y" rules
 *   9. System Self-Correction — Nori can say "the system was wrong"
 *
 * Still only selects consequences from data/consequenceLibrary.js, still
 * runs every consequence through safetyGuard. No new punishment category
 * is introduced at Degree 4 — only more rigor before one is chosen.
 * ---------------------------------------------------------------------------
 */

const { selectConsequence } = require("./consequenceEngine");
const { CONFIDENCE } = require("./contextEngine");

// ---------------------------------------------------------------------------
// 1. ENTRY CONDITIONS (spec §2, A-H)
// ---------------------------------------------------------------------------
function checkDegree4Entry(history = {}) {
  const reasons = [];
  if ((history.degree3EventsUnresolved || 0) >= 1) reasons.push("persistent_degree3_failure");
  if ((history.repeatedRecoveryFailureCount || 0) >= 2) reasons.push("repeated_failed_recovery");
  if ((history.failedStabilityCycleCount || 0) >= 1) reasons.push("repeated_14day_cycle_failure");
  if ((history.connectedDomainChainLength || 0) >= 3) reasons.push("cross_domain_systemic_failure");
  if ((history.confirmedBypassCount || 0) >= 2) reasons.push("repeated_deliberate_bypass");
  if (history.executionCollapseConfirmed) reasons.push("persistent_execution_collapse");
  if (history.systemIntegrityFailureConfirmed) reasons.push("system_integrity_failure");
  if (history.academicDisciplineRecoveryAllDeclining) reasons.push("critical_combined_failure");
  return { eligible: reasons.length > 0, reasons };
}

// ---------------------------------------------------------------------------
// 2. ROOT-CAUSE GRAPH (spec §6)
// ---------------------------------------------------------------------------
// Each cause: { id, description, classification: primary|secondary|contributing|unrelated|unknown }
function buildRootCauseGraph(causes = []) {
  const valid = ["primary", "secondary", "contributing", "unrelated", "unknown"];
  const graph = causes.map((c) => ({
    id: c.id,
    description: c.description,
    classification: valid.includes(c.classification) ? c.classification : "unknown",
  }));
  const primaryCount = graph.filter((c) => c.classification === "primary").length;
  return {
    causes: graph,
    isSingleCause: graph.length === 1,
    isMultiCause: graph.length > 1,
    // §6: is this independent problems or one connected chain? Multiple
    // "primary" causes with no shared domain suggests independent problems;
    // one primary + several contributing suggests one connected chain.
    likelyConnectedChain: primaryCount <= 1 && graph.length > 1,
  };
}

// ---------------------------------------------------------------------------
// 3. BREAKPOINT IDENTIFICATION (spec §5)
// ---------------------------------------------------------------------------
/**
 * @param {Array} timeline — [{ time, description, isDeviation, withinControl }]
 * Returns the EARLIEST entry marked as a deviation that was within the
 * user's control — not simply the final failure event.
 */
function identifyBreakpoint(timeline = []) {
  const sorted = [...timeline].sort((a, b) => new Date(a.time) - new Date(b.time));
  const breakpoint = sorted.find((e) => e.isDeviation && e.withinControl !== false);
  return {
    breakpoint: breakpoint || null,
    reasoning: breakpoint
      ? `Earliest preventable deviation: "${breakpoint.description}" at ${breakpoint.time}.`
      : "No clear in-control deviation point found in the supplied timeline.",
    fullTimeline: sorted,
  };
}

// ---------------------------------------------------------------------------
// 4. FOUR-LAYER REALITY MODEL (spec §7)
// ---------------------------------------------------------------------------
/**
 * Forces the caller to keep these separate instead of silently merging
 * "study block was missed" (observation) into "Degree 4 intervention"
 * (authority) in one step.
 */
function buildRealityLayers({ observation, inference, classification, authority }) {
  return {
    observation: observation || null,   // what the system actually knows
    inference: inference || null,       // what the system believes happened
    classification: classification || null, // which rule/category applies
    authority: authority || null,       // what action is permitted
  };
}

function tagEvidenceConfidence(evidenceSources = []) {
  if (evidenceSources.length >= 2) return CONFIDENCE.CONFIRMED;
  if (evidenceSources.length === 1) return CONFIDENCE.PROBABLE;
  return CONFIDENCE.UNCLEAR;
}

// ---------------------------------------------------------------------------
// 5. ANTI-GAMING ENGINE (spec §24) — suspicion triggers investigation, not guilt
// ---------------------------------------------------------------------------
const GAMING_PATTERNS = Object.freeze([
  "loophole_exploitation", "timestamp_manipulation", "event_splitting",
  "repeated_questionable_override", "minimum_effort_compliance",
  "deliberate_ambiguity", "repeated_circumvention",
]);

/**
 * @param {object} signals — { pattern: string, occurrences: number, evidence: string[] }[]
 */
function evaluateAntiGaming(signals = []) {
  const flagged = signals.filter((s) => GAMING_PATTERNS.includes(s.pattern) && s.occurrences >= 2);
  const withEvidence = flagged.filter((s) => (s.evidence || []).length > 0);

  if (withEvidence.length === 0) {
    return { requiresInvestigation: flagged.length > 0, confirmed: false,
      reasoning: "Suspicion is not proof — no evidenced pattern meets the confirmation bar. Investigate, do not punish." };
  }
  return {
    requiresInvestigation: true,
    confirmed: false, // Anti-Gaming Engine can trigger investigation only, never automatic guilt (spec §24)
    flaggedPatterns: withEvidence.map((s) => s.pattern),
    reasoning: "Evidenced pattern(s) found — route to investigation. Confirmation still requires human/audit review, not automation alone.",
  };
}

// ---------------------------------------------------------------------------
// 6. NO-DOUBLE-PUNISHMENT ENGINE (spec §25)
// ---------------------------------------------------------------------------
/**
 * @param {Array} events — [{ eventId, causedByEventId: string|null, domain }]
 * Groups events into causal chains. Only the earliest event in a chain
 * should receive a full consequence; downstream events in the same chain
 * are recorded but must not stack an independent consequence.
 */
function consolidateCausalChains(events = []) {
  const chains = [];
  const byId = Object.fromEntries(events.map((e) => [e.eventId, e]));

  function rootOf(e) {
    let current = e;
    const seen = new Set();
    while (current.causedByEventId && byId[current.causedByEventId] && !seen.has(current.eventId)) {
      seen.add(current.eventId);
      current = byId[current.causedByEventId];
    }
    return current.eventId;
  }

  const grouped = {};
  for (const e of events) {
    const root = rootOf(e);
    grouped[root] = grouped[root] || [];
    grouped[root].push(e.eventId);
  }
  for (const [root, members] of Object.entries(grouped)) {
    chains.push({ rootEventId: root, chainMembers: members, consequenceEligibleEventId: root });
  }
  return chains;
}

// ---------------------------------------------------------------------------
// 7. CONTROLLED AUTONOMY (spec §20)
// ---------------------------------------------------------------------------
const AUTONOMY_STATES = Object.freeze([
  "normal", "monitored", "controlled", "academic_priority", "reconstruction",
]);

function stepAutonomy(currentState, direction) {
  const idx = AUTONOMY_STATES.indexOf(currentState);
  if (idx === -1) return AUTONOMY_STATES[0];
  if (direction === "restrict") return AUTONOMY_STATES[Math.min(idx + 1, AUTONOMY_STATES.length - 1)];
  if (direction === "restore") return AUTONOMY_STATES[Math.max(idx - 1, 0)];
  return currentState;
}

// ---------------------------------------------------------------------------
// 8. VERIFIED 14-DAY STABILITY CYCLE (spec §21-23)
// ---------------------------------------------------------------------------
const CYCLE_PHASES = Object.freeze([
  "reset_initiated", "baseline_established", "daily_execution",
  "mid_cycle_review", "final_stability_review", "verification", "restoration",
]);

function initiateStabilityCycle(domain, lengthDays = 14) {
  return {
    domain,
    phase: "reset_initiated",
    lengthDays,
    startedAt: new Date().toISOString(),
    days: [], // { dayIndex, executed: bool, recurrence: bool, note }
  };
}

function recordStabilityDay(cycle, dayResult) {
  cycle.days.push({ dayIndex: cycle.days.length + 1, ...dayResult });
  if (cycle.phase === "reset_initiated") cycle.phase = "baseline_established";
  else if (cycle.days.length >= 1) cycle.phase = "daily_execution";
  if (cycle.days.length === Math.floor(cycle.lengthDays / 2)) cycle.phase = "mid_cycle_review";
  if (cycle.days.length >= cycle.lengthDays) cycle.phase = "final_stability_review";
  return cycle;
}

/**
 * A single good day never erases history; a single isolated failure doesn't
 * automatically destroy the whole cycle either (spec §21, Attacks 1-2) —
 * this only fails the cycle on recurrence, not on one rough day.
 */
function reviewStabilityCycle(cycle) {
  if (cycle.days.length < cycle.lengthDays) {
    return { ...cycle, phase: cycle.phase, verdict: "in_progress" };
  }
  const recurrenceCount = cycle.days.filter((d) => d.recurrence).length;
  const executedCount = cycle.days.filter((d) => d.executed).length;

  if (recurrenceCount === 0 && executedCount >= cycle.lengthDays * 0.85) {
    cycle.phase = "verification";
    return { ...cycle, verdict: "verified_stable" };
  }
  if (recurrenceCount >= 3) {
    cycle.phase = "reset_initiated"; // cycle restarts — genuine instability
    cycle.days = [];
    return { ...cycle, verdict: "failed_restart_required" };
  }
  return { ...cycle, phase: "final_stability_review", verdict: "marginal_extend_review" };
}

// ---------------------------------------------------------------------------
// 9. PRECOMMITMENT ENGINE (spec §30)
// ---------------------------------------------------------------------------
function createPrecommitment(trigger, response) {
  return { trigger, response, createdAt: new Date().toISOString(), timesFired: 0 };
}

function fireIfTriggered(precommitment, currentTrigger) {
  if (currentTrigger !== precommitment.trigger) return { fired: false, precommitment };
  precommitment.timesFired += 1;
  return { fired: true, response: precommitment.response, precommitment };
}

// ---------------------------------------------------------------------------
// 10. DEGREE 4 CONSEQUENCE SELECTION (Domain Precision, spec §15)
// ---------------------------------------------------------------------------
const DEGREE4_SEVERITY_CEILING = 4;

function selectDegree4Response(rootCauseGraph, primaryDomain, priorIneffectiveIds = []) {
  const primaryCauses = rootCauseGraph.causes.filter((c) => c.classification === "primary");
  if (primaryCauses.length === 0) {
    return { consequence: null, note: "No confirmed primary cause — investigate further before intervening." };
  }
  const consequence = selectConsequence(primaryDomain, 2, null, priorIneffectiveIds);
  return { consequence, note: `Selected for confirmed primary domain: ${primaryDomain}.` };
}

// ---------------------------------------------------------------------------
// 11. SYSTEM SELF-CORRECTION (spec §36)
// ---------------------------------------------------------------------------
function systemSelfCorrection(reason) {
  return {
    action: "cancel_active_consequence_and_flag_for_review",
    reason,
    flaggedAt: new Date().toISOString(),
    note: "The system was wrong for this event — correcting classification, not punishing the user for a system defect.",
  };
}

module.exports = {
  checkDegree4Entry,
  buildRootCauseGraph,
  identifyBreakpoint,
  buildRealityLayers,
  tagEvidenceConfidence,
  evaluateAntiGaming,
  consolidateCausalChains,
  AUTONOMY_STATES,
  stepAutonomy,
  CYCLE_PHASES,
  initiateStabilityCycle,
  recordStabilityDay,
  reviewStabilityCycle,
  createPrecommitment,
  fireIfTriggered,
  DEGREE4_SEVERITY_CEILING,
  selectDegree4Response,
  systemSelfCorrection,
};
