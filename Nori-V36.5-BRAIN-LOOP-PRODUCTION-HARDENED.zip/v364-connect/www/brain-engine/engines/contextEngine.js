/**
 * CONTEXT ENGINE
 * ---------------------------------------------------------------------------
 * Determines WHAT happened and WHY, before any consequence is considered.
 * Implements the context categories from Degree 1 §7 and Degree 2 §7-10.
 * ---------------------------------------------------------------------------
 */

const CONTEXT_TYPES = Object.freeze({
  LEGITIMATE_ACTIVITY: "legitimate_activity",
  NECESSARY_INTERRUPTION: "necessary_interruption", // emergency etc.
  ACCIDENTAL_INTERACTION: "accidental_interaction",
  EMOTIONAL_LAPSE: "emotional_lapse",
  DIFFICULT_DAY: "difficult_day",
  DELIBERATE_DISTRACTION: "deliberate_distraction",
  SUSTAINED_DELIBERATE_DISTRACTION: "sustained_deliberate_distraction",
  UNKNOWN: "unknown",
});

const CONFIDENCE = Object.freeze({ CONFIRMED: "confirmed", PROBABLE: "probable", UNCLEAR: "unclear" });

/**
 * @param {object} event
 *   domain: string                — which of the six domains this touches
 *   durationMinutes: number       — how long the behavior lasted
 *   statedPurpose: string|null    — what the user says they were doing
 *   isEmergency: boolean
 *   wasAccidental: boolean
 *   continuedAfterAwareness: boolean — did they keep going after recognizing it?
 *   reportedDifficultDay: boolean
 *   evidenceSources: string[]     — e.g. ["system_log", "user_report"]
 */
function classifyContext(event) {
  const evidenceCount = (event.evidenceSources || []).length;
  const confidence = evidenceCount >= 2 ? CONFIDENCE.CONFIRMED
    : evidenceCount === 1 ? CONFIDENCE.PROBABLE
    : CONFIDENCE.UNCLEAR;

  if (event.isEmergency) {
    return { type: CONTEXT_TYPES.NECESSARY_INTERRUPTION, confidence, breachEligible: false,
      reasoning: "Emergency/necessary communication — never a disciplinary breach." };
  }

  if (event.wasAccidental && (event.durationMinutes || 0) <= 1 && !event.continuedAfterAwareness) {
    return { type: CONTEXT_TYPES.ACCIDENTAL_INTERACTION, confidence, breachEligible: false,
      reasoning: "Brief accidental interaction, immediately exited — not a breach." };
  }

  if (event.statedPurpose && event.statedPurpose.toLowerCase().includes("academic")) {
    return { type: CONTEXT_TYPES.LEGITIMATE_ACTIVITY, confidence, breachEligible: false,
      reasoning: "Stated academic purpose — legitimate use unless contradicted by evidence." };
  }

  if (event.reportedDifficultDay && !event.continuedAfterAwareness) {
    return { type: CONTEXT_TYPES.DIFFICULT_DAY, confidence, breachEligible: false,
      reasoning: "Reported difficult day — context for interpreting result, not itself a breach." };
  }

  if (!event.wasAccidental && (event.durationMinutes || 0) > 1 && !event.continuedAfterAwareness) {
    return { type: CONTEXT_TYPES.EMOTIONAL_LAPSE, confidence, breachEligible: (event.durationMinutes || 0) > 10,
      reasoning: "Brief non-accidental deviation without sustained continuation." };
  }

  if (event.continuedAfterAwareness && (event.durationMinutes || 0) <= 20) {
    return { type: CONTEXT_TYPES.DELIBERATE_DISTRACTION, confidence, breachEligible: true,
      reasoning: "Continued deliberately after recognizing the breach; not yet sustained." };
  }

  if (event.continuedAfterAwareness && (event.durationMinutes || 0) > 20) {
    return { type: CONTEXT_TYPES.SUSTAINED_DELIBERATE_DISTRACTION, confidence, breachEligible: true,
      reasoning: "Continued deliberately for an extended period after recognizing the breach." };
  }

  return { type: CONTEXT_TYPES.UNKNOWN, confidence: CONFIDENCE.UNCLEAR, breachEligible: false,
    reasoning: "Insufficient evidence to classify — defaults to investigation, not consequence." };
}

module.exports = { classifyContext, CONTEXT_TYPES, CONFIDENCE };
