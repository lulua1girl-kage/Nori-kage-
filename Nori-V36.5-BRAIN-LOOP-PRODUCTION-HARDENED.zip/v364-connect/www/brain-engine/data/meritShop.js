/**
 * MERIT SHOP
 * ---------------------------------------------------------------------------
 * Fixed exchange tiers for spending accumulated Merit points on privileges.
 *
 * Two redemption paths now exist:
 *   - redeem(account, tierName, domain)        <- original flat tiers
 *     (small/standard/major/achievement/milestone), kept unchanged for
 *     backward compatibility with anything already calling it.
 *   - redeemLevelTier(account, level, points, domain) <- the real per-level
 *     reward tiers transcribed from the handbook's Award System (Level 1
 *     Merit Shop through Level 5 reward tiers), sourced from
 *     data/awardLibrary.js so the numbers never drift out of sync with the
 *     award catalog.
 *
 * Integrity rule (Degree 2 §18, Degree 3 §38, Level 1 RULE 3 / Level 2
 * PROTECTION 3): Merit is never awarded simply for enduring a consequence,
 * and redemption never restores an actively locked privilege early — both
 * redemption functions enforce the same activeLocks check below.
 * ---------------------------------------------------------------------------
 */

const { LEVELS } = require("../data/awardLibrary");

const SHOP_TIERS = [
  { tier: "small", cost: 5, examples: ["extra 15 min entertainment", "choose tonight's snack", "one bonus meme/video"] },
  { tier: "standard", cost: 10, examples: ["1 hour free-choice screen time", "pick next movie/show", "skip one low-priority chore"] },
  { tier: "major", cost: 20, examples: ["half-day outing", "new small purchase within budget", "extra gaming session"] },
  { tier: "achievement", cost: 30, examples: ["full free day (non-academic obligations still apply)", "larger purchase within budget"] },
  { tier: "milestone", cost: 50, examples: ["major reward defined case-by-case with the user"] },
];

function getTier(tierName) {
  return SHOP_TIERS.find((t) => t.tier === tierName) || null;
}

/**
 * @param {object} account { balance: number, activeLocks: string[] domain ids currently restricted }
 * @param {string} tierName
 * @param {string} desiredDomain — which domain the reward would touch, e.g. "entertainment"
 */
function redeem(account, tierName, desiredDomain) {
  const tier = getTier(tierName);
  if (!tier) return { success: false, reason: `Unknown tier: ${tierName}` };
  if (account.balance < tier.cost) {
    return { success: false, reason: `Insufficient balance (${account.balance}/${tier.cost})` };
  }
  // A redemption cannot be used to circumvent an active consequence lock in
  // the same domain — that would let points buy back a breach for free.
  if ((account.activeLocks || []).includes(desiredDomain)) {
    return { success: false, reason: `Domain "${desiredDomain}" is currently locked by an active consequence; redemption unavailable there until recovery.` };
  }
  return {
    success: true,
    newBalance: account.balance - tier.cost,
    tier: tier.tier,
    cost: tier.cost,
    grantedIn: desiredDomain,
  };
}

/** Returns the Level N reward-tier menu straight from the award catalog. */
function getRewardTiers(level) {
  const levelDef = LEVELS.find((l) => l.level === level);
  return levelDef ? levelDef.rewardTiers : [];
}

/**
 * Redeem against a specific Level's reward-tier menu (Level 1 = 5/10/20/30,
 * Level 2 = 10/20/40/60, Level 3 = 25/50/75/100, Level 4 = 50/100/150/250,
 * Level 5 = 100/250/500/1000 — see data/awardLibrary.js for exact tables).
 *
 * @param {object} account       { balance, activeLocks }
 * @param {number} level         1-5
 * @param {number} pointsCost    must match a tier's `points` exactly
 * @param {string} desiredDomain domain the reward would touch/unlock
 */
function redeemLevelTier(account, level, pointsCost, desiredDomain) {
  const tiers = getRewardTiers(level);
  if (tiers.length === 0) return { success: false, reason: `Unknown level: ${level}` };

  const tier = tiers.find((t) => t.points === pointsCost);
  if (!tier) {
    return {
      success: false,
      reason: `No Level ${level} reward tier at ${pointsCost} points.`,
      availableTiers: tiers.map((t) => t.points),
    };
  }
  if (account.balance < tier.points) {
    return { success: false, reason: `Insufficient balance (${account.balance}/${tier.points})` };
  }
  if ((account.activeLocks || []).includes(desiredDomain)) {
    return { success: false, reason: `Domain "${desiredDomain}" is currently locked by an active consequence; redemption unavailable there until recovery.` };
  }

  return {
    success: true,
    newBalance: account.balance - tier.points,
    level,
    tierTitle: tier.title,
    cost: tier.points,
    examples: tier.examples || [],
    grantedIn: desiredDomain,
  };
}

module.exports = { SHOP_TIERS, getTier, redeem, getRewardTiers, redeemLevelTier };
