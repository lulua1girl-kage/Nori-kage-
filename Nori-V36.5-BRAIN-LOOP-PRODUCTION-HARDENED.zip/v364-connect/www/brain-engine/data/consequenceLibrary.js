/**
 * CONSEQUENCE LIBRARY
 * ---------------------------------------------------------------------------
 * This is the ONLY source of consequences the Brain is allowed to select
 * from. Nothing here is physical, painful, degrading, or health-affecting.
 * The Brain (engines/consequenceEngine.js) NEVER invents a new consequence
 * at runtime — it only picks an id from this list, per the fixed-consequence
 * principle in the Degree 1 & 2 specs.
 *
 * Hard rule enforced elsewhere in code (see engines/safetyGuard.js):
 * any consequence object lacking `domain` or carrying a `physical` flag is
 * rejected before it can ever reach the user.
 * ---------------------------------------------------------------------------
 */

const DOMAINS = Object.freeze({
  DIGITAL_SOCIAL: "digital_social",
  ENTERTAINMENT: "entertainment",
  GAMING: "gaming",
  ACADEMIC_RABBIT_HOLE: "academic_rabbit_hole",
  CREATIVE_HOBBY: "creative_hobby",
  PLANNING_SYSTEM: "planning_system",
  STATUS_RECOGNITION: "status_recognition",
  AUTONOMY: "autonomy",
  ACADEMIC_CORRECTION: "academic_correction",
});

// Every entry: { id, domain, severity: 1-5 (maps loosely to Degree band),
// label, description, defaultDurationHours (null = until recovery conditions met) }
const CONSEQUENCES = [
  // ---- DOMAIN 1: Digital / Social ----
  { id: "social_media_lock_short", domain: DOMAINS.DIGITAL_SOCIAL, severity: 1,
    label: "Short social media lock",
    description: "Social apps unavailable for a fixed short window.",
    defaultDurationHours: 24 },
  { id: "short_form_content_lock", domain: DOMAINS.DIGITAL_SOCIAL, severity: 2,
    label: "Short-form content lock",
    description: "Reels/Shorts/TikTok-style feeds blocked; regular app use unaffected.",
    defaultDurationHours: 48 },
  { id: "non_academic_browsing_restriction", domain: DOMAINS.DIGITAL_SOCIAL, severity: 2,
    label: "Non-academic browsing restriction",
    description: "General recreational browsing restricted; academic sites whitelisted.",
    defaultDurationHours: 48 },
  { id: "academic_use_only_mode", domain: DOMAINS.DIGITAL_SOCIAL, severity: 3,
    label: "Academic-use-only mode",
    description: "Device/app restricted to a whitelist of academic tools only.",
    defaultDurationHours: 72 },
  { id: "discretionary_digital_suspension", domain: DOMAINS.DIGITAL_SOCIAL, severity: 4,
    label: "Discretionary digital privilege suspension",
    description: "All optional digital privileges suspended pending recovery.",
    defaultDurationHours: null },

  // ---- DOMAIN 2: Entertainment / Escapism ----
  { id: "streaming_restriction", domain: DOMAINS.ENTERTAINMENT, severity: 2,
    label: "Streaming restriction",
    description: "Streaming services unavailable for a fixed window.",
    defaultDurationHours: 48 },
  { id: "binge_content_restriction", domain: DOMAINS.ENTERTAINMENT, severity: 2,
    label: "Binge-content restriction",
    description: "Episodic/binge content specifically restricted.",
    defaultDurationHours: 48 },
  { id: "entertainment_browsing_lock", domain: DOMAINS.ENTERTAINMENT, severity: 3,
    label: "Entertainment browsing lock",
    description: "Entertainment sites/apps locked until recovery conditions met.",
    defaultDurationHours: null },
  { id: "delayed_entertainment_unlock", domain: DOMAINS.ENTERTAINMENT, severity: 1,
    label: "Delayed entertainment unlock",
    description: "Entertainment access delayed until a scheduled window.",
    defaultDurationHours: 24 },

  // ---- DOMAIN 3: Gaming ----
  { id: "gaming_suspension_short", domain: DOMAINS.GAMING, severity: 2,
    label: "Short gaming suspension",
    description: "Gaming apps unavailable for a fixed short window.",
    defaultDurationHours: 48 },
  { id: "online_game_restriction", domain: DOMAINS.GAMING, severity: 2,
    label: "Online game restriction",
    description: "Multiplayer/online games restricted; offline unaffected.",
    defaultDurationHours: 48 },
  { id: "protected_hour_gaming_lock", domain: DOMAINS.GAMING, severity: 1,
    label: "Protected-hour gaming lock",
    description: "Gaming blocked only during protected study hours.",
    defaultDurationHours: null },
  { id: "gaming_suspension_full", domain: DOMAINS.GAMING, severity: 4,
    label: "Full gaming suspension",
    description: "All gaming suspended pending recovery.",
    defaultDurationHours: null },

  // ---- DOMAIN 4: Academic Rabbit Holes ----
  { id: "curiosity_reserve", domain: DOMAINS.ACADEMIC_RABBIT_HOLE, severity: 1,
    label: "Curiosity Reserve",
    description: "Unrelated topic captured and deferred, not blocked outright.",
    defaultDurationHours: null },
  { id: "research_queue", domain: DOMAINS.ACADEMIC_RABBIT_HOLE, severity: 1,
    label: "Research Queue",
    description: "Off-topic research queued for an optional later window.",
    defaultDurationHours: null },
  { id: "academic_purpose_only_research", domain: DOMAINS.ACADEMIC_RABBIT_HOLE, severity: 2,
    label: "Academic-purpose-only research mode",
    description: "Research tools restricted to the current subject only.",
    defaultDurationHours: 48 },

  // ---- DOMAIN 5: Creative / Hobby ----
  { id: "optional_hobby_suspension", domain: DOMAINS.CREATIVE_HOBBY, severity: 2,
    label: "Optional hobby suspension",
    description: "Non-required creative/hobby activity suspended.",
    defaultDurationHours: 48 },
  { id: "hobby_scheduling_restriction", domain: DOMAINS.CREATIVE_HOBBY, severity: 1,
    label: "Hobby scheduling restriction",
    description: "Hobby time restricted to specific scheduled windows.",
    defaultDurationHours: null },
  { id: "project_queue", domain: DOMAINS.CREATIVE_HOBBY, severity: 1,
    label: "Project queue",
    description: "New creative projects queued until current objective is done.",
    defaultDurationHours: null },

  // ---- DOMAIN 6: Planning / System Interference ----
  { id: "plan_freeze", domain: DOMAINS.PLANNING_SYSTEM, severity: 2,
    label: "Plan Freeze",
    description: "Current approved plan locked; redesign unavailable without cause.",
    defaultDurationHours: 72 },
  { id: "execution_first_mode", domain: DOMAINS.PLANNING_SYSTEM, severity: 2,
    label: "Execution-First Mode",
    description: "Optimization/redesign deferred until required execution is complete.",
    defaultDurationHours: null },
  { id: "one_plan_only_mode", domain: DOMAINS.PLANNING_SYSTEM, severity: 3,
    label: "One-Plan-Only Mode",
    description: "Only one active plan permitted at a time.",
    defaultDurationHours: null },

  // ---- DOMAIN 7: Status / Recognition ----
  { id: "merit_deduction", domain: DOMAINS.STATUS_RECOGNITION, severity: 1,
    label: "Merit deduction",
    description: "Fixed point deduction from the Merit balance.",
    defaultDurationHours: null },
  { id: "merit_freeze", domain: DOMAINS.STATUS_RECOGNITION, severity: 2,
    label: "Merit freeze",
    description: "Merit accrual paused until recovery conditions met.",
    defaultDurationHours: null },
  { id: "recognition_suspension", domain: DOMAINS.STATUS_RECOGNITION, severity: 2,
    label: "Recognition suspension",
    description: "Badges/awards suspended pending recovery.",
    defaultDurationHours: null },
  { id: "promotion_freeze", domain: DOMAINS.STATUS_RECOGNITION, severity: 3,
    label: "Promotion freeze",
    description: "Tier/level promotion paused pending recovery.",
    defaultDurationHours: null },
  { id: "probation", domain: DOMAINS.STATUS_RECOGNITION, severity: 4,
    label: "Probation",
    description: "Formal probation status; heightened verification required.",
    defaultDurationHours: null },

  // ---- DOMAIN 8: Autonomy ----
  { id: "guided_autonomy", domain: DOMAINS.AUTONOMY, severity: 2,
    label: "Guided Autonomy",
    description: "Brain offers a predefined choice set instead of free choice.",
    defaultDurationHours: null },
  { id: "restricted_discretionary_choice", domain: DOMAINS.AUTONOMY, severity: 3,
    label: "Restricted Discretionary Choice",
    description: "Optional/discretionary choices narrowed to a fixed set.",
    defaultDurationHours: null },
  { id: "decision_friction_gate", domain: DOMAINS.AUTONOMY, severity: 2,
    label: "Decision Friction Gate",
    description: "A predefined check-gate is inserted before optional activity access.",
    defaultDurationHours: null },

  // ---- DOMAIN 9: Academic Correction (not punitive — required recovery work) ----
  { id: "targeted_reteaching", domain: DOMAINS.ACADEMIC_CORRECTION, severity: 1,
    label: "Targeted reteaching",
    description: "Re-explanation of the specific missed concept(s).",
    defaultDurationHours: null },
  { id: "retrieval_practice_set", domain: DOMAINS.ACADEMIC_CORRECTION, severity: 1,
    label: "Retrieval practice set",
    description: "Practice problems targeting the confirmed weak concept(s).",
    defaultDurationHours: null },
  { id: "error_autopsy", domain: DOMAINS.ACADEMIC_CORRECTION, severity: 1,
    label: "Error autopsy",
    description: "Structured error -> cause -> correction -> prevention writeup.",
    defaultDurationHours: null },
  { id: "reassessment", domain: DOMAINS.ACADEMIC_CORRECTION, severity: 2,
    label: "Reassessment",
    description: "A follow-up assessment verifying the specific weak area.",
    defaultDurationHours: null },
  { id: "mastery_checkpoint", domain: DOMAINS.ACADEMIC_CORRECTION, severity: 2,
    label: "Mastery checkpoint",
    description: "Gate requiring demonstrated mastery before status restores.",
    defaultDurationHours: null },
];

// Explicit, permanent denylist. Nothing matching these categories may ever
// be added to CONSEQUENCES above. safetyGuard.js checks every consequence
// object against this at runtime as a second layer of defense.
const FOREVER_BANNED = Object.freeze([
  "physical_punishment", "forced_exercise", "cold_exposure", "cold_shower",
  "food_restriction", "sleep_restriction", "pain", "humiliation", "threats",
  "degradation", "self_insult", "social_humiliation", "intimidation",
]);

function getConsequenceById(id) {
  return CONSEQUENCES.find((c) => c.id === id) || null;
}

function getConsequencesByDomain(domain) {
  return CONSEQUENCES.filter((c) => c.domain === domain);
}

module.exports = { DOMAINS, CONSEQUENCES, FOREVER_BANNED, getConsequenceById, getConsequencesByDomain };
