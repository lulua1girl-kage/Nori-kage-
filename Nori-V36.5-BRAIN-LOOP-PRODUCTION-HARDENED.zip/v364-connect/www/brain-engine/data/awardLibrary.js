/**
 * AWARD LIBRARY
 * ---------------------------------------------------------------------------
 * The full 5-level Merit/Award system (Level 1 Merit -> Level 5 Elite Honor).
 * This is a pure data catalog — like consequenceLibrary.js, it defines WHAT
 * can be earned, never decides on its own that something WAS earned. That
 * job belongs to engines/awardEngine.js, which checks a caller-supplied
 * `evidence` object against each award's `requirements` before granting
 * anything (same "evidence, not vibes" pattern as the rest of brain-engine).
 *
 * requirements[] uses a tiny DSL so simple thresholds can be checked
 * automatically:
 *   { key: "overallResult", op: "gte", value: 90 }   -> evidence.overallResult >= 90
 *   { key: "noDeliberateAvoidance", op: "true" }      -> evidence.noDeliberateAvoidance === true
 * Multi-step narrative requirements (the Phoenix Award, the Grand Academic
 * Honor's full checklist, etc.) are still encoded the same way — each
 * checklist bullet becomes one boolean requirement — so the caller/app is
 * responsible for actually verifying each condition before asserting it in
 * evidence, exactly like buildHandbookCaseFile()'s required-fields list or
 * runSystemicFailureTest()'s audited dimensions elsewhere in this engine.
 *
 * Two awards (Level 1 Cat 2 "Academic Score Merit" and Level 1 Cat 5 "Model
 * Exam Merit") are score-BAND awards rather than single-threshold awards —
 * those are handled by dedicated functions in awardEngine.js
 * (evaluateScoreBandMerit / evaluateModelExamMerit) instead of the generic
 * requirements[] evaluator, and are listed here only as reference tables.
 * ---------------------------------------------------------------------------
 */

const LEVEL_TITLES = Object.freeze({
  1: "Merit",
  2: "Distinction",
  3: "Excellence",
  4: "Honor",
  5: "Elite Honor",
});

// ---------------------------------------------------------------------------
// LEVEL 1 — MERIT AWARDS
// ---------------------------------------------------------------------------
const LEVEL_1 = {
  level: 1,
  title: "Merit",
  purpose: "Recognize small but meaningful achievements — every completed responsibility is an opportunity to earn merit.",
  categories: [
    {
      id: "l1_continuous_assessment",
      title: "Continuous Assessment Merit",
      awards: [
        { id: "quiz_merit", title: "Quiz Merit", requirement: "Score 80% or higher on a quiz/short test.",
          requirements: [{ key: "scorePercentage", op: "gte", value: 80 }], meritPoints: 1,
          notes: "Also grants one small earned leisure privilege after the day's academic responsibilities are complete." },
        { id: "classwork_merit", title: "Classwork Merit", requirement: "Classwork completed properly and submitted when required.",
          requirements: [{ key: "completedProperly", op: "true" }], meritPoints: 1 },
        { id: "homework_merit", title: "Homework Merit", requirement: "Homework completed and submitted on time.",
          requirements: [{ key: "completedOnTime", op: "true" }], meritPoints: 1 },
        { id: "group_work_merit", title: "Group Work Merit", requirement: "Assigned contribution to a group task completed; participated responsibly; did not leave the work entirely to others.",
          requirements: [{ key: "contributionCompleted", op: "true" }, { key: "didNotOffload", op: "true" }], meritPoints: 1 },
        { id: "participation_merit", title: "Participation Merit", requirement: "Meaningful participation during class (questions, answers, discussion, assisting appropriately).",
          requirements: [{ key: "meaningfulParticipation", op: "true" }], meritPoints: 1 },
        { id: "practical_merit", title: "Practical / Experiment Merit", requirement: "Practical activity completed responsibly with genuine effort; observations/notes/conclusions completed.",
          requirements: [{ key: "practicalCompletedResponsibly", op: "true" }], meritPoints: 1 },
        { id: "assignment_merit", title: "Assignment Merit", requirement: "Assignment completed correctly and submitted on time.",
          requirements: [{ key: "assignmentCompletedOnTime", op: "true" }], meritPoints: 2 },
        { id: "project_merit", title: "Project Merit", requirement: "Assigned project responsibility completed, deadline met, genuine effort shown.",
          requirements: [{ key: "projectCompletedOnTime", op: "true" }], meritPoints: 2 },
        { id: "fieldwork_merit", title: "Field Work Merit", requirement: "Assigned field-work responsibilities completed, participated properly, required work submitted.",
          requirements: [{ key: "fieldworkCompleted", op: "true" }], meritPoints: 1 },
      ],
    },
    {
      id: "l1_academic_score",
      title: "Academic Score Merit",
      note: "Score-band award — evaluated via awardEngine.evaluateScoreBandMerit(percentage), not the generic requirements[] evaluator.",
      bands: [
        { min: 80, max: 84, meritPoints: 2 },
        { min: 85, max: 89, meritPoints: 3 },
        { min: 90, max: 94, meritPoints: 4 },
        { min: 95, max: 99, meritPoints: 5 },
        { min: 100, max: 100, meritPoints: 6, badge: "Perfect Score Recognition" },
      ],
    },
    {
      id: "l1_discipline",
      title: "Discipline Merit",
      awards: [
        { id: "discipline_streak_7day", title: "7-Day Discipline Streak",
          requirement: "Study schedule followed for 7 consecutive days; no deliberate academic avoidance; required assignments completed; no unnecessary academic backlog.",
          requirements: [
            { key: "streakDays", op: "gte", value: 7 },
            { key: "noDeliberateAvoidance", op: "true" },
            { key: "assignmentsCompleted", op: "true" },
            { key: "noUnnecessaryBacklog", op: "true" },
          ], meritPoints: 5, notes: "Also grants one earned leisure privilege." },
        { id: "zero_backlog_merit", title: "Zero-Backlog Merit", requirement: "No overdue academic work for 7 consecutive days.",
          requirements: [{ key: "noOverdueWorkDays", op: "gte", value: 7 }], meritPoints: 5 },
        { id: "early_preparation_merit", title: "Early Preparation Merit", requirement: "Preparing for an upcoming assessment before the last-minute period.",
          requirements: [{ key: "preparedBeforeLastMinute", op: "true" }], meritPoints: 2 },
      ],
    },
    {
      id: "l1_recovery",
      title: "Recovery Merit",
      awards: [
        { id: "recovery_merit", title: "Recovery Merit",
          requirement: "A previous result was below 80%, followed by correcting mistakes, completing recovery work, demonstrating understanding, and achieving 80%+ on the next relevant assessment.",
          requirements: [
            { key: "previousResultBelow80", op: "true" },
            { key: "mistakesCorrected", op: "true" },
            { key: "recoveryWorkCompleted", op: "true" },
            { key: "understandingDemonstrated", op: "true" },
            { key: "nextAssessmentScore", op: "gte", value: 80 },
          ], meritPoints: 5 },
        { id: "improvement_merit_10", title: "Improvement Merit (10+ points)", requirement: "Score improves by 10 or more percentage points from the previous comparable assessment.",
          requirements: [{ key: "improvementPercentagePoints", op: "gte", value: 10 }], meritPoints: 3 },
        { id: "improvement_merit_15", title: "Improvement Merit (15+ points)", requirement: "Score improves by 15 or more percentage points from the previous comparable assessment.",
          requirements: [{ key: "improvementPercentagePoints", op: "gte", value: 15 }], meritPoints: 5 },
      ],
    },
    {
      id: "l1_entrance_prep",
      title: "Entrance Preparation Merit",
      note: "Model Exam Merit — score-band award for the five entrance subjects (Mathematics, English, Biology, Chemistry, Physics). Evaluated via awardEngine.evaluateModelExamMerit(percentage).",
      bands: [
        { min: 80, max: 84, meritPoints: 3 },
        { min: 85, max: 89, meritPoints: 4 },
        { min: 90, max: 94, meritPoints: 5 },
        { min: 95, max: 99, meritPoints: 6 },
        { min: 100, max: 100, meritPoints: 8, badge: "Perfect Model Exam Recognition" },
      ],
    },
  ],
  rewardTiers: [
    { points: 5, title: "Small Reward", examples: ["Short earned leisure period", "Choice of a permitted hobby activity"] },
    { points: 10, title: "Standard Reward", examples: ["Extended leisure privilege", "Choose a permitted weekend activity"] },
    { points: 20, title: "Major Reward", examples: ["Larger earned entertainment window", "Special hobby privilege"] },
    { points: 30, title: "Achievement Reward", examples: ["Special planned reward", "Recognition in the handbook's achievement record"] },
  ],
  rules: [
    "RULE 1 — No award for something that is already a requirement after a breach: work completed only after a punishment/recovery protocol was activated does not automatically earn a normal completion award.",
    "RULE 2 — No double counting: one achievement cannot be repeatedly counted as different awards unless it genuinely satisfies separate criteria.",
    "RULE 3 — Awards never cancel penalties: Merit Points cannot erase an already-triggered disciplinary consequence.",
    "RULE 4 — Awards are earned, not expected: no award is automatic merely because the student wants a reward.",
    "RULE 5 — 80% remains the academic floor: awards can recognize improvement below 80%, but the standard remains 80% or higher.",
  ],
  commandment: "DO THE WORK. DO IT ON TIME. DO IT PROPERLY. BUILD THE STREAK. EARN THE MERIT.",
};

// ---------------------------------------------------------------------------
// LEVEL 2 — DISTINCTION AWARDS
// ---------------------------------------------------------------------------
const LEVEL_2 = {
  level: 2,
  title: "Distinction",
  purpose: "Recognize repeated achievement — good performance becoming a consistent standard rather than a one-time result.",
  categories: [
    {
      id: "l2_performance_streaks",
      title: "Academic Performance Streaks",
      awards: [
        { id: "streak_3_80", title: "3-Assessment Streak", requirement: "80%+ on 3 consecutive comparable assessments.",
          requirements: [{ key: "streakCount", op: "gte", value: 3 }, { key: "streakMinScore", op: "gte", value: 80 }], meritPoints: 8, badge: "Distinction Streak I" },
        { id: "streak_5_80", title: "5-Assessment Streak", requirement: "80%+ on 5 consecutive comparable assessments.",
          requirements: [{ key: "streakCount", op: "gte", value: 5 }, { key: "streakMinScore", op: "gte", value: 80 }], meritPoints: 12, badge: "Distinction Streak II" },
        { id: "streak_3_90", title: "3-Assessment Excellence Streak", requirement: "90%+ on 3 consecutive assessments.",
          requirements: [{ key: "streakCount", op: "gte", value: 3 }, { key: "streakMinScore", op: "gte", value: 90 }], meritPoints: 15, badge: "Excellence Streak Recognition" },
      ],
    },
    {
      id: "l2_ca_distinction",
      title: "Continuous-Assessment Distinction",
      awards: [
        { id: "complete_ca_distinction", title: "Complete-CA Distinction",
          requirement: "For one assessment period: quizzes, classwork, homework, group work, participation, practical work, assignments, projects, field work all completed, AND CA performance ≥80%.",
          requirements: [{ key: "allCaComponentsCompleted", op: "true" }, { key: "caResult", op: "gte", value: 80 }],
          meritPoints: 15, badge: "30% Distinction Badge" },
        { id: "zero_missing_work_streak_30", title: "Zero-Missing-Work Streak", requirement: "30 consecutive days without a missed required academic task.",
          requirements: [{ key: "streakDays", op: "gte", value: 30 }], meritPoints: 10 },
      ],
    },
    {
      id: "l2_subject_distinction",
      title: "Subject Distinction",
      awards: [
        { id: "subject_80_streak3", title: "Subject 80", requirement: "80%+ in one subject across 3 consecutive assessments.",
          requirements: [{ key: "subjectStreakCount", op: "gte", value: 3 }, { key: "subjectStreakMinScore", op: "gte", value: 80 }], meritPoints: 8 },
        { id: "subject_excellence_streak3", title: "Subject Excellence", requirement: "90%+ in one subject across 3 consecutive assessments.",
          requirements: [{ key: "subjectStreakCount", op: "gte", value: 3 }, { key: "subjectStreakMinScore", op: "gte", value: 90 }], meritPoints: 12 },
        { id: "five_subject_distinction", title: "Five-Subject Distinction",
          requirement: "80%+ across all five entrance subjects (Mathematics, English, Biology, Chemistry, Physics) during the same assessment period.",
          requirements: [{ key: "allFiveSubjectsMin", op: "gte", value: 80 }, { key: "samePeriod", op: "true" }], meritPoints: 15 },
      ],
    },
    {
      id: "l2_model_exam_distinction",
      title: "Model Exam Distinction",
      awards: [
        { id: "model_streak_2_80", title: "2-Model Streak", requirement: "Two consecutive model exams at 80%+.",
          requirements: [{ key: "modelStreakCount", op: "gte", value: 2 }, { key: "modelStreakMinScore", op: "gte", value: 80 }], meritPoints: 10 },
        { id: "model_streak_3_80", title: "3-Model Streak", requirement: "Three consecutive model exams at 80%+.",
          requirements: [{ key: "modelStreakCount", op: "gte", value: 3 }, { key: "modelStreakMinScore", op: "gte", value: 80 }], meritPoints: 15 },
        { id: "model_streak_5_80", title: "5-Model Streak", requirement: "Five consecutive model exams at 80%+.",
          requirements: [{ key: "modelStreakCount", op: "gte", value: 5 }, { key: "modelStreakMinScore", op: "gte", value: 80 }], meritPoints: 25, badge: "Model Exam Distinction Badge" },
      ],
    },
    {
      id: "l2_comeback_distinction",
      title: "Comeback Distinction",
      awards: [
        { id: "comeback_10pt", title: "10-Point Comeback", requirement: "Improve by 10+ percentage points and reach at least 80%.",
          requirements: [{ key: "improvementPercentagePoints", op: "gte", value: 10 }, { key: "reachedScore", op: "gte", value: 80 }], meritPoints: 10 },
        { id: "comeback_15pt", title: "15-Point Comeback", requirement: "Improve by 15+ percentage points and reach at least 80%.",
          requirements: [{ key: "improvementPercentagePoints", op: "gte", value: 15 }, { key: "reachedScore", op: "gte", value: 80 }], meritPoints: 15 },
        { id: "major_comeback_l2", title: "Major Comeback", requirement: "Recover from a result of 60% or below and subsequently achieve 80%+.",
          requirements: [{ key: "priorResult", op: "lte", value: 60 }, { key: "reachedScore", op: "gte", value: 80 }],
          meritPoints: 20, badge: "Major Comeback Recognition" },
      ],
    },
    {
      id: "l2_discipline_streak",
      title: "Discipline Streak",
      awards: [
        { id: "discipline_streak_14", title: "14-Day Discipline Streak",
          requirement: "Required study schedule followed; no deliberate academic avoidance; assignments current; no unnecessary academic backlog; required recovery work completed.",
          requirements: [
            { key: "streakDays", op: "gte", value: 14 },
            { key: "noDeliberateAvoidance", op: "true" },
            { key: "assignmentsCurrent", op: "true" },
            { key: "noUnnecessaryBacklog", op: "true" },
            { key: "recoveryWorkCompleted", op: "true" },
          ], meritPoints: 15 },
        { id: "discipline_streak_30", title: "30-Day Discipline Streak", requirement: "Same conditions sustained for 30 consecutive days.",
          requirements: [{ key: "streakDays", op: "gte", value: 30 }], meritPoints: 25, badge: "Discipline Distinction" },
      ],
    },
    {
      id: "l2_early_preparation",
      title: "Early Preparation",
      awards: [
        { id: "assessment_ready", title: "Assessment Ready", requirement: "Planned revision completed before the final preparation window, with practice questions and error correction completed.",
          requirements: [{ key: "revisionCompletedEarly", op: "true" }], meritPoints: 5 },
        { id: "exam_readiness_l2", title: "Exam Readiness", requirement: "Before a major examination: syllabus reviewed, weak topics identified, Error Notebook reviewed, practice completed, no academic backlog.",
          requirements: [
            { key: "syllabusReviewed", op: "true" }, { key: "weakTopicsIdentified", op: "true" },
            { key: "errorNotebookReviewed", op: "true" }, { key: "practiceCompleted", op: "true" }, { key: "noAcademicBacklog", op: "true" },
          ], meritPoints: 10 },
      ],
    },
  ],
  rewardTiers: [
    { points: 10, title: "Distinction Reward", examples: ["Extended permitted leisure period", "Choice of a permitted hobby"] },
    { points: 20, title: "Advanced Reward", examples: ["Larger earned leisure privilege", "Choice of a weekend activity"] },
    { points: 40, title: "Major Distinction Reward", examples: ["Special planned reward", "Achievement recorded in the handbook"] },
    { points: 60, title: "Elite Distinction Reward", examples: ["Major milestone privilege", "Formal recognition in the achievement record"] },
  ],
  rules: [
    "Level 2 rewards cannot be farmed through endless small tasks — the point is consistency over time.",
    "PROTECTION 1 — A streak must be real: a deliberate violation that invalidates the relevant criterion ends that particular streak.",
    "PROTECTION 2 — Failure does not erase all progress: a single ordinary mistake does not destroy unrelated achievements.",
    "PROTECTION 3 — Awards do not buy their way out of discipline: Merit Points cannot cancel an already-triggered punishment.",
    "PROTECTION 4 — 80% remains the floor: the objective is to make 80%+ normal, not just occasional.",
    "PROTECTION 5 — Higher performance earns higher recognition: 80% is the minimum, 90%+ is excellence, 95%+ is exceptional.",
  ],
  commandment: "ONE GOOD RESULT IS ACHIEVEMENT. REPEATED GOOD RESULTS ARE DISTINCTION. CONSISTENCY IS THE REAL AWARD.",
};

// ---------------------------------------------------------------------------
// LEVEL 3 — EXCELLENCE AWARDS
// ---------------------------------------------------------------------------
const LEVEL_3 = {
  level: 3,
  title: "Excellence",
  purpose: "Recognize students consistently performing above the 80% standard while maintaining discipline across the entire academic system.",
  categories: [
    {
      id: "l3_sustained_excellence",
      title: "Sustained Academic Excellence",
      awards: [
        { id: "excellence_streak_5_90", title: "5-Assessment Excellence Streak", requirement: "90%+ on 5 consecutive comparable assessments.",
          requirements: [{ key: "streakCount", op: "gte", value: 5 }, { key: "streakMinScore", op: "gte", value: 90 }], meritPoints: 20, badge: "Excellence Streak I" },
        { id: "excellence_streak_10_90", title: "10-Assessment Excellence Streak", requirement: "90%+ on 10 consecutive comparable assessments.",
          requirements: [{ key: "streakCount", op: "gte", value: 10 }, { key: "streakMinScore", op: "gte", value: 90 }], meritPoints: 35, badge: "Excellence Streak II" },
        { id: "elite_streak_5_95", title: "5-Assessment Elite Streak", requirement: "95%+ on 5 consecutive comparable assessments.",
          requirements: [{ key: "streakCount", op: "gte", value: 5 }, { key: "streakMinScore", op: "gte", value: 95 }], meritPoints: 40, badge: "Elite Performance Recognition" },
      ],
    },
    {
      id: "l3_overall_excellence",
      title: "Overall Academic Excellence",
      awards: [
        { id: "period_85", title: "85%+ Period Award", requirement: "Overall academic result of 85%+ for the defined assessment period.",
          requirements: [{ key: "overallResult", op: "gte", value: 85 }], meritPoints: 20 },
        { id: "period_90", title: "90%+ Period Award", requirement: "Overall academic result of 90%+.",
          requirements: [{ key: "overallResult", op: "gte", value: 90 }], meritPoints: 30, badge: "Academic Excellence Recognition" },
        { id: "period_95", title: "95%+ Period Award", requirement: "Overall academic result of 95%+.",
          requirements: [{ key: "overallResult", op: "gte", value: 95 }], meritPoints: 45, badge: "Exceptional Performance Recognition" },
      ],
    },
    {
      id: "l3_five_subject_excellence",
      title: "Five-Subject Excellence",
      awards: [
        { id: "five_subject_90", title: "Five-Subject 90", requirement: "90%+ in all five entrance subjects during the same assessment period.",
          requirements: [{ key: "allFiveSubjectsMin", op: "gte", value: 90 }], meritPoints: 30 },
        { id: "five_subject_95", title: "Five-Subject 95", requirement: "95%+ in all five subjects.",
          requirements: [{ key: "allFiveSubjectsMin", op: "gte", value: 95 }], meritPoints: 50, badge: "Five-Subject Excellence" },
      ],
    },
    {
      id: "l3_model_exam_excellence",
      title: "12 Model Exam Excellence",
      awards: [
        { id: "model_streak3_90", title: "3-Model 90+ Streak", requirement: "90%+ on 3 consecutive model exams.",
          requirements: [{ key: "modelStreakCount", op: "gte", value: 3 }, { key: "modelStreakMinScore", op: "gte", value: 90 }], meritPoints: 25 },
        { id: "model_streak5_90", title: "5-Model 90+ Streak", requirement: "90%+ on 5 consecutive model exams.",
          requirements: [{ key: "modelStreakCount", op: "gte", value: 5 }, { key: "modelStreakMinScore", op: "gte", value: 90 }], meritPoints: 40 },
        { id: "model_10of10_80", title: "10-Model 80+ Streak", requirement: "80%+ on 10 of the first 10 model examinations.",
          requirements: [{ key: "modelsAtOrAbove80", op: "gte", value: 10 }], meritPoints: 50, badge: "Model Examination Excellence" },
        { id: "model_12_mastery_90avg", title: "12-Model Mastery", requirement: "All 12 model examinations completed with an overall average of 90%+.",
          requirements: [{ key: "modelsCompleted", op: "gte", value: 12 }, { key: "modelAverage", op: "gte", value: 90 }],
          meritPoints: 75, badge: "12-Model Mastery Award" },
      ],
    },
    {
      id: "l3_ca_excellence",
      title: "Continuous-Assessment Excellence",
      awards: [
        { id: "ca_excellence_90", title: "CA Excellence", requirement: "90%+ across continuous-assessment components for the defined period.",
          requirements: [{ key: "caResult", op: "gte", value: 90 }], meritPoints: 25 },
        { id: "perfect_completion", title: "Perfect Completion",
          requirement: "No missed quizzes/classwork/homework; group responsibilities, participation, practical work, assignments, projects, field work all completed; AND CA result ≥90%.",
          requirements: [{ key: "allCaComponentsCompleted", op: "true" }, { key: "caResult", op: "gte", value: 90 }],
          meritPoints: 30, badge: "Continuous Assessment Excellence" },
      ],
    },
    {
      id: "l3_discipline_excellence",
      title: "Discipline Excellence",
      awards: [
        { id: "discipline_30day_l3", title: "30-Day Discipline Streak",
          requirement: "Schedule maintained; academic work current; no deliberate avoidance; required recovery work completed; no unnecessary academic backlog.",
          requirements: [
            { key: "streakDays", op: "gte", value: 30 }, { key: "noDeliberateAvoidance", op: "true" },
            { key: "recoveryWorkCompleted", op: "true" }, { key: "noUnnecessaryBacklog", op: "true" },
          ], meritPoints: 30 },
        { id: "discipline_60day_l3", title: "60-Day Discipline Streak", requirement: "Same conditions sustained for 60 consecutive days.",
          requirements: [{ key: "streakDays", op: "gte", value: 60 }], meritPoints: 50, badge: "60-Day Discipline Excellence" },
        { id: "discipline_90day_l3", title: "90-Day Discipline Streak", requirement: "Same conditions sustained for 90 consecutive days.",
          requirements: [{ key: "streakDays", op: "gte", value: 90 }], meritPoints: 75, badge: "90-Day Discipline Excellence" },
      ],
    },
    {
      id: "l3_comeback_excellence",
      title: "Comeback Excellence",
      awards: [
        { id: "major_recovery_l3", title: "Major Recovery", requirement: "Recover from ≤60% to 90%+ on a later comparable assessment.",
          requirements: [{ key: "priorResult", op: "lte", value: 60 }, { key: "reachedScore", op: "gte", value: 90 }], meritPoints: 30 },
        { id: "double_recovery", title: "Double Recovery", requirement: "Recover from two separate below-standard results and return to 90%+.",
          requirements: [{ key: "separateRecoveries", op: "gte", value: 2 }, { key: "reachedScore", op: "gte", value: 90 }], meritPoints: 45 },
        { id: "complete_academic_comeback", title: "Complete Academic Comeback",
          requirement: "After entering a major academic recovery protocol: backlog cleared, weak topics corrected, subsequent assessments reach 90%+, discipline maintained.",
          requirements: [
            { key: "backlogCleared", op: "true" }, { key: "weakTopicsCorrected", op: "true" },
            { key: "reachedScore", op: "gte", value: 90 }, { key: "disciplineMaintained", op: "true" },
          ], meritPoints: 60, badge: "Academic Comeback Excellence" },
      ],
    },
    {
      id: "l3_exam_readiness",
      title: "Exam Readiness Excellence",
      awards: [
        { id: "readiness_checklist_l3", title: "Readiness Checklist Complete",
          requirement: "Before a major examination: syllabus coverage, Error Notebook review, practice examinations, weak-topic correction, current assignments, no academic backlog, multiple revision cycles — all completed.",
          requirements: [
            { key: "syllabusCovered", op: "true" }, { key: "errorNotebookReviewed", op: "true" }, { key: "practiceExamsCompleted", op: "true" },
            { key: "weakTopicsCorrected", op: "true" }, { key: "assignmentsCurrent", op: "true" },
            { key: "noAcademicBacklog", op: "true" }, { key: "multipleRevisionCycles", op: "true" },
          ], meritPoints: 20 },
        { id: "readiness_plus_90_l3", title: "Readiness + 90%+ Result",
          requirement: "readiness_checklist_l3 satisfied AND the subsequent examination result reaches 90%+.",
          requirements: [{ key: "readinessChecklistComplete", op: "true" }, { key: "examResult", op: "gte", value: 90 }], meritPoints: 25 },
      ],
    },
  ],
  rewardTiers: [
    { points: 25, title: "Excellence Reward" },
    { points: 50, title: "Major Excellence Reward" },
    { points: 75, title: "Elite Privilege Reward" },
    { points: 100, title: "Excellence Milestone", examples: ["A major achievement may be selected from the approved reward list."] },
  ],
  advancementStandard: "To be considered for Level 4: academic excellence + discipline + consistency + recovery ability. A single 95% score is excellent — Level 3 asks whether you can maintain excellence.",
  commandment: "MEETING THE STANDARD IS MERIT. REPEATING THE STANDARD IS DISTINCTION. SURPASSING THE STANDARD CONSISTENTLY IS EXCELLENCE.",
};

// ---------------------------------------------------------------------------
// LEVEL 4 — HONOR AWARDS
// ---------------------------------------------------------------------------
const LEVEL_4 = {
  level: 4,
  title: "Honor",
  purpose: "Recognize exceptional sustained performance across multiple areas of academic life — awards become substantially harder to earn.",
  categories: [
    {
      id: "l4_year_long_honor",
      title: "Year-Long Academic Honor",
      awards: [
        { id: "yearly_90", title: "90% Yearly Performance",
          requirement: "Overall academic performance of 90%+ across the defined yearly assessment period, including continuous assessments, mid-semester and final examination.",
          requirements: [{ key: "yearlyOverallResult", op: "gte", value: 90 }], meritPoints: 75, badge: "Academic Honor I" },
        { id: "yearly_95", title: "95% Yearly Performance", requirement: "Overall yearly result of 95%+.",
          requirements: [{ key: "yearlyOverallResult", op: "gte", value: 95 }], meritPoints: 100, badge: "Academic Honor II" },
      ],
    },
    {
      id: "l4_complete_assessment_honor",
      title: "Complete Assessment Honor",
      awards: [
        { id: "complete_assessment_honor", title: "Complete Assessment Honor",
          requirement: "30% Continuous Assessment ≥90%, 20% Mid-Semester ≥90%, 50% Final ≥90%, AND overall ≥90%.",
          requirements: [
            { key: "caResult", op: "gte", value: 90 }, { key: "midSemesterResult", op: "gte", value: 90 },
            { key: "finalResult", op: "gte", value: 90 }, { key: "overallResult", op: "gte", value: 90 },
          ], meritPoints: 100, badge: "Complete Assessment Honor",
          notes: "Deliberately difficult — requires consistent performance across all three major grading components." },
      ],
    },
    {
      id: "l4_five_subject_honor",
      title: "Five-Subject Honor",
      awards: [
        { id: "five_subject_90_honor", title: "Five-Subject 90 Honor", requirement: "90%+ in all five subjects across the defined assessment period.",
          requirements: [{ key: "allFiveSubjectsMin", op: "gte", value: 90 }], meritPoints: 75 },
        { id: "five_subject_95_honor", title: "Five-Subject 95 Honor", requirement: "95%+ in all five subjects.",
          requirements: [{ key: "allFiveSubjectsMin", op: "gte", value: 95 }], meritPoints: 125, badge: "Five-Subject Academic Honor" },
      ],
    },
    {
      id: "l4_model_exam_honor",
      title: "12 Model Exam Honor",
      awards: [
        { id: "model_12_80_honor", title: "12-Model 80+ Honor", requirement: "All 12 model exams with every model ≥80% and overall average ≥85%.",
          requirements: [{ key: "modelsCompleted", op: "gte", value: 12 }, { key: "everyModelMin", op: "gte", value: 80 }, { key: "modelAverage", op: "gte", value: 85 }],
          meritPoints: 100, badge: "Model Examination Honor" },
        { id: "model_12_90_honor", title: "12-Model 90+ Honor", requirement: "All 12 model exams with every model ≥90% and overall average ≥90%.",
          requirements: [{ key: "modelsCompleted", op: "gte", value: 12 }, { key: "everyModelMin", op: "gte", value: 90 }, { key: "modelAverage", op: "gte", value: 90 }],
          meritPoints: 150, badge: "Model Examination Excellence Honor" },
      ],
    },
    {
      id: "l4_ca_honor",
      title: "Continuous-Assessment Honor",
      awards: [
        { id: "ca_honor", title: "30% Assessment Honor",
          requirement: "Quizzes, classwork, homework, group work, participation, practical work, assignments, projects, field work all consistently completed throughout the period, AND CA ≥90%.",
          requirements: [{ key: "allCaComponentsCompleted", op: "true" }, { key: "caResult", op: "gte", value: 90 }],
          meritPoints: 75, badge: "30% Assessment Honor" },
      ],
    },
    {
      id: "l4_discipline_honor",
      title: "Discipline Honor",
      awards: [
        { id: "discipline_90day_honor", title: "90-Day Discipline Streak",
          requirement: "Study schedule consistently followed; no deliberate academic avoidance; no unnecessary backlog; required assignments completed; recovery protocols followed when necessary; academic priorities maintained.",
          requirements: [
            { key: "streakDays", op: "gte", value: 90 }, { key: "noDeliberateAvoidance", op: "true" },
            { key: "noUnnecessaryBacklog", op: "true" }, { key: "recoveryProtocolsFollowed", op: "true" },
          ], meritPoints: 75 },
        { id: "discipline_180day_honor", title: "180-Day Discipline Streak", requirement: "Same conditions sustained for 180 consecutive days.",
          requirements: [{ key: "streakDays", op: "gte", value: 180 }], meritPoints: 125, badge: "Long-Term Discipline Honor" },
      ],
    },
    {
      id: "l4_comeback_honor",
      title: "Academic Comeback Honor",
      awards: [
        { id: "crisis_to_excellence", title: "From Critical Failure to Excellence",
          requirement: "Previously reached 60% or below, entered recovery, eventually achieved 90%+, and maintained the standard afterward.",
          requirements: [{ key: "priorResult", op: "lte", value: 60 }, { key: "reachedScore", op: "gte", value: 90 }, { key: "standardMaintained", op: "true" }],
          meritPoints: 100, badge: "Major Comeback Honor" },
        { id: "multiple_failures_to_honor", title: "From Multiple Failures to Honor",
          requirement: "Recover from repeated below-standard results and establish 90%+ sustained performance with no unresolved academic backlog.",
          requirements: [{ key: "repeatedFailuresRecovered", op: "true" }, { key: "reachedScore", op: "gte", value: 90 }, { key: "noUnresolvedBacklog", op: "true" }],
          meritPoints: 150, badge: "Complete Recovery Honor" },
      ],
    },
    {
      id: "l4_exam_readiness_honor",
      title: "Examination Readiness Honor",
      awards: [
        { id: "exam_readiness_honor", title: "Examination Readiness Honor",
          requirement: "Full syllabus reviewed, weak topics corrected, Error Notebook completed, practice examinations completed, assignments current, no academic backlog, revision completed ahead of schedule, AND the actual examination result reaches 90%+.",
          requirements: [
            { key: "syllabusReviewed", op: "true" }, { key: "weakTopicsCorrected", op: "true" }, { key: "errorNotebookCompleted", op: "true" },
            { key: "practiceExamsCompleted", op: "true" }, { key: "assignmentsCurrent", op: "true" },
            { key: "noAcademicBacklog", op: "true" }, { key: "revisionAheadOfSchedule", op: "true" },
            { key: "examResult", op: "gte", value: 90 },
          ], meritPoints: 75 },
      ],
    },
  ],
  rewardTiers: [
    { points: 50, title: "Honor Privilege" },
    { points: 100, title: "Major Honor Reward" },
    { points: 150, title: "High Honor Reward" },
    { points: 250, title: "Distinguished Achievement", examples: ["A major approved reward or privilege may be selected."] },
  ],
  specialRule: "Level 4 awards are not meant to be farmed — a student cannot repeatedly collect large rewards by splitting one achievement into multiple artificial awards. The same achievement may contribute to multiple records only when it genuinely satisfies different categories, and the handbook must record the achievement transparently.",
  advancementStandard: "Level 5 is reserved for achievements demonstrating an exceptional overall academic record, not one excellent examination. Academic performance + continuous assessment + examination performance + entrance preparation + discipline must all demonstrate sustained excellence.",
  commandment: "MERIT RECOGNIZES THE ACTION. DISTINCTION RECOGNIZES THE STREAK. EXCELLENCE RECOGNIZES THE PERFORMANCE. HONOR RECOGNIZES THE RECORD.",
};

// ---------------------------------------------------------------------------
// LEVEL 5 — ELITE / HIGHEST HONOR AWARDS
// ---------------------------------------------------------------------------
const LEVEL_5 = {
  level: 5,
  title: "Elite Honor",
  purpose: "The highest recognition in the handbook — the combination of academic excellence, consistency, discipline, recovery, examination performance, and entrance preparation. Should be rare, difficult, and meaningful.",
  categories: [
    {
      id: "l5_academic_elite",
      title: "Academic Elite",
      awards: [
        { id: "yearly_elite_95", title: "95%+ Yearly Elite",
          requirement: "Overall yearly academic result ≥95% across the complete school grading system (30% Continuous Assessment + 20% Mid-Semester + 50% Final Examination).",
          requirements: [{ key: "yearlyOverallResult", op: "gte", value: 95 }], meritPoints: 200, badge: "Academic Elite Honor" },
        { id: "exceptional_98", title: "98%+ Exceptional Performance", requirement: "Overall yearly result ≥98%. Should be extremely rare.",
          requirements: [{ key: "yearlyOverallResult", op: "gte", value: 98 }], meritPoints: 300, badge: "Exceptional Academic Honor" },
      ],
    },
    {
      id: "l5_system_mastery",
      title: "Complete 100% System Mastery",
      awards: [
        { id: "system_mastery", title: "Complete Academic Mastery",
          requirement: "Continuous Assessment (30%) ≥95%, Mid-Semester (20%) ≥95%, Final Examination (50%) ≥95%, AND overall result ≥95%.",
          requirements: [
            { key: "caResult", op: "gte", value: 95 }, { key: "midSemesterResult", op: "gte", value: 95 },
            { key: "finalResult", op: "gte", value: 95 }, { key: "overallResult", op: "gte", value: 95 },
          ], meritPoints: 300, badge: "Complete Academic Mastery" },
      ],
    },
    {
      id: "l5_five_subject_elite",
      title: "Five-Subject Elite",
      awards: [
        { id: "five_subject_95_elite", title: "Five-Subject 95 Elite", requirement: "≥95% in all five subjects during the defined assessment period.",
          requirements: [{ key: "allFiveSubjectsMin", op: "gte", value: 95 }], meritPoints: 200, badge: "Five-Subject Elite Honor" },
        { id: "five_subject_consistency_elite", title: "Five-Subject Consistency Elite",
          requirement: "≥90% in all five subjects across multiple consecutive assessment periods.",
          requirements: [{ key: "allFiveSubjectsMin", op: "gte", value: 90 }, { key: "consecutivePeriods", op: "gte", value: 2 }],
          meritPoints: 250, badge: "Five-Subject Consistency Honor" },
      ],
    },
    {
      id: "l5_model_exam_elite",
      title: "12-Model Exam Elite",
      awards: [
        { id: "model_12_90_elite", title: "12-Model 90+ Elite", requirement: "All 12 model exams with every model ≥90% and overall average ≥90%.",
          requirements: [{ key: "modelsCompleted", op: "gte", value: 12 }, { key: "everyModelMin", op: "gte", value: 90 }, { key: "modelAverage", op: "gte", value: 90 }],
          meritPoints: 250, badge: "12-Model Elite Honor" },
        { id: "model_12_95_elite", title: "12-Model 95+ Elite", requirement: "All 12 model exams with every model ≥95% and overall average ≥95%.",
          requirements: [{ key: "modelsCompleted", op: "gte", value: 12 }, { key: "everyModelMin", op: "gte", value: 95 }, { key: "modelAverage", op: "gte", value: 95 }],
          meritPoints: 350, badge: "12-Model Mastery" },
      ],
    },
    {
      id: "l5_entrance_exam_elite",
      title: "Entrance Exam Elite",
      note: "The five entrance subjects, evaluated against the official 600-point entrance-exam scale where applicable.",
      awards: [
        { id: "model_to_exam_elite", title: "Model-to-Exam Elite",
          requirement: "Sustained ≥90% performance across the 12 model examinations, followed by an exceptional official entrance-exam result.",
          requirements: [{ key: "modelAverage", op: "gte", value: 90 }, { key: "exceptionalEntranceResult", op: "true" }],
          meritPoints: 500 },
        { id: "entrance_exam_elite", title: "Entrance Exam Elite",
          requirement: "PENDING — the exact score threshold should be set once the official entrance-exam scoring and competitive target are confirmed, rather than an invented cutoff.",
          requirements: [], meritPoints: null,
          notes: "Do not auto-grant this award; the threshold is intentionally undefined until the real entrance-exam scoring/target is known." },
      ],
    },
    {
      id: "l5_discipline_elite",
      title: "Perfect Discipline Elite",
      awards: [
        { id: "discipline_180_elite", title: "180-Day Discipline Elite",
          requirement: "For 180 consecutive days: required academic schedule maintained, assignments current, no deliberate academic avoidance, recovery requirements followed when triggered, study priorities maintained, unnecessary distractions under control.",
          requirements: [
            { key: "streakDays", op: "gte", value: 180 }, { key: "noDeliberateAvoidance", op: "true" },
            { key: "recoveryRequirementsFollowed", op: "true" }, { key: "distractionsUnderControl", op: "true" },
          ], meritPoints: 200, badge: "180-Day Discipline Elite" },
        { id: "full_year_discipline_elite", title: "Full-Year Discipline Elite",
          requirement: "The discipline system was maintained for the defined academic year without a systemic collapse requiring Degree 5.",
          requirements: [{ key: "fullYearMaintained", op: "true" }, { key: "noDegree5Collapse", op: "true" }],
          meritPoints: 350, badge: "Full-Year Discipline Honor" },
      ],
    },
    {
      id: "l5_ultimate_comeback",
      title: "Ultimate Comeback",
      note: "Different from the performance-based awards — a student does not need to start at the top to earn the highest recognition.",
      awards: [
        { id: "phoenix_award", title: "The Phoenix Award — Complete Academic Rebirth",
          requirement: "A serious academic decline is followed by entering the higher recovery degrees, clearing the academic backlog, correcting the underlying weaknesses, returning to ≥80%, eventually reaching ≥90%, maintaining the improvement, and successfully resuming model-exam preparation.",
          requirements: [
            { key: "seriousDeclineOccurred", op: "true" }, { key: "higherRecoveryDegreesEntered", op: "true" },
            { key: "backlogCleared", op: "true" }, { key: "underlyingWeaknessesCorrected", op: "true" },
            { key: "returnedTo80", op: "true" }, { key: "reached90", op: "true" },
            { key: "improvementMaintained", op: "true" }, { key: "modelExamPrepResumed", op: "true" },
          ], meritPoints: 300, badge: "Phoenix — Complete Academic Rebirth",
          notes: "Recognizes recovery through discipline, not failure itself." },
      ],
    },
    {
      id: "l5_complete_academic_year",
      title: "The Complete Academic Year",
      note: "The highest school-based award.",
      awards: [
        { id: "grand_academic_honor", title: "The Grand Academic Honor",
          requirement: "Across the complete academic year: CA ≥90%, Mid-Semester ≥90%, Final ≥90%, Overall ≥90%; all 12 model exams completed; entrance subjects (Mathematics, English, Biology, Chemistry, Physics) maintained at the required preparation standard; no unresolved major academic backlog; assignments consistently completed; projects/practical/field work consistently completed.",
          requirements: [
            { key: "caResult", op: "gte", value: 90 }, { key: "midSemesterResult", op: "gte", value: 90 },
            { key: "finalResult", op: "gte", value: 90 }, { key: "overallResult", op: "gte", value: 90 },
            { key: "modelsCompleted", op: "gte", value: 12 }, { key: "entranceSubjectsAtStandard", op: "true" },
            { key: "noUnresolvedMajorBacklog", op: "true" }, { key: "assignmentsConsistentlyCompleted", op: "true" },
            { key: "projectsPracticalFieldworkCompleted", op: "true" },
          ], meritPoints: 500, badge: "The Grand Academic Honor",
          notes: "This is the highest normal yearly award." },
      ],
    },
  ],
  rewardTiers: [
    { points: 100, title: "Elite Reward" },
    { points: 250, title: "Major Elite Reward" },
    { points: 500, title: "Grand Reward" },
    { points: 1000, title: "Legendary Achievement", examples: ["Represents accumulated excellence across the system rather than one examination."] },
  ],
  ladder: [
    { level: 1, title: "Merit", purpose: "Individual achievement" },
    { level: 2, title: "Distinction", purpose: "Repeated achievement" },
    { level: 3, title: "Excellence", purpose: "Sustained high performance" },
    { level: 4, title: "Honor", purpose: "Exceptional academic record" },
    { level: 5, title: "Elite Honor", purpose: "Extraordinary overall achievement" },
  ],
  finalPrinciple: {
    statement: "The highest reward is not simply the highest score. The system recognizes five things:",
    pillars: [
      "PERFORMANCE — How high did you score?",
      "CONSISTENCY — How long did you maintain it?",
      "DISCIPLINE — Did you follow the system?",
      "RECOVERY — Could you recover when you failed?",
      "PREPARATION — Did you build toward the final and entrance examinations?",
    ],
  },
  commandment: "LEVEL 5 IS NOT ABOUT BEING PERFECT. IT IS ABOUT DEMONSTRATING EXCEPTIONAL MASTERY OF THE ENTIRE SYSTEM.",
};

const LEVELS = Object.freeze([LEVEL_1, LEVEL_2, LEVEL_3, LEVEL_4, LEVEL_5]);

module.exports = { LEVELS, LEVEL_TITLES, LEVEL_1, LEVEL_2, LEVEL_3, LEVEL_4, LEVEL_5 };
