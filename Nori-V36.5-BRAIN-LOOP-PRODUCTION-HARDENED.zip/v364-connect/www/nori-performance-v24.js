/* NORI PERFORMANCE + SMART THINKING V24
   Local-first microcache, deterministic quick answers, compact context and
   a lightweight client-side thinking frame. No network calls are made here.
*/
(function(g){'use strict';
  var CACHE_KEY='nori_perf_v24_cache';
  var MAX=80, TTL=120000;
  function now(){return Date.now()}
  function norm(s){return String(s||'').toLowerCase().replace(/\s+/g,' ').trim()}
  function load(){try{return JSON.parse(localStorage.getItem(CACHE_KEY)||'[]')}catch(e){return []}}
  function save(a){try{localStorage.setItem(CACHE_KEY,JSON.stringify(a.slice(-MAX)))}catch(e){}}
  function get(message,opts){opts=opts||{};if(opts.web||opts.action)return null;var k=norm(message);if(!k)return null;var a=load(), t=now();for(var i=a.length-1;i>=0;i--){if(a[i].k===k){if(t-a[i].at<TTL)return a[i].v;a.splice(i,1);break}}save(a);return null}
  function put(message,value,opts){opts=opts||{};if(opts.web||opts.action||!message||!value)return;var a=load(),k=norm(message);a=a.filter(function(x){return x.k!==k});a.push({k:k,at:now(),v:value});save(a)}
  function quick(message){var t=norm(message), m=t.match(/^(-?\d+(?:\.\d+)?)\s*([+\-*\/])\s*(-?\d+(?:\.\d+)?)\s*\??$/);if(!m)return null;var a=Number(m[1]),b=Number(m[3]);if(m[2]==='/'&&b===0)return null;return String(m[2]==='+'?a+b:m[2]==='-'?a-b:m[2]==='*'?a*b:a/b)}
  function think(message){var t=norm(message), asks=[];if(/\b(why|how|explain|reason|cause)\b/.test(t))asks.push('explain reasoning');if(/\b(compare|versus|vs|difference|better)\b/.test(t))asks.push('compare relevant factors');if(/\b(plan|schedule|study|prepare|priorit)\b/.test(t))asks.push('check constraints and priorities');if(/\b(latest|current|today|recent|search|research|verify)\b/.test(t))asks.push('use current external evidence');if(!asks.length)asks.push('answer directly and avoid unnecessary work');return {goals:asks,localFirst:true,avoidOverthinking:t.length<90}}
  g.NoriPerformanceV24={get:get,put:put,quick:quick,think:think,clear:function(){try{localStorage.removeItem(CACHE_KEY)}catch(e){}}};
})(window);
