/* NORI AVATAR V27 — additive Kage interface evolution.
 * One Nori brain/state, shared memory. Presentation-only layer.
 * No background camera/mic access; visuals are demand-driven and lightweight.
 */
(function(g){'use strict';
  var root=null, face=null, caption=null, board=null, pulse=null, timer=null, visible=true;
  var speechLevel=0, selectedPanel='status';
  var states=['neutral','focused','analytical','concerned','strict','disappointed','encouraging','proud','success','surprised'];
  function esc(v){return String(v==null?'':v).replace(/[&<>"']/g,function(c){return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'})[c]})}
  function clamp(v,a,b){v=Number(v);return Number.isFinite(v)?Math.max(a,Math.min(b,v)):a}
  function make(){
    if(root)return;
    root=document.createElement('section'); root.className='nori-avatar-v27'; root.setAttribute('aria-label','Kage Avatar interface');
    root.innerHTML='<div class="nori-avatar-v27-backdrop"></div><div class="nori-avatar-v27-shell">'+
      '<header class="nori-avatar-v27-head"><div><small>KAGE AVATAR · NORI</small><strong>Educational Presentation</strong></div><div class="nori-avatar-v27-live">CONNECTED TO NORI BRAIN</div><button class="nori-avatar-v27-close" aria-label="Close">×</button></header>'+
      '<main class="nori-avatar-v27-main"><aside class="nori-avatar-v27-panel"><div class="nori-avatar-v27-tabs"><button data-panel="status">STATUS</button><button data-panel="study">STUDY</button><button data-panel="exams">EXAMS</button><button data-panel="trend">TREND</button></div><div id="nori-avatar-v27-board"></div></aside>'+
      '<div class="nori-avatar-v27-stage"><div class="nori-avatar-v27-halo"></div><div class="nori-avatar-v27-scan"></div><img id="nori-avatar-v27-face" alt="Kage avatar"><div class="nori-avatar-v27-speech"></div><button class="nori-avatar-v27-tap" aria-label="Interact with Kage"></button></div></main>'+
      '<footer class="nori-avatar-v27-foot"><div id="nori-avatar-v27-caption"></div><div class="nori-avatar-v27-actions"><button data-action="status">Explain status</button><button data-action="study">Show study</button><button data-action="close">Return</button></div></footer>'+
      '</div>';
    document.body.appendChild(root);
    face=root.querySelector('#nori-avatar-v27-face'); caption=root.querySelector('#nori-avatar-v27-caption'); board=root.querySelector('#nori-avatar-v27-board'); pulse=root.querySelector('.nori-avatar-v27-speech');
    root.querySelector('.nori-avatar-v27-close').onclick=close;
    root.querySelector('.nori-avatar-v27-backdrop').onclick=close;
    root.querySelector('.nori-avatar-v27-tap').onclick=function(){root.classList.remove('tap');void root.offsetWidth;root.classList.add('tap');toggleBoard();};
    root.querySelectorAll('[data-panel]').forEach(function(b){b.onclick=function(){selectedPanel=b.dataset.panel;renderBoard();}});
    root.querySelector('[data-action="status"]').onclick=function(){selectedPanel='status';renderBoard();open('analytical');};
    root.querySelector('[data-action="study"]').onclick=function(){selectedPanel='study';renderBoard();open('focused');};
    root.querySelector('[data-action="close"]').onclick=close;
    setState('neutral'); renderBoard();
  }
  function data(){
    var d={overall:0,subjects:[]};
    try{if(g.NoriRecoveryV26&&typeof g.NoriRecoveryV26.process==='function')d=g.NoriRecoveryV26.process()||d;}catch(e){}
    d.subjects=Array.isArray(d.subjects)?d.subjects:[]; return d;
  }
  function renderBoard(){
    if(!board)return; var d=data(), rows=d.subjects.slice(0,6), overall=clamp(d.overall,0,100);
    root.querySelectorAll('[data-panel]').forEach(function(b){b.classList.toggle('active',b.dataset.panel===selectedPanel);});
    var html='';
    if(selectedPanel==='status') html='<div class="v27-kicker">CURRENT ACADEMIC STATE</div><div class="v27-big">'+Math.round(overall)+'<span>%</span></div><div class="v27-meter"><i style="width:'+overall+'%"></i></div><p>Recorded evidence only. Low-data conclusions remain uncertain.</p>';
    else if(selectedPanel==='study') html='<div class="v27-kicker">STUDY VIEW</div><h3>Subjects in the record</h3>'+subjectRows(rows)+'<p class="v27-note">Use this view to discuss where study attention may be useful; it does not silently change your plan.</p>';
    else if(selectedPanel==='exams') html='<div class="v27-kicker">EXAM VIEW</div><h3>Preparation surface</h3><div class="v27-stat-grid"><div><b>COUNTDOWN</b><strong>—</strong><span>Add an exam date</span></div><div><b>READINESS</b><strong>'+Math.round(overall)+'%</strong><span>Uses recorded results</span></div></div><p>No exam date is invented. When one exists, Kage can present the countdown here.</p>';
    else html='<div class="v27-kicker">TRAJECTORY</div><h3>Personal trend</h3><div class="v27-bars">'+rows.map(function(x){var n=clamp(x.average,0,100);return '<div><span>'+esc(x.subject)+'</span><i><b style="height:'+n+'%"></b></i><strong>'+Math.round(n)+'%</strong></div>';}).join('')+'</div><p>Trend presentation stays tied to the student’s own recorded evidence.</p>';
    board.innerHTML=html;
  }
  function subjectRows(rows){if(!rows.length)return '<div class="v27-empty">No recorded results yet.</div>';return '<div class="v27-subjects">'+rows.map(function(x){var n=clamp(x.average,0,100);return '<div><span>'+esc(x.subject)+'</span><i><b style="width:'+n+'%"></b></i><strong>'+Math.round(n)+'%</strong></div>';}).join('')+'</div>';}
  function toggleBoard(){root.classList.toggle('panel-collapsed');}
  var preloaded={};
  function preloadState(s){if(preloaded[s])return;var im=new Image();im.src='assets/avatar/'+s+'.jpg';preloaded[s]=im;}
  function setState(s){make();s=states.indexOf(s)>=0?s:'neutral';states.forEach(preloadState);preloadState(s);var next='assets/avatar/'+s+'.jpg';if(face.src.indexOf(next)===-1){face.classList.add('switching');setTimeout(function(){face.src=next;face.onload=function(){face.classList.remove('switching');};},20);}face.dataset.state=s;root.dataset.state=s;}
  function open(s){make();root.classList.add('open');root.style.display='block';setState(s||'neutral');renderBoard();}
  function close(){if(root){root.classList.remove('open');root.style.display='none';}stopTalk();}
  function talk(on){make();root.classList.toggle('talking',!!on);if(!on)setSpeechLevel(0);}
  function setSpeechLevel(v){speechLevel=clamp(v,0,1);if(!root)return;root.style.setProperty('--speech',speechLevel.toFixed(3));}
  function stopTalk(){clearInterval(timer);timer=null;talk(false);}
  function explainStatus(){selectedPanel='status';open('analytical');caption.textContent='I can show the recorded academic state and explain what the evidence supports. Nothing is inferred from appearance alone.';talk(true);setTimeout(stopTalk,Math.min(10000,Math.max(3000,caption.textContent.length*55)));}
  function chart(d){selectedPanel='study';make();renderBoard();open('analytical');caption.textContent='Here is the academic presentation from the recorded data.';}
  function setVisible(v){visible=!!v;if(!visible)close();else if(root)root.style.display=root.classList.contains('open')?'block':'none';}
  function setContext(c){make();root.dataset.context=String(c||'general');}
  g.NoriAvatarV26={open:open,close:close,setState:setState,talk:talk,explainStatus:explainStatus,setVisible:setVisible,chart:chart,setSpeechLevel:setSpeechLevel,setContext:setContext,version:'27'};
  g.NoriKageAvatarV27=g.NoriAvatarV26;
})(window);
