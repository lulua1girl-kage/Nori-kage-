/* Private chat gate: sensitive history requires one biometric verification per app process. */
(function(g){'use strict';
 function sensitive(text,intent){var t=String(text||'').toLowerCase(),i=String(intent||'').toLowerCase();if(/private|personal|psycholog|family/.test(i))return true;return /private|personal|family|trauma|abuse|fear|unsafe|mental health|therapy|psychological|confidential|secret|password|medical|relationship/.test(t)}
 function plugin(){return g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.NoriBiometric}
 function status(){var p=plugin();return p?p.status():Promise.resolve({available:false,unlocked:false})}
 function unlock(){var p=plugin();return p?p.authenticate():Promise.reject(new Error('Biometric bridge unavailable'))}
 function open(turn,render){return status().then(function(s){if(!s.available||s.unlocked)return true;if(!s.unlocked)return unlock().then(function(r){if(r&&r.verified){g.__noriSensitiveUnlocked=true;return true}return false}).catch(function(){return false});return true}).then(function(ok){if(ok&&render)render(turn);return ok})}
 g.NoriSensitiveHistory={isSensitive:sensitive,status:status,unlock:unlock,open:open};
})(window);
