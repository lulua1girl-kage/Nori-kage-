/* NORI VOICE ALARM — scheduled briefing layer.
   Additive to Calendar/Notification/Study systems.
   Native Android: schedules a local notification. When Nori is open at the
   alarm time, it also speaks the same contextual briefing. Web: uses a
   foreground timer while the page is open; browser background delivery is
   intentionally not presented as a guaranteed alarm capability.
*/
(function(){
  const KEY='nori_voice_alarms_v1';
  const FIRED='nori_voice_alarm_fired_v1';
  const SESSION='nori_voice_alarm_session_v2';
  const HISTORY='nori_voice_alarm_history_v2';
  function load(k,fb){try{const v=JSON.parse(localStorage.getItem(k)||'null');return v==null?fb:v}catch(e){return fb}}
  function save(k,v){try{return typeof noriSafeWrite==='function'?noriSafeWrite(k,v):(localStorage.setItem(k,JSON.stringify(v)),true)}catch(e){return false}}
  function uid(){return 'alarm_'+Date.now()+'_'+Math.random().toString(36).slice(2,8)}
  function emit(type,payload){try{if(window.NoriEventBusV31)window.NoriEventBusV31.emit(type,payload,{source:'alarm-adapter'});}catch(e){}}

  function alarms(){return load(KEY,[]).filter(a=>a&&a.enabled!==false)}
  function allAlarms(){return load(KEY,[])}
  function relatedEvents(date){
    const out=[];
    const day=String(date).slice(0,10);
    if(window.noriCalendar&&noriCalendar.allOccurrences){
      noriCalendar.allOccurrences(new Date(day+'T00:00:00'),new Date(day+'T23:59:59')).forEach(x=>out.push({kind:x.type||'calendar',title:x.title,time:x.time||''}));
    }
    try{load('nori_exams',[]).filter(x=>x.date===day).forEach(x=>out.push({kind:'exam',title:x.subject+' — '+x.title,time:x.time||''}));}catch(e){}
    try{load('nori_command_assignments',[]).filter(x=>x.status!=='done'&&x.due===day).forEach(x=>out.push({kind:'assignment',title:x.title,time:x.time||''}));}catch(e){}
    try{load('nori_study_sessions',[]).filter(x=>x.status!=='completed'&&x.date===day).forEach(x=>out.push({kind:'study',title:x.subject+' — '+x.topic,time:x.time||''}));}catch(e){}
    const seen={};return out.filter(x=>{const k=x.kind+'|'+x.title+'|'+x.time;if(seen[k])return false;seen[k]=1;return true}).slice(0,8);
  }
  function buildBrief(alarm,when){
    const day=when.toISOString().slice(0,10), rel=relatedEvents(day);
    const prefix=alarm.label||'Nori alarm';
    let text=prefix+'.';
    if(rel.length){text+=' You have '+rel.length+' related event'+(rel.length===1?'':'s')+' today: ';text+=rel.map(x=>x.title+(x.time?' at '+x.time:'')).join('; ')+'.';}
    else text+=' No related events are currently recorded for today.';
    return {text,related:rel};
  }
  async function requestPermission(){
    if(typeof noriReminderRequestPermission!=='function')return false;
    try{return await noriReminderRequestPermission()}catch(e){return false}
  }
  async function ensureAlarmChannel(){
    const p=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.LocalNotifications;
    if(!p||!p.createChannel)return;
    try{await p.createChannel({id:'nori_alarm',name:'Nori Alarms',description:'Nori scheduled alarms',importance:5,sound:'default',vibration:true,lights:true});}catch(e){}
  }
  async function scheduleNative(alarm){
    if(!NORI_IS_NATIVE||typeof noriReminderSchedule!=='function')return null;
    await ensureAlarmChannel();
    const next=nextOccurrence(alarm,new Date()); if(!next)return null;
    const brief=buildBrief(alarm,next);
    const id=await noriReminderSchedule('NORI · '+(alarm.label||'Alarm'),brief.text,next,'nori_alarm');
    alarm.nativeNotificationId=id; alarm.nextAt=next.toISOString();
    return id;
  }
  function nextOccurrence(a,from){
    const base=new Date(String(a.date||new Date().toISOString().slice(0,10))+'T'+(a.time||'08:00')+':00');
    if(isNaN(base))return null;
    const now=new Date(from);
    if(a.repeat==='daily'){while(base<=now)base.setDate(base.getDate()+1);return base}
    if(a.repeat==='weekdays'){while(base<=now||[0,6].includes(base.getDay()))base.setDate(base.getDate()+1);return base}
    if(a.repeat==='weekly'){while(base<=now)base.setDate(base.getDate()+7);return base}
    return base>now?base:null;
  }
  async function add(data){
    const a=Object.assign({id:uid(),label:'Nori alarm',date:new Date().toISOString().slice(0,10),time:'20:00',repeat:'none',enabled:true,createdAt:new Date().toISOString()},data||{});
    const arr=allAlarms();arr.push(a);if(!save(KEY,arr))throw new Error('Could not save alarm.');
    if(NORI_IS_NATIVE){await requestPermission();try{await scheduleNative(a);save(KEY,arr)}catch(e){a.nativeError=e.message;save(KEY,arr)}}
    emit('alarm.created',{alarm:Object.assign({},a)});
    return a;
  }
  async function remove(id){
    const arr=allAlarms(), old=arr.find(x=>x.id===id);if(old&&old.nativeNotificationId&&typeof noriReminderCancel==='function'){try{await noriReminderCancel(old.nativeNotificationId)}catch(e){}}
    save(KEY,arr.filter(x=>x.id!==id));
    emit('alarm.cancelled',{alarm:old||{id}});
  }
  function markFired(key){const f=load(FIRED,{});emit('alarm.fired',{key});f[key]=Date.now();const cutoff=Date.now()-14*86400000;Object.keys(f).forEach(k=>{if(f[k]<cutoff)delete f[k]});save(FIRED,f)}
  function saveSession(v){save(SESSION,v||null)}
  function session(){return load(SESSION,null)}
  function logHistory(e){const h=load(HISTORY,[]);h.push(Object.assign({at:new Date().toISOString()},e));save(HISTORY,h.slice(-100));}
  function timeGreeting(d){const h=d.getHours();return h<12?'Good morning.':h<18?'Good afternoon.':'Good evening.'}
  function alarmReason(a){const x=String(a.label||'').toLowerCase();if(/wake|wake up|morning/.test(x))return 'You told me to wake you.';if(/remind|remember/.test(x))return 'You asked me to remind you.';if(/talk|chat|update/.test(x))return 'You planned to talk or update me.';if(/study|exam|chemistry|physics|biology|math|english|agriculture|web/.test(x))return 'You planned this as part of your academic work.';return 'You asked me to contact you at this time.'}
  function speakSmart(text,done){if(typeof noriBackgroundVoiceSpeak==='function'&&noriBackgroundVoiceAvailable()){return noriBackgroundVoiceSpeak(text).then(done||function(){}).catch(function(){if(typeof noriSpeak==='function')noriSpeak(text,{onEnd:done});});}if(typeof noriSpeak==='function')noriSpeak(text,{onEnd:done});}
  function offerDelay(){const choices=[5,10,15];const msg='You said wait. I can move this alarm by 5, 10, or 15 minutes. Say 5 minutes, 10 minutes, or 15 minutes.';speakSmart(msg);return choices}
  async function rescheduleMinutes(mins){const s=session();if(!s||!s.alarm)return false;const when=new Date(Date.now()+Number(mins)*60000);s.state='RESCHEDULED';s.nextAt=when.toISOString();saveSession(s);logHistory({type:'reschedule',minutes:Number(mins),alarmId:s.alarm.id});if(NORI_IS_NATIVE&&typeof noriReminderSchedule==='function'){await ensureAlarmChannel();try{const id=await noriReminderSchedule('NORI · '+(s.alarm.label||'Alarm'),buildBrief(s.alarm,when).text,when,'nori_alarm');logHistory({type:'native-reschedule',notificationId:id,alarmId:s.alarm.id});}catch(e){logHistory({type:'reschedule-error',message:e.message});}}s.state='WAITING';saveSession(s);return true}
  function handleAlarmSpeech(text){const s=session();if(!s||!s.active)return false;const l=String(text||'').toLowerCase().trim();
    if(/nori (shut down|shutdown|close yourself|close)/.test(l)){s.active=false;s.state='ENDED';saveSession(s);if(typeof noriBackgroundVoiceStop==='function')noriBackgroundVoiceStop();logHistory({type:'ended',reason:'user'});return true;}
    if(/^(wait|hold on|not yet|later)/.test(l)){s.state='WAIT_CHOICE';saveSession(s);offerDelay();return true;}
    if(/(5|five) minutes?/.test(l)&&s.state==='WAIT_CHOICE'){rescheduleMinutes(5);return true;}
    if(/(10|ten) minutes?/.test(l)&&s.state==='WAIT_CHOICE'){rescheduleMinutes(10);return true;}
    if(/(15|fifteen) minutes?/.test(l)&&s.state==='WAIT_CHOICE'){rescheduleMinutes(15);return true;}
    if(/i am busy|i'm busy|busy right now/.test(l)){s.state='BUSY_REVIEW';saveSession(s);speakSmart('Understood. I will reassess the timing against what is scheduled. If this is not time-critical, I can move it. If it is time-critical, I will tell you why before changing it.');return true;}
    if(/(yes|ready|confirm|go ahead|okay|ok)/.test(l)&&s.state==='CONFIRMATION'){s.state='BRIEFING';saveSession(s);const b=buildBrief(s.alarm,new Date());speakSmart('Confirmed. '+b.text+' '+(b.related.length?'I can continue with these items when you are ready.':'There is nothing else scheduled that I know about right now.'),function(){s.state='CONVERSATION';saveSession(s);beginConversation();});return true;}
    if(/(sick|not feeling well|changed my mind|cancel|stop this)/.test(l)){s.state='OVERRIDE_REVIEW';saveSession(s);speakSmart('Context changed. I will not treat the original alarm as automatically binding. You can reschedule or end it. Say wait, cancel, or a new time.');return true;}
    return false;}
  function ringLocal(){try{const AC=window.AudioContext||window.webkitAudioContext;if(!AC)return;const ctx=new AC();let n=0;const beep=()=>{if(n++>=6){setTimeout(()=>ctx.close().catch(()=>{}),50);return;}const o=ctx.createOscillator(),g=ctx.createGain();o.frequency.value=n%2?880:660;g.gain.value=.08;o.connect(g);g.connect(ctx.destination);o.start();o.stop(ctx.currentTime+.35);setTimeout(beep,500)};beep();}catch(e){}}
  async function beginConversation(){const s=session();if(!s||!s.active)return;if(noriBackgroundVoiceAvailable&&noriBackgroundVoiceAvailable())return; if(typeof noriListenOnce!=='function')return;try{const heard=await noriListenOnce();if(!handleAlarmSpeech(heard)){speakSmart('I heard you. Tell me what you want to do with this alarm. Say wait, I am busy, cancel, or a new time.');setTimeout(beginConversation,1200);}}catch(e){}}
  function startAlarmSession(a,now){if(window.NoriInteractivePresence){window.NoriInteractivePresence.open("alarm");window.NoriInteractivePresence.setState("ALARM");}ringLocal();const b=buildBrief(a,now);const s={active:true,state:'RINGING',alarm:a,startedAt:now.toISOString(),related:b.related};saveSession(s);logHistory({type:'ring',alarmId:a.id,related:b.related.length});if(typeof noriNotificationRecord==='function')noriNotificationRecord({type:'alarm',priority:'action',title:'NORI ALARM',body:b.text,source:'voice-alarm',actionHash:'#/alarms'});const text=timeGreeting(now)+' '+alarmReason(a)+' I am contacting you now. '+b.text+' Say “ready” to continue, or “wait” if you need five minutes.';s.state='CONFIRMATION';saveSession(s);speakSmart(text);}
  function dueNow(){
    const now=new Date();const pad=n=>String(n).padStart(2,'0');const localDate=now.getFullYear()+'-'+pad(now.getMonth()+1)+'-'+pad(now.getDate());const localTime=pad(now.getHours())+':'+pad(now.getMinutes());const minute=localDate+'T'+localTime, arr=allAlarms();
    arr.forEach(a=>{if(a.enabled===false||a.time!==localTime)return;const key=a.id+'@'+minute;if(load(FIRED,{})[key])return;
      const d=String(a.date||'');if(a.repeat==='none'&&d!==localDate)return;if(a.repeat!=='none'&&d>localDate)return;
      markFired(key);startAlarmSession(a,now);
    });
  }
  function attachNativeVoice(){if(!noriBackgroundVoiceAvailable||!noriBackgroundVoiceAvailable())return;const p=window.Capacitor&&window.Capacitor.Plugins&&window.Capacitor.Plugins.NoriVoice;if(!p||!p.addListener)return;p.addListener('speech',function(e){handleAlarmSpeech(e&&e.text||'');});}
  setTimeout(attachNativeVoice,500);
  function render(){
    const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});wrap.appendChild(noriRenderCommandHeader(false));wrap.appendChild(noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:'Voice Alarms'}]));
    const card=noriEl('section',{class:'nori-section-card'});const head=noriEl('div',{class:'nori-section-head'});head.appendChild(noriEl('h2',{text:'Nori Voice Alarms'}));head.appendChild(noriEl('span',{class:'nori-state-chip planned',text:NORI_IS_NATIVE?'ANDROID READY':'WEB · OPEN APP'}));card.appendChild(head);
    const intro=noriEl('p',{class:'nori-brief-main',text:'At the alarm time, Nori prepares a short briefing from the events it actually knows about. On Android, a system notification is scheduled; when Nori is open, the briefing is also spoken aloud.'});card.appendChild(intro);
    const form=noriEl('div',{class:'nori-alarm-form'});const date=noriEl('input',{type:'date'}),time=noriEl('input',{type:'time'}),label=noriEl('input',{type:'text',placeholder:'Alarm purpose'}),repeat=noriEl('select',{});[['none','ONCE'],['daily','DAILY'],['weekdays','WEEKDAYS'],['weekly','WEEKLY']].forEach(x=>repeat.appendChild(noriEl('option',{value:x[0],text:x[1]})));date.value=new Date().toISOString().slice(0,10);time.value='20:00';label.value='Study check';[['label','Purpose',label],['date','Date',date],['time','Time',time],['repeat','Repeat',repeat]].forEach(x=>{const b=noriEl('div',{class:'nori-field'});b.appendChild(noriEl('label',{text:x[1]}));b.appendChild(x[2]);form.appendChild(b)});const addBtn=noriEl('button',{class:'nori-btn nori-btn-primary',text:'SET VOICE ALARM'});addBtn.onclick=async()=>{try{await add({label:label.value.trim()||'Nori alarm',date:date.value,time:time.value,repeat:repeat.value});noriRoute()}catch(e){alert(e.message)}};form.appendChild(addBtn);card.appendChild(form);wrap.appendChild(card);
    const list=noriEl('section',{class:'nori-section-card'});list.appendChild(noriEl('div',{class:'nori-section-head'},[noriEl('h2',{text:'Scheduled Alarms'})]));const rows=noriEl('div',{class:'nori-verification-list'});const arr=allAlarms().slice().reverse();if(!arr.length)rows.appendChild(noriEl('div',{class:'nori-command-empty',text:'No alarms set.'}));arr.forEach(a=>{const r=noriEl('div',{class:'nori-verification-row'});const l=noriEl('div',{});l.appendChild(noriEl('strong',{text:a.label}));l.appendChild(noriEl('small',{text:a.date+' · '+a.time+' · '+a.repeat.toUpperCase()}));r.appendChild(l);r.appendChild(noriEl('button',{class:'nori-btn nori-btn-ghost',text:'TEST',onclick:()=>{startAlarmSession(a,new Date());}}));const del=noriEl('button',{class:'nori-btn nori-btn-ghost',text:'DELETE'});del.onclick=async()=>{await remove(a.id);noriRoute()};r.appendChild(del);rows.appendChild(r)});list.appendChild(rows);wrap.appendChild(list);wrap.appendChild(noriBottomNav('profile'));return wrap;
  }
  window.noriVoiceAlarms={alarms,allAlarms,add,remove,relatedEvents,buildBrief,render,handleAlarmSpeech,startAlarmSession,session,history:function(){return load(HISTORY,[])},test:function(){const a={id:uid(),label:'Nori test alarm',date:new Date().toISOString().slice(0,10),time:'',repeat:'none',enabled:true};startAlarmSession(a,new Date());}};window.noriRenderAlarms=render;
  setInterval(dueNow,15000);dueNow();
})();
