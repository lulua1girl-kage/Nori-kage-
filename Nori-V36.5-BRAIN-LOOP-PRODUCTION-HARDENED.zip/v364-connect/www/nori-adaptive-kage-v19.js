/* NORI ADAPTIVE KAGE V19
 * Real-time priority • context awareness • resilient replanning
 * recovery classification • proportional escalation • Human Override audit
 * Local-first. No physical punishment. No silent side effects.
 */
(function(g){'use strict';
  var KEY='nori_adaptive_kage_v19';
  var OVERRIDE_KEY='nori_adaptive_override_log_v19';
  var EVENT_KEY='nori_adaptive_events_v19';
  var defaults={
    school:{enabled:false,start:'08:30',end:'17:00',lateReturnDays:{},lateReturnMinutes:0},
    priorityWeights:{urgency:0.30,importance:0.25,consequence:0.20,feasibility:0.15,time:0.10},
    refreshMs:15000,
    maxPlanMinutes:600
  };
  var cache={at:0,value:null};
  function load(k,d){try{var x=JSON.parse(localStorage.getItem(k)||'null');return x==null?d:x}catch(e){return d}}
  function save(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function cfg(){return Object.assign({},defaults,load(KEY,{}),{school:Object.assign({},defaults.school,(load(KEY,{}).school||{})),priorityWeights:Object.assign({},defaults.priorityWeights,(load(KEY,{}).priorityWeights||{}))})}
  function now(){return new Date()}
  function iso(){return now().toISOString()}
  function uid(p){return p+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7)}
  function clamp(n,a,b){return Math.max(a,Math.min(b,Number(n)||0))}
  function hm(s){var p=String(s||'').split(':').map(Number);return (p[0]||0)*60+(p[1]||0)}
  function minutesNow(d){return d.getHours()*60+d.getMinutes()}
  function dayKey(d){return ['sun','mon','tue','wed','thu','fri','sat'][d.getDay()]}
  function minutesUntil(date){if(!date)return 999;var t=new Date(String(date).length<=10?String(date)+'T23:59:59':String(date));return Math.ceil((t.getTime()-Date.now())/60000)}
  function daysUntil(date){return Math.ceil(minutesUntil(date)/1440)}
  function arr(k){var v=load(k,[]);return Array.isArray(v)?v:[]}
  function state(){try{return typeof noriGetProtectionContext==='function'?noriGetProtectionContext():{mode:'normal'}}catch(e){return {mode:'normal'}}}
  function academic(){try{return g.noriBrainV14&&typeof g.noriBrainV14.academicProfile==='function'?g.noriBrainV14.academicProfile():null}catch(e){return null}}
  function exams(){return arr('nori_exams')}
  function assignments(){try{return typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():arr('nori_command_assignments')}catch(e){return arr('nori_command_assignments')}}
  function sessions(){return arr('nori_study_sessions')}
  function activeSession(){return sessions().find(function(s){return ['active','in_progress','started'].indexOf(s.status)>=0})||null}
  function recentEvents(){return arr(EVENT_KEY).slice(-100)}

  function context(d){
    d=d||now(); var c=cfg(),m=minutesNow(d),day=dayKey(d),school=false,late=false;
    if(c.school.enabled){school=m>=hm(c.school.start)&&m<hm(c.school.end);var lateMin=Number((c.school.lateReturnDays||{})[day]||c.school.lateReturnMinutes||0);late=lateMin>0 && m>=hm(c.school.end) && m<hm(c.school.end)+lateMin;}
    var s=state(),a=activeSession(),exam=exams().filter(function(e){return e.date&&daysUntil(e.date)>=0}).sort(function(x,y){return daysUntil(x.date)-daysUntil(y.date)})[0]||null;
    var as=assignments().filter(function(x){return x.status!=='done' && (x.due||x.deadline||x.date)}).sort(function(x,y){return minutesUntil(x.due||x.deadline||x.date)-minutesUntil(y.due||y.deadline||y.date)})[0]||null;
    var recovery=classifyRecovery();
    var available=availableTime(d,{school:school,lateReturn:late,study:a});
    return {timestamp:d.toISOString(),day:day,schoolDay:school,lateReturn:late,schoolWindow:c.school,mode:s.mode||'normal',recovery:recovery,activeStudy:a?{id:a.id,subject:a.subject||'Academic',topic:a.topic||'',minutes:Number(a.minutes||45)}:null,upcomingExam:exam?{id:exam.id,title:exam.title||'Exam',subject:exam.subject||'Academic',date:exam.date,days:daysUntil(exam.date)}:null,nextAssignment:as?{id:as.id,title:as.title||as.name||'Assignment',subject:as.subject||'Academic',due:as.due||as.deadline||as.date,days:daysUntil(as.due||as.deadline||as.date)}:null,availableMinutes:available};
  }
  function availableTime(d,c){
    if(c&&c.study)return Number(c.study.minutes||45);
    var cfgx=cfg(),m=minutesNow(d||now());
    if(cfgx.school.enabled){var end=hm(cfgx.school.end),lateMin=Number((cfgx.school.lateReturnDays||{})[dayKey(d||now())]||cfgx.school.lateReturnMinutes||0);if(m<end)return Math.max(10,end-m);if(lateMin&&m<end+lateMin)return Math.max(10,end+lateMin-m)}
    var sleepStart=22*60;if(m<sleepStart)return Math.max(10,sleepStart-m);return 30;
  }

  function classifyRecovery(){
    var ev=recentEvents(), ss=sessions(), nowMs=Date.now(), last48=ev.filter(function(e){return nowMs-(Date.parse(e.at)||nowMs)<=172800000});
    var overrides=arr(OVERRIDE_KEY).filter(function(x){return nowMs-(Date.parse(x.at)||nowMs)<=604800000});
    var disruptions=last48.filter(function(e){return e.kind==='contextual_disruption'||e.kind==='capacity_limit'||e.kind==='conflicting_priority'}).length;
    var avoid=last48.filter(function(e){return e.kind==='ordinary_procrastination'||e.kind==='repeated_avoidance'}).length;
    var missed=ss.filter(function(s){return s.status==='planned'&&s.date&&new Date(String(s.date)+'T23:59:59').getTime()<nowMs}).slice(-10).length;
    if(overrides.length||disruptions>0)return {code:'temporary_disruption',label:'Temporary disruption',confidence:'medium',basis:'Recent contextual interruption/override evidence is recorded.'};
    if(last48.some(function(e){return e.kind==='conflicting_priority'}))return {code:'conflicting_priorities',label:'Conflicting priorities',confidence:'medium',basis:'Competing obligations were recorded.'};
    if(last48.some(function(e){return e.kind==='capacity_limit'}))return {code:'capacity_limitation',label:'Capacity limitation',confidence:'medium',basis:'Reduced available capacity was recorded.'};
    if(avoid>=3||missed>=3)return {code:'repeated_avoidance',label:'Repeated avoidance',confidence:'medium',basis:'Multiple avoidance/missed-session signals are recorded.'};
    if(avoid>0||missed>0)return {code:'ordinary_procrastination',label:'Ordinary procrastination',confidence:'low',basis:'A limited avoidance/missed-session signal is recorded.'};
    return {code:'normal',label:'Normal execution',confidence:'low',basis:'No disruption pattern is currently recorded.'};
  }
  function recordEvent(kind,data){var rows=recentEvents();rows.push(Object.assign({id:uid('ak'),at:iso(),kind:kind},data||{}));save(EVENT_KEY,rows.slice(-300));cache.at=0;return rows[rows.length-1]}

  function scoreTask(task,d){
    var c=context(d),w=cfg().priorityWeights,urg=0,imp=0,cons=0,feas=0,time=0;
    var due=task.due||task.deadline||task.date, mins=due?minutesUntil(due):99999;
    if(mins<=0)urg=100;else if(mins<=1440)urg=95;else if(mins<=4320)urg=80;else if(mins<=10080)urg=60;else if(mins<=20160)urg=35;else urg=15;
    if(task.kind==='exam')imp=95;else if(task.kind==='assignment')imp=82;else if(task.kind==='weakness')imp=75;else imp=55;
    if(task.consequence!=null)cons=clamp(task.consequence,0,100);else cons=task.kind==='exam'?90:task.kind==='assignment'?75:55;
    var p=academic(),sub=task.subject||'Academic',row=p&&p.subjects?p.subjects[sub]:null,risk=row&&row.risk||0;cons=clamp(cons+risk*.25,0,100);
    var need=Number(task.minutes||45),avail=Math.max(10,c.availableMinutes||45);feas=clamp(100-Math.max(0,need-avail)*2,20,100);if(c.schoolDay)feas*=0.75;if(c.lateReturn)feas*=0.9;if(c.recovery.code==='capacity_limitation')feas*=0.7;
    time=clamp(avail/Math.max(need,1)*100,10,100);
    var total=urg*w.urgency+imp*w.importance+cons*w.consequence+feas*w.feasibility+time*w.time;
    return {score:Math.round(total),factors:{urgency:Math.round(urg),importance:Math.round(imp),consequence:Math.round(cons),feasibility:Math.round(feas),availableTime:Math.round(time)},availableMinutes:c.availableMinutes};
  }
  function candidates(d){
    var list=[];
    assignments().filter(function(a){return a.status!=='done'}).forEach(function(a){list.push({id:a.id,kind:'assignment',subject:a.subject||'Academic',topic:a.title||a.name||'Assignment',due:a.due||a.deadline||a.date,minutes:Number(a.minutes||45),consequence:a.consequence})});
    exams().filter(function(e){return e.date&&daysUntil(e.date)>=0}).forEach(function(e){list.push({id:e.id,kind:'exam',subject:e.subject||'Academic',topic:'Prepare: '+(e.title||'Exam'),due:e.date,minutes:45,consequence:95})});
    var p=academic();if(p&&p.weaknesses) p.weaknesses.slice(0,5).forEach(function(s){var row=p.subjects[s]||{};list.push({id:'weak_'+s,kind:'weakness',subject:s,topic:(row.mistakes&&row.mistakes.repeatedPatterns&&row.mistakes.repeatedPatterns[0]&&row.mistakes.repeatedPatterns[0].type)||'Highest-value weak area',minutes:30,consequence:65})});
    return list.map(function(t){return Object.assign(t,{priority:scoreTask(t,d)})}).sort(function(a,b){return b.priority.score-a.priority.score});
  }
  function nextMove(d){
    d=d||now();var c=context(d),active=activeSession();if(active)return {action:'continue',task:{id:active.id,subject:active.subject||'Academic',topic:active.topic||'Current study',minutes:Number(active.minutes||45)},reason:'A study session is already active.',priority:100,context:c};
    if(c.mode==='sleep')return {action:'protect_sleep',task:null,reason:'Sleep protection is active.',priority:100,context:c};
    var list=candidates(d);if(!list.length)return {action:'plan',task:null,reason:'No concrete unfinished academic task is recorded.',priority:0,context:c};
    var t=list[0],mins=Math.min(Number(t.minutes||45),Number(c.availableMinutes||45));if(c.recovery.code==='capacity_limitation')mins=Math.min(mins,25);if(c.lateReturn)mins=Math.min(mins,30);
    return {action:'start',task:{id:t.id,subject:t.subject,topic:t.topic,minutes:Math.max(10,mins),kind:t.kind},reason:'Selected from the live priority model: urgency × importance × consequence × feasibility × available time.',priority:t.priority.score,factors:t.priority.factors,context:c,alternatives:list.slice(1,4).map(function(x){return {subject:x.subject,topic:x.topic,score:x.priority.score}})};
  }
  function replan(opts){
    opts=opts||{};var d=opts.now?new Date(opts.now):now(),mins=Math.max(10,Math.min(cfg().maxPlanMinutes,Number(opts.availableMinutes)||context(d).availableMinutes||60)),list=candidates(d),items=[],left=mins;
    while(left>=10&&list.length){var t=list.shift(),take=Math.min(Number(t.minutes||45),left);if(context(d).recovery.code==='capacity_limitation')take=Math.min(take,25);items.push({subject:t.subject,topic:t.topic,minutes:Math.max(10,take),priority:t.priority.score,reason:t.kind});left-=take;}
    var result={id:uid('replan'),at:iso(),availableMinutes:mins,items:items,unusedMinutes:left,trigger:opts.trigger||'manual',rule:'Re-rank remaining work against current evidence; never mark missed work completed and never duplicate the entire old plan.'};save('nori_adaptive_replans_v19',arr('nori_adaptive_replans_v19').concat(result).slice(-100));return result;
  }
  function escalation(pattern){
    var p=pattern||classifyRecovery(),level={temporary_disruption:0,capacity_limitation:0,conflicting_priorities:0,normal:0,ordinary_procrastination:1,repeated_avoidance:2}[p.code];
    return {level:level,label:['No escalation','Monitor / restore','Pattern review'][level],proportional:true,action:level===0?'Replan or reduce workload as evidence requires.':level===1?'Address the immediate pattern and verify the next action.':'Review the repeated pattern, rebuild the plan, and verify execution before considering any further KAGE consequence.',forbidden:'No physical-punishment or humiliation action is generated.'};
  }
  function requestOverride(decision,reason){
    var row={id:uid('override'),at:iso(),decision:decision||null,reason:String(reason||'Human Override requested').slice(0,1000),status:'recorded',authority:'human'};var rows=arr(OVERRIDE_KEY);rows.push(row);save(OVERRIDE_KEY,rows.slice(-200));recordEvent('override_requested',{overrideId:row.id});return row;
  }
  function recordOutcome(outcome,data){return recordEvent(outcome,Object.assign({},data||{}, {outcome:outcome}))}
  function live(){var d=now(),n=nextMove(d),e=escalation(n.context.recovery);return {version:'19',generatedAt:iso(),nextMove:n,escalation:e,context:n.context,priorityFormula:'urgency × importance × consequence × feasibility × available time'} }
  function start(){if(g.__noriAdaptiveKageTimer)return;g.__noriAdaptiveKageTimer=setInterval(function(){cache.at=0;try{g.dispatchEvent(new CustomEvent('nori:adaptive-update',{detail:live()}))}catch(e){}},Math.max(5000,Number(cfg().refreshMs)||15000))}
  g.noriAdaptiveKageV19={version:'19',configure:function(p){var x=Object.assign({},cfg(),p||{});save(KEY,x);cache.at=0;return x},config:cfg,context:context,priority:scoreTask,candidates:candidates,nextMove:nextMove,replan:replan,classifyRecovery:classifyRecovery,escalation:escalation,requestOverride:requestOverride,recordEvent:recordEvent,recordOutcome:recordOutcome,live:live,start:start,events:recentEvents};
  start();
})(window);
