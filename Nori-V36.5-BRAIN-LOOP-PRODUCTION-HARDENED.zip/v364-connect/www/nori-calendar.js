/* NORI CALENDAR — persistent event memory + varied recurrence.
   This is an additive layer: assignments, exams, recovery, study sessions and
   consequences remain owned by their original systems; the calendar indexes
   them and stores only explicitly scheduled calendar events.
*/
(function(){
  const KEY='nori_calendar_events_v1';
  const EX_KEY='nori_calendar_exceptions_v1';
  const TYPES=['academic','exam','recovery','study','system','personal','festival'];
  const COLORS={}; // intentionally monochrome; CSS handles presentation.
  function load(k,fb){try{const v=JSON.parse(localStorage.getItem(k)||'null');return v==null?fb:v}catch(e){return fb}}
  function save(k,v){try{if(typeof noriSafeWrite==='function')return noriSafeWrite(k,v);localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function uid(){return 'cal_'+Date.now()+'_'+Math.random().toString(36).slice(2,8)}
  function isoDate(d){return d.toISOString().slice(0,10)}
  function parseDate(s){const d=new Date(String(s)+'T12:00:00');return isNaN(d)?null:d}
  function addDays(d,n){const x=new Date(d);x.setDate(x.getDate()+n);return x}
  function sameDay(a,b){return isoDate(a)===isoDate(b)}
  function normalize(e){
    return Object.assign({id:uid(),title:'Untitled event',type:'academic',start:isoDate(new Date()),end:null,allDay:true,notes:'',sourceType:'manual',sourceId:null,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),recurrence:{frequency:'none',interval:1,daysOfWeek:[],until:null,count:null}},e||{});
  }
  function events(){return load(KEY,[]).map(normalize)}
  function put(list){return save(KEY,list)}
  function add(e){const list=events();const row=normalize(e);list.push(row);put(list);return row}
  function update(id,patch){const list=events();const i=list.findIndex(x=>x.id===id);if(i<0)return null;list[i]=Object.assign({},list[i],patch||{}, {updatedAt:new Date().toISOString()});if(patch&&patch.recurrence)list[i].recurrence=Object.assign({},list[i].recurrence||{},patch.recurrence);put(list);return list[i]}
  function remove(id){return put(events().filter(x=>x.id!==id))}
  function exceptions(){return load(EX_KEY,{})}
  function setException(seriesId,date,action){const x=exceptions();if(!x[seriesId])x[seriesId]={};x[seriesId][date]=action;save(EX_KEY,x)}
  function exception(seriesId,date){return exceptions()[seriesId]&&exceptions()[seriesId][date]}

  function recurrenceOccurrences(e,from,to){
    const start=parseDate(e.start); if(!start)return [];
    const end=to||addDays(from,31), begin=from||addDays(new Date(),-30); const r=e.recurrence||{frequency:'none',interval:1,daysOfWeek:[],until:null,count:null};
    const out=[]; let cursor=new Date(start), emitted=0, guard=0;
    const until=r.until?parseDate(r.until):null;
    const limit=r.count?Number(r.count):Infinity;
    while(cursor<=end && guard<10000 && emitted<limit){
      guard++;
      if(until && cursor>until)break;
      let match=false;
      if(r.frequency==='none') match=sameDay(cursor,start);
      else if(r.frequency==='daily') match=Math.floor((cursor-start)/86400000)%(Number(r.interval)||1)===0;
      else if(r.frequency==='weekly') match=Math.floor((cursor-start)/86400000/7)%(Number(r.interval)||1)===0 && (!r.daysOfWeek||!r.daysOfWeek.length||r.daysOfWeek.indexOf(cursor.getDay())>=0);
      else if(r.frequency==='weekdays') match=[1,2,3,4,5].indexOf(cursor.getDay())>=0 && Math.floor((cursor-start)/86400000)%(Number(r.interval)||1)===0;
      else if(r.frequency==='monthly') match=cursor.getDate()===start.getDate() && (cursor.getFullYear()*12+cursor.getMonth()-(start.getFullYear()*12+start.getMonth()))%(Number(r.interval)||1)===0;
      else if(r.frequency==='custom') match=Math.floor((cursor-start)/86400000)%(Number(r.interval)||1)===0;
      if(match){const ds=isoDate(cursor);const ex=exception(e.id,ds);if(ex!=='skip' && cursor>=begin && cursor<=end)out.push({series:e, date:ds, occurrenceId:e.id+'@'+ds, exception:ex||null});emitted++;}
      if(r.frequency==='monthly'){cursor.setDate(cursor.getDate()+1)} else cursor=addDays(cursor,1);
    }
    return out;
  }

  function derived(){
    const out=[];
    const assignments=typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():[];
    assignments.forEach(a=>{if(a.due)out.push({id:'a_'+a.id,title:a.title,type:'academic',start:a.due,allDay:true,sourceType:'assignment',sourceId:a.id,status:a.status,priority:a.priority,readonly:true})});
    const exams=load('nori_exams',[]); exams.forEach(x=>{if(x.date)out.push({id:'e_'+x.id,title:x.subject+' — '+x.title,type:'exam',start:x.date,allDay:true,sourceType:'exam',sourceId:x.id,readonly:true})});
    const sessions=load('nori_study_sessions',[]); sessions.forEach(x=>{if(x.date)out.push({id:'s_'+(x.id||x.date+x.topic),title:x.subject+' — '+x.topic,type:'study',start:x.date,allDay:true,sourceType:'study',sourceId:x.id||null,status:x.status,readonly:true})});
    const active=typeof noriActiveConsequences==='function'?noriActiveConsequences():[]; active.forEach(x=>{const st=x.startedAt?isoDate(new Date(x.startedAt)):null;if(st)out.push({id:'c_'+x.eventId+'_'+x.consequenceId,title:x.label||'Active consequence',type:'system',start:st,end:x.endsAt?isoDate(new Date(x.endsAt)):null,allDay:true,sourceType:'consequence',sourceId:x.consequenceId,status:'active',readonly:true})});
    const brain=(typeof NORI_DECIDE_STATE!=='undefined'&&NORI_DECIDE_STATE&&Array.isArray(NORI_DECIDE_STATE.events))?NORI_DECIDE_STATE.events:[]; brain.forEach(e=>{const st=e.timestamp?isoDate(new Date(e.timestamp)):null;if(st&&(e.appliedConsequence||e.secondaryConsequence))out.push({id:'history_'+(e.eventId||st),title:'Decision event · Degree '+(e.degree||'?'),type:'system',start:st,allDay:true,sourceType:'brain-event',sourceId:e.eventId||null,status:e.recoveryStatus||'recorded',readonly:true})});
    return out;
  }
  function allOccurrences(from,to){
    const out=[];events().forEach(e=>recurrenceOccurrences(e,from,to).forEach(o=>out.push(Object.assign({},o.series,{occurrenceId:o.occurrenceId,occurrenceDate:o.date,derived:false}))));
    derived().forEach(e=>{const d=parseDate(e.start);if(d&&d>=from&&d<=to)out.push(Object.assign({},e,{occurrenceId:e.id,occurrenceDate:e.start,derived:true}))});
    return out.sort((a,b)=>String(a.occurrenceDate).localeCompare(String(b.occurrenceDate))||String(a.title).localeCompare(String(b.title)));
  }
  function dateLabel(s){const d=parseDate(s);return d?d.toLocaleDateString(undefined,{weekday:'short',day:'2-digit',month:'short',year:'numeric'}):s}
  function recurrenceLabel(r){r=r||{};if(!r.frequency||r.frequency==='none')return 'ONCE';const i=Number(r.interval)||1;if(r.frequency==='weekdays')return 'WEEKDAYS';if(r.frequency==='weekly'&&r.daysOfWeek&&r.daysOfWeek.length)return 'EVERY '+i+' WEEK'+(i>1?'S':'')+' · '+r.daysOfWeek.map(x=>['SUN','MON','TUE','WED','THU','FRI','SAT'][x]).join(', ');return 'EVERY '+i+' '+String(r.frequency).toUpperCase().replace('DAILY','DAY').replace('WEEKLY','WEEK').replace('MONTHLY','MONTH').replace('CUSTOM','DAY');}

  function modal(existing,preset){
    const ov=noriEl('div',{class:'nori-modal'}),m=noriEl('div',{class:'nori-modal-card nori-calendar-modal'});const h=noriEl('div',{class:'nori-modal-head'});h.appendChild(noriEl('h2',{text:existing?'Edit calendar event':'Schedule calendar event'}));h.appendChild(noriEl('button',{class:'nori-btn nori-btn-ghost',text:'Close'}));h.lastChild.onclick=()=>ov.remove();m.appendChild(h);
    const grid=noriEl('div',{class:'nori-calendar-form'});const f={};
    function field(key,label,type,opts){const b=noriEl('div',{class:'nori-field'});b.appendChild(noriEl('label',{text:label}));let el;if(type==='select'){el=noriEl('select',{});opts.forEach(o=>el.appendChild(noriEl('option',{value:o[0],text:o[1]})))}else el=noriEl('input',{type:type});f[key]=el;b.appendChild(el);grid.appendChild(b);}
    field('title','Event / task','text');field('type','Type','select',TYPES.map(x=>[x,x.toUpperCase()]));field('start','Date','date');field('until','Repeat until','date');field('frequency','Repeat','select',[['none','Does not repeat'],['daily','Daily'],['weekdays','Weekdays'],['weekly','Weekly'],['monthly','Monthly'],['custom','Every N days']]);field('interval','Repeat every','number');field('count','Maximum occurrences','number');
    const days=noriEl('div',{class:'nori-calendar-days'});days.appendChild(noriEl('label',{text:'Weekly days'}));const dayChecks=[];['SUN','MON','TUE','WED','THU','FRI','SAT'].forEach((name,i)=>{const lab=noriEl('label',{}),c=noriEl('input',{type:'checkbox'});c.value=String(i);dayChecks.push(c);lab.appendChild(c);lab.appendChild(document.createTextNode(name));days.appendChild(lab)});grid.appendChild(days);
    const note=noriEl('div',{class:'nori-field full'});note.appendChild(noriEl('label',{text:'Notes'}));f.notes=noriEl('textarea',{rows:'3',placeholder:'Optional details'});note.appendChild(f.notes);grid.appendChild(note);m.appendChild(grid);
    const actions=noriEl('div',{class:'nori-form-actions'});const saveBtn=noriEl('button',{class:'nori-btn nori-btn-primary',text:'Save event'});actions.appendChild(saveBtn);if(existing){const del=noriEl('button',{class:'nori-btn nori-btn-ghost',text:'Delete series'});del.onclick=()=>{if(confirm('Delete this recurring event and its future occurrences?')){remove(existing.id);ov.remove();noriRoute()}};actions.appendChild(del)}m.appendChild(actions);ov.appendChild(m);document.body.appendChild(ov);
    const src=existing||preset||{};f.title.value=src.title||'';f.type.value=src.type||'academic';f.start.value=src.start||isoDate(new Date());f.until.value=src.recurrence&&src.recurrence.until||'';f.frequency.value=src.recurrence&&src.recurrence.frequency||'none';f.interval.value=src.recurrence&&src.recurrence.interval||1;f.count.value=src.recurrence&&src.recurrence.count||'';f.notes.value=src.notes||'';(src.recurrence&&src.recurrence.daysOfWeek||[]).forEach(i=>dayChecks[i]&&(dayChecks[i].checked=true));
    saveBtn.onclick=()=>{if(!f.title.value.trim()||!f.start.value){alert('Title and date are required.');return}const rec={frequency:f.frequency.value,interval:Math.max(1,Number(f.interval.value)||1),until:f.until.value||null,count:f.count.value?Math.max(1,Number(f.count.value)):null,daysOfWeek:dayChecks.filter(x=>x.checked).map(x=>Number(x.value))};const payload={title:f.title.value.trim(),type:f.type.value,start:f.start.value,notes:f.notes.value.trim(),recurrence:rec};if(existing)update(existing.id,payload);else add(payload);ov.remove();noriRoute()};
  }

  function render(){
    const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen nori-calendar-screen'});wrap.appendChild(noriRenderCommandHeader(false));wrap.appendChild(noriRenderBreadcrumb([{label:'NORI',hash:'#/'},{label:'Calendar'}]));
    let cursor=new Date();cursor.setDate(1);let selected=isoDate(new Date());
    const state=load('nori_calendar_view',{year:cursor.getFullYear(),month:cursor.getMonth(),selected:selected});cursor.setFullYear(state.year);cursor.setMonth(state.month);selected=state.selected||isoDate(new Date());
    const head=noriEl('section',{class:'nori-section-card'});const hh=noriEl('div',{class:'nori-section-head'});hh.appendChild(noriEl('h2',{text:'Calendar'}));const acts=noriEl('div',{class:'nori-inline-actions'});acts.appendChild(noriEl('button',{class:'nori-btn nori-btn-ghost',text:'TODAY'}));acts.appendChild(noriEl('button',{class:'nori-btn nori-btn-primary',text:'+ EVENT'}));hh.appendChild(acts);head.appendChild(hh);
    acts.firstChild.onclick=()=>{selected=isoDate(new Date());state.year=new Date().getFullYear();state.month=new Date().getMonth();save('nori_calendar_view',state);noriRoute()};acts.lastChild.onclick=()=>modal(null,{start:selected});
    const monthBar=noriEl('div',{class:'nori-calendar-monthbar'});const prev=noriEl('button',{class:'nori-btn nori-btn-ghost',text:'‹'}),next=noriEl('button',{class:'nori-btn nori-btn-ghost',text:'›'});const title=noriEl('strong',{text:cursor.toLocaleDateString(undefined,{month:'long',year:'numeric'}).toUpperCase()});monthBar.appendChild(prev);monthBar.appendChild(title);monthBar.appendChild(next);head.appendChild(monthBar);
    const grid=noriEl('div',{class:'nori-calendar-grid'});['SUN','MON','TUE','WED','THU','FRI','SAT'].forEach(x=>grid.appendChild(noriEl('div',{class:'nori-calendar-weekday',text:x})));const first=new Date(cursor);const offset=first.getDay();const days=new Date(cursor.getFullYear(),cursor.getMonth()+1,0).getDate();const from=new Date(cursor.getFullYear(),cursor.getMonth(),1);const to=new Date(cursor.getFullYear(),cursor.getMonth()+1,0);const occ=allOccurrences(addDays(from,-7),addDays(to,7));for(let i=0;i<offset;i++)grid.appendChild(noriEl('div',{class:'nori-calendar-day empty'}));for(let d=1;d<=days;d++){const ds=isoDate(new Date(cursor.getFullYear(),cursor.getMonth(),d));const cell=noriEl('button',{class:'nori-calendar-day'+(ds===selected?' selected':'')+(ds===isoDate(new Date())?' today':'')});cell.appendChild(noriEl('span',{class:'nori-day-num',text:String(d)}));occ.filter(x=>x.occurrenceDate===ds).slice(0,4).forEach(x=>{const chip=noriEl('span',{class:'nori-calendar-chip '+x.type,text:x.title});chip.title=(x.derived?'LINKED · ':'')+(x.recurrence?recurrenceLabel(x.recurrence):'');cell.appendChild(chip)});if(occ.some(x=>x.occurrenceDate===ds))cell.appendChild(noriEl('span',{class:'nori-day-count',text:String(occ.filter(x=>x.occurrenceDate===ds).length)}));cell.onclick=()=>{state.selected=ds;save('nori_calendar_view',state);noriRoute()};grid.appendChild(cell)}head.appendChild(grid);wrap.appendChild(head);
    const day=noriEl('section',{class:'nori-section-card'});const dh=noriEl('div',{class:'nori-section-head'});dh.appendChild(noriEl('h2',{text:'Schedule · '+dateLabel(selected)}));dh.appendChild(noriEl('button',{class:'nori-btn nori-btn-ghost',text:'+ SCHEDULE'}));dh.lastChild.onclick=()=>modal(null,{start:selected});day.appendChild(dh);const list=noriEl('div',{class:'nori-calendar-event-list'});const todays=allOccurrences(parseDate(selected),parseDate(selected));if(!todays.length)list.appendChild(noriEl('div',{class:'nori-command-empty',text:'No events scheduled for this day.'}));todays.forEach(x=>{const row=noriEl('div',{class:'nori-calendar-event-row'});const datebox=noriEl('div',{class:'nori-calendar-event-date',text:x.type.toUpperCase()});const body=noriEl('div',{});body.appendChild(noriEl('strong',{text:x.title}));body.appendChild(noriEl('small',{text:(x.sourceType&&x.sourceType!=='manual'?x.sourceType.toUpperCase()+' · ':'')+(x.recurrence?recurrenceLabel(x.recurrence):'ONCE')+(x.notes?' · '+x.notes:'')}));row.appendChild(datebox);row.appendChild(body);if(x.derived)row.appendChild(noriEl('span',{class:'nori-state-chip planned',text:'LINKED'}));else{const acts2=noriEl('div',{class:'nori-inline-actions'});acts2.appendChild(noriEl('button',{class:'nori-btn nori-btn-ghost',text:'EDIT'}));acts2.lastChild.onclick=()=>modal(events().find(e=>e.id===x.id));acts2.appendChild(noriEl('button',{class:'nori-btn nori-btn-ghost',text:'SKIP'}));acts2.lastChild.onclick=()=>{setException(x.id,x.occurrenceDate,'skip');noriRoute()};row.appendChild(acts2)}list.appendChild(row)});day.appendChild(list);wrap.appendChild(day);
    const memory=noriEl('section',{class:'nori-section-card'});memory.appendChild(noriEl('div',{class:'nori-section-head'},[noriEl('h2',{text:'Event Memory & Repetition'})]));const text=noriEl('div',{class:'nori-calendar-memory'});text.innerHTML='<strong>Calendar memory is persistent.</strong><span>Assignments, exams, study sessions, recovery scheduling and active consequences are indexed automatically.</span><span>Manual events can repeat daily, weekdays, weekly on selected days, monthly, or every N days.</span><span>Skipped occurrences are remembered without deleting the rest of a series.</span>';memory.appendChild(text);wrap.appendChild(memory);wrap.appendChild(noriBottomNav('calendar'));return wrap;
  }
  function scheduleRecovery(subject){modal(null,{type:'recovery',title:subject?'Recovery · '+subject:'Recovery session',start:isoDate(new Date()),recurrence:{frequency:'none',interval:1,daysOfWeek:[],until:null,count:null}})}
  window.noriCalendar={events,add,update,remove,allOccurrences,recurrenceLabel,scheduleRecovery,render};
  window.noriRenderCalendar=render;
})();
