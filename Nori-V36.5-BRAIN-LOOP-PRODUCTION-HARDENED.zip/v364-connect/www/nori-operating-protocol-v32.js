/* NORI OPERATING PROTOCOL V32
 * Common nervous system for capabilities: intent, session, pending actions,
 * policy, idempotency, tracing, cancellation, locks, state gateway, time,
 * identity, platform adapters, result/error schemas, simulation and reactions.
 * This layer does not replace specialist engines; it gives them one contract.
 */
(function(g){'use strict';
  const VERSION='32';
  const clone=x=>{try{return JSON.parse(JSON.stringify(x));}catch(e){return x;}};
  const now=()=>new Date().toISOString();
  const uid=(p)=>String(p||'id')+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,10);
  const MAX=250, MAX_QUEUE=100;
  const events=[], pending=new Map(), locks=new Map(), reactions=new Map(), jobs=new Map();
  const cancelled=new Set(), idempotency=new Map(), cache=new Map();
  let current=null;

  const ERRORS={
    CAPABILITY_UNAVAILABLE:'CAPABILITY_UNAVAILABLE', PERMISSION_REQUIRED:'PERMISSION_REQUIRED',
    AUTH_REQUIRED:'AUTH_REQUIRED', CONFLICT:'CONFLICT', VALIDATION_FAILED:'VALIDATION_FAILED',
    USER_CONFIRMATION_REQUIRED:'USER_CONFIRMATION_REQUIRED', EXECUTION_FAILED:'EXECUTION_FAILED',
    VERIFICATION_FAILED:'VERIFICATION_FAILED', CANCELLED:'CANCELLED', TIMEOUT:'TIMEOUT',
    DEPENDENCY_UNAVAILABLE:'DEPENDENCY_UNAVAILABLE', LOCKED:'CAPABILITY_LOCKED',
    IDEMPOTENT_REPLAY:'IDEMPOTENT_REPLAY', TRANSACTION_FAILED:'TRANSACTION_FAILED'
  };
  const emit=(type,payload,meta)=>{
    const e={id:uid('evt'),type,at:now(),correlationId:meta&&meta.correlationId||uid('corr'),requestId:meta&&meta.requestId||null,intentId:meta&&meta.intentId||null,actionId:meta&&meta.actionId||null,payload:clone(payload||{}),source:meta&&meta.source||'operating-protocol-v32'};
    events.push(e);while(events.length>MAX)events.shift();
    try{if(g.NoriEventBusV31&&type!=='protocol.event'){g.NoriEventBusV31.emit(type,e.payload,Object.assign({},meta||{}, {correlationId:e.correlationId,requestId:e.requestId,intentId:e.intentId,actionId:e.actionId}));}}catch(_){ }
    try{window.dispatchEvent(new CustomEvent('nori:protocol-event',{detail:e}));}catch(_){ }
    return e;
  };
  function fail(code,message,extra){return Object.assign({ok:false,status:'error',error:{code,message:message||code}},extra||{});}
  function result(status,data,extra){return Object.assign({ok:status==='success',status,data:data===undefined?null:clone(data),stateChanges:[],verification:null,userMessage:null,errors:[]},extra||{});}

  /* 49: one intent object */
  function intent(input){
    input=input||{};
    return {id:input.intentId||uid('intent'),source:String(input.source||'text'),sessionId:input.sessionId||'default',goal:String(input.goal||input.text||input.action||'').trim(),entities:clone(input.entities||input.args||{}),requestedAction:input.requested_action||input.requestedAction||input.action||null,confidence:Number.isFinite(Number(input.confidence))?Number(input.confidence):null,context:clone(input.context||{}),userConfirmation:input.user_confirmation!==undefined?input.user_confirmation:(input.userConfirmation!==undefined?input.userConfirmation:null),operationClass:input.operationClass||null,createdAt:input.createdAt||now()};
  }

  /* 50/62: shared session + identity */
  function getSession(id){return clone(cache.get('session:'+String(id||'default'))||{id:id||'default',createdAt:now(),version:0});}
  function setSession(id,patch){const sid=String(id||'default'),old=getSession(sid),next=Object.assign({},old,clone(patch||{}),{id:sid,version:(old.version||0)+1,updatedAt:now()});cache.set('session:'+sid,next);current=next;emit('session.updated',{session:next},{source:'session'});return clone(next);}
  async function identity(){
    try{if(g.NoriProductionAuth&&typeof g.NoriProductionAuth.session==='function'){const r=await g.NoriProductionAuth.session();const s=r&&r.data&&r.data.session;return {authenticatedUserId:s&&s.user&&s.user.id||null,profile:g.NoriProfile||null,permissions:[],role:null,device:{platform:g.NORI_IS_NATIVE?'android':'web'},privacy:{}};}}catch(_){ }
    try{if(g.NoriSyncAuth&&typeof g.NoriSyncAuth.supabaseClient==='function'){const c=g.NoriSyncAuth.supabaseClient();if(c&&c.auth){const r=await c.auth.getSession();const s=r&&r.data&&r.data.session;return {authenticatedUserId:s&&s.user&&s.user.id||null,profile:g.NoriProfile||null,permissions:[],role:null,device:{platform:g.NORI_IS_NATIVE?'android':'web'},privacy:{}};}}}catch(_){ }
    return {authenticatedUserId:null,profile:g.NoriProfile||null,permissions:[],role:null,device:{platform:g.NORI_IS_NATIVE?'android':'web'},privacy:{}};
  }

  /* 61: one clock. UTC is storage authority; local/ethiopic are display helpers. */
  const Time={now:()=>new Date(),iso:()=>now(),timezone:()=>{try{return Intl.DateTimeFormat().resolvedOptions().timeZone||'UTC';}catch(_){return 'UTC';}},local:(iso)=>new Date(iso||Date.now()),ethiopic:(iso)=>{try{return new Intl.DateTimeFormat('en-u-ca-ethiopic',{dateStyle:'medium',timeStyle:'short'}).format(new Date(iso||Date.now()));}catch(_){return new Date(iso||Date.now()).toLocaleString();}},parse:(v,base)=>{if(v instanceof Date)return new Date(v);const s=String(v||'').trim();if(/^tomorrow\b/i.test(s)){const d=new Date(base||Date.now());d.setDate(d.getDate()+1);return d;}return new Date(s);}};

  /* 65/66/67/68/69: state gateway, cache, conflict and sync queue. */
  const State={
    async read(key,opts){
      const k=String(key), o=opts||{};
      if(cache.has('state:'+k)&&!o.refresh)return clone(cache.get('state:'+k));
      try{if(g.NoriCanonicalState&&typeof g.NoriCanonicalState.read==='function'){const v=await g.NoriCanonicalState.read(k);cache.set('state:'+k,v);return clone(v);}}catch(_){ }
      try{const v=JSON.parse(localStorage.getItem(k)||'null');cache.set('state:'+k,v);return clone(v);}catch(_){return null;}
    },
    async snapshot(keys){const out={};for(const k of (keys||[]))out[k]=await this.read(k);return {version:cache.get('canonical:version')||null,data:out};},
    async mutate(key,mutation,opts){
      const o=opts||{}, requestId=o.requestId||uid('request'), before=await this.read(key,{refresh:true});
      let next=typeof mutation==='function'?await mutation(clone(before)):clone(mutation);
      try{
        if(g.NoriCanonicalState&&typeof g.NoriCanonicalState.mutate==='function'){
          const r=await g.NoriCanonicalState.mutate(key,next,{expectedVersion:o.expectedVersion,requestId});
          if(r&&r.conflict)return fail(ERRORS.CONFLICT,'Canonical state version conflict.',{code:ERRORS.CONFLICT,server:r});
          cache.set('state:'+key,next);emit('state.changed',{key,before,after:next,version:r&&r.version||null},{requestId,source:'state-gateway'});return result('success',next,{stateChanges:[{key,before,after:next}],verification:{verified:true,source:'canonical-writer'}});
        }
        const raw=JSON.stringify(next);localStorage.setItem(key,raw);cache.set('state:'+key,next);emit('state.changed',{key,before,after:next,version:null},{requestId,source:'local-state-adapter'});return result('success',next,{stateChanges:[{key,before,after:next}],verification:{verified:true,source:'local-state-adapter'}});
      }catch(e){
        if(o.queueOffline!==false){const q=loadQueue();q.push({id:uid('queue'),requestId,key,mutation:clone(next),expectedVersion:o.expectedVersion,createdAt:now(),status:'pending'});saveQueue(q);return result('queued',next,{userMessage:'Saved for synchronization when the connection is available.'});}
        return fail(ERRORS.EXECUTION_FAILED,e.message);
      }
    },
    readSync(key){const k=String(key);if(cache.has('state:'+k))return clone(cache.get('state:'+k));try{const v=JSON.parse(localStorage.getItem(k)||'null');cache.set('state:'+k,v);return clone(v);}catch(_){return null;}},
    writeSync(key,value,meta){const k=String(key),before=this.readSync(k);try{localStorage.setItem(k,JSON.stringify(value));cache.set('state:'+k,clone(value));emit('state.changed',{key:k,before,after:value,version:null},{requestId:meta&&meta.requestId||uid('request'),source:'state-gateway-sync'});return true;}catch(_){return false;}},
    version:()=>cache.get('canonical:version')||null,
    async resolveConflict(key,recompile,opts){const o=opts||{};if(!o.safeRetry)return fail(ERRORS.CONFLICT,'Conflict requires explicit safe retry policy.');const latest=await this.read(key,{refresh:true});const next=typeof recompile==='function'?await recompile(clone(latest)):recompile;return this.mutate(key,next,Object.assign({},o,{expectedVersion:o.expectedVersion===undefined?this.version():o.expectedVersion,queueOffline:false}));}
  };
  const QKEY='nori_protocol_v32_queue';
  function loadQueue(){try{return JSON.parse(localStorage.getItem(QKEY)||'[]');}catch(_){return [];}}
  function saveQueue(q){try{localStorage.setItem(QKEY,JSON.stringify(q.slice(-MAX_QUEUE)));return true;}catch(_){return false;}}
  async function syncQueue(){const q=loadQueue(),left=[];for(const item of q){try{const r=await State.mutate(item.key,item.mutation,{requestId:item.requestId,expectedVersion:item.expectedVersion,queueOffline:false});if(!r.ok)left.push(Object.assign({},item,{lastError:r.error||r.status}));else emit('sync.completed',{queueId:item.id,requestId:item.requestId},{requestId:item.requestId,source:'sync'});}catch(e){left.push(Object.assign({},item,{lastError:e.message}));}}saveQueue(left);return {ok:true,remaining:left.length};}

  /* 52/53/54/55/56/57/58/60: one lifecycle */
  const risk=(cap,action)=>{const s=String(action||'').toLowerCase();if(/delete|remove|reset|wipe|revoke/.test(s))return 'high';if(/create|update|complete|cancel|stop|record|schedule|start/.test(s))return 'medium';return 'low';};
  function operationClass(action){const s=String(action||'').toLowerCase();if(/^read|^get|^show|^list|^observe/.test(s))return 'READ';if(/^navigate/.test(s))return 'NAVIGATE';if(/^speak/.test(s))return 'SPEAK';if(/delete|remove/.test(s))return 'DELETE';if(/create|update|complete|cancel|start|stop|schedule|record|mutate/.test(s))return 'MUTATE';return 'PROPOSE';}
  function policy(cap,action,ctx){const r=risk(cap,action), cls=operationClass(action), override=ctx&&ctx.userConfirmation==='override';return {risk:r,operationClass:cls,confirmationRequired:cls==='MUTATE'||cls==='DELETE'||r==='high',overrideRequired:r==='high'&&!override,allow:!((ctx&&ctx.cancelled)||false)};}
  function pendingCreate(intentObj,cap,proposal,ctx){const p={id:uid('pending'),intentId:intentObj.id,requestId:ctx.requestId,correlationId:ctx.correlationId,sessionId:intentObj.sessionId,capability:cap,action:intentObj.requestedAction,operationClass:operationClass(intentObj.requestedAction),risk:risk(cap,intentObj.requestedAction),createdAt:now(),expiresAt:new Date(Date.now()+10*60*1000).toISOString(),status:'AWAITING_CONFIRMATION',proposal:clone(proposal||null),steps:[],compensations:[],idempotencyKey:ctx.idempotencyKey||null};pending.set(p.id,p);persistPending();emit('pending_action.created',{pendingAction:p},{requestId:ctx.requestId,correlationId:ctx.correlationId,intentId:intentObj.id,actionId:p.id,source:'pending-manager'});return p;}
  const PKEY='nori_protocol_v32_pending';
  function persistPending(){try{localStorage.setItem(PKEY,JSON.stringify(Array.from(pending.values())));}catch(_){}}
  function hydratePending(){try{const a=JSON.parse(localStorage.getItem(PKEY)||'[]');(Array.isArray(a)?a:[]).forEach(p=>{if(p.expiresAt&&Date.parse(p.expiresAt)<Date.now())return;if(p&&p.id)pending.set(p.id,p);});}catch(_){}}
  function pendingList(){hydratePending();return Array.from(pending.values()).map(clone);}
  function clearPending(idv){pending.delete(idv);persistPending();}

  /* 54: central confirmation policy. */
  async function requireConfirmation(intentObj,cap,proposal,ctx){const p=policy(cap,intentObj.requestedAction,ctx);if(!p.confirmationRequired)return null;if(intentObj.userConfirmation===true)return null;return pendingCreate(intentObj,cap,proposal,ctx);}

  /* 53/80: rollback + compensating transaction contract. */
  async function transaction(steps,ctx){const completed=[],txId=uid('tx');for(let i=0;i<steps.length;i++){const s=steps[i];if(isCancelled(ctx))return fail(ERRORS.CANCELLED,'Transaction cancelled.',{transactionId:txId});try{const r=await withTimeout(Promise.resolve().then(()=>s.execute(ctx)),s.timeoutMs||30000,ctx);if(!r||r.ok===false)throw Object.assign(new Error(r&&r.error&&r.error.message||'step_failed'),{code:r&&r.error&&r.error.code});completed.push({step:s,result:r});}catch(e){for(let j=completed.length-1;j>=0;j--){const c=completed[j];if(typeof c.step.rollback==='function'){try{await c.step.rollback(c.result,ctx);}catch(_){}}}emit('transaction.failed',{transactionId:txId,failedStep:i,error:e.message,compensated:completed.length},{correlationId:ctx.correlationId,requestId:ctx.requestId,source:'transaction'});return fail(ERRORS.TRANSACTION_FAILED,e.message,{transactionId:txId,compensatedSteps:completed.length});}}
    emit('transaction.completed',{transactionId:txId,steps:completed.length},{correlationId:ctx.correlationId,requestId:ctx.requestId,source:'transaction'});return result('success',{transactionId:txId,steps:completed});}

  /* 54/60: lock manager */
  function acquireLock(resource,owner,ttl){const r=String(resource);const old=locks.get(r);if(old&&old.expiresAt>Date.now()&&old.owner!==owner)return false;locks.set(r,{owner,acquiredAt:Date.now(),expiresAt:Date.now()+(ttl||30000)});emit('lock.acquired',{resource:r,owner},{source:'lock-manager'});return true;}
  function releaseLock(resource,owner){const r=String(resource),x=locks.get(r);if(x&&x.owner===owner){locks.delete(r);emit('lock.released',{resource:r,owner},{source:'lock-manager'});return true;}return false;}

  /* 57/58: cancellation + interruption hierarchy. */
  const interrupt={SAFETY:500,OVERRIDE:400,INTEGRITY:350,USER_CANCEL:300,ACTION:200,CONVERSATION:100};
  function cancel(requestId,reason,priority){const p=Number(priority||interrupt.USER_CANCEL);cancelled.add(String(requestId));emit('request.cancelled',{requestId,reason:reason||'user_cancelled',priority:p},{requestId,source:'interrupt-manager'});return {ok:true,requestId,priority:p};}
  function isCancelled(ctx){return !!(ctx&&cancelled.has(String(ctx.requestId)));}
  async function withTimeout(promise,ms,ctx){let timer;return await Promise.race([promise, new Promise((_,rej)=>{timer=setTimeout(()=>rej(Object.assign(new Error('Operation timed out'),{code:ERRORS.TIMEOUT})),ms);})]).finally(()=>clearTimeout(timer));}

  /* 63/64: platform adapter boundary */
  const adapters={};
  function registerAdapter(platform,adapter){adapters[String(platform)]=adapter||{};emit('adapter.registered',{platform:String(platform),capabilities:Object.keys(adapter||{})},{source:'platform-adapter'});}
  function adapter(platform){return adapters[String(platform)]||adapters.web||{};}
  registerAdapter('web',{storage:State});
  registerAdapter('android',{storage:State});

  /* 70: dependency resolver */
  function dependencies(capability,registry){const missing=[];(capability&&capability.dependencies||[]).forEach(d=>{const x=registry&&registry.get?registry.get(d):null;if(!x)missing.push(d);});return {ok:missing.length===0,missing};}

  /* 71/72/74: change stream, subscriptions and system-level event priority */
  function on(type,fn){if(!reactions.has(type))reactions.set(type,new Set());reactions.get(type).add(fn);return ()=>reactions.get(type)&&reactions.get(type).delete(fn);}
  function priorityForEvent(type,payload){const t=String(type||'').toLowerCase(),p=payload||{};if(/safety|emergency|security/.test(t))return 500;if(/alarm\.fired/.test(t))return 420;if(/exam|deadline|overdue/.test(t))return 350;if(/user/.test(t))return 300;if(/result|assignment|recovery/.test(t))return 220;return 100;}
  function subscribe(type,fn){return on(type,fn);}
  function handleEvent(e){if(!e||e.type==='reaction.queued')return;const pr=priorityForEvent(e.type,e.payload);emit('reaction.queued',{eventId:e.id,type:e.type,priority:pr},{correlationId:e.correlationId,requestId:e.requestId,source:'reaction-priority'});const set=reactions.get(e.type);if(set)for(const fn of Array.from(set)){try{Promise.resolve(fn(e)).catch(()=>{});}catch(_){}}}
  try{window.addEventListener('nori:protocol-event',ev=>{if(ev&&ev.detail&&ev.detail.type)handleEvent(ev.detail);});}catch(_){ }

  /* 73: one background task manager */
  function scheduleJob(name,fn,opts){const o=opts||{},idv=o.id||uid('job'),job={id:idv,name,createdAt:now(),intervalMs:o.intervalMs||null,nextAt:o.nextAt||null,status:'scheduled'};jobs.set(idv,{job,fn});if(o.runAt||o.delayMs){const delay=o.delayMs!=null?o.delayMs:Math.max(0,Date.parse(o.runAt)-Date.now());setTimeout(()=>runJob(idv),delay);}else if(o.intervalMs){setInterval(()=>runJob(idv),o.intervalMs);}emit('job.scheduled',{job},{source:'background-task-manager'});return job;}
  function cancelJob(idv){const x=jobs.get(idv);if(!x)return false;x.job.status='cancelled';jobs.delete(idv);emit('job.cancelled',{job:x.job},{source:'background-task-manager'});return true;}
  async function runJob(idv){const x=jobs.get(idv);if(!x)return fail(ERRORS.CAPABILITY_UNAVAILABLE,'Job not found.');try{const r=await x.fn({job:x.job});x.job.lastRunAt=now();x.job.lastResult=clone(r);emit('job.completed',{job:x.job},{source:'background-task-manager'});return r;}catch(e){x.job.status='failed';emit('job.failed',{job:x.job,error:e.message},{source:'background-task-manager'});return fail(ERRORS.EXECUTION_FAILED,e.message);}}

  /* 75/76/77: filtered capability discovery + explicit operation classes + result schema */
  function discover(registry,ctx){const list=registry&&typeof registry.list==='function'?registry.list():[];const x=ctx||{};return list.filter(c=>{if(c.status==='unavailable')return false;if(c.platforms&&c.platforms.length&&!c.platforms.includes(g.NORI_IS_NATIVE?'android':'web'))return false;const required=c.permissions||[];const granted=x.permissions||[];if(required.some(r=>granted.indexOf(r)<0)&&x.permissions)return false;if(x.riskCeiling&&risk(c.id,(c.actions||[])[0])==='high'&&x.riskCeiling!=='high')return false;return true;}).map(c=>({id:c.id,version:c.version,actions:c.actions||[],risk:c.risk||'low',confirmation:c.confirmation||'required',operationClasses:(c.operationClasses||['READ','PROPOSE','MUTATE','DELETE','NAVIGATE','SPEAK']),dependencies:c.dependencies||[]}));}
  function normalizeResult(raw,ctx){if(raw&&raw.status&&raw.data!==undefined&&raw.errors!==undefined)return raw;if(raw&&raw.ok===false)return fail(raw.error&&raw.error.code||ERRORS.EXECUTION_FAILED,raw.error&&raw.error.message||raw.reason||'Execution failed',{raw:clone(raw)});return result('success',raw,{correlationId:ctx&&ctx.correlationId,requestId:ctx&&ctx.requestId});}

  /* 78/79: dry-run/simulation */
  async function simulate(capability,input,ctx){const c=Object.assign({},ctx||{},{simulation:true});emit('simulation.started',{capability,input:clone(input)},{correlationId:c.correlationId,requestId:c.requestId,source:'simulation'});try{if(capability&&typeof capability.simulate==='function')return normalizeResult(await capability.simulate(input,c),c);if(capability&&typeof capability.preview==='function')return normalizeResult(await capability.preview(input,c),c);return result('simulated',{wouldExecute:true,capability:capability&&capability.id||null,input:clone(input)},{userMessage:'Simulation complete. No state was changed.'});}finally{emit('simulation.completed',{capability:capability&&capability.id||null},{correlationId:c.correlationId,requestId:c.requestId,source:'simulation'});}}

  /* 55/56: idempotency and trace */
  function beginTrace(intentObj,opts){const requestId=opts&&opts.requestId||uid('req'),correlationId=opts&&opts.correlationId||uid('corr'),actionId=opts&&opts.actionId||uid('action'),idempotencyKey=opts&&opts.idempotencyKey||null;const ctx={requestId,correlationId,intentId:intentObj.id,actionId,sessionId:intentObj.sessionId,idempotencyKey,startedAt:now(),signal:{cancelled:false}};return ctx;}
  function trace(ctx,patch){return Object.assign(ctx,patch||{},{updatedAt:now()});}
  function rememberIdempotency(key,value){if(!key)return;idempotency.set(String(key),clone(value));if(idempotency.size>MAX){idempotency.delete(idempotency.keys().next().value);}}
  function replayIdempotency(key){return key?idempotency.get(String(key))||null:null;}

  hydratePending();
  const api={version:VERSION,ERRORS,events:()=>clone(events),emit,intent,session:getSession,setSession,identity,Time,State,syncQueue,loadQueue,pending:pendingList,clearPending,requireConfirmation,policy,risk,operationClass,transaction,locks:{acquire:acquireLock,release:releaseLock},cancel,isCancelled,interrupt,adapters:{register:registerAdapter,get:adapter},dependencies,subscribe,on,scheduleJob,runJob,cancelJob,discover,normalizeResult,simulate,beginTrace,trace,rememberIdempotency,replayIdempotency,priorityForEvent};
  g.NoriOperatingProtocolV32=api;
  g.NoriState=State;
  g.NoriTime=Time;
  g.NoriIdentity={get:identity};
  g.NoriEventStreamV32={emit,on,subscribe,events:()=>clone(events)};
  emit('protocol.ready',{version:VERSION,features:['intent','session','pending','confirmation','rollback','idempotency','correlation','errors','cancellation','interrupts','locks','time','identity','platform','state','cache','conflict','sync','dependencies','reactions','background','discovery','results','operation-classes','dry-run','simulation','transactions']},{source:'operating-protocol'});
})(window);
