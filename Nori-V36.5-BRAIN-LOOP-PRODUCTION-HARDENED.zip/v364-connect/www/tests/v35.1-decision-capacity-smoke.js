const fs=require('fs'),vm=require('vm');
const context={console,Date,Math,JSON,Promise,setTimeout,clearTimeout};context.window=context;
context.fetch=async()=>({ok:true,json:async()=>({ok:true,context:{canonicalState:{state:{appData:{nori_command_assignments:[],nori_study_sessions:[],nori_calendar_events_v1:[],nori_voice_alarms:[],nori_eval_history_all_subjects:[]}}},stateVersion:1}})});
context.NoriOperatingProtocolV32={emit(){}};
context.NoriNavigationBrain={routeFor:()=> '#/time-tools',go(){}};
context.NoriOperativeV33={execute:async()=>({ok:true}),executeWorkflow:async()=>({ok:true})};
vm.createContext(context);vm.runInContext(fs.readFileSync(__dirname+'/../nori-decision-planner-v34.js','utf8'),context);
(async()=>{
 const P=context.NoriDecisionPlannerV34;
 const cases=[
  ['set a timer for 5 minutes','timer'],['start math speed for 10 problems','math_speed'],['stop stopwatch','time_stop'],
  ['schedule a chemistry alarm at 8 pm','alarm'],['start focus','focus'],['record chemistry result 85%','result'],
  ['create a physics assignment','assignment'],['study chemistry at 7 pm','study'],['open my results','navigate']
 ];
 for(const [text,kind] of cases){const p=await P.decide(text,{});if(p.kind!==kind)throw new Error(text+' classified as '+p.kind+' expected '+kind);if(!p.executable)throw new Error(text+' was not executable');}
 console.log('V35.1 DECISION CAPACITY SMOKE: PASS');
})().catch(e=>{console.error(e);process.exit(1)});
