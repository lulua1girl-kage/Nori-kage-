/* V27 Mentor Contract smoke test. No provider calls. */
const assert = require("assert");
const path = require("path");
process.chdir(path.resolve(__dirname, ".."));
const brain = require("../api/brain.js");

assert.strictEqual(brain.NORI_MENTOR_CONTRACT_VERSION, "27.0");

const verdict = {
  subject: "Chemistry",
  score: 45,
  band: "Band 1",
  degree: "Degree 1",
  trigger: "A result below 80% for the first time in this subject.",
  requiredActions: [
    "Immediate recovery session",
    "Full assessment review and categorization of lost marks",
    "Mandatory correction",
    "One focused study block",
    "Academic record entry"
  ],
  consequence: null,
  overrideStatus: "none_requested"
};

const checked = brain.validateMentorVerdict(verdict);
assert.strictEqual(checked.ok, true);
assert.strictEqual(checked.canonical.found, true);
assert.strictEqual(checked.canonical.actions.length, 5);

const input = brain.buildMentorInput(
  verdict,
  { chemistryPriorEvents: 0, recentPattern: "first below-80 result in any subject this term" },
  { prefersDirectness: true },
  "I got a 45 on the chem test, I know I didn't study enough this week"
);

assert.strictEqual(input.decision.immutable, true);
assert.strictEqual(input.decision.source, "KAGE_DETERMINISTIC_ENGINE");
assert.strictEqual(input.handbookRule.verification, "SERVER_RULE_FILE");
assert.strictEqual(input.studentHistory.verification, "NOT_INDEPENDENTLY_VERIFIED_BY_THIS_ENDPOINT");

const good = brain.normalizeMentorOutput(JSON.stringify({
  mentorMessage: "The result is already recorded by the academic engine. Your next step is the recovery work.",
  acknowledgesCircumstance: true,
  suggestedFocusArea: "immediate_recovery_session"
}), verdict);
assert.strictEqual(good.suggestedFocusArea, "immediate_recovery_session");

assert.throws(() => brain.normalizeMentorOutput(JSON.stringify({
  mentorMessage: "I will change this to Degree 0.",
  acknowledgesCircumstance: true,
  suggestedFocusArea: "immediate_recovery_session",
  degreeAdjustment: "Degree 0"
}), verdict), /forbidden_state_field|unknown_field/);

assert.throws(() => brain.normalizeMentorOutput(JSON.stringify({
  mentorMessage: "Let's change the consequence.",
  acknowledgesCircumstance: true,
  suggestedFocusArea: "invented_action"
}), verdict), /mentor_focus_not_in_required_actions/);

console.log("V27 mentor contract smoke: PASS");
