const fs=require('fs');
const root=__dirname+'/..';
for(const f of ['nori-operational-feature-center-v341.js','nori-system-directory-v34.js','nori-native-bridge.js','nori-blocker.js']){
 const s=fs.readFileSync(root+'/'+f,'utf8');
 if(!s.trim()) throw new Error(f+' empty');
}
const idx=fs.readFileSync(root+'/index.html','utf8');
if(!idx.includes('nori-operational-feature-center-v341.js')) throw new Error('feature center not loaded');
if(!idx.includes('nori-operational-feature-center-v341.css')) throw new Error('feature center css not loaded');
const main=fs.readFileSync(root+'/../android/app/src/main/java/com/nori/jarvis/MainActivity.java','utf8');
if(!main.includes('registerPlugin(NoriDevicePlugin.class)')) throw new Error('NoriDevice not registered');
const alarm=fs.readFileSync(root+'/../android/app/src/main/java/com/nori/jarvis/nori/android/alarm/NoriAlarmService.java','utf8');
if((alarm.match(/setAndAllowWhileIdle/g)||[]).length!==1) throw new Error('alarm scheduling branch malformed');
console.log('V34.1 operational completion smoke: PASS');
