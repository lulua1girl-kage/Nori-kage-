const fs=require('fs'), path=require('path');
const root=path.join(__dirname,'../..');
function ok(c,m){if(!c)throw new Error(m);}
const sync=fs.readFileSync(path.join(root,'www/nori-sync.js'),'utf8');
const gate=fs.readFileSync(path.join(root,'www/nori-auth-gate-v1.js'),'utf8');
const migration=fs.readFileSync(path.join(root,'supabase/migrations/007_nori_auth_profile_security.sql'),'utf8');
const index=fs.readFileSync(path.join(root,'www/index.html'),'utf8');
ok(sync.includes('auth.signUp')&&sync.includes('auth.signInWithPassword'),'Supabase email/password auth methods missing');
ok(sync.includes("from('profiles')")&&sync.includes('createPendingProfile'),'profile integration missing');
ok(gate.includes('window.NoriSyncAuth')&&gate.includes('signUp')&&gate.includes('signIn'),'auth gate missing signup/signin');
ok(migration.includes("'STUDENT', 'PENDING'"),'normal-user STUDENT provisioning missing');
ok(migration.includes("'ADMIN', 'APPROVED'"),'admin provisioning missing');
ok(migration.includes('ROLE_CHANGE_NOT_ALLOWED')&&migration.includes('ADMISSION_STATUS_CHANGE_NOT_ALLOWED'),'profile privilege protection missing');
ok(index.includes('nori-sync.js')&&index.includes('nori-auth-gate-v1.js'),'auth scripts not loaded');
console.log('V36.4 authentication smoke: PASS');
