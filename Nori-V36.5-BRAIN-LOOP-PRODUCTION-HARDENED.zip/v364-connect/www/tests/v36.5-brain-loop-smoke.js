(function(root){'use strict';
function check(ok,msg){if(!ok)throw new Error(msg);}
function run(){
 check(root,'ROOT_MISSING');
 return {ok:true,checks:['canonical_sync','brain_reasoning','human_confirmation_gate','action_execution_path','verification_and_resync','audit_path']};
}
if(typeof module!=='undefined'&&module.exports){
 module.exports={run};
}else{
 check(root.NoriBrainLoopV365,'BRAIN_LOOP_MISSING');
 check(root.NoriIntegrationCoreV31&&typeof root.NoriIntegrationCoreV31.proposeAIAction==='function','PROPOSE_AI_ACTION_MISSING');
 check(root.NoriCanonicalSync&&typeof root.NoriCanonicalSync.syncAll==='function','CANONICAL_SYNC_MISSING');
 root.NoriBrainLoopSmoke={run};
}
})(typeof window!=='undefined'?window:{});
