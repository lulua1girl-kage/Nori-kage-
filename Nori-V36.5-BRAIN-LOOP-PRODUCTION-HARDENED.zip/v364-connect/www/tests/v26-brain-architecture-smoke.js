/* V26 BRAIN ARCHITECTURE smoke test.
 *
 * This file used to be a byte-for-byte duplicate of
 * v28-explainability-review-smoke.js (a copy/paste leftover from a later
 * migration), which meant the actual V26 pipeline — processAcademicEvent,
 * Degree escalation, safetyGuard, override, awards — had silently lost all
 * test coverage while still showing green. Restored to test what its name
 * claims: the core Brain orchestration in brain-engine/brain.js.
 */
const assert = require("assert");
const path = require("path");
process.chdir(path.resolve(__dirname, "../.."));

const brain = require("../brain-engine/brain");
const { assertSafe, UnsafeConsequenceError } = require("../brain-engine/engines/safetyGuard");

// 1. Core pipeline: a low score with a genuine focus-mode breach should
//    classify as COMBINED, land on Degree 1 by default, and select both an
//    academic correction and a domain consequence — never invent either.
const result = brain.processAcademicEvent({
  subject: "Chemistry",
  assessment: {
    type: "unit_test",
    percentage: 62,
    missedConcepts: ["stoichiometry", "moles"],
    totalConceptsCovered: 8,
    carelessErrorCount: 0,
    applicationErrorCount: 1,
  },
  contextEvent: {
    domain: "digital_social",
    durationMinutes: 40,
    statedPurpose: "scrolling",
    isEmergency: false,
    wasAccidental: false,
    continuedAfterAwareness: true,
    reportedDifficultDay: false,
    evidenceSources: ["screen_time_log"],
  },
  history: { degree1EventsUnresolved: 0, degree1EventsTotal: 0, sameDomainRepeatCount: 0, degree2EventsTotal: 0 },
});

assert.strictEqual(result.academicResult.band, "D1-D", "62% should land in the D1-D band");
assert.strictEqual(result.degree, 1, "no Degree-2 history condition was met, so this must stay Degree 1");
assert.ok(result.academicCorrection, "a real academic band must always produce an academic correction");
assert.ok(Array.isArray(result.auditRecord.missedConcepts) && result.auditRecord.missedConcepts.length === 2);

// 2. Every consequence the pipeline actually selected must independently
//    pass safetyGuard — this re-checks the guarantee safetyGuard exists to
//    make, rather than trusting consequenceEngine called it correctly.
if (result.consequences.primary) assert.doesNotThrow(() => assertSafe(result.consequences.primary));
assert.doesNotThrow(() => assertSafe(result.academicCorrection));

// 3. safetyGuard must still reject an unsafe consequence even if something
//    upstream ever tried to hand it one directly — this is the guard's own
//    job, independent of whether the library is well-behaved.
assert.throws(
  () => assertSafe({ id: "cold_shower_punishment", domain: "digital_social", label: "Cold shower" }),
  UnsafeConsequenceError,
  "safetyGuard must block a banned-term consequence regardless of source"
);
assert.throws(
  () => assertSafe({ id: "x", domain: "digital_social", physical: true }),
  UnsafeConsequenceError,
  "safetyGuard must block anything explicitly flagged physical"
);

// 4. Degree escalation only fires when its entry conditions are actually
//    met — calling escalateToDegree3 must not escalate just because it was
//    called (this is the whole point of the entry-condition gate).
const notEligible = brain.escalateToDegree3(result.auditRecord.eventId, { degree1EventsUnresolved: 0, degree1EventsTotal: 0, sameDomainRepeatCount: 0 }, {});
assert.strictEqual(notEligible.success, false, "Degree 3 must not fire without real entry conditions");

// 5. Human Override: a bare "I don't want this" with no reason and no
//    evidence must be rejected, not quietly accepted.
const overrideDenied = brain.requestOverride(result.auditRecord.eventId, { reason: "", evidence: [] }, {});
assert.strictEqual(overrideDenied.success, true);
assert.strictEqual(overrideDenied.decision.outcome, "reject", "an override with no reason and no evidence must be rejected, not granted");

// 6. Award/merit ledger is caller-owned: granting an award the evidence
//    doesn't support must fail, and the same evidenceKey must never grant
//    an award twice.
const ledger = brain.createMeritLedger();
const scoreMerit = brain.grantScoreBandMerit(ledger, 95, "academic_score", "evt-test-1");
assert.ok(scoreMerit && scoreMerit.granted !== false, "a genuinely high score should be eligible for the score-band merit");
const dupe = brain.grantScoreBandMerit(ledger, 95, "academic_score", "evt-test-1");
assert.strictEqual(dupe.granted, false, "the same evidenceKey must not double-grant the same award");

console.log("V26 brain architecture smoke: PASS");
