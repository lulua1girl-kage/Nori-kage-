const fs=require('fs'),vm=require('vm');
const context={console,Date,Math,JSON,setTimeout,clearTimeout,setInterval,clearInterval,Promise,CustomEvent:function(t,d){this.type=t;this.detail=d}};
context.window=context;
context.document={readyState:'loading',addEventListener(){},getElementById(){return null}};
context.localStorage={_:{},getItem(k){return this._[k]??null},setItem(k,v){this._[k]=v},removeItem(k){delete this._[k]}};
context.dispatchEvent=()=>{};context.addEventListener=()=>{};
context.NoriOperatingProtocolV32={
 intent:(x)=>({id:'intent_test',...x}),beginTrace:()=>({requestId:'r',correlationId:'c',intentId:'i',actionId:'a'}),
 emit(){},session(){return {}},rememberIdempotency(){},replayIdempotency(){return null},isCancelled(){return false},interrupt(){}
};
context.NoriIntegrationCoreV31={dispatch:async()=>({status:'conversation'})};
context.NoriTimeToolsV35={
 watchState:()=>({status:'running',problemCount:10}),timerState:()=>null,
 stopStopwatch:(say)=>({ok:true,state:{status:'completed',problemCount:10},saidStop:say}),stopTimer:()=>({ok:true})
};
vm.createContext(context);
vm.runInContext(fs.readFileSync(__dirname+'/../nori-operative-v33.js','utf8'),context);
(async()=>{
  const r=await context.NoriOperativeV33.handleText('stop',{sessionId:'default'});
  if(!r.ok||r.control!=='math_stopwatch')throw new Error('plain stop did not stop active stopwatch');
  const caps=context.NoriOperativeV33.capabilities();
  if(caps.length<20)throw new Error('capability registry unexpectedly small');
  for(const c of caps){if(!c.id||!c.owner||!c.risk)throw new Error('invalid capability contract: '+c.id)}
  console.log('V35.1 RELIABILITY SMOKE: PASS');
})().catch(e=>{console.error(e);process.exit(1)});
