/* V28 explainability + rule-review smoke test. */
const assert = require("assert");
const path = require("path");
process.chdir(path.resolve(__dirname, ".."));

const brain = require("../api/brain.js");
const explain = require("../brain-engine/engines/explainabilityEngine");
const review = require("../brain-engine/engines/ruleReviewEngine");

assert.strictEqual(brain.NORI_BRAIN_VERSION, "31");

const record = {
  eventId: "EVT-TEST-001",
  subject: "Chemistry",
  score: 45,
  band: "Band 1",
  failureType: "academic_problem",
  degree: 1,
  degreeReasons: ["default_entry_no_degree2_condition_met"],
  appliedConsequence: null,
  academicCorrection: "academic-correction-1",
  overrideStatus: "none_requested"
};

const explanation = brain.explainDecision(record);
assert.strictEqual(explanation.readOnly, true);
assert.strictEqual(explanation.eventId, "EVT-TEST-001");
assert.ok(explanation.steps.some(s => s.stage === "rule"));
assert.ok(explanation.steps.some(s => s.stage === "degree"));
assert.ok(explanation.statement.includes("Chemistry"));
assert.ok(explanation.statement.includes("45%"));

const events = [
  {eventId:"1", subject:"Chemistry", primaryDomain:"academic", appliedConsequence:"academic-correction-1", recoveryStatus:"failed"},
  {eventId:"2", subject:"Chemistry", primaryDomain:"academic", appliedConsequence:"academic-correction-1", recoveryStatus:"unresolved"},
  {eventId:"3", subject:"Math", primaryDomain:"academic", appliedConsequence:"academic-correction-1", recoveryStatus:"complete"}
];

const flags = brain.buildRuleTuningReview(events);
assert.strictEqual(flags.ownerApprovalRequired, true);
assert.ok(flags.flags.length >= 1);
const correctionFlag = flags.flags.find(f => f.interventionId === "academic-correction-1");
assert.ok(correctionFlag);
assert.ok(correctionFlag.prohibitedAutomaticActions.includes("rewrite_rule"));

const safe = explain.explainDecision(record);
assert.strictEqual(safe.readOnly, true);

console.log("V28 explainability + rule-review smoke: PASS");
