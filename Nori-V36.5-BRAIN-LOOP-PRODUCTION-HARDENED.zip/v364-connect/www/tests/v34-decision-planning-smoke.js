/* V34 decision/planning smoke — no network, no DOM. */
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const context={console,Date,Math,fetch:async()=>{throw new Error('network not expected')}};context.window=context;vm.createContext(context);
vm.runInContext(fs.readFileSync(require('path').join(__dirname,'..','nori-decision-planner-v34.js'),'utf8'),context);
const P=context.NoriDecisionPlannerV34;assert(P&&P.version==='34');
let plan=P.planFor('Remind me to study Chemistry at 8 PM tomorrow',{appData:{nori_study_sessions:[],nori_calendar_events_v1:[],nori_voice_alarms:[],nori_command_assignments:[]}});assert(plan.kind==='alarm'&&plan.executable&&plan.actions[0].time==='20:00'&&plan.actions[0].date);
plan=P.planFor('Prepare my schedule for tomorrow and remind me to study Chemistry at 7 PM',{appData:{nori_study_sessions:[],nori_calendar_events_v1:[],nori_command_assignments:[]}});assert(plan.kind==='plan'&&plan.complex&&plan.actions.length>=2&&plan.requiresConfirmation);
plan=P.planFor('Move my Chemistry study session to 8 PM tomorrow',{appData:{nori_study_sessions:[{id:'s1',subject:'Chemistry',title:'Chemistry study',date:'2026-09-20',time:'19:00',duration:60}],nori_calendar_events_v1:[],nori_command_assignments:[]}});assert(plan.kind==='study_update'&&plan.executable&&plan.actions[0].type==='update_study_session');
plan=P.planFor('Open my Chemistry results',{appData:{}});assert(plan.kind==='navigate'&&plan.executable);
console.log('V34 DECISION/PLANNING SMOKE: PASS');
