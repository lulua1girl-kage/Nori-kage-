(function(){
  const fs=require('fs'), path=require('path');
  const root=path.join(__dirname,'..');
  function read(f){return fs.readFileSync(path.join(root,f),'utf8')}
  function assert(x,m){if(!x)throw new Error(m)}
  const sync=read('nori-canonical-sync-v1.js');
  const storage=read('nori-storage.js');
  const index=read('index.html');
  assert(sync.includes("'goals'"),'goals connector missing');
  ['assignments','assessments','study_sessions','calendar_events','alarms','mistakes','conversations','conversation_messages','notifications','recovery_records','action_audit'].forEach(t=>assert(sync.includes("'"+t+"'"),t+' connector missing'));
  assert(sync.includes('local_id'),'stable local identity mapping missing');
  assert(sync.includes('syncGoals')&&sync.includes('syncAssignments')&&sync.includes('syncStudy'),'core sync adapters missing');
  assert(sync.includes('syncAssessments')&&sync.includes('syncMistakes')&&sync.includes('syncRecovery')&&sync.includes('syncAudit'),'secondary sync adapters missing');
  assert(sync.includes('pullAll'),'canonical pull missing');
  assert(sync.includes('recordConversationTurn'),'conversation write bridge missing');
  assert(index.includes('nori-canonical-sync-v1.js'),'canonical sync script not loaded');
  assert(storage.includes('nori_command_assignments')&&storage.includes('nori_study_sessions'),'existing local systems remain intact');
  console.log('V36.4 canonical systems smoke: PASS');
})();
