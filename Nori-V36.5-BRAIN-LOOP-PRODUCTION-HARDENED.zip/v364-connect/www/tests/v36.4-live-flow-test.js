/* NORI V36.4 LIVE FLOW TEST
 * Run only after a real user is signed in. Creates one temporary assignment through
 * the real Nori action pipeline, verifies the canonical DB mirror, then cleans it up.
 * No password or privileged key is handled here.
 */
(function(g){'use strict';
  function assert(ok,msg){if(!ok)throw new Error(msg);}
  async function run(){
    const auth=g.NoriSyncAuth; assert(auth&&auth.configured&&auth.configured(),'AUTH_NOT_CONFIGURED');
    const sr=await auth.session(); const session=sr&&sr.data&&sr.data.session; assert(session&&session.user,'LOGIN_FAILED_OR_NO_SESSION');

    const profile=await auth.profile(); assert(profile&&profile.id===session.user.id,'PROFILE_MISSING_OR_MISMATCH');
    const role=String(profile.role||'STUDENT').toUpperCase();
    assert(['STUDENT','ADMIN','OWNER'].includes(role),'INVALID_PROFILE_ROLE');
    const adminCheck=role==='ADMIN'||role==='OWNER';
    if(adminCheck) assert(String(profile.admission_status).toUpperCase()==='APPROVED','ADMIN_NOT_APPROVED');

    assert(g.NoriAssistanceV36&&typeof g.NoriAssistanceV36.buildContext==='function','BRAIN_UNAVAILABLE');
    const brain=g.NoriAssistanceV36.buildContext();
    assert(brain&&typeof brain==='object','BRAIN_CONTEXT_FAILED');

    const sync=g.NoriCanonicalSync; assert(sync&&typeof sync.syncAll==='function','CANONICAL_SYNC_UNAVAILABLE');
    const synced=await sync.syncAll(); assert(synced&&synced.ok,'DATABASE_SYNC_FAILED');

    const core=g.NoriIntegrationCoreV31; assert(core&&typeof core.executeAIAction==='function','ACTION_ORCHESTRATOR_UNAVAILABLE');
    const title='[NORI LIVE TEST] '+new Date().toISOString();
    const action=await core.executeAIAction({type:'create_assignment',title,subject:'Nori System Test',due:new Date(Date.now()+86400000).toISOString(),reason:'V36.4 live flow verification'});
    assert(action&&action.ok,'ACTION_FAILED:'+((action&&action.reason)||'unknown'));
    const local=(typeof g.noriAssignmentsLoad==='function'?g.noriAssignmentsLoad():JSON.parse(localStorage.getItem('nori_command_assignments')||'[]'))||[];
    const created=Array.isArray(local)?local.find(x=>x&&x.title===title):null; assert(created&&created.id,'LOCAL_ACTION_VERIFICATION_FAILED');

    await sync.syncAll();
    const remote=await sync.getByLocalId('assignments',created.id); assert(remote&&remote.title===title,'DATABASE_ACTION_VERIFICATION_FAILED');
    const auditClient=sync.client(); const u=sync.user();
    const ar=await auditClient.from('action_audit').select('id,action_type,status,created_at').eq('user_id',u.id).order('created_at',{ascending:false}).limit(20);
    assert(!ar.error,'AUDIT_QUERY_FAILED');
    const auditFound=(ar.data||[]).some(x=>String(x.action_type||'').indexOf('action.executed')>=0 || String(x.action_type||'')==='system_event');

    // Cleanup only the temporary test record; retain the audit evidence.
    const del=await auditClient.from('assignments').delete().eq('id',remote.id).eq('user_id',u.id); assert(!del.error,'TEST_CLEANUP_DB_FAILED');
    const filtered=Array.isArray(local)?local.filter(x=>x&&x.id!==created.id):[];
    if(typeof g.noriSafeWrite==='function')g.noriSafeWrite('nori_command_assignments',filtered);else localStorage.setItem('nori_command_assignments',JSON.stringify(filtered));

    return {ok:true,flow:['LOGIN','PROFILE','ADMIN_CHECK','NORI_BRAIN','DATABASE','ACTION','VERIFICATION'],userId:session.user.id,role,adminCheck,brainContext:true,databaseSync:true,actionExecuted:true,localVerified:true,databaseVerified:true,auditObserved:auditFound,cleanup:true};
  }
  g.NoriLiveFlowTest={run};
})(window);
