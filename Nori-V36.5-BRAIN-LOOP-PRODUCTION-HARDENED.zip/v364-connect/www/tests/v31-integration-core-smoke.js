/* V31 integration-core smoke test — Node only, no Android/Supabase claim. */
const fs=require('fs'),vm=require('vm'),assert=require('assert');
const src=fs.readFileSync(__dirname+'/../nori-integration-core-v31.js','utf8');
const listeners={};
const local={};
const window={
  Capacitor:null,
  addEventListener:(t,f)=>(listeners[t]||(listeners[t]=[]).push(f)),
  dispatchEvent:(e)=>((listeners[e.type]||[]).forEach(f=>f(e))),
  NoriActionCoreV27:{
    makeProposal:(type,input)=>({id:'p1',type,input,status:'pending_confirmation',definition:{label:type}}),
    confirm:async()=>({ok:true,proposal:{operationId:'o1',execution:{ok:true}},verification:{ok:true}}),
    undo:async()=>({ok:true})
  },
  NoriNavigationBrain:{routeFor:(t)=>t.includes('calendar')?'#/calendar':null,go:()=>true,active:()=>({id:'calendar'})},
  noriStorageOnWrite:()=>{}
};
const context={window,document:{readyState:'complete'},setTimeout,clearTimeout,localStorage:{
 getItem:k=>local[k]??null,setItem:(k,v)=>{local[k]=String(v)},removeItem:k=>delete local[k]
},console,fetch:async()=>({ok:true,json:async()=>({})})};
context.global=window;
vm.runInNewContext(src,context,{filename:'nori-integration-core-v31.js'});
const core=window.NoriIntegrationCoreV31;
assert(core && core.version==='31.0');
assert(core.listCapabilities().some(x=>x.id==='alarms'));
assert(core.listCapabilities().some(x=>x.id==='navigation'));
assert.deepStrictEqual(core.normalizeIntent({text:'open calendar'}).route,'#/calendar');
(async()=>{
 const p=await core.proposeAction('schedule_alarm',{label:'Chemistry',date:'2026-09-20',time:'19:00',repeat:'none'});
 assert(p.ok && p.status==='confirmation_required' && p.proposal.id==='p1');
 const r=await core.confirmAction('p1');
 assert(r.ok);
 assert(core.events().some(e=>e.type==='action.proposed'));
 assert(core.events().some(e=>e.type==='action.executed'));
 console.log('V31 integration core smoke: PASS');
})().catch(e=>{console.error(e);process.exit(1)});
