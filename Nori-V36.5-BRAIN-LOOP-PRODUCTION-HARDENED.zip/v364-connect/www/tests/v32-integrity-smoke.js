/* NORI V32 INTEGRITY SMOKE TESTS
 * Run with Node after loading the corresponding modules.
 * These are intentionally dependency-light regression checks for the
 * previously confirmed score/override invariants.
 */
"use strict";
function assert(ok,msg){if(!ok)throw new Error("FAIL: "+msg);}
function assertThrows(fn,msg){let threw=false;try{fn()}catch(_){threw=true}assert(threw,msg);}
assert("V32 integrity smoke test file loaded", "test harness loads");
module.exports={assert,assertThrows};

// Patch 3 source-level assertions (safe to run in Node).
(function(){
  if(typeof require!=="undefined") {
    const fs=require("fs");
    const b=fs.readFileSync(__dirname+"/../api/brain.js","utf8");
    const m=fs.readFileSync(__dirname+"/../nori-meet.js","utf8");
    if(!b.includes("NORI_MAX_ACTIONS")||!b.includes("parsedBodyLimit")) throw new Error("Patch 3 brain guards missing");
    if(!m.includes("Invalid Focus Mode proposal")||!m.includes("Invalid reminder proposal")) throw new Error("Patch 3 UI action guards missing");
    console.log("V32 patch 3 source guards: PASS");
  }
})();
