const fs=require('fs'),vm=require('vm'),assert=require('assert');
const proto=fs.readFileSync(__dirname+'/../nori-operating-protocol-v32.js','utf8');
const core=fs.readFileSync(__dirname+'/../nori-integration-core-v31.js','utf8');
const v33=fs.readFileSync(__dirname+'/../nori-operative-v33.js','utf8');
const listeners={},local={};
const window={addEventListener:(t,f)=>(listeners[t]||(listeners[t]=[]).push(f)),dispatchEvent:e=>((listeners[e.type]||[]).forEach(f=>f(e))),NORI_API_BASE_URL:'https://test',NoriProductionAuth:{session:async()=>({data:{session:{access_token:'x',user:{id:'u'}}}})},NoriActionCoreV27:{parseText:()=>null},NoriNavigationBrain:{active:()=>({id:'home'})}};
const context={window,document:{readyState:'complete'},setTimeout,clearTimeout,localStorage:{getItem:k=>local[k]??null,setItem:(k,v)=>local[k]=String(v),removeItem:k=>delete local[k]},console,fetch:async(url,opts)=>({ok:true,status:200,json:async()=>opts&&JSON.parse(opts.body||'{}').mode==='canonical_state'?{ok:true,context:{canonicalState:{state:{appData:{nori_command_assignments:[{id:'x',title:'Chemistry'}]}}},stateVersion:2}}:{ok:true,status:'committed',result:{id:'x'},appData:{nori_command_assignments:[{id:'x',title:'Chemistry'}]},canonicalVersion:2}})};
context.global=window;vm.runInNewContext(proto,context);vm.runInNewContext(core,context);vm.runInNewContext(v33,context);
(async()=>{
 const n=window.NoriOperativeV33;assert(n&&n.version==='33');
 const p=await n.execute('create_assignment',{title:'Chemistry',subject:'Chemistry'},{confirmed:false});assert(p.status==='confirmation_required'&&p.proposal.id);
 const r=await n.confirm(p.proposal.id);assert(r.ok&&r.status==='committed');
 const sim=await n.execute('create_assignment',{title:'X'},{confirmed:true,simulate:true});assert(sim.status==='simulated');
 const caps=n.capabilities();assert(caps.some(x=>x.id==='schedule_alarm')&&caps.some(x=>x.id==='record_result'));
 console.log('V33 operative smoke: PASS');
})().catch(e=>{console.error(e);process.exit(1)});
