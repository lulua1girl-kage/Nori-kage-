/* V36 Assistance Engine static/behavioral smoke test. */
const fs=require('fs'); const path=require('path');
const f=path.join(__dirname,'..','nori-assistance-engine-v36.js'); const s=fs.readFileSync(f,'utf8');
const required=['NoriAssistanceV36','setProfile','buildContext','academicDiagnosis','detectPatterns','resolveReference','missingForAction','createPlan','recordOutcome','evaluateOutcome','proactive','askModel','assist','dashboard','Human Override','canonical state','Never invent state'];
for(const x of required) if(!s.includes(x)) throw new Error('Missing '+x);
if(!fs.readFileSync(path.join(__dirname,'..','index.html'),'utf8').includes('nori-assistance-engine-v36.js')) throw new Error('Engine not loaded');
console.log('V36 assistance engine smoke passed:',required.length,'checks');
