/**
 * Nori V32 -> Native migration export helper.
 *
 * This file is intentionally standalone and does not replace nori-storage.js.
 * It only reads localStorage and returns an exact key/value snapshot.
 *
 * Usage from the V32 console:
 *   NoriV32NativeExport.create()
 *
 * The returned string can later be supplied to the native
 * V32DataImporter / NativeMigrationManager.
 */
(function (global) {
  "use strict";

  function create() {
    var data = {};
    for (var i = 0; i < localStorage.length; i++) {
      var key = localStorage.key(i);
      if (key == null) continue;
      data[key] = localStorage.getItem(key);
    }

    return JSON.stringify({
      schemaVersion: 1,
      exportedAt: Date.now(),
      source: "nori-v32-localStorage",
      data: data
    });
  }

  function download(filename) {
    var json = create();
    var blob = new Blob([json], { type: "application/json" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = filename || "nori-v32-data-export.json";
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  global.NoriV32NativeExport = {
    create: create,
    download: download
  };
})(window);
