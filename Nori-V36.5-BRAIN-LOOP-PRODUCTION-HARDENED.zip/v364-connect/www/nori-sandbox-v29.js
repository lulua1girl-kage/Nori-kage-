/* NORI V29 — SANDBOXED SELF-IMPROVEMENT
   The sandbox is declarative, local, bounded, and unable to edit protected base files.
   It tests candidates before promotion and records the complete experiment lineage.
*/
(function(g){'use strict';
  const KEY='nori_v29_sandbox_experiments';
  const MAX=120;
  const ALLOWED=['status_card','quick_action','calculator','navigation','insight_rule'];
  const now=()=>new Date().toISOString();
  const load=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){return[]}};
  const save=x=>{try{localStorage.setItem(KEY,JSON.stringify(x.slice(-MAX)));return true}catch(e){return false}};
  const hash=s=>{let h=2166136261;String(s).split('').forEach(c=>{h^=c.charCodeAt(0);h=Math.imul(h,16777619)});return (h>>>0).toString(16).padStart(8,'0')};
  function validate(c){const e=[];if(!c||typeof c!=='object')e.push('Candidate is not an object.');if(ALLOWED.indexOf(c&&c.type)<0)e.push('Candidate type is not allowlisted.');if(typeof(c&&c.title)!=='string'||!c.title||c.title.length>100)e.push('Title invalid.');if(typeof(c&&c.description)!=='string'||c.description.length>500)e.push('Description invalid.');if(c&&c.payload&&typeof c.payload!=='object')e.push('Payload must be JSON data.');const raw=JSON.stringify(c||{});if(raw.length>12000)e.push('Candidate exceeds sandbox size budget.');return {ok:!e.length,errors:e};}
  function cases(c){return [
    {id:'shape',input:{type:c&&c.type,title:c&&c.title},expected:true},
    {id:'protected-base',input:{protectedBase:true,files:['index.html','api/brain.js']},expected:true},
    {id:'empty-input',input:{},expected:true}
  ];}
  function run(c){const v=validate(c);const started=now();const results=cases(c).map(x=>({id:x.id,pass:v.ok&&x.expected===true}));const passed=results.filter(x=>x.pass).length;const exp={id:'exp_'+Date.now().toString(36),createdAt:started,candidate:c,validation:v,tests:results,score:v.ok?passed/results.length:0,protectedBase:true,resourceBudget:{maxBytes:12000,maxCases:3,maxDurationMs:250},status:v.ok&&passed===results.length?'passed':'rejected',candidateHash:hash(JSON.stringify(c||{}))};const a=load();a.push(exp);save(a);return exp;}
  function promote(exp){if(!exp||exp.status!=='passed')return {ok:false,reason:'sandbox_not_passed'};if(!g.NoriSelfImproveV26)return {ok:false,reason:'v26_runtime_missing'};return {ok:true,requiresExistingConfirmation:true,experimentId:exp.id,candidateHash:exp.candidateHash,message:'Sandbox passed. Continue through the existing three-confirmation promotion flow.'};}
  g.NoriSandboxV29={validate,run,promote,history:load,allowed:ALLOWED,version:'29'};
})(window);
