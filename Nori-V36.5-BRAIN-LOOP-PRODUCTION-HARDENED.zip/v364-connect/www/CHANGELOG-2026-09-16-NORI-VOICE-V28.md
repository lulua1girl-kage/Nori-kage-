# Nori V28 — Voice Engine Layer

## Added
- Local-first voice engine router.
- Browser/native speech preserved as the default fallback.
- Optional Piper local TTS adapter.
- Optional Coqui XTTS/XTTS-v2 local TTS adapter.
- Existing LiveKit Tutor and Command paths preserved.
- Engine health checks.
- Local voice configuration panel.
- Test voice action with automatic browser fallback.
- Avatar talking state remains synchronized across engines.
- Voice engine preference stored locally.
- Voice service adapter contract and licensing notes.

## Safety / integrity
- No model weights are bundled.
- No API keys are embedded.
- No unrestricted voice cloning workflow is added.
- XTTS licensing is explicitly treated as model-specific; CPML is not represented as unrestricted commercial-free licensing.
- LiveKit Cloud is not represented as free; self-hosted LiveKit remains optional.
- Existing V27 action/execution, protected base, memory, recovery, graphics, avatar, PiP, research and provider failover are preserved.
