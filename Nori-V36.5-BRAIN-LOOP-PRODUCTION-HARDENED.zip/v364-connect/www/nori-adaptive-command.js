/* NORI ADAPTIVE COMMAND — local-first command layer.
 * Fast deterministic actions stay local; AI is reserved for complex reasoning.
 * Human Override remains above automation. No physical-punishment logic here.
 */
(function(g){
  'use strict';
  const CFG_KEY='nori_adaptive_command_v1';
  const VERIFY_KEY='nori_execution_verification_v1';
  const EXCEPTION_KEY='nori_context_exceptions_v1';
  const TASK_APP_RULES=[
    {words:['wps','document','essay','write','assignment','notes','report','pdf'],apps:['cn.wps.moffice_eng','com.google.android.apps.docs.editors.docs','com.google.android.apps.docs']},
    {words:['research','source','article','web','find','lookup'],apps:['browser']},
    {words:['video','lecture','lesson'],apps:['com.google.android.youtube']}
  ];
  const load=(k,d)=>{try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}};
  const save=(k,v)=>{try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}};
  const arr=k=>{const v=load(k,[]);return Array.isArray(v)?v:[]};
  const now=()=>new Date();
  const today=()=>now().toISOString().slice(0,10);
  const uid=p=>p+'_'+Date.now()+'_'+Math.random().toString(36).slice(2,7);
  function results(){
    const all=typeof noriHistoryLoadAll==='function'?noriHistoryLoadAll():{}; const out=[];
    Object.keys(all||{}).forEach(s=>(all[s]||[]).forEach(r=>{if(typeof r.score==='number')out.push({subject:s,score:r.score,date:r.date||''})}));
    return out.sort((a,b)=>String(b.date).localeCompare(String(a.date)));
  }
  function assignments(){return typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():arr('nori_command_assignments')}
  function exams(){return arr('nori_exams')}
  function sessions(){return arr('nori_study_sessions')}
  function openAssignments(){return assignments().filter(x=>x.status!=='done')}
  function daysUntil(date){return Math.ceil((new Date(String(date)+'T23:59:59')-now())/86400000)}
  function deadlinePressure(){
    const open=openAssignments(), es=exams().filter(e=>e.date&&daysUntil(e.date)>=0).map(e=>({type:'exam',days:daysUntil(e.date),title:e.title,subject:e.subject}));
    const as=open.filter(x=>x.due).map(x=>({type:'assignment',days:daysUntil(x.due),title:x.title,subject:x.subject}));
    const items=es.concat(as).sort((a,b)=>a.days-b.days); let score=0;
    items.forEach(x=>{if(x.days<=0)score+=40;else if(x.days<=2)score+=30;else if(x.days<=7)score+=18;else if(x.days<=14)score+=8});
    score+=Math.min(30,open.length*4);
    return {score:Math.min(100,score),level:score>=70?'HIGH':score>=35?'MEDIUM':'LOW',items:items.slice(0,5)};
  }
  function currentContext(){return typeof noriGetProtectionContext==='function'?noriGetProtectionContext():{mode:'normal',reason:'No active protection context.'}}
  function currentTask(){
    const c=currentContext();
    if(c.study)return {title:c.study.topic||'Study session',subject:c.study.subject||'Academic',minutes:c.study.minutes||45,source:'study'};
    const a=openAssignments().sort((x,y)=>String(x.due||'9999').localeCompare(String(y.due||'9999')))[0];
    if(a)return {title:a.title,subject:a.subject||'Academic',minutes:Number(a.minutes||45),source:'assignment',id:a.id};
    const e=exams().filter(x=>x.date&&daysUntil(x.date)>=0).sort((a,b)=>daysUntil(a.date)-daysUntil(b.date))[0];
    if(e)return {title:'Prepare: '+e.title,subject:e.subject||'Academic',minutes:45,source:'exam',id:e.id};
    return null;
  }
  function taskAppPermissions(task){
    if(!task)return [];
    const text=(String(task.title)+' '+String(task.subject)).toLowerCase();
    const found=[]; TASK_APP_RULES.forEach(r=>{if(r.words.some(w=>text.includes(w)))r.apps.forEach(a=>{if(!found.includes(a))found.push(a)})});
    return found;
  }
  function classifyFailure(input){
    const x=String(input||'').toLowerCase();
    if(/emergency|unsafe|health|family|urgent/.test(x))return {code:'safety_or_emergency',label:'Safety / emergency',next:'Human Override: stabilize first.'};
    if(/parent|family|appointment|unexpected|interrupted|visitor|travel|schedule/.test(x))return {code:'contextual_disruption',label:'Contextual disruption',next:'Repair the schedule; do not treat this as ordinary avoidance.'};
    if(/tired|sleep|exhaust|overload|too much|burnout/.test(x))return {code:'capacity_limit',label:'Capacity limitation',next:'Reduce the immediate demand and rebuild a workable block.'};
    if(/phone|instagram|pinterest|youtube|tiktok|distract|scroll|avoid|procrast/.test(x))return {code:'avoidance_or_distraction',label:'Avoidance / distraction',next:'Restore the smallest meaningful action.'};
    return {code:'unknown',label:'Insufficient evidence',next:'Ask for context before escalating.'};
  }
  function exception(task,kind,minutes){
    const rows=arr(EXCEPTION_KEY).filter(x=>x.expiresAt>Date.now());
    const row={id:uid('exception'),task:task||null,kind:kind||'necessary',createdAt:Date.now(),expiresAt:Date.now()+Math.max(1,minutes||5)*60000};
    rows.push(row);save(EXCEPTION_KEY,rows);return row;
  }
  function verify(sessionId,status,note){
    const rows=arr(VERIFY_KEY);const row={id:uid('verify'),sessionId,status,note:note||'',at:new Date().toISOString()};rows.push(row);save(VERIFY_KEY,rows.slice(-300));return row;
  }
  function fastStart(task){
    if(!task)return {ok:false,reason:'No task available.'};
    const s=sessions();const item={id:uid('study'),subject:task.subject||'Academic',topic:task.title||'Study',minutes:Number(task.minutes||45),date:today(),status:'active',startedAt:new Date().toISOString(),source:'adaptive_command'};
    s.push(item);save('nori_study_sessions',s);
    try{if(typeof noriBlockerSetSmartContext==='function')noriBlockerSetSmartContext();}catch(e){}
    return {ok:true,session:item};
  }
  function decide(){
    if(window.noriAdaptiveKageV19){
      const live=window.noriAdaptiveKageV19.live();
      const n=live.nextMove;
      return {action:n.action,title:n.task?('Your next move: '+n.task.subject+' — '+n.task.topic):n.action==='protect_sleep'?'Protect sleep':n.reason,reason:n.reason,task:n.task,confidence:n.priority>=80?'high':n.priority>=55?'medium':'low',adaptiveV19:live,context:n.context};
    }
    const c=currentContext(),task=currentTask(),pressure=deadlinePressure(),active=sessions().find(s=>s.status==='active'&&s.date===today()),
      result=results()[0],open=openAssignments();
    if(c.mode==='sleep')return {action:'protect_sleep',title:'Protect sleep',reason:c.reason,task:null,confidence:'high'};
    if(active)return {action:'continue',title:'Continue current study',reason:'An active study session already exists.',task:active,confidence:'high'};
    if(pressure.level==='HIGH'&&task)return {action:'start',title:'Start the highest-pressure task',reason:'Deadline pressure is high; the next meaningful action is to begin '+task.title+'.',task,confidence:'high'};
    if(task)return {action:'start',title:'Start the next academic task',reason:'Nori found a concrete unfinished objective.',task,confidence:'high'};
    if(result&&result.score<80)return {action:'review',title:'Review '+result.subject,reason:'The latest recorded result is below the current target.',task:{title:'Review '+result.subject,subject:result.subject,minutes:45},confidence:'medium'};
    if(open.length)return {action:'organize',title:'Choose an unfinished task',reason:'There are unfinished academic items but no active session.',task:null,confidence:'medium'};
    return {action:'plan',title:'Create the next study block',reason:'No immediate unfinished task is available.',task:null,confidence:'medium'};
  }
  function explain(d){return {action:d.action,title:d.title,reason:d.reason,confidence:d.confidence,context:currentContext(),pressure:deadlinePressure(),task:d.task,allowedApps:taskAppPermissions(d.task)}}
  function render(){
    const wrap=noriEl('div',{class:'nori-command-wrap nori-suite-screen'});
    if(typeof noriRenderCommandHeader==='function')wrap.appendChild(noriRenderCommandHeader(false));
    if(typeof noriRenderSuiteCrumb==='function')wrap.appendChild(noriRenderSuiteCrumb('Adaptive Command'));
    const d=decide(), e=explain(d), p=e.pressure;
    const card=noriEl('section',{class:'nori-section-card'});card.appendChild(noriEl('div',{class:'nori-adaptive-kicker',text:'LOCAL-FIRST DECISION'}));
    card.appendChild(noriEl('h1',{class:'nori-adaptive-title',text:d.title}));
    card.appendChild(noriEl('p',{class:'nori-brief-main',text:d.reason}));
    const meta=noriEl('div',{class:'nori-brief-grid'});meta.appendChild(noriEl('div',{text:'Mode: '+(e.context.mode||'normal').toUpperCase()}));meta.appendChild(noriEl('div',{text:'Pressure: '+p.level+' ('+p.score+'/100)'}));meta.appendChild(noriEl('div',{text:'Confidence: '+String(d.confidence).toUpperCase()}));card.appendChild(meta);
    const actions=noriEl('div',{class:'nori-inline-actions'});
    if(d.task)actions.appendChild(noriEl('button',{class:'nori-btn nori-btn-primary',text:'START NOW'})).addEventListener('click',()=>{const r=fastStart(d.task);if(r.ok){alert('Started: '+d.task.title);noriRoute()}else alert(r.reason)});
    actions.appendChild(noriEl('button',{class:'nori-btn nori-btn-ghost',text:'WHY?'})).addEventListener('click',()=>alert(d.reason+'\n\nMode: '+e.context.mode+'\nConfidence: '+d.confidence));
    actions.appendChild(noriEl('button',{class:'nori-btn nori-btn-ghost',text:'NECESSARY'})).addEventListener('click',()=>{exception(d.task,'necessary',5);alert('5-minute necessary-access exception recorded.');});
    card.appendChild(actions);wrap.appendChild(card);
    const next=noriEl('section',{class:'nori-section-card'});next.appendChild(noriEl('h2',{text:'Task-Aware Access'}));
    const apps=e.allowedApps.length?e.allowedApps.join(', '):'No special app permission needed.';next.appendChild(noriEl('p',{text:apps}));next.appendChild(noriEl('small',{text:'Nori only uses this as a temporary task context; it does not permanently unlock distracting apps.'}));wrap.appendChild(next);
    const risk=noriEl('section',{class:'nori-section-card'});risk.appendChild(noriEl('h2',{text:'Predictive Protection'}));
    if(p.items.length){p.items.forEach(x=>{const r=noriEl('div',{class:'nori-signal-row'});r.appendChild(noriEl('span',{text:(x.subject||'')+' — '+x.title}));r.appendChild(noriEl('strong',{text:x.days<=0?'DUE':x.days+'d'}));r.appendChild(noriEl('small',{text:x.type.toUpperCase()}));risk.appendChild(r)})}else risk.appendChild(noriEl('p',{text:'No near-term deadline pressure detected.'}));wrap.appendChild(risk);
    const verifyCard=noriEl('section',{class:'nori-section-card'});verifyCard.appendChild(noriEl('h2',{text:'Execution Verification'}));verifyCard.appendChild(noriEl('p',{text:'After a block, record what actually happened. Nori uses this to adapt without assuming failure is laziness.'}));
    ['completed','partially_completed','interrupted','could_not_start'].forEach(st=>verifyCard.appendChild(noriEl('button',{class:'nori-btn nori-btn-ghost',text:st.replaceAll('_',' ').toUpperCase()})).addEventListener('click',()=>{verify(d.task&&d.task.id||null,st,'Recorded from Adaptive Command');alert('Recorded: '+st.replaceAll('_',' '));}));wrap.appendChild(verifyCard);
    const fail=noriEl('section',{class:'nori-section-card'});fail.appendChild(noriEl('h2',{text:'Failure Classification'}));const input=noriEl('input',{type:'text',placeholder:'Optional: describe why a task was missed'});fail.appendChild(input);fail.appendChild(noriEl('button',{class:'nori-btn nori-btn-ghost',text:'CLASSIFY'})).addEventListener('click',()=>{const r=classifyFailure(input.value);alert(r.label+'\n\n'+r.next)});wrap.appendChild(fail);
    if(typeof noriBottomNav==='function')wrap.appendChild(noriBottomNav('study'));return wrap;
  }
  g.noriAdaptiveCommand={decide,explain,deadlinePressure,currentTask,taskAppPermissions,classifyFailure,exception,verify,fastStart,render};
  g.noriRenderAdaptiveCommand=render;
  g.noriFastAction=function(action,payload){
    if(action==='start')return fastStart(payload||currentTask());
    if(action==='necessary')return exception(payload||null,'necessary',5);
    if(action==='verify')return verify(payload&&payload.sessionId||null,payload&&payload.status||'completed',payload&&payload.note||'');
    return {ok:false,reason:'Unknown local action.'};
  };
})(window);
