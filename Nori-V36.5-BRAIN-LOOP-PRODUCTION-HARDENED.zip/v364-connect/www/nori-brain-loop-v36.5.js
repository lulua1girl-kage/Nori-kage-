/* NORI BRAIN LOOP V36.5
 * Canonical control loop: sync -> observe -> reason -> propose -> human confirm -> execute -> verify -> sync -> audit.
 * The model may propose; it never receives authority to silently mutate canonical state.
 */
(function(g){'use strict';
  const VERSION='36.5';
  function id(p){return p+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,7);}
  function assert(x,m){if(!x)throw new Error(m);}
  async function run(message,opts){
    const auth=g.NoriSyncAuth; assert(auth&&typeof auth.session==='function','AUTH_UNAVAILABLE');
    const sr=await auth.session(); const session=sr&&sr.data&&sr.data.session; assert(session&&session.user,'AUTH_REQUIRED');
    const sync=g.NoriCanonicalSync; assert(sync&&typeof sync.syncAll==='function','CANONICAL_SYNC_UNAVAILABLE');
    const pre=await sync.syncAll(); assert(pre&&pre.ok,'CANONICAL_SYNC_FAILED');
    const brain=g.NoriAssistanceV36; assert(brain&&typeof brain.assist==='function','BRAIN_UNAVAILABLE');
    const context=await brain.buildContext();
    const assistance=await brain.assist(String(message||''),opts||{});
    const result={version:VERSION,correlationId:id('brain'),status:assistance.status||'assisted',stages:['observe','reason'],context,assistance,proposal:null,execution:null,verification:null,postSync:null};
    const action=assistance&&assistance.decision&&assistance.decision.action;
    if(!action || !action.type){
      result.status=assistance.status||'assisted';
      return result;
    }
    const core=g.NoriIntegrationCoreV31; assert(core&&typeof core.proposeAIAction==='function','ACTION_PROPOSER_UNAVAILABLE');
    const proposal=await core.proposeAIAction(action);
    assert(proposal,'ACTION_PROPOSAL_FAILED');
    result.proposal=proposal.proposal||proposal;
    result.status='awaiting_confirmation'; result.stages.push('propose');
    if(opts&&opts.autoConfirm===true){
      const pid=proposal.proposal&&proposal.proposal.id; assert(pid,'PROPOSAL_ID_MISSING');
      result.execution=await core.confirmAction(pid); result.stages.push('confirm','execute');
      result.verification=result.execution&&result.execution.verification||null;
      result.postSync=await sync.syncAll(); result.stages.push('verify','canonical_write','audit');
      result.status=result.execution&&result.execution.ok?'verified':'execution_failed';
    }
    return result;
  }
  async function confirm(proposalId){
    const core=g.NoriIntegrationCoreV31; assert(core&&typeof core.confirmAction==='function','ACTION_ORCHESTRATOR_UNAVAILABLE');
    const r=await core.confirmAction(proposalId); const sync=g.NoriCanonicalSync;
    const postSync=sync&&sync.syncAll?await sync.syncAll():{ok:false,reason:'SYNC_UNAVAILABLE'};
    return {ok:!!(r&&r.ok),execution:r,verification:r&&r.verification||null,postSync,stages:['confirm','execute','verify','canonical_write','audit']};
  }
  async function cancel(proposalId){
    const core=g.NoriIntegrationCoreV31; assert(core,'ACTION_ORCHESTRATOR_UNAVAILABLE');
    const pending=(core.pending&&core.pending())||[]; const p=pending.find(x=>x&&x.proposal&&x.proposal.id===proposalId);
    if(g.NoriActionCoreV27&&typeof g.NoriActionCoreV27.cancel==='function')g.NoriActionCoreV27.cancel(proposalId);
    if(g.NoriEventBusV31&&g.NoriEventBusV31.emit)g.NoriEventBusV31.emit('action.cancelled',{proposalId,actionType:p&&p.proposal&&p.proposal.type||null});
    return {ok:true,status:'cancelled',proposalId};
  }
  g.NoriBrainLoopV365={version:VERSION,run,confirm,cancel};
})(window);
