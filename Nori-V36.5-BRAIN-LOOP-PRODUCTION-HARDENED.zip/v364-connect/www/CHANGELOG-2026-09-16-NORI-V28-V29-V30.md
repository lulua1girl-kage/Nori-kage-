# Nori KAGE — V28/V29/V30 Cumulative Upgrade

## V28 — Verification + Rollback
- Added independent operation integrity checks.
- Reconciles executed operations and reversible snapshots.
- Re-verifies operation records without changing the V27 action layer.
- Rollback remains routed through the existing deterministic V27 compensating restore path.
- Failed verification is never represented as success.

## V29 — Sandboxed Self-Improvement
- Added bounded declarative sandbox experiments.
- Protected base remains outside the writable extension layer.
- Candidate size, type, case count and execution budget are bounded.
- Every experiment gets an ID, hash, test results and status.
- Promotion is separated from candidate generation.
- Existing V26 three-confirmation flow remains the final installation gate.

## V30 — Advanced Learning / Adaptation
- Added experience ledger from verified local outcomes.
- Repeated evidence can produce a candidate adaptation.
- Promotion gates: local repair, held-out-style transfer, no critical regression, then human promotion.
- Promoted adaptations are stored as local verified skills, not foundation-model weight changes.
- Skills can be rolled back independently.
- No automatic unrestricted source editing.
- No physical-punishment logic, covert recording or surveillance added.

## Preservation
- V26 UI, graphics, avatar, voice/Piper/XTTS/LiveKit bridge, PiP, memory, recovery, research, provider failover, self-improvement runtime, visual generation and service worker preserved.
- V27 deterministic action execution, confirmation, verification and undo preserved.
