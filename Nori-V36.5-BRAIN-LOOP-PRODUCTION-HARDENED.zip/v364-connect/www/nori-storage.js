/* ==========================================================================
   NORI — STORAGE LAYER
   ==========================================================================
   Single source of truth for every localStorage read/write in this app.
   Load this file FIRST, before nori-phase-data.js, nori-phase-app.js, and
   every AI feature file — they all call into these functions instead of
   keeping their own copies. Before this file existed, subject-result
   history alone had two separate, independently-maintained
   implementations (one in nori-ai-evaluate.js, one in nori-meet.js) both
   writing the same key — exactly the drift risk this file removes.

   Nothing here renames any existing key. This is pure consolidation, not
   a migration — data already saved on a real device keeps working
   exactly as it did before.
   ========================================================================== */

const NORI_STORAGE_SCHEMA_VERSION = 1;

/* ---------------- safe read/write — one corrupted key must never crash the app ---------------- */

function noriSafeParse(raw, fallback) {
  if (raw === null || raw === undefined) return fallback;
  try {
    const parsed = JSON.parse(raw);
    return (parsed === null || parsed === undefined) ? fallback : parsed;
  } catch (err) {
    console.warn("Nori storage: recovered from corrupted JSON with a fallback value:", err.message);
    return fallback;
  }
}

function noriSafeWrite(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    NORI_STORAGE_WRITE_HOOKS.forEach(function (hook) {
      try { hook(key, value); } catch (hookErr) { console.error("Nori storage: a write hook threw:", hookErr.message); }
    });
    return true;
  } catch (err) {
    // Most likely QuotaExceededError — surface it rather than silently losing data.
    console.error("Nori storage: write failed for \u201c" + key + "\u201d:", err.message);
    return false;
  }
}

// Every write in this app funnels through noriSafeWrite (confirmed: every
// other write function in this file calls it, nothing writes to
// localStorage directly anywhere else). That means anything that needs to
// react to writes — like nori-sync.js pushing changes to the cloud — can
// register here ONCE and see every write across the whole app, instead of
// hooking dozens of individual call sites.
const NORI_STORAGE_WRITE_HOOKS = [];
function noriStorageOnWrite(hookFn) {
  NORI_STORAGE_WRITE_HOOKS.push(hookFn);
}

/* ---------------- Phase form storage (table-log / snapshot-log / pageFields) ---------------- */

function noriStorageKey(phaseId, systemId, formId) {
  return "nori_phase_" + phaseId + "_" + systemId + "_" + formId;
}

function noriLoadEntries(storageKey) {
  return noriSafeParse(localStorage.getItem(storageKey), []);
}

function noriSaveEntries(storageKey, entries) {
  return noriSafeWrite(storageKey, entries);
}

function noriLoadPageFields(storageKey) {
  return noriSafeParse(localStorage.getItem(storageKey + "_pagefields"), {});
}

function noriSavePageFields(storageKey, fields) {
  return noriSafeWrite(storageKey + "_pagefields", fields);
}

/* ---------------- Subject result history (Result System + Award System) ---------------- */

const NORI_HISTORY_KEY = "nori_eval_history_all_subjects";
const NORI_HISTORY_CAP = 10;

function noriHistoryLoadAll() {
  return noriSafeParse(localStorage.getItem(NORI_HISTORY_KEY), {});
}

function noriHistoryAppend(subject, record) {
  const all = noriHistoryLoadAll();
  if (!all[subject]) all[subject] = [];
  all[subject].push(record);
  if (all[subject].length > NORI_HISTORY_CAP) all[subject] = all[subject].slice(-NORI_HISTORY_CAP);
  return noriSafeWrite(NORI_HISTORY_KEY, all);
}

/* ---------------- Human Override claim history ---------------- */

const NORI_OVERRIDE_HISTORY_KEY = "nori_override_history_all_subjects";
const NORI_OVERRIDE_HISTORY_CAP = 8;

function noriOverrideHistoryLoadAll() {
  return noriSafeParse(localStorage.getItem(NORI_OVERRIDE_HISTORY_KEY), {});
}

function noriOverrideHistoryAppend(subject, record) {
  const all = noriOverrideHistoryLoadAll();
  if (!all[subject]) all[subject] = [];
  all[subject].push(record);
  if (all[subject].length > NORI_OVERRIDE_HISTORY_CAP) all[subject] = all[subject].slice(-NORI_OVERRIDE_HISTORY_CAP);
  return noriSafeWrite(NORI_OVERRIDE_HISTORY_KEY, all);
}

/* ---------------- Disciplinary breach history ---------------- */

const NORI_BREACH_HISTORY_KEY = "nori_breach_history_by_category";
const NORI_BREACH_HISTORY_CAP = 8;

function noriBreachHistoryLoadAll() {
  return noriSafeParse(localStorage.getItem(NORI_BREACH_HISTORY_KEY), {});
}

function noriBreachHistoryAppend(category, record) {
  const all = noriBreachHistoryLoadAll();
  if (!all[category]) all[category] = [];
  all[category].push(record);
  if (all[category].length > NORI_BREACH_HISTORY_CAP) all[category] = all[category].slice(-NORI_BREACH_HISTORY_CAP);
  return noriSafeWrite(NORI_BREACH_HISTORY_KEY, all);
}

/* ---------------- command center assignments ---------------- */
const NORI_ASSIGNMENTS_KEY = "nori_command_assignments";
function noriAssignmentsLoad() {
  const items = noriSafeParse(localStorage.getItem(NORI_ASSIGNMENTS_KEY), []);
  return Array.isArray(items) ? items : [];
}
function noriAssignmentsSave(items) { return noriSafeWrite(NORI_ASSIGNMENTS_KEY, items); }
function noriAssignmentAdd(item) {
  const items = noriAssignmentsLoad();
  const row = Object.assign({ id: "a_" + Date.now() + "_" + Math.random().toString(36).slice(2,7), status: "open", createdAt: new Date().toISOString() }, item || {});
  items.push(row); noriAssignmentsSave(items); return row;
}
function noriAssignmentUpdate(id, patch) {
  const items = noriAssignmentsLoad(); const i = items.findIndex(x => x.id === id);
  if (i < 0) return null; items[i] = Object.assign({}, items[i], patch || {}, { updatedAt: new Date().toISOString() });
  noriAssignmentsSave(items); return items[i];
}
function noriAssignmentDelete(id) {
  return noriAssignmentsSave(noriAssignmentsLoad().filter(x => x.id !== id));
}

/* ---------------- daily routine: exercise + shower ---------------- */
// Deliberately minimal, per the design principle this was built from:
// support, not discipline. No scoring, no streaks, no points, no
// verification of any kind — planned/completed/skipped/rescheduled is
// the entire model. Missing one is never written anywhere near the
// breach/history systems above; this is its own small, low-stakes space.

const NORI_ROUTINE_KEY = "nori_daily_routine";

function noriRoutineToday() {
  return new Date().toISOString().slice(0, 10);
}

function noriRoutineLoad() {
  const today = noriRoutineToday();
  const all = noriSafeParse(localStorage.getItem(NORI_ROUTINE_KEY), {});
  if (!all[today]) all[today] = { exercise: "planned", shower: "planned" };
  return all[today];
}

// item: "exercise" | "shower". status: "planned" | "completed" | "skipped" | "rescheduled"
function noriRoutineSet(item, status) {
  const today = noriRoutineToday();
  const all = noriSafeParse(localStorage.getItem(NORI_ROUTINE_KEY), {});
  if (!all[today]) all[today] = { exercise: "planned", shower: "planned" };
  all[today][item] = status;
  noriSafeWrite(NORI_ROUTINE_KEY, all);
  return all[today];
}

/* ---------------- user memory (things the student stated about themselves) ---------------- */
// Deliberately ONLY stores things the student actually said — a stated
// preference, a stated recurring pattern, a stated trait about themselves.
// It never stores anything the brain infers, guesses, or diagnoses on its
// own; api/brain.js's system prompt enforces that on the writing side, and
// nothing here trusts an item unless it went through that same path or was
// typed directly by the student.

const NORI_MEMORY_KEY = "nori_user_memory";
const NORI_MEMORY_CAP = 60;

function noriMemoryLoad() {
  return noriSafeParse(localStorage.getItem(NORI_MEMORY_KEY), { items: [] });
}

function noriMemorySaveAll(memory) {
  return noriSafeWrite(NORI_MEMORY_KEY, memory);
}

function noriMemoryAddItem(text, source) {
  const trimmed = (text || "").trim();
  if (!trimmed) return noriMemoryLoad();
  const memory = noriMemoryLoad();
  const dup = memory.items.some(function (it) { return it.text.toLowerCase() === trimmed.toLowerCase(); });
  if (dup) return memory;
  memory.items.push({ text: trimmed, date: new Date().toISOString().slice(0, 10), source: source || "user" });
  if (memory.items.length > NORI_MEMORY_CAP) memory.items = memory.items.slice(-NORI_MEMORY_CAP);
  noriMemorySaveAll(memory);
  return memory;
}

function noriMemoryRemoveItem(index) {
  const memory = noriMemoryLoad();
  memory.items.splice(index, 1);
  noriMemorySaveAll(memory);
  return memory;
}


/* ---------------- live command-suite data ---------------- */
function noriStudySessionsLoad(){ const x=noriSafeParse(localStorage.getItem("nori_study_sessions"),[]); return Array.isArray(x)?x:[]; }
function noriStudySessionsSave(x){ return noriSafeWrite("nori_study_sessions",x); }
function noriExamsLoad(){ const x=noriSafeParse(localStorage.getItem("nori_exams"),[]); return Array.isArray(x)?x:[]; }
function noriExamsSave(x){ return noriSafeWrite("nori_exams",x); }
function noriNotificationsLoad(){ const x=noriSafeParse(localStorage.getItem("nori_notifications"),[]); return Array.isArray(x)?x:[]; }
function noriNotificationsSave(x){ return noriSafeWrite("nori_notifications",x); }
function noriSystemEventsLoad(){ const x=noriSafeParse(localStorage.getItem("nori_system_events"),[]); return Array.isArray(x)?x:[]; }
function noriSystemEventsAppend(x){ const a=noriSystemEventsLoad(); a.push(x); return noriSafeWrite("nori_system_events",a); }

/* ---------------- discovery: every Nori key actually present right now ---------------- */
// Phase-form keys are dynamic (one per form), so this walks real
// localStorage rather than relying on a fixed list.

function noriDiscoverAllKeys() {
  const keys = [];
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.indexOf("nori_") === 0) keys.push(k);
  }
  return keys;
}

/* ---------------- export / import (backup) ---------------- */

function noriExportAllData() {
  const keys = noriDiscoverAllKeys();
  const dump = {};
  keys.forEach(function (k) { dump[k] = noriSafeParse(localStorage.getItem(k), null); });
  return { schemaVersion: NORI_STORAGE_SCHEMA_VERSION, exportedAt: new Date().toISOString(), data: dump };
}

function noriDownloadBackup() {
  const backup = noriExportAllData();
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "nori-backup-" + new Date().toISOString().slice(0, 10) + ".json";
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

// mode "merge" (default): only fills keys that don't already exist locally.
// mode "replace": overwrites everything present in the backup. Either way,
// keys NOT in the backup are never touched.
function noriImportBackup(backup, mode) {
  if (!backup || !backup.data) return { imported: 0, skipped: 0, error: "Not a valid Nori backup file." };
  mode = mode || "merge";
  let imported = 0, skipped = 0;
  Object.keys(backup.data).forEach(function (key) {
    const exists = localStorage.getItem(key) !== null;
    if (exists && mode === "merge") { skipped++; return; }
    noriSafeWrite(key, backup.data[key]);
    imported++;
  });
  return { imported: imported, skipped: skipped };
}

/* ---------------- storage health / size report ---------------- */

function noriStorageReport() {
  const keys = noriDiscoverAllKeys();
  let totalBytes = 0;
  const perKey = keys.map(function (k) {
    const raw = localStorage.getItem(k) || "";
    const bytes = raw.length * 2; // rough UTF-16 estimate
    totalBytes += bytes;
    return { key: k, bytes: bytes };
  }).sort(function (a, b) { return b.bytes - a.bytes; });
  return { totalKeys: keys.length, totalBytes: totalBytes, largest: perKey.slice(0, 5) };
}
