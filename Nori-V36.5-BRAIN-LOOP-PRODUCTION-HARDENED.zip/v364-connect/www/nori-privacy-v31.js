/* NORI V31 privacy/access rules. Client-side guardrails complement Android permissions. */
(function(g){'use strict';
  const RULES={camera:{background:false,requiresExplicitAction:true,permission:'while-in-use'},microphone:{background:false,requiresExplicitAction:true,permission:'while-in-use'},files:{background:false,requiresExplicitSelection:true},memory:{defaultMinimization:true,sensitiveByDefault:false},admin:{requiresOwnerSession:true,rawMediaExport:false}};
  function can(kind,ctx){ctx=ctx||{};const r=RULES[kind];if(!r)return false;if(r.background===false&&ctx.background)return false;if(r.requiresExplicitAction&&!ctx.explicitAction)return false;if(r.requiresExplicitSelection&&!ctx.userSelected)return false;if(kind==='admin'&&!ctx.ownerSession)return false;return true}
  function rules(){return JSON.parse(JSON.stringify(RULES))}
  g.NoriPrivacyV31={rules,can};
})(window);
