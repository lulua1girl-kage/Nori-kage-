/* ==========================================================================
   NORI — FEATURE FLAGS
   ==========================================================================
   One place to toggle what's actually available in a given build, instead
   of maintaining a separate stripped-down copy of the app (which would
   just recreate the same duplication problem the storage/speech/rules
   consolidation work in this project has been fixing all along). Flip a
   flag here, nothing else needs to change.

   Load this file FIRST, before everything else that reads it (right after
   nori-storage.js, before nori-native-bridge.js/nori-rules.js/nori-phase-
   app.js/nori-meet.js).

   CURRENT BUILD: integrated Nori with capability-specific availability.
   Individual features may be conditional on platform permissions or external
   services; availability is resolved by the operational feature center rather
   than a stale global OFF switch.
   ========================================================================== */

const NORI_FEATURES = {
  phaseForms: true,      // the 5-phase tracking system (Phase Forms hub card)
  currentState: true,    // progress map / dashboard (reads phaseForms + calculator data, so off alongside it)
  quickAddResult: true,  // Result System / Award System / Human Override calculators
  reportBreach: true,    // System Integrity / Disciplinary System
  aiChat: true,           // Meet Nori conversation + memory
  voice: true,            // mic input + spoken replies
  accountsSync: true,    // sign-in + multi-device sync
  focusMode: true,        // native app-blocking (Android only regardless)
  reminders: true,        // native alarm/reminder scheduling (Android only regardless)
  cameraVerification: true, // photo capture + AI image analysis for verification
  smartCommand: true,       // explainable daily planning from existing records
  adaptiveScheduling: true, // learns from recorded study duration/completion
  academicDiagnostic: true, // subject-level evidence and study-method diagnosis
  timeline: true,           // persistent system history view
  integrityAudit: true      // cross-feature integration checks
};
