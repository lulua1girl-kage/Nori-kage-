/* NORI BRAIN V13 — Fast, system-aware intelligence layer
   Memory 2.0+ • reasoning/uncertainty • system familiarity • fast local cache
   • self-check signals • academic model • local command handling.
   V12-compatible API; no sensitive memory, no hidden surveillance, Human Override preserved.
*/
(function(g){'use strict';
  var K={memory:'nori_brain_memory_v13',profile:'nori_academic_profile_v13',events:'nori_brain_events_v13',prefs:'nori_brain_prefs_v13'};
  var SECRET=/\b(sk-[A-Za-z0-9_-]{12,}|ghp_[A-Za-z0-9_]+|AIza[\w-]+|Bearer\s+\S+|password\s*=|token\s*=|secret\s*=)\b/i;
  var SENSITIVE=/(password|passcode|pin|api key|secret|token|bank|credit card|card number|address|location|medical|diagnos|medication|trauma|abuse|self[- ]?harm|suicide|sexual|private|family conflict|legal case)/i;
  var CATEGORY_WORDS={goals:['goal','target','aim','objective'],preferences:['prefer','preference','like','dislike','style'],projects:['project','app','build','system','nori','kage'],academic:['study','subject','exam','assignment','grade','school','physics','chemistry','biology','math','english'],system_configuration:['setting','configuration','mode','rule','provider','model','feature']};
  var stateCache={at:0,value:null}, profileCache={at:0,value:null}, memoryCache={at:0,value:null,index:null};
  var STATE_TTL=1500, PROFILE_TTL=4000, MEMORY_TTL=2500;
  var now=function(){return new Date().toISOString()};
  function load(k,fb){try{var x=JSON.parse(localStorage.getItem(k)||'null');return x==null?fb:x}catch(e){return fb}}
  function save(k,v){try{if(typeof noriSafeWrite==='function')return noriSafeWrite(k,v);localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function uid(p){return p+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8)}
  function text(x){return String(x==null?'':x).replace(/[\u0000-\u001F]/g,' ').replace(/\s+/g,' ').trim()}
  function tokens(s){return text(s).toLowerCase().split(/[^a-z0-9%]+/).filter(function(x){return x.length>1})}
  function redact(s){s=text(s);return SECRET.test(s)?'[redacted credential]':s}
  function clamp(n,a,b){return Math.max(a,Math.min(b,n))}
  function categoryFor(t,explicit){if(explicit&&CATEGORY_WORDS[explicit])return explicit;var s=t.toLowerCase();for(var k in CATEGORY_WORDS){if(CATEGORY_WORDS[k].some(function(w){return s.indexOf(w)>=0}))return k}return 'general'}
  function confidenceLabel(v){v=Number(v);return v>=0.85?'confirmed':v>=0.55?'likely':'uncertain'}

  /* ---------- Fast system familiarity ---------- */
  var SYSTEMS=[
    {id:'storage',name:'Nori Storage',role:'persistent local data and safe writes'},
    {id:'context',name:'Context Intelligence',role:'protection/context state and disruption awareness'},
    {id:'decision',name:'Decision Engine',role:'priority and Human Override-aware decisions'},
    {id:'rules',name:'KAGE Rules',role:'exam, award, override and system-integrity rules'},
    {id:'phase',name:'Phase System',role:'phase data, academic forms and progress'},
    {id:'command',name:'Command Suite',role:'assignments, tasks, results and command surfaces'},
    {id:'calendar',name:'Calendar',role:'dates, planning and deadlines'},
    {id:'alarm',name:'Smart Alarm',role:'alarm scheduling and voice-call interaction'},
    {id:'blocker',name:'Protection / Blocker',role:'focus protection and temporary access'},
    {id:'adaptive',name:'Adaptive Command',role:'contextual next move and deadline pressure'},
    {id:'brain',name:'Nori Brain',role:'memory, reasoning, uncertainty and academic intelligence'},
    {id:'conversation',name:'Conversation Layer',role:'intent, affect, thread continuity and anti-awkwardness'},
    {id:'visual',name:'Visual / Affect',role:'UI state and subtle Nori affect'},
    {id:'tier3',name:'Serious KAGE',role:'analytics, replanning, failure patterns, reports and audits'},
    {id:'tier4',name:'Advanced Orchestration',role:'research, RAG, multi-model routing and workflow planning'},
    {id:'voice',name:'Native Voice',role:'speech recognition, TTS and call-style interaction'},
    {id:'human_override',name:'Human Override',role:'human authority above optimization and disciplinary automation'}
  ];
  var SYSTEM_RULE='Human Override remains the highest authority; deterministic app engines own records; AI explains/recommends but does not invent state or silently execute side effects.';
  function systemFamiliarity(query){var q=tokens(query||'');var hits=SYSTEMS.map(function(s){var words=tokens(s.name+' '+s.role);var overlap=q.reduce(function(n,x){return n+(words.indexOf(x)>=0?1:0)},0);return {system:s,score:overlap}}).filter(function(x){return x.score>0}).sort(function(a,b){return b.score-a.score});return {systems:SYSTEMS,matched:hits.slice(0,5).map(function(x){return x.system}),principle:SYSTEM_RULE,version:'13'}}

  /* ---------- Memory 2.0+ ---------- */
  function memoryRows(force){
    var t=Date.now();if(!force&&memoryCache.value&&t-memoryCache.at<MEMORY_TTL)return memoryCache.value;
    var rows=load(K.memory,[]).filter(function(m){return m&&typeof m.text==='string'});
    try{if(typeof noriMemoryLoad==='function')(noriMemoryLoad().items||[]).forEach(function(m){if(!m||typeof m.text!=='string'||SENSITIVE.test(m.text)||SECRET.test(m.text))return;if(!rows.some(function(x){return x.text===m.text}))rows.push({id:m.id||uid('legacy'),text:m.text,source:'legacy_confirmed',createdAt:m.date||now(),updatedAt:m.date||now(),learnedAt:m.date||now(),importance:3,confidence:1,scope:'user',status:'confirmed',category:categoryFor(m.text)});});}catch(e){}
    rows.forEach(function(m){m.category=m.category||categoryFor(m.text,m.category);m.confidence=clamp(m.confidence==null?1:m.confidence,0,1);m.status=m.status||confidenceLabel(m.confidence);m.learnedAt=m.learnedAt||m.createdAt||now();m.updatedAt=m.updatedAt||m.createdAt||m.learnedAt;m.importance=clamp(Number(m.importance)||3,1,5)});
    memoryCache={at:t,value:rows,index:null};return rows;
  }
  function invalidateMemory(){memoryCache={at:0,value:null,index:null}}
  function memoryPolicy(t){t=redact(t);if(!t||SECRET.test(t))return {allow:false,reason:'secret'};if(SENSITIVE.test(t))return {allow:false,reason:'sensitive'};return {allow:true}}
  function addMemory(t,meta){t=text(t);var p=memoryPolicy(t);if(!p.allow)return {ok:false,reason:p.reason};meta=meta||{};var rows=memoryRows(true),n=t.toLowerCase();var existing=rows.find(function(m){return m.text.toLowerCase()===n});
    var item;
    if(existing){existing.updatedAt=now();existing.status='confirmed';existing.confidence=1;existing.learnedAt=existing.learnedAt||now();if(meta.category)existing.category=categoryFor(existing.text,meta.category);save(K.memory,rows);invalidateMemory();return {ok:true,duplicate:true,item:existing}}
    item={id:uid('mem'),text:t,source:meta.source||'user_confirmed',createdAt:now(),updatedAt:now(),learnedAt:meta.learnedAt||now(),importance:clamp(Number(meta.importance)||3,1,5),confidence:clamp(Number(meta.confidence)==null?1:Number(meta.confidence),0,1),scope:meta.scope||'user',status:meta.status||confidenceLabel(meta.confidence==null?1:Number(meta.confidence)),category:categoryFor(t,meta.category),tags:Array.isArray(meta.tags)?meta.tags.slice(0,8):[]};
    rows.push(item);save(K.memory,rows.slice(-500));invalidateMemory();return {ok:true,item:item};
  }
  function updateMemory(id,patch){var rows=memoryRows(true),m=rows.find(function(x){return x.id===id});if(!m)return {ok:false,reason:'not_found'};patch=patch||{};if(patch.text){var p=memoryPolicy(patch.text);if(!p.allow)return {ok:false,reason:p.reason};m.text=text(patch.text);m.category=categoryFor(m.text,patch.category||m.category)};['importance','confidence'].forEach(function(k){if(patch[k]!=null)m[k]=clamp(Number(patch[k]),0,k==='importance'?5:1)});if(patch.category)m.category=categoryFor(m.text,patch.category);if(patch.status)m.status=String(patch.status);m.updatedAt=now();save(K.memory,rows);invalidateMemory();return {ok:true,item:m}}
  function removeMemory(id){var rows=memoryRows(true).filter(function(x){return x.id!==id});save(K.memory,rows);invalidateMemory();return rows}
  function recall(q,limit){var ts=tokens(q),nowMs=Date.now(),rows=memoryRows();if(!ts.length)return rows.slice(-Math.min(limit||8,8));return rows.map(function(m){var mt=tokens(m.text),overlap=ts.reduce(function(n,x){return n+(mt.indexOf(x)>=0?1:0)},0);var ageDays=Math.max(0,(nowMs-Date.parse(m.updatedAt||m.createdAt||now()))/86400000);var recency=Math.exp(-ageDays/120),importance=(m.importance||3)/5,confidence=m.confidence==null?1:m.confidence,exact=m.text.toLowerCase().indexOf(text(q).toLowerCase())>=0?3:0;return {m:m,score:overlap*2.8+exact+importance*0.8+confidence*0.7+recency*0.8,overlap:overlap}}).filter(function(x){return x.overlap>0||x.score>=3}).sort(function(a,b){return b.score-a.score}).slice(0,limit||8).map(function(x){return x.m})}
  function publicVoiceMemory(q){return recall(q,8).filter(function(m){return !SENSITIVE.test(m.text)&&!SECRET.test(m.text)}).map(function(m){return m.text})}
  function memoryCommand(message){
    var m=text(message);
    if (/^\s*(remember|save|store)\b/i.test(m)) {
      var body=m.replace(/^\s*(remember|save|store)\s*(that|this)?\s*:?-?\s*/i,'').trim();
      return body ? {type:'remember',result:addMemory(body,{source:'explicit_user_command',status:'confirmed',confidence:1})} : {type:'remember',result:{ok:false,reason:'empty'}};
    }
    if (/^\s*forget\b/i.test(m)) {
      var body2=m.replace(/^\s*forget\s*(that|this)?\s*:?-?\s*/i,'').trim();
      var matches=recall(body2,10);
      if (!matches.length) return {type:'forget',result:{ok:false,reason:'not_found'}};
      return {type:'forget',matches:matches};
    }
    if (/^\s*(what do you remember|what do you know about me|show my memories)\b/i.test(m)) {
      var q=m.replace(/^\s*(what do you remember|what do you know about me|show my memories)\s*/i,'').trim();
      return {type:'recall',matches:recall(q,10)};
    }
    return null;
  }

  /* ---------- Fast shared state / academic model ---------- */
  function state(force){var t=Date.now();if(!force&&stateCache.value&&t-stateCache.at<STATE_TTL)return stateCache.value;var out={};try{out.results=typeof noriHistoryLoadAll==='function'?noriHistoryLoadAll():{};}catch(e){out.results={}}try{out.assignments=typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():load('nori_command_assignments',[])}catch(e){out.assignments=[]}try{out.exams=typeof noriExamsLoad==='function'?noriExamsLoad():load('nori_exams',[])}catch(e){out.exams=[]}try{out.sessions=typeof noriStudySessionsLoad==='function'?noriStudySessionsLoad():load('nori_study_sessions',[])}catch(e){out.sessions=[]}try{out.context=typeof noriGetProtectionContext==='function'?noriGetProtectionContext():{mode:'normal'}}catch(e){out.context={mode:'normal'}};stateCache={at:t,value:out};return out}
  function invalidateState(){stateCache={at:0,value:null};profileCache={at:0,value:null}}
  function daysUntil(d){if(!d)return 999;var x=new Date(d+'T23:59:59'),n=new Date();return Math.ceil((x-n)/86400000)}
  function academicModel(s,force){var t=Date.now();if(!force&&profileCache.value&&t-profileCache.at<PROFILE_TTL)return profileCache.value;s=s||state();var subjects={};Object.keys(s.results||{}).forEach(function(sub){var arr=s.results[sub]||[],scores=arr.map(function(r){return Number(r.score)}).filter(isFinite);if(!scores.length)return;var latest=scores[scores.length-1],avg=scores.reduce(function(a,b){return a+b},0)/scores.length,window=scores.slice(-3),recent=window.reduce(function(a,b){return a+b},0)/window.length,trend=scores.length>1?latest-scores[Math.max(0,scores.length-3)]:0;subjects[sub]={latest:latest,average:Math.round(avg*10)/10,recentAverage:Math.round(recent*10)/10,trend:Math.round(trend*10)/10,resultCount:scores.length,confidence:'observed'};});
    (s.assignments||[]).forEach(function(a){var sub=a.subject||'Academic';subjects[sub]=subjects[sub]||{};if(a.status!=='done')subjects[sub].openAssignments=(subjects[sub].openAssignments||0)+1});
    (s.exams||[]).forEach(function(e){var sub=e.subject||'Academic';subjects[sub]=subjects[sub]||{};var d=daysUntil(e.date);if(d>=0&&d<=30)subjects[sub].nextExamDays=Math.min(subjects[sub].nextExamDays==null?999:subjects[sub].nextExamDays,d)});
    var rows=Object.keys(subjects).map(function(sub){var x=subjects[sub],risk=0;if(typeof x.latest==='number'&&x.latest<80)risk+=(80-x.latest)*1.2;if(x.openAssignments)risk+=x.openAssignments*8;if(x.nextExamDays!=null&&x.nextExamDays<=7)risk+=20;if(x.trend<0)risk+=Math.min(15,Math.abs(x.trend)/2);return {subject:sub,data:x,risk:Math.round(risk*10)/10}}).sort(function(a,b){return b.risk-a.risk});
    var profile={generatedAt:now(),subjects:rows,topWeaknesses:rows.slice(0,3).map(function(x){return x.subject}),note:'Performance records describe outcomes; they do not establish motivation, ability, laziness, or cause.'};profileCache={at:t,value:profile};save(K.profile,profile);return profile}

  /* ---------- Reasoning + uncertainty ---------- */
  function contradictions(t){var flags=[];if(/always|never/i.test(t)&&/sometimes|occasionally|usually/i.test(t))flags.push('Absolute and frequency language conflict.');if(/finished|completed/i.test(t)&&/not done|unfinished|didn't finish/i.test(t))flags.push('Completion claims conflict.');return flags}
  function decompose(input){var t=text(input),parts=t.split(/\b(?:and then|then|also|but|because|while|after that)\b|\n|[.;]/i).map(text).filter(function(x){return x.length>4}).slice(0,6);return parts.length>1?parts:[t]}
  function reason(input,ctx){var t=text(input),assumptions=[],unknowns=[],evidence=[],st=state(),profile=academicModel(st),parts=decompose(t),conf=0.72;if(profile.topWeaknesses.length)evidence.push('Recorded academic data identifies '+profile.topWeaknesses.join(', ')+' as higher-risk areas.');if(!st.assignments.length&&!st.exams.length&&!Object.keys(st.results||{}).length)unknowns.push('No useful academic records are available.');if(/why|cause|reason|because|motivation/i.test(t)&&!/record|score|result|document|evidence/i.test(t)){assumptions.push('Available records cannot establish the cause of a personal outcome.');conf-=0.18}var cons=contradictions(t);if(cons.length){assumptions=assumptions.concat(cons);conf-=0.12}return {subproblems:parts.map(function(p,i){return {id:i+1,question:p}}),evidence:evidence,assumptions:assumptions,unknowns:unknowns,contradictions:cons,confidence:unknowns.length?'low':conf<0.65?'medium':'high',confidenceScore:Math.round(clamp(conf,0,1)*100)/100,confidenceMeaning:unknowns.length?'I need evidence.':conf<0.65?'I infer this.':'I know this from recorded state.',academic:profile}}

  /* ---------- Tool router ---------- */
  function route(message,opts){opts=opts||{};var m=text(message),web=!!opts.webSearch,t=m.toLowerCase(),route='model',tools=[];if(web){route='web_research';tools.push('web_search')}else if(/^(what is|calculate|convert|define|translate)\b/i.test(m)&&m.length<220){route='fast_model'}if(/kage|handbook|human override|system integrity|award|exam result|new era|rule|breach|consequence|phase|tier|nori system/i.test(t))tools.push('kage_retrieval');if(/grade|score|exam|assignment|study|subject|physics|chemistry|biology|math|english|agriculture|deadline/i.test(t))tools.push('academic_model');if(/remember|forget|memory/i.test(t))tools.push('memory');if(/schedule|remind|focus mode|calendar|alarm/i.test(t))tools.push('app_action');if(/compare|trade.?off|contradict|reason|analy[sz]e|step by step|why/i.test(t))tools.push('reasoning');return {route:route,tools:Array.from(new Set(tools)),reason:web?'Explicit web request.':tools.length?'Relevant local intelligence is available.':'General conversation/reasoning.'}}

  function context(message,opts){opts=opts||{};var st=state(),profile=academicModel(st),r=reason(message),rt=route(message,opts),mem=opts.publicVoice?publicVoiceMemory(message):recall(message,8),legacy=(g.noriBrainV10Legacy&&g.noriBrainV10Legacy.buildChatContext)?g.noriBrainV10Legacy.buildChatContext(message,opts):null;return {version:'14',route:rt,reasoning:r,memory:mem,academic:profile,academicIntelligence:{exam:examIntelligence(),nextSession:nextDynamicSession(),missedSessions:missedSessionAdaptation()},systemFamiliarity:systemFamiliarity(message),worldState:legacy&&legacy.worldState||null,decision:legacy&&legacy.decision||null,privacy:{sensitiveExcluded:true,secretsExcluded:true},psychology:{mode:'general-support',nonDiagnostic:true,principles:['separate facts from interpretations','reduce cognitive load','use concrete next steps','protect autonomy','preserve standards when capacity permits']}}}
  function contextualNextMove(){ if(typeof nextDynamicSession==='function') return nextDynamicSession(); var s=state(),p=academicModel(s),best=null; return best?best:{available:false,reason:'Not enough current task, exam, or result data.'}; }
  function setPublicMode(v){var p=load(K.prefs,{});p.publicVoiceMode=!!v;save(K.prefs,p);return p.publicVoiceMode}function publicMode(){return !!load(K.prefs,{publicVoiceMode:false}).publicVoiceMode}
  function affect(message,decision){var t=text(message).toLowerCase(),a='calm';if(/sad|tired|overwhelmed|hard|rough|upset/.test(t))a='warm';if(/urgent|unsafe|emergency/.test(t))a='concerned';if(/deadline|exam|focus|start now/.test(t))a='focused';if(decision&&decision.action==='protect_sleep')a='caring';return a}function setAffect(e){if(typeof noriVisualSetAffect==='function')noriVisualSetAffect(e);return e}
  function rememberConfirmed(t,m){return addMemory(t,Object.assign({source:'user_confirmed',status:'confirmed',confidence:1},m||{}))}
  function buildChatContext(m,o){var c=context(m,o||{});c.emotion=affect(m,c.decision);c.emotionMeta={face:c.emotion,motion:c.emotion==='focused'?'precise':'steady',tone:c.emotion};return c}

  /* ---------- Academic Intelligence V14 ---------- */
  var AK={mistakes:'nori_academic_mistakes_v14',prefs:'nori_academic_prefs_v14'};
  var SUBJECT_PERSONALITIES={
    chemistry:{pace:'slow',depth:'deep',style:'concept -> equation -> worked example -> check',instruction:'Explain chemistry slowly and connect concepts to equations and observations.'},
    physics:{pace:'slow',depth:'deep',style:'reasoning -> knowns/unknowns -> equation -> units -> check',instruction:'Teach physics through reasoning, equations, units and verification.'},
    biology:{pace:'fast',depth:'conceptual',style:'core idea -> key terms -> quick retrieval check',instruction:'Keep biology explanations concise and conceptual unless the learner asks for depth.'},
    math:{pace:'adaptive',depth:'guided',style:'hint -> attempt -> next hint -> solution only if needed',instruction:'Use hint-first tutoring. Let the learner attempt before revealing the full solution.'},
    english:{pace:'adaptive',depth:'contextual',style:'example -> correction -> short practice',instruction:'Use concise examples and immediate practice.'},
    agriculture:{pace:'adaptive',depth:'conceptual',style:'definition -> application -> recall',instruction:'Connect agricultural concepts to practical applications and recall.'},
    web:{pace:'adaptive',depth:'practical',style:'example -> build -> verify',instruction:'Teach web/IT through practical examples and verification.'}
  };
  var MISTAKE_TYPES=['concept_gap','careless_error','calculation_error','memory_problem','misunderstanding','time_pressure'];
  function subjectKey(s){s=String(s||'').toLowerCase();if(/chem/.test(s))return 'chemistry';if(/phys/.test(s))return 'physics';if(/bio/.test(s))return 'biology';if(/math/.test(s))return 'math';if(/english|eng/.test(s))return 'english';if(/agri/.test(s))return 'agriculture';if(/web|it|informat/.test(s))return 'web';return s||'general'}
  function mistakeRows(){return load(AK.mistakes,[]).filter(function(x){return x&&x.subject&&x.type})}
  function recordMistake(m){m=m||{};var type=MISTAKE_TYPES.indexOf(m.type)>=0?m.type:'misunderstanding',row={id:uid('mistake'),subject:text(m.subject||'General'),topic:text(m.topic||''),type:type,description:text(m.description||''),date:m.date||now(),resolved:!!m.resolved,source:m.source||'user'};var a=mistakeRows();a.push(row);save(AK.mistakes,a.slice(-1000));invalidateState();return row}
  function classifyMistake(input){var t=text(input).toLowerCase();if(/forgot|couldn't remember|memory|memorize/.test(t))return 'memory_problem';if(/careless|sign|minus|copied|read wrong|silly/.test(t))return 'careless_error';if(/calculation|arithmetic|computed|calculated|unit/.test(t))return 'calculation_error';if(/time|ran out|too slow|hurry/.test(t))return 'time_pressure';if(/concept|didn't understand|don't understand|definition|why/.test(t))return 'concept_gap';return 'misunderstanding'}
  function mistakeIntelligence(subject){var rows=mistakeRows().filter(function(x){return !subject||subjectKey(x.subject)===subjectKey(subject)}),counts={};rows.forEach(function(x){counts[x.type]=(counts[x.type]||0)+1});var repeated=Object.keys(counts).sort(function(a,b){return counts[b]-counts[a]}).map(function(k){return {type:k,count:counts[k]}});return {subject:subject||'all',total:rows.length,byType:counts,repeatedPatterns:repeated.slice(0,3),unresolved:rows.filter(function(x){return !x.resolved}).length,latest:rows.slice(-10)}}
  function academicProfileV14(force){var base=academicModel(null,force),st=state(),mistakes=mistakeRows(),subjects={};base.subjects.forEach(function(r){subjects[r.subject]=Object.assign({},r.data,{risk:r.risk,mistakes:mistakeIntelligence(r.subject)})});
    mistakes.forEach(function(m){subjects[m.subject]=subjects[m.subject]||{resultCount:0};subjects[m.subject].mistakes=mistakeIntelligence(m.subject)});
    var allSubjects=Object.keys(subjects),neglected=allSubjects.filter(function(s){var d=subjects[s];return !d.resultCount&&((d.openAssignments||0)>0||(d.nextExamDays!=null))});
    var weaknesses=base.subjects.slice().sort(function(a,b){return b.risk-a.risk}).map(function(x){return x.subject}).slice(0,5);
    return {version:'14',generatedAt:now(),subjects:subjects,weaknesses:weaknesses,neglectedSubjects:neglected,recurringMistakes:mistakeIntelligence().repeatedPatterns,subjectPersonalities:SUBJECT_PERSONALITIES,principle:'Academic records identify observable patterns and priorities; they do not prove motivation, ability, laziness, or psychological cause.'};
  }
  function examIntelligence(){var st=state(),profile=academicProfileV14(),today=new Date(),items=(st.exams||[]).map(function(e){var d=daysUntil(e.date),sub=e.subject||'Academic',p=profile.subjects[sub]||{},risk=0;if(d<=3)risk+=45;else if(d<=7)risk+=35;else if(d<=14)risk+=22;else if(d<=30)risk+=10;if(typeof p.recentAverage==='number'&&p.recentAverage<80)risk+=Math.min(25,(80-p.recentAverage)*.7);risk+=(p.openAssignments||0)*4;return {exam:e,subject:sub,days:d,pressure:Math.round(clamp(risk,0,100)),highestValueTopics:(p.mistakes&&p.mistakes.repeatedPatterns||[]).slice(0,3).map(function(x){return x.type})}}).filter(function(x){return x.days>=0&&x.days<=60}).sort(function(a,b){return b.pressure-a.pressure});return {generatedAt:now(),exams:items,highestPressure:items.slice(0,3)}}
  function availableMinutes(input){var n=Number(input);return isFinite(n)&&n>0?Math.max(10,Math.min(600,Math.round(n))):60}
  function studyPlanV14(opts){opts=opts||{};var minutes=availableMinutes(opts.availableMinutes),st=state(),profile=academicProfileV14(),ex=examIntelligence(),candidates=[];
    (st.assignments||[]).filter(function(a){return a.status!=='done'}).forEach(function(a){var d=daysUntil(a.dueDate||a.deadline||a.date);candidates.push({kind:'assignment',subject:a.subject||'Academic',topic:a.title||a.name||'Assignment',urgency:d<=1?90:d<=3?75:d<=7?55:30,minutes:Math.min(45,minutes)})});
    ex.exams.forEach(function(e){var p=profile.subjects[e.subject]||{};var topic=(p.mistakes&&p.mistakes.repeatedPatterns&&p.mistakes.repeatedPatterns[0]&&p.mistakes.repeatedPatterns[0].type)||'highest-value weak topic';candidates.push({kind:'exam',subject:e.subject,topic:topic,urgency:e.pressure+15,minutes:Math.min(45,minutes)})});
    profile.weaknesses.forEach(function(s){var p=profile.subjects[s]||{},topic=(p.mistakes&&p.mistakes.repeatedPatterns&&p.mistakes.repeatedPatterns[0]&&p.mistakes.repeatedPatterns[0].type)||'weakest recent area';candidates.push({kind:'weakness',subject:s,topic:topic,urgency:(p.risk||0)+20,minutes:30})});
    candidates.sort(function(a,b){return b.urgency-a.urgency});var items=[],left=minutes;while(left>=10&&candidates.length){var c=candidates.shift(),mins=Math.min(c.minutes,left);mins=Math.max(10,mins);items.push({kind:'study',subject:c.subject,topic:c.topic,minutes:mins,reason:c.kind});left-=mins;if(items.length>=6)break}if(!items.length)items.push({kind:'study',subject:'Academic',topic:'Review the highest-priority current material',minutes:Math.min(25,minutes),reason:'fallback'});return {generatedAt:now(),availableMinutes:minutes,items:items,unusedMinutes:left,adaptation:'If a planned session is missed, unfinished work returns to the queue and is re-ranked against current deadlines; it is not treated as automatically completed.'}}
  function nextDynamicSession(){var p=academicProfileV14(),plan=studyPlanV14({availableMinutes:60});var x=plan.items[0];return {available:true,subject:x.subject,topic:x.topic,minutes:x.minutes,reason:x.reason,personality:SUBJECT_PERSONALITIES[subjectKey(x.subject)]||SUBJECT_PERSONALITIES.math,stopRule:'Stop when the planned objective is completed or the allocated time ends; verify before extending.'}}
  function examDebrief(input){input=input||{};var sub=input.subject||'Academic',before=academicModel().subjects.find(function(x){return x.subject===sub}),mist=mistakeIntelligence(sub);return {subject:sub,whatWentWrong:{observable:mist.repeatedPatterns},whatWentWell:{recordedAverage:before&&before.data&&before.data.recentAverage||null},why:'Use the recorded mistakes, result, timing and preparation evidence; do not infer causes that the records cannot establish.',changeNext:['Target the most repeated error type','Re-test the weakest topic','Adjust preparation allocation using the next deadline'],keep:['Methods that produced verified understanding or improved results'],evidence:{academic:before||null,mistakes:mist}}}
  function missedSessionAdaptation(){var s=state(),missed=(s.sessions||[]).filter(function(x){return x.status==='planned'&&x.date&&new Date(x.date+'T23:59:59')<new Date()});return {missed:missed.length,items:missed.slice(-10).map(function(x){return {subject:x.subject,topic:x.topic,minutes:x.minutes,date:x.date}}),rule:'Missed sessions are re-ranked, not duplicated blindly; current exams and deadlines can outrank old planned work.'}}

  g.noriBrainV14={version:'14',contextualNextMove:contextualNextMove,memoryAdd:addMemory,memoryUpdate:updateMemory,memoryRemove:removeMemory,getMemory:memoryRows,recall:recall,publicVoiceMemory:publicVoiceMemory,rememberConfirmed:rememberConfirmed,memoryCommand:memoryCommand,academicModel:academicModel,academicProfile:academicProfileV14,examIntelligence:examIntelligence,studyPlan:studyPlanV14,nextDynamicSession:nextDynamicSession,recordMistake:recordMistake,classifyMistake:classifyMistake,mistakeIntelligence:mistakeIntelligence,examDebrief:examDebrief,missedSessionAdaptation:missedSessionAdaptation,subjectPersonalities:SUBJECT_PERSONALITIES,invalidateState:invalidateState,reason:reason,route:route,buildChatContext:buildChatContext,setAffect:setAffect,publicMode:publicMode,setPublicMode:setPublicMode,redact:redact,systemFamiliarity:systemFamiliarity,systems:SYSTEMS,systemRule:SYSTEM_RULE};
  g.noriBrainV13=g.noriBrainV14;g.noriBrainV12=g.noriBrainV14;g.noriBrainV10=g.noriBrainV14;
})(window);
