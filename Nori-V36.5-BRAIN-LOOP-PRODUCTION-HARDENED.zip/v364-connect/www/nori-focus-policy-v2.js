/* Nori Focus Policy v2 — explicit app selection + purpose-aware strictness. */
(function(g){'use strict';
 var KEY='nori_focus_selected_apps_v2';
 function load(){try{return JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){return[]}}
 function save(a){a=Array.from(new Set((a||[]).map(String)));localStorage.setItem(KEY,JSON.stringify(a));return a}
 function selected(){return load()}
 function sync(a){try{if(g.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.NoriBlocker&&Capacitor.Plugins.NoriBlocker.setSelectedPackages)Capacitor.Plugins.NoriBlocker.setSelectedPackages({packages:a});}catch(e){}}
 function setSelected(a){a=save(a);sync(a);return a}
 function selectedHas(pkg){return load().indexOf(String(pkg))>=0}
 function explain(purpose,activity){
   var p=String(purpose||'').toLowerCase(),a=String(activity||'').toLowerCase();
   if(/video call|video chat|class call|teacher chat/.test(a)||/teacher|classmate/.test(p)) return {decision:'ALLOW',reason:'Communication appears connected to academic work.'};
   if(/scroll|reels|shorts|feed/.test(a)||/random chat|unnecessary chat|casual chat|direct message|\bdm\b/.test(a)||/post|publish|upload|story/.test(a)) return {decision:'BLOCK',reason:'Scrolling, unnecessary chat, or posting is not an academic use.'};
   if(/homework|assignment|study|class|exam|teacher|school/.test(p)||/document|notes|worksheet|textbook|video lesson|class/.test(a)) return {decision:'ALLOW',reason:'Academic purpose/activity.'};
   return {decision:'REVIEW',reason:'Activity is ambiguous; ask the user rather than assuming misuse.'};
 }
 function render(container){
   if(!container)return;container.innerHTML='';
   var h=document.createElement('div');h.innerHTML='<h3>Focus app selection</h3><p>Select the apps Nori may restrict during study/exam focus. Unselected apps are not blocked by this policy.</p>';container.appendChild(h);
   var status=document.createElement('pre');status.textContent='Selected: '+load().length;container.appendChild(status);
   var actions=document.createElement('div'); actions.style.display='flex'; actions.style.gap='8px'; actions.style.margin='8px 0 12px';
   var clear=document.createElement('button'); clear.className='nori-btn nori-btn-ghost'; clear.textContent='CLEAR SELECTION'; clear.onclick=function(){setSelected([]); render(container);}; actions.appendChild(clear);
   var refresh=document.createElement('button'); refresh.className='nori-btn nori-btn-primary'; refresh.textContent='REFRESH APP LIST'; refresh.onclick=function(){render(container);}; actions.appendChild(refresh); container.appendChild(actions);
   if(g.Capacitor&&Capacitor.Plugins&&Capacitor.Plugins.NoriBlocker){
     Capacitor.Plugins.NoriBlocker.listLaunchableApps().then(function(r){(r.apps||[]).forEach(function(x){var row=document.createElement('label');row.style.display='block';row.style.padding='7px 0';var c=document.createElement('input');c.type='checkbox';c.checked=selectedHas(x.package);c.onchange=function(){var a=load();if(c.checked)a.push(x.package);else a=a.filter(function(v){return v!==x.package});save(a);sync(a);status.textContent='Selected: '+a.length};row.appendChild(c);row.appendChild(document.createTextNode(' '+x.label));container.appendChild(row)})}).catch(function(){status.textContent+='\nNative app list unavailable until Android bridge is built.'});
   }
 }
 g.NoriFocusPolicyV2={selected:selected,setSelected:setSelected,selectedHas:selectedHas,explain:explain,render:render};
})(window);
