# Deploying Nori (web app + backend)

This is the one part of the whole build I genuinely can't do for you: I
have no network access in this sandbox, and even with it, deploying needs
YOUR Vercel account — I can't log in as you. Everything below is exact,
copy-pasteable, and this is the real gap this file exists to close: the
backend has existed as code in zip files this whole time and has never
actually been reachable by a phone or browser.

## What you need first

- A free [Vercel](https://vercel.com) account (sign up with GitHub, Google,
  or email — free tier is enough for this)
- [Node.js](https://nodejs.org) installed on your computer (this gives you
  `npx`, which is all you need — no separate Vercel install required)
- Your **rotated** API keys (OpenAI, Gemini) — not the ones pasted earlier
  in this conversation, if you haven't rotated those yet, do that first

## 1. Unzip and open a terminal there

Unzip `nori-jarvis.zip` into a folder, then open a terminal in that folder.
You should see `index.html`, `package.json`, the `api/` folder, and the
rest of the app files all at the top level — not nested in a subfolder.

## 2. Log in to Vercel

```bash
npx vercel login
```

This opens your browser to authenticate — no separate install needed,
`npx` downloads the Vercel CLI temporarily just to run this command.

## 3. Deploy

```bash
npx vercel
```

It'll ask a few questions — accept the defaults for all of them (set up
and deploy: yes; link to existing project: no, unless you've done this
before; project name: accept or rename; directory: `.` / current
directory). This creates a **preview** deployment and gives you a URL
like `https://nori-jarvis-xyz123.vercel.app`.

## 4. Add your API keys (this is the step that's easy to miss)

Go to [vercel.com/dashboard](https://vercel.com/dashboard) → your new
project → **Settings → Environment Variables**, and add:

| Name | Required for |
|---|---|
| `ANTHROPIC_API_KEY` | `api/checkin.js`, `api/evaluate.js` |
| `GEMINI_API_KEY` | `api/brain.js` (primary) |
| `OPENAI_API_KEY` | `api/brain.js` (1st fallback) |
| `OPENAI_BACKUP_API_KEY` | `api/brain.js` (2nd fallback — optional) |
| `OPENAI_BACKUP_BASE_URL` | only if the backup key is Azure OpenAI, not a 2nd OpenAI account |

Note: `api/verify-photo.js` (camera verification) reuses these same `GEMINI_API_KEY`/`OPENAI_API_KEY`/`OPENAI_BACKUP_*` variables — nothing extra to add for it.

Environment variables added after the first deploy don't apply
retroactively — you need one more deploy for them to take effect:

```bash
npx vercel --prod
```

This also promotes it to your **production** URL (no random suffix —
something like `https://nori-jarvis.vercel.app`, or your chosen project
name).

## 5. Test it's actually working

Open the production URL in a browser. Try:
- **Check-In** or **Report Result** (tests `api/checkin.js` / `api/evaluate.js`
  and your `ANTHROPIC_API_KEY`)
- **Meet Nori** chat (tests `api/brain.js` and your Gemini/OpenAI keys)

If something fails, Vercel's dashboard → your project → **Deployments** →
click the latest one → **Functions** tab shows real-time logs for each
`api/*.js` file — that's where to look first.

## 6. If you're also building the Android app

Once you have the production URL, that's what goes into
`nori-native-bridge.js`'s `NORI_API_BASE_URL` for the Android build (see
the separate Android README) — the native app can't use relative paths,
it needs this real deployed URL.

## 7. Updating later

Any time you get new files from me, unzip them into the same folder
(overwriting the old ones) and just run `npx vercel --prod` again. You
don't need to redo the login or environment variable steps — those stick
to the project.


## V25 AI provider failover
Existing brain providers are preserved: `GEMINI_API_KEY` → `OPENAI_API_KEY` → `OPENAI_BACKUP_API_KEY`. V25 additionally uses the existing project-level `ANTHROPIC_API_KEY` as an optional independent fallback for the main Brain route. Optional model overrides: `ANTHROPIC_FAST_MODEL`, `ANTHROPIC_REASONING_MODEL`, `ANTHROPIC_BASE_URL`. Provider failures use bounded retry and short circuit-breaker cooldowns; the local Nori engine is the final deterministic fallback.
