/* NORI V36.2 — actual-chat -> native brain adapter.
 * The native brain is consulted when the Android bridge exists. It never owns
 * canonical records or silently executes side effects; it returns reasoning
 * context to the cloud/local response layer.
 */
(function(g){'use strict';
  const plugin=()=>g.Capacitor&&g.Capacitor.Plugins&&g.Capacitor.Plugins.NoriMetaBrain||null;
  let last=null;
  function compact(x,n){try{return JSON.stringify(x).slice(0,n||18000);}catch(_){return '{}';}}
  async function process(message,ctx,opts){
    const p=plugin(); if(!p||typeof p.process!=='function') return {available:false,reason:'NATIVE_BRAIN_UNAVAILABLE'};
    const c=ctx||{};
    const external=!!(opts&&opts.externalAvailable);
    const initiated=opts&&opts.userInitiatedAction!==undefined?!!opts.userInitiatedAction:true;
    const fresh=!!(opts&&opts.freshDataRequested);
    const capacity=(opts&&opts.capacity)||'NORMAL';
    const context=compact({
      source:'actual_chat',
      page:c.current&&c.current.page||location.hash||location.pathname||'',
      profile:c.profile||{},
      state:c.state||{},
      current:c.current||{},
      pendingAction:c.pendingAction||null,
      canonicalVersion:c.canonicalVersion||0,
      authority:c.authority||'LOCAL_EVIDENCE',
      sourcePriority:c.sourcePriority||[]
    },22000);
    try{
      const result=await p.process({request:String(message||''),context,externalAvailable:external,userInitiated:initiated,freshDataRequested:fresh,capacity});
      last={available:true,at:new Date().toISOString(),result};
      return last;
    }catch(e){
      last={available:false,at:new Date().toISOString(),reason:String(e&&e.message||e)};
      return last;
    }
  }
  async function capabilities(){const p=plugin();if(!p||!p.capabilities)return {available:false};try{return {available:true,result:await p.capabilities()};}catch(e){return {available:false,reason:String(e&&e.message||e)};}}
  g.NoriNativeAssistanceV36={available:()=>!!plugin(),process,capabilities,last:()=>last};
})(window);
