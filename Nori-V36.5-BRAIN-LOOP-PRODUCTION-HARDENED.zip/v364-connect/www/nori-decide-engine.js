/* ==========================================================================
   NORI — DECISION ENGINE CLIENT (brain-engine bridge)
   ==========================================================================
   Talks to api/decide.js, the deterministic Degree 1-5 rule engine
   (brain-engine/) — NOT the AI conversation layer (nori-meet.js talks to
   that one, api/brain.js). This file is what a feature screen calls when
   it needs an actual classification/consequence decision instead of a
   conversational reply.

   Load this AFTER nori-native-bridge.js (needs NORI_API_BASE_URL from it).
   ========================================================================== */

const NORI_DECIDE_ENDPOINT = (typeof NORI_API_BASE_URL !== "undefined" ? NORI_API_BASE_URL : "") + "/api/decide";
/* V30: canonical state is server-authoritative. This is a volatile read model only.
 * It is never sent back as mutation input and is never persisted to localStorage. */
let NORI_DECIDE_STATE = null;

/**
 * @param {string} action  — one of the actions listed in api/decide.js
 * @param {Array} args     — positional args for that brain.js function
 * @returns {Promise<object>} the result payload from brain.js
 */
async function noriDecide(action, args) {
  const headers = { "Content-Type": "application/json" };
  if (typeof noriSyncGetAccessToken === "function") {
    const token = noriSyncGetAccessToken();
    if (token) headers.Authorization = "Bearer " + token;
  }
  const resp = await fetch(NORI_DECIDE_ENDPOINT, {
    method: "POST", headers: headers,
    body: JSON.stringify({ action: action, args: args || [] }),
  });
  const data = await resp.json().catch(function () { return null; });
  if (!resp.ok || !data || data.ok === false) {
    throw new Error((data && data.error) || "decide-engine-request-failed");
  }
  if (data.state) {
    NORI_DECIDE_STATE = Object.freeze(data.state);
  }
  return data.result;
}

// Refresh the authoritative brain state from the server when an authenticated
// session exists. `listEvents` is intentionally a read-through operation: the
// API hydrates its state from Supabase, then returns the same state payload, so
// a fresh device does not have to wait for a write before the UI can see it.
async function noriBrainRefreshState() {
  return noriDecide("listEvents", []);
}

// Convenience wrappers — thin, so the call sites stay readable.
const noriBrainEngine = {
  processAcademicEvent: (input) => noriDecide("processAcademicEvent", [input]),
  requestOverride: (eventId, request, history) => noriDecide("requestOverride", [eventId, request, history]),
  completeRecovery: (eventId, verification) => noriDecide("completeRecovery", [eventId, verification]),
  escalateToDegree3: (eventId, history, input) => noriDecide("escalateToDegree3", [eventId, history, input]),
  advanceMasteryGate: (eventId, concept, evidence) => noriDecide("advanceMasteryGate", [eventId, concept, evidence]),
  escalateToDegree4: (eventId, history, input) => noriDecide("escalateToDegree4", [eventId, history, input]),
  escalateToDegree5: (eventId, history, input) => noriDecide("escalateToDegree5", [eventId, history, input]),
  reviewHandbookBoundary: (eventId, status) => noriDecide("reviewHandbookBoundary", [eventId, status]),
  finalizeHandbookTransition: (eventId, caseFileData, actions) => noriDecide("finalizeHandbookTransition", [eventId, caseFileData, actions]),
  checkAntiGaming: (signals) => noriDecide("checkAntiGaming", [signals]),
  consolidateEvents: (events) => noriDecide("consolidateEvents", [events]),
  startStabilityCycle: (eventId, lengthDays) => noriDecide("startStabilityCycle", [eventId, lengthDays]),
  logStabilityDay: (eventId, dayResult) => noriDecide("logStabilityDay", [eventId, dayResult]),
  meritRedeem: (account, tier, domain) => noriDecide("meritRedeem", [account, tier, domain]),
  meritRedeemLevelTier: (account, level, points, domain) => noriDecide("meritRedeemLevelTier", [account, level, points, domain]),
  getEvent: (eventId) => noriDecide("getEvent", [eventId]),
  listEvents: () => noriDecide("listEvents", []),
  // Award / Merit system (Level 1 Merit -> Level 5 Elite Honor)
  getAwardCatalog: (level) => noriDecide("getAwardCatalog", [level ?? null]),
  getAward: (awardId) => noriDecide("getAward", [awardId]),
  checkAward: (awardId, evidence) => noriDecide("checkAward", [awardId, evidence]),
  createMeritLedger: () => noriDecide("createMeritLedger", []),
  grantAward: (ledger, awardId, evidence, evidenceKey) => noriDecide("grantAward", [ledger, awardId, evidence, evidenceKey ?? null]),
  grantScoreBandMerit: (ledger, percentage, kind, evidenceKey) => noriDecide("grantScoreBandMerit", [ledger, percentage, kind ?? "academic_score", evidenceKey ?? null]),
};
