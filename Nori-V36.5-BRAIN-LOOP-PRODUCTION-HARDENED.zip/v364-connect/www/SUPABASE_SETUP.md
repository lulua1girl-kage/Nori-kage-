# Setting Up Cloud Sync (Supabase)

Nori is connected to its Supabase project. The project URL and publishable key are configured in the release; the publishable key is safe for client use when Row Level Security is enabled. Service-role keys remain server-only.

## 1. Create a Supabase project

1. Go to [supabase.com](https://supabase.com), sign up (free tier is
   enough for this), and create a new project.
2. Wait for it to finish provisioning (a couple of minutes).

## 2. Create the table and security policies

In your project dashboard, go to **SQL Editor → New query**, paste this
exactly, and run it:

```sql
create table public.nori_data (
  user_id uuid references auth.users(id) not null,
  key text not null,
  value jsonb not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, key)
);

alter table public.nori_data enable row level security;

create policy "Users can read their own data"
  on public.nori_data for select
  using (auth.uid() = user_id);

create policy "Users can insert their own data"
  on public.nori_data for insert
  with check (auth.uid() = user_id);

create policy "Users can update their own data"
  on public.nori_data for update
  using (auth.uid() = user_id);

create policy "Users can delete their own data"
  on public.nori_data for delete
  using (auth.uid() = user_id);

-- Enables realtime sync (so a change on one device shows up on another
-- without polling)
alter publication supabase_realtime add table public.nori_data;
```

**The Row Level Security (RLS) policies are not optional.** Without them,
anyone with your project's public key (which ships in the app, by design —
see below) could read or write any user's data. With them, Postgres itself
enforces that a user can only ever touch rows where `user_id` matches
their own logged-in session — no user can see another user's data even if
they wanted to.

## 2B. Persistent deterministic Brain state

The decision API now persists its audit ledger and Merit ledger server-side when these server environment variables are configured:

- `SUPABASE_URL` — the same project URL
- `SUPABASE_SERVICE_ROLE_KEY` — **server only; never put this in the web app**

Run this SQL once:

```sql
create table public.nori_brain_state (
  user_id uuid references auth.users(id) primary key,
  state jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.nori_brain_state enable row level security;
create policy "Users can read their own brain state" on public.nori_brain_state for select using (auth.uid() = user_id);
create policy "Users can insert their own brain state" on public.nori_brain_state for insert with check (auth.uid() = user_id);
create policy "Users can update their own brain state" on public.nori_brain_state for update using (auth.uid() = user_id);
```

The server uses the service-role key only inside `api/decide.js` and `api/domain-status.js`; the browser only sends the signed-in user's Supabase access token. If server persistence is not configured yet, the decision bridge still round-trips its state locally so development does not silently lose events.

## 3. Turn on email/password auth

By default it's already on. If you want to double check or add other
sign-in methods later: **Authentication → Providers** in the dashboard.

For testing, you may also want to turn off "Confirm email" under
**Authentication → Providers → Email** so you don't need to click a
confirmation link for every test account — turn it back on before real
users sign up.

## 4. Get your project URL and key

**Settings → API** in the dashboard. Copy:
- **Project URL** (looks like `https://xyzcompany.supabase.co`)
- **anon / publishable key** (a long string — this one is *meant* to be
  public; it's safe to ship in client code because RLS above is what
  actually protects the data, not secrecy of this key)

**Do NOT use the `service_role` key anywhere in client code** — that one
bypasses RLS entirely and must never leave your server.

## 5. Set the two config lines

Open `nori-sync.js` and change:

```js
const NORI_SUPABASE_URL = "";
const NORI_SUPABASE_ANON_KEY = "";
```

to your actual project URL and anon key from step 4.

## 6. Deploy and test

Redeploy (see `DEPLOY.md`), open the app, tap the account button on the
home hub, sign up with an email + password, and check two things:
- A new row appears in **Table Editor → nori_data** in the Supabase
  dashboard after you use the app a bit
- Signing in on a second device/browser with the same account pulls that
  data down

## What this does and doesn't give you

**Does:** real accounts, password auth (handled by Supabase, not
hand-rolled), data synced across every device you log into, automatic
merge if you use the app offline on two devices before they sync.

**Doesn't:** it's still self-managed — if a user forgets their password
and never set up account recovery, that's between them and Supabase's
password-reset flow (built in, uses email — no extra setup needed beyond
what's above). There's also no admin dashboard in the app itself for
managing users; that lives in the Supabase dashboard.
