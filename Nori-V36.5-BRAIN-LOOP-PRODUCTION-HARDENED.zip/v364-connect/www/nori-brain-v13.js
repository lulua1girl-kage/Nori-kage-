/* NORI BRAIN V13 — Fast, system-aware intelligence layer
   Memory 2.0+ • reasoning/uncertainty • system familiarity • fast local cache
   • self-check signals • academic model • local command handling.
   V12-compatible API; no sensitive memory, no hidden surveillance, Human Override preserved.
*/
(function(g){'use strict';
  var K={memory:'nori_brain_memory_v13',profile:'nori_academic_profile_v13',events:'nori_brain_events_v13',prefs:'nori_brain_prefs_v13'};
  var SECRET=/\b(sk-[A-Za-z0-9_-]{12,}|ghp_[A-Za-z0-9_]+|AIza[\w-]+|Bearer\s+\S+|password\s*=|token\s*=|secret\s*=)\b/i;
  var SENSITIVE=/(password|passcode|pin|api key|secret|token|bank|credit card|card number|address|location|medical|diagnos|medication|trauma|abuse|self[- ]?harm|suicide|sexual|private|family conflict|legal case)/i;
  var CATEGORY_WORDS={goals:['goal','target','aim','objective'],preferences:['prefer','preference','like','dislike','style'],projects:['project','app','build','system','nori','kage'],academic:['study','subject','exam','assignment','grade','school','physics','chemistry','biology','math','english'],system_configuration:['setting','configuration','mode','rule','provider','model','feature']};
  var stateCache={at:0,value:null}, profileCache={at:0,value:null}, memoryCache={at:0,value:null,index:null};
  var STATE_TTL=1500, PROFILE_TTL=4000, MEMORY_TTL=2500;
  var now=function(){return new Date().toISOString()};
  function load(k,fb){try{var x=JSON.parse(localStorage.getItem(k)||'null');return x==null?fb:x}catch(e){return fb}}
  function save(k,v){try{if(typeof noriSafeWrite==='function')return noriSafeWrite(k,v);localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function uid(p){return p+'_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8)}
  function text(x){return String(x==null?'':x).replace(/[\u0000-\u001F]/g,' ').replace(/\s+/g,' ').trim()}
  function tokens(s){return text(s).toLowerCase().split(/[^a-z0-9%]+/).filter(function(x){return x.length>1})}
  function redact(s){s=text(s);return SECRET.test(s)?'[redacted credential]':s}
  function clamp(n,a,b){return Math.max(a,Math.min(b,n))}
  function categoryFor(t,explicit){if(explicit&&CATEGORY_WORDS[explicit])return explicit;var s=t.toLowerCase();for(var k in CATEGORY_WORDS){if(CATEGORY_WORDS[k].some(function(w){return s.indexOf(w)>=0}))return k}return 'general'}
  function confidenceLabel(v){v=Number(v);return v>=0.85?'confirmed':v>=0.55?'likely':'uncertain'}

  /* ---------- Fast system familiarity ---------- */
  var SYSTEMS=[
    {id:'storage',name:'Nori Storage',role:'persistent local data and safe writes'},
    {id:'context',name:'Context Intelligence',role:'protection/context state and disruption awareness'},
    {id:'decision',name:'Decision Engine',role:'priority and Human Override-aware decisions'},
    {id:'rules',name:'KAGE Rules',role:'exam, award, override and system-integrity rules'},
    {id:'phase',name:'Phase System',role:'phase data, academic forms and progress'},
    {id:'command',name:'Command Suite',role:'assignments, tasks, results and command surfaces'},
    {id:'calendar',name:'Calendar',role:'dates, planning and deadlines'},
    {id:'alarm',name:'Smart Alarm',role:'alarm scheduling and voice-call interaction'},
    {id:'blocker',name:'Protection / Blocker',role:'focus protection and temporary access'},
    {id:'adaptive',name:'Adaptive Command',role:'contextual next move and deadline pressure'},
    {id:'brain',name:'Nori Brain',role:'memory, reasoning, uncertainty and academic intelligence'},
    {id:'conversation',name:'Conversation Layer',role:'intent, affect, thread continuity and anti-awkwardness'},
    {id:'visual',name:'Visual / Affect',role:'UI state and subtle Nori affect'},
    {id:'tier3',name:'Serious KAGE',role:'analytics, replanning, failure patterns, reports and audits'},
    {id:'tier4',name:'Advanced Orchestration',role:'research, RAG, multi-model routing and workflow planning'},
    {id:'voice',name:'Native Voice',role:'speech recognition, TTS and call-style interaction'},
    {id:'human_override',name:'Human Override',role:'human authority above optimization and disciplinary automation'}
  ];
  var SYSTEM_RULE='Human Override remains the highest authority; deterministic app engines own records; AI explains/recommends but does not invent state or silently execute side effects.';
  function systemFamiliarity(query){var q=tokens(query||'');var hits=SYSTEMS.map(function(s){var words=tokens(s.name+' '+s.role);var overlap=q.reduce(function(n,x){return n+(words.indexOf(x)>=0?1:0)},0);return {system:s,score:overlap}}).filter(function(x){return x.score>0}).sort(function(a,b){return b.score-a.score});return {systems:SYSTEMS,matched:hits.slice(0,5).map(function(x){return x.system}),principle:SYSTEM_RULE,version:'13'}}

  /* ---------- Memory 2.0+ ---------- */
  function memoryRows(force){
    var t=Date.now();if(!force&&memoryCache.value&&t-memoryCache.at<MEMORY_TTL)return memoryCache.value;
    var rows=load(K.memory,[]).filter(function(m){return m&&typeof m.text==='string'});
    try{if(typeof noriMemoryLoad==='function')(noriMemoryLoad().items||[]).forEach(function(m){if(!m||typeof m.text!=='string'||SENSITIVE.test(m.text)||SECRET.test(m.text))return;if(!rows.some(function(x){return x.text===m.text}))rows.push({id:m.id||uid('legacy'),text:m.text,source:'legacy_confirmed',createdAt:m.date||now(),updatedAt:m.date||now(),learnedAt:m.date||now(),importance:3,confidence:1,scope:'user',status:'confirmed',category:categoryFor(m.text)});});}catch(e){}
    rows.forEach(function(m){m.category=m.category||categoryFor(m.text,m.category);m.confidence=clamp(m.confidence==null?1:m.confidence,0,1);m.status=m.status||confidenceLabel(m.confidence);m.learnedAt=m.learnedAt||m.createdAt||now();m.updatedAt=m.updatedAt||m.createdAt||m.learnedAt;m.importance=clamp(Number(m.importance)||3,1,5)});
    memoryCache={at:t,value:rows,index:null};return rows;
  }
  function invalidateMemory(){memoryCache={at:0,value:null,index:null}}
  function memoryPolicy(t){t=redact(t);if(!t||SECRET.test(t))return {allow:false,reason:'secret'};if(SENSITIVE.test(t))return {allow:false,reason:'sensitive'};return {allow:true}}
  function addMemory(t,meta){t=text(t);var p=memoryPolicy(t);if(!p.allow)return {ok:false,reason:p.reason};meta=meta||{};var rows=memoryRows(true),n=t.toLowerCase();var existing=rows.find(function(m){return m.text.toLowerCase()===n});
    var item;
    if(existing){existing.updatedAt=now();existing.status='confirmed';existing.confidence=1;existing.learnedAt=existing.learnedAt||now();if(meta.category)existing.category=categoryFor(existing.text,meta.category);save(K.memory,rows);invalidateMemory();return {ok:true,duplicate:true,item:existing}}
    item={id:uid('mem'),text:t,source:meta.source||'user_confirmed',createdAt:now(),updatedAt:now(),learnedAt:meta.learnedAt||now(),importance:clamp(Number(meta.importance)||3,1,5),confidence:clamp(Number(meta.confidence)==null?1:Number(meta.confidence),0,1),scope:meta.scope||'user',status:meta.status||confidenceLabel(meta.confidence==null?1:Number(meta.confidence)),category:categoryFor(t,meta.category),tags:Array.isArray(meta.tags)?meta.tags.slice(0,8):[]};
    rows.push(item);save(K.memory,rows.slice(-500));invalidateMemory();return {ok:true,item:item};
  }
  function updateMemory(id,patch){var rows=memoryRows(true),m=rows.find(function(x){return x.id===id});if(!m)return {ok:false,reason:'not_found'};patch=patch||{};if(patch.text){var p=memoryPolicy(patch.text);if(!p.allow)return {ok:false,reason:p.reason};m.text=text(patch.text);m.category=categoryFor(m.text,patch.category||m.category)};['importance','confidence'].forEach(function(k){if(patch[k]!=null)m[k]=clamp(Number(patch[k]),0,k==='importance'?5:1)});if(patch.category)m.category=categoryFor(m.text,patch.category);if(patch.status)m.status=String(patch.status);m.updatedAt=now();save(K.memory,rows);invalidateMemory();return {ok:true,item:m}}
  function removeMemory(id){var rows=memoryRows(true).filter(function(x){return x.id!==id});save(K.memory,rows);invalidateMemory();return rows}
  function recall(q,limit){var ts=tokens(q),nowMs=Date.now(),rows=memoryRows();if(!ts.length)return rows.slice(-Math.min(limit||8,8));return rows.map(function(m){var mt=tokens(m.text),overlap=ts.reduce(function(n,x){return n+(mt.indexOf(x)>=0?1:0)},0);var ageDays=Math.max(0,(nowMs-Date.parse(m.updatedAt||m.createdAt||now()))/86400000);var recency=Math.exp(-ageDays/120),importance=(m.importance||3)/5,confidence=m.confidence==null?1:m.confidence,exact=m.text.toLowerCase().indexOf(text(q).toLowerCase())>=0?3:0;return {m:m,score:overlap*2.8+exact+importance*0.8+confidence*0.7+recency*0.8,overlap:overlap}}).filter(function(x){return x.overlap>0||x.score>=3}).sort(function(a,b){return b.score-a.score}).slice(0,limit||8).map(function(x){return x.m})}
  function publicVoiceMemory(q){return recall(q,8).filter(function(m){return !SENSITIVE.test(m.text)&&!SECRET.test(m.text)}).map(function(m){return m.text})}
  function memoryCommand(message){
    var m=text(message);
    if (/^\s*(remember|save|store)\b/i.test(m)) {
      var body=m.replace(/^\s*(remember|save|store)\s*(that|this)?\s*:?-?\s*/i,'').trim();
      return body ? {type:'remember',result:addMemory(body,{source:'explicit_user_command',status:'confirmed',confidence:1})} : {type:'remember',result:{ok:false,reason:'empty'}};
    }
    if (/^\s*forget\b/i.test(m)) {
      var body2=m.replace(/^\s*forget\s*(that|this)?\s*:?-?\s*/i,'').trim();
      var matches=recall(body2,10);
      if (!matches.length) return {type:'forget',result:{ok:false,reason:'not_found'}};
      return {type:'forget',matches:matches};
    }
    if (/^\s*(what do you remember|what do you know about me|show my memories)\b/i.test(m)) {
      var q=m.replace(/^\s*(what do you remember|what do you know about me|show my memories)\s*/i,'').trim();
      return {type:'recall',matches:recall(q,10)};
    }
    return null;
  }

  /* ---------- Fast shared state / academic model ---------- */
  function state(force){var t=Date.now();if(!force&&stateCache.value&&t-stateCache.at<STATE_TTL)return stateCache.value;var out={};try{out.results=typeof noriHistoryLoadAll==='function'?noriHistoryLoadAll():{};}catch(e){out.results={}}try{out.assignments=typeof noriAssignmentsLoad==='function'?noriAssignmentsLoad():load('nori_command_assignments',[])}catch(e){out.assignments=[]}try{out.exams=typeof noriExamsLoad==='function'?noriExamsLoad():load('nori_exams',[])}catch(e){out.exams=[]}try{out.sessions=typeof noriStudySessionsLoad==='function'?noriStudySessionsLoad():load('nori_study_sessions',[])}catch(e){out.sessions=[]}try{out.context=typeof noriGetProtectionContext==='function'?noriGetProtectionContext():{mode:'normal'}}catch(e){out.context={mode:'normal'}};stateCache={at:t,value:out};return out}
  function invalidateState(){stateCache={at:0,value:null};profileCache={at:0,value:null}}
  function daysUntil(d){if(!d)return 999;var x=new Date(d+'T23:59:59'),n=new Date();return Math.ceil((x-n)/86400000)}
  function academicModel(s,force){var t=Date.now();if(!force&&profileCache.value&&t-profileCache.at<PROFILE_TTL)return profileCache.value;s=s||state();var subjects={};Object.keys(s.results||{}).forEach(function(sub){var arr=s.results[sub]||[],scores=arr.map(function(r){return Number(r.score)}).filter(isFinite);if(!scores.length)return;var latest=scores[scores.length-1],avg=scores.reduce(function(a,b){return a+b},0)/scores.length,window=scores.slice(-3),recent=window.reduce(function(a,b){return a+b},0)/window.length,trend=scores.length>1?latest-scores[Math.max(0,scores.length-3)]:0;subjects[sub]={latest:latest,average:Math.round(avg*10)/10,recentAverage:Math.round(recent*10)/10,trend:Math.round(trend*10)/10,resultCount:scores.length,confidence:'observed'};});
    (s.assignments||[]).forEach(function(a){var sub=a.subject||'Academic';subjects[sub]=subjects[sub]||{};if(a.status!=='done')subjects[sub].openAssignments=(subjects[sub].openAssignments||0)+1});
    (s.exams||[]).forEach(function(e){var sub=e.subject||'Academic';subjects[sub]=subjects[sub]||{};var d=daysUntil(e.date);if(d>=0&&d<=30)subjects[sub].nextExamDays=Math.min(subjects[sub].nextExamDays==null?999:subjects[sub].nextExamDays,d)});
    var rows=Object.keys(subjects).map(function(sub){var x=subjects[sub],risk=0;if(typeof x.latest==='number'&&x.latest<80)risk+=(80-x.latest)*1.2;if(x.openAssignments)risk+=x.openAssignments*8;if(x.nextExamDays!=null&&x.nextExamDays<=7)risk+=20;if(x.trend<0)risk+=Math.min(15,Math.abs(x.trend)/2);return {subject:sub,data:x,risk:Math.round(risk*10)/10}}).sort(function(a,b){return b.risk-a.risk});
    var profile={generatedAt:now(),subjects:rows,topWeaknesses:rows.slice(0,3).map(function(x){return x.subject}),note:'Performance records describe outcomes; they do not establish motivation, ability, laziness, or cause.'};profileCache={at:t,value:profile};save(K.profile,profile);return profile}

  /* ---------- Reasoning + uncertainty ---------- */
  function contradictions(t){var flags=[];if(/always|never/i.test(t)&&/sometimes|occasionally|usually/i.test(t))flags.push('Absolute and frequency language conflict.');if(/finished|completed/i.test(t)&&/not done|unfinished|didn't finish/i.test(t))flags.push('Completion claims conflict.');return flags}
  function decompose(input){var t=text(input),parts=t.split(/\b(?:and then|then|also|but|because|while|after that)\b|\n|[.;]/i).map(text).filter(function(x){return x.length>4}).slice(0,6);return parts.length>1?parts:[t]}
  function reason(input,ctx){var t=text(input),assumptions=[],unknowns=[],evidence=[],st=state(),profile=academicModel(st),parts=decompose(t),conf=0.72;if(profile.topWeaknesses.length)evidence.push('Recorded academic data identifies '+profile.topWeaknesses.join(', ')+' as higher-risk areas.');if(!st.assignments.length&&!st.exams.length&&!Object.keys(st.results||{}).length)unknowns.push('No useful academic records are available.');if(/why|cause|reason|because|motivation/i.test(t)&&!/record|score|result|document|evidence/i.test(t)){assumptions.push('Available records cannot establish the cause of a personal outcome.');conf-=0.18}var cons=contradictions(t);if(cons.length){assumptions=assumptions.concat(cons);conf-=0.12}return {subproblems:parts.map(function(p,i){return {id:i+1,question:p}}),evidence:evidence,assumptions:assumptions,unknowns:unknowns,contradictions:cons,confidence:unknowns.length?'low':conf<0.65?'medium':'high',confidenceScore:Math.round(clamp(conf,0,1)*100)/100,confidenceMeaning:unknowns.length?'I need evidence.':conf<0.65?'I infer this.':'I know this from recorded state.',academic:profile}}

  /* ---------- Tool router ---------- */
  function route(message,opts){opts=opts||{};var m=text(message),web=!!opts.webSearch,t=m.toLowerCase(),route='model',tools=[];if(web){route='web_research';tools.push('web_search')}else if(/^(what is|calculate|convert|define|translate)\b/i.test(m)&&m.length<220){route='fast_model'}if(/kage|handbook|human override|system integrity|award|exam result|new era|rule|breach|consequence|phase|tier|nori system/i.test(t))tools.push('kage_retrieval');if(/grade|score|exam|assignment|study|subject|physics|chemistry|biology|math|english|agriculture|deadline/i.test(t))tools.push('academic_model');if(/remember|forget|memory/i.test(t))tools.push('memory');if(/schedule|remind|focus mode|calendar|alarm/i.test(t))tools.push('app_action');if(/compare|trade.?off|contradict|reason|analy[sz]e|step by step|why/i.test(t))tools.push('reasoning');return {route:route,tools:Array.from(new Set(tools)),reason:web?'Explicit web request.':tools.length?'Relevant local intelligence is available.':'General conversation/reasoning.'}}

  function context(message,opts){opts=opts||{};var st=state(),profile=academicModel(st),r=reason(message),rt=route(message,opts),mem=opts.publicVoice?publicVoiceMemory(message):recall(message,8),legacy=(g.noriBrainV10Legacy&&g.noriBrainV10Legacy.buildChatContext)?g.noriBrainV10Legacy.buildChatContext(message,opts):null;return {version:'13',route:rt,reasoning:r,memory:mem,academic:profile,systemFamiliarity:systemFamiliarity(message),worldState:legacy&&legacy.worldState||null,decision:legacy&&legacy.decision||null,privacy:{sensitiveExcluded:true,secretsExcluded:true},psychology:{mode:'general-support',nonDiagnostic:true,principles:['separate facts from interpretations','reduce cognitive load','use concrete next steps','protect autonomy','preserve standards when capacity permits']}}}
  function contextualNextMove(){var s=state(),p=academicModel(s),best=null;(s.assignments||[]).forEach(function(a){if(a.status==='done')return;var d=daysUntil(a.dueDate||a.deadline||a.date),score=(d<999?Math.max(0,40-d):0)+10;if(!best||score>best.score)best={type:'assignment',subject:a.subject||'Academic',title:a.title||a.name||'Open assignment',score:score}});(s.exams||[]).forEach(function(e){var d=daysUntil(e.date);if(d>=0&&d<=30){var score=55+(30-d);if(!best||score>best.score)best={type:'exam',subject:e.subject||'Academic',title:e.title||'Upcoming exam',days:d,score:score}}});if(!best&&p.topWeaknesses.length)best={type:'weakness',subject:p.topWeaknesses[0],title:'Work the highest-risk subject',score:20};return best?{available:true,type:best.type,subject:best.subject,title:best.title,days:best.days,reason:'Selected from current recorded academic state; not a claim about motivation or cause.'}:{available:false,reason:'Not enough current task, exam, or result data.'}}
  function setPublicMode(v){var p=load(K.prefs,{});p.publicVoiceMode=!!v;save(K.prefs,p);return p.publicVoiceMode}function publicMode(){return !!load(K.prefs,{publicVoiceMode:false}).publicVoiceMode}
  function affect(message,decision){var t=text(message).toLowerCase(),a='calm';if(/sad|tired|overwhelmed|hard|rough|upset/.test(t))a='warm';if(/urgent|unsafe|emergency/.test(t))a='concerned';if(/deadline|exam|focus|start now/.test(t))a='focused';if(decision&&decision.action==='protect_sleep')a='caring';return a}function setAffect(e){if(typeof noriVisualSetAffect==='function')noriVisualSetAffect(e);return e}
  function rememberConfirmed(t,m){return addMemory(t,Object.assign({source:'user_confirmed',status:'confirmed',confidence:1},m||{}))}
  function buildChatContext(m,o){var c=context(m,o||{});c.emotion=affect(m,c.decision);c.emotionMeta={face:c.emotion,motion:c.emotion==='focused'?'precise':'steady',tone:c.emotion};return c}
  g.noriBrainV13={version:'13',contextualNextMove:contextualNextMove,memoryAdd:addMemory,memoryUpdate:updateMemory,memoryRemove:removeMemory,getMemory:memoryRows,recall:recall,publicVoiceMemory:publicVoiceMemory,rememberConfirmed:rememberConfirmed,memoryCommand:memoryCommand,academicModel:academicModel,invalidateState:invalidateState,reason:reason,route:route,buildChatContext:buildChatContext,setAffect:setAffect,publicMode:publicMode,setPublicMode:setPublicMode,redact:redact,systemFamiliarity:systemFamiliarity,systems:SYSTEMS,systemRule:SYSTEM_RULE};
  g.noriBrainV12=g.noriBrainV13;g.noriBrainV10=g.noriBrainV13;
})(window);
