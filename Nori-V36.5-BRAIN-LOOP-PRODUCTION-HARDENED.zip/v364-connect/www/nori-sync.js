/* ==========================================================================
   NORI — CLOUD SYNC (accounts + multi-device sync)
   ==========================================================================
   Real accounts and cross-device sync, built on Supabase (hosted Postgres
   + built-in authentication) rather than hand-rolled auth — password
   hashing, session tokens, and account security are Supabase's job, not
   this app's. See SUPABASE_SETUP.md for the exact one-time setup (SQL
   schema, Row Level Security policies, getting your project URL and key).

   HOW SYNC HOOKS IN: nori-storage.js's noriSafeWrite() is the single
   funnel every write in this app already goes through (confirmed: every
   other write function calls it, nothing writes to localStorage directly
   anywhere else). This file registers ONE hook there — every local write,
   from any feature, gets queued for upload automatically. Nothing else in
   the app needed to change.

   CONFLICT HANDLING: this app's data is almost entirely append-only logs
   (table-log rows, snapshot-log entries, subject/override/breach history)
   — the existing architecture never edits a saved entry in place, it only
   ever pushes new ones. That makes UNION-MERGE safe and correct: when
   local and remote both have data for the same key, this combines both
   sets of entries and de-duplicates exact matches, so two devices editing
   offline and syncing later both keep their changes — neither device's
   writes get silently discarded by a naive "last write wins."
   The one exception is Phase-form pageFields (a handful of plain text
   boxes, edited in place rather than appended to) — for those, whichever
   side syncs LAST wins on that whole object. That's a real, documented
   limitation, not an oversight: true field-by-field conflict resolution
   for freeform text inputs would need per-keystroke timestamps this app
   doesn't track.

   SECURITY NOTE: NORI_SUPABASE_ANON_KEY below is meant to be public —
   unlike the OpenAI/Gemini keys in api/brain.js (which must NEVER appear
   in client code), Supabase's anon/publishable key is safe to ship to the
   browser specifically because Row Level Security policies (set up in
   SUPABASE_SETUP.md) are what actually restrict access, not secrecy of
   this key. Don't confuse the two key types.

   CONFIGURE before deploying:
   ========================================================================== */
const NORI_SUPABASE_URL = "https://qrlvkxewyoceykaquapv.supabase.co";
const NORI_SUPABASE_ANON_KEY = "sb_publishable_3QSgkXgNWRa82Z2ID6n7Ag_QdvmH92_";

/* ========================================================================== */

let noriSupabaseClient = null;
let noriSyncCurrentUser = null;
let noriSyncAccessToken = null;
let noriSyncPushTimer = null;
let noriSyncPendingKeys = {};
const NORI_SYNC_DEBOUNCE_MS = 2000; // batch rapid writes instead of one round-trip per keystroke

function noriSyncConfigured() {
  return !!(NORI_SUPABASE_URL && NORI_SUPABASE_ANON_KEY && window.supabase);
}

function noriSyncInit() {
  if (!noriSyncConfigured()) return;
  noriSupabaseClient = window.supabase.createClient(NORI_SUPABASE_URL, NORI_SUPABASE_ANON_KEY);

  noriSupabaseClient.auth.getSession().then(function (result) {
    noriSyncCurrentUser = result.data && result.data.session ? result.data.session.user : null;
    noriSyncAccessToken = result.data && result.data.session ? result.data.session.access_token : null;
    if (noriSyncCurrentUser) {
      noriSyncPullAndMergeAll();
      if (typeof noriBrainRefreshState === "function") noriBrainRefreshState().catch(function () {});
      try { window.dispatchEvent(new CustomEvent("nori:auth-ready")); } catch (e) {}
    }
  });

  noriSupabaseClient.auth.onAuthStateChange(function (event, session) {
    noriSyncCurrentUser = session ? session.user : null;
    noriSyncAccessToken = session ? session.access_token : null;
    if (noriSyncCurrentUser && event === "SIGNED_IN") {
      noriSyncPullAndMergeAll();
      if (typeof noriBrainRefreshState === "function") noriBrainRefreshState().catch(function () {});
      try { window.dispatchEvent(new CustomEvent("nori:auth-ready")); } catch (e) {}
    }
  });

  // Every local write anywhere in the app queues an upload — see the
  // header comment for why hooking one function covers everything.
  noriStorageOnWrite(function (key) {
    if (!noriSyncCurrentUser) return;
    noriSyncPendingKeys[key] = true;
    clearTimeout(noriSyncPushTimer);
    noriSyncPushTimer = setTimeout(noriSyncFlushPending, NORI_SYNC_DEBOUNCE_MS);
  });

  // Realtime: pick up changes made on OTHER devices without polling.
  noriSupabaseClient
    .channel("nori_data_changes")
    .on("postgres_changes", { event: "*", schema: "public", table: "nori_data" }, function (payload) {
      if (!noriSyncCurrentUser) return;
      if (payload.new && payload.new.user_id !== noriSyncCurrentUser.id) return; // RLS already filters this, belt-and-suspenders
      if (payload.new && payload.new.key) noriSyncPullAndMergeKey(payload.new.key);
    })
    .subscribe();
}

/* ---------------- auth ---------------- */

async function noriSyncSignUp(email, password, profile) {
  if (!noriSyncConfigured()) throw new Error("Sync isn't configured — set NORI_SUPABASE_URL and NORI_SUPABASE_ANON_KEY.");
  const result = await noriSupabaseClient.auth.signUp({ email: email, password: password, options: { data: { display_name: profile?.name || null } } });
  if (result.error) throw result.error;
  return result.data;
}

async function noriSyncLogIn(email, password) {
  if (!noriSyncConfigured()) throw new Error("Sync isn't configured — set NORI_SUPABASE_URL and NORI_SUPABASE_ANON_KEY.");
  const result = await noriSupabaseClient.auth.signInWithPassword({ email: email, password: password });
  if (result.error) throw result.error;
  noriSyncCurrentUser = result.data.user;
  noriSyncAccessToken = result.data.session ? result.data.session.access_token : null;
  return result.data;
}

async function noriSyncLogOut() {
  if (!noriSupabaseClient) return;
  await noriSupabaseClient.auth.signOut();
  noriSyncCurrentUser = null;
  noriSyncAccessToken = null;
}

function noriSyncGetCurrentUser() {
  return noriSyncCurrentUser;
}

/* ---------------- merge ---------------- */

// See the file header for why union-merge fits this app's append-only
// data shapes. Recurses through nested objects (e.g. per-subject history
// keyed by subject name, each value an array) so the same rule applies at
// every level, not just the top one.
function noriSyncMergeValues(local, remote) {
  if (local === undefined) return remote;
  if (remote === undefined) return local;

  if (Array.isArray(local) && Array.isArray(remote)) {
    const merged = local.slice();
    remote.forEach(function (rItem) {
      const alreadyPresent = merged.some(function (lItem) { return JSON.stringify(lItem) === JSON.stringify(rItem); });
      if (!alreadyPresent) merged.push(rItem);
    });
    return merged;
  }

  if (local && remote && typeof local === "object" && typeof remote === "object" && !Array.isArray(local) && !Array.isArray(remote)) {
    const merged = {};
    const allKeys = Object.keys(local).concat(Object.keys(remote)).filter(function (k, i, arr) { return arr.indexOf(k) === i; });
    allKeys.forEach(function (k) { merged[k] = noriSyncMergeValues(local[k], remote[k]); });
    return merged;
  }

  // Scalars, or mismatched shapes — no safe way to combine two different
  // values. Documented limitation: the more recently synced side wins.
  return remote;
}

/* ---------------- push / pull ---------------- */

async function noriSyncFlushPending() {
  const keys = Object.keys(noriSyncPendingKeys);
  noriSyncPendingKeys = {};
  for (const key of keys) await noriSyncPushKey(key);
}

async function noriSyncPushKey(key) {
  if (!noriSupabaseClient || !noriSyncCurrentUser) return;
  const localValue = noriSafeParse(localStorage.getItem(key), null);
  if (localValue === null) return;
  const result = await noriSupabaseClient
    .from("nori_data")
    .upsert({ user_id: noriSyncCurrentUser.id, key: key, value: localValue, updated_at: new Date().toISOString() }, { onConflict: "user_id,key" });
  if (result.error) console.error("Nori sync: push failed for", key, result.error.message);
}

async function noriSyncPullAndMergeKey(key) {
  if (!noriSupabaseClient || !noriSyncCurrentUser) return;
  const result = await noriSupabaseClient
    .from("nori_data")
    .select("value")
    .eq("user_id", noriSyncCurrentUser.id)
    .eq("key", key)
    .maybeSingle();
  if (result.error) { console.error("Nori sync: pull failed for", key, result.error.message); return; }
  if (!result.data) return; // nothing remote for this key yet

  const localValue = noriSafeParse(localStorage.getItem(key), null);
  const merged = localValue === null ? result.data.value : noriSyncMergeValues(localValue, result.data.value);
  noriSafeWrite(key, merged); // this itself queues a push if the merge changed anything — fine, it'll no-op if already in sync
}

async function noriSyncPullAndMergeAll() {
  if (!noriSupabaseClient || !noriSyncCurrentUser) return;
  const result = await noriSupabaseClient.from("nori_data").select("key, value").eq("user_id", noriSyncCurrentUser.id);
  if (result.error) { console.error("Nori sync: initial pull failed:", result.error.message); return; }

  (result.data || []).forEach(function (row) {
    const localValue = noriSafeParse(localStorage.getItem(row.key), null);
    const merged = localValue === null ? row.value : noriSyncMergeValues(localValue, row.value);
    noriSafeWrite(row.key, merged);
  });

  // Also push anything local-only that the server has never seen (e.g.
  // data created before this device ever signed in).
  noriDiscoverAllKeys().forEach(function (key) { noriSyncPendingKeys[key] = true; });
  noriSyncFlushPending();
}

window.addEventListener("DOMContentLoaded", noriSyncInit);

function noriSyncGetAccessToken() { return noriSyncAccessToken; }

/* Nori authentication bridge: Supabase Auth owns credentials; the database trigger owns profile role provisioning. */
window.NoriSyncAuth = {
  configured: function(){ return noriSyncConfigured(); },
  signUp: function(email,password,profile){ return noriSyncSignUp(email,password,profile); },
  signIn: function(email,password){ return noriSyncLogIn(email,password); },
  signOut: function(){ return noriSyncLogOut(); },
  session: function(){ return noriSupabaseClient ? noriSupabaseClient.auth.getSession() : Promise.resolve({data:{session:null}}); },
  supabaseClient: function(){ return noriSupabaseClient; },
  user: function(){ return noriSyncCurrentUser; },
  profile: async function(){
    if(!noriSupabaseClient || !noriSyncCurrentUser) return null;
    const r=await noriSupabaseClient.from('profiles').select('*').eq('id',noriSyncCurrentUser.id).maybeSingle();
    if(r.error) throw r.error; return r.data;
  },
  createPendingProfile: async function(profile){
    if(!noriSupabaseClient || !noriSyncCurrentUser) throw new Error('Verify/sign in before creating a Nori profile.');
    const r=await noriSupabaseClient.from('profiles').update({full_name:profile.name,display_name:profile.name,email:profile.email}).eq('id',noriSyncCurrentUser.id);
    if(r.error) throw r.error; return r.data;
  }
};
