/* NORI V48 — Study-block communication control for Instagram/Telegram.
 * Draft-first. No autonomous AI-like replies. User decides text vs call/video and content.
 */
(function(){'use strict';
 const ALLOWED=['instagram','telegram'];
 const KEY='nori.message.control.v48';
 const st={platform:null,mode:null,incoming:null,action:'ASK',draft:null};
 function reset(){Object.assign(st,{platform:null,mode:null,incoming:null,action:'ASK',draft:null});return st;}
 function begin(platform,mode,incoming){platform=String(platform||'').toLowerCase();if(!ALLOWED.includes(platform))throw new Error('Only Instagram and Telegram are supported by this study-block communication controller.');if(!['text','call','video'].includes(mode))throw new Error('Choose text, call, or video.');st.platform=platform;st.mode=mode;st.incoming=incoming||'';st.action='ASK';st.draft=null;return {ask:mode==='text'?'What should I say?':`What do you want me to do on the ${mode} request? You choose the response.`};}
 function ignore(){st.action='IGNORE';st.draft=null;return {action:'IGNORE',send:false};}
 function draft(text){if(st.action==='IGNORE')return {action:'IGNORE',send:false};if(!String(text||'').trim())return {action:'ASK',question:'What should I say?'};st.draft=String(text).trim();st.action='DRAFT';return {action:'DRAFT',draft:st.draft,send:false,requiresConfirmation:true};}
 function confirm(){if(st.action!=='DRAFT'||!st.draft)return {send:false,reason:'NO_CONFIRMED_DRAFT'};st.action='CONFIRMED';return {send:false,reason:'EXTERNAL_SEND_REQUIRES_EXPLICIT_USER_ACTION',draft:st.draft,platform:st.platform,mode:st.mode};}
 function openExternal(){if(!st.platform)return false;const url=st.platform==='telegram'?'https://t.me/':'https://www.instagram.com/';location.href=url;return true;}
 function capabilities(){return {platforms:ALLOWED,modes:['text','call','video'],rules:['ask what to say when unspecified','ignore means ignore','no autonomous AI-like messages','user chooses text/call/video','draft before send','external platform permissions required']};}
 window.NoriMessageControl={state:()=>Object.assign({},st),reset,begin,ignore,draft,confirm,openExternal,capabilities};
})();
