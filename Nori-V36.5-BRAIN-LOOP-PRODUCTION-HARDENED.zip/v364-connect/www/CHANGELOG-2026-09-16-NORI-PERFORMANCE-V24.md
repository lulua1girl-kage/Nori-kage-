# Nori V24 — Performance + Smarter Thinking

- Added conservative context-free response microcache for repeated generic requests.
- Added request timeouts so a stalled provider does not freeze the interaction indefinitely.
- Compacts conversation history before provider calls to reduce prompt size and latency.
- Adds a deterministic thinking directive: direct mode for simple requests, evidence separation for web, and constraint/evidence/alternative checking for difficult reasoning.
- Keeps model routing/cost controls from V23.
- Added local client performance helper for quick arithmetic, lightweight intent framing, and short-lived UI cache.
- No background surveillance, physical-punishment logic, or silent side effects.
