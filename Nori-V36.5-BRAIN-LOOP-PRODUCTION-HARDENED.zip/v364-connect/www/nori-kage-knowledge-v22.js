/* NORI KAGE KNOWLEDGE V22
   Local searchable rule catalog • precedence • conflicts • versions • audit evidence.
*/
(function(g){'use strict';
  var KEY='nori_kage_knowledge_v22';
  var VERSION='3.2';
  var PRECEDENCE=[
    {rank:100,id:'human_override',label:'Human Override'},
    {rank:90,id:'safety_integrity',label:'Safety / System Integrity'},
    {rank:80,id:'recovery',label:'Recovery'},
    {rank:70,id:'academic_priority',label:'Academic Priority'},
    {rank:60,id:'convenience',label:'Convenience'}
  ];
  var SOURCES=[
    {file:'nori-human-override-rules.json',category:'human_override',authority:100},
    {file:'nori-system-integrity-rules.json',category:'safety_integrity',authority:90},
    {file:'nori-exam-result-rules.json',category:'academic_priority',authority:70},
    {file:'nori-award-rules.json',category:'academic_priority',authority:70},
    {file:'NORI-BRAIN-V10.md',category:'system',authority:80},
    {file:'SMART-ADAPTIVE-COMMAND-V8.md',category:'adaptive',authority:80},
    {file:'NORI-VISUAL-SYSTEM-V9.md',category:'interface',authority:60}
  ];
  function now(){return new Date().toISOString()}
  function load(k,fb){try{var x=JSON.parse(localStorage.getItem(k)||'null');return x==null?fb:x}catch(e){return fb}}
  function save(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
  function norm(s){return String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()}
  function tokens(s){return norm(s).split(/\s+/).filter(function(x){return x.length>2})}
  function audit(type,data){var a=load(KEY+'/audit',[]);a.push(Object.assign({at:now(),version:VERSION,type:type},data||{}));save(KEY+'/audit',a.slice(-500));return a[a.length-1]}
  function sourceVersion(){return SOURCES.map(function(s){return {file:s.file,version:'source-unversioned',catalogVersion:VERSION}})}
  function precedence(){return PRECEDENCE.slice()}
  function search(query,limit){
    var q=tokens(query), docs=[];
    SOURCES.forEach(function(s){
      var text=''; try{var req=new XMLHttpRequest();req.open('GET',s.file,false);req.send(null);if(req.status>=200&&req.status<300)text=req.responseText||'';}catch(e){}
      var ts=tokens(text), overlap=q.reduce(function(n,x){return n+(ts.indexOf(x)>=0?1:0)},0);
      if(overlap>0)docs.push({source:s.file,category:s.category,authority:s.authority,score:overlap,text:text.slice(0,12000)});
    });
    docs.sort(function(a,b){return (b.score*10+b.authority)-(a.score*10+a.authority)});var out=docs.slice(0,limit||6);audit('knowledge_search',{query:String(query||'').slice(0,300),results:out.map(function(x){return {source:x.source,score:x.score,authority:x.authority}})});return out;
  }
  function resolveConflict(items){
    items=(items||[]).map(function(x){return Object.assign({},x,{authority:Number(x.authority)||0})}).sort(function(a,b){return b.authority-a.authority});
    if(items.length<2)return {conflict:false,items:items,winner:items[0]||null,reason:'Insufficient competing rule evidence.'};
    var top=items[0], second=items[1];
    var conflict=top.authority!==second.authority;
    var result={conflict:conflict,items:items,winner:top,reason:conflict?'Higher-precedence rule wins under KAGE Rule Catalog v'+VERSION+'.':'Rules have equal authority; human review is required rather than inventing a winner.'};
    audit('rule_conflict', {conflict:conflict,winner:top&&top.source,reason:result.reason}); return result;
  }
  function explainDecision(decision,evidence){
    var ev=(evidence||[]).slice(0,8).map(function(x){return typeof x==='string'?x:(x.label||x.source||x.id||JSON.stringify(x))});
    var record={id:'decision_'+Date.now().toString(36),at:now(),version:VERSION,decision:String(decision||''),evidence:ev,precedence:PRECEDENCE.slice(),explanation:'Decision recorded from the listed evidence and current KAGE precedence. This record does not claim that AI reasoning itself is a rule.'};
    audit('decision_explanation',record);return record;
  }
  function catalog(){return {version:VERSION,precedence:precedence(),sources:sourceVersion()}}
  g.NoriKageKnowledgeV22={version:VERSION,catalog:catalog,search:search,precedence:precedence,resolveConflict:resolveConflict,explainDecision:explainDecision,audit:function(){return load(KEY+'/audit',[])}};
})(window);
