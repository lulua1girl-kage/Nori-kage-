# Nori V32 — Post-23 Step 15 Brain Capacity Expansion

This step expands the existing Human-Centered Brain rather than replacing it.

## 20 implemented improvements
1. Request normalization
2. Local intent classification
3. Adaptive reasoning effort
4. Minimal-disclosure policy
5. Humane response-mode selection
6. Goal vs task scope detection
7. Context compression
8. Repeated-pattern detection
9. Evidence threshold before strictness
10. Safety-first boundary
11. Fresh-research gate
12. Privacy-aware cache eligibility
13. Deterministic request keys
14. Short burst plan memoization
15. Post-action verification contract
16. Decision history without conversation-content storage
17. Human Override guard
18. 10+ source research target
19. Local-first external escalation
20. Unified preflight planning

## Provider-speed upgrades
- Shared executor instead of creating a new thread pool per request.
- 15-second provider cooldown after timeout to avoid repeatedly hammering a stuck provider.
- Small bounded response cache for eligible non-personal responses.
- Streaming path remains available.
- Existing 10-second remote timeout remains the ceiling.

## Android performance
A baseline profile seed is included for critical Brain paths. It must be regenerated and benchmarked on a physical device before release. Android documents Baseline Profiles as a way to precompile critical code paths and recommends benchmarking on a physical device.

## Important limitation
The current environment does not contain the Android SDK/Gradle distribution, so a full APK build and device benchmark cannot be honestly claimed here.
