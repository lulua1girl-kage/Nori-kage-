# Nori KAGE V32 — Android Build Hardening

V32 is an installability/build-focused release based on V31.

## Build hardening
- Android Gradle Plugin 8.13.0 / Gradle 8.13 configuration.
- Android compile/target SDK 36, minimum SDK 24.
- Java 21 source/target configuration; AGP 8.x requires JDK 17+.
- Added Gradle properties for stable AndroidX builds.
- Added SDK-path example without committing machine-specific paths.
- Added Android toolchain diagnostic script.
- Added stricter APK build verification.
- Added portable Gradle launcher that refuses to pretend a missing compiler exists.
- Fixed a native compile blocker: the app previously referenced a Material3 theme without declaring a Material3 dependency. V32 uses the Android framework theme instead.
- Preserved V31 web UI, privacy, self-model, voice, owner/admin, history and Human Override systems.

## Important limitation
The source package cannot contain Android's proprietary/large compiler toolchain as a substitute for a real SDK installation. A machine running the final build must provide Android SDK Platform 36, compatible Build Tools/aapt2, and Gradle 8.13 or Android Studio.


## Stage 5 — Native KAGE / Override
- Added native KageEngine, ConsequencePolicy, AuditRecord, MeritLedger, KageRepository.
- Exposed KageEngine through native NoriBrain.
- Preserved all V32 KAGE/Override JS as migration reference.

## Stage 6 — Native Academic Engine
- Migrated V32 academic assessment analysis into native Java.
- Added typed Assessment and AcademicAnalysisResult models.
- Preserved V32 score bands, assessment weights, concept-ratio logic, and error-classification precedence.
- Added AcademicRepository persistence boundary without replacing generic V32/native storage.
- Exposed AcademicEngine through native NoriBrain.
- Added native unit tests.
- Preserved all V32 academic JavaScript and UI as migration reference.

## Stage 7 — Native Brain Core
- Connected native IntentEngine, ContextEngine, AcademicEngine, KageEngine, ConsequencePolicy and VerificationEngine through NoriBrain.
- Added structured AcademicEventInput and BrainDecision contracts.
- Migrated V32 context classification into native Java.
- Added deterministic intent routing for core Brain intents.
- Added verification pass separating facts, inferences and next actions.
- Kept Stage 7 recommendation-only: no silent consequence execution or data mutation.
- Preserved all V32 JavaScript Brain/engine files as migration reference.

## Stage 8 — Native Memory & Personal Model
- Added native MemoryItem with category, confidence/status, importance, timestamps, source and provenance.
- Added native MemoryEngine with explicit remember/update/archive/delete/recall behavior.
- Added credential and sensitive-memory rejection based on V32 memory policy.
- Added relevance-ranked recall using overlap, exact match, importance, confidence and recency.
- Added bounded 500-item memory policy.
- Added repository-backed memory persistence through DataRepository.
- Added native PersonalModel projection for goals, preferences, projects, academic state, work patterns, constraints, communication preferences, current priorities, confirmed facts and uncertain assumptions.
- Added structured MemoryDecision responses.
- Connected MemoryEngine and PersonalModel access to NoriBrain.
- Updated NoriNativeCore and native shell construction so the Brain receives the existing native repository.
- Preserved V32 memory, self-model and learning JavaScript as migration reference.
- Added Stage 8 documentation and status.

## 2026-09-17 — Stage 9: Native Tool & Action System
- Added native ActionEngine with proposal, preview, confirmation, execution, verification, cancellation and undo boundaries.
- Added ToolRouter, ToolDefinition, ToolRequest, ActionProposal/Preview/Result/Status models.
- Added EducationalPurposeFirewall and permission-check boundary.
- Added deterministic local academic adapters for task creation/completion, study-session creation and explicit result recording.
- Connected Stage 9 ActionEngine/ToolRouter to NoriBrain.
- Preserved V32 nori-action-core-v27.js, nori-action-center-v27.js and nori-tool-router-v22.js unchanged as migration references.
- Device/external integrations remain disabled until Stage 10 supplies Android permission/service adapters.
- Native Stage 9 smoke tests pass.

## Stage 10 — Native Android Services
- Added native notification boundary.
- Added inexact reminder alarm service and non-exported receiver.
- Added user-mediated calendar event boundary.
- Added Storage Access Framework file boundary.
- Added permissioned UsageStats screen-time boundary.
- Added explicit focus/accessibility/overlay settings boundary.
- Added Android runtime permission adapter for Stage 9 actions.
- Added central NoriAndroidServices registry.
- Preserved existing V32 voice/blocker implementations and all prior native stages.

## Stage 11 — Native AI Provider Layer
- Added provider-neutral native AI abstraction and routing.
- Added local deterministic fallback and optional remote adapter.
- Remote AI disabled by default and requires explicit consent.
- Added bounded request/output sizes and graceful fallback.
- Added Brain integration through askOptionalAi().
- Preserved V32 AI/Brain JavaScript implementation.

## Stage 12 — Educational Intelligence
- Added native offline-first EducationalIntelligence coordinator.
- Added adaptive planning, strength/weakness analysis, mistake intelligence, learning-pattern analysis, exam preparation, dynamic study sessions, and adaptive tutoring policy.
- Added bounded academic evidence history with optional native repository persistence.
- Connected NoriBrain to EducationalIntelligence and automatic academic-event evidence capture.
- Preserved V32 JavaScript systems and Stage 9 action/override boundaries.

## Stage 14 — Admin & Multi-Student System
- Added native AdminControlPlane and role/access models.
- Added owner bootstrap, invitation allowlist/revocation, student registry, authorization and bounded admin audit.
- Added NoriBrain.getAdminControlPlane().
- Preserved V32 and all prior native stages.
- Full Android build remains a separate Android Studio validation step because the current environment lacks the Android SDK/Gradle wrapper JAR.

## Stage 17 — Voice & Conversation Polish
- Added native conversation models and bounded session state.
- Added Tutor/Command/Casual/Exam/Planning voice modes.
- Added mode-aware voice presentation policy.
- Added explicit action-confirmation and protected-rule human-input gates.
- Connected ConversationEngine to NoriBrain.
- Preserved existing opt-in Android voice service and all prior V32/native stages.

## Stage 18 — UI/UX Completion
- Reworked native Java UI into a coherent dark dossier interface.
- Added reusable theme primitives, metrics, cards and spacing.
- Added Home, Study, Plan, Results, KAGE, Recover and Settings surfaces.
- Added persistent native bottom navigation and header.
- Preserved V32 and all Brain/action safety boundaries.

## Stage 21
- Added native performance/offline boundary.
- Added bounded process-local cache and timing monitor.
- Added explicit offline-first connectivity policy and resource budgets.
- Preserved V32 and prior security/action boundaries.

## Stage 22 — Release Candidate
- Froze release-candidate identity at versionCode 33 / versionName 33.0.0-rc1.
- Added native release metadata and reproducible release gate.
- Release gate runs Stage 20 regression + Stage 21 offline/performance verification.
- Added manifest/security/version consistency checks and credential-pattern scan.
- Final APK/AAB build and physical-device validation remain an Android Studio/SDK gate.

## Stage 23 — Future Evolution & Final Architecture
- Final staged-migration architecture freeze and handoff boundary.
- Added `FutureEvolutionPolicy` for controlled post-release change classes.
- Added bounded explicit `ExtensionRegistry`; no runtime code download/self-installation.
- Documented protected boundaries, evolution rules, data migration policy, AI optionality, and final release status.
- Added `verify-stage23.sh` and deterministic Stage 23 checks.
- Final Android APK/device validation remains an external Android Studio/SDK gate.
