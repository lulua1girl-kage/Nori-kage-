# Post23 Step45 — Five-X Knowledge, Humanization, Trust & Cloud Library

This advancement expands the Step45 Knowledge Hub into a governed student knowledge system.

## 1. Fast multi-format library
Supported routing now covers PDF, DOC/DOCX, PPT/PPTX, XLS/XLSX, CSV/TSV, TXT/Markdown, HTML/XML/JSON, RTF, EPUB, OpenDocument text/spreadsheets/presentations, images, audio, video, archives and source code.

The pipeline is metadata-first: accept/index immediately, queue expensive extraction, deduplicate by content hash, and deep-process only the relevant material.

## 2. 15 GB logical cloud library
15 GB is a per-user logical quota, not an on-device allocation. The preferred architecture is cloud object storage with resumable upload (Supabase TUS when configured), Firebase resumable storage as an alternative, and Android Storage Access Framework for user-owned document providers. Local storage is bounded cache/index data.

Android's Storage Access Framework lets the user explicitly select documents/folders and can work with cloud document providers. It does not grant Nori unrestricted access to another app's private data.

## 3. Registered-user boundary
Nori now has an explicit active-user identity and deterministic per-user library/memory scopes. Personalization means continuity for the signed-in student, not obedience, exclusivity, surveillance or replacement of real relationships.

## 4. Internet source intelligence
Nori ranks sources by primary/official status, topic match, evidence quality, corroboration, transparency and recency. YouTube/video/community sources are useful discovery leads but are not automatically facts. Contradictions remain visible.

## 5. Humanized cooperation
Nori can support, collaborate, challenge, be firm, or enter recovery/safety stance. It is deliberately not a yes-machine: evidence or the user's own stated goal can cause respectful disagreement.

## 6. Disclosure response
The disclosure policy is trauma-informed and non-diagnostic. It avoids forced disclosure and unnecessary probing. Safety seriousness can increase when evidence rises, while preserving agency. This follows the general principles in WHO guidance: minimize additional distress, use age-appropriate/non-stigmatizing communication, offer choices, and avoid making a child repeatedly retell a disclosure. UNICEF guidance likewise emphasizes calm, caring, non-judgmental responses and linking children to appropriate specialist support.

## 7. Visual context
Anatomy, biology and medical-education imagery can remain available when the educational purpose is clear. Topic sensitivity alone does not trigger a blanket block. Graphic-harm or sexualized contexts are handled separately.

## 8. Autonomous learning
Nori can discover, filter, compare, verify, store provenance, reflect and adapt learning strategies. It cannot silently rewrite constitutional rules, permissions, identity boundaries or sensitive personal facts.

## 9. Reliability principle
Nori's target is not omniscience. The target is fast retrieval + source selection + contradiction detection + calibrated uncertainty + strong teaching. It should say what it knows, why it believes it, and what would change the answer.
