# Nori Native Java — Stage 3: App Shell

Stage 3 establishes the native Android UI/navigation body in parallel with V32.

## Added
- `NativeMainActivity`
- `NoriNavigator`
- `NoriTheme`
- Native screens: Home, Academics, Plan, Results, KAGE, Settings
- Native activity declaration in AndroidManifest

## Deliberate non-changes
- Existing `MainActivity` remains the launcher.
- Capacitor/Web UI remains untouched.
- Existing Brain/KAGE/voice/blocker behavior remains untouched.
- Native screens are shell placeholders; they do not pretend that migration is complete.

## Why parallel
This lets the native UI be tested before it takes control of the application. A later stage can connect migrated engines one subsystem at a time.

## Exit criteria
1. Native activity opens successfully.
2. Navigation between shell screens works.
3. App survives rotation/lifecycle appropriately.
4. Data repository can be created/closed without affecting V32.
5. Only after validation should launcher ownership be considered for migration.
