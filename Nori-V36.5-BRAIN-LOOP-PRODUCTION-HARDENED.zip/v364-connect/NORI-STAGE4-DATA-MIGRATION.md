# Nori Stage 4 — Native Storage & V32 Data Migration

## Objective

Give the native Java application a safe persistent data layer and a
non-destructive path for importing the existing V32 localStorage data.

## Implemented

1. Native SQLite store: `nori_native.db`.
2. Generic JSON/string preservation so old records are not prematurely
   converted into new models.
3. V32 export helper: `www/nori-v32-native-export.js`.
4. Pre-import validation: `V32MigrationValidator`.
5. Import coordinator: `NativeMigrationManager`.
6. Native-store JSON backup/export.
7. Existing native keys are skipped by default.
8. No V32 localStorage deletion is performed.
9. No existing V32 storage module was replaced.
10. Dynamic `nori_phase_*` keys remain supported.

## Migration protocol

V32 localStorage
  -> exact JSON snapshot
  -> validate
  -> native import
  -> count/report
  -> equivalence verification
  -> only later consider native authority

## Important boundary

Stage 4 does NOT make native storage the sole source of truth yet.
Both systems remain available until equivalence testing proves that the
native representation preserves the required V32 behavior.

## Safety rules

- Never delete V32 data during migration.
- Never silently overwrite native data.
- Preserve unknown keys.
- Preserve exact localStorage values as strings.
- Record schema versions.
- Make future database upgrades additive and reversible where practical.
- Do not retire old V32 storage code until the corresponding native
  behavior has passed regression tests.

## Next

Stage 5 can begin migrating KAGE/Override logic while continuing to use
the repository as the stable persistence boundary.
