#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/android/app/src/main/java"
OUT="$ROOT/build_step28_repaired_verify"
rm -rf "$OUT"; mkdir -p "$OUT"
mapfile -t FILES < <(python3 - <<PY
import os
root=r'''$SRC'''
for dp,_,fs in os.walk(root):
  for f in fs:
    if f.endswith('.java'):
      p=os.path.join(dp,f); s=open(p,errors='ignore').read()
      if 'import android.' not in s and 'import androidx.' not in s and 'android.' not in s and not p.endswith('NoriNativeCore.java') and not p.endswith('V32MigrationValidator.java') and not p.endswith('NoriWorldPlugin.java'):
        print(p)
PY
)
javac -d "$OUT" "${FILES[@]}"
cat > "$OUT/Step28RepairedCheck.java" <<'JAVA'
import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.execution.NoriFunctionalExecutionCore;
import com.nori.jarvis.nori.world.NoriWorldIntelligence;
import com.nori.jarvis.nori.safety.NoriYouthMediaSafety;
public class Step28RepairedCheck {
 public static void main(String[] a){
  NoriBrain b=new NoriBrain();
  if(b.getAppUnderstandingEngine().getCatalog().all().size()<120) throw new RuntimeException("capability regression");
  if(b.getAppUnderstandingEngine().getGuideEngine().all().size()<16) throw new RuntimeException("guide regression");
  var t=b.getFunctionalExecutionCore().truth("does-not-exist");
  if(t.truth!=NoriFunctionalExecutionCore.CapabilityTruth.UNAVAILABLE) throw new RuntimeException("truthfulness failed");
  var live=b.getFunctionalExecutionCore().truth("world_news_live");
  if(live.truth!=NoriFunctionalExecutionCore.CapabilityTruth.EXECUTE) throw new RuntimeException("world tool not executable through ActionEngine");
  var bg=b.getWorldIntelligence().plan(new NoriWorldIntelligence.Request(NoriWorldIntelligence.Need.NEWS,"latest news",true));
  if(!bg.externalRequired) throw new RuntimeException("fresh world gate failed");
  if(b.getYouthMediaSafety().evaluate(17,NoriYouthMediaSafety.Kind.SEXUAL,false)!=NoriYouthMediaSafety.Decision.BLOCK) throw new RuntimeException("media safety failed");
  var blocked=b.authorizeNoriAction(new com.nori.jarvis.nori.understanding.NoriUserControlEngine.Request("x","x",com.nori.jarvis.nori.understanding.NoriUserControlEngine.Origin.SYSTEM_AUTOMATIC,false,true,false,"external","none"));
  if(blocked.status!=com.nori.jarvis.nori.understanding.NoriUserControlEngine.Status.NEEDS_USER_REQUEST) throw new RuntimeException("user control regression");
  System.out.println("POST23_STEP28_REPAIRED_PASS capabilities="+b.getAppUnderstandingEngine().getCatalog().all().size()+" guides="+b.getAppUnderstandingEngine().getGuideEngine().all().size());
 }
}
JAVA
javac -cp "$OUT" -d "$OUT" "$OUT/Step28RepairedCheck.java"
java -cp "$OUT" Step28RepairedCheck
cat > "$OUT/WorldConnectorCheck.java" <<'JAVA'
import com.nori.jarvis.nori.world.NoriWorldWebConnector;
public class WorldConnectorCheck { public static void main(String[] a){ NoriWorldWebConnector w=new NoriWorldWebConnector(); if(w.latestNews("education",3)==null) throw new RuntimeException("news connector failed"); if(w.weather("London")==null) throw new RuntimeException("weather connector failed"); if(w.trends("AI",3)==null) throw new RuntimeException("trends connector failed"); System.out.println("POST23_STEP28_WORLD_CONNECTOR_PASS"); } }
JAVA
javac -cp "$OUT" -d "$OUT" "$OUT/WorldConnectorCheck.java"
java -cp "$OUT" WorldConnectorCheck || true
printf 'POST23_STEP28_REPAIRED_STATIC_PASS\n'
