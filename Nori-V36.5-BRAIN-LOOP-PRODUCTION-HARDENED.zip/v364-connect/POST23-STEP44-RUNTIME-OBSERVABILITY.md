# Post-23 Step 44 — Runtime Observability & Real-World Measurement

Step 44 advances the previous integrated brain by measuring the system it actually runs on.

## Measurements
- latency: per operation plus P50/P95 session telemetry
- memory: Android PSS and available memory snapshots on demand
- battery: Android BatteryManager percentage/charging state on demand
- model selection: task, multimodality, privacy, latency budget, model size and context constraints
- web retrieval: bounded HTTPS GET with status, provenance URL, retrieval timestamp, response size limit and latency
- Android actions: existing ActionEngine remains the authority; NoriOperations records real prepare/execute/verify latency
- long sessions: request count, failure count, consecutive failures, P95 latency and bounded reset recommendation

## Design rules
- no background telemetry
- no raw conversation content in telemetry
- no automatic battery optimization changes
- web requires HTTPS and bounded time/bytes
- model selection never downloads a model silently
- action measurement does not bypass confirmation or permissions
- long-session reset is a recommendation/state signal, not an automatic destructive reset

## Current measurement boundary
The instrumentation is device-capable. A real Samsung/Android run is required for truthful battery, PSS, hardware model availability and end-to-end action numbers. Source-level smoke tests must not be presented as device measurements.
