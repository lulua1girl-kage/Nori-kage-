# Post-28 — Advanced Creative Image + PDF Layer

This is an additive capability layer. It does not replace the existing Nori Brain, Kage, Interactive Circle, memory, navigation, ActionEngine, permissions, or Human Override.

## Image generation
NoriImageGenerationEngine provides:
- create, edit, variation, inpaint, outpaint, storyboard and diagram request modes
- aspect ratio and quality planning
- multiple variants (bounded to 4)
- style and negative-prompt fields
- optional reference asset identifier
- transparent-background intent
- provider-neutral ImageProvider contract
- local/remote provider distinction
- safety gate before generation
- truthful `no_image_provider_configured` state instead of pretending generation occurred

A configured image-capable provider performs the actual model inference. The app does not claim to contain a frontier image model locally.

## PDF generation
NoriPdfGenerationEngine provides structured document specifications and conversion from plain text into sections.
NoriPdfService uses Android's native `PdfDocument` API to render multipage PDFs offline without a paid PDF service.

Supported document types include notes, study guides, reports, assignments, revision sheets, plans, resumes and custom documents.

## Intelligent use
NoriCreativeIntentEngine detects when the user actually asks for image/PDF creation. It should not interrupt unrelated conversation merely to advertise creative tools.

## Safety and control
- Creative capability is not authorization to act.
- Image generation remains subject to NoriYouthMediaSafety and other system policies.
- No automatic publishing or posting.
- References and camera/screen assets require explicit user action/permission.
- Remote image generation is opt-in/configured and may have provider privacy/cost implications.
- PDF creation can remain fully local.
