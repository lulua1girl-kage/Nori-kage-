# Post-23 Step 7 — Voice-to-Action + Exam Integrity

## Voice-to-action orchestration
- Background voice wake word remains explicit-session only.
- After `Nori` is detected, speech is parsed into a structured intent before execution.
- Academic intents: new result, new assessment, new assignment, another entry/subject, exam mode.
- The native voice workspace collects missing fields and keeps them editable.
- Saving is an explicit human confirmation.
- The workspace stores a structured intake record in native SQLite; existing academic/KAGE engines remain separate and can analyze it without direct disciplinary coupling.
- A background command cannot arbitrarily launch an Activity. Android-compatible flow is: wake -> intent -> visible notification -> user taps Return -> workspace opens. If the app is already visible, the command event can be handled immediately.
- Explicit `open WPS/Instagram/Pinterest/...` can use a direct notification PendingIntent. Active Nori focus restrictions are checked first; a blocked app is not used as a bypass.

## Exam integrity screen analysis
- User explicitly enters Exam Integrity mode and accepts Android MediaProjection consent.
- Foreground application identity is sampled via UsageStats.
- Nori does not continuously record the screen.
- A screen frame is captured only on a suspicious trigger: configured distraction app foreground or rapid app switching.
- Each trigger is labeled as evidence with a confidence signal; it is not treated as proof of misconduct.
- The captured frame is transient and forwarded through the existing visual-context event boundary when the app is active. This layer does not silently persist screenshots as memory.
- The monitor has a bounded four-hour session, visible foreground-service notification, and stops non-sticky.
- No hidden camera or microphone recording is introduced by this feature.

## Integrity boundary
- Result calculation and KAGE consequence analysis remain separate.
- Device restrictions are user-enabled focus controls, not physical or harmful punishment.
- Human Override remains above convenience.
- The system can answer ordinary questions and perform normal app navigation; integrity rules constrain actions that conflict with an active protection state rather than making Nori generally obstructive.

## Android limitation
Android does not provide a general permission for an app to silently launch arbitrary activities from the background. This release therefore uses a notification/PendingIntent handoff for background voice commands rather than trying to evade that platform boundary.
