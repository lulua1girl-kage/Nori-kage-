# Stage 21 — Performance & Offline

This package is the Stage 21 continuation of Nori V32 Native Java. It adds offline-first performance infrastructure while preserving the existing migration architecture.

Run `./verify-stage21.sh` for the native regression check. Full Android compilation still belongs in Android Studio with an installed Android SDK/Gradle environment.
