# Nori V32 — Post-23 Step 19

## Cognitive Core: higher-order thinking + faster adaptive routing

Built directly on Step 18.

### Core change
Nori now has a Cognitive Core that asks, in bounded structured form:
- What is the user actually trying to accomplish?
- What interpretations are plausible?
- What constraints matter?
- What evidence is needed?
- Is current information required?
- What could contradict the first interpretation?
- Is a tool/action actually necessary?
- What must be verified before answering?
- What answer shape best fits the situation?
- How much reasoning effort is justified?

This is not exposed chain-of-thought. The app receives a compact decision state and checks.

### 41 higher-order features
See `NoriCognitiveFeatureCatalog`.

### Speed
The cognitive preflight has a 256-entry hot cache, deterministic keys, no I/O, and a MICRO effort path. Existing Step 17/18 performance architecture remains intact.

No unsupported claim of 5x/10x real-world speed is made. Real speed must be benchmarked on a physical Android device. Android recommends Baseline Profiles + Macrobenchmark for this measurement.
