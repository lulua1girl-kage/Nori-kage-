# Nori V32 — Stage 10 Native Android Services

Stage 10 connects Nori to Android capabilities through explicit native service boundaries.

## Included
- Notification channel/post/cancel boundary.
- Inexact reminder alarms using AlarmManager + a non-exported receiver.
- Calendar event creation through Android's user-facing calendar UI; no silent calendar mutation.
- Storage Access Framework open/create document intents; no broad storage permission.
- Permissioned UsageStats screen-time evidence collection.
- Explicit focus/accessibility/overlay settings boundary; no silent accessibility enablement.
- Central `NoriAndroidServices` registry.
- Runtime permission adapter for ActionEngine.

## Safety and architecture
- These classes expose capabilities, not autonomous authority.
- Stage 9 ActionEngine remains the proposal/confirmation/verification boundary.
- No arbitrary shell/command execution was added.
- No silent app launching or distraction optimization was added.
- Screen-time data is evidence only; the service does not infer causes.
- Exact-alarm permission is intentionally not requested in Stage 10.
- Existing V32 blocker and voice implementations remain intact.

## Deferred
- Full ActionEngine adapters for every Android service.
- Native notification UI polish.
- Calendar provider read/write with explicit permission, if later justified.
- Accessibility-based blocking, only after explicit permission, educational-purpose checks, and dedicated validation.
- Device camera integration; existing camera permission remains unchanged.

## Migration rule
New native capability -> verify -> connect through Stage 9 -> compare with V32 -> only then retire old implementation.
