#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/android/app/src/main/java"
OUT="$ROOT/build_step25_verify"
rm -rf "$OUT"; mkdir -p "$OUT"
mapfile -t FILES < <(python3 - <<PY
import os
root=r'''$SRC'''
for dp,_,fs in os.walk(root):
  for f in fs:
    if f.endswith('.java'):
      p=os.path.join(dp,f); s=open(p,errors='ignore').read()
      if 'import android.' not in s and 'import androidx.' not in s and 'android.' not in s and not p.endswith('NoriNativeCore.java') and not p.endswith('V32MigrationValidator.java'):
        print(p)
PY
)
javac -d "$OUT" "${FILES[@]}"
test -f "$SRC/com/nori/jarvis/nori/conversation/intelligence/NoriConversationIntelligence.java"
test -f "$SRC/com/nori/jarvis/nori/conversation/intelligence/NoriLanguageIntelligence.java"
test -f "$SRC/com/nori/jarvis/nori/actions/coordination/NoriToolCoordinationEngine.java"
grep -q 'understandConversation' "$SRC/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'coordinateTool' "$SRC/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'ambientVoiceOptIn' "$SRC/com/nori/jarvis/voice/NoriVoiceService.java"
grep -q 'EXTRA_LANGUAGE' "$SRC/com/nori/jarvis/voice/NoriVoiceService.java"
echo 'POST23_STEP25_CONVERSATION_TOOLS_SOURCE_PASS'
