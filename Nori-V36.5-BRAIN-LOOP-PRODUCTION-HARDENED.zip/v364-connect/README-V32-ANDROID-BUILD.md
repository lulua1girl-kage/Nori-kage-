# Nori KAGE V32 — Android Build Ready

V32 is an Android-build-focused release. It does not claim to contain a fake or embedded Android compiler.

## Recommended build machine
- Android Studio with Android SDK Platform 36 and compatible Build Tools
- JDK 17+ (JDK 21 is supported by this project configuration)
- Node.js + npm
- Gradle 8.13, or Android Studio's Gradle integration

## Build
1. Extract this package.
2. Run `./diagnose-android-v32.sh`.
3. Run `./build-v32.sh` after the diagnostic passes.
4. Debug APK output: `android/app/build/outputs/apk/debug/app-debug.apk`

## Android Studio route
Open the `android/` folder as a project. Let Android Studio install/resolve the configured Gradle and SDK components, then build `app`.

## Why the APK is not inside this ZIP
An APK must be produced by the Android compiler/toolchain (AAPT2, D8/R8, SDK platform/build tools and Gradle/AGP). V32 prepares the project and detects those dependencies; it does not fabricate them.
