#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "$0")" && pwd)"
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
pass(){ printf '[PASS] %s\n' "$1"; }
warn(){ printf '[WARN] %s\n' "$1"; }
fail(){ printf '[FAIL] %s\n' "$1"; }
echo "NORI V32 Android Toolchain Diagnostic"
echo "======================================"
command -v java >/dev/null 2>&1 && pass "Java found: $(java -version 2>&1 | head -1)" || fail "Java missing"
command -v node >/dev/null 2>&1 && pass "Node found: $(node --version)" || fail "Node missing"
command -v npm >/dev/null 2>&1 && pass "npm found: $(npm --version)" || fail "npm missing"
command -v gradle >/dev/null 2>&1 && pass "Gradle found: $(gradle --version | grep '^Gradle ' | head -1)" || warn "Gradle not on PATH"
if [ -n "$SDK" ] && [ -d "$SDK" ]; then
  pass "Android SDK: $SDK"
  [ -d "$SDK/platforms/android-36" ] && pass "Android API 36 platform" || warn "Android API 36 platform missing"
  [ -x "$SDK/build-tools/35.0.0/aapt2" ] && pass "Build Tools 35.0.0 / aapt2" || warn "Build Tools 35.0.0 / aapt2 missing"
  [ -x "$SDK/build-tools/36.0.0/aapt2" ] && pass "Build Tools 36.0.0 / aapt2" || true
else
  fail "Android SDK path not configured"
fi
[ -d "$ROOT/node_modules" ] && pass "npm dependencies installed" || warn "node_modules absent; run npm install"
[ -f "$ROOT/android/gradle/wrapper/gradle-wrapper.properties" ] && pass "Gradle wrapper configuration present" || fail "Wrapper configuration missing"
[ -f "$ROOT/android/app/build.gradle" ] && pass "Android app Gradle project present" || fail "Android app project missing"
[ -f "$ROOT/android/app/src/main/AndroidManifest.xml" ] && pass "Android manifest present" || fail "Manifest missing"
echo
echo "Required for an APK: Android SDK + platform/build-tools + Gradle/Android Studio + npm dependencies."
