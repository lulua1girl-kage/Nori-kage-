#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
"$ROOT/verify-post23-step36-43.sh"
OUT="$ROOT/.step44-classes"; rm -rf "$OUT"; mkdir -p "$OUT"
mapfile -t FILES < <(python3 - <<PY
import os
root=r'''$ROOT/android/app/src/main/java'''
for dp,_,fs in os.walk(root):
  for f in fs:
    if not f.endswith('.java'): continue
    p=os.path.join(dp,f); s=open(p,errors='ignore').read()
    if any(x in s for x in ['import android.','import androidx.','import com.getcapacitor.']): continue
    if p.endswith(('NoriNativeCore.java','NoriWorldPlugin.java','NoriOperationsPlugin.java','MainActivity.java','V32MigrationValidator.java')): continue
    print(p)
PY
)
javac -d "$OUT" "${FILES[@]}"
java -cp "$OUT" com.nori.jarvis.nori.benchmark.NoriRuntimeAdvancementSmoke
grep -q 'NoriRuntimeTelemetry' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'NoriLongSessionMonitor' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'NoriModelSelectionEngine' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'NoriLiveWebRetrieval' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'NoriRuntimePlugin.class' "$ROOT/android/app/src/main/java/com/nori/jarvis/MainActivity.java"
grep -q 'latencyMs' "$ROOT/android/app/src/main/java/com/nori/jarvis/NoriOperationsPlugin.java"
grep -q 'NoriAndroidRuntimeProbe' "$ROOT/android/app/src/main/java/com/nori/jarvis/NoriRuntimePlugin.java"
echo 'POST23_STEP44_RUNTIME_OBSERVABILITY_PASS'
