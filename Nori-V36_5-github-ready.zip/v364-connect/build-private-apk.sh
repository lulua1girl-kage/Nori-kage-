#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
if [ -z "${ANDROID_HOME}" ] || [ ! -d "${ANDROID_HOME}" ]; then
  echo "Android SDK not found. Set ANDROID_HOME to your Android SDK." >&2
  exit 2
fi
if ! command -v node >/dev/null 2>&1 || ! command -v npm >/dev/null 2>&1; then
  echo "Node.js and npm are required." >&2
  exit 2
fi
npm install --no-audit --no-fund
if [ ! -d android ]; then npx cap add android; fi
npx cap sync android
if [ -f native-voice/NoriVoicePlugin.java ]; then
  mkdir -p android/app/src/main/java/com/nori/jarvis/voice
  cp native-voice/NoriVoicePlugin.java native-voice/NoriVoiceService.java android/app/src/main/java/com/nori/jarvis/voice/
fi
if [ -f android/gradlew ]; then
  chmod +x android/gradlew
  cd android
  ./gradlew assembleDebug
else
  echo "Capacitor Android project was not generated." >&2
  exit 3
fi
