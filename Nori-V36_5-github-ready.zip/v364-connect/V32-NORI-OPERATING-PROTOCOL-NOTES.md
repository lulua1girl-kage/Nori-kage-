# Nori V32 — Operating Protocol

This V32 pass addresses weaknesses 49–80 as a protocol/integration hardening layer. It does not create another brain.

## Common protocol

Every new capability can use:

- Intent: source, session, goal, entities, requested action, confidence, context, confirmation.
- Session: shared session ID, correlation/request/intent/action IDs, pending action, route/context.
- Pending action: durable browser-backed pending state with expiry and proposal linkage.
- Policy: READ / PROPOSE / MUTATE / DELETE / NAVIGATE / SPEAK operation classes and risk/confirmation policy.
- Result: `{ ok, status, data, stateChanges, verification, userMessage, errors }`.
- Error codes: capability unavailable, permission required, auth required, conflict, validation failed, confirmation required, execution failed, verification failed, cancelled, timeout, dependency unavailable, locked, idempotent replay, transaction failed.
- Rollback/compensation: transaction helper plus capability rollback contract metadata.
- Idempotency: optional idempotency key and replay cache.
- Trace: request ID, correlation ID, intent ID, action ID.
- Cancellation/interruption: shared cancellation signal and hierarchy.
- Locks: resource ownership/locking with TTL.
- Time: one time service; UTC storage plus local and Ethiopic display helper.
- Identity: shared authenticated-user/device/privacy abstraction.
- Platform adapters: web/Android capability boundary.
- State gateway: `NoriState.read/readSync/mutate/writeSync`, cache, conflict handling and offline queue.
- Event stream: `state.changed`, subscriptions, event priority and reaction dispatch.
- Background tasks: one scheduler abstraction.
- Capability discovery: filtered capability descriptions rather than exposing theoretical capability lists to the model.
- Simulation/dry run: capability preview/simulation without mutation.
- Transactions: multi-step execution with compensating rollback.

## Existing-system integration

`NoriIntegrationCoreV31` remains the orchestrator. V32 wraps it rather than introducing a competing orchestrator.

AI consequential actions now pass through the protocol confirmation boundary. An AI action without explicit human confirmation produces `confirmation_required`; after confirmation the existing V31/V27 executor performs the action.

`NoriActionCoreV27` now uses the V32 state gateway for its central load/save/snapshot/rollback path when available. Legacy feature modules still contain direct localStorage/fetch usage and must be migrated incrementally; this release does not falsely claim that all 53 remaining direct localStorage users have been rewritten.

## Tests

- `www/tests/v32-operating-protocol-smoke.js` — PASS
- V26 architecture smoke — PASS
- V27 mentor contract smoke — PASS
- V28 explainability/governance smoke — PASS
- V29 canonical state smoke — PASS
- V30 canonical writer smoke — PASS
- V31 integration core smoke — PASS
- V32 integrity smoke — PASS
- All `www/**/*.js` files pass `node --check`.

No Android Gradle/device build is claimed by this pass.
