# Nori V32 — Stage 8: Memory & Personal Model

## Scope
Stage 8 adds the native long-term memory and evidence-backed personal model layer.
It is local-first and repository-backed, while the V32 JavaScript memory/self-model
implementation remains intact as the reference during migration.

## Native memory capabilities
- Explicit memory creation; inferred facts are not automatically saved.
- Categories: goals, preferences, projects, academic, system configuration, general.
- Confidence states: confirmed, likely, uncertain, archived.
- Importance from 1–5.
- Source and provenance fields on every item.
- Relevance-ranked recall using lexical overlap, exact match, importance, confidence and recency.
- Editable memory records.
- Archive and delete operations.
- Credential and sensitive-memory firewall based on the V32 memory policy.
- Maximum bounded memory size (500 records).
- Repository-backed persistence through the existing DataRepository abstraction.
- Reload from native persistence after process recreation.

## Personal model
Memory is projected into a structured PersonalModel containing:
- goals
- preferences
- projects
- academic state
- work patterns
- constraints
- communication preferences
- current priorities
- confirmed facts
- uncertain assumptions

The model is derived from memory rather than being treated as an independent source of truth.
Archived items are excluded. Confirmed items are kept separate from uncertain assumptions.

## Brain integration
NoriBrain now exposes:
- MemoryEngine
- PersonalModel
- explicit remember()
- recall()

The native application creates NoriBrain with the existing native repository, so memory
persistence uses the same SQLite-backed data boundary introduced in Stage 2/4.

## Migration boundary
- Existing V32 `nori-memory-v26.js`, V12/V13/V14 memory behavior, V31 self-model and
  learning systems are preserved.
- Stage 8 does not delete or replace those files.
- Existing V32 localStorage records still require an explicit export/bridge path before
  they can be mapped into typed native memory records.
- Native UI memory management is not claimed complete yet.

## Safety and control
- Memory is editable and deletable by explicit application operations.
- No silent recording or surveillance is introduced.
- Sensitive/credential-like material is rejected before persistence.
- Memory is evidence, not an authority. Current explicit information can supersede older memory.
- The PersonalModel is a planning aid, not a diagnosis or immutable identity label.

## Verification
- Native memory/model classes compile with the Stage 7 Brain core.
- Smoke tests passed for creation, categorization, recall, sensitive-data rejection,
  persistence/reload and model projection.
- Full Android APK/device validation remains pending until Android Studio/Android SDK is available.
