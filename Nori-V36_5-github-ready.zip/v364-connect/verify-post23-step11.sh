#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
node --check "$ROOT/www/nori-navigation-brain-v1.js"
node --check "$ROOT/www/nori-voice-action-orchestrator-v1.js"
node --check "$ROOT/www/nori-phase-app.js"
grep -q 'nori-navigation-brain-v1.js' "$ROOT/www/index.html"
grep -q 'nori-navigation-brain-v1.css' "$ROOT/www/index.html"
grep -q 'parts\[0\] === "alarms" ? "reminders"' "$ROOT/www/nori-phase-app.js"
grep -q 'parts\[0\] === "profile" || parts\[0\] === "settings"' "$ROOT/www/nori-phase-app.js"
grep -q 'NoriNavigationBrain' "$ROOT/www/nori-navigation-brain-v1.js"
grep -q 'CONNECTED TO NORI BRAIN' "$ROOT/www/nori-navigation-brain-v1.js"
echo 'POST23_STEP11_ORGANIZATION_NAVIGATION_VOICE_PASS'
