# Nori Stage 5 — KAGE / Override Migration

Stage 5 adds a native Java KAGE boundary while preserving the complete V32 KAGE/Override implementation as the reference source.

## Migrated deterministic responsibilities
- Failure type classification
- Degree 1/2 entry-condition evaluation
- Human Override validity/evidence/scope evaluation
- Consequence severity ceilings and candidate filtering
- Explicit audit record model
- Explicit Merit ledger model

## Safety of migration
- No V32 JavaScript KAGE files were deleted or rewritten.
- Native KAGE does not invent consequence IDs or point values.
- Merit state is explicit; no hidden singleton state.
- The native Brain only exposes the KAGE engine; existing V32 launcher behavior is unchanged.
- Full catalog parity and device tests remain required before retiring V32 KAGE modules.

## Next stage
Stage 6 migrates the academic engine and connects it to the native data/repository layer.
