# Nori V32 Post-23 Step 13 — Kage Avatar Evolution

## Baseline
Step 12 Interface Evolution. Existing interfaces remain available; Kage is an additional presentation mode.

## Added
- Kage Avatar V27 presentation shell with shared Nori connection label.
- Demand-driven educational panels: Status, Study, Exams, Trend.
- Subject progress bars and compact trend visualization from recorded academic data.
- No invented exam dates; empty exam state explicitly asks for a recorded date.
- Speech-level visual coordination API (`setSpeechLevel`) for future native/audio bridges.
- Tap interaction with lightweight visual response and panel collapse/restore.
- Thinking/analytical visual motion, subtle scan/halo, and restrained presentation effects.
- Mobile responsive layout and reduced-motion support.
- Existing `NoriAvatarV26` API preserved as the compatibility surface, now backed by V27.
- Shared memory/brain architecture is unchanged; this is presentation-only.

## Safety / privacy boundaries
- No background microphone or camera behavior was added.
- No automatic remote image generation was added.
- Visual panels use existing recorded data and do not silently rewrite plans or memory.

## Verification
`POST23_STEP13_AVATAR_EVOLUTION_SOURCE_PASS`

Android build/device runtime verification remains pending because the environment does not contain the Android SDK/build toolchain required for a full APK build.
