#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")" && pwd)"
required=(
  "$root/android/app/src/main/java/com/nori/jarvis/nori/voice/NoriVoiceCommand.java"
  "$root/android/app/src/main/java/com/nori/jarvis/nori/voice/NoriVoiceCommandRouter.java"
  "$root/android/app/src/main/java/com/nori/jarvis/voice/NoriVoiceWorkspaceActivity.java"
  "$root/android/app/src/main/java/com/nori/jarvis/nori/navigation/NoriNavigationPolicy.java"
  "$root/android/app/src/main/java/com/nori/jarvis/nori/exam/NoriScreenEvidence.java"
  "$root/android/app/src/main/java/com/nori/jarvis/nori/exam/NoriScreenSuspicionAnalyzer.java"
  "$root/android/app/src/main/java/com/nori/jarvis/nori/exam/NoriExamIntegrityService.java"
  "$root/android/app/src/main/java/com/nori/jarvis/visual/NoriExamIntegrityPlugin.java"
  "$root/www/nori-voice-action-orchestrator-v1.js"
)
for f in "${required[@]}"; do test -s "$f" || { echo "MISSING $f"; exit 1; }; done
node --check "$root/www/nori-voice-action-orchestrator-v1.js"
grep -q 'NoriExamIntegrityService' "$root/android/app/src/main/AndroidManifest.xml"
grep -q 'NoriVoiceWorkspaceActivity' "$root/android/app/src/main/AndroidManifest.xml"
grep -q 'NoriExamIntegrityPlugin' "$root/android/app/src/main/java/com/nori/jarvis/MainActivity.java"
grep -q 'CONFIRM & SAVE' "$root/android/app/src/main/java/com/nori/jarvis/voice/NoriVoiceWorkspaceActivity.java"
grep -q 'rapid_app_switching' "$root/android/app/src/main/java/com/nori/jarvis/nori/exam/NoriExamIntegrityService.java"
grep -q 'focus_restriction_active' "$root/android/app/src/main/java/com/nori/jarvis/nori/navigation/NoriNavigationPolicy.java"
echo 'POST23_STEP7_VOICE_ACTION_EXAM_INTEGRITY_SOURCE_PASS'
