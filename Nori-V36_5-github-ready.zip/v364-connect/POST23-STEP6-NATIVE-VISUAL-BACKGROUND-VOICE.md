# Post-23 Step 6 — Native Visual Context + Bounded Background Voice

This release replaces the Step 5 JavaScript-only capability boundary with real Android implementations.

## Camera context
- Explicit `CAMERA` permission.
- User-visible native camera screen using Camera2.
- One-shot JPEG capture at bounded resolution.
- Returns the captured image to the JS presence layer as a data URL.
- The image is not captured silently or in the background.

## Screen context
- Uses Android `MediaProjection`.
- Android shows its system consent UI for every capture session.
- Captures one screen frame and tears the projection down immediately.
- Android 14+ media-projection foreground-service permission/type are declared.
- The captured frame is passed to the JS presence layer and, when the user sends a message, to the configured vision-capable AI provider.
- Visual-context requests disable response caching and are never persisted as conversation memory by this layer.

## Background voice
- Uses a real Android microphone foreground service.
- Starts only from an explicit user action while Nori is visible.
- Continues when Nori moves to the background.
- Persistent notification is shown with a Stop action.
- Session is bounded to 30 minutes and is not sticky after process/service termination.
- No automatic boot-time microphone start and no silent microphone activation.

## Privacy / authority boundaries
- Camera, screen, and background microphone are separate capabilities.
- Human action is required before each visual capture.
- Screen capture requires Android's MediaProjection consent for each session.
- Background voice is opt-in and visibly indicated by an ongoing notification.
- Private Mode does not forward visual context to remote AI.
- No accessibility service is used for arbitrary app clicking.

## Verification status
- JavaScript syntax checks: required.
- Source regression suites: required.
- Android APK/device build: still pending because the repository does not include the Android SDK/build environment.
