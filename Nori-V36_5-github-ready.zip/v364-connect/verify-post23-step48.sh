#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
node --check "$ROOT/www/nori-admin-unified-v48.js"
node --check "$ROOT/www/nori-language-specialist-v48.js"
node --check "$ROOT/www/nori-sat-intelligence-v48.js"
node --check "$ROOT/www/nori-message-control-v48.js"
node --check "$ROOT/www/nori-production-auth-v47.js"
node --check "$ROOT/www/nori-sync.js"
grep -q 'supabaseClient: function' "$ROOT/www/nori-sync.js"
grep -qi 'admin' "$ROOT/supabase/migrations/003_nori_v48_admin_learning_message.sql"
grep -q 'operating_language' "$ROOT/supabase/migrations/003_nori_v48_admin_learning_message.sql"
grep -q 'auto_send boolean not null default false' "$ROOT/supabase/migrations/003_nori_v48_admin_learning_message.sql"
grep -q 'nori-theme-v48.css' "$ROOT/www/index.html"
grep -q 'nori-sat-intelligence-v48.js' "$ROOT/www/index.html"
grep -q 'nori-message-control-v48.js' "$ROOT/www/index.html"
echo 'POST23_STEP48_SOURCE_PASS unified_admin=on languages=en+ar+es+ja sat=adaptive message_draft_only=on theme=unified'
