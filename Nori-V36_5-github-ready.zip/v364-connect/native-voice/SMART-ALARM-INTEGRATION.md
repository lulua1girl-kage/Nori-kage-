# Nori Smart Alarm

The alarm layer is now a stateful, contextual alarm rather than a plain reminder.

## Flow

`SCHEDULED -> RINGING -> CONFIRMATION -> BRIEFING -> CONVERSATION`

Supported branches:

- `wait` / `later` -> offers 5, 10, or 15 minutes
- `5 minutes`, `10 minutes`, `15 minutes` -> schedules a new one-off reminder without changing a recurring alarm's base schedule
- `I'm busy` -> tells the user that timing will be reassessed rather than silently overriding the plan
- `sick`, `not feeling well`, `changed my mind`, `cancel` -> Human Override/context branch
- `ready`, `yes`, `confirm`, `go ahead` -> briefing and conversation
- `Nori shut down`, `Nori close yourself`, etc. -> ends the voice session

## Ringing

Android alarms use the `nori_alarm` high-importance notification channel with the default system sound. When the app is in the foreground, the web layer also emits a short local audio ring before the spoken briefing.

The Android package is still a Capacitor source package rather than a compiled APK. The notification channel is created through Capacitor Local Notifications, so the final Android build must request notification permission and retain the channel configuration. OEM battery policies and Android notification settings can still affect delivery.

## Privacy / control

The background microphone mode remains explicitly opt-in and visible through the foreground-service notification. This is not covert listening.
