# Nori Background Voice

Opt-in Android foreground microphone service. It continuously restarts Android SpeechRecognizer sessions, detects the configured wake word (default `Nori`), enters active conversation, broadcasts speech to the WebView, and supports native TextToSpeech. The foreground notification remains visible while the microphone is active.

After `npx cap add android`, copy the two Java files to `android/app/src/main/java/com/nori/jarvis/voice/`, add `AndroidManifest-additions.xml`, and register `NoriVoicePlugin` with the generated Capacitor bridge. This is intentionally visible and user-controlled; it is not covert microphone access.

Android/OEM battery policies can still restrict long-running microphone services, so target-device testing remains required for reliability.