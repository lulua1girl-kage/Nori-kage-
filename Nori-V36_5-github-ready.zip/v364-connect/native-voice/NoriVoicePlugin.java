package com.nori.jarvis.voice;
import android.content.*; import com.getcapacitor.*; import com.getcapacitor.annotation.CapacitorPlugin;
@CapacitorPlugin(name="NoriVoice")
public class NoriVoicePlugin extends Plugin{
 BroadcastReceiver br;
 public void load(){br=new BroadcastReceiver(){public void onReceive(Context c,Intent i){JSObject d=new JSObject();d.put("text",i.getStringExtra("text")==null?"":i.getStringExtra("text"));String a=i.getAction();if(NoriVoiceService.EVENT_WAKE.equals(a))notifyListeners("wakeWord",d);else if(NoriVoiceService.EVENT_SPEECH.equals(a))notifyListeners("speech",d);else if(NoriVoiceService.EVENT_STATE.equals(a))notifyListeners("state",d);}};IntentFilter f=new IntentFilter();f.addAction(NoriVoiceService.EVENT_WAKE);f.addAction(NoriVoiceService.EVENT_SPEECH);f.addAction(NoriVoiceService.EVENT_STATE);if(android.os.Build.VERSION.SDK_INT>=33)getContext().registerReceiver(br,f,Context.RECEIVER_NOT_EXPORTED);else getContext().registerReceiver(br,f);}
 protected void handleOnDestroy(){if(br!=null)try{getContext().unregisterReceiver(br);}catch(Exception e){}}
 @PluginMethod public void start(PluginCall c){Intent i=new Intent(getContext(),NoriVoiceService.class);i.setAction(NoriVoiceService.ACTION_CONFIG);i.putExtra("wakeWord",c.getString("wakeWord","nori"));if(android.os.Build.VERSION.SDK_INT>=26)getContext().startForegroundService(i);else getContext().startService(i);c.resolve();}
 @PluginMethod public void stop(PluginCall c){getContext().stopService(new Intent(getContext(),NoriVoiceService.class));c.resolve();}
 @PluginMethod public void speak(PluginCall c){Intent i=new Intent(getContext(),NoriVoiceService.class);i.setAction(NoriVoiceService.ACTION_SPEAK);i.putExtra("text",c.getString("text",""));if(android.os.Build.VERSION.SDK_INT>=26)getContext().startForegroundService(i);else getContext().startService(i);c.resolve();}
}