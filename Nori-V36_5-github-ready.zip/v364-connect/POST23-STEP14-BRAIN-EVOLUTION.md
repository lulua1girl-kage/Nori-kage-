# Nori Post-23 Step 14 — Human-Centered Brain Evolution

This step advances the Brain beyond API orchestration into a shared human-context decision layer.

## Architecture

Nori Brain now separates:
- local deterministic capability from optional external intelligence
- human-context assessment from clinical diagnosis
- support strategy from personal disclosure
- research organization from source retrieval
- provider failure logging from conversation content

## Human Context

`HumanContextEngine` recognizes bounded signals such as overload, fatigue, low activation and repeated avoidance patterns. It does not diagnose, assign clinical labels, or require the student to explain family/personal circumstances.

`NoriSupportPolicy` maps context to behavior:
- normal
- lighten load
- stabilize
- safety-first

It explicitly avoids interrogation and preserves Human Override.

## Provider architecture

Local Nori is first. Simple deterministic work is answered locally. Difficult requests can use ordered remote providers:

Nori local → API 1 → API 2 → API 3 → graceful local response

Remote providers have a bounded 10-second timeout and failures are persisted without prompts or credentials.

## Research

`ResearchIntelligence` can organize 10+ retrieved sources, deduplicate them, compare evidence, and expose agreement/disagreement/unknown fields. Actual web retrieval remains owned by the existing Web Intelligence/provider layer.

## Not included

This step does not claim clinical diagnosis, covert monitoring, automatic psychological profiling, or real-time web retrieval by itself. Those would require separate explicit, privacy-preserving integrations.
