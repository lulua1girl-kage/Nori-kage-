# Post-23 Step 9 — Focus Reasoning + Private History Gate

## Focus policy
- User explicitly selects which apps are eligible for focus restriction.
- Unselected apps are not implicitly blocked.
- Selected social apps are treated by purpose/activity, not app identity alone.
- Academic homework, teacher/class communication, and academic documents can be allowed.
- Scrolling, reels/shorts/feed use, unnecessary chat, posting/uploading are block candidates during a protected window.
- Ambiguous activity becomes REVIEW rather than an automatic breach.
- The blocker never publishes, posts, sends messages, or changes another app's permissions.

## Private history
- Sensitive/personal/psychologically important history is gated before display.
- Android biometric prompt is used when available; the OS controls enrolled biometrics.
- Successful verification unlocks sensitive history for the current app process/session.
- Closing the app process clears the unlock state.
- No fingerprint data is stored by Nori.
- Nori does not expose the sensitive text to the classifier's logs.

## Brain principle
Nori's system integrity is a priority, but it is not a reason to obstruct unrelated normal use. The Brain distinguishes purpose, activity, evidence, confidence, and uncertainty before taking a focus action.
