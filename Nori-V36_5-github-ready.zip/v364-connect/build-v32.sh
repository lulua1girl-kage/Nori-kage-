#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
fail(){ echo "[NORI V32] ERROR: $1" >&2; exit 1; }
command -v node >/dev/null 2>&1 || fail "Node.js is required."
command -v npm >/dev/null 2>&1 || fail "npm is required."
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
[ -n "$SDK" ] && [ -d "$SDK" ] || fail "Android SDK not found. Set ANDROID_HOME or ANDROID_SDK_ROOT."
[ -d "$SDK/platforms/android-36" ] || fail "Android API 36 platform is missing. Install Android SDK Platform 36."
if [ -x "$SDK/build-tools/35.0.0/aapt2" ]; then :; elif [ -x "$SDK/build-tools/36.0.0/aapt2" ]; then :; else fail "Android Build Tools with aapt2 are missing. Install Build Tools 35.0.0 or newer compatible with AGP 8.13.0."; fi
if [ ! -d node_modules ]; then npm install --no-audit --no-fund; fi
npx cap sync android
# Package the custom voice plugin/service under the Java package path expected by MainActivity.
# Keep native-voice as the source of truth; this does not alter the app logic.
if [ -f native-voice/NoriVoicePlugin.java ] && [ -f native-voice/NoriVoiceService.java ]; then
  mkdir -p android/app/src/main/java/com/nori/jarvis/voice
  cp native-voice/NoriVoicePlugin.java android/app/src/main/java/com/nori/jarvis/voice/NoriVoicePlugin.java
  cp native-voice/NoriVoiceService.java android/app/src/main/java/com/nori/jarvis/voice/NoriVoiceService.java
fi
if command -v gradle >/dev/null 2>&1; then GRADLE_CMD=(gradle); elif [ -x android/gradlew ]; then GRADLE_CMD=(android/gradlew); else fail "Gradle is unavailable."; fi
cd android
"${GRADLE_CMD[@]}" :app:assembleDebug --stacktrace
cd ..
APK="android/app/build/outputs/apk/debug/app-debug.apk"
[ -f "$APK" ] || fail "Build completed but APK was not found at $APK"
SIZE=$(wc -c < "$APK" | tr -d ' ')
[ "$SIZE" -gt 100000 ] || fail "APK exists but is suspiciously small ($SIZE bytes)."
echo "[NORI V32] INSTALLABLE DEBUG APK CREATED"
echo "$ROOT/$APK"
