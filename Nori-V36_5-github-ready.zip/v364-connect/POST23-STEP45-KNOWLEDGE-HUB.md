# Post23 Step 45 — Knowledge Hub, WPS/Document Intake, YouTube Learning & Lifelong Learning

## What changed

### 1. Student Library
- Logical library ceiling: 15 GiB.
- Files remain in user-selected Android document locations; Nori stores URI metadata and a fast retrieval index rather than blindly duplicating every file.
- Recent indexed files, search, subject hints, processing state and chunk counts.
- PDF imports use bounded local text extraction and feed the existing DocumentIntelligence chunk/search pipeline.
- First-pass indexing runs off the UI thread so file import does not become a long blocking operation.

Android Storage Access Framework is used for user-selected documents/folders. This is the privacy-preserving Android mechanism for accessing documents outside Nori's private storage.

### 2. WPS Office connection
- Nori can launch the installed WPS Office Android app when its package is available.
- Nori can import PDFs selected through the Android document picker, including documents opened from WPS-visible storage/providers.
- Nori does **not** read WPS's private internal database or silently inspect another app's private data.
- Therefore "recent WPS files" means recent files the student has made available to Nori, not an undocumented scrape of WPS private state.

### 3. YouTube public learning
- Public YouTube research connector prepared for the YouTube Data API.
- Search is restricted to public educational discovery; no user account access is required.
- Caption-aware search is used when available.
- A video is evidence, not truth. Nori must compare claims against primary/official/research sources and identify uncertainty.
- API credentials must be supplied through secure runtime/server configuration; they are not hardcoded in the web UI.

### 4. Ten additional learning sources
1. Khan Academy
2. MIT OpenCourseWare
3. OpenStax
4. MDN Web Docs
5. Android Developers
6. Python Documentation
7. arXiv
8. PubMed
9. NASA
10. NPTEL

The registry is a routing layer, not a claim that every page on a source is correct.

### 5. Lifelong subject map
Nori now has routing domains for mathematics, physics, chemistry, biology, languages, geography, history, economics, business administration, marketing, management, software engineering, web development, AI development, advanced coding, mining engineering, general engineering, agriculture and research skills.

### 6. Contradiction protocol
When teacher material, uploaded files, research and online material disagree, Nori does not silently pick one. It surfaces the conflict and asks what hierarchy should govern the answer for that task.

Suggested hierarchy options:
- course/teacher material for an exam-specific answer;
- student's uploaded library for personal notes/reference;
- primary/official source for factual/technical claims;
- recent peer-reviewed/research material when the question requires current evidence.

The choice is contextual, not a permanent global truth rule.

### 7. Continuous learning
`NoriAutonomousLearningEngine` adds governed learning modes. It can plan source refreshes and research up to the existing bounded research depth, while preserving provenance and verification.

It cannot silently rewrite Nori's constitution, permissions, safety rules, or user data.

### 8. Teaching personality
Nori can use a warmer friend/family-like conversational feel while remaining a mentor. The design target is familiar + protective + honest + corrective, not dependency. The student keeps agency and real-world relationships.

## Fast-processing architecture

The feature is intentionally split into:

`IMPORT -> INDEX METADATA -> EXTRACT/CHUNK IN BACKGROUND -> CACHE -> FAST RETRIEVAL -> DEEP ANALYSIS ONLY WHEN NEEDED`

This prevents a newly added document from forcing a full-library reprocessing pass before Nori can respond.

## Reliability rules
- Source existence is not proof of truth.
- YouTube existence is not proof of correctness.
- A teacher/source conflict is visible rather than silently resolved.
- Device/app evidence is not treated as causal proof.
- No background microphone/camera surveillance.
- No silent social posting.
- No silent model download.
- No silent self-modification of core rules.
- Library access is user-granted through Android's document system.

## Current verification
- `STEP45_KNOWLEDGE_PASS library15GB=true sources=10 contradiction=ask priority`
- JavaScript syntax check passed.
- Full Android build/device verification remains dependent on a complete Android SDK/Gradle environment and a physical Android device.
