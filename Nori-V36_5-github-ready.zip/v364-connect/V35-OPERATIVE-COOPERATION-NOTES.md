# Nori V35 — Operative Cooperation, Navigation & Thinking

## Purpose
V35 hardens the existing V31–V34 architecture instead of adding a competing brain. It focuses on end-to-end cooperation, stronger semantic navigation, time tools, math-speed measurement, and deeper reasoning routing.

## New operational layer
- `nori-time-tools-v35.js`
  - timer
  - persistent timer state
  - native/browser reminder integration when available
  - spoken Start/Stop cues
  - math-speed stopwatch
  - seconds/problem and problems/minute metrics
  - local speed history
- `nori-time-tools-v35.css`
- V33 capability contracts for time operations
- V34 decision recognition for timer/stopwatch goals
- semantic navigation for results, assignments, recovery, alarms, timer, math speed, focus, calendar, exams, settings and profile
- calendar `festival` event type
- stronger deep-reasoning triggers for planning, prioritization, constraints, patterns, diagnosis, multi-step workflows and decisions
- removed an existing duplicate Focus Mode success message

## Math speed behavior
Commands such as:
- `start math speed stopwatch`
- `start math speed for 20 problems`
- `stop stopwatch`

enter the same Nori intent/decision/execution pipeline.

The stopwatch immediately begins, Nori speaks `Start.`, and stopping speaks `Stop.` and records elapsed time, seconds/problem and problems/minute.

## Thinking model
The foundation-model worker remains a replaceable worker. Nori does not expose hidden chain-of-thought. Instead the system uses observable stages: understand → context → reason/plan → policy → execute → verify. More complex planning, constraints, patterns and multi-step requests are now more reliably routed to reasoning-capable providers, with the existing provider fallback and verification system preserved.

## Testing
The V35 suite verifies:
- timer lifecycle
- math stopwatch lifecycle and metrics
- semantic navigation
- V34 decision recognition
- V33 capability contract presence
- server capability gateway coverage for durable actions
- calendar festival support
- script wiring
- all prior V26–V34 smoke tests

A real Android device/build, live provider call, native notification delivery, and production database mutation cannot be truthfully marked passed from this environment unless those external systems are available during testing.
