#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
SRC=android/app/src/main/java/com/nori/jarvis/nori/brain/frontier/NoriFrontierCapabilityEngine.java
CAT=android/app/src/main/java/com/nori/jarvis/nori/brain/frontier/NoriFrontierCapabilityCatalog.java
[[ -f "$SRC" && -f "$CAT" ]] || { echo "STEP16_FRONTIER_FAIL missing_source"; exit 1; }
TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
javac -d "$TMP" "$SRC" "$CAT"
cat > "$TMP/Test.java" <<'JAVA'
import com.nori.jarvis.nori.brain.frontier.*;
public class Test { public static void main(String[] a){
  NoriFrontierCapabilityEngine e=new NoriFrontierCapabilityEngine();
  var p=e.plan("research my PDF and compare the latest sources, then create a study guide", true, false);
  if(!p.capabilities.contains(NoriFrontierCapabilityEngine.Capability.DEEP_RESEARCH)) throw new RuntimeException();
  if(!p.capabilities.contains(NoriFrontierCapabilityEngine.Capability.SOURCE_GROUNDED_NOTEBOOK)) throw new RuntimeException();
  if(!p.parallelize) throw new RuntimeException();
  if(NoriFrontierCapabilityCatalog.all().size()!=20) throw new RuntimeException();
  System.out.println("STEP16_FRONTIER_PASS");
}}
JAVA
javac -cp "$TMP" -d "$TMP" "$TMP/Test.java"
java -cp "$TMP" Test
echo "POST23_STEP16_FRONTIER_SOURCE_PASS"
