# Nori Native Stage 12 — Educational Intelligence

## Purpose
Build the offline-first educational intelligence layer above Stage 6 Academic Engine and Stage 7 Brain Core. It turns accumulated academic evidence into adaptive study priorities, mistake analysis, exam preparation, dynamic sessions, progress patterns, and tutoring policy.

## Added native components
- `EducationalIntelligence` — coordinator and bounded evidence history; optional repository persistence.
- `StrengthWeaknessEngine` — subject mastery, confidence, strengths, weaknesses and priority lists.
- `MistakeIntelligence` — repeated concept/careless/application patterns and interventions.
- `LearningPatternAnalyzer` — score/error pattern measurements over accumulated evidence.
- `StudyPlanner` — time-bounded priority planning; respects available minutes.
- `ExamPreparationEngine` — exam countdown, focus topics and preparation phases.
- `DynamicStudySessionEngine` — chooses reteach/retrieval/error-review/exam-drill based on evidence.
- `AdaptiveTutorPolicy` — depth/help style based on demonstrated need; supports hint-first solving.
- Typed models for evidence, plans, sessions, tutoring policy and reports.

## Design rules
- Deterministic/offline first. Stage 11 AI is optional and is not required for academic intelligence.
- Evidence is not the same as interpretation: models expose measured values and derived priorities separately.
- No peer ranking, shame, or score-as-worth logic.
- Available time bounds plans; the engine does not manufacture impossible study time.
- Academic weakness is handled academically, not converted directly into a disciplinary consequence.
- Human Override and the Stage 9 action-confirmation boundary remain intact.
- V32 JavaScript remains preserved for migration comparison.

## Integration
`NoriBrain` now owns `EducationalIntelligence`, exposes `getEducationalIntelligence()`, and records each processed academic event as evidence. With a repository, the evidence history is persisted under the versioned education key; without one it remains process-local.

## Verification
The Stage 12 educational package is designed as pure Java except for the existing `DataRepository` interface, so it can be compiled/tested independently of Android SDK availability. Full Android build remains a separate validation step in Android Studio because the current environment does not contain the Android SDK/Gradle wrapper JAR.
