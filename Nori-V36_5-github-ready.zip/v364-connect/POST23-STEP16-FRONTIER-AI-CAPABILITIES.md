# Post-23 Step 16 — Frontier AI Capability Expansion

Step 16 adds a provider-agnostic capability layer inspired by capabilities currently appearing across leading AI assistants, research systems, coding agents and AI notebook products.

It does **not** copy proprietary model weights or closed-source implementations. It gives Nori a local routing contract so the app can use equivalent capabilities when a configured provider supports them, while preserving the local-first/offline architecture.

## 20 capability families
1. Multimodal vision
2. Deep research
3. Source-grounded notebooks
4. Computer-use planning
5. Agent orchestration
6. Persistent project workspaces
7. Interactive artifacts
8. Long-term memory
9. Personalization
10. Coding-agent workflows
11. Scheduled tasks
12. Connectors/MCP tool access
13. Real-time voice
14. Screen context
15. Image creation
16. Long-context handling
17. Structured tool use
18. Fresh-web awareness
19. Automatic model/provider routing
20. Self-evaluation and verification

## Speed architecture
- O(1) capability membership via EnumSet.
- One local preflight instead of repeatedly probing every feature.
- Four independent cheap preflight signals can run in parallel.
- Parallel external fan-out is only requested for research/agentic/feature-dense work.
- Simple chat keeps a fast path.
- Existing Step 15 shared executor, bounded cache and provider cooldown remain intact.
- No claim of a measured 10x speedup: physical-device benchmarks are still required.

## Safety/agency boundaries
Computer use, tool execution, publishing, account changes and other consequential actions remain confirmation-gated by the existing action/security layers. Capability availability never grants permission by itself.

## Products reviewed for the capability survey
This was a capability survey, not a ranking: ChatGPT, Claude, Gemini, Perplexity, Microsoft Copilot, Grok, DeepSeek, Mistral Vibe/Le Chat, Meta AI, Qwen, NotebookLM, Poe, Cursor, Devin, GitHub Copilot, Replit Agent, Manus, Genspark, You.com and Character.AI.

The current industry direction is toward unified assistants that combine chat, research, files, tools, agents and creation. Recent examples include Claude combining chat/Cowork with projects, scheduled tasks, connectors, artifacts and computer use; Perplexity adding persistent Computer work, subagents, automations and model switching; Gemini adding collaborative Deep Research and multimodal File Search; Grok adding long-running agents, voice, image/video creation and build mode; and NotebookLM adding agentic research plus generated charts, spreadsheets and slides. See the cited research in the release notes accompanying this step.
