# Stage 20 — Testing & Regression

Stage 20 establishes the first repeatable cross-stage regression gate for the native migration.

Run:

```bash
./verify-stage20.sh
```

Expected:

```text
STAGE20_REGRESSION_PASS cases=44
STAGE20_STATIC_REGRESSION_PASS
```

The suite intentionally tests the platform-independent Java layer. It does not claim a full Android APK build. Android build/install/device tests remain a separate requirement for the release candidate.
