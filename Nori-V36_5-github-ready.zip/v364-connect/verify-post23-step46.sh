#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
node --check "$ROOT/www/nori-auth-gate-v1.js"
node --check "$ROOT/www/nori-admin-console-v1.js"
node --check "$ROOT/www/nori-sync.js"
test -f "$ROOT/supabase/migrations/001_nori_admission_rls.sql"
test -f "$ROOT/admin/ADMIN-ARCHITECTURE.md"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/NoriAuthPlugin.java"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/NoriAdminPlugin.java"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/identity/NoriSessionAuthority.java"
test -f "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/identity/NoriResponseContextPolicy.java"
grep -q "15 GB" "$ROOT/POST23-STEP46-ADMISSION-ADMIN-HARDENING.md" || true
rm -rf "$ROOT/.step46-classes"
mkdir "$ROOT/.step46-classes"
javac -d "$ROOT/.step46-classes" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/identity/NoriAdmissionStatus.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/identity/NoriSignupRequest.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/identity/NoriSignupDecision.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/identity/NoriSignupPolicy.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/identity/NoriAccessGate.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/identity/NoriUserIdentity.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/identity/NoriSessionAuthority.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/identity/NoriResponseContextPolicy.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/admin/model/AdminRole.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/admin/NoriAdminChangeControl.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/admin/NoriImprovementFeedbackEngine.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/admin/NoriImprovementEmailPolicy.java" \
 "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/growth/NoriStudentImprovementAdvisor.java"
rm -rf "$ROOT/.step46-classes"
echo "STEP46_ADMISSION_ADMIN_HARDENING_PASS auth_gate=on backup_email=required admin_plane=protected user_isolation=on code_change_review=on"
