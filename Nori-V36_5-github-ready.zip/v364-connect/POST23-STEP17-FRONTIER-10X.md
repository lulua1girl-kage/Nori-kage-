# Post-23 Step 17 — Frontier Brain 10X Expansion

Step 17 expands the Step 16 frontier capability layer into **200 concrete capability contracts**. The contracts are provider-agnostic: they describe routing, planning, verification, memory, research, study, coding, document, voice, device, and performance behaviors Nori can invoke when the underlying local/native/provider implementation exists.

## Major capability families
- reasoning and planning: decomposition, branching, dependency graphs, critical paths, deadline reasoning, plan repair, rollback, dry runs
- research: query planning, parallel research, synthesis, evidence gaps, source diversity, provenance, citation checks, conflict maps, freshness guards
- learning: adaptive quizzes, spaced repetition, retrieval practice, misconception detection, mastery estimation, error notebook, explanation adaptation
- documents: ingestion, chunking, retrieval, comparison, PDF QA, table extraction, reports, artifacts, version tracking
- coding: semantic code search, bug triage, tests, refactoring, build diagnostics, performance profiling, regression detection, security review
- voice/device: voice intent, context, barge-in, navigation, screen semantics, foreground context, notifications, calendar/reminder reasoning
- human-centered intelligence: fatigue-aware study, recovery-aware planning, human context, non-intrusive context, support-mode selection, autonomy support, Human Override
- performance/routing: local-first, fast path, hot-request cache, plan cache, provider health, escalation/de-escalation, token/latency/concurrency/RAM/thermal/battery budgets
- reliability: self-critique, second-pass verification, postcondition checks, bounded retries, idempotency, safe cancellation, degraded mode, task resume

## Speed architecture
Step 16 used a four-thread preflight executor. Step 17 removes that always-on executor from the local routing layer and instead uses:
- normalized deterministic request keys
- a bounded 128-entry plan cache
- direct local classification
- capability expansion only for the detected work class
- bounded parallelization only when external work is actually useful
- explicit latency/token/concurrency budgets
- simple chat fast path

This is an architectural speed target, **not a measured 5x benchmark**. Android performance must be measured on the target device. Android's current guidance recommends Baseline Profiles and Startup Profiles; Google reports Baseline Profiles can improve execution speed by about 30% from first launch, while actual gains vary by app and device. See official Android guidance.

## Safety and agency
More capabilities do not automatically grant permissions. Computer use, consequential actions, publication, account changes, and sensitive operations remain behind existing confirmation/security layers. Human Override remains authoritative.

## Verification
- Frontier engine + catalog standalone javac compile: PASS
- Step 17 smoke test: PASS
- Capability count: 200
- Plan-cache reuse: PASS
- Instant fast-path test: PASS
- Full Android/Gradle build: not performed in this environment
- Physical-device speed benchmark: not performed
