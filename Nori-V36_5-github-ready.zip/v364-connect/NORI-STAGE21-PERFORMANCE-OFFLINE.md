# Nori V32 — Native Java Stage 21: Performance & Offline

## Purpose
Stage 21 makes the native Nori core explicitly offline-first and introduces bounded process-local performance infrastructure without making network services mandatory.

## Added
- `NoriPerformance`: central performance/offline boundary.
- `OfflinePolicy`: OFFLINE_FIRST by default; remote use requires explicit ONLINE_ALLOWED mode and observed network availability.
- `BoundedLruCache`: hard process-local entry bound; not persisted.
- `PerformanceMonitor`: bounded timing samples.
- `ResourceBudget`: hard limits for cache entries, text size, collection size, and operation budget metadata.
- `NoriBrain.getPerformance()`: exposes the boundary without giving it authority to bypass Brain/action/security rules.

## Design boundaries
- Local academic, KAGE, memory, integrity, and decision logic remains usable without network access.
- Stage 11 AI remains optional; Stage 15 web remains explicitly network-dependent.
- No credentials are stored by the performance layer.
- Cache is deliberately non-persistent so stale process-local results do not become long-term student data.
- The performance layer cannot execute actions or bypass Human Override, Integrity, or Security layers.

## Verification
`verify-stage21.sh` compiles the non-Android native layer and runs `Stage21PerformanceOffline`.
Expected markers:
- `STAGE21_PERFORMANCE_OFFLINE_PASS`
- `STAGE21_STATIC_REGRESSION_PASS`

A complete APK/device build still requires the Android SDK/Gradle environment and should be performed later in Android Studio.
