# Post-23 Step 25 — Knowledge Verification + Governed Learning

## 11 — Knowledge / AI / Verification
- Preserved local-first provider architecture and consent gate.
- Added capability-aware routing metadata and verification escalation for difficult knowledge requests.
- Added source validation, claim verification states, hallucination-risk heuristics, and explicit knowledge-conflict handling.
- Added optional multi-model council for difficult verification. Council agreement is evidence of consistency, never proof of truth; disagreement produces review/evidence requirements.
- RAG remains an architecture boundary; no fake vector database was introduced.

## 12 — Learning / Diagnostics / Evolution
- Added diagnostics findings.
- Added governed intervention/personalization experiments.
- Added action -> outcome -> learning -> adaptation loop.
- Added outcome rates and automatic improvement *proposals*.
- Added capability discovery from observed registered actions.
- Automatic proposals remain proposals; user confirmation is required before applying a change.
- Core rules, security boundaries, memory privacy and Human Override remain protected by FutureEvolutionPolicy.
- No uncontrolled self-modification.

## Verification principle
Evidence quality, provenance, freshness and disagreement affect confidence. No model vote is treated as truth. Nori must be able to say that evidence is insufficient or conflicting.

Full Android APK/device build remains pending because the current environment lacks the Android SDK/Gradle wrapper needed for a real device build.
