# Nori Native Stage 13 — Educational Integrity & Protection

## Purpose
Port the V32 system-integrity and Human Override principles into a native, deterministic protection layer. The goal is strictness that remains useful: protect academic priorities and system integrity without turning discipline into harm, coercion, dependency, or punishment for legitimate circumstances.

## Added native components
- `IntegrityEngine` — breach classification, proportionality checks, repeated-consequence/system-failure analysis, and Human Override routing.
- `HumanOverrideGuard` — bounded circumstance categories, proportional severity scoring, and repeated-override review.
- `ConsequenceSafetyGuard` — hard blocks for physical, deprivation-based, humiliating, threatening, unsafe, or unrecognized consequences.
- `RecoveryIntegrity` — keeps consequence and academic restoration separate; restoration must be verified and never falsely erases the breach record.

## Protection rules
- Human Override remains above ordinary disciplinary operation.
- Fatigue, emergencies, necessary communication, honest mistakes, and legitimate circumstances are not automatically treated as integrity breaches.
- A legitimate override changes timing/workload; it does not rewrite history or make false status acceptable.
- Essential needs are protected: no deprivation of food, necessary sleep, safety, or health.
- A consequence that creates a new or greater failure is rejected.
- Repeated failure of a consequence triggers diagnosis of the system/environment/restoration/control rather than automatic harsher punishment.
- Unsafe or physically punitive consequence descriptions are hard-blocked.
- Academic failure and integrity breach remain separate signals.
- Recovery does not erase the original breach; verified restoration protects the academic result.
- Nori cannot silently apply a consequence: Stage 9 proposal/preview/human-confirmation boundaries remain required.

## Brain integration
`NoriBrain` owns `IntegrityEngine`, exposes it through `getIntegrityEngine()`, and exposes the consequence safety gate through `checkConsequenceSafety(...)`.

## Preserved systems
All V32 JavaScript remains intact for comparison. Stage 5 KAGE, Stage 7 Brain, Stage 9 action controls, Stage 10 Android services, Stage 11 AI provider abstraction, and Stage 12 educational intelligence remain unchanged except for the Stage 13 Brain wiring.

## Verification
The Stage 13 integrity package is pure Java and can be compiled independently of the Android SDK. Tests cover safe/unsafe consequences, breach vs. legitimate circumstance classification, Human Override severity, proportionality, repeated system failure, and recovery verification.
Full Android build remains a separate validation step in Android Studio because the current environment does not contain the Android SDK/Gradle wrapper JAR.
