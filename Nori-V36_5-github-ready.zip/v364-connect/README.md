# Nori — Hybrid Android App (Capacitor)

This folder wraps the NORI PHASE web app in [Capacitor](https://capacitorjs.com),
so it can be built into a real, installable Android app instead of just a
website. Everything that CAN be prepared without your own machine's Android
toolchain is done — `package.json`, `capacitor.config.json`, the `www/`
folder with the full app, and a native speech bridge already wired in.

**What's honest about this:** actually generating the native `android/`
project and compiling an APK requires Android Studio, the Android SDK, and
Node with internet access to download packages — none of which this
sandbox has. So the steps below are exact commands to run on your own
machine to finish the job; nothing here is guesswork, but it hasn't been
run end-to-end on a real device.

## 1. Prerequisites

- [Node.js](https://nodejs.org) (18+)
- [Android Studio](https://developer.android.com/studio) — installs the
  Android SDK for you
- A real Android device (with USB debugging enabled) or an emulator set up
  in Android Studio

## 2. First-time setup

From this folder:

```bash
npm install
npx cap add android
```

`cap add android` generates the actual native `android/` project — a real
Android Studio/Gradle project — using `www/` as its web content.

## 3. Set your backend URL (IMPORTANT — do this before syncing)

The app talks to the same backend as the web version
(`api/checkin.js`, `api/evaluate.js`, `api/brain.js` — deploy those to
Vercel or wherever you deployed them before, if you haven't already).

Open `www/nori-native-bridge.js` and change this one line:

```js
const NORI_API_BASE_URL = ""; // <- change to your deployed backend
```

to:

```js
const NORI_API_BASE_URL = "https://your-nori-app.vercel.app";
```

This one line feeds all three API endpoints (check-in, evaluate, brain) —
you only have to change it in one place. **This step is required**, not
optional: Capacitor serves the app from a local origin on the device, so a
relative path like `/api/checkin` (which works fine on the web, same
origin as the backend) will NOT reach your real backend from inside the
native app without this.

## 4. Sync and open in Android Studio

```bash
npx cap sync android
npx cap open android
```

This copies `www/` into the native project and opens it in Android Studio.
From there: **Run ▶** to install on a connected device/emulator, or
**Build > Generate Signed Bundle / APK** to produce an installable APK.

## 5. Permissions (microphone + speech recognition)

After `cap add android` generates `android/app/src/main/AndroidManifest.xml`,
add these two lines inside the `<manifest>` tag (above `<application>`):

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.INTERNET" />
```

`INTERNET` is usually added automatically by Capacitor; `RECORD_AUDIO` is
not — the speech recognition plugin needs it, and the app will ask the
user for it at runtime (via `Plugin.requestPermissions()` in
`nori-native-bridge.js`), but Android still requires it declared in the
manifest first.

## 6. The one real technical gotcha — speech recognition

Android's native WebView (what a Capacitor app runs inside) does **not**
reliably support the Web Speech API's `SpeechRecognition` interface — this
is a Chrome-specific feature, not a WebView one. Text-to-speech
(`speechSynthesis`) generally does work fine in WebView.

This is why `www/nori-native-bridge.js` exists: it detects native vs. web
and routes speech-to-text through `@capacitor-community/speech-recognition`
(a real native plugin) when running as the Android app, and through the
Web Speech API when running as a regular website — both come out the other
side as the same `noriListenOnce()` function, so the rest of the app never
has to know which platform it's on.

What this means in practice on native Android:

- **Check-In, Report Result (voice confirm), and Quick Add Result's Speak
  button** all use `noriListenOnce()` — one tap, one utterance, works the
  same way on both platforms.
- **Meet Nori's main chat mic** (the continuous "Start Listening" button)
  is built on the Web Speech API's continuous/partial-results event model,
  which doesn't map cleanly onto the native plugin. On native Android, it
  automatically switches to tap-per-utterance instead: tap the mic, say one
  thing, it's added to the text box, tap again for the next thing. Still
  fully voice-driven, just turn-based instead of continuously open. Mute
  and "let me interrupt" don't apply to that mode, so they're hidden
  automatically rather than left as controls that silently do nothing.

**This needs testing on a real device** — WebView and native plugin
behavior can vary by Android version and OEM in ways that can't be fully
verified without one.

## 7. App icon / splash screen

Done — `resources/icon.png` (1024×1024) and `resources/splash.png` /
`resources/splash-dark.png` (2732×2732) are generated from your cover
art, following the standard Capacitor asset convention. The same image
is also in `www/assets/nori-cover.jpg` and shows as a full-screen tap-to-
enter cover the first time the app opens each session (see `index.html`
/ `nori-phase.css`, `#nori-cover`).

To turn `resources/` into the actual native icons/splash screens once
you've run `npx cap add android` (step 4 above):

```bash
npm install @capacitor/assets --save-dev
npx capacitor-assets generate --android
```

This reads `resources/icon.png` and `resources/splash.png` and writes
every required density into `android/app/src/main/res/mipmap-*` and
`drawable-*` for you — nothing to resize by hand. Re-run it any time you
swap the source art.


## V28
Explainable deterministic audit chain and owner-only rule-tuning review. See V28-EXPLAINABILITY-RULE-REVIEW-NOTES.md.
