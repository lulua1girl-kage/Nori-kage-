# Nori V32 Integrity Patch 3

## Fixed in this pass
- Added authenticated per-user rate limiting to AI/check-in/evaluate/decision/photo APIs in addition to coarse IP limits.
- Added parsed-body size enforcement so requests cannot bypass the content-length check.
- Hardened AI action parsing with strict schemas, bounded counts/text, positive reminder range (1 minute–7 days), and academic-only photo claims.
- Fixed the ACTIONS/MEMORY_SUGGESTIONS parser so marker order is genuinely order-independent.
- Added a second validation gate immediately before chat-proposed side effects execute in the browser.
- Limited AI-proposed action count to 3 and Focus Mode app count to 12.

## Remaining architectural work
- Replace marker parsing with provider structured output / JSON schema where supported.
- Route chat-proposed actions through the existing NoriActionCore proposal/preview/confirm/audit pipeline instead of the legacy direct executor.
- Add a single authoritative grading module and cross-engine golden tests.
- Complete Human Override evidence/persistence/budget model and safety gate.
- Pin all remaining dependency versions and perform a real Android Gradle/device build.
