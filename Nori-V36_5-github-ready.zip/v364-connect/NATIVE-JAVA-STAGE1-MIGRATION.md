# Nori V32 → Native Java — Stage 1

## Purpose

This stage establishes the native Java foundation **without replacing or deleting the working V32 application**.

### Safety rule

V32 remains the reference implementation.

Nothing is retired until:
1. its behavior is mapped,
2. a native replacement exists,
3. the replacement is tested,
4. the old behavior is confirmed covered.

## What was added

- `NoriNativeCore`
- `NoriBrain`
- `IntentEngine`
- `ContextEngine`
- `AcademicEngine`
- `MemoryEngine`
- `KageEngine`
- `DataRepository`

These are architectural boundaries, not a replacement Brain yet.

## What was deliberately NOT changed

- `MainActivity`
- Capacitor configuration
- existing V32 HTML/CSS/JS
- existing KAGE engines
- existing voice implementation
- existing blocker
- existing storage behavior
- existing API/AI behavior
- Android permissions
- existing navigation/UI

Therefore the existing V32 app remains the active application.

## Next migration order

1. Inventory every V32 module and dependency.
2. Extract behavior/contracts from each module.
3. Implement native data models/repositories.
4. Migrate KAGE/Override and academic engines.
5. Migrate memory and context.
6. Build the native Brain orchestrator.
7. Rebuild the UI natively.
8. Migrate voice, alarms, notifications, blocker and other Android integrations.
9. Add optional AI providers behind a native interface.
10. Run regression tests against V32 behavior.
11. Only then retire redundant web modules.

## Important

This project is intentionally a **parallel native foundation** inside the existing Android project. It is not activated from `MainActivity` yet, because activating an incomplete native Brain/UI would risk breaking V32.
