# Nori Post-Stage-23 Step 1 — Unified State

## Purpose
Create one additive read-only state composition layer without replacing or deleting existing Stage 23 engines.

## Added
- `nori.state.NoriState`: immutable snapshot containing situation, academic state, memory summary, conversation state, and system health.
- `nori.state.NoriStateEngine`: composes existing engines into a single current-state snapshot.
- `NoriBrain.getCurrentState()` and `getStateEngine()` expose the new layer without removing existing APIs.
- Academic event processing refreshes unified state after the existing Stage 7 pipeline.
- Deterministic unit coverage for state composition and sequence progression.

## Preservation rule
No existing Stage 23 engine, UI, storage format, KAGE rule, action permission, AI provider, voice mode, or web feature is removed or replaced by this step. The new layer observes existing components and composes a read-only view.

## Current boundary
This step intentionally does not yet invent automatic situation detection. Availability/activity and exam proximity can be explicitly observed, while existing context classification remains authoritative for observed events.
