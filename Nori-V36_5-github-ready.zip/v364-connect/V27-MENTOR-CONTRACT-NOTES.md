# Nori V27 — Mentor Contract

Baseline: Nori-V32-BRAIN-V26-IMPROVED.zip

## What V27 adds

V27 locks the deterministic KAGE engine / frontier mentor boundary before persona work.

### Mentor input contract
The mentor receives a fixed JSON envelope containing:
- an immutable KAGE deterministic verdict;
- a server-loaded handbook rule reference;
- student history, explicitly marked as client evidence until Canonical State Authority is wired;
- student memory, explicitly marked as contextual/user data;
- the student's own statement, marked as student-authored transcript.

The model is instructed to treat the verdict as read-only and never recompute it.

### Mentor output contract
The only permitted output fields are:
- `mentorMessage`
- `acknowledgesCircumstance`
- `suggestedFocusArea`

`suggestedFocusArea` must reference one of the already-supplied required actions.

Forbidden state-changing fields include:
- overrideDecision
- consequenceOverride
- bandAdjustment
- degreeAdjustment
- scoreAdjustment
- decision/verdict
- actions
- memorySuggestions
- stateChange
- recordUpdate

Unknown output fields are rejected.

### API
A new authenticated endpoint mode is available through the existing `/api/brain.js` handler:

`mode: "mentor_contract"`

It does not use web search, does not execute actions, and does not feed mentor text into the deterministic engine.

### Worked example
The smoke test uses:
Chemistry, 45%, Band 1, Degree 1, first below-80 result.

The server verifies that the supplied Band/Degree exists in the server rule catalog before constructing mentor input.

### Important current limitation
Student history and memory are still supplied by the authenticated client and are therefore labeled as evidence/context, not canonical truth. The next architecture layer remains Canonical State Authority:
Supabase/canonical storage -> authenticated user -> verified state engine -> Mentor Contract -> frontier model.

### Tests
- `www/tests/v27-mentor-contract-smoke.js`
- updated V26 architecture smoke test for V27 versioning
- existing V32 integrity smoke test

All three passed during the build verification.
