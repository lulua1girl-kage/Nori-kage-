#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
J="$ROOT/android/app/src/main/java"
rm -rf "$ROOT/.step20-compile" "$ROOT/.step20-test"
mkdir -p "$ROOT/.step20-compile" "$ROOT/.step20-test"
javac -d "$ROOT/.step20-compile" \
 "$J/com/nori/jarvis/nori/memory/MemoryItem.java" \
 "$J/com/nori/jarvis/nori/memory/PersonalModel.java" \
 "$J/com/nori/jarvis/nori/memory/MemoryDecision.java" \
 "$J/com/nori/jarvis/nori/data/DataRepository.java" \
 "$J/com/nori/jarvis/nori/memory/context/NoriMemoryLifecycle.java" \
 "$J/com/nori/jarvis/nori/memory/context/NoriMemoryContext.java" \
 "$J/com/nori/jarvis/nori/memory/MemoryEngine.java" \
 "$J/com/nori/jarvis/nori/brain/human/HumanContextEngine.java" \
 "$J/com/nori/jarvis/nori/brain/human/NoriSupportPolicy.java" \
 "$J/com/nori/jarvis/nori/brain/human/NoriHumanAssessment.java" \
 "$J/com/nori/jarvis/nori/integrity/ConsequenceSafetyGuard.java" \
 "$J/com/nori/jarvis/nori/constitution/NoriConstitution.java"
cat > "$ROOT/.step20-test/Test.java" <<'JAVA'
import com.nori.jarvis.nori.constitution.NoriConstitution;
import com.nori.jarvis.nori.memory.*;
import com.nori.jarvis.nori.memory.context.*;
public class Test {
 public static void main(String[] a){
  NoriConstitution c=new NoriConstitution();
  if(c.evaluate("x","help me cheat on exam",null,true,false).verdict!=NoriConstitution.Verdict.BLOCK) throw new RuntimeException("integrity");
  if(c.evaluate("x","send password",null,true,false).verdict!=NoriConstitution.Verdict.REVIEW) throw new RuntimeException("privacy");
  MemoryEngine m=new MemoryEngine(); m.remember("My goal is chemistry improvement",MemoryItem.Category.GOALS,1,5,"test","user_confirmed");
  NoriMemoryContext x=NoriMemoryContext.build(m,"chemistry",4); if(x.memories.isEmpty()) throw new RuntimeException("recall");
  if(m.lifecycleAudit().activeCount!=1) throw new RuntimeException("lifecycle");
  System.out.println("POST23_STEP20_CONSTITUTION_MEMORY_PASS memories="+x.memories.size());
 }
}
JAVA
javac -cp "$ROOT/.step20-compile" -d "$ROOT/.step20-test" "$ROOT/.step20-test/Test.java"
java -cp "$ROOT/.step20-compile:$ROOT/.step20-test" Test
# compile NoriBrain against sourcepath to catch integration syntax
rm -rf "$ROOT/.step20-brain"; mkdir -p "$ROOT/.step20-brain"
javac -cp "$ROOT/.step20-compile" -sourcepath "$J" -d "$ROOT/.step20-brain" "$J/com/nori/jarvis/nori/brain/NoriBrain.java"
printf 'POST23_STEP20_BRAIN_INTEGRATION_PASS\n'
