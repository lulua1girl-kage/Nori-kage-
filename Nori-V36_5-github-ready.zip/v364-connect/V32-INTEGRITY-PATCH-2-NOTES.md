# Nori V32 Integrity Patch 2

Additional hardening applied after the first integrity patch.

## Changes

- Cross-origin API responses no longer reflect arbitrary Origin headers. Cross-origin access requires `NORI_ALLOWED_ORIGINS`.
- Pinned `@capacitor-community/speech-recognition` instead of `latest`.
- Voice V28 now carries a configurable BCP-47 language into browser TTS.
- Voice PiP recognition reads the shared Nori voice language instead of hard-coding `en-US`.
- Avatar V27 no longer uses `Math.random()` as a fake speech-level signal.
- Browser TTS boundary events can drive the avatar speech-level signal.
- Avatar states are preloaded and face changes use a small transition hook.
- Added reduced-motion CSS handling for the avatar/voice layer.
- Added a small integrity smoke-test scaffold.

## Still requires environment/device verification

- Real Android build/install.
- Supabase production auth/RLS verification.
- Real microphone/audio testing.
- Provider streaming and sentence-level speech.
- Full Human Override redesign and regression suite.
- Crisis-safety flow.
- Full multilingual recognition/TTS tests.
