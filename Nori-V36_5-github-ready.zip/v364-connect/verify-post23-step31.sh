#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
SRC="$ROOT/android/app/src/main/java"; OUT="$ROOT/build_step31_verify"; rm -rf "$OUT"; mkdir -p "$OUT"
mapfile -t FILES < <(python3 - <<PY2
import os
root=r'''$SRC'''
for dp,_,fs in os.walk(root):
  for f in fs:
    if not f.endswith('.java'): continue
    p=os.path.join(dp,f); s=open(p,errors='ignore').read()
    if any(x in s for x in ['import android.','import androidx.','import com.getcapacitor.','android.']): continue
    if p.endswith(('NoriNativeCore.java','NoriWorldPlugin.java','NoriOperationsPlugin.java','MainActivity.java','V32MigrationValidator.java')): continue
    print(p)
PY2
)
javac -d "$OUT" "${FILES[@]}"
cat > "$OUT/Step31Check.java" <<'JAVA'
import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.ops.NoriOperationalCore;
import com.nori.jarvis.nori.data.DataRepository;
import java.util.*;
public class Step31Check {
 static final class R implements DataRepository { Map<String,String> m=new HashMap<>(); public boolean putJson(String k,String v,String c,int s){m.put(k,v);return true;} public String getJson(String k){return m.get(k);} public boolean contains(String k){return m.containsKey(k);} public boolean delete(String k){return m.remove(k)!=null;} }
 public static void main(String[] a){
  NoriBrain b=new NoriBrain(new R());
  if(b.getOperationalCore().capabilityTruths().size()<15) throw new RuntimeException("ops catalog regression");
  if(b.getFunctionalExecutionCore().truth("ops_add_task").truth!=com.nori.jarvis.nori.execution.NoriFunctionalExecutionCore.CapabilityTruth.EXECUTE) throw new RuntimeException("task handler not registered");
  if(b.getFunctionalExecutionCore().truth("ops_search").truth!=com.nori.jarvis.nori.execution.NoriFunctionalExecutionCore.CapabilityTruth.EXECUTE) throw new RuntimeException("search handler not registered");
  if(b.getRealityEngine().inspect("ops_add_task").state!=com.nori.jarvis.nori.execution.NoriRealityEngine.State.PREPARED) throw new RuntimeException("reality gate failed");
  var p=b.getOperationalCore().upsert(NoriOperationalCore.ItemType.TASK,"Test task","Math","2099-01-01",NoriOperationalCore.Priority.HIGH,"smoke");
  if(b.getOperationalCore().search("Test task").isEmpty()) throw new RuntimeException("local persistence/search failed");
  if(b.getOperationalCore().setStatus(p.id,"DONE").ok!=true) throw new RuntimeException("status update failed");
  b.getOperationalCore().checkIn("LOW","testing","explicit smoke check-in");
  if(!b.getOperationalCore().exportSnapshot().startsWith("NORI_EXPORT_V1")) throw new RuntimeException("export failed");
  java.util.Map<String,String> in=new java.util.LinkedHashMap<>(); in.put("title","End-to-end action"); in.put("subject","Physics");
  var prepared=b.getFunctionalExecutionCore().prepare(new com.nori.jarvis.nori.actions.model.ToolRequest("ops_add_task",in),"smoke user request",java.util.Collections.singletonList("smoke"),com.nori.jarvis.nori.understanding.NoriUserControlEngine.Origin.USER_DIRECT,true,false,false,"nori_operations","");
  if(prepared.proposal==null || !prepared.preview.allowed) throw new RuntimeException("action preparation failed");
  var ar=b.getFunctionalExecutionCore().confirmAndExecute(prepared.proposal.id,"smoke_user");
  if(!ar.ok || !ar.verified) throw new RuntimeException("action execution/verification failed");
  if(b.getRealityEngine().fromResult("ops_add_task",ar).state!=com.nori.jarvis.nori.execution.NoriRealityEngine.State.VERIFIED) throw new RuntimeException("reality verification failed");
  System.out.println("POST23_STEP31_END_TO_END_PASS capabilities="+b.getOperationalCore().capabilityTruths().size()+" records="+b.getOperationalCore().records().size());
 }
}
JAVA
javac -cp "$OUT" -d "$OUT" "$OUT/Step31Check.java"
java -cp "$OUT" Step31Check
printf 'POST23_STEP31_STATIC_PASS\n'
