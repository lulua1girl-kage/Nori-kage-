# Post-Stage-23 Step 2 — Evidence, Reasoning & Confidence

Baseline: Post-Stage-23 Step 1 — Unified State.

## Additive design
- Adds a structured evidence model with FACT, CONTEXT, INFERENCE and ASSUMPTION types.
- Adds coarse evidence-quality confidence: HIGH, MEDIUM, LOW, UNKNOWN.
- Adds a reasoning summary containing evidence, assumptions, conclusion, confidence and verification requirement.
- Connects the new reasoning summary to existing BrainDecision without removing existing fields or changing the existing decision pipeline.

## Safety of reasoning
The layer exposes concise evidence/conclusion summaries. It does not expose or store hidden chain-of-thought. Existing verification, KAGE, Human Override, integrity and action controls remain authoritative.

## Preservation
Existing features and APIs are preserved. The legacy BrainDecision constructor delegates to the new constructor with a null reasoning summary for compatibility.
