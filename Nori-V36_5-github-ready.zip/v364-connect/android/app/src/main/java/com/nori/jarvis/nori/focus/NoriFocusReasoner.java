package com.nori.jarvis.nori.focus;

import java.util.*;

/**
 * Context-sensitive focus policy. User-selected apps are the only apps eligible
 * for restriction. Purpose and visible activity can create an allow exception.
 * It never publishes, posts, sends messages, or silently changes app permissions.
 */
public final class NoriFocusReasoner {
    public enum Decision { ALLOW, WARN, BLOCK, REVIEW }
    public static final class Result {
        public final Decision decision; public final String reason; public final double confidence;
        Result(Decision d,String r,double c){decision=d;reason=r;confidence=c;}
    }
    public Result decide(String packageName, String purpose, String activity, boolean protectedWindow, Set<String> selected) {
        String p=(packageName==null?"":packageName).toLowerCase(Locale.ROOT);
        String pu=(purpose==null?"":purpose).toLowerCase(Locale.ROOT);
        String a=(activity==null?"":activity).toLowerCase(Locale.ROOT);
        if(!protectedWindow) return new Result(Decision.ALLOW,"No active protected study/exam window.",0.99);
        if(selected==null || !selected.contains(p)) return new Result(Decision.ALLOW,"App was not selected by the user for focus restriction.",0.99);
        if(isVideoCallOrNecessaryChat(a,pu)) return new Result(Decision.ALLOW,"Communication appears necessary or connected to the academic task.",0.78);
        if(isScroll(a) || isUnnecessaryChat(a) || isPosting(a)) return new Result(Decision.BLOCK,"Selected app is being used for scrolling, unnecessary chat, or posting during a protected window.",0.90);
        if(isAcademicPurpose(pu) || isAcademicActivity(a)) return new Result(Decision.ALLOW,"Selected app appears to be used for an explicitly academic purpose.",0.86);
        return new Result(Decision.REVIEW,"Selected app activity is ambiguous; request a quick purpose clarification instead of assuming misuse.",0.55);
    }
    private boolean isAcademicPurpose(String s){return s.contains("homework")||s.contains("assignment")||s.contains("study")||s.contains("class")||s.contains("exam")||s.contains("teacher")||s.contains("school");}
    private boolean isAcademicActivity(String s){return s.contains("document")||s.contains("lesson")||s.contains("notes")||s.contains("worksheet")||s.contains("textbook")||s.contains("video lesson")||s.contains("class");}
    private boolean isVideoCallOrNecessaryChat(String a,String p){return a.contains("video call")||a.contains("video chat")||a.contains("class call")||a.contains("teacher chat")||p.contains("teacher")||p.contains("classmate");}
    private boolean isScroll(String s){return s.contains("scroll")||s.contains("reels")||s.contains("shorts")||s.contains("feed")||s.contains("browse feed");}
    private boolean isUnnecessaryChat(String s){return s.contains("random chat")||s.contains("unnecessary chat")||s.contains("casual chat")||s.contains("dm")||s.contains("direct message");}
    private boolean isPosting(String s){return s.contains("post")||s.contains("publish")||s.contains("upload")||s.contains("story");}
}
