package com.nori.jarvis.nori.exam;

import java.util.*;

/** Conservative, explainable screen/app trigger policy. No hidden behavioral scoring. */
public final class NoriScreenSuspicionAnalyzer {
    private static final Set<String> DISTRACTING=new HashSet<>(Arrays.asList(
        "com.instagram.android","com.pinterest","com.snapchat.android","com.zhiliaoapp.musically","com.google.android.youtube"
    ));
    public NoriScreenEvidence inspect(String pkg, boolean examActive, boolean alreadySeen){
        if(!examActive) return null;
        if(pkg==null || pkg.isEmpty()) return null;
        if(DISTRACTING.contains(pkg)) return new NoriScreenEvidence(pkg,alreadySeen?"reopened_distraction":"distraction_app_foreground","probability="+(alreadySeen?"high":"moderate"),String.valueOf(System.currentTimeMillis()));
        return null;
    }
    public boolean isDistraction(String pkg){return DISTRACTING.contains(pkg);}
}
