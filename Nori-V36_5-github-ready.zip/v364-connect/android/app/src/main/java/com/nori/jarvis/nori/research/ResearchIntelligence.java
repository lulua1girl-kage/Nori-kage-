package com.nori.jarvis.nori.research;

import java.util.*;

/**
 * Source-agnostic research coordinator. Retrieval is supplied by WebIntelligence/provider adapters;
 * this class organizes 10+ source results, removes duplicates, and separates evidence from inference.
 */
public final class ResearchIntelligence {
    public enum EvidenceLevel { ESTABLISHED, SUPPORTED, MIXED, EMERGING, INSUFFICIENT }
    public static final class Source {
        public final String id,title,url,summary; public final double authority;
        public Source(String id,String title,String url,String summary,double authority){this.id=id;this.title=title;this.url=url;this.summary=summary;this.authority=authority;}
    }
    public static final class Synthesis {
        public final String question; public final int sourceCount; public final EvidenceLevel level;
        public final List<Source> sources; public final List<String> agreements,disagreements,unknowns;
        public Synthesis(String q,int n,EvidenceLevel l,List<Source>s,List<String>a,List<String>d,List<String>u){question=q;sourceCount=n;level=l;sources=Collections.unmodifiableList(new ArrayList<>(s));agreements=Collections.unmodifiableList(new ArrayList<>(a));disagreements=Collections.unmodifiableList(new ArrayList<>(d));unknowns=Collections.unmodifiableList(new ArrayList<>(u));}
    }
    public Synthesis organize(String question,List<Source> input){
        List<Source> unique=new ArrayList<>(); Set<String> keys=new HashSet<>();
        if(input!=null) for(Source s:input){if(s==null)continue;String k=(s.url==null?"":s.url).toLowerCase(Locale.ROOT);if(k.isEmpty())k=(s.title==null?"":s.title).toLowerCase(Locale.ROOT);if(keys.add(k))unique.add(s);}
        unique.sort(Comparator.comparingDouble((Source s)->s.authority).reversed());
        EvidenceLevel level=unique.size()>=10?EvidenceLevel.SUPPORTED:(unique.size()>=5?EvidenceLevel.MIXED:EvidenceLevel.INSUFFICIENT);
        return new Synthesis(question,unique.size(),level,unique,
                unique.size()>=3?Collections.singletonList("multiple_sources_available_for_cross_check"):Collections.emptyList(),
                Collections.emptyList(),unique.size()<3?Collections.singletonList("insufficient_independent_sources"):Collections.emptyList());
    }
}
