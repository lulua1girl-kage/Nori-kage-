package com.nori.jarvis;

import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.nori.jarvis.nori.NoriNativeCore;
import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.meta.NoriMetaBrainEngine;
import java.util.*;

/** Step 34 bridge: exposes the Meta-Brain as a read/decision service to the app UI. */
@CapacitorPlugin(name="NoriMetaBrain")
public final class NoriMetaBrainPlugin extends Plugin {
    private NoriBrain brain;
    @Override public void load(){ brain=new NoriNativeCore().getBrain(); }
    private NoriMetaBrainEngine meta(){ return brain.getMetaBrainEngine(); }

    @PluginMethod public void capabilities(PluginCall c){
        JSArray a=new JSArray();
        for(NoriMetaBrainEngine.CapabilityStatus s:meta().capabilityMatrix()){
            JSObject o=new JSObject(); o.put("id",s.capability.name()); o.put("understood",s.understood);
            o.put("guideable",s.guideable); o.put("executable",s.executable); o.put("verifiable",s.verifiable); o.put("route",s.route); a.put(o);
        }
        JSObject r=new JSObject(); r.put("count",meta().capabilityMatrix().size()); r.put("capabilities",a); c.resolve(r);
    }

    @PluginMethod public void think(PluginCall c){
        String request=c.getString("request",""); String context=c.getString("context","");
        boolean external=c.getBoolean("externalAvailable",false); boolean initiated=c.getBoolean("userInitiated",false);
        boolean fresh=c.getBoolean("freshDataRequested",false); String cap=c.getString("capacity","UNKNOWN");
        NoriMetaBrainEngine.Capacity capacity;
        try{capacity=NoriMetaBrainEngine.Capacity.valueOf(cap.toUpperCase(Locale.ROOT));}catch(Exception e){capacity=NoriMetaBrainEngine.Capacity.UNKNOWN;}
        NoriMetaBrainEngine.ThoughtPlan p=meta().think(request,context,external,initiated,fresh,capacity);
        JSObject r=new JSObject(); r.put("goal",p.goal); r.put("phase",p.phase.name()); r.put("confidence",p.confidence.name());
        r.put("gate",p.gate.name()); r.put("needsFreshEvidence",p.needsFreshEvidence); r.put("needsUserControl",p.needsUserControl);
        r.put("estimatedWorkUnits",p.estimatedWorkUnits); r.put("strategy",p.strategy); r.put("capabilities",toStrings(p.capabilities));
        r.put("checks",toStrings(p.checks)); r.put("risks",toStrings(p.risks)); r.put("nextSteps",toStrings(p.nextSteps)); c.resolve(r);
    }

    @PluginMethod public void process(PluginCall c){
        String request=c.getString("request",""); String context=c.getString("context","");
        boolean external=c.getBoolean("externalAvailable",false); boolean initiated=c.getBoolean("userInitiated",false);
        boolean fresh=c.getBoolean("freshDataRequested",false); String cap=c.getString("capacity","UNKNOWN");
        NoriMetaBrainEngine.Capacity capacity;
        try{capacity=NoriMetaBrainEngine.Capacity.valueOf(cap.toUpperCase(Locale.ROOT));}catch(Exception e){capacity=NoriMetaBrainEngine.Capacity.UNKNOWN;}
        NoriMetaBrainOrchestrator.Cycle x=brain.processMetaBrain(request,context,external,initiated,fresh,capacity);
        JSObject r=new JSObject(); r.put("request",x.request); r.put("strategy",x.answerStrategy); r.put("requiresUserControl",x.requiresUserControl);
        r.put("requiresFreshEvidence",x.requiresFreshEvidence); r.put("phase",x.metaPlan.phase.name()); r.put("confidence",x.cognition.confidence.name());
        r.put("intent",x.cognition.intent.name()); r.put("effort",x.cognition.effort.name()); r.put("answerShape",x.cognition.answerShape.name());
        r.put("constitutionVerdict",x.constitution.verdict); r.put("constitutionInstruction",x.constitution.instruction);
        JSArray a=new JSArray(); for(NoriMetaBrainOrchestrator.CapabilityResult z:x.capabilities){JSObject o=new JSObject();o.put("id",z.capability.name());o.put("status",z.status.name());o.put("evidence",z.evidence);a.put(o);} r.put("capabilities",a);
        c.resolve(r);
    }

    @PluginMethod public void researchDepth(PluginCall c){
        int depth=meta().researchDepth(c.getString("question","")); JSObject r=new JSObject(); r.put("maxSources",depth); c.resolve(r);
    }

    @PluginMethod public void routeAppGoal(PluginCall c){
        JSObject r=new JSObject(); r.put("destination",meta().appRoute(c.getString("goal",""),c.getString("currentFeature",""))); c.resolve(r);
    }

    @PluginMethod public void freshness(PluginCall c){
        long now=c.getLong("now",System.currentTimeMillis()); long retrieved=c.getLong("retrievedAt",0L);
        JSObject r=new JSObject(); r.put("status",meta().worldFreshness(c.getBoolean("networkAvailable",false),retrieved,now)); c.resolve(r);
    }

    private JSArray toStrings(List<?> xs){JSArray a=new JSArray();for(Object x:xs)a.put(String.valueOf(x));return a;}
}
