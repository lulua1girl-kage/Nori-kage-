package com.nori.jarvis.nori.library;

import java.security.MessageDigest;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

/** Five-speed library pipeline: metadata immediately, extraction/indexing asynchronously, deep work on demand. */
public final class NoriFastLibraryPipeline {
    public enum State { ACCEPTED, INDEXED, QUEUED, READY, FAILED }
    public static final class Job { public final String id,sha256,name; public final NoriFileIntelligence.Route route; public final State state; public Job(String i,String s,String n,NoriFileIntelligence.Route r,State st){id=i;sha256=s;name=n;route=r;state=st;} }
    private final ExecutorService executor=Executors.newFixedThreadPool(2);
    private final Map<String,Job> jobs=new ConcurrentHashMap<>();
    private final Set<String> hashes=ConcurrentHashMap.newKeySet();
    private final NoriFileIntelligence intelligence=new NoriFileIntelligence();
    public Job accept(String name,String mime,byte[] sample){String hash=hash(sample==null?new byte[0]:sample);String id="file-"+hash.substring(0,16);NoriFileIntelligence.Route r=intelligence.route(name,mime);if(!hashes.add(hash))return jobs.get(id);Job j=new Job(id,hash,name,r,State.ACCEPTED);jobs.put(id,j);jobs.put(id,new Job(id,hash,name,r,State.INDEXED));executor.submit(()->jobs.put(id,new Job(id,hash,name,r,State.READY)));return jobs.get(id);}
    public boolean known(String sha){return hashes.contains(sha);}
    public Job get(String id){return jobs.get(id);}
    public int pending(){int n=0;for(Job j:jobs.values())if(j.state==State.ACCEPTED||j.state==State.INDEXED||j.state==State.QUEUED)n++;return n;}
    public void close(){executor.shutdownNow();}
    private String hash(byte[] b){try{byte[]x=MessageDigest.getInstance("SHA-256").digest(b);StringBuilder s=new StringBuilder();for(byte q:x)s.append(String.format(Locale.ROOT,"%02x",q));return s.toString();}catch(Exception e){return Integer.toHexString(Arrays.hashCode(b));}}
}
