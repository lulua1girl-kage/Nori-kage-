package com.nori.jarvis.nori.library;

/** Fast-path budget for student library interactions. */
public final class NoriLibraryPerformancePolicy {
    public static final long INTERACTIVE_TARGET_MS=700;
    public static final long METADATA_TARGET_MS=150;
    public static final long SEARCH_TARGET_MS=500;
    public boolean isInteractive(long ms){return ms<=INTERACTIVE_TARGET_MS;}
    public String policy(){return "Never make the student wait for deep extraction when metadata/indexed chunks can answer first. Stream progress and upgrade analysis only when needed.";}
}
