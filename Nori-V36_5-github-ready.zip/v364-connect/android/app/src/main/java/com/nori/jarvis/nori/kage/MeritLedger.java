package com.nori.jarvis.nori.kage;

import java.util.*;

/** Explicit merit ledger; state is owned by the caller/repository, not hidden inside KAGE. */
public final class MeritLedger {
    private int balance;
    private final List<Entry> history=new ArrayList<>();
    public MeritLedger(int initialBalance){balance=Math.max(0,initialBalance);}
    public synchronized void grant(String awardId,int points,String evidenceKey,String grantedAt){
        if(points<=0) throw new IllegalArgumentException("points must be positive");
        balance+=points; history.add(new Entry(awardId,points,evidenceKey,grantedAt));
    }
    public synchronized int getBalance(){return balance;}
    public synchronized List<Entry> getHistory(){return Collections.unmodifiableList(new ArrayList<>(history));}
    public static final class Entry { public final String awardId,evidenceKey,grantedAt; public final int points;
        Entry(String a,int p,String e,String g){awardId=a;points=p;evidenceKey=e;grantedAt=g;}
    }
}
