package com.nori.jarvis.nori.browser;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** Explicit browser hand-off. Nori never controls Chrome invisibly. */
public final class NoriChromeBridge {
    private NoriChromeBridge() {}
    public static boolean openUrl(Context context,String url){
        if(context==null||url==null||!url.startsWith("https://")) return false;
        Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PackageManager pm=context.getPackageManager();
        if(pm.getLaunchIntentForPackage("com.android.chrome")!=null){i.setPackage("com.android.chrome");}
        try{context.startActivity(i);return true;}catch(Exception e){
            try{i.setPackage(null);context.startActivity(i);return true;}catch(Exception ignored){return false;}
        }
    }
    public static boolean search(Context context,String query){
        if(query==null||query.trim().isEmpty())return false;
        try{return openUrl(context,"https://www.google.com/search?q="+URLEncoder.encode(query,StandardCharsets.UTF_8.name()));}
        catch(Exception e){return false;}
    }
    public static boolean news(Context context,String query){
        try{return openUrl(context,"https://news.google.com/search?q="+URLEncoder.encode(query==null?"latest news":query,StandardCharsets.UTF_8.name()));}
        catch(Exception e){return false;}
    }
}
