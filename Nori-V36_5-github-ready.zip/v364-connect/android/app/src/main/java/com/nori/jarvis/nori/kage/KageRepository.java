package com.nori.jarvis.nori.kage;

import java.util.*;

/** Persistence-facing KAGE contract. Implementation can be backed by Stage 4 native storage. */
public interface KageRepository {
    void appendAudit(AuditRecord record);
    List<AuditRecord> getAudit();
    int getMeritBalance();
    void setMeritBalance(int balance);
}
