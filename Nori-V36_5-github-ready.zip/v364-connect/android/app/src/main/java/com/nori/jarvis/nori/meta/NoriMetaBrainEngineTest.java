package com.nori.jarvis.nori.meta;

public final class NoriMetaBrainEngineTest {
    public static void main(String[] args) {
        NoriMetaBrainEngine n = new NoriMetaBrainEngine();
        if (NoriMetaBrainEngine.Capability.values().length != 30) throw new AssertionError("capability_count");
        NoriMetaBrainEngine.ThoughtPlan p = n.think("research the latest study methods and plan what to do tomorrow", "school exam soon", true, false, true, NoriMetaBrainEngine.Capacity.NORMAL);
        if (p.capabilities.size() < 5) throw new AssertionError("capability_selection");
        if (!p.needsFreshEvidence) throw new AssertionError("freshness");
        if (!p.checks.toString().contains("freshness")) throw new AssertionError("checks");
        if (n.researchDepth("exhaustive research") != 25) throw new AssertionError("research_25");
        if (!n.edgeAiRoute(true, true, true).contains("LOCAL")) throw new AssertionError("privacy_route");
        if (!n.failureRecovery("save","timeout",false,true).contains("ALTERNATE")) throw new AssertionError("recovery");
        n.recordStrategy("retrieval", true);
        if (!n.strategyEvidence("retrieval").contains("POSITIVE")) throw new AssertionError("strategy_learning");
        System.out.println("STEP34_SMOKE_PASS capabilities=" + NoriMetaBrainEngine.Capability.values().length + " selected=" + p.capabilities.size() + " researchMax=" + n.researchDepth("exhaustive research"));
    }
}
