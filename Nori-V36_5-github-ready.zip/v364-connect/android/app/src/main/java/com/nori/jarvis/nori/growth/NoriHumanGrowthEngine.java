package com.nori.jarvis.nori.growth;

import com.nori.jarvis.nori.brain.human.HumanContextEngine;
import java.util.*;

/** Non-clinical, autonomy-preserving human-context and growth layer. */
public final class NoriHumanGrowthEngine {
    public enum Signal { CAPACITY_LIMITED, OVERLOAD, LOW_ACTIVATION, AVOIDANCE_PATTERN, POSITIVE_MOMENTUM, UNCLEAR }
    public enum GrowthArea { ACADEMIC, SELF_CORRECTION, CONSISTENCY, SELF_RELIANCE, ADAPTABILITY, LIFE_SKILL, RECOVERY }
    public static final class Snapshot { public final Signal signal; public final boolean disclosureOptional; public final String nextStep;
        Snapshot(Signal s,boolean d,String n){signal=s;disclosureOptional=d;nextStep=n;}}
    public Snapshot assess(HumanContextEngine.Assessment a){
        if(a==null)return new Snapshot(Signal.UNCLEAR,true,"Ask only for the smallest information needed to choose a route.");
        String d=String.valueOf(a.difficulty).toLowerCase(Locale.ROOT);
        if(d.contains("overload"))return new Snapshot(Signal.OVERLOAD,true,"Reduce load before adding demands.");
        if(d.contains("fatigue"))return new Snapshot(Signal.CAPACITY_LIMITED,true,"Protect recovery and choose a manageable next step.");
        if(d.contains("low_activation"))return new Snapshot(Signal.LOW_ACTIVATION,true,"Use a deliberately small starting step.");
        if(d.contains("avoidance"))return new Snapshot(Signal.AVOIDANCE_PATTERN,true,"Address the repeated pattern without assuming its cause.");
        return new Snapshot(Signal.POSITIVE_MOMENTUM,true,"Preserve what is working and increase difficulty only when evidence supports it.");
    }
    public List<GrowthArea> areas(){return Collections.unmodifiableList(Arrays.asList(GrowthArea.ACADEMIC,GrowthArea.SELF_CORRECTION,GrowthArea.CONSISTENCY,GrowthArea.SELF_RELIANCE,GrowthArea.ADAPTABILITY,GrowthArea.LIFE_SKILL,GrowthArea.RECOVERY));}
}
