package com.nori.jarvis.nori.exam;

/** Evidence produced by exam-integrity monitoring. A trigger is a signal, not proof of misconduct. */
public final class NoriScreenEvidence {
    public final String packageName, trigger, confidence, timestamp;
    public NoriScreenEvidence(String packageName,String trigger,String confidence,String timestamp){this.packageName=packageName;this.trigger=trigger;this.confidence=confidence;this.timestamp=timestamp;}
}
