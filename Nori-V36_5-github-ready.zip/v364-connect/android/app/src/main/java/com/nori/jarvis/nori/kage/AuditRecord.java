package com.nori.jarvis.nori.kage;

/** Immutable evidence record for a KAGE decision. */
public final class AuditRecord {
    public final String eventId, action, timestamp, evidenceSummary;
    public final boolean confirmed;
    public AuditRecord(String eventId,String action,String timestamp,String evidenceSummary,boolean confirmed){
        this.eventId=eventId;this.action=action;this.timestamp=timestamp;this.evidenceSummary=evidenceSummary;this.confirmed=confirmed;
    }
}
