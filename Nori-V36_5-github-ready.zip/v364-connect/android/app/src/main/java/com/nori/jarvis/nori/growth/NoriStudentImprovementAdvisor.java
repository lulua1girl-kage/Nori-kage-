package com.nori.jarvis.nori.growth;

import java.util.*;

/** Gives actionable improvement feedback without turning performance into personal worth. */
public final class NoriStudentImprovementAdvisor {
    public static final class Advice { public final String area,observation,action; public final int priority; public Advice(String a,String o,String x,int p){area=a;observation=o;action=x;priority=p;} }
    public Advice fromEvidence(String area,String observation,String action,int priority){return new Advice(area,observation,action,Math.max(0,Math.min(100,priority)));}
    public String emailBody(List<Advice> items){StringBuilder b=new StringBuilder("Nori improvement summary\n\n");for(Advice a:items)b.append(a.area).append(": ").append(a.observation).append("\nNext step: ").append(a.action).append("\n\n");return b.toString();}
    public String rule(){return "Describe observable patterns and useful next actions; never equate academic performance with personal worth and never send sensitive details without authorization.";}
}
