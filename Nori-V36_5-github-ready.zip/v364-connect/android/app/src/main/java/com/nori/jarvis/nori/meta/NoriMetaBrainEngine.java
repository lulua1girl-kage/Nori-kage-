package com.nori.jarvis.nori.meta;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Step 34: Meta-Brain integration layer.
 *
 * This is an orchestration layer, not a second assistant. It makes the 30
 * capability families cooperate through one bounded decision cycle while
 * preserving Human Override, Constitution, permissions and verification.
 * No hidden chain-of-thought is stored or exposed.
 */
public final class NoriMetaBrainEngine {
    public enum Capability {
        COGNITIVE_LOOP,
        PERSONAL_WORLD_MODEL,
        TEMPORAL_INTELLIGENCE,
        CAUSAL_REASONING,
        COUNTERFACTUAL_REASONING,
        ADAPTIVE_PERSONALITY,
        CONVERSATION_STATE,
        RELATIONSHIP_CONTINUITY,
        DYNAMIC_GOAL_GRAPH,
        SKILL_GRAPH,
        MISCONCEPTION_DETECTION,
        TRANSFER_INTELLIGENCE,
        RETENTION_MODEL,
        STRATEGY_EXPERIMENTS,
        INTERVENTION_INTELLIGENCE,
        HUMAN_STATE_REASONING,
        DISCLOSURE_CONTEXT,
        CONTRADICTION_RESOLUTION,
        EVIDENCE_GRAPH,
        SELF_CORRECTION,
        CAPABILITY_EXECUTION,
        EDGE_AI_EXECUTION,
        MODEL_ARBITRATION,
        RESEARCH_BRAIN,
        WORLD_AWARENESS,
        APP_OPERATING_MODEL,
        FAILURE_RECOVERY,
        RESOURCE_INTELLIGENCE,
        SECURITY_BOUNDARY_INTELLIGENCE,
        META_BRAIN
    }

    public enum Phase { UNDERSTAND, CONTEXT, RECALL, REASON, STRATEGY, CONTROL, EXECUTE, VERIFY, RECOVER, LEARN }
    public enum Confidence { LOW, MODERATE, HIGH }
    public enum ActionGate { ANSWER, PREPARE, NEEDS_USER_CONFIRMATION, BLOCK, UNAVAILABLE }
    public enum Capacity { NORMAL, LIMITED, LOW, UNKNOWN }

    public static final class Signal {
        public final String key;
        public final String value;
        public final long timestamp;
        public Signal(String key, String value, long timestamp) {
            this.key = safe(key); this.value = safe(value); this.timestamp = timestamp;
        }
    }

    public static final class WorldFact {
        public final String subject, relation, value, source;
        public final Confidence confidence;
        public final long observedAt;
        public WorldFact(String subject, String relation, String value, String source,
                         Confidence confidence, long observedAt) {
            this.subject=safe(subject); this.relation=safe(relation); this.value=safe(value);
            this.source=safe(source); this.confidence=confidence==null?Confidence.LOW:confidence; this.observedAt=observedAt;
        }
    }

    public static final class ThoughtPlan {
        public final String goal;
        public final Phase phase;
        public final Confidence confidence;
        public final ActionGate gate;
        public final List<Capability> capabilities;
        public final List<String> checks;
        public final List<String> risks;
        public final List<String> nextSteps;
        public final boolean needsFreshEvidence;
        public final boolean needsUserControl;
        public final int estimatedWorkUnits;
        public final String strategy;
        ThoughtPlan(String goal, Phase phase, Confidence confidence, ActionGate gate,
                    List<Capability> capabilities, List<String> checks, List<String> risks,
                    List<String> nextSteps, boolean fresh, boolean control, int units, String strategy) {
            this.goal=safe(goal); this.phase=phase; this.confidence=confidence; this.gate=gate;
            this.capabilities=immutable(capabilities); this.checks=immutable(checks); this.risks=immutable(risks);
            this.nextSteps=immutable(nextSteps); this.needsFreshEvidence=fresh; this.needsUserControl=control;
            this.estimatedWorkUnits=units; this.strategy=safe(strategy);
        }
    }

    public static final class CapabilityStatus {
        public final Capability capability;
        public final boolean understood;
        public final boolean guideable;
        public final boolean executable;
        public final boolean verifiable;
        public final String route;
        CapabilityStatus(Capability c, boolean u, boolean g, boolean e, boolean v, String r) {
            capability=c; understood=u; guideable=g; executable=e; verifiable=v; route=safe(r);
        }
    }

    public static final class Outcome {
        public final String action;
        public final String result;
        public final boolean effective;
        public final String learning;
        public final long timestamp;
        Outcome(String a,String r,boolean e,String l,long t){action=safe(a);result=safe(r);effective=e;learning=safe(l);timestamp=t;}
    }

    private final EnumMap<Capability, CapabilityStatus> catalog = new EnumMap<>(Capability.class);
    private final Map<String, WorldFact> world = new ConcurrentHashMap<>();
    private final ArrayDeque<Signal> signals = new ArrayDeque<>();
    private final ArrayDeque<Outcome> outcomes = new ArrayDeque<>();
    private final Map<String, Integer> correctionCounts = new ConcurrentHashMap<>();
    private final Map<String, Integer> strategyResults = new ConcurrentHashMap<>();
    private volatile Phase lastPhase = Phase.UNDERSTAND;
    private volatile String lastStrategy = "understand_goal_then_choose_minimum_safe_work";
    private volatile long lastCycleAt = 0L;

    public NoriMetaBrainEngine() { registerCatalog(); }

    private void registerCatalog() {
        for (Capability c : Capability.values()) {
            catalog.put(c, new CapabilityStatus(c, true, true, true, true, routeFor(c)));
        }
        // These are deliberately capability contracts: execution still depends on the
        // concrete runtime, permission, user request, provider/model and ActionEngine.
        catalog.put(Capability.EDGE_AI_EXECUTION, new CapabilityStatus(Capability.EDGE_AI_EXECUTION,true,true,true,true,"EdgeAiEngine"));
        catalog.put(Capability.WORLD_AWARENESS, new CapabilityStatus(Capability.WORLD_AWARENESS,true,true,true,true,"WorldWebConnector"));
        catalog.put(Capability.APP_OPERATING_MODEL, new CapabilityStatus(Capability.APP_OPERATING_MODEL,true,true,true,true,"AppUnderstandingEngine"));
    }

    /** The single coordination entry point for the 30 capability families. */
    public synchronized ThoughtPlan think(String request, String context, boolean externalAvailable,
                                           boolean userInitiated, boolean freshDataRequested,
                                           Capacity capacity) {
        String r = normalize(request), c = normalize(context);
        lastCycleAt = System.currentTimeMillis();
        List<Capability> selected = selectCapabilities(r, freshDataRequested);
        boolean ambiguous = r.length() < 5 || containsAny(r,"it","that","this","something","same thing");
        boolean action = userInitiated && containsAny(r,"open","save","send","schedule","start","do","change","delete","export");
        boolean dangerousOrExternal = containsAny(r,"publish","post","message","permission","camera","microphone","screen","other app");
        boolean control = action || dangerousOrExternal;
        boolean fresh = freshDataRequested || containsAny(r,"latest","today","current","now","recent","weather","news","trend");
        boolean support = containsAny(r,"tired","overwhelmed","stressed","can't focus","cannot focus","bad day","upset","confused");
        boolean research = containsAny(r,"research","sources","compare","evidence","fact check","study","investigate");
        Confidence conf = confidence(r,c,ambiguous,fresh,research,capacity);
        Phase phase = action ? Phase.CONTROL : (support ? Phase.CONTEXT : Phase.UNDERSTAND);
        ActionGate gate;
        if (ambiguous && c.length()<12) gate=ActionGate.NEEDS_USER_CONFIRMATION;
        else if (control && !userInitiated) gate=ActionGate.NEEDS_USER_CONFIRMATION;
        else if (dangerousOrExternal && !userInitiated) gate=ActionGate.NEEDS_USER_CONFIRMATION;
        else if (capacity==Capacity.LOW && action && !containsAny(r,"urgent","important")) gate=ActionGate.PREPARE;
        else if (fresh && !externalAvailable) gate=ActionGate.UNAVAILABLE;
        else gate=ActionGate.ANSWER;

        List<String> checks = new ArrayList<>();
        checks.add("identify the user's actual outcome");
        checks.add("separate observed facts from inference");
        checks.add("preserve Human Override and explicit authorization");
        if(fresh) checks.add("verify freshness before presenting current information");
        if(research) checks.add("separate sources, claims, contradictions and uncertainty");
        if(action) checks.add("preview and verify the requested action");
        if(support) checks.add("adjust difficulty to current capacity without diagnosing");
        if(selected.contains(Capability.MISCONCEPTION_DETECTION)) checks.add("look for repeated conceptual error, not just repeated wrong answers");

        List<String> risks = new ArrayList<>();
        if(ambiguous) risks.add("ambiguous request");
        if(fresh && !externalAvailable) risks.add("fresh-data unavailable");
        if(dangerousOrExternal) risks.add("external side effect requires user control");
        if(capacity==Capacity.LOW) risks.add("low usable capacity");
        if(containsAny(r,"always","never","because","proves","definitely")) risks.add("overconfident or causal wording");

        List<String> next = new ArrayList<>();
        next.add("resolve goal and relevant context");
        if(selected.contains(Capability.PERSONAL_WORLD_MODEL)) next.add("retrieve only task-relevant personal context");
        if(selected.contains(Capability.RESEARCH_BRAIN)) next.add("retrieve only the evidence depth justified by the question");
        if(selected.contains(Capability.EDGE_AI_EXECUTION)) next.add("select the smallest suitable local model/runtime");
        if(control) next.add("show a preview before side effects");
        next.add("verify the result and record outcome without exposing hidden reasoning");

        int units = 2 + selected.size() + (research?5:0) + (action?3:0) + (fresh?2:0);
        if(capacity==Capacity.LOW) units=Math.max(2,units/2);
        lastPhase = gate==ActionGate.ANSWER ? Phase.REASON : Phase.CONTROL;
        lastStrategy = strategy(selected, gate, conf, capacity, fresh);
        return new ThoughtPlan(r,lastPhase,conf,gate,selected,checks,risks,next,fresh,control,units,lastStrategy);
    }

    /** Capability truth matrix used by the app to avoid claiming that a catalog entry is fully wired. */
    public CapabilityStatus capabilityStatus(Capability c) { return catalog.get(c); }
    public List<CapabilityStatus> capabilityMatrix() { return Collections.unmodifiableList(new ArrayList<>(catalog.values())); }

    // 1. Cognitive loop
    public Phase cognitivePhase(){ return lastPhase; }
    public String cognitiveLoop(String request){ return "UNDERSTAND>CONTEXT>RECALL>REASON>STRATEGY>CONTROL>EXECUTE>VERIFY>RECOVER>LEARN"; }

    // 2. Personal world model
    public void rememberWorldFact(WorldFact fact){ if(fact==null)return; world.put(fact.subject+"|"+fact.relation,fact); }
    public List<WorldFact> relevantWorld(String query){
        String q=normalize(query); List<WorldFact> out=new ArrayList<>();
        for(WorldFact f:world.values()) if(q.contains(normalize(f.subject))||q.contains(normalize(f.relation))||q.contains(normalize(f.value))) out.add(f);
        out.sort((a,b)->Long.compare(b.observedAt,a.observedAt)); return Collections.unmodifiableList(out);
    }

    // 3. Temporal intelligence
    public String temporalInterpretation(long previous,long current,String event){
        long delta=Math.max(0,current-previous);
        if(previous<=0)return "first_observation";
        if(delta<60_000L)return "immediate_continuation:"+safe(event);
        if(delta<3_600_000L)return "same_session:"+safe(event);
        if(delta<86_400_000L)return "same_day_gap:"+safe(event);
        return "multi_day_change:"+safe(event);
    }

    // 4. Causal reasoning
    public String causalAssessment(String observation,String proposedCause,boolean evidence){
        if(!evidence)return "possible_cause_only:no_established_causality";
        return "supported_association_requires_context:"+safe(proposedCause);
    }

    // 5. Counterfactual reasoning
    public List<String> counterfactuals(String goal,String variable){
        String g=safe(goal), v=safe(variable);
        return Collections.unmodifiableList(Arrays.asList("change:"+v+" -> expected effect on "+g,
                "hold:"+v+" constant -> compare alternative route for "+g,
                "reverse:"+v+" -> identify downside and recovery path"));
    }

    // 6. Adaptive personality
    public String personalityFor(Capacity capacity,boolean serious,boolean academic){
        if(serious)return "CALM_DIRECT";
        if(capacity==Capacity.LOW)return "GENTLE_LOW_LOAD";
        if(academic)return "ACADEMIC_FOCUSED";
        return "FRIENDLY_ADAPTIVE";
    }

    // 7. Conversation state
    public String conversationState(String request){
        String r=normalize(request);
        if(containsAny(r,"actually","problem","help me","i don't know"))return "PROBLEM_DISCOVERY";
        if(containsAny(r,"plan","schedule","steps"))return "PLANNING";
        if(containsAny(r,"do it","open","save","start"))return "ACTION";
        if(containsAny(r,"done","worked","failed","didn't work"))return "FOLLOW_UP";
        return "CONVERSATION_OR_INFORMATION";
    }

    // 8. Relationship continuity: continuity without dependency framing.
    public String continuity(String priorResult,String currentRequest){
        if(normalize(priorResult).isEmpty())return "NO_PRIOR_RESULT";
        if(normalize(currentRequest).isEmpty())return "NO_CURRENT_REQUEST";
        return "compare_current_request_against_prior_result_and_recheck_changed_constraints";
    }

    // 9. Dynamic goal graph
    public List<String> goalGraph(String goal){
        String g=safe(goal); return Collections.unmodifiableList(Arrays.asList(
                "GOAL:"+g,"DOMAIN:"+g,"SKILL_PREREQUISITES:"+g,"CHECKPOINT:"+g,"NEAR_TERM_ACTION:"+g,"VERIFY:"+g));
    }

    // 10. Skill graph
    public List<String> skillGraph(String subject){
        String s=safe(subject); return Collections.unmodifiableList(Arrays.asList(
                s+":knowledge",s+":recognition",s+":application",s+":problem_solving",s+":self_check",s+":transfer"));
    }

    // 11. Misconception detection
    public String misconceptionSignal(String concept,List<Boolean> attempts){
        int wrong=0, n=attempts==null?0:attempts.size();
        if(attempts!=null)for(Boolean b:attempts)if(Boolean.FALSE.equals(b))wrong++;
        if(n<3)return "INSUFFICIENT_EVIDENCE";
        if(wrong>=2)return "REPEATED_ERROR_REVIEW:"+safe(concept);
        return "NO_STRONG_MISCONCEPTION_SIGNAL";
    }

    // 12. Transfer intelligence
    public String transferAssessment(int familiarCorrect,int novelCorrect){
        if(familiarCorrect<1)return "NO_BASELINE";
        if(novelCorrect>=familiarCorrect)return "TRANSFER_EVIDENCE_PRESENT";
        if(novelCorrect>0)return "PARTIAL_TRANSFER_GAP";
        return "TRANSFER_GAP_REQUIRES_RETEACH_AND_REAPPLICATION";
    }

    // 13. Retention model
    public String retentionNeed(long lastRetrieval,long now,int successfulRetrievals){
        if(lastRetrieval<=0)return "RETRIEVAL_BASELINE_REQUIRED";
        long age=Math.max(0,now-lastRetrieval);
        if(successfulRetrievals<2)return "RETRIEVE_SOON_AND_RECHECK";
        if(age>7L*86_400_000L)return "RETRIEVAL_REFRESH_DUE";
        return "RETENTION_SIGNAL_STABLE_BUT_NOT_PROOF_OF_LONG_TERM_MASTERY";
    }

    // 14. Strategy experiments
    public void recordStrategy(String strategy,boolean success){
        String k=safe(strategy); strategyResults.merge(k,success?1:-1,Integer::sum);
    }
    public String strategyEvidence(String strategy){
        int score=strategyResults.getOrDefault(safe(strategy),0);
        return score==0?"NO_LOCAL_EVIDENCE":(score>0?"POSITIVE_LOCAL_SIGNAL":"NEGATIVE_LOCAL_SIGNAL");
    }

    // 15. Intervention intelligence
    public String interventionDecision(int expectedBenefit,int interruptionCost,boolean protectedWindow,boolean requestedHelp){
        if(protectedWindow && !requestedHelp)return "HOLD_NON_URGENT_INTERVENTION";
        if(requestedHelp)return "INTERVENE_NOW";
        return expectedBenefit>interruptionCost?"LOW_COST_INTERVENTION":"DO_NOT_INTERRUPT";
    }

    // 16. Human-state reasoning
    public String humanState(Capacity capacity,boolean explicitFatigue,boolean explicitOverload,boolean momentum){
        if(explicitOverload)return "OVERLOADED";
        if(explicitFatigue)return "FATIGUE_LIMITED";
        if(capacity==Capacity.LOW)return "LOW_CAPACITY";
        if(momentum)return "POSITIVE_MOMENTUM";
        return "NORMAL_OR_UNKNOWN";
    }

    // 17. Disclosure context
    public String disclosureContext(String disclosure,boolean userVoluntary){
        if(!userVoluntary)return "DO_NOT_TREAT_AS_VOLUNTARY_PERSONAL_CONTEXT";
        if(safe(disclosure).isEmpty())return "NO_DISCLOSURE";
        return "CONTEXT_ONLY_NOT_DIAGNOSIS:"+safe(disclosure);
    }

    // 18. Contradiction resolution
    public String contradiction(String statementA,String statementB){
        String a=normalize(statementA),b=normalize(statementB);
        if(a.equals(b))return "NO_CONTRADICTION";
        if(a.isEmpty()||b.isEmpty())return "INSUFFICIENT_CONTEXT";
        return "CONFLICT_REQUIRES_SCOPE_TIME_OR_EVIDENCE_CHECK";
    }

    // 19. Evidence graph
    public List<String> evidenceGraph(String claim,String evidence,String interpretation){
        return Collections.unmodifiableList(Arrays.asList("CLAIM:"+safe(claim),"EVIDENCE:"+safe(evidence),"INTERPRETATION:"+safe(interpretation),"CONFIDENCE:CALIBRATE","DECISION:ONLY_AFTER_RELEVANCE_CHECK"));
    }

    // 20. Self-correction
    public String selfCorrect(String errorKey,String oldBehavior,String correctedBehavior){
        String k=safe(errorKey); correctionCounts.merge(k,1,Integer::sum);
        return "CORRECTED:"+k+";NEXT_CHECK="+safe(correctedBehavior);
    }

    // 21. Capability execution lifecycle
    public List<String> executionLifecycle(){
        return Collections.unmodifiableList(Arrays.asList("DISCOVER","UNDERSTAND","RESOLVE","PREPARE","PREVIEW","AUTHORIZE","EXECUTE","VERIFY","RECOVER","LEARN"));
    }

    // 22. Edge AI execution policy
    public String edgeAiRoute(boolean privateData,boolean localBackendAvailable,boolean remoteAllowed){
        if(privateData && localBackendAvailable)return "LOCAL_ONLY_PREFERRED";
        if(localBackendAvailable)return "LOCAL_FIRST";
        return remoteAllowed?"REMOTE_FALLBACK_WITH_DISCLOSURE":"DETERMINISTIC_LOCAL_FALLBACK";
    }

    // 23. Model arbitration
    public String arbitrateModel(String task,boolean multimodal,boolean fast,boolean privateData,boolean network){
        if(privateData)return "LOCAL_PRIVACY_FIRST";
        if(multimodal)return network?"VISION_CAPABLE_PROVIDER_OR_LOCAL_MULTIMODAL":"LOCAL_MULTIMODAL_IF_AVAILABLE";
        if(fast)return "LOW_LATENCY_LOCAL_OR_FAST_PROVIDER";
        return network?"CAPABILITY_MATCHED_PROVIDER":"LOCAL_FALLBACK";
    }

    // 24. Research brain, bounded to at most 25 source slots.
    public int researchDepth(String question){
        String q=normalize(question);
        if(containsAny(q,"exhaustive","deep research","comprehensive"))return 25;
        if(containsAny(q,"compare","current","latest","evidence"))return 8;
        if(containsAny(q,"research","investigate"))return 15;
        return 3;
    }

    // 25. World awareness
    public String worldFreshness(boolean networkAvailable,long retrievedAt,long now){
        if(!networkAvailable)return "OFFLINE_UNKNOWN_FRESHNESS";
        long age=Math.max(0,now-retrievedAt);
        if(age<15*60_000L)return "LIVE_RECENT";
        if(age<24*60*60_000L)return "RECENT";
        return "STALE_RECHECK_REQUIRED";
    }

    // 26. App operating model
    public String appRoute(String goal,String currentFeature){
        String g=normalize(goal), f=normalize(currentFeature);
        if(containsAny(g,"study","subject","lesson","quiz"))return "STUDY_CENTER";
        if(containsAny(g,"result","grade","score"))return "RESULTS";
        if(containsAny(g,"calendar","schedule"))return "CALENDAR";
        if(containsAny(g,"alarm","remind"))return "ALARMS";
        if(containsAny(g,"focus","block"))return "FOCUS";
        if(containsAny(g,"recover","recovery"))return "RECOVER";
        return f.isEmpty()?"HOME_OR_COMMAND":"CURRENT_FEATURE_GUIDANCE";
    }

    // 27. Failure recovery
    public String failureRecovery(String operation,String error,boolean safeRetry,boolean alternateRoute){
        if(safeRetry)return "RETRY_ONCE_WITH_SAME_INTENT:"+safe(operation);
        if(alternateRoute)return "ALTERNATE_ROUTE:"+safe(operation);
        return "FAIL_CLOSED_AND_EXPLAIN_LIMITATION:"+safe(error);
    }

    // 28. Resource intelligence
    public String resourceStrategy(boolean lowBattery,boolean lowMemory,boolean network,boolean heavyTask){
        if(lowMemory)return "MINIMIZE_MODEL_AND_CONTEXT";
        if(lowBattery&&heavyTask)return "DEFER_OR_USE_LIGHT_LOCAL_PATH";
        if(!network)return "OFFLINE_FIRST";
        if(heavyTask)return "BOUNDED_DEEP_PATH";
        return "FAST_PATH";
    }

    // 29 is intentionally represented by the resource capability above; capability count remains exactly 30.
    // 30. Meta-brain supervisory summary
    public String metaBrainSummary(){
        return "ONE_BRAIN:human+world+app_models -> unified_state -> memory -> reasoning -> strategy -> control -> execution -> verification -> learning";
    }

    public void recordOutcome(String action,String result,boolean effective,String learning){
        synchronized(outcomes){ outcomes.addLast(new Outcome(action,result,effective,learning,System.currentTimeMillis())); while(outcomes.size()>256)outcomes.removeFirst(); }
    }
    public List<Outcome> recentOutcomes(){ synchronized(outcomes){ return Collections.unmodifiableList(new ArrayList<>(outcomes)); } }
    public int worldFactCount(){return world.size();}
    public int correctionCount(String key){return correctionCounts.getOrDefault(safe(key),0);}
    public long lastCycleAt(){return lastCycleAt;}
    public String lastStrategy(){return lastStrategy;}

    private List<Capability> selectCapabilities(String r,boolean fresh){
        LinkedHashSet<Capability> s=new LinkedHashSet<>();
        s.add(Capability.COGNITIVE_LOOP); s.add(Capability.CONVERSATION_STATE); s.add(Capability.PERSONAL_WORLD_MODEL);
        if(fresh||containsAny(r,"latest","today","current","news","weather","trend")){s.add(Capability.WORLD_AWARENESS);s.add(Capability.TEMPORAL_INTELLIGENCE);}
        if(containsAny(r,"why","because","cause","reason")){s.add(Capability.CAUSAL_REASONING);s.add(Capability.EVIDENCE_GRAPH);}
        if(containsAny(r,"what if","if i","scenario"))s.add(Capability.COUNTERFACTUAL_REASONING);
        if(containsAny(r,"study","learn","exam","biology","chemistry","physics","math")){
            s.add(Capability.DYNAMIC_GOAL_GRAPH);s.add(Capability.SKILL_GRAPH);s.add(Capability.MISCONCEPTION_DETECTION);
            s.add(Capability.TRANSFER_INTELLIGENCE);s.add(Capability.RETENTION_MODEL);s.add(Capability.STRATEGY_EXPERIMENTS);
        }
        if(containsAny(r,"tired","overwhelmed","stressed","can't focus","bad day","confused")){s.add(Capability.HUMAN_STATE_REASONING);s.add(Capability.INTERVENTION_INTELLIGENCE);}
        if(containsAny(r,"research","source","evidence","compare","investigate"))s.add(Capability.RESEARCH_BRAIN);
        if(containsAny(r,"open","save","send","schedule","start","do","change","export")){s.add(Capability.APP_OPERATING_MODEL);s.add(Capability.CAPABILITY_EXECUTION);}
        if(containsAny(r,"private","privacy","permission","security","model","local ai","offline ai","llama","onnx","mediapipe","tflite","litert")){s.add(Capability.SECURITY_BOUNDARY_INTELLIGENCE);}
        if(containsAny(r,"model","local ai","offline ai","llama","onnx","mediapipe","tflite","litert")){s.add(Capability.EDGE_AI_EXECUTION);s.add(Capability.MODEL_ARBITRATION);s.add(Capability.RESOURCE_INTELLIGENCE);}
        if(containsAny(r,"error","failed","bug","doesn't work"))s.add(Capability.FAILURE_RECOVERY);s.add(Capability.SELF_CORRECTION);
        if(s.size()<3)s.add(Capability.ADAPTIVE_PERSONALITY);
        return new ArrayList<>(s);
    }

    private String strategy(List<Capability> caps,ActionGate gate,Confidence conf,Capacity cap,boolean fresh){
        if(gate==ActionGate.NEEDS_USER_CONFIRMATION)return "CLARIFY_OR_PREVIEW_BEFORE_SIDE_EFFECT";
        if(gate==ActionGate.UNAVAILABLE)return "EXPLAIN_FRESHNESS_LIMIT_AND_USE_SAFE_FALLBACK";
        if(cap==Capacity.LOW)return "REDUCE_LOAD_AND_PROTECT_CAPACITY";
        if(fresh)return "FRESH_EVIDENCE_THEN_SYNTHESIZE_AND_VERIFY";
        if(caps.contains(Capability.CAPABILITY_EXECUTION))return "RESOLVE_PREVIEW_AUTHORIZE_EXECUTE_VERIFY";
        return conf==Confidence.LOW?"CONSERVATIVE_ANSWER_WITH_UNCERTAINTY":"GOAL_CONTEXT_REASON_VERIFY";
    }

    private Confidence confidence(String r,String c,boolean amb,boolean fresh,boolean research,Capacity cap){
        int n=0;if(r.length()>20)n++;if(c.length()>12)n++;if(!amb)n++;if(!fresh)n++;if(!research)n++;if(cap!=Capacity.UNKNOWN)n++;
        return n>=5?Confidence.HIGH:n>=3?Confidence.MODERATE:Confidence.LOW;
    }

    private String routeFor(Capability c){return c.name();}
    private static boolean containsAny(String p,String... xs){for(String x:xs)if((" "+p+" ").contains(" "+x+" "))return true;return false;}
    private static String normalize(String s){return safe(s).toLowerCase(Locale.ROOT).replaceAll("\\s+"," ").trim();}
    private static String safe(String s){return s==null?"":s.trim();}
    private static <T> List<T> immutable(Collection<T> x){return Collections.unmodifiableList(new ArrayList<>(x==null?Collections.emptyList():x));}
}
