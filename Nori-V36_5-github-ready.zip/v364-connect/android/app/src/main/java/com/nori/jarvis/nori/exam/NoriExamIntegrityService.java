package com.nori.jarvis.nori.exam;

import android.app.*;
import android.app.usage.*;
import android.content.*;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.MediaProjection;
import android.os.*;
import androidx.core.app.ServiceCompat;
import java.io.*;
import java.nio.ByteBuffer;
import java.util.*;

/**
 * Explicit exam-integrity monitor. It watches foreground app identity via
 * UsageStats, not every user movement. A screen frame is captured only when a
 * configured suspicious app becomes foreground. Projection is torn down when
 * the service stops. No continuous screen recording or hidden microphone use.
 */
public final class NoriExamIntegrityService extends Service {
    public static final String ACTION_START="com.nori.jarvis.exam.START";
    public static final String ACTION_STOP="com.nori.jarvis.exam.STOP";
    public static final String EVENT_SUSPICIOUS="com.nori.jarvis.exam.SUSPICIOUS";
    public static final String EVENT_SCREEN="com.nori.jarvis.exam.SCREEN";
    public static final String EVENT_STATE="com.nori.jarvis.exam.STATE";
    private static final int NOTIFICATION_ID=8610;
    private static final long MAX_MS=4L*60L*60L*1000L;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final NoriScreenSuspicionAnalyzer analyzer=new NoriScreenSuspicionAnalyzer();
    private UsageStatsManager usage;
    private MediaProjection projection; private VirtualDisplay display; private ImageReader reader;
    private boolean active,capturing; private String lastPackage=""; private long lastTrigger=0L; private final ArrayDeque<String> recentPackages=new ArrayDeque<>(); private final ArrayDeque<Long> recentTimes=new ArrayDeque<>();
    private final Runnable poll=()->{pollForeground(); if(active)handler.postDelayed(this::runPoll,400);};
    private void runPoll(){handler.post(poll);}
    @Override public void onCreate(){super.onCreate();usage=(UsageStatsManager)getSystemService(USAGE_STATS_SERVICE);channel();}
    @Override public int onStartCommand(Intent in,int flags,int id){
        if(in==null){return START_NOT_STICKY;}
        if(ACTION_STOP.equals(in.getAction())){stopMonitoring();return START_NOT_STICKY;}
        if(!ACTION_START.equals(in.getAction()))return START_NOT_STICKY;
        Intent data=in.getParcelableExtra("projectionData"); int code=in.getIntExtra("resultCode",Activity.RESULT_CANCELED);
        if(data==null||code!=Activity.RESULT_OK){stopSelf();return START_NOT_STICKY;}
        try{
            android.media.projection.MediaProjectionManager m=(android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            projection=m.getMediaProjection(code,data); if(projection==null){stopSelf();return START_NOT_STICKY;}
            active=true; capturing=false; lastPackage=""; lastTrigger=0;
            if(Build.VERSION.SDK_INT>=29)ServiceCompat.startForeground(this,NOTIFICATION_ID,note("Exam integrity ON — screen review only on suspicious triggers"),android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION); else startForeground(NOTIFICATION_ID,note("Exam integrity ON — screen review only on suspicious triggers"));
            handler.removeCallbacks(poll); handler.post(poll); handler.postDelayed(this::stopMonitoring,MAX_MS);
        }catch(Exception e){stopSelf();}
        return START_NOT_STICKY;
    }
    private void pollForeground(){
        if(!active||usage==null)return;
        long now=System.currentTimeMillis(); List<UsageStats> stats=usage.queryUsageStats(UsageStatsManager.INTERVAL_DAILY,now-5000,now);
        String current=""; long latest=0; for(UsageStats s:stats){if(s.getLastTimeUsed()>latest){latest=s.getLastTimeUsed();current=s.getPackageName();}}
        if(current.isEmpty()||current.equals(getPackageName()))return;
        if(!current.equals(lastPackage)){
            boolean seenBefore=current.equals(lastPackage);
            recentPackages.addLast(current); recentTimes.addLast(now); while(!recentTimes.isEmpty()&&now-recentTimes.peekFirst()>10000){recentTimes.removeFirst();recentPackages.removeFirst();}
            NoriScreenEvidence ev=analyzer.inspect(current,true,seenBefore);
            if(ev==null && recentPackages.size()>=3){ev=new NoriScreenEvidence(current,"rapid_app_switching","probability=moderate",String.valueOf(now));}
            if(ev!=null && now-lastTrigger>3000){lastTrigger=now; emit(EVENT_SUSPICIOUS,ev.packageName+"|"+ev.trigger+"|"+ev.confidence); captureOneFrame(ev);}
            lastPackage=current;
        }
    }
    private void captureOneFrame(NoriScreenEvidence ev){
        if(capturing||projection==null)return; capturing=true;
        try{
            int w=Math.min(1280,getResources().getDisplayMetrics().widthPixels), h=Math.min(720,getResources().getDisplayMetrics().heightPixels), d=getResources().getDisplayMetrics().densityDpi;
            reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
            reader.setOnImageAvailableListener(r->finishFrame(r,w,h,ev),handler);
            display=projection.createVirtualDisplay("NoriExamReview",w,h,d,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
            handler.postDelayed(()->{if(capturing)finishFrame(reader,w,h,ev);},300);
        }catch(Exception e){capturing=false;}
    }
    private void finishFrame(ImageReader r,int w,int h,NoriScreenEvidence ev){
        if(!capturing||r==null)return; Image image=null;
        try{image=r.acquireLatestImage();if(image==null)return; Image.Plane p=image.getPlanes()[0];ByteBuffer b=p.getBuffer();int ps=p.getPixelStride(),rs=p.getRowStride();int pad=rs-ps*w;Bitmap bmp=Bitmap.createBitmap(w+pad/ps,h,Bitmap.Config.ARGB_8888);bmp.copyPixelsFromBuffer(b);Bitmap crop=Bitmap.createBitmap(bmp,0,0,w,h);bmp.recycle();File dir=new File(getCacheDir(),"nori_exam");if(!dir.exists())dir.mkdirs();File out=new File(dir,"review_"+System.currentTimeMillis()+".jpg");try(FileOutputStream f=new FileOutputStream(out)){crop.compress(Bitmap.CompressFormat.JPEG,70,f);}crop.recycle();capturing=false;Intent i=new Intent(EVENT_SCREEN);i.setPackage(getPackageName());i.putExtra("path",out.getAbsolutePath());i.putExtra("packageName",ev.packageName);i.putExtra("trigger",ev.trigger);i.putExtra("confidence",ev.confidence);sendBroadcast(i);update("Review captured: "+shortName(ev.packageName));destroyProjection();}catch(Exception e){capturing=false;destroyProjection();}finally{if(image!=null)image.close();}}
    private String shortName(String p){int i=p.lastIndexOf('.');return i>0?p.substring(i+1):p;}
    private void emit(String action,String value){Intent i=new Intent(action);i.setPackage(getPackageName());i.putExtra("text",value);sendBroadcast(i);}
    private void stopMonitoring(){active=false;handler.removeCallbacks(poll);destroyProjection();stopForeground(true);stopSelf();emit(EVENT_STATE,"stopped");}
    private void destroyProjection(){try{if(display!=null)display.release();}catch(Exception ignored){}try{if(reader!=null)reader.close();}catch(Exception ignored){}try{if(projection!=null)projection.stop();}catch(Exception ignored){}display=null;reader=null;projection=null;capturing=false;}
    @Override public void onDestroy(){handler.removeCallbacks(poll);destroyProjection();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
    private void channel(){if(Build.VERSION.SDK_INT>=26)((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(new NotificationChannel("nori_exam","Nori Exam Integrity",NotificationManager.IMPORTANCE_LOW));}
    private Notification note(String s){Intent o=getPackageManager().getLaunchIntentForPackage(getPackageName());PendingIntent p=PendingIntent.getActivity(this,33,o,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);return new Notification.Builder(this,"nori_exam").setContentTitle("NORI EXAM INTEGRITY").setContentText(s).setSmallIcon(android.R.drawable.ic_menu_view).setContentIntent(p).setOngoing(true).build();}
    private void update(String s){((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTIFICATION_ID,note(s));}
}
