package com.nori.jarvis.nori.kage;

import java.util.*;

/** Native KAGE/Override boundary. Stage 5 ports core deterministic rules without deleting V32. */
public final class KageEngine {
    public enum FailureType { ACADEMIC_PROBLEM, DISCIPLINARY_BREACH, COMBINED_FAILURE }
    public enum OverrideOutcome { ACCEPT, PARTIAL_ACCEPT, REJECT, DEFER, RECLASSIFY }
    public static final Set<String> VALID_OVERRIDE_REASONS = Collections.unmodifiableSet(new HashSet<>(Arrays.asList(
        "false_detection","incorrect_data","technical_failure","emergency",
        "legitimate_academic_use","extraordinary_circumstance","assessment_error",
        "duplicate_event","system_misclassification","system_integrity_issue"
    )));

    public FailureType classifyFailure(boolean academicIssue, boolean disciplinaryIssue) {
        if (academicIssue && disciplinaryIssue) return FailureType.COMBINED_FAILURE;
        if (disciplinaryIssue) return FailureType.DISCIPLINARY_BREACH;
        return FailureType.ACADEMIC_PROBLEM;
    }

    public DegreeDecision determineDegree(int unresolvedDegree1, int sameDomainRepeat, int degree1Total,
                                          FailureType type, String contextType) {
        List<String> reasons = new ArrayList<>();
        if (unresolvedDegree1 >= 1) reasons.add("persistent_unresolved_degree1_failure");
        if (sameDomainRepeat >= 3) reasons.add("repeated_same_domain_breach");
        if ("sustained_deliberate_distraction".equals(contextType) && sameDomainRepeat >= 1)
            reasons.add("serious_single_event_with_prior_pattern");
        if (type == FailureType.COMBINED_FAILURE && degree1Total >= 2)
            reasons.add("combined_repeated_failure");
        if (reasons.isEmpty()) reasons.add("default_entry_no_degree2_condition_met");
        return new DegreeDecision(reasons.size() > 1 || !"default_entry_no_degree2_condition_met".equals(reasons.get(0)) ? 2 : 1, reasons);
    }

    public OverrideDecision evaluateOverride(String reason, List<String> evidence, String requestedScope,
                                             String originalConfidence, int recentOverrideCount) {
        boolean recognized = VALID_OVERRIDE_REASONS.contains(reason);
        boolean hasEvidence = evidence != null && !evidence.isEmpty();
        boolean review = recentOverrideCount >= 3;
        if (!recognized && !hasEvidence)
            return new OverrideDecision(OverrideOutcome.REJECT, null, "No recognized reason and no evidence.", review);
        if (recognized && hasEvidence && !"confirmed".equals(originalConfidence))
            return new OverrideDecision(OverrideOutcome.ACCEPT, requestedScope, "Recognized reason with evidence; original classification was not confirmed.", review);
        if (recognized && hasEvidence)
            return new OverrideDecision(OverrideOutcome.PARTIAL_ACCEPT, "consequence", "Valid reason present, but confirmed event; scope is narrowed rather than erased.", review);
        if (!hasEvidence)
            return new OverrideDecision(OverrideOutcome.DEFER, null, "Recognized reason but insufficient evidence.", review);
        return new OverrideDecision(OverrideOutcome.REJECT, null, "Override criteria not met.", review);
    }

    public static final class DegreeDecision {
        public final int degree; public final List<String> reasons;
        public DegreeDecision(int degree, List<String> reasons) { this.degree=degree; this.reasons=Collections.unmodifiableList(new ArrayList<>(reasons)); }
    }
    public static final class OverrideDecision {
        public final OverrideOutcome outcome; public final String scope; public final String reasoning; public final boolean classificationReview;
        public OverrideDecision(OverrideOutcome outcome,String scope,String reasoning,boolean review){this.outcome=outcome;this.scope=scope;this.reasoning=reasoning;this.classificationReview=review;}
    }
}
