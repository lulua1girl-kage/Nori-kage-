package com.nori.jarvis.nori.library;

import com.nori.jarvis.nori.data.DataRepository;
import java.util.*;

/** Fast student library index. Files remain at user-selected URIs; extracted text/chunks may be cached separately. */
public final class NoriLibraryIndex {
    public static final long MAX_LIBRARY_BYTES = 15L * 1024L * 1024L * 1024L;
    public enum Kind { PDF, DOC, DOCX, PPT, PPTX, XLS, XLSX, CSV, TSV, TXT, MD, HTML, XML, JSON, RTF, EPUB, ODT, ODS, ODP, IMAGE, AUDIO, VIDEO, ARCHIVE, SOURCE_CODE, OTHER }
    public enum Status { INDEXED, NEEDS_PROCESSING, PROCESSING, ERROR }
    public static final class Entry {
        public final String id, name, uri, subject, source;
        public final long sizeBytes, modifiedAt;
        public final Kind kind;
        public final Status status;
        public final int chunks;
        public Entry(String id,String name,String uri,long size,String subject,String source,long modified,Kind kind,Status status,int chunks){
            this.id=id;this.name=name;this.uri=uri;this.sizeBytes=size;this.subject=subject;this.source=source;this.modifiedAt=modified;this.kind=kind;this.status=status;this.chunks=chunks;
        }
    }
    private final DataRepository repo;
    private final LinkedHashMap<String,Entry> entries=new LinkedHashMap<>();
    private long logicalBytes=0;
    public NoriLibraryIndex(DataRepository r){repo=r;}
    public synchronized boolean add(Entry e){
        if(e==null||e.id==null||e.id.isEmpty())return false;
        Entry old=entries.get(e.id); long projected=logicalBytes-(old==null?0:old.sizeBytes)+Math.max(0,e.sizeBytes);
        if(projected>MAX_LIBRARY_BYTES)return false;
        if(old!=null) logicalBytes-=old.sizeBytes;
        entries.put(e.id,e); logicalBytes+=Math.max(0,e.sizeBytes);
        return true;
    }
    public synchronized Entry get(String id){return entries.get(id);}
    public synchronized boolean updateStatus(String id,Status status,int chunks){Entry e=entries.get(id);if(e==null)return false;entries.put(id,new Entry(e.id,e.name,e.uri,e.sizeBytes,e.subject,e.source,e.modifiedAt,e.kind,status,chunks));return true;}
    public synchronized List<Entry> recent(int limit){
        List<Entry> all=new ArrayList<>(entries.values());
        all.sort((a,b)->Long.compare(b.modifiedAt,a.modifiedAt));
        return Collections.unmodifiableList(new ArrayList<>(all.subList(0,Math.min(Math.max(1,limit),all.size()))));
    }
    public synchronized List<Entry> search(String q,int limit){
        String x=q==null?"":q.toLowerCase(Locale.ROOT); List<Entry> out=new ArrayList<>();
        for(Entry e:entries.values()) if(x.isEmpty()||e.name.toLowerCase(Locale.ROOT).contains(x)||e.subject.toLowerCase(Locale.ROOT).contains(x)||e.source.toLowerCase(Locale.ROOT).contains(x)) out.add(e);
        out.sort((a,b)->Long.compare(b.modifiedAt,a.modifiedAt)); return Collections.unmodifiableList(out.subList(0,Math.min(Math.max(1,limit),out.size())));
    }
    public synchronized long logicalBytes(){return logicalBytes;}
    public synchronized long remainingBytes(){return MAX_LIBRARY_BYTES-logicalBytes;}
    public synchronized int size(){return entries.size();}
    public synchronized void clear(){entries.clear();logicalBytes=0;}
}
