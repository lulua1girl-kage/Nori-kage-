package com.nori.jarvis;

import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.nori.jarvis.nori.admin.*;
import com.nori.jarvis.nori.admin.model.*;
import com.nori.jarvis.nori.identity.NoriSessionAuthority;
import java.util.*;

/** Admin-only bridge. Production role enforcement must also happen server-side. */
@CapacitorPlugin(name="NoriAdmin")
public final class NoriAdminPlugin extends Plugin {
    private final NoriAdminChangeControl changes=new NoriAdminChangeControl();
    private final NoriImprovementFeedbackEngine feedback=new NoriImprovementFeedbackEngine();
    private final NoriImprovementEmailPolicy emailPolicy=new NoriImprovementEmailPolicy();
    private final NoriSessionAuthority authority=NoriSessionAuthority.get();

    @PluginMethod public void role(PluginCall c){JSObject o=new JSObject();AdminRole role=authority.role();o.put("role",role.name());o.put("admin",authority.admin());c.resolve(o);}
    @PluginMethod public void feedback(PluginCall c){String uid=c.getString("userId","");String text=c.getString("text","");String k=c.getString("kind","QUALITY");NoriImprovementFeedbackEngine.Kind kind;try{kind=NoriImprovementFeedbackEngine.Kind.valueOf(k);}catch(Exception e){kind=NoriImprovementFeedbackEngine.Kind.QUALITY;}var f=feedback.submit(uid,text,kind);if(f==null){c.reject("Invalid feedback");return;}JSObject o=new JSObject();o.put("ok",true);o.put("id",f.id);c.resolve(o);}
    @PluginMethod public void proposeCodeChange(PluginCall c){AdminRole role=authority.role(); if(!authority.admin()){c.reject("Admin authorization required");return;} var x=changes.propose(c.getString("actor",authority.identity().userId()),role,c.getString("summary",""),c.getString("patch",""));if(x==null){c.reject("Admin authorization required");return;}JSObject o=new JSObject();o.put("id",x.id);o.put("status",x.status.name());o.put("patchHash",x.patchHash);c.resolve(o);}
    @PluginMethod public void adminPolicy(PluginCall c){JSObject o=new JSObject();o.put("codeEdit","OWNER/ADMIN only; production mutation requires tests and explicit release");o.put("studentsCanEditCode",false);o.put("feedbackAutoDeploy",false);o.put("emailPolicy",emailPolicy.rule());c.resolve(o);}
}
