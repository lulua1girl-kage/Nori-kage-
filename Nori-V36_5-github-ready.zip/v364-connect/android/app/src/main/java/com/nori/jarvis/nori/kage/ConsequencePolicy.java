package com.nori.jarvis.nori.kage;

import java.util.*;

/** Fixed consequence selection policy. It chooses from migrated IDs; it never invents consequences. */
public final class ConsequencePolicy {
    private final Map<String,Integer> severity = new HashMap<>();
    public ConsequencePolicy() {
        // IDs are references to the existing V32 consequence catalog; values are its severity ceiling data.
        severity.put("protected_hour_gaming_lock",1); severity.put("curiosity_reserve",1);
        severity.put("research_queue",1); severity.put("hobby_scheduling_restriction",1);
        severity.put("project_queue",1); severity.put("plan_freeze",2);
        severity.put("academic_purpose_only_research",2); severity.put("optional_hobby_suspension",2);
        severity.put("online_game_restriction",2); severity.put("gaming_suspension_full",4);
    }
    public int ceilingFor(String band, int degree) {
        if (degree != 1) return 4;
        if (band == null) return 1;
        switch (band) { case "D1-A": return 1; case "D1-B": case "D1-C": return 2; case "D1-D": case "D1-E": return 3; default: return 1; }
    }
    public List<String> selectCandidates(Collection<String> ids, String band, int degree, Collection<String> ineffective) {
        int ceiling=ceilingFor(band,degree); Set<String> skip=new HashSet<>(ineffective==null?Collections.emptyList():ineffective);
        List<String> out=new ArrayList<>(); for(String id:ids) if(severity.getOrDefault(id,99)<=ceiling&&!skip.contains(id)) out.add(id);
        out.sort(Comparator.comparingInt(id->severity.getOrDefault(id,99))); return out;
    }
}
