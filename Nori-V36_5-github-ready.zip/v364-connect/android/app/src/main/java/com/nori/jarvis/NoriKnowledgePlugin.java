package com.nori.jarvis;

import android.content.*;
import android.net.Uri;
import android.provider.OpenableColumns;
import com.getcapacitor.*;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.nori.jarvis.nori.NoriNativeCore;
import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.library.NoriLibraryIndex;
import com.nori.jarvis.nori.library.NoriFileIntelligence;
import com.nori.jarvis.nori.cloud.NoriCloudStorageRouter;
import com.nori.jarvis.nori.identity.NoriUserIdentity;
import com.nori.jarvis.nori.knowledge.NoriSourcePrioritizer;
import com.nori.jarvis.nori.knowledge.NoriKnowledgeSourceRegistry;
import com.nori.jarvis.nori.knowledge.NoriContradictionResolver;
import com.nori.jarvis.nori.youtube.NoriYouTubeLearningConnector;
import com.nori.jarvis.nori.android.files.NoriPdfFastExtractor;
import java.util.*;

/** Student knowledge hub: WPS handoff, SAF imports, fast library index, source registry and public YouTube discovery. */
@CapacitorPlugin(name="NoriKnowledge")
public final class NoriKnowledgePlugin extends Plugin {
    private static final int PICK_FILE=4511, PICK_TREE=4512;
    private NoriBrain brain; private NoriLibraryIndex library;
    private final NoriKnowledgeSourceRegistry sources=new NoriKnowledgeSourceRegistry();
    private final NoriContradictionResolver contradictions=new NoriContradictionResolver();
    private NoriYouTubeLearningConnector youtube; private NoriPdfFastExtractor pdfExtractor;
    private final NoriSessionAuthority authority=NoriSessionAuthority.get();
    private NoriUserIdentity activeUser=new NoriUserIdentity("","","","","",0);
    private final NoriSourcePrioritizer sourcePrioritizer=new NoriSourcePrioritizer();
    @Override public void load(){brain=new NoriNativeCore().getBrain(); library=brain.getLibraryIndex(); youtube=new NoriYouTubeLearningConnector(brain.getLiveWebRetrieval()); pdfExtractor=new NoriPdfFastExtractor(getContext());}

    @PluginMethod public void openWps(PluginCall call){ if(!requireApproved(call))return;
        Intent i=getContext().getPackageManager().getLaunchIntentForPackage("cn.wps.moffice_eng");
        if(i==null)i=getContext().getPackageManager().getLaunchIntentForPackage("cn.wps.moffice");
        if(i==null){call.reject("WPS Office is not installed or its Android package is unavailable.");return;}
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);getContext().startActivity(i);call.resolve();
    }
    @PluginMethod public void pickDocuments(PluginCall call){ if(!requireApproved(call))return;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(call,i,"pickDocumentsResult");
    }
    @ActivityCallback public void pickDocumentsResult(PluginCall call,ActivityResult result){
        if(result==null||result.getResultCode()!=android.app.Activity.RESULT_OK||result.getData()==null){call.reject("No document selected");return;}
        Intent data=result.getData();ClipData cd=data.getClipData();int count=0;if(cd!=null){for(int i=0;i<cd.getItemCount();i++){indexUri(cd.getItemAt(i).getUri());count++;}}else if(data.getData()!=null){indexUri(data.getData());count++;}
        JSObject o=new JSObject();o.put("ok",true);o.put("indexed",count);call.resolve(o);
    }
    @PluginMethod public void pickLibraryFolder(PluginCall call){ if(!requireApproved(call))return;
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);startActivityForResult(call,i,"pickLibraryFolderResult");
    }
    @ActivityCallback public void pickLibraryFolderResult(PluginCall call,ActivityResult result){
        if(result==null||result.getResultCode()!=android.app.Activity.RESULT_OK||result.getData()==null){call.reject("Library folder selection canceled");return;}
        Uri u=result.getData().getData();try{getContext().getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
        JSObject o=new JSObject();o.put("ok",true);o.put("uri",u.toString());o.put("logicalLimitBytes",NoriLibraryIndex.MAX_LIBRARY_BYTES);call.resolve(o);
    }
    @PluginMethod public void librarySummary(PluginCall call){ if(!requireApproved(call))return;
        JSObject o=new JSObject();o.put("maxBytes",NoriLibraryIndex.MAX_LIBRARY_BYTES);o.put("usedBytes",library.logicalBytes());o.put("remainingBytes",library.remainingBytes());o.put("items",library.size());
        JSArray recent=new JSArray();for(NoriLibraryIndex.Entry e:library.recent(20)){JSObject x=new JSObject();x.put("id",e.id);x.put("name",e.name);x.put("subject",e.subject);x.put("source",e.source);x.put("sizeBytes",e.sizeBytes);x.put("modifiedAt",e.modifiedAt);x.put("status",e.status.name());recent.put(x);}o.put("recent",recent);call.resolve(o);
    }
    @PluginMethod public void searchLibrary(PluginCall call){ if(!requireApproved(call))return;String q=call.getString("query","");JSArray a=new JSArray();for(NoriLibraryIndex.Entry e:library.search(q,30)){JSObject x=new JSObject();x.put("id",e.id);x.put("name",e.name);x.put("subject",e.subject);x.put("uri",e.uri);x.put("status",e.status.name());a.put(x);}JSObject o=new JSObject();o.put("items",a);call.resolve(o);}
    @PluginMethod public void youtubeSearch(PluginCall call){ if(!requireApproved(call))return;JSObject o=new JSObject();o.put("endpoint",youtube.searchEndpoint(call.getString("query","")));o.put("policy",youtube.explainPolicy());o.put("requiresApiKey",true);call.resolve(o);}
    @PluginMethod public void learningSources(PluginCall call){JSArray a=new JSArray();for(NoriKnowledgeSourceRegistry.Source s:sources.all()){JSObject x=new JSObject();x.put("id",s.id);x.put("name",s.name);x.put("url",s.url);x.put("coverage",s.coverage);x.put("trustWeight",s.trustWeight);a.put(x);}JSObject o=new JSObject();o.put("sources",a);call.resolve(o);}

    @PluginMethod public void setActiveUser(PluginCall call){ if(!requireApproved(call))return;activeUser=authority.identity();JSObject o=new JSObject();o.put("ok",true);o.put("scope",activeUser.scope());o.put("displayName",activeUser.displayName());call.resolve(o);}
    @PluginMethod public void activeUser(PluginCall call){ if(!requireApproved(call))return;JSObject o=new JSObject();o.put("userId",activeUser.userId());o.put("displayName",activeUser.displayName());o.put("scope",activeUser.scope());o.put("libraryScope",activeUser.libraryScope());call.resolve(o);}
    @PluginMethod public void fileRoute(PluginCall call){String name=call.getString("name","");String mime=call.getString("mime","");NoriFileIntelligence.Route r=new NoriFileIntelligence().route(name,mime);JSObject o=new JSObject();o.put("format",r.format.name());o.put("fastPath",r.fastPath);JSArray a=new JSArray();for(NoriFileIntelligence.Work w:r.work)a.put(w.name());o.put("work",a);call.resolve(o);}
    @PluginMethod public void sourcePriorityPolicy(PluginCall call){JSObject o=new JSObject();o.put("policy",sourcePrioritizer.policy());o.put("rule","Popularity is not evidence. Official/primary/peer-reviewed and corroborated sources receive stronger default priority; videos and community posts are treated as leads unless supported.");call.resolve(o);}
    @PluginMethod public void cloudLibraryPlan(PluginCall call){ if(!requireApproved(call))return;NoriCloudStorageRouter r=new NoriCloudStorageRouter(activeUser);NoriCloudStorageRouter.Backend b=NoriCloudStorageRouter.Backend.SUPABASE_TUS;String pref=call.getString("backend","").toLowerCase(Locale.ROOT);if(pref.contains("firebase"))b=NoriCloudStorageRouter.Backend.FIREBASE_RESUMABLE;else if(pref.contains("document"))b=NoriCloudStorageRouter.Backend.DOCUMENT_PROVIDER;NoriCloudStorageRouter.UploadPlan p=r.plan(b,call.getString("fileId","unknown"));JSObject o=new JSObject();o.put("backend",p.backend.name());o.put("objectKey",p.objectKey);o.put("resumable",p.resumable);o.put("localCopyRequired",p.localCopyRequired);o.put("reason",p.reason);call.resolve(o);}
    @PluginMethod public void contradictionPolicy(PluginCall call){ if(!requireApproved(call))return;JSObject o=new JSObject();o.put("question",contradictions.compare(Collections.emptyList()).question);o.put("rule","Nori does not silently choose between conflicting course materials, uploaded documents, teachers or internet sources.");call.resolve(o);}

    private boolean requireApproved(PluginCall call){ if(!authority.approved()){call.reject("Approved Nori sign-in required");return false;} activeUser=authority.identity(); return true; }

    private void indexUri(Uri u){if(u==null)return;String name="document";long size=0,modified=System.currentTimeMillis();try(CursorHolder h=new CursorHolder(u)){if(h.name!=null)name=h.name;size=h.size;modified=h.modified;}catch(Exception ignored){}
        String id=Integer.toHexString((u.toString()+":"+size+":"+modified).hashCode());NoriLibraryIndex.Kind kind=NoriLibraryIndex.Kind.PDF;String mime=getContext().getContentResolver().getType(u);if(mime!=null&&!mime.contains("pdf"))kind=NoriLibraryIndex.Kind.OTHER;
        library.add(new NoriLibraryIndex.Entry(id,name,u.toString(),size,guessSubject(name),"WPS/Android import",modified,kind,NoriLibraryIndex.Status.NEEDS_PROCESSING,0));
        new Thread(()->fastIndex(id,u),"nori-doc-index").start();
    }
    private void fastIndex(String id,Uri u){
        try{String mime=getContext().getContentResolver().getType(u);if(mime!=null&&mime.contains("pdf")){String text=pdfExtractor.extract(u,80);var d=brain.getDocumentIntelligence().ingest(library.get(id).name,mime,u.toString(),text);library.updateStatus(id,NoriLibraryIndex.Status.INDEXED,brain.getDocumentIntelligence().chunks(d.id).size());}else library.updateStatus(id,NoriLibraryIndex.Status.INDEXED,0);}catch(Exception e){library.updateStatus(id,NoriLibraryIndex.Status.ERROR,0);}
    }
    private NoriLibraryIndex.Kind mapKind(NoriFileIntelligence.Format f){switch(f){case PDF:return NoriLibraryIndex.Kind.PDF;case DOC:return NoriLibraryIndex.Kind.DOC;case DOCX:return NoriLibraryIndex.Kind.DOCX;case PPT:return NoriLibraryIndex.Kind.PPT;case PPTX:return NoriLibraryIndex.Kind.PPTX;case XLS:return NoriLibraryIndex.Kind.XLS;case XLSX:return NoriLibraryIndex.Kind.XLSX;case CSV:return NoriLibraryIndex.Kind.CSV;case TSV:return NoriLibraryIndex.Kind.TSV;case TXT:return NoriLibraryIndex.Kind.TXT;case MD:return NoriLibraryIndex.Kind.MD;case HTML:return NoriLibraryIndex.Kind.HTML;case XML:return NoriLibraryIndex.Kind.XML;case JSON:return NoriLibraryIndex.Kind.JSON;case RTF:return NoriLibraryIndex.Kind.RTF;case EPUB:return NoriLibraryIndex.Kind.EPUB;case ODT:return NoriLibraryIndex.Kind.ODT;case ODS:return NoriLibraryIndex.Kind.ODS;case ODP:return NoriLibraryIndex.Kind.ODP;case IMAGE:return NoriLibraryIndex.Kind.IMAGE;case AUDIO:return NoriLibraryIndex.Kind.AUDIO;case VIDEO:return NoriLibraryIndex.Kind.VIDEO;case ARCHIVE:return NoriLibraryIndex.Kind.ARCHIVE;case SOURCE_CODE:return NoriLibraryIndex.Kind.SOURCE_CODE;default:return NoriLibraryIndex.Kind.OTHER;}}
    private String guessSubject(String n){String x=n.toLowerCase(Locale.ROOT);String[] ss={"math","chem","physics","biology","english","agri","history","geography","econom","business","programming","software","web","mining"};for(String s:ss)if(x.contains(s))return s;return "unspecified";}
    private final class CursorHolder implements AutoCloseable{android.database.Cursor c;String name;long size,modified;CursorHolder(Uri u){c=getContext().getContentResolver().query(u,null,null,null,null);if(c!=null&&c.moveToFirst()){int n=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);int z=c.getColumnIndex(OpenableColumns.SIZE);int m=c.getColumnIndex(android.provider.DocumentsContract.Document.COLUMN_LAST_MODIFIED);if(n>=0)name=c.getString(n);if(z>=0&&!c.isNull(z))size=c.getLong(z);if(m>=0&&!c.isNull(m))modified=c.getLong(m);}}public void close(){if(c!=null)c.close();}}
}
