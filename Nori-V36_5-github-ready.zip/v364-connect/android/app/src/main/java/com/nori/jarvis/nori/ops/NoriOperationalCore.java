package com.nori.jarvis.nori.ops;

import com.nori.jarvis.nori.data.DataRepository;
import java.time.Instant;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Local-first operational layer. Turns Nori's planning concepts into durable,
 * verifiable operations without replacing the existing Brain or ActionEngine.
 * Storage uses a versioned line format inside DataRepository so no JSON library is required.
 */
public final class NoriOperationalCore {
    public enum CapabilityStatus { WORKING_LOCAL, WORKING_WITH_INTERNET, REQUIRES_PERMISSION, REQUIRES_CONFIRMATION, PARTIAL, UNAVAILABLE }
    public enum ItemType { TASK, ASSIGNMENT, EXAM, CHECKPOINT, NOTE, CHECKIN, EVENT }
    public enum Priority { CRITICAL, HIGH, NORMAL, LOW }
    public enum PlanState { ACTIVE, PAUSED, COMPLETED, RECOVERED }
    public enum RecoveryKind { NO_CHANGE, REDUCE_SCOPE, RESCHEDULE, SPLIT, DROP_LOW_PRIORITY, RESTORE_BACKUP }

    public static final class CapabilityTruth {
        public final String id, label; public final CapabilityStatus status; public final String reason;
        CapabilityTruth(String i,String l,CapabilityStatus s,String r){id=i;label=l;status=s;reason=r;}
    }
    public static final class Record {
        public final String id,type,title,subject,dueAt,priority,status,createdAt,updatedAt,details;
        Record(String i,String t,String ti,String s,String d,String p,String st,String c,String u,String de){id=i;type=t;title=ti;subject=s;dueAt=d;priority=p;status=st;createdAt=c;updatedAt=u;details=de;}
    }
    public static final class CheckIn {
        public final String id,capacity,day,activity,notes,createdAt;
        CheckIn(String i,String c,String d,String a,String n,String at){id=i;capacity=c;day=d;activity=a;notes=n;createdAt=at;}
    }
    public static final class Verification {
        public final boolean ok; public final String operation,detail;
        Verification(boolean o,String op,String d){ok=o;operation=op;detail=d;}
    }
    public static final class Plan {
        public final String id; public final List<Record> steps; public final PlanState state;
        Plan(String i,List<Record>s,PlanState st){id=i;steps=Collections.unmodifiableList(new ArrayList<>(s));state=st;}
    }

    private static final String PREFIX="nori.ops.v1.";
    private static final String RECORDS=PREFIX+"records";
    private static final String CHECKINS=PREFIX+"checkins";
    private static final String TIMELINE=PREFIX+"timeline";
    private static final int MAX=600;
    private final DataRepository repo;

    public NoriOperationalCore(DataRepository repository){this.repo=repository;}

    public List<CapabilityTruth> capabilityTruths(){
        List<CapabilityTruth> x=new ArrayList<>();
        add(x,"tasks","Tasks",CapabilityStatus.WORKING_LOCAL,"Create, update, complete and recover local tasks.");
        add(x,"assignments","Assignments",CapabilityStatus.WORKING_LOCAL,"Persist assignment title, subject, deadline and status.");
        add(x,"exams","Exams",CapabilityStatus.WORKING_LOCAL,"Persist exams and build local countdown-ready records.");
        add(x,"adaptive_planning","Adaptive planning",CapabilityStatus.WORKING_LOCAL,"Replans local records around deadlines and capacity.");
        add(x,"study_execution","Study execution",CapabilityStatus.WORKING_LOCAL,"Creates concrete study checkpoints from a goal.");
        add(x,"knowledge_vault","Knowledge vault",CapabilityStatus.WORKING_LOCAL,"Indexes user-provided local references by metadata; content parsing remains document-engine dependent.");
        add(x,"daily_checkin","Daily check-in",CapabilityStatus.WORKING_LOCAL,"Stores explicit capacity/activity check-ins.");
        add(x,"universal_search","Universal search",CapabilityStatus.WORKING_LOCAL,"Searches Nori's local operational records.");
        add(x,"recovery","Recovery",CapabilityStatus.WORKING_LOCAL,"Detects overdue items and creates a bounded recovery plan.");
        add(x,"offline_core","Offline core",CapabilityStatus.WORKING_LOCAL,"Core planning and records remain local-first.");
        add(x,"timeline","Activity timeline",CapabilityStatus.WORKING_LOCAL,"Records transparent Nori operational events.");
        add(x,"why","Why explanations",CapabilityStatus.WORKING_LOCAL,"Explains operational recommendations from explicit signals.");
        add(x,"confusion_help","Confusion help",CapabilityStatus.WORKING_LOCAL,"Maps plain-language goals to app capabilities.");
        add(x,"export","Data export",CapabilityStatus.WORKING_LOCAL,"Exports a portable operational snapshot.");
        add(x,"live_world","Live world",CapabilityStatus.WORKING_WITH_INTERNET,"News/weather/trends/web require network retrieval.");
        add(x,"chrome_handoff","Chrome handoff",CapabilityStatus.REQUIRES_PERMISSION,"Opening another app is device/OS dependent and remains explicit.");
        return Collections.unmodifiableList(x);
    }
    private void add(List<CapabilityTruth>x,String i,String l,CapabilityStatus s,String r){x.add(new CapabilityTruth(i,l,s,r));}

    public synchronized Record upsert(ItemType type,String title,String subject,String dueAt,Priority priority,String details){
        String id="rec_"+UUID.randomUUID(); String now=Instant.now().toString();
        Record r=new Record(id,type.name(),clean(title),clean(subject),clean(dueAt),priority.name(),"OPEN",now,now,clean(details));
        List<Record> all=records(); all.add(r); saveRecords(all); event("CREATE",id,type.name()+":"+r.title); return r;
    }
    public synchronized Verification setStatus(String id,String status){
        List<Record> all=records(); for(int i=0;i<all.size();i++){Record r=all.get(i);if(r.id.equals(id)){Record n=new Record(r.id,r.type,r.title,r.subject,r.dueAt,r.priority,clean(status),r.createdAt,Instant.now().toString(),r.details);all.set(i,n);saveRecords(all);event("STATUS",id,n.status);return new Verification(true,"status_update","status="+n.status);}}
        return new Verification(false,"status_update","record_not_found");
    }
    public synchronized List<Record> records(){return parseRecords(repo==null?null:repo.getJson(RECORDS));}
    public synchronized List<Record> openRecords(){List<Record>o=new ArrayList<>();for(Record r:records())if(!"DONE".equals(r.status)&&!"CANCELLED".equals(r.status))o.add(r);return Collections.unmodifiableList(o);}

    public synchronized CheckIn checkIn(String capacity,String activity,String notes){
        String now=Instant.now().toString(); CheckIn c=new CheckIn("chk_"+UUID.randomUUID(),clean(capacity),now.substring(0,10),clean(activity),clean(notes),now);
        List<CheckIn> a=checkins();a.add(c);while(a.size()>120)a.remove(0);saveCheckins(a);event("CHECKIN",c.id,c.capacity+"|"+c.activity);return c;
    }
    public synchronized List<CheckIn> checkins(){return parseCheckins(repo==null?null:repo.getJson(CHECKINS));}

    public synchronized Plan buildAdaptivePlan(String goal,int maxSteps,String capacity){
        int limit=Math.max(1,Math.min(8,maxSteps)); List<Record> open=openRecords();
        List<Record> candidates=new ArrayList<>();
        for(Record r:open)if(!"DONE".equals(r.status))candidates.add(r);
        candidates.sort((a,b)->Integer.compare(priorityRank(b.priority),priorityRank(a.priority)));
        if("LOW".equalsIgnoreCase(capacity)||"LIMITED".equalsIgnoreCase(capacity)) limit=Math.min(limit,3);
        List<Record> chosen=candidates.subList(0,Math.min(limit,candidates.size()));
        event("PLAN",goal,"steps="+chosen.size()+";capacity="+capacity);
        return new Plan("plan_"+UUID.randomUUID(),chosen,PlanState.ACTIVE);
    }

    public synchronized Plan recover(){
        List<Record> overdue=new ArrayList<>(); String today=Instant.now().toString().substring(0,10);
        for(Record r:openRecords())if(!r.dueAt.isEmpty()&&r.dueAt.compareTo(today)<0)overdue.add(r);
        overdue.sort((a,b)->Integer.compare(priorityRank(b.priority),priorityRank(a.priority)));
        event("RECOVERY","overdue","count="+overdue.size());
        return new Plan("recovery_"+UUID.randomUUID(),overdue,overdue.isEmpty()?PlanState.COMPLETED:PlanState.RECOVERED);
    }

    public synchronized List<Record> search(String q){
        String query=clean(q).toLowerCase(Locale.ROOT); if(query.isEmpty())return Collections.unmodifiableList(records());
        List<Record>o=new ArrayList<>();for(Record r:records()){String hay=(r.type+" "+r.title+" "+r.subject+" "+r.details).toLowerCase(Locale.ROOT);if(hay.contains(query))o.add(r);}return Collections.unmodifiableList(o);
    }

    public synchronized String why(String recommendation){
        String q=clean(recommendation); List<Record> overdue=new ArrayList<>();String today=Instant.now().toString().substring(0,10);
        for(Record r:openRecords())if(!r.dueAt.isEmpty()&&r.dueAt.compareTo(today)<0)overdue.add(r);
        CheckIn latest=checkins().isEmpty()?null:checkins().get(checkins().size()-1);
        String capacity=latest==null?"unknown":latest.capacity;
        return "Recommendation: "+q+". Signals: openItems="+openRecords().size()+", overdue="+overdue.size()+", latestCapacity="+capacity+". This is an operational explanation, not a claim about your motives or mental state.";
    }

    public synchronized String exportSnapshot(){
        StringBuilder b=new StringBuilder();b.append("NORI_EXPORT_V1\n");b.append("generatedAt=").append(Instant.now()).append("\n");
        b.append("records=\n");for(Record r:records())b.append(encode(recordLine(r))).append("\n");
        b.append("checkins=\n");for(CheckIn c:checkins())b.append(encode(checkinLine(c))).append("\n");
        b.append("timeline=\n");String t=repo==null?null:repo.getJson(TIMELINE);if(t!=null)b.append(t);
        return b.toString();
    }
    public synchronized Verification restoreSnapshot(String snapshot){
        if(snapshot==null||!snapshot.startsWith("NORI_EXPORT_V1\n"))return new Verification(false,"restore","invalid_export");
        String[] lines=snapshot.split("\\n",-1);List<Record> rs=new ArrayList<>();List<CheckIn> cs=new ArrayList<>();String section="";
        try{for(String line:lines){if(line.equals("records=")){section="records";continue;}if(line.equals("checkins=")){section="checkins";continue;}if(line.equals("timeline=")){section="timeline";continue;}if(line.isEmpty()||line.startsWith("NORI_")||line.startsWith("generatedAt="))continue;String decoded=decode(line);if("records".equals(section))rs.add(parseRecord(decoded));else if("checkins".equals(section))cs.add(parseCheckin(decoded));}
            saveRecords(rs);saveCheckins(cs);event("RESTORE","snapshot","records="+rs.size()+";checkins="+cs.size());return new Verification(true,"restore","restored");
        }catch(Exception e){return new Verification(false,"restore","invalid_record:"+e.getMessage());}
    }
    public synchronized List<String> timeline(){String s=repo==null?null:repo.getJson(TIMELINE);if(s==null||s.isEmpty())return Collections.emptyList();return Collections.unmodifiableList(Arrays.asList(s.split("\\n")));}

    private void saveRecords(List<Record>a){if(repo!=null)repo.putJson(RECORDS,joinRecords(a),"operations",1);}
    private void saveCheckins(List<CheckIn>a){if(repo!=null)repo.putJson(CHECKINS,joinCheckins(a),"operations",1);}
    private void event(String type,String id,String detail){if(repo==null)return;String old=repo.getJson(TIMELINE);List<String>a=new ArrayList<>();if(old!=null&&!old.isEmpty())a.addAll(Arrays.asList(old.split("\\n")));a.add(Instant.now()+"|"+clean(type)+"|"+clean(id)+"|"+clean(detail));while(a.size()>MAX)a.remove(0);repo.putJson(TIMELINE,String.join("\n",a),"operations",1);}
    private static String joinRecords(List<Record>a){StringBuilder b=new StringBuilder();for(Record r:a){if(b.length()>0)b.append("\n");b.append(recordLine(r));}return b.toString();}
    private static String joinCheckins(List<CheckIn>a){StringBuilder b=new StringBuilder();for(CheckIn c:a){if(b.length()>0)b.append("\n");b.append(checkinLine(c));}return b.toString();}
    private static String recordLine(Record r){return String.join("|",enc(r.id),enc(r.type),enc(r.title),enc(r.subject),enc(r.dueAt),enc(r.priority),enc(r.status),enc(r.createdAt),enc(r.updatedAt),enc(r.details));}
    private static String checkinLine(CheckIn c){return String.join("|",enc(c.id),enc(c.capacity),enc(c.day),enc(c.activity),enc(c.notes),enc(c.createdAt));}
    private static Record parseRecord(String s){String[]p=s.split("\\|",-1);if(p.length<10)throw new IllegalArgumentException("record_fields");return new Record(dec(p[0]),dec(p[1]),dec(p[2]),dec(p[3]),dec(p[4]),dec(p[5]),dec(p[6]),dec(p[7]),dec(p[8]),dec(p[9]));}
    private static CheckIn parseCheckin(String s){String[]p=s.split("\\|",-1);if(p.length<6)throw new IllegalArgumentException("checkin_fields");return new CheckIn(dec(p[0]),dec(p[1]),dec(p[2]),dec(p[3]),dec(p[4]),dec(p[5]));}
    private static List<Record> parseRecords(String s){if(s==null||s.isEmpty())return new ArrayList<>();List<Record>a=new ArrayList<>();for(String l:s.split("\\n"))try{a.add(parseRecord(l));}catch(Exception ignored){}return a;}
    private static List<CheckIn> parseCheckins(String s){if(s==null||s.isEmpty())return new ArrayList<>();List<CheckIn>a=new ArrayList<>();for(String l:s.split("\\n"))try{a.add(parseCheckin(l));}catch(Exception ignored){}return a;}
    private static int priorityRank(String p){if("CRITICAL".equals(p))return 4;if("HIGH".equals(p))return 3;if("NORMAL".equals(p))return 2;return 1;}
    private static String clean(String s){return s==null?"":s.replace("|","/").replace("\n"," ").trim();}
    private static String enc(String s){return Base64.getEncoder().encodeToString(clean(s).getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    private static String dec(String s){return new String(Base64.getDecoder().decode(s),java.nio.charset.StandardCharsets.UTF_8);}
    private static String encode(String s){return Base64.getEncoder().encodeToString(s.getBytes(java.nio.charset.StandardCharsets.UTF_8));}
    private static String decode(String s){return new String(Base64.getDecoder().decode(s),java.nio.charset.StandardCharsets.UTF_8);}
}
