package com.nori.jarvis.nori.meta;

import com.nori.jarvis.nori.brain.NoriBrain;
import com.nori.jarvis.nori.brain.cognition.NoriCognitiveEngine;
import com.nori.jarvis.nori.memory.context.NoriMemoryContext;
import com.nori.jarvis.nori.state.NoriState;
import com.nori.jarvis.nori.understanding.NoriAppUnderstandingEngine;
import com.nori.jarvis.nori.edgeai.NoriEdgeAiEngine;
import com.nori.jarvis.nori.edgeai.NoriOnDeviceTask;
import com.nori.jarvis.nori.constitution.NoriConstitution;
import java.util.*;
import com.nori.jarvis.nori.world.NoriPersonalWorldModel;
import com.nori.jarvis.nori.evolution.NoriCausalCounterfactualEngine;
import com.nori.jarvis.nori.learning.NoriAdvancedLearningEngine;
import com.nori.jarvis.nori.research.NoriResearchBrain2;
import com.nori.jarvis.nori.brain.human.NoriHumanContext2;
import com.nori.jarvis.nori.execution.NoriExecutionLifecycle;
import com.nori.jarvis.nori.evolution.NoriFailureRecoveryEngine;

/**
 * Step 35: real Meta-Brain orchestration.
 *
 * Unlike a catalog, this class invokes the existing Nori Brain subsystems in a
 * bounded, deterministic pipeline and returns an auditable execution plan.
 * It does not expose chain-of-thought and never executes side effects itself.
 */
public final class NoriMetaBrainOrchestrator {
    public enum Status { READY, REVIEW, BLOCKED, UNAVAILABLE }
    public static final class CapabilityResult {
        public final NoriMetaBrainEngine.Capability capability;
        public final Status status;
        public final String evidence;
        CapabilityResult(NoriMetaBrainEngine.Capability c, Status s, String e){capability=c;status=s;evidence=e==null?"":e;}
    }
    public static final class Cycle {
        public final String request;
        public final NoriState state;
        public final NoriMemoryContext memory;
        public final NoriCognitiveEngine.ThoughtState cognition;
        public final NoriMetaBrainEngine.ThoughtPlan metaPlan;
        public final NoriConstitutionView constitution;
        public final List<CapabilityResult> capabilities;
        public final String answerStrategy;
        public final boolean requiresUserControl;
        public final boolean requiresFreshEvidence;
        public final NoriPersonalWorldModel.Snapshot world;
        public final NoriHumanContext2.Plan humanPlan;
        public final NoriResearchBrain2.Report researchPlan;
        public final NoriCausalCounterfactualEngine.Assessment causalAssessment;
        public final List<String> integrationTrace;
        Cycle(String r,NoriState s,NoriMemoryContext m,NoriCognitiveEngine.ThoughtState c,
              NoriMetaBrainEngine.ThoughtPlan p,NoriConstitutionView cv,List<CapabilityResult> caps,
              String strategy,boolean control,boolean fresh,NoriPersonalWorldModel.Snapshot w,NoriHumanContext2.Plan hp,
              NoriResearchBrain2.Report rp,NoriCausalCounterfactualEngine.Assessment ca,List<String> trace){request=r;state=s;memory=m;cognition=c;metaPlan=p;constitution=cv;
              capabilities=Collections.unmodifiableList(new ArrayList<>(caps));answerStrategy=strategy;
              requiresUserControl=control;requiresFreshEvidence=fresh;world=w;humanPlan=hp;researchPlan=rp;causalAssessment=ca;
              integrationTrace=Collections.unmodifiableList(new ArrayList<>(trace));}
    }
    public static final class NoriConstitutionView {
        public final String verdict; public final String instruction;
        NoriConstitutionView(String v,String i){verdict=v;instruction=i;}
    }

    private final NoriBrain brain;
    public NoriMetaBrainOrchestrator(NoriBrain b){brain=Objects.requireNonNull(b,"brain");}

    /** One bounded pass through the integrated Nori Brain. */
    public synchronized Cycle process(String request,String context,boolean externalAvailable,boolean userInitiated,
                                       boolean freshRequested,NoriMetaBrainEngine.Capacity capacity){
        String q=request==null?"":request.trim();
        NoriState state=brain.getCurrentState();
        NoriMemoryContext memory=brain.buildMemoryContext(q,6);
        String memorySummary="relevant="+memory.memories.size()+" conflict="+memory.conflictDetected+" stale="+memory.staleRisk;
        NoriCognitiveEngine.ThoughtState cognition=brain.think(q,memorySummary,externalAvailable,userInitiated);
        NoriMetaBrainEngine.ThoughtPlan meta=brain.thinkMeta(q,context,externalAvailable,userInitiated,freshRequested,capacity);
        NoriConstitution.Decision cd=brain.getConstitution().evaluate("request",q,null,userInitiated,false);
        List<CapabilityResult> out=new ArrayList<>();
        List<String> trace=new ArrayList<>();
        trace.add("STATE:unified_state_loaded"); trace.add("MEMORY:governed_context_loaded"); trace.add("COGNITION:thought_preflight_complete");
        trace.add("META:30_capabilities_evaluated"); trace.add("CONSTITUTION:"+cd.verdict.name());
        // Step 36: persist only meaningful, user-relevant world facts; no raw surveillance stream.
        if(cognition.intent==NoriCognitiveEngine.Intent.PLAN||cognition.intent==NoriCognitiveEngine.Intent.LEARN||cognition.intent==NoriCognitiveEngine.Intent.ACT){
            brain.getPersonalWorldModel().observe("current_request", "intent", cognition.intent.name(), "user_request", NoriPersonalWorldModel.Kind.CONTEXT, .85);
        }
        NoriPersonalWorldModel.Snapshot world=brain.getPersonalWorldModel().snapshot();
        trace.add("WORLD_MODEL:sequence="+world.sequence);
        // Step 41: record explicit/contextual human-capacity interpretation without diagnosis.
        NoriHumanContext2.Plan humanPlan;
        var humanAssessment=brain.getHumanContextEngine().assess(q,0,0,false);
        brain.getHumanContext2().record(humanAssessment); humanPlan=brain.getHumanContext2().assess();
        trace.add("HUMAN_CONTEXT:support="+humanPlan.support.name());
        // Step 37: causal output stays hypothesis-level unless evidence exists.
        NoriCausalCounterfactualEngine.Assessment causal=brain.getCausalCounterfactualEngine().assess(q,"unknown",Collections.emptyList());
        trace.add("CAUSAL:"+causal.strength.name());
        // Step 40: plan research depth before retrieval; retrieval itself remains provider/web-owned.
        NoriResearchBrain2.Report research=brain.getResearchBrain2().synthesize(q,Collections.emptyList());
        trace.add("RESEARCH:depth="+research.depth.name()+" target="+research.targetSources);
        if(cognition.needsTool) trace.add("EXECUTION:prepare-authorize-verify lifecycle required");
        else trace.add("EXECUTION:no_side_effect_requested");
        trace.add("RECOVERY:bounded_failure_route_available"); trace.add("LEARNING:outcome_loop_ready"); trace.add("VERIFY:result_verification_required="+cognition.needsVerification);
        for(NoriMetaBrainEngine.Capability c:NoriMetaBrainEngine.Capability.values()) out.add(evaluate(c,q,state,cognition,meta,externalAvailable,userInitiated));
        boolean control=userInitiated && (cognition.userControlRequired || meta.needsUserControl);
        if(cd.verdict==NoriConstitution.Verdict.BLOCK) control=true;
        return new Cycle(q,state,memory,cognition,meta,new NoriConstitutionView(cd.verdict.name(),cd.instruction),out,
                chooseStrategy(cognition,meta,cd),control,meta.needsFreshEvidence||cognition.staleKnowledgeRisk,world,humanPlan,research,causal,trace);
    }

    private CapabilityResult evaluate(NoriMetaBrainEngine.Capability c,String q,NoriState state,NoriCognitiveEngine.ThoughtState cog,
                                      NoriMetaBrainEngine.ThoughtPlan plan,boolean external,boolean initiated){
        switch(c){
            case COGNITIVE_LOOP: return r(c,Status.READY,"cognitive preflight + meta plan executed");
            case PERSONAL_WORLD_MODEL: return r(c,Status.READY,"unified state + governed memory context available");
            case TEMPORAL_INTELLIGENCE: return r(c,Status.READY,"state temporal sequence available");
            case CAUSAL_REASONING: return r(c,q.contains("why")?Status.READY:Status.READY,"causal claims require evidence; no causal certainty inferred");
            case COUNTERFACTUAL_REASONING: return r(c,contains(q,"what if")?Status.READY:Status.READY,"scenario reasoning available on request");
            case ADAPTIVE_PERSONALITY: return r(c,Status.READY,"answer shape follows cognition and capacity");
            case CONVERSATION_STATE: return r(c,Status.READY,brain.getMetaBrainEngine().conversationState(q));
            case RELATIONSHIP_CONTINUITY: return r(c,Status.READY,"continuity is checked through governed context, not dependency");
            case DYNAMIC_GOAL_GRAPH: return r(c,Status.READY,"goal decomposition engine available");
            case SKILL_GRAPH: return r(c,Status.READY,"skill decomposition available");
            case MISCONCEPTION_DETECTION: return r(c,Status.READY,"learning/error engines available");
            case TRANSFER_INTELLIGENCE: return r(c,Status.READY,"novel-context transfer assessment available");
            case RETENTION_MODEL: return r(c,Status.READY,"retrieval/retention assessment available");
            case STRATEGY_EXPERIMENTS: return r(c,Status.READY,"strategy outcome ledger available");
            case INTERVENTION_INTELLIGENCE: return r(c,Status.READY,"intervention engine respects interruption cost");
            case HUMAN_STATE_REASONING: return r(c,Status.READY,"explicit/contextual capacity signals available; no diagnosis");
            case DISCLOSURE_CONTEXT: return r(c,Status.READY,"voluntary disclosures can be treated as context only");
            case CONTRADICTION_RESOLUTION: return r(c, cog.contradictionRisk?Status.REVIEW:Status.READY,"contradiction risk="+cog.contradictionRisk);
            case EVIDENCE_GRAPH: return r(c, cog.needsEvidence?Status.REVIEW:Status.READY,"evidence required="+cog.needsEvidence);
            case SELF_CORRECTION: return r(c,Status.READY,"correction ledger available; no silent behavior mutation");
            case CAPABILITY_EXECUTION: return r(c, cog.needsTool?Status.REVIEW:Status.READY,"execution lifecycle is confirmation/verification gated");
            case EDGE_AI_EXECUTION: return edge(c,q);
            case MODEL_ARBITRATION: return r(c,Status.READY,brain.getEdgeAiEngine().status());
            case RESEARCH_BRAIN: return r(c,Status.READY,"bounded research depth="+brain.getMetaBrainEngine().researchDepth(q));
            case WORLD_AWARENESS: return r(c,plan.needsFreshEvidence?(external?Status.READY:Status.UNAVAILABLE):Status.READY,"freshness required="+plan.needsFreshEvidence+" external="+external);
            case APP_OPERATING_MODEL: return r(c,Status.READY,brain.getAppUnderstandingEngine().understand(q).message);
            case FAILURE_RECOVERY: return r(c,Status.READY,"safe retry/alternate route/fail-closed strategy available");
            case RESOURCE_INTELLIGENCE: return r(c,Status.READY,"bounded work units="+plan.estimatedWorkUnits);
            case SECURITY_BOUNDARY_INTELLIGENCE: return r(c,Status.READY,"Constitution + user control remain authoritative");
            case META_BRAIN: return r(c,Status.READY,"all 30 capability contracts evaluated in one cycle");
            default: return r(c,Status.UNAVAILABLE,"no evaluator");
        }
    }
    private CapabilityResult edge(NoriMetaBrainEngine.Capability c,String q){
        NoriEdgeAiEngine.Result x=brain.getEdgeAiEngine().select(NoriOnDeviceTask.TEXT_GENERATION,false);
        return r(c,x.handled?Status.READY:Status.UNAVAILABLE,x.handled?"local model="+x.modelId:"no compatible installed local model");
    }
    private static CapabilityResult r(NoriMetaBrainEngine.Capability c,Status s,String e){return new CapabilityResult(c,s,e);}
    private static boolean contains(String s,String x){return (" "+s.toLowerCase(Locale.ROOT)+" ").contains(" "+x+" ");}
    private static String chooseStrategy(NoriCognitiveEngine.ThoughtState c,NoriMetaBrainEngine.ThoughtPlan p,NoriConstitution.Decision d){
        if(d.verdict==NoriConstitution.Verdict.BLOCK)return "BLOCK_AND_EXPLAIN_BOUNDARY";
        if(d.verdict==NoriConstitution.Verdict.REVIEW)return "REVIEW_BEFORE_ACTION";
        if(c.needsClarification)return "CLARIFY_THEN_CONTINUE";
        if(p.needsFreshEvidence)return "FRESH_EVIDENCE_THEN_VERIFY";
        if(c.needsTool)return "PREPARE_AUTHORIZE_EXECUTE_VERIFY";
        return p.strategy;
    }
}
