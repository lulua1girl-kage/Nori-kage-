package com.nori.jarvis.nori.ai;

import org.junit.Test;
import static org.junit.Assert.*;

public class AiRouterStage11Test {
    @Test public void localIsDefaultAndAlwaysAvailable(){
        AiRouter r=new AiRouter();
        assertEquals("local",r.activeMode());
        AiResponse x=r.generate(new AiRequest("status"));
        assertEquals(AiResponse.Status.SUCCESS,x.status);
        assertFalse(x.remote);
    }
    @Test public void remoteRequiresExplicitConsent(){
        AiProviderConfig c=new AiProviderConfig(true,false,"test","https://example.invalid","token",1000);
        RemoteAiProvider p=new RemoteAiProvider(c);
        assertFalse(p.isAvailable());
        AiRouter r=new AiRouter();
        r.configureRemote(p,new AiRoutingPolicy(AiRoutingPolicy.Route.REMOTE_THEN_LOCAL,true));
        assertFalse(r.remoteEnabled());
        assertEquals(AiResponse.Status.SUCCESS,r.generate(new AiRequest("hello")).status);
    }
    @Test public void requestLimitsAreBounded(){
        AiRequest r=new AiRequest("hello",null,null,999999);
        assertEquals(20000,r.maxOutputCharacters);
        assertEquals("hello",r.prompt);
    }
}
