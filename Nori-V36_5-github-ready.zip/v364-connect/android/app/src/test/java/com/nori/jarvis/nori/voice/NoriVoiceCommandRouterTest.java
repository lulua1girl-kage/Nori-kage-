package com.nori.jarvis.nori.voice;
import org.junit.Test;import static org.junit.Assert.*;
public class NoriVoiceCommandRouterTest {
 @Test public void academicCommandsBecomeStructuredIntents(){NoriVoiceCommandRouter r=new NoriVoiceCommandRouter();assertEquals(NoriVoiceCommand.Type.NEW_RESULT,r.parse("Nori, new result to record").type);assertEquals(NoriVoiceCommand.Type.NEW_ASSESSMENT,r.parse("Nori, new assessment updates").type);assertEquals(NoriVoiceCommand.Type.NEW_ASSIGNMENT,r.parse("Nori, new assignment update").type);}
 @Test public void appAndExamCommandsAreSeparate(){NoriVoiceCommandRouter r=new NoriVoiceCommandRouter();assertEquals(NoriVoiceCommand.Type.OPEN_APP,r.parse("Nori open WPS").type);assertEquals(NoriVoiceCommand.Type.START_EXAM_MODE,r.parse("Nori, I have an exam tomorrow").type);}
}
