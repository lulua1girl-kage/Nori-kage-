package com.nori.jarvis.nori.focus;

public final class NoriFocusReasonerTest {
    public static void main(String[] args) {
        NoriFocusReasoner r = new NoriFocusReasoner();
        if (r.decide("com.instagram.android", "homework", "video chat", true, java.util.Collections.singleton("com.instagram.android")).decision != NoriFocusReasoner.Decision.ALLOW) throw new AssertionError("academic video chat should be allowed");
        if (r.decide("com.instagram.android", "study", "reels scroll", true, java.util.Collections.singleton("com.instagram.android")).decision != NoriFocusReasoner.Decision.BLOCK) throw new AssertionError("scrolling should be blocked");
        if (r.decide("com.example.app", "study", "unknown", true, java.util.Collections.singleton("com.instagram.android")).decision != NoriFocusReasoner.Decision.ALLOW) throw new AssertionError("unselected app must remain allowed");
        System.out.println("STEP9_REASONER_UNIT_PASS");
    }
}
