package com.nori.jarvis.nori.brain;

import com.nori.jarvis.nori.academic.model.Assessment;
import com.nori.jarvis.nori.brain.model.AcademicEventInput;
import com.nori.jarvis.nori.brain.model.BrainDecision;
import org.junit.Test;
import java.util.*;
import static org.junit.Assert.*;

public class NoriBrainStage7Test {
    @Test public void routesBasicIntents() {
        IntentEngine e=new IntentEngine();
        assertEquals(IntentEngine.Intent.PLAN,e.classify("make a study plan"));
        assertEquals(IntentEngine.Intent.SEARCH,e.classify("search this topic"));
        assertEquals(IntentEngine.Intent.VERIFY,e.classify("verify this result"));
    }

    @Test public void orchestratesAcademicAndContextWithoutWriting() {
        NoriBrain brain=new NoriBrain();
        Assessment assessment=new Assessment("quiz",65,Arrays.asList("algebra","vectors"),10,0,1);
        ContextEngine.Event context=new ContextEngine.Event("gaming",25,null,false,false,true,false,Arrays.asList("system_log","user_report"));
        BrainDecision result=brain.processAcademicEvent(new AcademicEventInput("Math",assessment,context,null,0,0,0,Collections.emptyList()));
        assertEquals("D1-D",result.academicResult.getBand());
        assertEquals(ContextEngine.ContextType.SUSTAINED_DELIBERATE_DISTRACTION,result.contextResult.type);
        assertEquals(com.nori.jarvis.nori.kage.KageEngine.FailureType.COMBINED_FAILURE,result.failureType);
        assertEquals(1,result.degreeDecision.degree);
        assertTrue(result.verification.isVerified());
        assertFalse(result.consequenceCandidates.isEmpty());
        assertEquals("error_autopsy",result.academicCorrection);
    }

    @Test public void academicOnlyDoesNotCreateDisciplinaryCandidates() {
        NoriBrain brain=new NoriBrain();
        Assessment assessment=new Assessment("assignment",70,Arrays.asList("cell division"),5,0,0);
        ContextEngine.Event context=new ContextEngine.Event("gaming",0,"academic research",false,false,false,false,Collections.singletonList("user_report"));
        BrainDecision result=brain.processAcademicEvent(new AcademicEventInput("Biology",assessment,context,null,0,0,0,Collections.emptyList()));
        assertEquals(com.nori.jarvis.nori.kage.KageEngine.FailureType.ACADEMIC_PROBLEM,result.failureType);
        assertTrue(result.consequenceCandidates.isEmpty());
        assertNotNull(result.academicCorrection);
    }
}
