package com.nori.jarvis.nori.state;

import com.nori.jarvis.nori.brain.ContextEngine;
import com.nori.jarvis.nori.conversation.engine.ConversationEngine;
import com.nori.jarvis.nori.education.EducationalIntelligence;
import com.nori.jarvis.nori.memory.MemoryEngine;
import com.nori.jarvis.nori.performance.NoriPerformance;
import com.nori.jarvis.nori.security.NoriSecurity;
import org.junit.Test;
import java.util.*;
import static org.junit.Assert.*;

public class NoriStateEngineTest {
    @Test public void composesExistingSubsystemsWithoutReplacingThem() {
        EducationalIntelligence education = new EducationalIntelligence();
        MemoryEngine memory = new MemoryEngine();
        ConversationEngine conversation = new ConversationEngine();
        NoriSecurity security = new NoriSecurity();
        security.reliability().initialize(true);
        NoriPerformance performance = new NoriPerformance();
        NoriStateEngine engine = new NoriStateEngine();

        memory.remember("Math is a priority subject.");
        conversation.acceptUserText("make a study plan");
        ContextEngine.Result context = new ContextEngine().classifyContext(
                new ContextEngine.Event("academic", 30, "academic study", false, false, false, false,
                        Arrays.asList("user_report", "study_log")));

        engine.observeAvailability(NoriState.Availability.BUSY, "studying");
        NoriState state = engine.observeAndRefresh(context, true, education, memory,
                conversation.state(), security, performance);

        assertEquals(NoriState.Availability.BUSY, state.situation.availability);
        assertEquals("studying", state.situation.activity);
        assertEquals("legitimate_activity", state.situation.contextType);
        assertTrue(state.situation.nearExam);
        assertEquals(1, state.memory.total);
        assertTrue(state.conversation.recentTurns >= 1);
        assertTrue(state.system.securityHealthy);
        assertTrue(state.system.reliabilityHealthy);
    }

    @Test public void stateIsReadOnlySnapshotAndSequenceAdvances() {
        NoriStateEngine engine = new NoriStateEngine();
        NoriState first = engine.refresh(new EducationalIntelligence(), new MemoryEngine(),
                new ConversationEngine().state(), new NoriSecurity(), new NoriPerformance());
        NoriState second = engine.refresh(new EducationalIntelligence(), new MemoryEngine(),
                new ConversationEngine().state(), new NoriSecurity(), new NoriPerformance());
        assertTrue(second.system.sequence > first.system.sequence);
        assertNotSame(first, second);
    }
}
