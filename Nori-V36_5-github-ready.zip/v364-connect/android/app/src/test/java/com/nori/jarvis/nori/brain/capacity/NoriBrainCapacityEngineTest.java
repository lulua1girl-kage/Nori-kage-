package com.nori.jarvis.nori.brain.capacity;

import com.nori.jarvis.nori.brain.human.HumanContextEngine;
import org.junit.Test;
import static org.junit.Assert.*;

public class NoriBrainCapacityEngineTest {
    @Test public void localRequestsAreInstantAndDoNotNeedExternal(){
        NoriBrainCapacityEngine e=new NoriBrainCapacityEngine();
        NoriBrainCapacityEngine.Plan p=e.plan("what is 15% of 240",null,true,false);
        assertEquals(NoriBrainCapacityEngine.Intent.CALCULATION,p.intent);
        assertEquals(NoriBrainCapacityEngine.Effort.INSTANT,p.effort);
        assertFalse(p.externalNeeded);
    }
    @Test public void difficultResearchEscalatesWithoutReplacingNori(){
        NoriBrainCapacityEngine e=new NoriBrainCapacityEngine();
        NoriBrainCapacityEngine.Plan p=e.plan("latest research on learning and sleep",null,false,false);
        assertTrue(p.researchNeeded); assertTrue(p.externalNeeded); assertTrue(p.localFirst);
    }
    @Test public void privateCausesAreOptional(){
        NoriBrainCapacityEngine e=new NoriBrainCapacityEngine();
        assertEquals(NoriBrainCapacityEngine.Disclosure.OPTIONAL,e.disclosurePolicy(NoriBrainCapacityEngine.Intent.LIFE_SUPPORT,false));
    }
    @Test public void strictnessNeedsPattern(){
        NoriBrainCapacityEngine e=new NoriBrainCapacityEngine();
        assertFalse(e.enoughEvidenceForStrictness(1,false,false));
        assertTrue(e.enoughEvidenceForStrictness(4,false,false));
        assertFalse(e.enoughEvidenceForStrictness(4,true,false));
    }
    @Test public void safetyWins(){
        HumanContextEngine h=new HumanContextEngine();
        HumanContextEngine.Assessment a=h.assess("I feel unsafe",0,0,true);
        NoriBrainCapacityEngine e=new NoriBrainCapacityEngine();
        assertTrue(e.requiresSafetyFirst(a));
        assertEquals(NoriBrainCapacityEngine.ResponseMode.SAFETY,e.responseMode(a,NoriBrainCapacityEngine.Intent.LIFE_SUPPORT));
    }
}
