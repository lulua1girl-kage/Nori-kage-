package com.nori.jarvis.nori.academic;

import com.nori.jarvis.nori.academic.model.AcademicAnalysisResult;
import com.nori.jarvis.nori.academic.model.Assessment;

import org.junit.Test;

import java.util.Arrays;
import java.util.Collections;

import static org.junit.Assert.*;

public class AcademicEngineTest {
    private final AcademicEngine engine = new AcademicEngine();

    @Test public void scoreBandsMatchV32() {
        assertEquals("D1-A", engine.getScoreBand(79).getId());
        assertEquals("D1-B", engine.getScoreBand(75).getId());
        assertEquals("D1-C", engine.getScoreBand(70).getId());
        assertEquals("D1-D", engine.getScoreBand(65).getId());
        assertEquals("D1-E", engine.getScoreBand(50).getId());
        assertNull(engine.getScoreBand(80));
    }

    @Test public void assessmentAnalysisMatchesPriorityRules() {
        Assessment a = new Assessment("quiz", 72,
                Arrays.asList("algebra"), 5, 0, 0);
        AcademicAnalysisResult r = engine.analyzeAssessment(a);
        assertEquals("D1-B", r.getBand());
        assertEquals(AcademicAnalysisResult.ErrorDistribution.LOCALIZED_WEAKNESS,
                r.getErrorDistribution());
        assertEquals(0.5, r.getEscalationWeight(), 0.0001);
        assertEquals(0.2, r.getConceptRatio(), 0.0001);
    }

    @Test public void carelessErrorsTakePrecedence() {
        Assessment a = new Assessment("final_examination", 65,
                Collections.singletonList("vectors"), 1, 2, 3);
        AcademicAnalysisResult r = engine.analyzeAssessment(a);
        assertEquals(AcademicAnalysisResult.ErrorDistribution.CARELESS_ERROR_PATTERN,
                r.getErrorDistribution());
        assertEquals(1.0, r.getEscalationWeight(), 0.0001);
    }

    @Test public void zeroConceptsProducesUnknownDistributionAndNullRatio() {
        Assessment a = new Assessment("practice", 90,
                Collections.emptyList(), 0, 0, 0);
        AcademicAnalysisResult r = engine.analyzeAssessment(a);
        assertNull(r.getBand());
        assertEquals(AcademicAnalysisResult.ErrorDistribution.UNKNOWN, r.getErrorDistribution());
        assertNull(r.getConceptRatio());
        assertNull(r.getTotalConceptsCovered());
    }

    @Test(expected = IllegalArgumentException.class)
    public void unknownAssessmentTypeIsRejected() {
        engine.analyzeAssessment(new Assessment("unknown", 50,
                Collections.emptyList(), 0, 0, 0));
    }
}
