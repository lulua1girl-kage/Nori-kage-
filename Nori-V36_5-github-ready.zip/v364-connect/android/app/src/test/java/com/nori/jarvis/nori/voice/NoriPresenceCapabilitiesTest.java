package com.nori.jarvis.nori.voice;

import org.junit.Test;
import java.util.Map;
import static org.junit.Assert.*;

public class NoriPresenceCapabilitiesTest {
    @Test public void presenceCapabilitiesRemainExplicit() {
        Map<String, Boolean> m = NoriPresenceCapabilities.defaults();
        assertTrue(m.get("bargeInInterrupt"));
        assertTrue(m.get("pauseResume"));
        assertTrue(m.get("liveTranscript"));
        assertTrue(m.get("sameChatVoiceText"));
        assertTrue(m.get("visualContextEntry"));
        assertTrue(m.get("nativeCameraCapture"));
        assertTrue(m.get("nativeScreenCapture"));
        assertTrue(m.get("visionContextForwarding"));
        assertTrue(m.get("boundedBackgroundVoice"));
        assertTrue(NoriPresenceCapabilities.requiresExplicitUserAction("camera"));
        assertTrue(NoriPresenceCapabilities.requiresExplicitUserAction("screen"));
        assertTrue(NoriPresenceCapabilities.requiresExplicitUserAction("backgroundVoice"));
    }
}
