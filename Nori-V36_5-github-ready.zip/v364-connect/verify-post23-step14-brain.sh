#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
for f in \
  "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/ai/AiRouter.java" \
  "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/ai/AiRequest.java" \
  "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java" \
  "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/human/HumanContextEngine.java" \
  "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/human/NoriSupportPolicy.java" \
  "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/research/ResearchIntelligence.java"; do test -s "$f"; done

grep -q 'local deterministic capability first' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/ai/AiRouter.java"
grep -q '10_000\|10000' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/ai/AiRouter.java"
grep -q 'configureExternalAiProviders' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/NoriBrain.java"
grep -q 'does not diagnose' "$ROOT/android/app/src/main/java/com/nori/jarvis/nori/brain/human/HumanContextEngine.java"
grep -q '10+ retrieved sources' "$ROOT/POST23-STEP14-BRAIN-EVOLUTION.md"

echo POST23_STEP14_BRAIN_HUMAN_CONTEXT_PROVIDER_CHAIN_PASS
